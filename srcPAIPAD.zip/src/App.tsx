import React, { useCallback, useEffect, useState } from 'react';
import { Provider } from 'react-redux';
import RootContainer, { navigationRef } from './base/navigation/RootContainer.Screen';
import 'react-native-gesture-handler';
import store from './base/stories';
// import messaging from '@react-native-firebase/messaging';
import Configure, { getDeviceId, getFcmToken, requestUserPermission } from './base/service/PushNotification';
import { NavigationContainer } from "@react-navigation/native";

// messaging().setBackgroundMessageHandler(async remoteMessage => {
//   console.log('Message handled in the background!', remoteMessage);
// });

const App = () => {

  // useEffect(() => {
  //   requestUserPermission()
  //   getDeviceId()
  // }, [])

  return (
    <Provider store={store}>
      <NavigationContainer ref={navigationRef}>
        <RootContainer />
        {/* <Configure /> */}
      </NavigationContainer>
    </Provider>
  );
};
export default App;
