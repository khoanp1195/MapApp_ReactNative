import React, { useState, useCallback, useEffect, } from 'react';
import { View, Text, } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { dimnensHeight, dimensWidth, funtionVBDiData, bottomTabName } from '~/base/Constants';
import colors from "../../base/Colors"
import { BASE_URL, FontSize } from '../../base/Constants'
import {
    isNullOrUndefined,
    arrayIsEmpty,
    format_dd_mm_yy,
    removeSpecialCharacters,
    removeNumbersAndHashes,
    byteConverter,
    checkTypeFiles,
    checkTrangThai,
    DownloadFile,
    splitID,
} from '../../base/Functions'
import { fetchAttachFiles, fetchDetailById, onResetVbbhDetailAction, submitActionShare } from '~/base/stories/vbbh/reducer';
import styles from './VBBH.Style'
import LinearGradient from 'react-native-linear-gradient';
import { FlatList, TouchableOpacity } from 'react-native-gesture-handler';
import { ClockWhiteIcon, DownloadIcon, HoSoDuThaoIcon, ShareBlueIcon, ThreeDotIcon, ViewFileFull } from '~/base/assets/svg';
import { Action } from './VBBH.Enum';
import { LoadingView, TextInputCustom } from '~/base/components';
import WebView from 'react-native-webview';
import FastImage from 'react-native-fast-image';
import WorkflowHistory from './components/WorkflowHistory.Modal';
import ShareModal from './components/Share.Modal';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { onChangeFuntionVBDiMenu, onChangeSellecteDocumentIDbDiAction } from '~/base/stories/home/reducer';

const ItemAction = ({ item, index, onActionPress }: any) => {
    if (index >= 2) return null;
    const { Title, ID } = item;
    // if(Title === 'Chia sẻ') return ShareBlueIcon
    return (
        <TouchableOpacity
            key={ID}
            style={styles.shareButton}
            onPress={() => onActionPress(ID)}
        >
            <View style={styles.flexDirectionRowAction}>
                <IconView ID={ID} />
                <Text style={styles.tabBarLabelActive} numberOfLines={1}>
                    {Title}
                </Text>
            </View>
        </TouchableOpacity>
    );
};

const IconView = ({ ID }: any) => {
    if (ID === Action.ChiaSe)
        return <ShareBlueIcon color={colors.white} dimens={20} />;
    if (ID === Action.HoSoDuThao) return <HoSoDuThaoIcon />;
    return <View />;
};

const ItemFile = ({ item, index, selectedIndex, onItemPress, DownloadFile, token }: any) => {
    const {
        Title,
        Author,
        Created,
        Category,
        Size,
        Url
    } = item;

    const createdFormated = format_dd_mm_yy(Created);
    const FileIcon = () => {
        return checkTypeFiles(Url);
    };
    const fileSize = Size ? byteConverter(Size, 0) : null;
    const color = index % 2 == 0 ? '#EFF7FF' : '#FFFFFF'

    return (
        <TouchableOpacity
            onPress={() => onItemPress(index)}
            style={{
                flex: 1,
                flexDirection: 'row',
                height: dimnensHeight(40),
                backgroundColor: index % 2 == 0 ? '#EFF7FF' : '#FFFFFF',
                alignItems: 'center',
            }}>
            <View style={{
                backgroundColor: selectedIndex === index ? '#005FD4' : color,
                width: dimensWidth(5),
                height: '100%',
                marginRight: dimensWidth(20)
            }} />
            <View style={{
                flex: 0.3
            }}>
                <FileIcon />
            </View>
            <Text style={{
                flex: 2,
                color: '#015DD1',
                fontSize: FontSize.MEDIUM,
                fontWeight: 400
            }}
                numberOfLines={1}>{Title}</Text>

            <Text style={{
                flex: 0.5,
                color: '#5E5E5E',
                fontSize: FontSize.SMALL,
                marginLeft: dimensWidth(10)
            }}
                numberOfLines={1}>{fileSize}</Text>
            <Text style={{
                flex: 1,
                color: '#000000',
                fontSize: FontSize.MEDIUM,
                marginLeft: dimensWidth(10)
            }}
                numberOfLines={1}>{Category}</Text>

            <Text style={{
                flex: 1,
                color: '#000000',
                fontSize: FontSize.MEDIUM,
            }}
                numberOfLines={1}>{Author}</Text>

            <Text style={{
                flex: 0.8,
                color: '#5E5E5E',
                fontSize: FontSize.SMALL,
            }}
                numberOfLines={1}>{createdFormated}</Text>

            <TouchableOpacity style={{
                marginRight: dimensWidth(10)
            }} onPress={() => DownloadFile(item, token)}>
                <View>
                    <DownloadIcon color='#005FD4' />
                </View>
            </TouchableOpacity>

        </TouchableOpacity>
    )
}

const ItemComment = ({ item, index, token, subSite }: any) => {
    const { Title, Value, ImagePath, Position, Created } = item;
    const createdFormated = format_dd_mm_yy(Created);
    const isOdd = index % 2 === 0;
    const pos = !isNullOrUndefined(Position) ? Position.split(";#")[1] : "";
    return (
        <View
            style={{
                backgroundColor: isOdd ? colors.alice_blue : colors.white,
                padding: 15,
                flexDirection: 'row'
            }}>
            <FastImage
                style={{
                    height: dimensWidth(40),
                    width: dimensWidth(40),
                    marginRight: dimensWidth(10),
                    borderRadius: dimensWidth(20),
                }}
                source={{
                    uri: `${BASE_URL}/${subSite}/${ImagePath}`,
                    headers: { Authorization: `${token}` },
                    priority: FastImage.priority.normal,
                }}
                defaultSource={require("base/assets/images/avatar80.png")}
                resizeMode={FastImage.resizeMode.contain}
            />
            <View style={{
                flex: 1
            }}>
                <Text style={styles.titleCommentJson}>{Title}</Text>
                <Text style={styles.positionComment}>{pos}</Text>

                <Text style={{
                    marginTop: dimnensHeight(10),
                    fontSize: FontSize.MEDIUM,
                    color: colors.textBlack19,
                    fontWeight: "400",
                    fontFamily: "arial",
                    borderRadius: 4,
                }}>{Value}</Text>
            </View>
            <Text style={styles.titleCommentJson}>{createdFormated}</Text>
        </View>
    );
}

const ItemTask = ({
    item,
    index,
    subSite,
    token,
    gotoNhiemVuDaPhanCongScreen,
}: any) => {
    const {
        AssignedToType,
        TrangThai,
        DepartmentTitle,
        Position,
        Created,
        DeThucHien,
        DueDate,
        ImagePath,
        ID,
    } = item;
    const createdFormated = format_dd_mm_yy(Created);
    const isOdd = index % 2 === 0;
    const customColor = checkTrangThai(TrangThai);
    const pos = !isNullOrUndefined(Position) ? Position.split(';#')[1] : Position;
    return (
        <TouchableOpacity activeOpacity={1} style={{
            height: dimnensHeight(70),
            width: '100%',
            backgroundColor: index % 2 == 0 ? colors.alice_blue : colors.white
        }}>
            {
                AssignedToType == 1 ? (
                    <View style={{
                        flex: 1,
                        flexDirection: 'row',
                        alignItems: 'center',
                        paddingLeft: dimensWidth(15),
                        paddingRight: dimensWidth(15)
                    }}>
                        <Text style={{
                            flex: 1, fontSize: FontSize.MEDIUM,
                            color: colors.textBlack19,
                            fontWeight: "400",
                            fontFamily: "arial",
                            borderRadius: 4
                        }}>{DepartmentTitle}</Text>
                        <Text style={{
                            flex: 1,
                            color: DeThucHien ? '#0072C6' : '#5E5E5E'
                        }}>{DeThucHien ? "Thực hiện" : "Phối hợp"}</Text>
                        <View>
                            <Text>{createdFormated}</Text>
                            <View
                                style={[
                                    styles.viewTrangThai,
                                    { backgroundColor: customColor?.backgroundColor },
                                ]}
                            >
                                <Text
                                    style={[styles.textTrangThai, { color: customColor?.color }]}
                                    numberOfLines={1}
                                >
                                    {TrangThai}
                                </Text>
                            </View>
                        </View>
                    </View>
                ) : <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    paddingLeft: dimensWidth(15),
                    paddingRight: dimensWidth(15),
                    alignItems: 'center'
                }}>
                    <View style={{
                        flex: 1,
                        flexDirection: 'row'
                    }}>
                        <FastImage
                            style={{
                                height: dimensWidth(40),
                                width: dimensWidth(40),
                                marginRight: dimensWidth(10),
                                borderRadius: dimensWidth(20),
                            }}
                            source={{
                                uri: `${BASE_URL}/${subSite}/${ImagePath}`,
                                headers: { Authorization: `${token}` },
                                priority: FastImage.priority.normal,
                            }}
                            defaultSource={require("base/assets/images/avatar80.png")}
                            resizeMode={FastImage.resizeMode.contain}
                        />

                        <View style={{
                            flex: 1
                        }}>
                            <Text style={styles.titleCommentJson}>{DepartmentTitle}</Text>
                            <Text style={styles.positionComment}>{pos}</Text>
                        </View>
                    </View>
                    <Text style={{
                        flex: 1,
                        color: DeThucHien ? '#0072C6' : '#5E5E5E'
                    }}>{DeThucHien ? "Thực hiện" : "Phối hợp"}</Text>

                    <View>
                        <Text>{createdFormated}</Text>
                        <View
                            style={[
                                styles.viewTrangThai,
                                { backgroundColor: customColor?.backgroundColor },
                            ]}
                        >
                            <Text
                                style={[styles.textTrangThai, { color: customColor?.color }]}
                                numberOfLines={1}
                            >
                                {TrangThai}
                            </Text>
                        </View>
                    </View>
                </View>
            }
        </TouchableOpacity>
    );
};

const VBBHDetail = ({ route, navigation, selectedItemIndex }: any) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { subSite, token } = useSelector((state: any) => state.login);
    const { dataDetailVB, dataFiles, isLoadingVBBHDetail, isLoadingVBBH } = useSelector((state: any) => state.vbbh);
    const [ItemId, setItemId] = useState()
    const [ItemVB, setItemVB] = useState<any>({})
    const [hiddenInfo, setHiddenInfo] = useState(false)
    const [comment, setComment] = useState("")
    const [dataFileState, setDataFileState] = useState([])
    const [dataAttachFileWebView, setDataAttachFileWebView] = useState({})
    const [modalWorkflowHistory, setModalWorkflowHistory] = useState(false)
    const [modalShare, setModalShare] = useState(false)
    const [selectIndexFile, setSeletedIndexFile] = useState(0)

    const onHiddenInfo = useCallback(() => {
        setHiddenInfo(!hiddenInfo)
    }, [hiddenInfo])

    const fetchData = useCallback(async (Id: any, sub: any) => {
        const item = {
            SubSite: sub,
            ItemId: Id
        }
        dispatch(fetchDetailById(item));
        dispatch(fetchAttachFiles(item))
    }, [dispatch]);
    useEffect(() => {
        if (route.ItemId !== undefined) {
            setItemId(route.ItemId)
            fetchData(route.ItemId, subSite)
        } else {
            dispatch(onResetVbbhDetailAction(null))
        }
    }, [dispatch, route.ItemId, subSite, selectedItemIndex])

    useEffect(() => {
        if (!isNullOrUndefined(dataDetailVB)) {
            setItemVB(dataDetailVB)
        }
    }, [dataDetailVB])

    useEffect(() => {
        if (!isNullOrUndefined(dataFiles)) {
            setDataFileState(dataFiles)
            setDataAttachFileWebView(dataFiles[0])
        }
    }, [dataFiles])

    const onCommentChanged = useCallback((text: string) => {
        setComment(text)
    }, [comment])
    const onConfirmHoSoDuThao = useCallback(
        (data: any) => {

            if (!isNullOrUndefined(data?.InfoVBDi)) {
                const DocumentID = splitID(data?.InfoVBDi)
                dispatch(onChangeSellecteDocumentIDbDiAction(DocumentID))
                dispatch(onChangeFuntionVBDiMenu(funtionVBDiData.DaPheDuyet))
                navigation.navigate(bottomTabName.TrangChu, {
                    screen: "VBDiMenu",
                });
            }
        }, [dataDetailVB],
    )
    const onActionPress = useCallback(
        (ID: number) => {
            console.log('dataDetailVBdataDetailVB', dataDetailVB);

            if (ID === Action.ChiaSe) setModalShare(true)
            if (ID === Action.HoSoDuThao) onConfirmHoSoDuThao(dataDetailVB)
        },
        [dataDetailVB]
    );

    const onConfirmShareModal = useCallback((data) => {
        let tmpValue = ''
        for (let index = 0; index < data.data.length; index++) {
            const element = data.data[index];
            tmpValue += element.AccountID + ';#' + element.AccountName + ';#';
        }

        dispatch(
            submitActionShare({
                SubSite: subSite,
                UserShared: tmpValue.substring(0, tmpValue.length - 2),
                Comment: data.text,
                ItemId
            })
        )

        setModalShare(false)
    }, [ItemId])

    const onCloseShareModal = useCallback(() => {
        setModalShare(false)
    }, [modalShare])

    const onCloseWorkflowHistoryModal = useCallback(() => {
        setModalWorkflowHistory(false)
    }, [modalWorkflowHistory])
    const onItemFilePress = useCallback((index) => {
        const element = dataFileState[index]
        setDataAttachFileWebView(element)
        setSeletedIndexFile(index)
    }, [dataFileState, selectIndexFile])

    return (
        <View style={{
            flex: 1,
            backgroundColor: isLoadingVBBHDetail ? "rgba(0, 0, 0, 0.1333333)" : 'white'
        }}>
            <LinearGradient style={{
                paddingLeft: dimensWidth(15),
                height: dimnensHeight(55),
                alignItems: 'center',
                flexDirection: 'row',
                justifyContent: 'flex-end',
                paddingRight: dimensWidth(15)
            }}
                colors={["#0262E9", "#0054AE"]}>
                {!arrayIsEmpty(ItemVB?.ActionJson) && !isLoadingVBBHDetail ? (
                    <View style={[styles.actionView]}>
                        {ItemVB?.ActionJson.map((item: any, index: any) => {
                            return (
                                <ItemAction
                                    key={index}
                                    item={item}
                                    index={index}
                                    onActionPress={onActionPress}
                                />
                            );
                        })}
                    </View>
                ) : null}
                {!isLoadingVBBHDetail &&
                    <TouchableOpacity style={{
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}
                        onPress={() => { setModalWorkflowHistory(true) }}>
                        <ClockWhiteIcon />
                    </TouchableOpacity>}
            </LinearGradient>
            <KeyboardAwareScrollView style={{
                flex: 1,
                backgroundColor: colors.white
            }}>
                <View style={{
                    paddingLeft: dimensWidth(15),
                    paddingRight: dimensWidth(15),
                    paddingTop: dimnensHeight(20),
                    paddingBottom: dimnensHeight(20)
                }}>
                    <View style={{
                        flex: 1,
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <Text style={{
                            color: '#005FD4',
                            fontWeight: 700,
                            fontSize: FontSize.LARGE_X,
                            flex: 1,
                        }}>{ItemVB?.TrichYeu}</Text>
                        <TouchableOpacity onPress={onHiddenInfo}>
                            <ThreeDotIcon color={!hiddenInfo ? "#C5C5C5" : '#0072C6'} />
                        </TouchableOpacity>
                    </View>
                    {
                        hiddenInfo ? <View style={{ marginTop: dimnensHeight(20) }} /> : <View>
                            <View style={{
                                width: '100%',
                                height: 1,
                                backgroundColor: '#B3B3B3',
                                marginTop: dimnensHeight(15)
                            }} />
                            <View style={{
                                flex: 1,
                                flexDirection: 'row',
                                marginTop: dimnensHeight(20)
                            }}>
                                <View style={{
                                    flex: 1
                                }}>
                                    <View>
                                        <Text style={styles.titleDoc}>Sổ văn bản</Text>
                                        <Text style={styles.valueDoc}>{ItemVB?.Title}</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.titleDoc}>Số văn bản</Text>
                                        <Text style={styles.valueDoc}>{removeSpecialCharacters(ItemVB?.SoVanBan)}</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.titleDoc}>Người ký văn bản</Text>
                                        <Text style={styles.valueDoc}>{removeSpecialCharacters(ItemVB?.NguoiKyVanBan)}</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.titleDoc}>Người soạn thảo</Text>
                                        <Text style={styles.valueDoc}>{ItemVB?.NguoiSoanThaoText}</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.titleDoc}>Độ mật</Text>
                                        <Text style={styles.valueDoc}>{ItemVB?.DoMat}</Text>
                                    </View>
                                </View>
                                <View style={{
                                    flex: 1
                                }}>
                                    <View>
                                        <Text style={styles.titleDoc}>Loại văn bản</Text>
                                        <Text style={styles.valueDoc}>{removeSpecialCharacters(ItemVB?.DocumentType)}</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.titleDoc}>Ngày ban hành</Text>
                                        <Text style={styles.valueDoc}>{format_dd_mm_yy(ItemVB?.ReceivedDate)}</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.titleDoc}>Chức vụ</Text>
                                        <Text style={styles.valueDoc}>{ItemVB?.ChucVu}</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.titleDoc}>Đơn vị soạn thảo</Text>
                                        <Text style={styles.valueDoc}>{removeSpecialCharacters(ItemVB?.DonViSoanThao)}</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.titleDoc}>Độ khẩn</Text>
                                        <Text style={styles.valueDoc}>{ItemVB?.DoKhan}</Text>
                                    </View>
                                </View>
                            </View>

                        </View>
                    }
                    <Text style={{
                        marginTop: dimnensHeight(10),
                        marginBottom: dimnensHeight(15),
                        color: '#000000',
                        fontSize: FontSize.LARGE,
                        fontWeight: 700
                    }}>Danh sách nhận văn bản qua mạng</Text>

                    <Text style={styles.titleDoc}>Cá nhân</Text>
                    <Text style={styles.valueDoc} numberOfLines={1}>
                        {ItemVB?.PeopleText}
                    </Text>
                    <Text style={styles.titleDoc}>Đơn vị</Text>
                    <Text style={styles.valueDoc} numberOfLines={3}>
                        {removeNumbersAndHashes(ItemVB?.DonVi)}
                    </Text>

                    <Text style={{
                        marginBottom: dimnensHeight(15),
                        color: '#000000',
                        fontSize: FontSize.LARGE,
                        fontWeight: 700
                    }}>Danh sách nhận văn bản ngoài hệ thống</Text>

                    <Text style={styles.titleDoc}>Đơn vị</Text>
                    <Text style={styles.valueDoc} numberOfLines={3}>
                        {removeNumbersAndHashes(ItemVB?.LTDonVi)}
                    </Text>
                    {
                        arrayIsEmpty(dataFiles) ? <View /> :
                            <View>
                                <View style={{
                                    flex: 1,
                                    width: '100%',
                                    height: dimnensHeight(350),
                                    backgroundColor: 'white',
                                    borderRadius: 8,
                                    shadowColor: '#000000',
                                    shadowOffset: {
                                        width: 0,
                                        height: 1
                                    },
                                    shadowRadius: 4,
                                    shadowOpacity: 0.3,
                                }}>
                                    <WebView
                                        source={{ uri: BASE_URL + dataAttachFileWebView?.Url }}
                                        style={{ flex: 1 }}
                                        sharedCookiesEnabled
                                    />
                                    <View style={{
                                        position: 'absolute',
                                        alignSelf: 'flex-end',
                                        bottom: 15,
                                        right: 15
                                    }}>
                                        <TouchableOpacity>
                                            <ViewFileFull />
                                        </TouchableOpacity>
                                    </View>

                                </View>
                                <Text style={{
                                    marginTop: dimnensHeight(20),
                                    marginBottom: dimnensHeight(15),
                                    fontSize: FontSize.LARGE_X,
                                    color: '#000000',
                                    fontWeight: 700
                                }}>Tài liệu đính kèm</Text>
                                <FlatList
                                    style={{
                                        borderWidth: 1,
                                        borderRadius: 4,
                                        borderColor: '#DDDDDD'
                                    }}
                                    data={dataFileState}
                                    renderItem={({ item, index }) => (
                                        <ItemFile item={item} index={index} token={token}
                                            selectedIndex={selectIndexFile}
                                            onItemPress={onItemFilePress}
                                            DownloadFile={(item) => DownloadFile(item, token)} />
                                    )}
                                    extraData={dataFileState}
                                    disableVirtualization
                                    nestedScrollEnabled
                                    scrollEnabled={false}
                                    keyExtractor={(item, index) => String(index)}
                                />
                            </View>
                    }
                    <View>
                        <Text style={{
                            marginTop: dimnensHeight(20),
                            color: '#000000',
                            fontSize: FontSize.LARGE,
                            fontWeight: 700
                        }}>Ý kiến lãnh đạo</Text>

                        <TextInputCustom
                            editable={true}
                            placeholder="Vui lòng nhập ý kiến"
                            placeholderTextColor={colors.grey999}
                            multiline
                            onChangeText={onCommentChanged}
                            style={styles.commentInput}
                        />
                        {!arrayIsEmpty(ItemVB?.CommentJson) && (
                            <FlatList
                                nestedScrollEnabled
                                scrollEnabled={false}
                                style={styles.commentJsonFlatlist}
                                extraData={ItemVB?.CommentJson}
                                disableVirtualization
                                horizontal={false}
                                keyExtractor={(item) => item?.ID}
                                data={ItemVB?.CommentJson}
                                renderItem={({ item, index }) => (
                                    <ItemComment item={item} index={index} />
                                )}
                            />
                        )}
                    </View>
                    {
                        !arrayIsEmpty(ItemVB.TaskJson) ?
                            <View>
                                <Text style={{
                                    marginTop: dimnensHeight(20),
                                    marginBottom: dimnensHeight(15),
                                    fontSize: FontSize.LARGE_X,
                                    color: '#000000',
                                    fontWeight: 700
                                }}>Tổ chức phân công thực hiện</Text>
                                <FlatList
                                    nestedScrollEnabled
                                    scrollEnabled={false}
                                    style={styles.danhMucFlatList}
                                    extraData={ItemVB?.TaskJson}
                                    disableVirtualization
                                    horizontal={false}
                                    keyExtractor={(item, index) => index.toString()}
                                    data={ItemVB?.TaskJson}
                                    renderItem={({ item, index }) => (
                                        <ItemTask
                                            item={item}
                                            index={index}
                                        />
                                    )}
                                />
                            </View>
                            : null
                    }
                </View>
            </KeyboardAwareScrollView>
            <LoadingView isLoading={isLoadingVBBHDetail} bgColor={colors.white} viewLoadingStyle={{ top: dimnensHeight(55) }} />
            <WorkflowHistory
                modalVisible={modalWorkflowHistory}
                ItemId={ItemId}
                onCloseModal={onCloseWorkflowHistoryModal}
            />

            <ShareModal
                modalVisible={modalShare}
                onCloseModal={onCloseShareModal}
                Comment={comment}
                ItemId={ItemId}
                onConfirmModal={(data) => onConfirmShareModal(data)}
            />
        </View>
    )
}

export default VBBHDetail