import React, { FC, useState, useCallback, useEffect } from "react";
import {
    Modal,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    KeyboardAvoidingView,
} from "react-native";
import colors from "~/base/Colors";
import { FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";
import { arrayIsEmpty, isNullOrUndefined } from "~/base/Functions";
import { CloseXIcon, ConfirmIcon } from "~/base/assets/svg";
import { TextInputCustom } from "~/base/components";
import ModalCusTom from "~/base/components/ModalCusTom";
import UserGroupModal from "~/base/components/UserGroup.Modal";

interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    onConfirmModal: (data: any) => void;
    Comment: string;
    ItemId: any;
}

const ShareModal: FC<Props> = ({
    modalVisible,
    onCloseModal,
    onConfirmModal,
    Comment,
    ItemId,
    ...props
}: Props) => {
    const [modalUserGroup, setModalUserGroup] = useState(false)
    const [value, setValue] = useState({})
    const [textValue, setTextValue] = useState("")
    const [comment, setComment] = useState("")

    const onUserGroupPress = useCallback(() => {
        setModalUserGroup(!modalUserGroup)
    }, [modalUserGroup])

    const onCloseOwnModal = () => {
        setComment("")
        setTextValue("")
        onCloseModal()
    }

    const onConfirmOwnModal = () => {
        if (isNullOrUndefined(textValue)) {
            alert("Vui lòng chọn người bạn muốn chia sẻ!");
        } else {
            setTextValue("")
            setComment("")
            onConfirmModal({ ...value, text: comment })
        }
    }

    useEffect(() => {
        setComment(Comment)
    }, [Comment])

    const onChangeText = useCallback(
        (input: string) => {
            setComment(input);
        },
        [comment]
    );

    const onConfirmUserGroup = useCallback((data) => {
        setModalUserGroup(false)
        if (!arrayIsEmpty(data)) {
            let tmpText = ''
            for (let index = 0; index < data.length; index++) {
                tmpText += data[index].FullName + "; ";
            }

            setTextValue(tmpText.substring(0, tmpText.length - 2))
            setValue({
                data: data,
                text: comment
            })
        } else {
            setTextValue("")
            setValue({})
        }
    }, [ItemId,value, textValue, comment])

    return (
        <ModalCusTom
            transparent={true}
            visible={modalVisible}
            {...props}
            onCloseModalCustom={onCloseModal}
            style={styles.centeredView}
        >
            <KeyboardAvoidingView style={styles.centeredView}>
                <View style={styles.modalView}>
                    <View style={{
                        padding: dimensWidth(20),
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <Text style={{
                            flex: 1,
                            color: '#005FD4',
                            fontSize: FontSize.LARGE_X,
                            fontWeight: 700,
                        }}>Chia sẻ</Text>
                        <TouchableOpacity style={{
                            marginRight: dimensWidth(40)
                        }}
                            onPress={onConfirmOwnModal}>
                            <ConfirmIcon />
                        </TouchableOpacity>
                        <TouchableOpacity onPress={onCloseOwnModal}>
                            <CloseXIcon />
                        </TouchableOpacity>
                    </View>
                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        backgroundColor: '#F6F8FA'
                    }} />

                    <View style={{
                        flexDirection: 'row'
                    }}>
                        <Text style={{
                            fontSize: FontSize.SMALL,
                            color: colors.lightBlack,
                            fontWeight: "400",
                            fontFamily: "arial",
                            marginTop: dimnensHeight(20),
                            marginLeft: dimnensHeight(20),
                            marginBottom: dimnensHeight(6)
                        }}>Chia sẻ</Text>
                        <Text style={{
                            color: colors.red,
                            marginTop: dimnensHeight(20)
                        }}> (*)</Text>
                    </View>
                    <View style={styles.chooseTypeView}>
                        <TouchableOpacity
                            style={styles.typeChild}
                            onPress={onUserGroupPress}
                        >
                            <Text style={styles.textFiltedType} numberOfLines={1}>
                                {textValue}
                            </Text>
                        </TouchableOpacity>
                    </View>
                    <Text style={{
                        fontSize: FontSize.SMALL,
                        color: colors.lightBlack,
                        fontWeight: "400",
                        fontFamily: "arial",
                        paddingLeft: dimensWidth(20),
                        marginBottom: dimnensHeight(6)
                    }}>Ý kiến</Text>
                    <TextInputCustom
                        placeholder="Vui lòng nhập ý kiến"
                        placeholderTextColor={colors.grey999}
                        multiline
                        onChangeText={(text) => onChangeText(text)}
                        value={comment}
                        style={styles.yKienLanhDaoInput}
                    />
                </View>
            </KeyboardAvoidingView>

            <UserGroupModal
                modalVisible={modalUserGroup}
                onCloseModal={onUserGroupPress}
                onConfirmModal={(data) => onConfirmUserGroup(data)}
                defaultValue={value}
            />
        </ModalCusTom>
    )
}

const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(0,0,0,0.4)"
    },
    modalView: {
        height: dimnensHeight(640),
        width: dimensWidth(750),
        backgroundColor: 'white',
        borderRadius: 20,
        overflow: 'hidden'
    },
    chooseTypeView: {
        marginBottom: dimnensHeight(20),
        flexDirection: "row",
        alignItems: "center",
        height: dimnensHeight(35),
        borderColor: colors.greyDDD,
        borderWidth: 1,
        borderRadius: 3,
        marginHorizontal: dimnensHeight(20),
    },
    textType: {
        fontSize: FontSize.SMALL,
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: dimnensHeight(20),
        marginVertical: 10,
    },
    typeChild: {
        flexDirection: "row",
        flex: 1,
        alignItems: "center",
        paddingHorizontal: dimnensHeight(10),
        justifyContent: "space-between",
    },
    textFiltedType: {
        fontSize: FontSize.MEDIUM,
        color: colors.black,
        fontWeight: "400",
        fontFamily: "arial",
        marginRight: 9,
    },
    yKienLanhDaoInput: {
        paddingHorizontal: 10,
        borderColor: colors.greyDDD,
        borderRadius: 3,
        height: dimensWidth(100),
        borderWidth: 1,
        marginHorizontal: dimnensHeight(20),
        marginBottom: dimnensHeight(10),
        textAlignVertical: "top",
    }
});

export default ShareModal