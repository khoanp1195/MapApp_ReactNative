import { Alert, Modal, StyleSheet, Text, Pressable, View, TouchableOpacity, Dimensions, KeyboardAvoidingView } from 'react-native';
import React, { FC, useState, useCallback, useMemo, useEffect } from "react";
import { BASE_URL, FontSize, dimensWidth, dimnensHeight } from '~/base/Constants';
import { Action, TaskRole, TaskVB } from '../VBDen.Enum';
import {
    AssignGreenIcon,
    KetThucIcon,
    CloseXIcon,
    ActionMoreIcon,
    TraoDoiLaiIcon,
    SaveIcon,
    DownloadIcon,
    ViewFileFull,
    DropDownIcon,
    DateIcon,
    UserGreyIcon,
} from "../../../base/assets/svg";
import colors from '../../../base/Colors'
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { fetchTaskById, submitActionTaskCompleted, submitActionTaskFeedback, submitActionTaskSave } from '~/base/stories/vbden/reducer';
import { DownloadFile, arrayIsEmpty, byteConverter, checkIsEmpty, checkTypeFiles, formatDate, format_dd_mm_yy, format_yy_mm_dd, isNullOrEmpty, isNullOrUndefined, removeSpecialCharacters } from '~/base/Functions';
import ActionModal from './components/Action.Modal';
import { FlatList, TextInput } from 'react-native-gesture-handler';
import WebView from 'react-native-webview';
import { TextInputCustom } from '~/base/components';
import UserGroupOnlyModal from '~/base/components/UserGroupOnly.Modal';
import CalendarPickerTaskModal from './components/CalendarPicker.Task.Modal';
import FeedbackModal from './components/Feedback.Modal';
import StatusModal from './components/Status.Modal';
import FileModal from '~/base/components/File.Modal';
import CompletedModal from './components/Completed.Modal';
import { fetchSetting } from '~/base/stories/data/reducer';
import AssignmentModal from './components/Assignment.Modal';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import ModalCusTom from '~/base/components/ModalCusTom';
import FastImageCustom from '~/base/components/FastImageCustom';

interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    CommentJson: any;
    TaskId: any,
    ItemVB: any,
    AttachFiles: any,
}

const TaskModal: FC<Props> = ({
    modalVisible,
    onCloseModal,
    CommentJson,
    TaskId,
    ItemVB,
    AttachFiles,
    ...props
}: Props) => {
    const ItemAction = ({ item, index, onActionPress }: any) => {
        if (index >= 3) return null;
        const { Title, ID } = item;
        return (
            <TouchableOpacity
                key={ID}
                style={styles.shareButton}
                onPress={() => onActionPress(ID)}
            >
                <View style={styles.flexDirectionRowAction}>
                    <IconView ID={ID} />
                    <Text style={styles.tabBarLabelActive} numberOfLines={1}>
                        {Title}
                    </Text>
                </View>
            </TouchableOpacity>
        );
    };

    const ItemFile = ({ item, selectFileIndex, index, DownloadFile, onItemFilePress }: any) => {
        const {
            Title,
            Author,
            Created,
            Category,
            Size,
            Url
        } = item;

        const createdFormated = format_dd_mm_yy(Created);
        const FileIcon = () => {
            return checkTypeFiles(Url);
        };
        const fileSize = Size ? byteConverter(Size, 0) : null;
        const isOdd = index % 2 == 0 ? '#EFF7FF' : '#FFFFFF'
        return (
            <View style={{
                flex: 1,
                flexDirection: 'row',
                height: dimnensHeight(40),
                backgroundColor: isOdd,
                alignItems: 'center'
            }}>
                <View style={{
                    backgroundColor: selectFileIndex === index ? '#005FD4' : isOdd,
                    width: dimensWidth(5),
                    height: '100%',
                    marginRight: dimensWidth(20)
                }} />
                <View style={{
                    flex: 0.3
                }}>
                    <FileIcon />
                </View>
                <View style={{
                    flex: 2
                }}>
                    <TouchableOpacity onPress={() => onItemFilePress(index)}>
                        <Text style={{
                            color: '#015DD1',
                            fontSize: FontSize.MEDIUM,
                            fontWeight: 400
                        }}
                            numberOfLines={1}>{Title}</Text>
                    </TouchableOpacity>

                </View>


                <Text style={{
                    flex: 0.5,
                    color: '#5E5E5E',
                    fontSize: FontSize.SMALL,
                    marginLeft: dimensWidth(10)
                }}
                    numberOfLines={1}>{fileSize}</Text>
                <Text style={{
                    flex: 1,
                    color: '#000000',
                    fontSize: FontSize.MEDIUM,
                    marginLeft: dimensWidth(10)
                }}
                    numberOfLines={1}>{Category}</Text>

                <Text style={{
                    flex: 1,
                    color: '#000000',
                    fontSize: FontSize.MEDIUM,
                }}
                    numberOfLines={1}>{Author}</Text>

                <Text style={{
                    flex: 0.8,
                    color: '#5E5E5E',
                    fontSize: FontSize.SMALL,
                }}
                    numberOfLines={1}>{createdFormated}</Text>

                <TouchableOpacity style={{
                    marginRight: dimensWidth(10)
                }}
                    onPress={() => DownloadFile(item)}>
                    <View>
                        <DownloadIcon color='#005FD4' />
                    </View>
                </TouchableOpacity>

            </View>
        )
    }

    const ItemComment = ({ item, index, token, subSite }: any) => {
        const { Title, Value, ImagePath, Position, Created } = item;
        const createdFormated = format_dd_mm_yy(Created);
        const isOdd = index % 2 === 0;
        const pos = !isNullOrUndefined(Position) ? Position.split(";#")[1] : "";
        return (
            <View
                style={{
                    backgroundColor: isOdd ? colors.alice_blue : colors.white,
                    padding: 15,
                    flexDirection: 'row'
                }}>
                <FastImageCustom
                    styleImg={{
                        height: dimensWidth(40),
                        width: dimensWidth(40),
                        marginRight: dimensWidth(10),
                        borderRadius: dimensWidth(20),
                    }}
                    urlOnline={`${BASE_URL}/${subSite}/${ImagePath}`}
                />
                <View style={{
                    flex: 1
                }}>
                    <Text style={styles.titleCommentJson}>{Title}</Text>
                    <Text style={styles.positionComment}>{pos}</Text>

                    <Text style={{
                        marginTop: dimnensHeight(10),
                        fontSize: FontSize.MEDIUM,
                        color: colors.textBlack19,
                        fontWeight: "400",
                        fontFamily: "arial",
                        borderRadius: 4,
                    }}>{Value}</Text>
                </View>
                <Text style={styles.titleCommentJson}>{createdFormated}</Text>
            </View>
        );
    }

    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { subSite, dataCurrentUsers } = useSelector((state: any) => state.login);
    const { dataTask, isProcessTaskVbdenSuccess, isProcessVbdenSuccess } = useSelector((state: any) => state.vbden);
    const [modalAction, setModalAction] = useState(false)
    const [dataAttachFiles, setDataAttachFiles] = useState([])
    const [dataAttachFileWebView, setDataAttachFileWebView] = useState({})
    const [assignedToTextJson, setAssignedToTextJsonState] = useState<any>({})
    const [YKienCuaNguoiChuyen, setYKienCuaNguoiChuyen] = useState("")
    const [YKienCuaNguoiGiaiQuyet, setYKienCuaNguoiGiaiQuyet] = useState("")
    const [dueDateState, setDueDateState] = useState("")
    const [NguoiChuyen, setNguoiChuyenState] = useState("")
    const [modalUserGroup, setModalUserGroup] = useState(false)
    const [isOpenCalendarTaskPicker, setIsOpenCalendarTaskPicker] = useState(false);
    const [typeDate, setTypeDate] = useState<number>(0);
    const [modalFeedback, setModalFeedback] = useState(false)
    const [TrangThaiText, setTrangThaiText] = useState("")
    const [TienDoText, setTienDoText] = useState("")
    const [statusModal, setStatusModal] = useState(false)
    const [fileModal, setFileModal] = useState(false)
    const [selectFileIndex, setSelectFileIndex] = useState(0)
    const [modalCompleted, setCompletedModal] = useState(false)
    const [modalAssignment, setModalAssignment] = useState(false)

    const fetchData = useCallback(async (itemId: any,_subSite: any) => {
        dispatch(fetchTaskById({
            SubSite: _subSite,
            TaskId: itemId
        }));
        dispatch(fetchSetting(_subSite))
    }, [dispatch]);

    const onActionPress = useCallback((ID: number) => {
        setModalAction(false);
        if (ID === TaskVB.Luu) onConfirmLuu();
        if (ID === TaskVB.TraoDoiLai) setModalFeedback(true);
        if (ID === TaskVB.HoanTat) setCompletedModal(true)
        if (ID == TaskVB.PhanCong) setModalAssignment(true)
    }, [dataTask, modalFeedback, dueDateState, YKienCuaNguoiChuyen, YKienCuaNguoiGiaiQuyet, TrangThaiText, TienDoText, assignedToTextJson, subSite]);

    const IconView = ({ ID }: any) => {
        if (ID === TaskVB.TraoDoiLai)
            return <TraoDoiLaiIcon />;
        if (ID === TaskVB.PhanCong) return <AssignGreenIcon color='#1F671D' />;
        if (ID === TaskVB.Luu) return <SaveIcon />;
        if (ID === TaskVB.HoanTat) return <KetThucIcon color='#239720' />;
        return <View />;
    };

    const onConfirmLuu = useCallback(() => {
        const NguoiXuLy = !checkIsEmpty(assignedToTextJson?.AccountName)
            ? assignedToTextJson?.AccountID +
            ";#" +
            assignedToTextJson?.AccountName
            : "";

        const payload = {
            SubSite: subSite,
            YKienChiDao: YKienCuaNguoiChuyen,
            YKienCuaNguoiGiaiQuyet: YKienCuaNguoiGiaiQuyet,
            ThoiHanGiaiQuyet: dueDateState,
            TrangThai: !isNullOrEmpty(TrangThaiText) ? TrangThaiText : dataTask?.TrangThai,
            TienDo: !isNullOrEmpty(TienDoText) ? TienDoText : dataTask?.TienDo,
            NguoiXuLy,
            TaskId,
            isNguoiGiaoViec: dataTask?.Role === TaskRole.NguoiGiaoViec
        };
        dispatch(submitActionTaskSave(payload))
        onCloseModal()
    }, [TaskId, subSite, assignedToTextJson, YKienCuaNguoiGiaiQuyet, TrangThaiText, TienDoText, dueDateState, YKienCuaNguoiChuyen, dataTask])
    const onConfirmFeedbackModal = useCallback((text: any) => {
        if (checkIsEmpty(text)) {
            Alert.alert("Thông báo", "Vui lòng nhập ý kiến!", [
                { text: "OK", onPress: () => { } },
            ]);
        } else {
            const NguoiXuLy = !checkIsEmpty(assignedToTextJson?.AccountName)
                ? assignedToTextJson?.AccountID +
                ";#" +
                assignedToTextJson?.AccountName
                : "";

            const payload = {
                SubSite: subSite,
                YKienChiDao: text,
                ThoiHanGiaiQuyet: dueDateState,
                YKienCuaNguoiGiaiQuyet,
                TrangThai: !isNullOrEmpty(TrangThaiText) ? TrangThaiText : dataTask?.TrangThai,
                TienDo: !isNullOrEmpty(TienDoText) ? TienDoText : dataTask?.TienDo,
                NguoiXuLy,
                TaskId,
                isNguoiGiaoViec: dataTask?.Role === TaskRole.NguoiGiaoViec
            };
            dispatch(submitActionTaskFeedback(payload))
            setModalFeedback(false)
            onCloseModal();
        }
    }, [TaskId, assignedToTextJson, TrangThaiText, TienDoText, dueDateState, YKienCuaNguoiChuyen, dataTask])

    const onCloseFeedbackModal = useCallback(() => {
        setModalFeedback(false)
    }, [modalFeedback])

    useEffect(() => {
        let data = {};
        if (dataTask?.Role === TaskRole.NguoiGiaoViec) {
            data = dataTask?.AssignedToTextJson;
        } else {
            data = dataTask?.NguoiNhanJson;
        }

        if (dataTask?.Role === TaskRole.NguoiGiaoViec) {
            setNguoiChuyenState(dataCurrentUsers[0]?.FullName)
        } else {
            setNguoiChuyenState(dataTask?.NguoiChuyenJson?.FullName)
        }

        setAssignedToTextJsonState(data);

        if (!isNullOrUndefined(dataTask?.DueDate)) {
            setDueDateState(dataTask?.DueDate)
        } else {
            setDueDateState("")
        }
    }, [dataTask])

    useEffect(() => {
        fetchData(TaskId,subSite)
    }, [TaskId, subSite])

    useEffect(() => {
        if (isProcessTaskVbdenSuccess || isProcessVbdenSuccess) fetchData(TaskId,subSite)
    }, [TaskId, isProcessTaskVbdenSuccess || isProcessVbdenSuccess])

    useEffect(() => {
        if (!isNullOrUndefined(AttachFiles)) {
            setDataAttachFiles(AttachFiles)
            setDataAttachFileWebView(AttachFiles[0])
        }
    }, [AttachFiles])

    useEffect(() => {
        setYKienCuaNguoiChuyen(dataTask?.YKienChiDao)
        setYKienCuaNguoiGiaiQuyet(dataTask?.YKienCuaNguoiGiaiQuyet)
    }, [dataTask?.YKienChiDao])

    useEffect(() => {
        setTrangThaiText(dataTask?.TrangThai)
        setTienDoText(dataTask?.Percent?.toString())
    }, [dataTask?.TrangThai, dataTask?.Percent, onCloseModal])

    const onCloseActionModal = useCallback(() => {
        setModalAction(false)
    }, [modalAction])

    const onOpenDropdownAction = useCallback(() => {
        setModalAction(!modalAction)
    }, [modalAction])

    const onItemFilePress = useCallback((index: any) => {
        const element = dataAttachFiles[index]
        setDataAttachFileWebView(element)
        setSelectFileIndex(index)
    }, [dataAttachFiles, selectFileIndex])

    const onOpenDateTaskModal = useCallback(() => {
        setTypeDate(0);
        setIsOpenCalendarTaskPicker(true);
    }, []);

    const onCloseCompletedModal = useCallback(() => {
        setCompletedModal(false)
    }, [])

    const onConfirmCompletedModal = useCallback(() => {
        const body = {
            SubSite: subSite,
            YKienCuaNguoiGiaiQuyet: YKienCuaNguoiGiaiQuyet,
            TaskId
        };
        dispatch(submitActionTaskCompleted(body));
        setCompletedModal(false)
        onCloseModal();
    }, [YKienCuaNguoiGiaiQuyet, TaskId, subSite])

    const onCommentNXLChanged = useCallback((text) => {
        setYKienCuaNguoiChuyen(text)
    }, [YKienCuaNguoiChuyen])
    const onChangedYKienCuaNguoiGiaiQuyet = useCallback((text) => {
        setYKienCuaNguoiGiaiQuyet(text)
    }, [YKienCuaNguoiGiaiQuyet])

    const onNguoiNhanPress = useCallback(() => {
        setModalUserGroup(true)
    }, [modalUserGroup])

    const onCloseModalUserGroup = useCallback(() => {
        setModalUserGroup(false)
    }, [modalUserGroup])

    const onConfirmModalUserGroup = useCallback((data) => {
        if (!arrayIsEmpty(data)) {
            setAssignedToTextJsonState(data[0])
            onCloseModalUserGroup()
        }
    }, [])

    const onCloseCalendarPickerTaskModal = useCallback(() => {
        setIsOpenCalendarTaskPicker(false);
    }, []);

    const onCloseFileModal = useCallback(() => {
        setFileModal(false)
    }, [fileModal])

    const onChangeTienDoText = useCallback(
        (number: any) => {
            setTienDoText(number);
            if (parseInt(number) === 0 || isNullOrEmpty(number)) {
                setTrangThaiText("Chưa bắt đầu")
            } else if (parseInt(number) === 100) {
                setTrangThaiText("Hoàn tất")
            } else {
                setTrangThaiText("Đang thực hiện")
            }
        },
        [TienDoText]
    );

    const handleWarningTienDoText = useCallback(() => {
        if (parseInt(TienDoText) > 100) {
            Alert.alert("Thông báo", "Vui lòng nhập dưới 100", [
                { text: "OK", onPress: () => { } },
            ]);
        }
    }, [TienDoText]);

    const onDateChangeModal = useCallback(
        (date: string) => {
            setIsOpenCalendarTaskPicker(false);
            setDueDateState(date);
        },
        [typeDate]
    );

    const onCloseAssignmentModal = useCallback(() => {
        setModalAssignment(false)
    }, [])

    const onConfirmAssignmentModal = useCallback(() => {
        onCloseModal()
        setModalAssignment(false)
    }, [])

    const dateParams = useMemo(() => {
        let date = "";
        date = dueDateState;
        return date;
    }, [typeDate, dueDateState]);

    const onCloseStatusModal = useCallback(() => {
        setStatusModal(false)
    }, [statusModal])

    const onConfirmStatusModal = useCallback((data: any) => {
        setTrangThaiText(data)
        if (data === "Chưa bắt đầu") {
            setTienDoText("")
        } else if (data === "Hoàn tất") {
            setTienDoText("100")
        } else {
            setTienDoText("")
        }
        setStatusModal(false)
    }, [])

    return (
        <ModalCusTom
            transparent={true}
            visible={modalVisible}
            {...props}
            style={styles.centeredView}
            onCloseModalCustom={onCloseModal}
        >
            <KeyboardAvoidingView style={styles.centeredView}>
                <View style={styles.modalView}>
                    <View style={{
                        paddingLeft: dimensWidth(15),
                        height: dimnensHeight(55),
                        alignItems: 'center',
                        flexDirection: 'row',
                        justifyContent: 'flex-end',
                        paddingRight: dimensWidth(15)
                    }}>
                        {!arrayIsEmpty(dataTask?.ActionJson) ? (
                            <View style={[styles.actionView]}>
                                {dataTask?.ActionJson.map((item: any, index: any) => {
                                    return (
                                        <ItemAction
                                            key={index}
                                            item={item}
                                            index={index}
                                            onActionPress={onActionPress}
                                        />
                                    );
                                })}
                                {dataTask?.ActionJson.length > 3 && (
                                    <TouchableOpacity
                                        style={styles.actionMore}
                                        onPress={onOpenDropdownAction}
                                    >
                                        <ActionMoreIcon color='#000000' />
                                    </TouchableOpacity>
                                )}
                            </View>
                        ) : null}
                        <TouchableOpacity
                            onPress={() => {
                                onCloseModal()
                            }}
                            style={{
                                alignItems: 'center',
                                justifyContent: 'center'
                            }}
                        >
                            <CloseXIcon />
                        </TouchableOpacity>
                    </View>
                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        backgroundColor: '#F6F8FA'
                    }} />
                    <KeyboardAwareScrollView
                        contentContainerStyle={{
                            padding: dimensWidth(20)
                        }}>
                        <Text style={{
                            flex: 1,
                            fontSize: FontSize.LARGE,
                            color: '#005FD4',
                            fontWeight: 700
                        }}>{ItemVB?.TrichYeu}</Text>
                        {
                            arrayIsEmpty(dataAttachFiles) ? <></> :
                                <View>
                                    <View style={{
                                        flex: 1,
                                        width: '100%',
                                        marginTop: dimnensHeight(20),
                                        height: dimnensHeight(350),
                                        backgroundColor: 'white',
                                        borderRadius: 8,
                                        shadowColor: '#000000',
                                        shadowOffset: {
                                            width: 0,
                                            height: 1
                                        },
                                        shadowRadius: 4,
                                        shadowOpacity: 0.3,
                                    }}>
                                        <WebView
                                            source={{ uri: BASE_URL + dataAttachFileWebView?.Url }}
                                            style={{ flex: 1 }}
                                            sharedCookiesEnabled
                                        />
                                        <View style={{
                                            position: 'absolute',
                                            alignSelf: 'flex-end',
                                            bottom: 15,
                                            right: 15
                                        }}>
                                            <TouchableOpacity onPress={() => setFileModal(true)}>
                                                <ViewFileFull />
                                            </TouchableOpacity>
                                        </View>

                                    </View>
                                    <Text style={{
                                        marginTop: dimnensHeight(20),
                                        marginBottom: dimnensHeight(15),
                                        fontSize: FontSize.LARGE_X,
                                        color: '#000000',
                                        fontWeight: 700,
                                    }}>Tài liệu đính kèm</Text>
                                    <FlatList
                                        style={{
                                            borderWidth: 1,
                                            borderRadius: 4,
                                            borderColor: '#DDDDDD',
                                        }}
                                        data={dataAttachFiles}
                                        renderItem={({ item, index }) => (
                                            <ItemFile
                                                item={item}
                                                index={index}
                                                DownloadFile={(item: any) => DownloadFile(item)}
                                                selectFileIndex={selectFileIndex}
                                                onItemFilePress={(index: any) => onItemFilePress(index)} />
                                        )}
                                        extraData={dataAttachFiles}
                                        disableVirtualization
                                        nestedScrollEnabled
                                        scrollEnabled={false}
                                        keyExtractor={(item, index) => String(index)}
                                    />
                                </View>
                        }
                        {
                            arrayIsEmpty(CommentJson) ? <></> : (
                                <View>
                                    <Text style={{
                                        marginTop: dimnensHeight(20),
                                        color: '#000000',
                                        fontSize: FontSize.LARGE,
                                        fontWeight: 700
                                    }}>Ý kiến lãnh đạo</Text>

                                    <FlatList
                                        nestedScrollEnabled
                                        scrollEnabled={false}
                                        style={styles.commentJsonFlatlist}
                                        extraData={ItemVB?.CommentJson}
                                        disableVirtualization
                                        horizontal={false}
                                        data={ItemVB?.CommentJson}
                                        renderItem={({ item, index }) => (
                                            <ItemComment item={item} index={index} />
                                        )}
                                    />
                                </View>
                            )
                        }
                        <View>
                            {
                                dataTask?.Percent === 100 ? <View>
                                    <View style={{
                                        flex: 1,
                                        marginTop: dimnensHeight(20),
                                        flexDirection: 'row'
                                    }}>
                                        <View style={{
                                            flex: 1
                                        }}>
                                            <Text style={styles.title}>Người chuyển</Text>
                                            <Text style={styles.value}>{NguoiChuyen}</Text>
                                        </View>
                                        <View style={{
                                            flex: 1
                                        }}>
                                            <Text style={styles.title}>Người nhận</Text>
                                            <Text style={styles.value}>{assignedToTextJson?.FullName
                                                ? assignedToTextJson?.FullName
                                                : dataTask?.DepartmentTitle}</Text>
                                        </View>
                                    </View>

                                    <View style={{
                                        flex: 1,
                                        marginTop: dimnensHeight(20),
                                        flexDirection: 'row'
                                    }}>
                                        <View style={{
                                            flex: 1
                                        }}>
                                            <Text style={styles.title}>Ngày bắt đầu</Text>
                                            <Text style={styles.value}>{!isNullOrUndefined(dataTask?.StartDate) ? format_dd_mm_yy(dataTask?.StartDate) : ''}</Text>
                                        </View>
                                        <View style={{
                                            flex: 1
                                        }}>
                                            <Text style={styles.title}>Hạn hoàn tất</Text>
                                            <Text style={styles.value}>{format_dd_mm_yy(dueDateState)}</Text>
                                        </View>
                                    </View>

                                    <View style={{
                                        flex: 1,
                                        marginTop: dimnensHeight(20)
                                    }}>
                                        <Text style={styles.title}>
                                            Ý kiến của người chuyển
                                        </Text>
                                        <Text style={styles.value}>{dataTask?.YKienChiDao}</Text>
                                    </View>

                                    <View style={{
                                        flex: 1,
                                        marginTop: dimnensHeight(20)
                                    }}>
                                        <Text style={styles.title}>
                                            Ý kiến của người nhận
                                        </Text>
                                        <Text style={styles.value}>
                                            {dataTask?.YKienCuaNguoiGiaiQuyet}
                                        </Text>
                                    </View>

                                    <View style={{
                                        flex: 1,
                                        marginTop: dimnensHeight(20)
                                    }}>
                                        <Text style={styles.title}>
                                            Hồ sơ dự thảo
                                        </Text>
                                        <Text style={styles.value}>

                                        </Text>
                                    </View>

                                    <View style={{
                                        flex: 1,
                                        marginTop: dimnensHeight(20),
                                        flexDirection: 'row'
                                    }}>
                                        <View style={{
                                            flex: 1
                                        }}>
                                            <Text style={styles.title}>Tình trạng</Text>
                                            <Text style={[styles.editValue, { paddingStart: 0 }]}>{TrangThaiText}</Text>

                                        </View>
                                        <View style={{
                                            flex: 1,
                                            marginLeft: dimensWidth(15)
                                        }}>
                                            <Text style={styles.title}>Tiến độ</Text>
                                            <Text style={[styles.editValue, { paddingStart: 0 }]}>{TienDoText} %</Text>
                                        </View>
                                    </View>
                                </View> : dataTask?.Role === TaskRole.NguoiGiaoViec ? (
                                    <View>
                                        <View style={{
                                            flex: 1,
                                            marginTop: dimnensHeight(20),
                                            flexDirection: 'row'
                                        }}>
                                            <View style={{
                                                flex: 1
                                            }}>
                                                <Text style={styles.title}>Người chuyển</Text>
                                                <Text style={styles.value}>{NguoiChuyen}</Text>
                                            </View>
                                            <View style={{
                                                flex: 1
                                            }}>
                                                <Text style={styles.title}>Người nhận</Text>
                                                <TouchableOpacity onPress={onNguoiNhanPress} style={styles.viewEditValue}>
                                                    <Text numberOfLines={1} style={styles.editValue}>{assignedToTextJson?.FullName
                                                        ? assignedToTextJson?.FullName
                                                        : dataTask?.DepartmentTitle}</Text>
                                                    <UserGreyIcon />
                                                </TouchableOpacity>
                                            </View>
                                        </View>

                                        <View style={{
                                            flex: 1,
                                            marginTop: dimnensHeight(20),
                                            flexDirection: 'row'
                                        }}>
                                            <View style={{
                                                flex: 1
                                            }}>
                                                <Text style={styles.title}>Ngày bắt đầu</Text>
                                                <Text style={styles.value}>{!isNullOrUndefined(dataTask?.StartDate) ? format_dd_mm_yy(dataTask?.StartDate) : ''}</Text>
                                            </View>
                                            <View style={{
                                                flex: 1
                                            }}>
                                                <Text style={styles.title}>Hạn hoàn tất</Text>
                                                <TouchableOpacity onPress={onOpenDateTaskModal} style={styles.viewEditValue}>
                                                    <Text style={[styles.editValue]}>{isNullOrUndefined(dueDateState) ? "" : formatDate(dueDateState, "DD/MM/YYYY")}</Text>
                                                    <DateIcon color={"#5E5E5E"} />
                                                </TouchableOpacity>
                                            </View>
                                        </View>

                                        <View style={{
                                            flex: 1,
                                            marginTop: dimnensHeight(20)
                                        }}>
                                            <Text style={styles.title}>
                                                Ý kiến của người chuyển
                                            </Text>
                                            <TextInputCustom
                                                editable={true}
                                                placeholder="Vui lòng nhập ý kiến"
                                                placeholderTextColor={colors.grey999}
                                                multiline
                                                value={YKienCuaNguoiChuyen}
                                                onChangeText={onCommentNXLChanged}
                                                style={styles.commentInput}
                                            />
                                        </View>

                                        <View style={{
                                            flex: 1,
                                            marginTop: dimnensHeight(20)
                                        }}>
                                            <Text style={styles.title}>
                                                Ý kiến của người nhận
                                            </Text>
                                            <Text style={styles.value}>
                                                {dataTask?.YKienCuaNguoiGiaiQuyet}
                                            </Text>
                                        </View>

                                        <View style={{
                                            flex: 1,
                                            marginTop: dimnensHeight(20)
                                        }}>
                                            <Text style={styles.title}>
                                                Hồ sơ dự thảo
                                            </Text>
                                            <Text style={styles.value}>
                                            </Text>
                                        </View>

                                        <View style={{
                                            flex: 1,
                                            marginTop: dimnensHeight(20),
                                            flexDirection: 'row'
                                        }}>
                                            <View style={{
                                                flex: 1
                                            }}>
                                                <Text style={styles.title}>Tình trạng</Text>
                                                <Text style={styles.value}>{dataTask?.TrangThai}</Text>
                                            </View>
                                            <View style={{
                                                flex: 1
                                            }}>
                                                <Text style={styles.title}>Tiến độ</Text>
                                                <Text style={styles.value}>{dataTask?.Percent} %</Text>
                                            </View>
                                        </View>
                                    </View>
                                ) : dataTask?.Role == TaskRole.NguoiXem ? (
                                    <View>
                                        <View style={{
                                            flex: 1,
                                            marginTop: dimnensHeight(20),
                                            flexDirection: 'row'
                                        }}>
                                            <View style={{
                                                flex: 1
                                            }}>
                                                <Text style={styles.title}>Người chuyển</Text>
                                                <Text style={styles.value}>{NguoiChuyen}</Text>
                                            </View>
                                            <View style={{
                                                flex: 1
                                            }}>
                                                <Text style={styles.title}>Người nhận</Text>
                                                <Text style={styles.value}>{assignedToTextJson?.FullName
                                                    ? assignedToTextJson?.FullName
                                                    : dataTask?.DepartmentTitle}</Text>
                                            </View>
                                        </View>

                                        <View style={{
                                            flex: 1,
                                            marginTop: dimnensHeight(20),
                                            flexDirection: 'row'
                                        }}>
                                            <View style={{
                                                flex: 1
                                            }}>
                                                <Text style={styles.title}>Ngày bắt đầu</Text>
                                                <Text style={styles.value}>{!isNullOrUndefined(dataTask?.StartDate) ? format_dd_mm_yy(dataTask?.StartDate) : ''}</Text>
                                            </View>
                                            <View style={{
                                                flex: 1
                                            }}>
                                                <Text style={styles.title}>Hạn hoàn tất</Text>
                                                <Text style={styles.value}>{format_dd_mm_yy(dueDateState)}</Text>
                                            </View>
                                        </View>

                                        <View style={{
                                            flex: 1,
                                            marginTop: dimnensHeight(20)
                                        }}>
                                            <Text style={styles.title}>
                                                Ý kiến của người chuyển
                                            </Text>
                                            <Text style={styles.value}>{dataTask?.YKienChiDao}</Text>
                                        </View>

                                        <View style={{
                                            flex: 1,
                                            marginTop: dimnensHeight(20)
                                        }}>
                                            <Text style={styles.title}>
                                                Ý kiến của người nhận
                                            </Text>
                                            <Text style={styles.value}>
                                                {dataTask?.YKienCuaNguoiGiaiQuyet}
                                            </Text>
                                        </View>

                                        <View style={{
                                            flex: 1,
                                            marginTop: dimnensHeight(20)
                                        }}>
                                            <Text style={styles.title}>
                                                Hồ sơ dự thảo
                                            </Text>
                                            <Text style={styles.value}>

                                            </Text>
                                        </View>

                                        <View style={{
                                            flex: 1,
                                            marginTop: dimnensHeight(20),
                                            flexDirection: 'row'
                                        }}>
                                            <View style={{
                                                flex: 1
                                            }}>
                                                <Text style={styles.title}>Tình trạng</Text>
                                                <Text style={styles.value}>{dataTask?.TrangThai}</Text>
                                            </View>
                                            <View style={{
                                                flex: 1
                                            }}>
                                                <Text style={styles.title}>Tiến độ</Text>
                                                <Text style={styles.value}>{dataTask?.Percent} %</Text>
                                            </View>
                                        </View>
                                    </View>
                                ) : (
                                    <View>
                                        <View style={{
                                            flex: 1,
                                            marginTop: dimnensHeight(20),
                                            flexDirection: 'row'
                                        }}>
                                            <View style={{
                                                flex: 1
                                            }}>
                                                <Text style={styles.title}>Người chuyển</Text>
                                                <Text style={styles.value}>{NguoiChuyen}</Text>
                                            </View>
                                            <View style={{
                                                flex: 1
                                            }}>
                                                <Text style={styles.title}>Người nhận</Text>
                                                <Text style={styles.value}>{assignedToTextJson?.FullName
                                                    ? assignedToTextJson?.FullName
                                                    : dataTask?.DepartmentTitle}</Text>
                                            </View>
                                        </View>

                                        <View style={{
                                            flex: 1,
                                            marginTop: dimnensHeight(20),
                                            flexDirection: 'row'
                                        }}>
                                            <View style={{
                                                flex: 1
                                            }}>
                                                <Text style={styles.title}>Ngày bắt đầu</Text>
                                                <Text style={styles.value}>{!isNullOrUndefined(dataTask?.StartDate) ? format_dd_mm_yy(dataTask?.StartDate) : ''}</Text>
                                            </View>
                                            <View style={{
                                                flex: 1
                                            }}>
                                                <Text style={styles.title}>Hạn hoàn tất</Text>
                                                <Text style={styles.value}>{format_dd_mm_yy(dueDateState)}</Text>
                                            </View>
                                        </View>

                                        <View style={{
                                            flex: 1,
                                            marginTop: dimnensHeight(20)
                                        }}>
                                            <Text style={styles.title}>
                                                Ý kiến của người chuyển
                                            </Text>
                                            <Text style={styles.value}>{dataTask?.YKienChiDao}</Text>
                                        </View>

                                        <View style={{
                                            flex: 1,
                                            marginTop: dimnensHeight(20)
                                        }}>
                                            <Text style={styles.title}>
                                                Ý kiến của người nhận
                                            </Text>
                                            <TextInputCustom
                                                editable={true}
                                                placeholder="Vui lòng nhập ý kiến"
                                                placeholderTextColor={colors.grey999}
                                                multiline
                                                value={YKienCuaNguoiGiaiQuyet}
                                                onChangeText={onChangedYKienCuaNguoiGiaiQuyet}
                                                style={styles.commentInput}
                                            />
                                            {/* <Text style={styles.value}>
                                                {dataTask?.YKienCuaNguoiGiaiQuyet}
                                            </Text> */}
                                        </View>

                                        <View style={{
                                            flex: 1,
                                            marginTop: dimnensHeight(20)
                                        }}>
                                            <Text style={styles.title}>
                                                Hồ sơ dự thảo
                                            </Text>
                                            <Text style={styles.value}>

                                            </Text>
                                        </View>

                                        <View style={{
                                            flex: 1,
                                            marginTop: dimnensHeight(20),
                                            flexDirection: 'row',
                                        }}>
                                            <View style={{
                                                flex: 1,
                                                marginRight: dimensWidth(15)
                                            }}>
                                                <Text style={styles.title}>Tình trạng</Text>
                                                <TouchableOpacity onPress={() => setStatusModal(true)} style={styles.viewEditValue}>
                                                    <Text style={[styles.editValue,]}>{TrangThaiText}</Text>
                                                    <DropDownIcon />
                                                </TouchableOpacity>
                                            </View>
                                            <View style={{
                                                flex: 1,
                                                marginLeft: dimensWidth(15)
                                            }}>
                                                <Text style={styles.title}>Tiến độ</Text>
                                                <View style={styles.viewEditValue}>
                                                    <TextInput
                                                        placeholderTextColor={colors.grey999}
                                                        numberOfLines={1}
                                                        onChangeText={onChangeTienDoText}
                                                        onBlur={handleWarningTienDoText}
                                                        keyboardType="numeric"
                                                        value={TienDoText}
                                                        style={styles.editValue}
                                                    />
                                                    <Text
                                                        style={styles.percenText}> %</Text>
                                                </View>
                                            </View>
                                        </View>
                                    </View>
                                )
                            }
                        </View>
                    </KeyboardAwareScrollView>
                </View>
            </KeyboardAvoidingView>

            <ActionModal
                modalVisible={modalAction}
                onCloseModal={onCloseActionModal}
                Actions={dataTask?.ActionJson}
                onActionPress={onActionPress}
            />

            <UserGroupOnlyModal
                modalVisible={modalUserGroup}
                onCloseModal={onCloseModalUserGroup}
                onConfirmModal={(data) => onConfirmModalUserGroup(data)}
                isUser={false}
                isGroup={false}
            />

            <CalendarPickerTaskModal
                modalCalendarVisible={isOpenCalendarTaskPicker}
                onCloseModal={onCloseCalendarPickerTaskModal}
                onDateChangeModal={onDateChangeModal}
                typeModalDate={typeDate}
                dateParams={dateParams}
            />

            <FeedbackModal
                modalVisible={modalFeedback}
                onCloseFeedbackModal={onCloseFeedbackModal}
                ItemTask={dataTask}
                onConfirmFeedbackModal={(data) => onConfirmFeedbackModal(data)}
                Comment={dataTask?.Role === 256 ? YKienCuaNguoiChuyen : YKienCuaNguoiGiaiQuyet}
            />

            <FileModal
                modalVisible={fileModal}
                onCloseModal={onCloseFileModal}
                value={dataAttachFileWebView} />

            <StatusModal
                modalVisible={statusModal}
                defaultValue={TrangThaiText}
                onCloseStatusModal={onCloseStatusModal}
                ItemTask={dataTask}
                onConfirmStatusModal={(data) => onConfirmStatusModal(data)}
            />

            <CompletedModal
                modalVisible={modalCompleted}
                ItemTask={dataTask}
                onCloseCompletedModal={onCloseCompletedModal}
                onConfirmCompletedModal={onConfirmCompletedModal} />

            <AssignmentModal
                modalVisible={modalAssignment}
                ItemTask={dataTask}
                Comment=""
                onCloseModal={onCloseAssignmentModal}
                onConfirmModal={onConfirmAssignmentModal}
                TaskId={TaskId}
            />
        </ModalCusTom>
    )
}

const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(0,0,0,0.4)"
    },
    modalView: {
        height: dimnensHeight(780),
        width: dimensWidth(720),
        backgroundColor: 'white',
        borderRadius: 20,
        overflow: 'hidden'
    },
    shareButton: {
    },
    flexDirectionRowAction: {
        flex: 1,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        marginRight: dimensWidth(30)
    },
    actionMore: {
        padding: 8,
        marginRight: dimensWidth(20)
    },
    actionView: {
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "row",
    },
    tabBarLabelActive: {
        color: colors.black,
        fontWeight: "400",
        fontSize: 18,
        marginLeft: 12,
    },
    titleCommentJson: {
        fontSize: FontSize.MEDIUM,
        color: colors.textBlack19,
        fontWeight: "400",
        fontFamily: "arial",
        borderRadius: 4,
    },
    positionComment: {
        fontSize: dimensWidth(13),
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        borderRadius: 4,
        marginTop: dimnensHeight(5)
    },
    commentJsonFlatlist: {
        borderColor: colors.greyDDD,
        borderWidth: 1,
        borderRadius: 8,
        marginTop: dimnensHeight(15),
        overflow: "hidden",
    },
    title: {
        color: '#5E5E5E',
        fontSize: FontSize.SMALL,
    },
    value: {
        color: '#19191E',
        fontSize: FontSize.LARGE,
        marginTop: dimnensHeight(13)
    },
    editValue: {
        flex: 1,
        color: '#19191E',
        fontSize: FontSize.LARGE,
        padding: dimensWidth(10),
    },
    percenText: {
        color: '#19191E',
        fontSize: FontSize.LARGE,
    },
    viewEditValue: {
        flexDirection: 'row',
        marginTop: dimnensHeight(13),
        borderWidth: 1,
        borderRadius: 3,
        borderColor: '#DDDDDD',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingRight: 10
    },
    commentInput: {
        paddingHorizontal: 10,
        borderColor: "#DDDDDD",
        borderWidth: 1,
        borderRadius: 3,
        height: 100,
        textAlignVertical: "top",
        marginTop: dimnensHeight(15)
    }
});

export default TaskModal