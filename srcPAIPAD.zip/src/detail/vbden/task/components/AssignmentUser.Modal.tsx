import React, { FC, useState, useCallback, useEffect } from "react";
import {
    Modal,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    KeyboardAvoidingView,
    Alert,
} from "react-native";
import { FlatList } from "react-native-gesture-handler";
import colors from "~/base/Colors";
import { FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";
import { arrayIsEmpty, isNullOrUndefined } from "~/base/Functions";
import { BackIcon, CloseXIcon, ConfirmIcon, DeleteRedIcon, MemberIcon, MinusIcon, PlusIcon, SellectedBoxIcon, UnSellectedBoxIcon, UserPlusIcon } from "~/base/assets/svg";
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { fetchDepartment, fetchBanLanhDao, fetchSetting } from "~/base/stories/data/reducer";
import { fetchCheckUserInGroup } from "~/base/stories/vbden/reducer";
import AssignmentModal from "./Assignment.Modal";
import ModalCusTom from "~/base/components/ModalCusTom";

interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    onConfirmModal: (data: any) => void;
    ItemTask: any,
}

const AssignmentUserModal: FC<Props> = ({
    modalVisible,
    onCloseModal,
    onConfirmModal,
    ItemTask,
    ...props
}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { subSite } = useSelector((state: any) => state.login);
    const { IsGroupAssignmentFull } = useSelector((state: any) => state.vbden);
    const { dataDepartment, dataSetting } = useSelector((state: any) => state.data);
    const [dataPhongBanState, setdataPhongBanState] = useState<any>([]);
    const [isAllThucHien, setIsAllThucHien] = useState(false);
    const [isAllPhoiHop, setIsAllPhoiHop] = useState(false);

    const fetchAssignmentGroupFullRequest = useCallback(async (_subSite: any, groupName: any) => {
        dispatch(fetchCheckUserInGroup({
            subSite: _subSite,
            groupName
        }))
    }, [dispatch])

    const renderItem = ({ item, index, level = 0 }: any) => {
        const hasChildren = item?.children && item.children.length > 0;
        const {
            Title,
            children,
            ID,
            IsRoot,
            isThucHien,
            isPhoiHop,
            isEnded = false,
            isExpanded,
        } = item;

        return (
            <View style={styles.item}>
                <View
                    style={[
                        styles.flexDirectionRowItem,
                        { paddingLeft: 20 + level * 20 },
                    ]}
                >
                    {!isEnded && (
                        <TouchableOpacity onPress={() => handleToggleExpanded(item.dummyID)}>
                            {isExpanded ? <MinusIcon /> : <PlusIcon />}
                        </TouchableOpacity>
                    )}
                    <View style={{ flex: 1 }}>
                        <Text style={{
                            fontSize: FontSize.MEDIUM,
                            lineHeight: dimensWidth(20),
                            color: colors.textBlack19,
                            fontWeight: IsRoot ? "500" : "400",
                            fontFamily: "arial",
                            marginLeft: 10,
                            marginRight: 10,
                        }} numberOfLines={1}>
                            {Title}
                        </Text>
                    </View>
                    <TouchableOpacity
                        style={styles.viewBox1}
                        onPress={() => handleToggleThucHien(item.dummyID, level)}
                    >
                        {isThucHien ? <SellectedBoxIcon /> : <UnSellectedBoxIcon />}
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.viewBox1} onPress={() => handleTogglePhoiHop(item.dummyID, level)}>
                        {isPhoiHop ? <SellectedBoxIcon /> : <UnSellectedBoxIcon />}
                    </TouchableOpacity>
                </View>
                {isExpanded && hasChildren && (
                    <FlatList
                        data={item?.children}
                        renderItem={({ item, index }) =>
                            renderItem({ item, index, level: level + 1 })
                        }
                        keyExtractor={(child, index) => index.toString()}
                    />
                )}
            </View>
        );
    };

    const handleToggleExpanded = (itemId: any) => {
        setdataPhongBanState((prevData: any) => {
            const newData = [...prevData];

            const findItemAndToggleExpanded = (items: any) => {
                for (let i = 0; i < items.length; i++) {
                    const item = items[i];

                    if (item.dummyID === itemId) {
                        const newValue = !item.isExpanded;
                        item.isExpanded = newValue;
                        return;
                    }

                    if (item?.children && item.children.length > 0) {
                        findItemAndToggleExpanded(item.children);
                    }
                }
            };
            findItemAndToggleExpanded(newData);
            return newData;
        });
    };

    const handleToggleThucHien = (itemId: any, level: number) => {
        setdataPhongBanState((prevData: any) => {
            const newData = [...prevData];
            const findItemAndToggleThucHien = (items: any) => {
                for (let i = 0; i < items.length; i++) {
                    const item = items[i];

                    if (item.dummyID === itemId) {
                        const newValue = !item.isThucHien;
                        item.isThucHien = newValue;
                        if (item.isThucHien && item.isPhoiHop) item.isPhoiHop = false;
                        if (level === 0 && newValue)
                            toggleChildrenThucHien(item.children, newValue);
                        return;
                    }

                    if (item?.children && item.children.length > 0) {
                        findItemAndToggleThucHien(item.children);
                    }
                }
            };

            const toggleChildrenThucHien = (children: any, value: any) => {
                for (let i = 0; i < children.length; i++) {
                    const childItem = children[i];
                    childItem.isThucHien = value;
                    if (childItem.isThucHien && childItem.isPhoiHop)
                        childItem.isPhoiHop = false;
                    if (childItem?.children && childItem?.children.length > 0) {
                        toggleChildrenThucHien(childItem?.children, value);
                    }
                }
            };

            findItemAndToggleThucHien(newData);

            return newData;
        });
    };

    const handleTogglePhoiHop = (itemId: any, level: number) => {
        setdataPhongBanState((prevData: any) => {
            const newData = [...prevData];

            const findItemAndTogglePhoiHop = (items: any) => {
                for (let i = 0; i < items.length; i++) {
                    const item = items[i];

                    if (item.dummyID === itemId) {
                        const newValue = !item.isPhoiHop;
                        item.isPhoiHop = newValue;
                        if (item.isThucHien && item.isPhoiHop) item.isThucHien = false;
                        if (newValue)
                            toggleChildrenPhoiHop(item.children, newValue);
                        return;
                    }

                    if (item?.children && item.children.length > 0) {
                        findItemAndTogglePhoiHop(item.children);
                    }
                }
            };

            const toggleChildrenPhoiHop = (children: any, value: any) => {
                for (let i = 0; i < children.length; i++) {
                    const childItem = children[i];
                    childItem.isPhoiHop = value;
                    if (childItem.isThucHien && childItem.isPhoiHop)
                        childItem.isThucHien = false;
                    if (childItem?.children && childItem?.children.length > 0) {
                        toggleChildrenPhoiHop(childItem?.children, value);
                    }
                }
            };

            findItemAndTogglePhoiHop(newData);

            return newData;
        });
    };

    const onChangeAllThucHien = useCallback(() => {
        if (arrayIsEmpty(dataPhongBanState)) {
            Alert.alert("Thông báo", "Không có dữ liệu!", [
                { text: "OK", onPress: () => { } },
            ]);
            return;
        }
        setIsAllThucHien(!isAllThucHien);
        setdataPhongBanState((prevData: any) => {
            const newData = [...prevData];

            const findItemAndToggleThucHien = (items: any) => {
                for (let i = 0; i < items.length; i++) {
                    const item = items[i];

                    const newValue = !isAllThucHien;
                    if (!item.isPhoiHop) item.isThucHien = newValue;
                    toggleChildrenThucHien(item.children, newValue);
                    return;
                }

                if (item?.children && item?.children.length > 0) {
                    findItemAndToggleThucHien(item?.children);
                }
            };

            const toggleChildrenThucHien = (children: any, value: any) => {
                for (let i = 0; i < children.length; i++) {
                    const childItem = children[i];
                    if (!childItem.isPhoiHop) childItem.isThucHien = value;
                    if (childItem?.children && childItem?.children.length > 0) {
                        toggleChildrenThucHien(childItem?.children, value);
                    }
                }
            };

            findItemAndToggleThucHien(newData);

            return newData;
        });
    }, [isAllThucHien, dataPhongBanState]);

    const onChangeAllPhoiHop = useCallback(() => {
        if (arrayIsEmpty(dataPhongBanState)) {
            Alert.alert("Thông báo", "Không có dữ liệu!", [
                { text: "OK", onPress: () => { } },
            ]);
            return;
        }
        setIsAllPhoiHop(!isAllPhoiHop);
        setdataPhongBanState((prevData: any) => {
            const newData = [...prevData];

            const findItemAndTogglePhoiHop = (items: any) => {
                for (let i = 0; i < items.length; i++) {
                    const item = items[i];

                    const newValue = !isAllPhoiHop;
                    if (!item.isThucHien) item.isPhoiHop = newValue;
                    toggleChildrenPhoiHop(item.children, newValue);
                    return;
                }

                if (item?.children && item.children.length > 0) {
                    findItemAndTogglePhoiHop(item.children);
                }
            };

            const toggleChildrenPhoiHop = (children: any, value: any) => {
                for (let i = 0; i < children.length; i++) {
                    const childItem = children[i];
                    if (!childItem.isThucHien) childItem.isPhoiHop = value;
                    if (childItem?.children && childItem?.children.length > 0) {
                        toggleChildrenPhoiHop(childItem?.children, value);
                    }
                }
            };

            findItemAndTogglePhoiHop(newData);

            return newData;
        });
    }, [isAllPhoiHop, dataPhongBanState]);

    const onCloseOwnModal = useCallback(() => {
        onCloseModal()
    }, [])

    const clone = (data: any, item: any) => {
        if (item && data) {
            const items = data.filter(
                (r) =>
                    (r.URL === null || r.URL === "") &&
                    r.ParentDept != null &&
                    r.Status === 'A' &&
                    r.ParentDept.split(";")[0] === item.ID.toString()
            );
            if (items?.length > 0) {
                item.children = items;
                item.isUser = false;
                item.dummyID = item.ID;
                item.children.forEach((r1) => {
                    clone(data, r1);
                });
            } else {
                if (item.SPNhomUserId?.length > 0) {
                    item.SPNhomUserId.forEach((r) => {
                        item.children.push({
                            Title: r.FullName,
                            ID: r.AccountID,
                            Manager: item.ID + ";#" + item.Title,
                            isThucHien: false,
                            isPhoiHop: false,
                            isExpanded: false,
                            DueDate: "",
                            Comment: "",
                            isUser: true,
                            children: [],
                            isEnded: true,
                            dummyID: r.FullName + ";#" + r.AccountID,
                            ImagePath: r.ImagePath,
                            Position: r.Position
                        });
                    });
                }
            }
        }
    };

    useEffect(() => {
        if (dataDepartment) {
            const data = dataDepartment.map((record) => ({
                ...record,
                isThucHien: false,
                isPhoiHop: false,
                isExpanded: false,
                isUser: false,
                DueDate: "",
                dummyID: record.ID,
                children: [],
            }));

            if (IsGroupAssignmentFull) {
                const newItem = data?.filter((it) => it.IsRoot);
                clone(data, newItem[0]);
                setdataPhongBanState(newItem)
            } else {
                if (isNullOrUndefined(ItemTask?.DepartmentId)) {
                    const newItem = data?.filter((it) => it.IsRoot);
                    clone(data, newItem[0]);
                    setdataPhongBanState(newItem)
                } else {
                    const data = dataDepartment.map((record) => ({
                        ...record,
                        isThucHien: false,
                        isPhoiHop: false,
                        isExpanded: true,
                        isUser: false,
                        DueDate: "",
                        Comment: "",
                        dummyID: record.ID,
                        children: [],
                    }));

                    const newItem = data?.filter((it) => it.ID === ItemTask?.DepartmentId);
                    clone(data, newItem[0]);
                    setdataPhongBanState(newItem);
                }
            }
        }
    }, [dataDepartment, IsGroupAssignmentFull, ItemTask])

    useEffect(() => {
        if (dataSetting) {
            const items = dataSetting.filter(r => r.KEY === 'GroupAssignmentFull')
            if (!isNullOrUndefined(items) && items.length > 0) {
                fetchAssignmentGroupFullRequest(subSite, items[0].VALUE)
            }
        }
    }, [dataSetting,])

    useEffect(() => {
        dispatch(fetchSetting(subSite))
        dispatch(fetchDepartment(subSite));
    }, [subSite])

    return (
        <ModalCusTom
            transparent={true}
            visible={modalVisible}
            {...props}
            onCloseModalCustom={onCloseModal}
            style={styles.centeredView}
        >
            <KeyboardAvoidingView style={styles.centeredView}>
                <View style={styles.modalView}>
                    <View style={{
                        padding: dimensWidth(20),
                        flexDirection: 'row',
                        alignItems: 'center'
                    }}>
                        <TouchableOpacity style={{
                            flex: 0.08
                        }}
                            onPress={onCloseOwnModal}>
                            <BackIcon />
                        </TouchableOpacity>
                        <Text style={{
                            flex: 1,
                            color: '#005FD4',
                            fontSize: FontSize.LARGE_X,
                            fontWeight: 700,
                        }}>Các phòng/ban nghiệp vụ công ty</Text>
                        <TouchableOpacity style={{
                            marginRight: dimensWidth(40)
                        }}
                            onPress={() => onConfirmModal(dataPhongBanState)}>
                            <ConfirmIcon />
                        </TouchableOpacity>
                        <TouchableOpacity onPress={onCloseModal}>
                            <CloseXIcon />
                        </TouchableOpacity>
                    </View>
                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        backgroundColor: '#F6F8FA'
                    }} />
                    <FlatList
                        ListHeaderComponent={() => {
                            return (
                                <View style={styles.flexDirectionRowHeader}>
                                    <View style={styles.viewListHeader}>
                                        <TouchableOpacity
                                            style={styles.selectedAll}
                                            onPress={onChangeAllThucHien}
                                        >
                                            {isAllThucHien ? (
                                                <SellectedBoxIcon />
                                            ) : (
                                                <UnSellectedBoxIcon />
                                            )}
                                        </TouchableOpacity>

                                        <Text style={styles.header} numberOfLines={2}>
                                            {"Thực hiện"}
                                        </Text>

                                    </View>
                                    <View style={{
                                        flexDirection: 'row',
                                        alignItems: "center",
                                        justifyContent: "center",
                                        marginLeft: dimensWidth(20)
                                    }}>
                                        <TouchableOpacity
                                            style={styles.selectedAll}
                                            onPress={onChangeAllPhoiHop}
                                        >
                                            {isAllPhoiHop ? <SellectedBoxIcon /> : <UnSellectedBoxIcon />}
                                        </TouchableOpacity>
                                        <View style={styles.viewListHeader}>
                                            <Text style={styles.header} numberOfLines={2}>
                                                {"Phối hợp"}
                                            </Text>
                                        </View>
                                    </View>
                                </View>
                            );
                        }}
                        contentContainerStyle={styles.flatlist}
                        data={dataPhongBanState}
                        extraData={dataPhongBanState}
                        renderItem={renderItem}
                        keyExtractor={(item, index) => item?.ID + index}
                    />
                </View>
            </KeyboardAvoidingView>
        </ModalCusTom>
    )
}

const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(0,0,0,0.4)"
    },
    modalView: {
        height: dimnensHeight(780),
        width: dimensWidth(750),
        backgroundColor: 'white',
        borderRadius: 20,
        overflow: 'hidden'
    },
    flatlist: {
        flexGrow: 1,
        backgroundColor: "#FFFFFF",
        paddingBottom: 30,
        overflow: "hidden",
    },
    flatlistChild: {
        marginRight: 15,
    },
    selectedAll: {
        marginRight: dimensWidth(5),
    },
    viewListHeader: {
        flexDirection: 'row',
        alignItems: "center",
        justifyContent: "center",
    },
    item: {
        width: "100%",
        marginTop: 20,
        paddingTop: 20,
        borderTopWidth: 1,
        borderTopColor: "#E5E5E5",
    },
    itemChild: {
        flex: 1,
        width: "100%",
        padding: 20,
        borderTopWidth: 1,
        borderTopColor: "#E5E5E5",
    },
    header: {
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.textBlack19,
        fontWeight: "400",
        fontFamily: "arial",
        marginRight: 10,
    },
    title: {
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.textBlack19,
        fontWeight: "500",
        fontFamily: "arial",
        marginLeft: 10,
        marginRight: 10,
    },
    viewHeader: {
        backgroundColor: colors.primary,
        height: 55,
        justifyContent: "center",
        width: "100%",
        paddingHorizontal: 10,
    },
    titleHeader: {
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.white,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 15,
        flex: 1,
    },
    flexDirectionRow: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
    },
    flexDirectionRowItem: {
        flex: 1,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        paddingHorizontal: 20,
    },
    flexDirectionRowHeader: {
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: colors.alice_blue,
        height: dimnensHeight(50),
        justifyContent: "flex-end",
    },
    viewBox: {
        width: dimensWidth(80),
    },
    viewBox1: {
        width: dimensWidth(75),
    }
});

export default AssignmentUserModal