import React, { FC, useState, useCallback, useMemo, useEffect } from "react";
import {
    Modal,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    KeyboardAvoidingView,
    ScrollView,
    Animated,
    Alert
} from "react-native";
import colors from "~/base/Colors";
import { BASE_URL, FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";
import { arrayIsEmpty, checkIsEmpty, convertDataPhongBan, format_dd_mm_yy, isNullOrUndefined, removeSpecialCharacters } from "~/base/Functions";
import { CloseXIcon, CommentIcon, ConfirmIcon, DeleteRedIcon, DueDateBlueIcon, MemberIcon, UserPlusIcon } from "~/base/assets/svg";
import AssignmentUserModal from "./AssignmentUser.Modal";
import { SwipeListView } from "react-native-swipe-list-view";
import AssignmentDeptModal from "./AssignmentDept.Modal";
import CalendarPickerPhanCongModal from "./CalendarPicker.Assigment.Modal";
import { fetchIsGroupAssignmentDept, taskVbDenPhanCongApi } from "~/base/stories/vbden/reducer";
import { useDispatch, useSelector } from "react-redux";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { EnumPhancong } from "../../VBDen.Enum";
import CommentAssignmentModal from "./CommentAssignment.Modal";
import FastImage from "react-native-fast-image";
import ModalCusTom from "~/base/components/ModalCusTom";
interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    onConfirmModal: () => void;
    Comment: string;
    ItemTask: any,
    TaskId: any
}

const AssignmentModal: FC<Props> = ({
    modalVisible,
    onCloseModal,
    onConfirmModal,
    Comment,
    ItemTask,
    TaskId,
    ...props
}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { isLoading, IsGroupAssignmentDept } = useSelector((state: any) => state.vbden);
    const { subSite, token } = useSelector((state: any) => state.login);

    const [yKienLanhDao, setYKienLanhDao] = useState("")
    const [dataAfterAssigmentUser, setDataAfterAssigmentUser] = useState([])
    const [modalAssignmentDept, setModalAssigmentDept] = useState(false)
    const [dataAfterAssignmentDept, setDataAfterAssigmentDept] = useState([])
    const [isOpenCalendarPhanCongPicker, setIsOpenCalendarPhanCongPicker] = useState(false)
    const [DueDateParams, setDueDateDateParams] = useState<string>("");
    const [sellectedItemId, setSellectedItemId] = useState<number>(-1);
    const [typePhanCong, setTypePhanCong] = useState<EnumPhancong | null>(null);

    const [isShowAssignmentDept, setisShowAssignmentDept] = useState(false)
    const [modalAssignmentUser, setModalAssignmentUser] = useState(false)
    const [modalCommentAssignment, setModalCommentAssignment] = useState(false)
    const [commentAssignment, setCommentAssignment] = useState("")

    const fetchIsGroupAssignmentDeptRequest = useCallback(async () => [
        dispatch(fetchIsGroupAssignmentDept(subSite))
    ], [dispatch])
    const handleChooseDueDate = useCallback(
        (itemId: number, DueDate: string, typePhanCong: EnumPhancong) => {
            setIsOpenCalendarPhanCongPicker(true);
            setDueDateDateParams(DueDate);
            setSellectedItemId(itemId);
            setTypePhanCong(typePhanCong)
        },
        [typePhanCong, DueDateParams, sellectedItemId]
    );
    const handleChooseComment = useCallback(
        (itemId: number, comment: string, typePhanCong: EnumPhancong) => {
            setCommentAssignment(comment);
            setSellectedItemId(itemId);
            setModalCommentAssignment(true);
            setTypePhanCong(typePhanCong)
        },
        [sellectedItemId, commentAssignment]
    );
    const ItemPhongBan = ({ item, index }) => {
        const { Title, DueDate, Created, isThucHien, ImagePath, Position, isUser } = item;
        const DueDateFormated = checkIsEmpty(DueDate)
            ? DueDate
            : format_dd_mm_yy(DueDate);
        const isOdd = index % 2 === 0;
        const positionFormat = Position ? removeSpecialCharacters(Position) + ' - ' : ''
        return (
            <View>

                <View
                    style={[
                        styles.itemPhongBanChild,
                        isOdd && { backgroundColor: colors.alice_blue },
                    ]}
                >
                    {isUser && <FastImage
                        style={styles.itemAvatar}
                        source={{
                            uri: BASE_URL + `/${subSite}` + ImagePath,
                            headers: { Authorization: `${token}` },
                            priority: FastImage.priority.normal,
                        }}
                    />}
                    <View style={styles.flexDirectionRowBetween}>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.titlePhongBan} numberOfLines={1}>
                                {Title}
                            </Text>
                            <Text style={styles.blueText} numberOfLines={1}>
                                {`${positionFormat}${isThucHien ? "Thực Hiện" : "Phối Hợp"}`}
                            </Text>
                            {!checkIsEmpty(item?.Comment) &&
                                <TouchableOpacity onPress={() => {
                                    handleChooseComment(item?.dummyID, item?.Comment, EnumPhancong.PhongBan);
                                }}>
                                    <Text style={styles.commentText} >
                                        {item?.Comment}
                                    </Text>
                                </TouchableOpacity>
                            }
                        </View>
                        <View style={styles.flexRowPhongBan}>
                            <View style={styles.flexRow}>
                                {checkIsEmpty(item?.Comment) &&
                                    <TouchableOpacity
                                        style={styles.iconChange}
                                        onPress={() => {
                                            handleChooseComment(item?.dummyID, item?.Comment, EnumPhancong.PhongBan);
                                        }}
                                    >
                                        <CommentIcon />
                                    </TouchableOpacity>
                                }
                                <TouchableOpacity
                                    style={styles.iconChange}
                                    onPress={() => {
                                        handleChooseDueDate(item?.dummyID, item?.DueDate, EnumPhancong.PhongBan);
                                    }}
                                >
                                    {!checkIsEmpty(DueDateFormated) ? (
                                        <Text style={styles.blueText}>
                                            {DueDateFormated}
                                        </Text>
                                    ) : (
                                        <DueDateBlueIcon />
                                    )}
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </View>
            </View>
        );
    };
    const ItemToChucPhanCong = ({ item, index }) => {
        const { Title, ParentDept, Created, DueDate } = item;
        const DueDateFormated = checkIsEmpty(DueDate)
            ? DueDate
            : format_dd_mm_yy(DueDate);
        const isOdd = index % 2 === 0;

        return (
            <Animated.View
                style={[
                    styles.itemPhongBanChild,
                    isOdd && { backgroundColor: colors.alice_blue },
                ]}
            >
                <View style={styles.flexDirectionRowBetween}>
                    <Text style={styles.title} numberOfLines={1}>
                        {Title}
                    </Text>
                    <Text style={styles.blueText} numberOfLines={1}>
                        {DueDateFormated}
                    </Text>
                </View>
                <Text style={styles.blueText} numberOfLines={1}>
                    {removeSpecialCharacters(ParentDept)}
                </Text>
            </Animated.View>
        );
    };

    const onCloseOwnModal = useCallback(() => {
        onConfirmModal();
        setSellectedItemId(-1)
        setDueDateDateParams("")
        setYKienLanhDao("")
        setDataAfterAssigmentDept([])
        setDataAfterAssigmentUser([])
    }, [])

    const onChooseAssigmentDept = useCallback(() => {
        setModalAssigmentDept(true)
    }, [])

    const onCloseAssignmentDeptModal = useCallback(() => {
        setModalAssigmentDept(false)
    }, [])

    const onConfirmAssigmentDeptModal = useCallback((data: any) => {
        setModalAssigmentDept(false)
        setDataAfterAssigmentDept(data)
    }, [])

    const onChangeYKienLanhDao = useCallback((input: string) => {
        setYKienLanhDao(input);
    }, [yKienLanhDao]);

    const findItemsWithPhongBan = (data) => {
        const result = [];

        const traverseData = (data) => {
            data.forEach((item) => {
                if (item.isThucHien || item.isPhoiHop) {
                    result.push(item);
                }

                if (item.children && item.children.length > 0) {
                    traverseData(item.children); // Đệ quy duyệt qua các phần tử con
                }
            });
        };

        traverseData(data); // Bắt đầu duyệt từ mảng data

        return result;
    };

    const filteredDataPhongBan = useMemo(() => {
        let filteredData: any[] = [];
        if (!arrayIsEmpty(dataAfterAssigmentUser)) {
            filteredData = findItemsWithPhongBan(dataAfterAssigmentUser);
            return filteredData;
        }
        return filteredData;
    }, [dataAfterAssigmentUser]);

    const filteredDanhSachTochucPhanCong = useMemo(() => {
        if (!arrayIsEmpty(dataAfterAssignmentDept)) {
            const filteredData = dataAfterAssignmentDept.filter(
                (it: any) => it.isSellectedToChucPhanCong
            );
            return filteredData;
        }
    }, [dataAfterAssignmentDept]);

    const handleToggleDeletePhongban = useCallback(
        (itemId: any) => {
            setDataAfterAssigmentUser((prevData) => {
                const newData = [...prevData];

                const findItemAndTogglePhoiHop = (items: any) => {
                    for (let i = 0; i < items.length; i++) {
                        const item = items[i];

                        if (item.dummyID === itemId) {
                            item.isPhoiHop = false;
                            item.isThucHien = false;
                            return;
                        }

                        if (item.children && item.children.length > 0) {
                            findItemAndTogglePhoiHop(item.children);
                        }
                    }
                };
                findItemAndTogglePhoiHop(newData);

                return newData;
            });
        },
        [dataAfterAssigmentUser]
    );

    const onConfirmDeletePhongBan = useCallback((dummyID: any) => {
        Alert.alert("Thông báo", "Bạn thực sự muốn xóa?", [
            {
                text: "Cancel",
                onPress: () => console.log("Cancel Pressed"),
                style: "cancel",
            },
            { text: "OK", onPress: () => handleToggleDeletePhongban(dummyID) },
        ]);
    }, []);

    const onConfirmDeleteDSToChucPhanCong = useCallback((dummyID: any) => {
        Alert.alert("Thông báo", "Bạn thực sự muốn xóa?", [
            {
                text: "Cancel",
                onPress: () => console.log("Cancel Pressed"),
                style: "cancel",
            },
            { text: "OK", onPress: () => handleToggleDeleteDSToChucPhanCong(dummyID) },
        ]);
    }, []);

    const handleToggleDeleteDSToChucPhanCong = (itemId: any) => {
        setDataAfterAssigmentDept((prevData) => {
            const newData = prevData.map((it: any) =>
                it.ID == itemId ? { ...it, isSellectedToChucPhanCong: false } : it
            );
            return newData;
        });
    };

    const onDueDateDateChangeModal = useCallback((date: string, typePhanCong: EnumPhancong) => {
        setIsOpenCalendarPhanCongPicker(false);
        if (typePhanCong === EnumPhancong.PhongBan) {
            setDataAfterAssigmentUser((prevData) => {
                const newData = [...prevData];
                const findItemAndToggleDueDate = (items: any) => {
                    for (let i = 0; i < items.length; i++) {
                        const item = items[i];

                        if (item.dummyID === sellectedItemId) {
                            item.DueDate = date;
                            return;
                        }
                        if (item.children && item.children.length > 0) {
                            findItemAndToggleDueDate(item.children);
                        }
                    }
                };
                findItemAndToggleDueDate(newData);

                return newData;
            });
        } else {
            setDataAfterAssigmentDept((prevData) => {
                const newData = [...prevData];
                const findItemAndToggleDueDate = (items: any) => {
                    for (let i = 0; i < items.length; i++) {
                        const item = items[i];

                        if (item.dummyID === sellectedItemId) {
                            item.DueDate = date;
                            return;
                        }
                        if (item.children && item.children.length > 0) {
                            findItemAndToggleDueDate(item.children);
                        }
                    }
                };
                findItemAndToggleDueDate(newData);

                return newData;
            });
        }
    },
        [sellectedItemId, dataAfterAssigmentUser, dataAfterAssignmentDept]
    );

    const onCloseCalendarPickerPhanCongModal = useCallback(() => {
        setIsOpenCalendarPhanCongPicker(false);
    }, []);

    const resetToday = useCallback((today: any) => { }, []);

    const onConfirmModalYKienChiDao = useCallback(
        (comment: string) => {
            setModalCommentAssignment(false);
            if (typePhanCong == EnumPhancong.PhongBan) {
                setDataAfterAssigmentUser((prevData) => {
                    const newData = [...prevData];
                    const findItemAndToggleComment = (items: any) => {
                        for (let i = 0; i < items.length; i++) {
                            const item = items[i];

                            if (item.dummyID === sellectedItemId) {
                                item.Comment = comment;
                                return;
                            }
                            if (item.children && item.children.length > 0) {
                                findItemAndToggleComment(item.children);
                            }
                        }
                    };
                    findItemAndToggleComment(newData);
                    return newData;
                });
            } else {
                setDataAfterAssigmentDept((prevData) => {
                    const newData = [...prevData];
                    const findItemAndToggleDueDate = (items: any) => {
                        for (let i = 0; i < items.length; i++) {
                            const item = items[i];

                            if (item.dummyID === sellectedItemId) {
                                item.Comment = comment;
                                return;
                            }
                            if (item.children && item.children.length > 0) {
                                findItemAndToggleDueDate(item.children);
                            }
                        }
                    };
                    findItemAndToggleDueDate(newData);

                    return newData;
                });
            }
        },
        [dataAfterAssigmentUser, dataAfterAssignmentDept, sellectedItemId]
    );


    const onConfirmAssignmentUserModal = useCallback((data: any) => {
        setDataAfterAssigmentUser(data)
        setModalAssignmentUser(false)
    }, [dataAfterAssigmentUser])

    const onConfirmOwnModal = useCallback(() => {
        let AssignmentUser = "";
        let AssignmentDept = "";
        if (arrayIsEmpty(filteredDataPhongBan)) {
            Alert.alert("Thông báo", "Vui lòng chọn người dùng!", [
                { text: "OK", onPress: () => { } },
            ]);
            return;
        } else {
            const traverseData = (filterData: any) => {
                filterData.forEach((item: any) => {

                    const DepartmentTitle = item.ID + ";#" + item.Title;
                    const assignmentType = item.isThucHien
                        ? "&&1&&0&&0&&"
                        : "&&0&&0&&1&&";
                    const duedate = !isNullOrUndefined(item?.DueDate) ? item?.DueDate : ""
                    const comment = !isNullOrUndefined(item?.Comment) ? item?.Comment : ""
                    if (item.isUser) {
                        AssignmentUser +=
                            DepartmentTitle +
                            assignmentType +
                            duedate +
                            "&&" +
                            item.Manager +
                            "&&" +
                            comment +
                            "@@";
                    } else {
                        AssignmentUser +=
                            item.Manager +
                            assignmentType +
                            duedate +
                            "&&" +
                            DepartmentTitle +
                            "&&" +
                            comment +
                            "@@";
                    }
                });
            };
            traverseData(filteredDataPhongBan); // Bắt đầu duyệt từ mảng data
        }

        if (!arrayIsEmpty(filteredDanhSachTochucPhanCong)) {
            const traverseData = (filterData: any) => {
                filterData.forEach((item: any) => {
                    const DepartmentTitle = item?.ID + ";#" + item?.Title;
                    const duedate = !isNullOrUndefined(item?.DueDate) ? item?.DueDate : ""
                    const comment = !isNullOrUndefined(item?.Comment) ? item?.Comment : ""
                    AssignmentDept +=
                        DepartmentTitle + "&&" + item?.URL + "&&" + duedate + "&&" + comment + "@@";
                });
            };
            traverseData(filteredDanhSachTochucPhanCong);
        }
        const payload = {
            subSite,
            Comment: "",
            BanLanhDao: "",
            UserCC: "",
            AssignmentUser,
            AssignmentDept,
            taskID: TaskId
        };
        dispatch(taskVbDenPhanCongApi(payload))
        onCloseOwnModal()
    }, [filteredDanhSachTochucPhanCong, subSite, yKienLanhDao, TaskId, ItemTask, filteredDataPhongBan])

    useEffect(() => {
        setisShowAssignmentDept(IsGroupAssignmentDept)
    }, [IsGroupAssignmentDept])

    useEffect(() => {
        fetchIsGroupAssignmentDeptRequest()
    }, [ItemTask])

    return (
        <ModalCusTom
            transparent={true}
            visible={modalVisible}
            {...props}
            onCloseModalCustom={onCloseModal}
            style={styles.centeredView}
        >
            <KeyboardAvoidingView style={styles.centeredView}>
                <View style={styles.modalView}>
                    <View style={{
                        padding: dimensWidth(20),
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <Text style={{
                            flex: 1,
                            color: '#005FD4',
                            fontSize: FontSize.LARGE_X,
                            fontWeight: 700,
                        }}>Phân công</Text>
                        <TouchableOpacity style={{
                            marginRight: dimensWidth(40)
                        }}
                            onPress={onConfirmOwnModal}>
                            <ConfirmIcon />
                        </TouchableOpacity>
                        <TouchableOpacity onPress={onCloseOwnModal}>
                            <CloseXIcon />
                        </TouchableOpacity>
                    </View>
                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        marginBottom: dimnensHeight(10),
                        backgroundColor: '#F6F8FA'
                    }} />
                    <ScrollView>

                        <View>
                            <Text style={styles.titleBoss}>
                                Chọn người dùng để phân công
                            </Text>
                            <View style={styles.chooseTypeView}>
                                <Text style={styles.textChooseType}>
                                    {"Vui lòng bấm vào nút để chọn người dùng"}
                                </Text>
                                <TouchableOpacity
                                    style={styles.buttonPhongBan}
                                    onPress={() => setModalAssignmentUser(true)}
                                >
                                    <UserPlusIcon />
                                    <Text style={styles.textPhongBan} numberOfLines={1}>
                                        Người dùng
                                    </Text>
                                </TouchableOpacity>
                            </View>
                            {!arrayIsEmpty(filteredDataPhongBan) && (
                                <View style={styles.flatlist}>
                                    <SwipeListView
                                        extraData={filteredDataPhongBan}
                                        data={filteredDataPhongBan}
                                        renderItem={({ item, index }) =>
                                            <ItemPhongBan
                                                item={item}
                                                index={index}
                                            />
                                        }
                                        renderHiddenItem={(data, rowMap) => {
                                            return (

                                                <View style={styles.rowBack}>
                                                    <TouchableOpacity
                                                        style={styles.iconDelete}
                                                        onPress={() => {
                                                            onConfirmDeletePhongBan(data?.item?.dummyID);
                                                        }}
                                                    >
                                                        <DeleteRedIcon />
                                                    </TouchableOpacity>
                                                </View>
                                            );
                                        }}
                                        keyExtractor={(item: any, index) => item.dummyID}
                                        rightOpenValue={-50}
                                        disableRightSwipe
                                    />
                                </View>
                            )}
                            {
                                IsGroupAssignmentDept && (
                                    <View>
                                        <Text style={styles.titleBoss}>
                                            Tổ chức phân công thực hiện
                                        </Text>

                                        <View style={styles.chooseTypeView}>
                                            <Text style={styles.textChooseType}>
                                                {"Vui lòng bấm vào nút để chọn chi nhánh trực thuộc"}
                                            </Text>
                                            <TouchableOpacity
                                                style={styles.buttonPhongBan}
                                                onPress={onChooseAssigmentDept}
                                            >
                                                <MemberIcon />

                                                <Text style={styles.textPhongBan} numberOfLines={1}>
                                                    Chi nhánh trực thuộc
                                                </Text>
                                            </TouchableOpacity>
                                        </View>
                                        {!arrayIsEmpty(filteredDanhSachTochucPhanCong) && (
                                            <View style={styles.flatlist}>
                                                <SwipeListView
                                                    extraData={filteredDanhSachTochucPhanCong}
                                                    data={filteredDanhSachTochucPhanCong}
                                                    renderItem={({ item, index }) =>
                                                        <ItemToChucPhanCong
                                                            item={item}
                                                            index={index}
                                                        />
                                                    }
                                                    renderHiddenItem={(data, rowMap) => {
                                                        return (
                                                            <View style={styles.rowBack}>
                                                                <TouchableOpacity
                                                                    style={styles.iconChange}
                                                                    onPress={() => {
                                                                        handleChooseDueDate(
                                                                            data?.item?.dummyID,
                                                                            data?.item?.DueDate,
                                                                            EnumPhancong.ToChucPhanCong
                                                                        );
                                                                    }}
                                                                >
                                                                    <DueDateBlueIcon />
                                                                </TouchableOpacity>
                                                                <TouchableOpacity
                                                                    style={styles.iconDelete}
                                                                    onPress={() => {
                                                                        onConfirmDeleteDSToChucPhanCong(
                                                                            data?.item?.dummyID
                                                                        );
                                                                    }}
                                                                >
                                                                    <DeleteRedIcon />
                                                                </TouchableOpacity>
                                                            </View>
                                                        );
                                                    }}
                                                    keyExtractor={(item, index) => item.ID}
                                                    rightOpenValue={-50}
                                                    disableRightSwipe
                                                />
                                            </View>
                                        )}
                                    </View>
                                )
                            }
                        </View>
                    </ScrollView>
                </View>
            </KeyboardAvoidingView>

            <AssignmentDeptModal
                modalVisible={modalAssignmentDept}
                onCloseModal={onCloseAssignmentDeptModal}
                onConfirmModal={(data) => onConfirmAssigmentDeptModal(data)}
                ItemTask={ItemTask}
            />

            <AssignmentUserModal
                modalVisible={modalAssignmentUser}
                ItemTask={ItemTask}
                onCloseModal={() => setModalAssignmentUser(false)}
                onConfirmModal={(data) => onConfirmAssignmentUserModal(data)}
            />

            <CalendarPickerPhanCongModal
                modalCalendarVisible={isOpenCalendarPhanCongPicker}
                onDateChangeModal={onDueDateDateChangeModal}
                onCloseModal={onCloseCalendarPickerPhanCongModal}
                resetToday={resetToday}
                DueDate={DueDateParams}
                typePhanCong={typePhanCong}
            />

            <CommentAssignmentModal
                modalVisible={modalCommentAssignment}
                sellectedItemId={sellectedItemId}
                phanCongComment={commentAssignment}
                onCloseModalYKienChiDao={() => setModalCommentAssignment(false)}
                onConfirmModalYKienChiDao={(text) => onConfirmModalYKienChiDao(text)}
            />
        </ModalCusTom>
    )
}

const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(0,0,0,0.4)"
    },
    modalView: {
        height: dimnensHeight(640),
        width: dimensWidth(750),
        backgroundColor: 'white',
        borderRadius: 20,
        overflow: 'hidden'
    },
    chooseTypeView: {
        height: 100,
        borderWidth: 1,
        borderColor: "#005FD4",
        marginBottom: dimensWidth(15),
        borderRadius: 8,
        justifyContent: "center",
        alignItems: "center",
        marginHorizontal: dimensWidth(20),
        marginTop: dimensWidth(10),
    },
    flexDirection: {
        flexDirection: "row",
        paddingHorizontal: 20,
        alignItems: "center",
    },
    stroke: {
        borderWidth: 0.5,
        borderColor: "#999999",
        borderStyle: "dashed",
    },
    textType: {
        fontSize: FontSize.SMALL,
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 15,
        marginVertical: 10,
    },
    tabBarLabelActive: {
        color: colors.white,
        fontWeight: "400",
        fontSize: FontSize.MEDIUM,
    },
    textPhongBan: {
        color: colors.white,
        fontWeight: "400",
        fontSize: FontSize.MEDIUM,
        marginLeft: 5,
    },
    viewTabBottomBar: {
        flexDirection: "row",
        borderRadius: 8,
        justifyContent: "flex-end",
        marginBottom: 30,
    },
    buttonTransfer: {
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: colors.blueMedium,
        width: dimensWidth(130),
        height: dimensWidth(34),
        borderRadius: 4,
        marginEnd: 15,
    },
    buttonPhongBan: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: colors.blueMedium,
        height: 34,
        borderRadius: 4,
        marginTop: 10,
        paddingHorizontal: 20,
    },
    buttonExit: {
        alignItems: "center",
        justifyContent: "center",
        width: dimensWidth(130),
        height: dimensWidth(34),
        borderRadius: 4,
    },
    buttonExitText: {
        color: colors.red,
        fontWeight: "400",
        fontSize: FontSize.MEDIUM,
    },
    textAssign: {
        color: colors.blueMedium,
        fontWeight: "700",
        fontSize: FontSize.LARGE,
    },
    viewAssign: {
        backgroundColor: colors.lightBlue,
        padding: 15,
    },
    titleBoss: {
        fontSize: FontSize.LARGE,
        color: colors.black,
        fontWeight: "700",
        fontFamily: "arial",
        marginHorizontal: 15,
        marginTop: 10,
    },
    commentInput: {
        paddingHorizontal: 10,
        borderColor: colors.greyDDD,
        borderRadius: 3,
        height: dimensWidth(100),
        borderWidth: 1,
        marginHorizontal: 15,
        marginBottom: 10,
        textAlignVertical: "top",
    },
    typeChild: {
        paddingHorizontal: 16,
        flexDirection: "row",
        alignItems: "center",
        marginHorizontal: 15,
        justifyContent: "space-between",
    },
    textFiltedType: {
        fontSize: FontSize.MEDIUM,
        color: colors.black,
        fontWeight: "400",
        fontFamily: "arial",
        marginRight: 9,
    },
    textChooseType: {
        fontSize: FontSize.MEDIUM,
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginRight: 9,
        marginHorizontal: 10,
    },
    title: {
        fontSize: FontSize.MEDIUM,
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
    },
    titlePhongBan: {
        flex: 1,
        fontSize: FontSize.MEDIUM,
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
    },
    blueText: {
        fontSize: dimensWidth(13),
        color: colors.scienceBlue,
        fontWeight: "400",
        fontFamily: "arial",
    },
    itemPhongBan: {
        height: dimensWidth(70),
    },
    itemPhongBanChild: {
        flexDirection: "row",
        backgroundColor: colors.white,
        padding: 15,
    },
    flexDirectionRowBetween: {
        flex: 1,
        flexDirection: "row",
        justifyContent: "space-between",
        paddingBottom: 8,
        alignItems: "center",
    },
    rowBack: {
        width: 50,
        height: 50,
        alignSelf: "flex-end",
        flexDirection: "row",
    },
    flexRowPhongBan: {
        flexDirection: "row",
    },
    flexRow: {
        flexDirection: "row",
    },
    iconChange: {
        justifyContent: "center",
        alignItems: "center",
        marginHorizontal: dimensWidth(15),
    },
    iconDelete: {
        flex: 1,
        height: dimensWidth(70),
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#FFD7D7"
    },
    flatlist: {
        borderColor: colors.greyDDD,
        borderWidth: 1,
        borderRadius: 8,
        marginHorizontal: dimensWidth(20),
        overflow: "hidden",
        marginBottom: 20,
    },
    backRightBtnLeft: {
        backgroundColor: 'blue',
        right: 75,
    },
    itemAvatar: {
        height: dimensWidth(40),
        width: dimensWidth(40),
        marginRight: dimensWidth(10),
        borderRadius: dimensWidth(20),
    },
    commentText: {
        fontSize: dimensWidth(13),
        color: colors.scienceBlue,
        fontWeight: "400",
        fontFamily: "arial",
    },
});

export default AssignmentModal