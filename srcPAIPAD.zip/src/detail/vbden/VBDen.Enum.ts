export enum Action {
    ChuyenPhanCong = 1,
    ChuyenXuLy = 2,
    PhanCong = 4,
    PhanCongLai = 8,
    ChoYKienVP = 16,
    ChoYKienLanhDao = 32,
    ChiaSe = 64,
    BoSungThuHoi = 128,
    KetThuc = 256
}
export enum TaskVB {
    Luu = 1,
    PhanCong = 2,
    TraoDoiLai = 16,
    HoanTat = 32
}
export enum EnumPhancong {
    null,
    PhongBan = 0,
    ToChucPhanCong = 1,
    PhongBanPhanCongLai = 2,
    BoSungThuHoi = 128
}
export enum TaskRole {
    NguoiXem = 0,
    NguoiGiaoViec = 256,
    NguoiXuLy = 64
}
export enum NguoiGiaoViecVBDen {
    Luu = 1,
    TraoDoiLai = 16,
}