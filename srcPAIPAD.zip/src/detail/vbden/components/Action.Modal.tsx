import { Alert, Modal, StyleSheet, Text, Pressable, View, TouchableOpacity, Dimensions } from 'react-native';
import React, { FC, useState, useCallback, useEffect } from "react";
import { FontSize, dimensWidth, dimnensHeight } from '~/base/Constants';
import { Action } from '../VBDen.Enum';
import {
    FowardProcesscon,
    TransferProcessIcon,
    ShareBlueIcon,
    AddRemoveIcon,
    ReAssignIcon,
    AssignGreenIcon,
    KetThucIcon,
    BoSungThongTinIcon,
} from "../../../base/assets/svg";
import colors from '../../../base/Colors'
import ModalCusTom from '~/base/components/ModalCusTom';

interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    onActionPress: (ID: number) => void;
    Actions: any;
}

const ActionModel: FC<Props> = ({
    modalVisible,
    onCloseModal,
    onActionPress,
    Actions,
    ...props
}: Props) => {
    const IconView = ({ ID }: any) => {
        if (ID === Action.ChuyenPhanCong)
            return <TransferProcessIcon color={colors.green} dimens={25}/>;
        if (ID === Action.ChuyenXuLy)
            return <FowardProcesscon color={colors.green} dimens={25}/>;
        if (ID === Action.PhanCong)
            return <AssignGreenIcon color={colors.green} dimens={25}/>;
        if (ID === Action.PhanCongLai)
            return <ReAssignIcon color={colors.green} dimens={25}/>;
        if (ID === Action.ChiaSe)
            return <ShareBlueIcon color={"#0091FF"} dimens={25} />;
        if (ID === Action.BoSungThuHoi)
            return <AddRemoveIcon color={colors.green} dimens={25}/>;
        if (ID === Action.KetThuc)
            return <KetThucIcon color={colors.green} dimens={25}/>;
        return <View />;
    };

    const ItemAction = ({ item, index, onChooseonActionMorePress }: any) => {
        if (index <= 2) return null;
        const { Title, ID } = item;
        return (
            <View style={styles.chooseTypeView}>
                <TouchableOpacity
                    style={styles.flexDirection}
                    onPress={() => onChooseonActionMorePress(ID)}
                >
                    <IconView ID={ID} />
                    <Text style={styles.textType} numberOfLines={1}>
                        {Title}
                    </Text>
                </TouchableOpacity>
                {Actions.length !== index + 1 && <View style={styles.stroke} />}
            </View>
        );
    };

    return (
        <View style={styles.centeredView}>
            <ModalCusTom
                transparent={true}
                visible={modalVisible}
                onCloseModalCustom={onCloseModal}
                onRequestClose={() => {
                }}>
                <TouchableOpacity
                    activeOpacity={1}
                    onPress={onCloseModal}>
                    <View style={styles.centeredView}>
                        <View style={styles.modalView}>
                            <View style={styles.chooseTypeView}>
                                {Actions &&
                                    Actions.map((item: any, index: any) => {
                                        return (
                                            <ItemAction
                                                key={index}
                                                item={item}
                                                index={index}
                                                onChooseonActionMorePress={onActionPress}
                                            />
                                        );
                                    })}
                            </View>
                        </View>
                    </View>
                </TouchableOpacity>
            </ModalCusTom>
        </View>
    );
};

const styles = StyleSheet.create({
    centeredView: {
        width: '100%',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        position: 'absolute',
    },
    modalView: {
        marginRight: dimensWidth(50),
        backgroundColor: 'white',
        borderBottomLeftRadius: 4,
        borderBottomRightRadius: 4,
        marginTop: dimnensHeight(75),
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 2,
    },
    chooseTypeView: {
        backgroundColor: colors.white,
        borderRadius: 4,
    },
    flexDirection: {
        height: dimnensHeight(60),
        width: dimensWidth(200),
        flexDirection: "row",
        paddingHorizontal: 20,
        alignItems: "center",
    },
    stroke: {
        borderWidth: 0.5,
        borderColor: "#999",
    },
    textType: {
        fontSize: FontSize.LARGE,
        color: colors.black,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: dimensWidth(10),
    },
    tabBarLabelActive: {
        color: colors.white,
        fontWeight: "400",
        fontSize: FontSize.LARGE,
    },
    viewTabBottomBar: {
        flexDirection: "row",
        height: dimensWidth(66),
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: colors.blueMedium,
        borderRadius: 8,
    }
});

export default ActionModel;