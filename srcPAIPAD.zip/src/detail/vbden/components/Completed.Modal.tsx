import React, { FC, useState, useCallback, useEffect } from "react";
import {
    Modal,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    Platform,
    TouchableWithoutFeedback,
    Keyboard,
    KeyboardAvoidingView
} from "react-native";
import colors from "../../../base/Colors";
import { dimensWidth, dimnensHeight, FontSize } from "../../../base/Constants";
import { checkIsEmpty } from "../../../base/Functions";
import TextInputCustom from "../../../base/components/TextInputCustom";
import { CloseXIcon, ConfirmIcon } from "~/base/assets/svg";
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { submitActionCompleted } from "~/base/stories/vbden/reducer";
import ModalCusTom from "~/base/components/ModalCusTom";

interface Props {
    modalVisible: Boolean;
    onCloseCompletedModal: () => void;
    ItemId: any;
    Comment: any
}

const CompletedModal: FC<Props> = ({
    modalVisible,
    onCloseCompletedModal,
    ItemId,
    Comment,
    ...props
}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { subSite } = useSelector((state: any) => state.login);
    const [text, setText] = useState("");

    const onChangeText = useCallback(
        (input: string) => {
            setText(input);
        },
        [text]
    );
    const onConfirm = useCallback(() => {
        const body = {
            SubSite: subSite,
            Comment: text,
            ItemId,
        };

        dispatch(submitActionCompleted(body));
        onCloseModal()

    }, [text, ItemId]);

    const onCloseModal = useCallback(() => {
        setText("")
        onCloseCompletedModal();
    }, []);

    useEffect(() => {
        if (!checkIsEmpty(ItemId)) {
            setText("");
        }
    }, [ItemId]);

    useEffect(() => {
        setText(Comment)
    }, [Comment])

    return (
        <ModalCusTom
            transparent={true}
            visible={modalVisible}
            {...props}
            style={styles.centeredView}
            onCloseModalCustom={onCloseModal}
        >
            <TouchableWithoutFeedback
                onPress={Keyboard.dismiss}
                accessible={false}
                style={{ flex: 1, backgroundColor: "red" }}
            >
                <KeyboardAvoidingView
                    style={styles.centeredView}
                    // behavior={Platform.OS === "ios" ? "padding" : "height"}
                >
                    <View style={styles.modalView}>
                        <View style={{
                            padding: dimensWidth(20),
                            flexDirection: 'row',
                            alignItems: 'center',
                            justifyContent: 'center'
                        }}>
                            <Text style={{
                                flex: 1,
                                color: '#005FD4',
                                fontSize: FontSize.LARGE_X,
                                fontWeight: 700,
                            }}>Kết thúc</Text>
                            <TouchableOpacity style={{
                                marginRight: dimensWidth(40)
                            }}
                                onPress={onConfirm}
                            >
                                <ConfirmIcon />
                            </TouchableOpacity>
                            <TouchableOpacity onPress={onCloseModal}>
                                <CloseXIcon />
                            </TouchableOpacity>
                        </View>
                        <View style={{
                            width: '100%',
                            height: dimnensHeight(10),
                            backgroundColor: '#F6F8FA',
                            marginBottom: dimnensHeight(10)
                        }} />

                        <View>

                            <Text style={styles.textType}>Ý kiến lãnh đạo</Text>
                            <TextInputCustom
                                placeholder="Vui lòng nhập ý kiến"
                                placeholderTextColor={colors.grey999}
                                multiline
                                onChangeText={(text) => onChangeText(text)}
                                value={text}
                                style={styles.yKienLanhDaoInput}
                            />
                            <Text style={styles.textWarning}>
                                Anh/Chị xác nhận kết thúc luồng xử lý của văn bản này?
                            </Text>
                        </View>
                    </View>
                </KeyboardAvoidingView>
            </TouchableWithoutFeedback>
        </ModalCusTom>
    );
};

const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(0,0,0,0.4)"
    },
    modalView: {
        height: dimnensHeight(640),
        width: dimensWidth(750),
        backgroundColor: 'white',
        borderRadius: 20,
        overflow: 'hidden'
    },
    chooseTypeView: {
        height: 100,
        borderWidth: 1,
        borderColor: "#005FD4",
        marginBottom: 15,
        borderRadius: 8,
        justifyContent: "center",
        alignItems: "center",
        marginHorizontal: dimensWidth(20),
        marginTop: 10,
    },
    flexDirection: {
        // height: 67,
        flexDirection: "row",
        paddingHorizontal: dimensWidth(20),
        alignItems: "center",
    },
    stroke: {
        borderWidth: 0.5,
        borderColor: "#999999",
        borderStyle: "dashed",
    },
    textType: {
        fontSize: FontSize.SMALL,
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: dimensWidth(20),
        marginVertical: dimnensHeight(10),
    },
    textWarning: {
        fontSize: FontSize.SMALL,
        color: colors.red,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: dimensWidth(20),
        marginVertical: 10,
    },
    tabBarLabelActive: {
        color: colors.white,
        fontWeight: "400",
        fontSize: FontSize.MEDIUM,
    },
    textPhongBan: {
        color: colors.white,
        fontWeight: "400",
        fontSize: FontSize.MEDIUM,
        marginLeft: 5,
    },
    viewTabBottomBar: {
        flexDirection: "row",
        // height: dimensWidth(66),
        borderRadius: 8,
        justifyContent: "flex-end",
    },
    buttonTransfer: {
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: colors.blueMedium,
        width: dimensWidth(130),
        height: dimensWidth(34),
        borderRadius: 4,
        marginEnd: dimensWidth(20),
    },
    buttonPhongBan: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: colors.blueMedium,
        height: 34,
        borderRadius: 4,
        marginTop: 10,
        paddingHorizontal: dimensWidth(20),
    },
    buttonExit: {
        alignItems: "center",
        justifyContent: "center",
        width: dimensWidth(130),
        height: dimensWidth(34),
        borderRadius: 4,
    },
    buttonExitText: {
        color: colors.red,
        fontWeight: "400",
        fontSize: FontSize.MEDIUM,
    },
    textAssign: {
        color: colors.blueMedium,
        fontWeight: "700",
        fontSize: FontSize.LARGE,
    },
    viewAssign: {
        backgroundColor: colors.lightBlue,
        padding: dimensWidth(20),
    },
    titleBoss: {
        fontSize: FontSize.LARGE,
        color: colors.black,
        fontWeight: "700",
        fontFamily: "arial",
        marginHorizontal: dimensWidth(20),
    },
    yKienLanhDaoInput: {
        paddingHorizontal: 10,
        borderColor: colors.greyDDD,
        borderRadius: 3,
        height: dimensWidth(100),
        borderWidth: 1,
        marginHorizontal: dimensWidth(20),
        marginBottom: 10,
        textAlignVertical: "top",
    },
    typeChild: {
        paddingHorizontal: dimensWidth(20),
        flexDirection: "row",
        alignItems: "center",
        marginHorizontal: dimensWidth(20),
        justifyContent: "space-between",
    },
    textFiltedType: {
        fontSize: FontSize.MEDIUM,
        color: colors.black,
        fontWeight: "400",
        fontFamily: "arial",
        marginRight: 9,
    },
    textChooseType: {
        fontSize: FontSize.MEDIUM,
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginRight: 9,
        marginHorizontal: 10,
    },
});

export default CompletedModal;