import React, { FC, useState, useCallback, useEffect } from "react";
import {
    Modal,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    KeyboardAvoidingView,
    ScrollView
} from "react-native";
import { FlatList } from "react-native-gesture-handler";
import colors from "~/base/Colors";
import { FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";
import { arrayIsEmpty, checkNotNullAndEmpty, removeSpecialCharacters, splitID } from "~/base/Functions";
import { BackIcon, CloseXIcon, ConfirmIcon, DeleteRedIcon, MemberIcon, MinusIcon, PlusIcon, SellectedBoxIcon, UnSellectedBoxIcon, UserPlusIcon } from "~/base/assets/svg";
import { TextInputCustom } from "~/base/components";
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { fetchDepartment } from "~/base/stories/data/reducer";
import ModalCusTom from "~/base/components/ModalCusTom";

interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    onConfirmModal: (data: any) => void;
    ItemId: any
}

const AssignmentDeptModal: FC<Props> = ({
    modalVisible,
    onCloseModal,
    onConfirmModal,
    ItemId,
    ...props
}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { subSite } = useSelector((state: any) => state.login);
    const { dataDepartment } = useSelector((state: any) => state.data);
    const [danhsachToChucPhanCong, setDanhSachToChucPhanCong] = useState([]);
    const [isAllSellectedToChucPhanCong, setIsAllSellectedToChucPhanCong] = useState(false);

    type ItemProps = {
        index: number;
        item: any;
        chooseTypePress: (ID: string) => void;
    };

    const Item = ({ item, chooseTypePress, index }: ItemProps) => {
        const { Title, ID, isSellectedToChucPhanCong } = item;

        return (
            <TouchableOpacity
                style={[styles.item, index === 0 && { borderTopWidth: 0 }]}
                onPress={() => chooseTypePress(ID)}
            >
                <View>
                    <Text style={styles.title}>{Title}</Text>
                </View>
                <View>
                    {isSellectedToChucPhanCong ? (
                        <SellectedBoxIcon />
                    ) : (
                        <UnSellectedBoxIcon />
                    )}
                </View>
            </TouchableOpacity>
        );
    };

    const fetchData = useCallback(async () => {
        dispatch(fetchDepartment(subSite));
    }, [dispatch]);

    useEffect(() => {
        const IDHaveIsRoot = dataDepartment?.find((it) => it?.IsRoot)?.ID;
        const dataTmp = dataDepartment
            ?.filter(
                (it) =>
                    checkNotNullAndEmpty(it?.URL) &&
                    splitID(it?.ParentDept) == IDHaveIsRoot
            )
            .map((it) => (it = { ...it, dummyID: it.ID, isSellectedToChucPhanCong: false }));
        setDanhSachToChucPhanCong(dataTmp);
    }, [dataDepartment]);

    const chooseTypePress = useCallback(
        (ID) => {
            let tmp = [];
            tmp = danhsachToChucPhanCong.map((it: any) =>
                it.ID === ID
                    ? {
                        ...it,
                        isSellectedToChucPhanCong: !it.isSellectedToChucPhanCong,
                        DueDate: "",
                    }
                    : it
            );
            setDanhSachToChucPhanCong(tmp);
        },
        [danhsachToChucPhanCong]
    );

    const onChangeAllSellectedToChucPhanCong = useCallback(() => {
        setIsAllSellectedToChucPhanCong(!isAllSellectedToChucPhanCong);
        setDanhSachToChucPhanCong((prevData: any) => {
            const newData = [...prevData];

            const findItemAndToggleToChucPhanCong = (items: any) => {
                for (let i = 0; i < items.length; i++) {
                    const item = items[i];

                    const newValue = !isAllSellectedToChucPhanCong;
                    item.isSellectedToChucPhanCong = newValue;
                }
            };
            findItemAndToggleToChucPhanCong(newData);
            return newData;
        });
    }, [isAllSellectedToChucPhanCong, danhsachToChucPhanCong]);

    useEffect(() => {
        fetchData()
    }, [ItemId])

    return (
        <ModalCusTom
            transparent={true}
            visible={modalVisible}
            {...props}
            style={styles.centeredView}
        >
            <KeyboardAvoidingView style={styles.centeredView}>
                <View style={styles.modalView}>
                    <View style={{
                        padding: dimensWidth(20),
                        flexDirection: 'row',
                        alignItems: 'center'
                    }}>
                        <TouchableOpacity style={{
                            flex: 0.08
                        }}
                            onPress={onCloseModal}>
                            <BackIcon />
                        </TouchableOpacity>
                        <Text style={{
                            flex: 1,
                            color: '#005FD4',
                            fontSize: FontSize.LARGE_X,
                            fontWeight: 700,
                        }}>Tổ chức phân công thực hiện</Text>
                        <TouchableOpacity style={{
                            marginRight: dimensWidth(40)
                        }}
                            onPress={() => onConfirmModal(danhsachToChucPhanCong)}>
                            <ConfirmIcon />
                        </TouchableOpacity>
                        <TouchableOpacity onPress={onCloseModal}>
                            <CloseXIcon />
                        </TouchableOpacity>
                    </View>
                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        backgroundColor: '#F6F8FA'
                    }} />
                    <FlatList
                        contentContainerStyle={styles.flatlist}
                        ListHeaderComponent={() => {
                            return (
                                <View style={styles.flexDirectionRowHeader}>
                                    <View style={styles.viewListHeader}>
                                        <Text style={styles.header} numberOfLines={2}>
                                            {"Thực hiện"}
                                        </Text>
                                        <TouchableOpacity
                                            style={styles.selectedAll}
                                            onPress={onChangeAllSellectedToChucPhanCong}
                                        >
                                            {isAllSellectedToChucPhanCong ? (
                                                <SellectedBoxIcon />
                                            ) : (
                                                <UnSellectedBoxIcon />
                                            )}
                                        </TouchableOpacity>
                                    </View>
                                </View>
                            );
                        }}
                        data={danhsachToChucPhanCong}
                        extraData={danhsachToChucPhanCong}
                        renderItem={({ item, index }) => (
                            <Item
                                index={index}
                                item={item}
                                chooseTypePress={(ID) => chooseTypePress(ID)}
                            />
                        )}
                        keyExtractor={(item: any) => item?.ID}
                    />
                </View>
            </KeyboardAvoidingView>
        </ModalCusTom>
    )
}

const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(0,0,0,0.4)"
    },
    modalView: {
        height: dimnensHeight(780),
        width: dimensWidth(750),
        backgroundColor: 'white',
        borderRadius: 20,
        overflow: 'hidden'
    },
    flatlist: {
        backgroundColor: "#FFFFFF",
        borderRadius: 8,
    },
    item: {
        flexDirection: "row",
        justifyContent: "space-between",
        padding: 20,
        borderTopWidth: 1,
        borderTopColor: "#E5E5E5",
    },
    title: {
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.black,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 15,
    },
    position: {
        fontSize: dimensWidth(13),
        lineHeight: dimensWidth(20),
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 15,
    },
    viewHeader: {
        backgroundColor: colors.primary,
        height: Platform.OS === "ios" ? 130 : 90,
        justifyContent: "center",
        width: "100%",
        padding: 10,
    },
    titleHeader: {
        flex: 1,
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.white,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 15,
    },
    flexDirectionRow: {
        flexDirection: "row",
        alignItems: "center",
    },
    backPress: {
        padding: 8,
    },
    iconDone: {
        marginEnd: 15,
    },
    flexDirectionRowHeader: {
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: colors.alice_blue,
        paddingVertical: 10,
        justifyContent: "flex-end",
    },
    header: {
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.textBlack19,
        fontWeight: "400",
        fontFamily: "arial",
        marginRight: 10,
    },
    selectedAll: {
        height: dimnensHeight(45),
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 20
    },
    viewListHeader: {
        flex: 1,
        flexDirection: 'row',
        alignItems: "center",
        justifyContent: "flex-end",
    }
});

export default AssignmentDeptModal