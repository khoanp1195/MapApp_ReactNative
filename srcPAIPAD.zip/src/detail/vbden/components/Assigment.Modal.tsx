import React, { FC, useState, useCallback, useMemo, useEffect } from "react";
import {
    Modal,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    KeyboardAvoidingView,
    ScrollView,
    Animated,
    Alert
} from "react-native";
import colors from "~/base/Colors";
import { FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";
import { arrayIsEmpty, checkIsEmpty, format_dd_mm_yy, isNullOrUndefined, removeSpecialCharacters } from "~/base/Functions";
import { CloseXIcon, ConfirmIcon, DeleteRedIcon, DueDateBlueIcon, MemberIcon, UserPlusIcon } from "~/base/assets/svg";
import { TextInputCustom } from "~/base/components";
import AssignmentUserModal from "./AssigmentUser.Modal";
import { SwipeListView, SwipeRow } from "react-native-swipe-list-view";
import AssignmentDeptModal from "./AssigmentDept.Modal";
import { EnumPhancong } from "../VBDen.Enum";
import CalendarPickerModal from "~/search/components/CalendarPickerModal";
import CalendarPickerPhanCongModal from "./CalendarPicker.Assigment.Modal";
import { submitActionAssigment } from "~/base/stories/vbden/reducer";
import { useDispatch, useSelector } from "react-redux";
import { ThunkDispatch } from "@reduxjs/toolkit";
import ModalCusTom from "~/base/components/ModalCusTom";

interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    onConfirmModal: (data: any) => void;
    Comment: string;
    ItemId: any,
    BanLanhDao: any,
}

const AssignmentModal: FC<Props> = ({
    modalVisible,
    onCloseModal,
    onConfirmModal,
    Comment,
    ItemId,
    BanLanhDao,
    ...props
}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const [yKienLanhDao, setYKienLanhDao] = useState("")
    const [modalAssignmentUser, setModalAssimentUser] = useState(false)
    const [dataAfterAssigmentUser, setDataAfterAssigmentUser] = useState([])
    const [modalAssignmentDept, setModalAssigmentDept] = useState(false)
    const [dataAfterAssignmentDept, setDataAfterAssigmentDept] = useState([])
    const [isOpenCalendarPhanCongPicker, setIsOpenCalendarPhanCongPicker] = useState(false)
    const [DueDateParams, setDueDateDateParams] = useState<string>("");
    const [typePhanCong, setTypePhanCong] = useState<EnumPhancong | null>(null);
    const [sellectedItemId, setSellectedItemId] = useState<number>(-1);

    const { isLoading } = useSelector((state: any) => state.vbden);
    const { subSite } = useSelector((state: any) => state.login);

    useEffect(() => {
        setYKienLanhDao(Comment)
    }, [Comment])

    const ItemPhongBan = ({ item, index, onPressSwipe }: any) => {
        const { Title, DueDate, Created, isThucHien } = item;
        const DueDateFormated = checkIsEmpty(DueDate)
            ? DueDate
            : format_dd_mm_yy(DueDate);
        const isOdd = index % 2 === 0;

        return (
            <Animated.View
                style={[
                    styles.itemPhongBanChild,
                    isOdd && { backgroundColor: colors.alice_blue },
                ]}
            >
                <View style={styles.flexDirectionRowBetween}>
                    <Text style={styles.title} numberOfLines={1}>
                        {Title}
                    </Text>
                    <TouchableOpacity onPress={() => {
                        handleChooseDueDate(
                            item?.dummyID,
                            item?.DueDate,
                            EnumPhancong.PhongBan
                        )
                        onPressSwipe()
                    }}>
                        <Text style={styles.blueText} numberOfLines={1}>
                            {DueDateFormated}
                        </Text>
                    </TouchableOpacity>
                </View>
                <Text style={styles.blueText} numberOfLines={1}>
                    {isThucHien ? "Thực Hiện" : "Phối Hợp"}
                </Text>
            </Animated.View>
        );
    };

    const ItemToChucPhanCong = ({ item, index, onPressSwipe }: anhy) => {
        const { Title, ParentDept, Created, DueDate } = item;
        const DueDateFormated = checkIsEmpty(DueDate)
            ? DueDate
            : format_dd_mm_yy(DueDate);
        const isOdd = index % 2 === 0;
        return (
            <Animated.View
                style={[
                    styles.itemPhongBanChild,
                    isOdd && { backgroundColor: colors.alice_blue },
                ]}
            >
                <View style={styles.flexDirectionRowBetween}>
                    <Text style={styles.title} numberOfLines={1}>
                        {Title}
                    </Text>
                    <TouchableOpacity onPress={() => {
                        handleChooseDueDate(
                            item?.dummyID,
                            item?.DueDate,
                            EnumPhancong.ToChucPhanCong
                        )
                        onPressSwipe()
                    }}>
                        <Text style={styles.blueText} numberOfLines={1}>
                            {DueDateFormated}
                        </Text>
                    </TouchableOpacity>
                </View>
                <Text style={styles.blueText} numberOfLines={1}>
                    {removeSpecialCharacters(ParentDept)}
                </Text>
            </Animated.View>
        );
    };

    const onCloseOwnModal = useCallback(() => {
        setSellectedItemId(-1)
        setDueDateDateParams("")
        setYKienLanhDao("")
        setDataAfterAssigmentDept([])
        setDataAfterAssigmentUser([])
        onCloseModal()
    }, [])

    const onChooseAssigmentUser = useCallback(() => {
        setModalAssimentUser(true)
    }, [])

    const onChooseAssigmentDept = useCallback(() => {
        setModalAssigmentDept(true)
    }, [])

    const onCloseAssigmentUserModal = useCallback(() => {
        setModalAssimentUser(false)
    }, [])

    const onCloseAssignmentDeptModal = useCallback(() => {
        setModalAssigmentDept(false)
    }, [])

    const onConfirmAssigmentDeptModal = useCallback((data: any) => {
        setModalAssigmentDept(false)
        setDataAfterAssigmentDept(data)
    }, [])

    const onConfirmAssigmentUserModal = useCallback((data: any) => {
        setModalAssimentUser(false)
        setDataAfterAssigmentUser(data)
    }, [modalAssignmentUser])

    const onChangeYKienLanhDao = useCallback((input: string) => {
        setYKienLanhDao(input);
    }, [yKienLanhDao]);


    const findItemsWithPhongBan = (data) => {
        const result = [];

        const traverseData = (data) => {
            data.forEach((item) => {
                if (item.isThucHien || item.isPhoiHop) {
                    result.push(item);
                }

                if (item.children && item.children.length > 0) {
                    traverseData(item.children); // Đệ quy duyệt qua các phần tử con
                }
            });
        };

        traverseData(data); // Bắt đầu duyệt từ mảng data

        return result;
    };

    const filteredDataPhongBan = useMemo(() => {
        let filteredData: any[] = [];
        if (!arrayIsEmpty(dataAfterAssigmentUser)) {
            filteredData = findItemsWithPhongBan(dataAfterAssigmentUser);
            return filteredData;
        }
        return filteredData;
    }, [dataAfterAssigmentUser]);

    const filteredDanhSachTochucPhanCong = useMemo(() => {
        if (!arrayIsEmpty(dataAfterAssignmentDept)) {
            const filteredData = dataAfterAssignmentDept.filter(
                (it) => it.isSellectedToChucPhanCong
            );
            return filteredData;
        }
    }, [dataAfterAssignmentDept]);

    const handleToggleDeletePhongban = useCallback(
        (itemId: any) => {
            setDataAfterAssigmentUser((prevData: any) => {
                const newData = [...prevData];

                const findItemAndTogglePhoiHop = (items: any) => {
                    for (let i = 0; i < items.length; i++) {
                        const item = items[i];

                        if (item.dummyID === itemId) {
                            item.isPhoiHop = false;
                            item.isThucHien = false;
                            item.DueDate = "";
                            return;
                        }

                        if (item.children && item.children.length > 0) {
                            findItemAndTogglePhoiHop(item.children);
                        }
                    }
                };
                findItemAndTogglePhoiHop(newData);

                return newData;
            });
        },
        [dataAfterAssigmentUser]
    );

    const onConfirmDeletePhongBan = useCallback((dummyID: any) => {
        Alert.alert("Thông báo", "Bạn thực sự muốn xóa?", [
            {
                text: "Cancel",
                onPress: () => console.log("Cancel Pressed"),
                style: "cancel",
            },
            { text: "OK", onPress: () => handleToggleDeletePhongban(dummyID) },
        ]);
    }, []);

    const onConfirmDeleteDSToChucPhanCong = useCallback((dummyID: any) => {
        Alert.alert("Thông báo", "Bạn thực sự muốn xóa?", [
            {
                text: "Cancel",
                onPress: () => console.log("Cancel Pressed"),
                style: "cancel",
            },
            { text: "OK", onPress: () => handleToggleDeleteDSToChucPhanCong(dummyID) },
        ]);
    }, []);

    const handleToggleDeleteDSToChucPhanCong = (itemId: any) => {
        setDataAfterAssigmentDept((prevData: any) => {
            const newData = prevData.map((it) =>
                it.dummyID == itemId ? { ...it, isSellectedToChucPhanCong: false } : it
            );
            return newData;
        });
    };

    const onDueDateDateChangeModal = useCallback((date: string) => {
        setIsOpenCalendarPhanCongPicker(false);
        if (typePhanCong === EnumPhancong.PhongBan) {
            setDataAfterAssigmentUser((prevData: any) => {
                const newData = [...prevData];
                const findItemAndToggleDueDate = (items: any) => {
                    for (let i = 0; i < items.length; i++) {
                        const item = items[i];

                        if (item.dummyID === sellectedItemId) {
                            item.DueDate = date;
                            return;
                        }
                        if (item.children && item.children.length > 0) {
                            findItemAndToggleDueDate(item.children);
                        }
                    }
                };
                findItemAndToggleDueDate(newData);

                return newData;
            });
        } else {
            setDataAfterAssigmentDept((prevData: any) => {
                const newData = [...prevData];
                const findItemAndToggleDueDate = (items: any) => {
                    for (let i = 0; i < items.length; i++) {
                        const item = items[i];

                        if (item.dummyID === sellectedItemId) {
                            item.DueDate = date;
                            return;
                        }
                        if (item.children && item.children.length > 0) {
                            findItemAndToggleDueDate(item.children);
                        }
                    }
                };
                findItemAndToggleDueDate(newData);

                return newData;
            });
        }
    },
        [sellectedItemId, typePhanCong, dataAfterAssigmentUser, dataAfterAssignmentDept]
    );

    const onCloseCalendarPickerPhanCongModal = useCallback(() => {
        setIsOpenCalendarPhanCongPicker(false);
    }, []);

    const resetToday = useCallback((today: any) => { }, []);

    const handleChooseDueDate = useCallback(
        (itemId: number, DueDate: string, typePhanCong: EnumPhancong) => {
            setIsOpenCalendarPhanCongPicker(true);
            setTypePhanCong(typePhanCong);
            setDueDateDateParams(DueDate);
            setSellectedItemId(itemId);
        },
        [typePhanCong, DueDateParams, sellectedItemId]
    );

    const onConfirmOwnModal = useCallback(() => {
        let AssignmentUser = "";
        let AssignmentDept = "";
        if (arrayIsEmpty(filteredDataPhongBan) && arrayIsEmpty(filteredDanhSachTochucPhanCong)) {
            Alert.alert("Thông báo", "Vui lòng chọn phòng ban!", [
                { text: "OK", onPress: () => { } },
            ]);
            return;
        } else {
            const Comment = "";
            const traverseData = (filterData: any) => {
                filterData.forEach((item: any) => {
                    const DepartmentTitle = item.ID + ";#" + item.Title;
                    const DueDateFormat = isNullOrUndefined(item?.DueDate) ? "" : item?.DueDate
                    const assignmentType = item.isThucHien
                        ? "&&1&&0&&0&&"
                        : "&&0&&0&&1&&";
                    if (item.isUser) {
                        AssignmentUser +=
                            // AssignmentUser +
                            // plusString +
                            DepartmentTitle +
                            assignmentType +
                            DueDateFormat +
                            "&&" +
                            item.Manager +
                            "&&" +
                            Comment +
                            "@@";
                    } else {
                        AssignmentUser +=
                            // AssignmentUser +
                            // plusString +
                            item.Manager +
                            assignmentType +
                            DueDateFormat +
                            "&&" +
                            DepartmentTitle +
                            "&&" +
                            Comment +
                            "@@";
                    }
                });
            };
            traverseData(filteredDataPhongBan); // Bắt đầu duyệt từ mảng data
        }

        if (!arrayIsEmpty(filteredDanhSachTochucPhanCong)) {
            const traverseData = (filterData: any) => {
                filterData.forEach((item: any) => {
                    const DepartmentTitle = item?.ID + ";#" + item?.Title;
                    const DueDateFormat = isNullOrUndefined(item?.DueDate) ? "" : item?.DueDate
                    AssignmentDept +=
                        DepartmentTitle + "&&" + item?.URL + "&&" + DueDateFormat + "@@";
                });
            };
            traverseData(filteredDanhSachTochucPhanCong); // Bắt đầu duyệt từ mảng data
        }
        const payload = {
            SubSite: subSite,
            Comment: yKienLanhDao,
            BanLanhDao: "",
            UserCC: "",
            AssignmentUser,
            AssignmentDept,
            ItemId,
        };
        dispatch(submitActionAssigment(payload))
        onCloseOwnModal()
    }, [filteredDanhSachTochucPhanCong, yKienLanhDao, ItemId, subSite, filteredDataPhongBan])

    return (
        <ModalCusTom
            transparent={true}
            visible={modalVisible}
            {...props}
            style={styles.centeredView}
            onCloseModalCustom={onCloseModal}
        >
            <KeyboardAvoidingView style={styles.centeredView}>
                <View style={styles.modalView}>
                    <View style={{
                        padding: dimensWidth(20),
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <Text style={{
                            flex: 1,
                            color: '#005FD4',
                            fontSize: FontSize.LARGE_X,
                            fontWeight: 700,
                        }}>Phân công</Text>
                        <TouchableOpacity style={{
                            marginRight: dimensWidth(40)
                        }}
                            onPress={onConfirmOwnModal}>
                            <ConfirmIcon />
                        </TouchableOpacity>
                        <TouchableOpacity onPress={onCloseOwnModal}>
                            <CloseXIcon />
                        </TouchableOpacity>
                    </View>
                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        marginBottom: dimnensHeight(10),
                        backgroundColor: '#F6F8FA'
                    }} />
                    <ScrollView>
                        <Text style={styles.textType}>Ý kiến lãnh đạo</Text>

                        <TextInputCustom
                            placeholder="Vui lòng nhập ý kiến"
                            placeholderTextColor={colors.grey999}
                            multiline
                            onChangeText={(text) => onChangeYKienLanhDao(text)}
                            value={yKienLanhDao}
                            style={styles.commentInput}
                        />
                        <View>
                            <Text style={styles.titleBoss}>
                                Các Phòng/Ban nghiệp vụ Công ty
                            </Text>
                            <View style={styles.chooseTypeView}>
                                <Text style={styles.textChooseType}>
                                    {"Vui lòng bấm vào nút để chọn phòng/ban"}
                                </Text>
                                <TouchableOpacity
                                    style={styles.buttonPhongBan}
                                    onPress={onChooseAssigmentUser}
                                >
                                    <UserPlusIcon />
                                    <Text style={styles.textPhongBan} numberOfLines={1}>
                                        Phòng/ban
                                    </Text>
                                </TouchableOpacity>
                            </View>
                            {!arrayIsEmpty(dataAfterAssigmentUser) && (
                                <View style={styles.flatlist}>
                                    <SwipeListView
                                        extraData={filteredDataPhongBan}
                                        data={filteredDataPhongBan}
                                        // renderItem={({ item, index }) =>
                                        //     ItemPhongBan({ item, index })
                                        // }
                                        // renderHiddenItem={(data, rowMap) => {
                                        //     return (
                                        //         <View style={styles.rowRightHidden}>
                                        //                 {
                                        //                     !data?.item?.DueDate ?
                                        //                     <TouchableOpacity
                                        //                     style={styles.iconChange}
                                        //                         onPress={() => {
                                        //                             handleChooseDueDate(
                                        //                                 data?.item?.dummyID,
                                        //                                 data?.item?.DueDate,
                                        //                                 EnumPhancong.PhongBan
                                        //                             );
                                        //                         }}
                                        //                     >
                                        //                         <DueDateBlueIcon />
                                        //                     </TouchableOpacity>
                                        //                     :
                                        //                     <View />
                                        //                 }

                                        //             <TouchableOpacity
                                        //                 style={styles.iconDelete}
                                        //                 onPress={() => {
                                        //                     onConfirmDeletePhongBan(data?.item?.dummyID);
                                        //                 }}
                                        //             >
                                        //                 <DeleteRedIcon />
                                        //             </TouchableOpacity>
                                        //         </View>
                                        //     );
                                        // }}

                                        renderItem={(data, rowMap) => {
                                            const itemWidth = data?.item?.DueDate ? 50 : 100

                                            return (
                                                <SwipeRow
                                                    ref={(ref: any) => rowMap[data?.item?.dummyID] = ref}
                                                    key={data?.item?.dummyID}
                                                    rightOpenValue={-itemWidth}>
                                                    <View style={styles.rowRightHidden}>
                                                        {checkIsEmpty(data?.item?.DueDate)
                                                            &&
                                                            <TouchableOpacity
                                                                style={styles.iconChange}
                                                                onPress={async () => {
                                                                    handleChooseDueDate(
                                                                        data?.item?.dummyID,
                                                                        data?.item?.DueDate,
                                                                        EnumPhancong.PhongBan
                                                                    );
                                                                    rowMap[data?.item?.dummyID].closeRow()
                                                                }}
                                                            >
                                                                <DueDateBlueIcon />
                                                            </TouchableOpacity>
                                                        }
                                                        <TouchableOpacity
                                                            style={styles.iconDelete}
                                                            onPress={() => {
                                                                onConfirmDeletePhongBan(
                                                                    data?.item?.dummyID
                                                                );
                                                            }}
                                                        >
                                                            <DeleteRedIcon />
                                                        </TouchableOpacity>
                                                    </View>
                                                    <ItemPhongBan item={data?.item} index={data?.index} onPressSwipe={() => {
                                                        rowMap[data?.item?.dummyID].closeRow()
                                                    }} />
                                                </SwipeRow>
                                            )
                                        }}
                                        keyExtractor={(item, index) => item.dummyID}
                                        // rightOpenValue={-100}
                                        disableRightSwipe
                                    />
                                </View>
                            )}

                            <Text style={styles.titleBoss}>
                                Tổ chức phân công thực hiện
                            </Text>

                            <View style={styles.chooseTypeView}>
                                <Text style={styles.textChooseType}>
                                    {"Vui lòng bấm vào nút để chọn Chi nhánh trực thuộc"}
                                </Text>
                                <TouchableOpacity
                                    style={styles.buttonPhongBan}
                                    onPress={onChooseAssigmentDept}
                                >
                                    <MemberIcon />

                                    <Text style={styles.textPhongBan} numberOfLines={1}>
                                        Chi nhánh trực thuộc
                                    </Text>
                                </TouchableOpacity>
                            </View>
                            {!arrayIsEmpty(filteredDanhSachTochucPhanCong) && (
                                <View style={styles.flatlist}>
                                    <SwipeListView
                                        extraData={filteredDanhSachTochucPhanCong}
                                        data={filteredDanhSachTochucPhanCong}
                                        // renderItem={({ item, index }) =>
                                        //     ItemToChucPhanCong({ item, index })
                                        // }
                                        // renderHiddenItem={(data, rowMap) => {
                                        //     return (
                                        //         <View style={styles.rowRightHidden}>
                                        //             <TouchableOpacity
                                        //                 style={styles.iconChange}
                                        //                 onPress={() => {
                                        //                     handleChooseDueDate(
                                        //                         data?.item?.dummyID,
                                        //                         data?.item?.DueDate,
                                        //                         EnumPhancong.ToChucPhanCong
                                        //                     );
                                        //                 }}
                                        //             >
                                        //                 <DueDateBlueIcon />
                                        //             </TouchableOpacity>
                                        //             <TouchableOpacity
                                        //                 style={styles.iconDelete}
                                        //                 onPress={() => {
                                        //                     onConfirmDeleteDSToChucPhanCong(
                                        //                         data?.item?.dummyID
                                        //                     );
                                        //                 }}
                                        //             >
                                        //                 <DeleteRedIcon />
                                        //             </TouchableOpacity>
                                        //         </View>
                                        //     );
                                        // }}
                                        renderItem={(data, rowMap) => {
                                            const itemWidth = data?.item?.DueDate ? 50 : 100
                                            return (
                                                <SwipeRow
                                                    ref={(ref: any) => rowMap[data?.item?.dummyID] = ref}
                                                    key={data?.item?.dummyID}
                                                    rightOpenValue={-itemWidth}>
                                                    <View style={styles.rowRightHidden}>
                                                        {checkIsEmpty(data?.item?.DueDate) && <TouchableOpacity
                                                            style={styles.iconChange}
                                                            onPress={() => {
                                                                handleChooseDueDate(
                                                                    data?.item?.dummyID,
                                                                    data?.item?.DueDate,
                                                                    EnumPhancong.ToChucPhanCong
                                                                );
                                                                rowMap[data?.item?.dummyID].closeRow()
                                                            }}
                                                        >
                                                            <DueDateBlueIcon />
                                                        </TouchableOpacity>}
                                                        <TouchableOpacity
                                                            style={styles.iconDelete}
                                                            onPress={() => {
                                                                onConfirmDeleteDSToChucPhanCong(
                                                                    data?.item?.dummyID
                                                                );
                                                            }}
                                                        >
                                                            <DeleteRedIcon />
                                                        </TouchableOpacity>
                                                    </View>
                                                    <ItemToChucPhanCong item={data?.item} index={data?.index} onPressSwipe={() => {
                                                        rowMap[data?.item?.dummyID].closeRow()
                                                    }} />
                                                </SwipeRow>
                                            )
                                        }}
                                        keyExtractor={(item, index) => item?.dummyID}
                                        rightOpenValue={-100}
                                        disableRightSwipe
                                    />
                                </View>
                            )}
                        </View>
                    </ScrollView>
                </View>
            </KeyboardAvoidingView>

            <AssignmentUserModal
                modalVisible={modalAssignmentUser}
                onCloseModal={onCloseAssigmentUserModal}
                onConfirmModal={(data) => onConfirmAssigmentUserModal(data)}
                ItemId={ItemId}
                BanLanhDao={BanLanhDao}
            />

            <AssignmentDeptModal
                modalVisible={modalAssignmentDept}
                onCloseModal={onCloseAssignmentDeptModal}
                onConfirmModal={(data) => onConfirmAssigmentDeptModal(data)}
                ItemId={ItemId}
            />

            <CalendarPickerPhanCongModal
                modalCalendarVisible={isOpenCalendarPhanCongPicker}
                onDateChangeModal={onDueDateDateChangeModal}
                onCloseModal={onCloseCalendarPickerPhanCongModal}
                resetToday={resetToday}
                DueDate={DueDateParams}
            />
        </ModalCusTom>
    )
}

const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(0,0,0,0.4)"
    },
    modalView: {
        height: dimnensHeight(640),
        width: dimensWidth(750),
        backgroundColor: 'white',
        borderRadius: 20,
        overflow: 'hidden'
    },
    chooseTypeView: {
        height: 100,
        borderWidth: 1,
        borderColor: "#005FD4",
        marginBottom: dimensWidth(15),
        borderRadius: 8,
        justifyContent: "center",
        alignItems: "center",
        marginHorizontal: dimensWidth(20),
        marginTop: dimensWidth(10),
    },
    flexDirection: {
        flexDirection: "row",
        paddingHorizontal: dimensWidth(20),
        alignItems: "center",
    },
    stroke: {
        borderWidth: 0.5,
        borderColor: "#999999",
    },
    textType: {
        fontSize: FontSize.SMALL,
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: dimensWidth(20),
        marginVertical: 10,
    },
    tabBarLabelActive: {
        color: colors.white,
        fontWeight: "400",
        fontSize: FontSize.MEDIUM,
    },
    textPhongBan: {
        color: colors.white,
        fontWeight: "400",
        fontSize: FontSize.MEDIUM,
        marginLeft: dimensWidth(5),
    },
    viewTabBottomBar: {
        flexDirection: "row",
        borderRadius: 8,
        justifyContent: "flex-end",
        marginBottom: 30,
    },
    buttonTransfer: {
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: colors.blueMedium,
        width: dimensWidth(130),
        height: dimensWidth(34),
        borderRadius: 4,
        marginEnd: dimensWidth(20),
    },
    buttonPhongBan: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: colors.blueMedium,
        height: 34,
        borderRadius: 4,
        marginTop: 10,
        paddingHorizontal: 20,
    },
    buttonExit: {
        alignItems: "center",
        justifyContent: "center",
        width: dimensWidth(130),
        height: dimensWidth(34),
        borderRadius: 4,
    },
    buttonExitText: {
        color: colors.red,
        fontWeight: "400",
        fontSize: FontSize.MEDIUM,
    },
    textAssign: {
        color: colors.blueMedium,
        fontWeight: "700",
        fontSize: FontSize.LARGE,
    },
    viewAssign: {
        backgroundColor: colors.lightBlue,
        padding: 15,
    },
    titleBoss: {
        fontSize: FontSize.LARGE,
        color: colors.black,
        fontWeight: "700",
        fontFamily: "arial",
        marginHorizontal: dimensWidth(20),
    },
    commentInput: {
        paddingHorizontal: 10,
        borderColor: colors.greyDDD,
        borderRadius: 3,
        height: dimensWidth(100),
        borderWidth: 1,
        marginHorizontal: dimensWidth(20),
        marginBottom: dimnensHeight(30),
        textAlignVertical: "top",
    },
    typeChild: {
        paddingHorizontal: 16,
        flexDirection: "row",
        alignItems: "center",
        marginHorizontal: 15,
        justifyContent: "space-between",
    },
    textFiltedType: {
        fontSize: FontSize.MEDIUM,
        color: colors.black,
        fontWeight: "400",
        fontFamily: "arial",
        marginRight: 9,
    },
    textChooseType: {
        fontSize: FontSize.MEDIUM,
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginRight: 9,
        marginHorizontal: 10,
    },
    title: {
        fontSize: FontSize.MEDIUM,
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
    },
    blueText: {
        fontSize: dimensWidth(13),
        color: colors.scienceBlue,
        fontWeight: "400",
        fontFamily: "arial",
    },
    itemPhongBan: {
        height: dimensWidth(70),
    },
    itemPhongBanChild: {
        backgroundColor: colors.white,
        height: dimensWidth(70),
        padding: 15,
    },
    flexDirectionRowBetween: {
        flexDirection: "row",
        justifyContent: "space-between",
        paddingBottom: 8,
    },
    rowRightHidden: {
        // width: 100,
        height: 100,
        alignSelf: "flex-end",
        flexDirection: "row",
    },
    iconChange: {
        // flex: 1,
        width: 50,
        height: dimensWidth(70),
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#9DD5FF",
    },
    iconDelete: {
        // flex: 1,
        width: 50,
        height: dimensWidth(70),
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#FFD7D7",
    },
    flatlist: {
        borderColor: colors.greyDDD,
        borderWidth: 1,
        borderRadius: 8,
        marginHorizontal: dimensWidth(20),
        overflow: "hidden",
        maxHeight: 250,
        marginBottom: 20,
    }
});

export default AssignmentModal