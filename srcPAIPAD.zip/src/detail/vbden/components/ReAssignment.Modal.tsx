import React, { FC, useState, useCallback, useMemo, useEffect } from "react";
import {
    Modal,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    KeyboardAvoidingView,
    ScrollView,
    Animated,
    Alert
} from "react-native";
import colors from "~/base/Colors";
import { FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";
import { arrayIsEmpty, checkIsEmpty, format_dd_mm_yy, removeSpecialCharacters } from "~/base/Functions";
import { CloseXIcon, ConfirmIcon, DeleteRedIcon, DueDateBlueIcon, MemberIcon, UserPlusIcon } from "~/base/assets/svg";
import { TextInputCustom } from "~/base/components";
import AssignmentUserModal from "./AssigmentUser.Modal";
import { SwipeListView } from "react-native-swipe-list-view";
import { EnumPhancong } from "../VBDen.Enum";
import CalendarPickerPhanCongModal from "./CalendarPicker.Assigment.Modal";
import {  submitActionReAssignment } from "~/base/stories/vbden/reducer";
import { useDispatch, useSelector } from "react-redux";
import { ThunkDispatch } from "@reduxjs/toolkit";
import ModalCusTom from "~/base/components/ModalCusTom";
interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    Comment: string;
    ItemId: any,
    BanLanhDao: any,
    TaskJson: any
}

const ReAssignmentModal: FC<Props> = ({
    modalVisible,
    onCloseModal,
    Comment,
    ItemId,
    BanLanhDao,
    TaskJson,
    ...props
}: Props) => {
    const ItemPhongBan = ({ item, index }) => {
        const { Title, DepartmentTitle, DueDate, Created, isThucHien, DeThucHien } =
            item;
        console.log("DueDateDueDate", DueDate);

        const DueDateFormated = checkIsEmpty(DueDate)
            ? DueDate
            : format_dd_mm_yy(DueDate);
        const isOdd = index % 2 === 0;
        const PhanCongTitle = DepartmentTitle ? DepartmentTitle : Title;
        return (
            <Animated.View
                style={[
                    styles.itemPhongBanChild,
                    isOdd && { backgroundColor: colors.alice_blue },
                ]}
            >
                <View style={styles.flexDirectionRowBetween}>
                    <Text style={styles.title} numberOfLines={1}>
                        {PhanCongTitle}
                    </Text>
                    <Text style={styles.blueText} numberOfLines={1}>
                        {DueDateFormated}
                    </Text>
                </View>
                {DeThucHien === undefined && (
                    <Text style={styles.blueText} numberOfLines={1}>
                        {isThucHien ? "Thực Hiện" : "Phối Hợp"}
                    </Text>
                )}

                {isThucHien === undefined && (
                    <Text style={styles.blueText} numberOfLines={1}>
                        {DeThucHien ? "Thực Hiện" : "Phối Hợp"}
                    </Text>
                )}
            </Animated.View>
        );
    };

    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { subSite } = useSelector((state: any) => state.login);
    const [yKienLanhDao, setYKienLanhDao] = useState("")
    const [dataPhongBanState, setDataPhongBanState] = useState([])
    const [modalAssignmentUser, setModalAssignmentUser] = useState(false)
    const [taskJsonDetail, setTaskJsonDetail] = useState([])
    const [deleteDeptList, setDeleteDeptList] = useState("");
    const [isOpenCalendarPhanCongPicker, setIsOpenCalendarPhanCongPicker] =
        useState(false);
    const [sellectedItemId, setSellectedItemId] = useState<number>(-1);
    const [DueDateParams, setDueDateDateParams] = useState<string>("");
    const [typePhanCong, setTypePhanCong] = useState<EnumPhancong | null>(null);

    const onCloseOwnModal = useCallback(() => {
        setYKienLanhDao("")
        setDataPhongBanState([])
        setTaskJsonDetail([])
        setDeleteDeptList("")
        setSellectedItemId(-1)
        setDueDateDateParams("")
        onCloseModal()
    }, [])

    const onChangeYKienLanhDao = useCallback(
        (input: string) => {
            setYKienLanhDao(input);
        },
        [yKienLanhDao]
    );

    const onChoosePhongBan = useCallback(() => {
        setModalAssignmentUser(true)
    }, [modalAssignmentUser])

    const onCloseAssigmentUserModal = useCallback(() => {
        setModalAssignmentUser(false)
    }, [modalAssignmentUser])

    const onConfirmAssigmentUserModal = useCallback((data) => {
        setDataPhongBanState(data)
        setModalAssignmentUser(false)
    }, [dataPhongBanState])

    const findItemsWithPhongBan = (data) => {
        const result = [];

        const traverseData = (data) => {
            data.forEach((item) => {
                if (item.isThucHien || item.isPhoiHop) {
                    result.push(item);
                }

                if (item.children && item.children.length > 0) {
                    traverseData(item.children); // Đệ quy duyệt qua các phần tử con
                }
            });
        };

        traverseData(data); // Bắt đầu duyệt từ mảng data

        return result;
    };

    const filteredDataPhongBan = useMemo(() => {
        let filteredData: any[] = [];
        if (!arrayIsEmpty(dataPhongBanState)) {
            filteredData = findItemsWithPhongBan(dataPhongBanState);
            return filteredData;
        }
        return filteredData;
    }, [dataPhongBanState]);

    const onConfirmDeleteTaskJsonDetail = useCallback((ID: any) => {
        Alert.alert("Thông báo", "Bạn thực sự muốn xóa?", [
            {
                text: "Cancel",
                onPress: () => console.log("Cancel Pressed"),
                style: "cancel",
            },
            { text: "OK", onPress: () => handleToggleDeleteTaskJsonDetail(ID) },
        ]);
    }, []);

    const onConfirmDeletePhongBan = useCallback((dummyID: any) => {
        Alert.alert("Thông báo", "Bạn thực sự muốn xóa?", [
            {
                text: "Cancel",
                onPress: () => console.log("Cancel Pressed"),
                style: "cancel",
            },
            { text: "OK", onPress: () => handleToggleDeletePhongban(dummyID) },
        ]);
    }, []);

    const handleToggleDeletePhongban = useCallback(
        (itemId: any) => {
            setDataPhongBanState((prevData: any) => {
                const newData = [...prevData];

                const findItemAndTogglePhoiHop = (items: any) => {
                    for (let i = 0; i < items.length; i++) {
                        const item = items[i];

                        if (item.dummyID === itemId) {
                            item.isPhoiHop = false;
                            item.isThucHien = false;
                            return;
                        }

                        if (item.children && item.children.length > 0) {
                            findItemAndTogglePhoiHop(item.children);
                        }
                    }
                };
                findItemAndTogglePhoiHop(newData);

                return newData;
            });
        },
        [dataPhongBanState]
    );

    const handleToggleDeleteTaskJsonDetail = useCallback(
        (itemId: any) => {
            setTaskJsonDetail((prevData: any) => {
                const newData = prevData.filter((it) => it.dummyID !== itemId);
                return newData;
            });


            setDeleteDeptList((prevData: any) => {
                const newString = prevData + itemId + "|";

                return newString;
            });
        },
        [taskJsonDetail, deleteDeptList]
    );

    const onCloseCalendarPickerPhanCongModal = useCallback(() => {
        setIsOpenCalendarPhanCongPicker(false);
    }, []);

    const onDueDateDateChangeModal = useCallback((date: string, typePhanCong: EnumPhancong) => {
        setIsOpenCalendarPhanCongPicker(false);
        setDataPhongBanState((prevData: any) => {
            const newData = [...prevData];
            const findItemAndToggleDueDate = (items: any) => {
                for (let i = 0; i < items.length; i++) {
                    const item = items[i];

                    if (item.dummyID === sellectedItemId) {
                        item.DueDate = date;
                        return;
                    }
                    if (item.children && item.children.length > 0) {
                        findItemAndToggleDueDate(item.children);
                    }
                }
            };
            findItemAndToggleDueDate(newData);

            return newData;
        });
    },
        [sellectedItemId, dataPhongBanState]
    );

    const handleChooseDueDate = useCallback(
        (itemId: number, DueDate: string, typePhanCong: EnumPhancong) => {
            setIsOpenCalendarPhanCongPicker(true);
            setTypePhanCong(typePhanCong);
            setDueDateDateParams(DueDate);
            setSellectedItemId(itemId);
        },
        [typePhanCong, DueDateParams, sellectedItemId]
    );

    const resetToday = useCallback((today: any) => { }, []);

    const onConfirm = useCallback(() => {
        let AssignmentUser = "";
        if (arrayIsEmpty(filteredDataPhongBan)) {
            Alert.alert("Thông báo", "Vui lòng chọn phòng ban!", [
                { text: "OK", onPress: () => { } },
            ]);
            return;
        } else {
            const Comment = "";
            const traverseData = (filterData: any) => {
                filterData.forEach((item: any) => {
                    const DepartmentTitle = item.ID + ";#" + item.Title;
                    const assignmentType = item.isThucHien
                        ? "&&1&&0&&0&&"
                        : "&&0&&0&&1&&";
                    if (item.isUser) {
                        AssignmentUser +=
                            // AssignmentUser +
                            // plusString +
                            DepartmentTitle +
                            assignmentType +
                            item?.DueDate +
                            "&&" +
                            item.Manager +
                            "&&" +
                            Comment +
                            "@@";
                    } else {
                        AssignmentUser +=
                            // AssignmentUser +
                            // plusString +
                            item.Manager +
                            assignmentType +
                            item?.DueDate +
                            "&&" +
                            DepartmentTitle +
                            "&&" +
                            Comment +
                            "@@";
                    }
                });
            };
            traverseData(filteredDataPhongBan); // Bắt đầu duyệt từ mảng data
        }

        const payload = {
            SubSite: subSite,
            Comment: yKienLanhDao,
            deleteDept: deleteDeptList,
            BanLanhDao: "",
            AssignmentUser,
            ItemId,
        };
        dispatch(submitActionReAssignment(payload));
        onCloseOwnModal()
    }, [dataPhongBanState, yKienLanhDao, ItemId, deleteDeptList])

    useEffect(() => {
        if (!arrayIsEmpty(TaskJson)) {
            const tmp = TaskJson
                ? TaskJson.map(
                    (it) =>
                    (it = {
                        ...it,
                        dummyID: it?.ID,
                    })
                )
                : [];
            setTaskJsonDetail(tmp);
        }
    }, [TaskJson])

    return (
        <ModalCusTom
            transparent={true}
            visible={modalVisible}
            {...props}
            style={styles.centeredView}
            onCloseModalCustom={onCloseModal}
        >
            <KeyboardAvoidingView style={styles.centeredView}>
                <View style={styles.modalView}>
                    <View style={{
                        padding: dimensWidth(20),
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <Text style={{
                            flex: 1,
                            color: '#005FD4',
                            fontSize: FontSize.LARGE_X,
                            fontWeight: 700,
                        }}>Phân công lại</Text>
                        <TouchableOpacity style={{
                            marginRight: dimensWidth(40)
                        }}
                            onPress={onConfirm}
                        >
                            <ConfirmIcon />
                        </TouchableOpacity>
                        <TouchableOpacity onPress={onCloseOwnModal}>
                            <CloseXIcon />
                        </TouchableOpacity>
                    </View>
                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        marginBottom: dimnensHeight(10),
                        backgroundColor: '#F6F8FA'
                    }} />
                    <ScrollView>
                        <Text style={styles.textType}>Ý kiến lãnh đạo</Text>
                        <TextInputCustom
                            placeholder="Vui lòng nhập ý kiến"
                            placeholderTextColor={colors.grey999}
                            multiline
                            onChangeText={(text) => onChangeYKienLanhDao(text)}
                            value={yKienLanhDao}
                            style={styles.commentInput}
                        />

                        <View>
                            <Text style={styles.titleBoss}>
                                Các Phòng/Ban nghiệp vụ Công ty
                            </Text>
                            <View style={styles.chooseTypeView}>
                                <Text style={styles.textChooseType}>
                                    {"Vui lòng bấm vào nút để chọn phòng/ban"}
                                </Text>
                                <TouchableOpacity
                                    style={styles.buttonPhongBan}
                                    onPress={onChoosePhongBan}
                                >
                                    <UserPlusIcon />
                                    <Text style={styles.textPhongBan} numberOfLines={1}>
                                        Phòng/ban
                                    </Text>
                                </TouchableOpacity>
                            </View>
                            {(!arrayIsEmpty(filteredDataPhongBan) ||
                                !arrayIsEmpty(TaskJson)) && (
                                    <View style={styles.flatlist}>
                                        <SwipeListView
                                            extraData={filteredDataPhongBan}
                                            data={filteredDataPhongBan}
                                            renderItem={({ item, index }) =>
                                                ItemPhongBan({ item, index })
                                            }
                                            renderHiddenItem={(data, rowMap) => {
                                                return (
                                                    <View style={styles.rowBack}>
                                                        <TouchableOpacity
                                                            style={styles.iconChange}
                                                            onPress={() => {
                                                                handleChooseDueDate(
                                                                    data?.item?.dummyID,
                                                                    data?.item?.DueDate,
                                                                    EnumPhancong.PhongBanPhanCongLai
                                                                );
                                                            }}
                                                        >
                                                            <DueDateBlueIcon />
                                                        </TouchableOpacity>
                                                        <TouchableOpacity
                                                            style={styles.iconDelete}
                                                            onPress={() =>
                                                                onConfirmDeletePhongBan(data?.item?.dummyID)
                                                            }
                                                        >
                                                            <DeleteRedIcon />
                                                        </TouchableOpacity>
                                                    </View>
                                                );
                                            }}
                                            keyExtractor={(item, index) => item.dummyID}
                                            rightOpenValue={-100}
                                            disableRightSwipe
                                        />
                                        <SwipeListView
                                            extraData={taskJsonDetail}
                                            data={taskJsonDetail}
                                            renderItem={({ item, index }) =>
                                                ItemPhongBan({ item, index })
                                            }
                                            renderHiddenItem={(data, rowMap) => {
                                                return (
                                                    <View style={styles.rowBackTaskDetail}>
                                                        <TouchableOpacity
                                                            style={styles.iconDeleteTaskDetail}
                                                            onPress={() => {
                                                                onConfirmDeleteTaskJsonDetail(data?.item?.dummyID);
                                                            }}
                                                        >
                                                            <DeleteRedIcon />
                                                        </TouchableOpacity>
                                                    </View>
                                                );
                                            }}
                                            keyExtractor={(item, index) => item.dummyID}
                                            rightOpenValue={-50}
                                            disableRightSwipe
                                        />
                                    </View>
                                )}
                        </View>
                    </ScrollView>
                </View>
            </KeyboardAvoidingView>

            <AssignmentUserModal
                modalVisible={modalAssignmentUser}
                onCloseModal={onCloseAssigmentUserModal}
                onConfirmModal={(data) => onConfirmAssigmentUserModal(data)}
                ItemId={ItemId}
                BanLanhDao={BanLanhDao}
            />

            <CalendarPickerPhanCongModal
                modalCalendarVisible={isOpenCalendarPhanCongPicker}
                onDateChangeModal={onDueDateDateChangeModal}
                onCloseModal={onCloseCalendarPickerPhanCongModal}
                resetToday={resetToday}
                DueDate={DueDateParams}
                typePhanCong={typePhanCong}
            />
        </ModalCusTom>
    )
}

const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(0,0,0,0.4)"
    },
    modalView: {
        height: dimnensHeight(640),
        width: dimensWidth(750),
        backgroundColor: 'white',
        borderRadius: 20,
        overflow: 'hidden'
    },
    chooseTypeView: {
        height: 100,
        borderWidth: 1,
        borderColor: "#005FD4",
        borderStyle: "dashed",
        marginBottom: 15,
        borderRadius: 8,
        justifyContent: "center",
        alignItems: "center",
        marginHorizontal: dimensWidth(20),
        marginTop: 10,
    },
    flexDirection: {
        flexDirection: "row",
        paddingHorizontal: dimensWidth(20),
        alignItems: "center",
    },
    stroke: {
        borderWidth: 0.5,
        borderColor: "#999999",
        borderStyle: "dashed",
    },
    textType: {
        fontSize: FontSize.SMALL,
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: dimensWidth(20),
        marginVertical: 10,
    },
    tabBarLabelActive: {
        color: colors.white,
        fontWeight: "400",
        fontSize: FontSize.MEDIUM,
    },
    textPhongBan: {
        color: colors.white,
        fontWeight: "400",
        fontSize: FontSize.MEDIUM,
        marginLeft: 5,
    },
    viewTabBottomBar: {
        flexDirection: "row",
        // height: dimensWidth(66),
        borderRadius: 8,
        justifyContent: "flex-end",
        marginBottom: 30,
    },
    buttonTransfer: {
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: colors.blueMedium,
        width: dimensWidth(130),
        height: dimensWidth(34),
        borderRadius: 4,
        marginEnd: 15,
    },
    buttonPhongBan: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: colors.blueMedium,
        height: 34,
        borderRadius: 4,
        marginTop: 10,
        paddingHorizontal: dimensWidth(20),
    },
    buttonExit: {
        alignItems: "center",
        justifyContent: "center",
        width: dimensWidth(130),
        height: dimensWidth(34),
        borderRadius: 4,
    },
    buttonExitText: {
        color: colors.red,
        fontWeight: "400",
        fontSize: FontSize.MEDIUM,
    },
    textAssign: {
        color: colors.blueMedium,
        fontWeight: "700",
        fontSize: FontSize.LARGE,
    },
    viewAssign: {
        backgroundColor: colors.lightBlue,
        padding: 15,
    },
    titleBoss: {
        fontSize: FontSize.LARGE,
        color: colors.black,
        fontWeight: "700",
        fontFamily: "arial",
        marginHorizontal: dimensWidth(20),
    },
    commentInput: {
        paddingHorizontal: 10,
        borderColor: colors.greyDDD,
        borderRadius: 3,
        height: dimensWidth(100),
        borderWidth: 1,
        marginHorizontal: dimensWidth(20),
        marginBottom: 10,
        textAlignVertical: "top",
    },
    typeChild: {
        paddingHorizontal: dimensWidth(20),
        flexDirection: "row",
        alignItems: "center",
        marginHorizontal: dimensWidth(20),
        justifyContent: "space-between",
    },
    textFiltedType: {
        fontSize: FontSize.MEDIUM,
        color: colors.black,
        fontWeight: "400",
        fontFamily: "arial",
        marginRight: 9,
    },
    textChooseType: {
        fontSize: FontSize.MEDIUM,
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginRight: 9,
        marginHorizontal: 10,
    },
    title: {
        fontSize: FontSize.MEDIUM,
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
    },
    blueText: {
        fontSize: dimensWidth(13),
        color: colors.scienceBlue,
        fontWeight: "400",
        fontFamily: "arial",
    },
    itemPhongBan: {
        height: dimensWidth(70),
    },
    itemPhongBanChild: {
        backgroundColor: colors.white,
        height: dimensWidth(70),
        padding: 15,
    },
    flexDirectionRowBetween: {
        flexDirection: "row",
        justifyContent: "space-between",
        paddingBottom: 8,
    },
    rowBack: {
        width: 100,
        height: 100,
        alignSelf: "flex-end",
        flexDirection: "row",
    },
    rowBackTaskDetail: {
        width: 50,
        height: dimensWidth(70),
        alignSelf: "flex-end",

    },
    iconChange: {
        flex: 1,
        height: dimensWidth(70),
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#9DD5FF",
    },
    iconDelete: {
        flex: 1,
        height: dimensWidth(70),
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#FFD7D7",
    },
    iconDeleteTaskDetail: {
        width: 50,
        height: dimensWidth(70),
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#FFD7D7",
    },
    flatlist: {
        borderColor: colors.greyDDD,
        borderWidth: 1,
        borderRadius: 8,
        marginHorizontal: dimensWidth(20),
        overflow: "hidden",
        marginBottom: 20,
    },
});

export default ReAssignmentModal