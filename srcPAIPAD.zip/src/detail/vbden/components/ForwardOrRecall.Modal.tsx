import React, { FC, useState, useCallback, useMemo, useEffect } from "react";
import {
    Modal,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    KeyboardAvoidingView,
    ScrollView,
    Animated,
    Alert
} from "react-native";
import colors from "~/base/Colors";
import { BASE_URL, FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";
import { arrayIsEmpty, checkIsEmpty, checkTrangThai, format_dd_mm_yy, isNullOrUndefined, removeSpecialCharacters } from "~/base/Functions";
import { CloseXIcon, ConfirmIcon, DeleteRedIcon, DueDateBlueIcon, MemberIcon, UserPlusIcon } from "~/base/assets/svg";
import { TextInputCustom } from "~/base/components";
import { SwipeListView } from "react-native-swipe-list-view";
import { EnumPhancong } from "../VBDen.Enum";
import CalendarPickerPhanCongModal from "./CalendarPicker.Assigment.Modal";
import { useDispatch, useSelector } from "react-redux";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { FlatList } from "react-native-gesture-handler";
import RecallAssignmentDeptModal from "./Recall.AssignmentDept.Modal";
import { submitActionForwallOrRecall } from "~/base/stories/vbden/reducer";
import FastImage from "react-native-fast-image";
import ModalCusTom from "~/base/components/ModalCusTom";
interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    Comment: string;
    ItemId: any,
    DonViXuLyJson: any,
    CommentJson: any
}

const ForwardOrRecallModal: FC<Props> = ({
    modalVisible,
    onCloseModal,
    Comment,
    ItemId,
    DonViXuLyJson,
    CommentJson,
    ...props
}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { subSite, token } = useSelector((state: any) => state.login);
    const [tabName, setTabName] = useState("Bổ sung");
    const [comment, setComment] = useState("");
    const [yKienThuHoi, setYKienThuHoi] = useState("");
    const [DonViXuLyJsonState, setDonViXuLyJsonState] = useState<any>([]);
    const [deleteDeptList, setDeleteDeptList] = useState("");
    const [danhsachToChucPhanCong, setDanhsachToChucPhanCong] = useState<any>([]);
    const [modalAssignmentDept, setModalAssigmentDept] = useState(false)
    const [isOpenCalendarPhanCongPicker, setIsOpenCalendarPhanCongPicker] = useState(false)
    const [DueDateParams, setDueDateDateParams] = useState<string>("");
    const [sellectedItemId, setSellectedItemId] = useState<number>(-1);

    const onCloseOwnModal = useCallback(() => {
        setDanhsachToChucPhanCong([])
        setDueDateDateParams("")
        setSellectedItemId(-1)
        setDeleteDeptList("")
        setYKienThuHoi("")
        setComment("")
        setTabName("Bổ sung")
        onCloseModal()
    }, [])

    const onChangeComment = useCallback((text: string) => {
        setComment(text);
    }, []);
    const onChangeYKienThuHoi = useCallback((text: string) => {
        setYKienThuHoi(text);
    }, []);
    const onPressProcessedDocx = useCallback(() => {
        setTabName("Thu hồi");
    }, []);
    const onPressWaitProcesseDocx = useCallback(() => {
        setTabName("Bổ sung");
    }, []);

    const onCloseAssignmentDeptModal = useCallback(() => {
        setModalAssigmentDept(false)
    }, [modalAssignmentDept])

    const onConfirmAssignmentDeptModal = useCallback((data) => {
        setModalAssigmentDept(false)
        setDanhsachToChucPhanCong(data)
    }, [])

    useEffect(() => {
        if (!arrayIsEmpty(DonViXuLyJson)) {
            setDonViXuLyJsonState(DonViXuLyJson);
            setYKienThuHoi("");
            setComment("");
            setTabName("Bổ sung");
        }
    }, [DonViXuLyJson]);

    const ItemToChucPhanCong = ({ item, index }) => {
        const { Title, ParentDept, Created, DueDate } = item;
        const DueDateFormated = checkIsEmpty(DueDate)
            ? DueDate
            : format_dd_mm_yy(DueDate);
        let isOdd = index % 2 === 0;

        return (
            <Animated.View
                style={[
                    styles.itemPhongBanChild,
                    isOdd && { backgroundColor: colors.alice_blue },
                ]}
            >
                <View style={styles.flexDirectionRowBetween}>
                    <Text style={styles.title} numberOfLines={1}>
                        {Title}
                    </Text>
                    <Text style={styles.blueText} numberOfLines={1}>
                        {DueDateFormated}
                    </Text>
                </View>
                <Text style={styles.blueText} numberOfLines={1}>
                    {removeSpecialCharacters(ParentDept)}
                </Text>
            </Animated.View>
        );
    };

    const ItemVBDenDonVi = ({ item, index }: any) => {
        const { DepartmentName, TrangThai, DueDate } = item;
        const isOdd = index % 2 === 0;
        const customColor = checkTrangThai(TrangThai);
        return (
            <View
                style={[
                    styles.danhMucItemView,
                    isOdd && { backgroundColor: colors.alice_blue },
                ]}
            >
                <View
                    style={[styles.flexDirectionRowBetween, { alignItems: "flex-start" }]}
                >
                    <View style={styles.flexDirectionRow}>
                        <Text style={styles.textTrichYeu} numberOfLines={1}>
                            {DepartmentName}
                        </Text>

                        <View>
                            <Text
                                numberOfLines={1}
                            >
                                {format_dd_mm_yy(DueDate)}
                            </Text>
                            <View
                                style={[
                                    styles.viewTrangThai,
                                    { backgroundColor: customColor?.backgroundColor },
                                ]}
                            >
                                <Text
                                    style={[styles.textTrangThai, { color: customColor?.color }]}
                                    numberOfLines={1}
                                >
                                    {TrangThai}
                                </Text>
                            </View>
                        </View>
                    </View>
                </View>
            </View>
        );
    };

    const ItemComment = ({ item, index, token, subSite }: any) => {
        const { Title, Value, ImagePath, Position, Created } = item;
        const createdFormated = format_dd_mm_yy(Created);
        const isOdd = index % 2 === 0;
        const pos = !isNullOrUndefined(Position) ? Position.split(";#")[1] : "";
        return (
            <View
                style={{
                    backgroundColor: isOdd ? colors.alice_blue : colors.white,
                    padding: 15,
                    flexDirection: 'row'
                }}>
                <FastImage
                    style={{
                        height: dimensWidth(40),
                        width: dimensWidth(40),
                        marginRight: dimensWidth(10),
                        borderRadius: dimensWidth(20),
                    }}
                    source={{
                        uri: `${BASE_URL}/${subSite}/${ImagePath}`,
                        headers: { Authorization: `${token}` },
                        priority: FastImage.priority.normal,
                    }}
                    defaultSource={require("base/assets/images/avatar80.png")}
                    resizeMode={FastImage.resizeMode.contain}
                />
                <View style={{
                    flex: 1
                }}>
                    <Text style={styles.titleCommentJson}>{Title}</Text>
                    <Text style={styles.positionComment}>{pos}</Text>

                    <Text style={{
                        marginTop: dimnensHeight(10),
                        fontSize: FontSize.MEDIUM,
                        color: colors.textBlack19,
                        fontWeight: "400",
                        fontFamily: "arial",
                        borderRadius: 4,
                    }}>{Value}</Text>
                </View>
                <Text style={styles.titleCommentJson}>{createdFormated}</Text>
            </View>
        );
    }

    const filteredDanhSachTochucPhanCong = useMemo(() => {
        if (!arrayIsEmpty(danhsachToChucPhanCong)) {
            const filteredData = danhsachToChucPhanCong.filter(
                (it) => it.isSellectedToChucPhanCong
            );
            return filteredData;
        }
    }, [danhsachToChucPhanCong]);

    const onChooseToChucPhanCong = useCallback(() => {
        setModalAssigmentDept(true)
    }, [])

    const handleDeleteDonVi = useCallback(
        (selectedItem: any) => {
            setDonViXuLyJsonState((prevData: any) => {
                const newState = prevData.filter(
                    (it) => it?.DepartmentId !== selectedItem?.DepartmentId
                );
                return newState;
            });
            setDeleteDeptList((prevData: any) => {
                const newString =
                    prevData +
                    selectedItem?.ID +
                    ";#" +
                    selectedItem?.DepartmentId +
                    ";#" +
                    selectedItem?.DepartmentName +
                    ";#" +
                    selectedItem?.DepartmentUrl +
                    "|";
                return newString;
            });
        },
        [DonViXuLyJsonState, deleteDeptList]
    );

    const handleChooseDueDate = useCallback(
        (itemId: number, DueDate: string) => {
            setIsOpenCalendarPhanCongPicker(true);
            setDueDateDateParams(DueDate);
            setSellectedItemId(itemId);
        },
        [DueDateParams, sellectedItemId]
    );

    const onDueDateDateChangeModal = useCallback((date: string, typePhanCong: EnumPhancong) => {
        setIsOpenCalendarPhanCongPicker(false);
        setDanhsachToChucPhanCong((prevData: any) => {
            const newData = [...prevData];
            const findItemAndToggleDueDate = (items: any) => {
                for (let i = 0; i < items.length; i++) {
                    const item = items[i];

                    if (item.dummyID === sellectedItemId) {
                        item.DueDate = date;
                        return;
                    }
                    if (item.children && item.children.length > 0) {
                        findItemAndToggleDueDate(item.children);
                    }
                }
            };
            findItemAndToggleDueDate(newData);

            return newData;
        });
    },
        [sellectedItemId, danhsachToChucPhanCong]
    );

    const onCloseCalendarPickerPhanCongModal = useCallback(() => {
        setIsOpenCalendarPhanCongPicker(false);
    }, []);

    const resetToday = useCallback((today: any) => { }, []);

    const onConfirmDeleteDSDonVi = useCallback((selectedItem: any) => {
        Alert.alert("Thông báo", "Bạn thực sự muốn xóa?", [
            {
                text: "Cancel",
                onPress: () => console.log("Cancel Pressed"),
                style: "cancel",
            },
            { text: "OK", onPress: () => handleDeleteDonVi(selectedItem) },
        ]);
    }, []);

    const onConfirmDeleteToChucPhanCong = useCallback((ID: any) => {
        Alert.alert("Thông báo", "Bạn thực sự muốn xóa?", [
            {
                text: "Cancel",
                onPress: () => console.log("Cancel Pressed"),
                style: "cancel",
            },
            { text: "OK", onPress: () => handleToggleDeleteToChucPhanCong(ID) },
        ]);
    }, []);

    const handleToggleDeleteToChucPhanCong = (itemId: any) => {
        setDanhsachToChucPhanCong((prevData: any) => {
            const newData = prevData.map((it) =>
                it.ID == itemId ? { ...it, isSellectedToChucPhanCong: false } : it
            );
            return newData;
        });
    };

    const onConfirm = useCallback(() => {
        const IsBoSung = tabName === "Bổ sung";
        let AssignmentDept = "";
        if (IsBoSung && arrayIsEmpty(filteredDanhSachTochucPhanCong)) {
            Alert.alert("Thông báo", "Vui lòng chọn Chi nhánh trực thuộc!", [
                { text: "OK", onPress: () => { } },
            ]);
            return;
        } else if (!IsBoSung && checkIsEmpty(deleteDeptList)) {
            Alert.alert("Thông báo", "Vui lòng chọn đơn vị bạn muốn thu hồi!", [
                { text: "Đóng" },
            ]);
            return;
        } else {
            if (IsBoSung) {
                const traverseData = (filterData: any) => {
                    filterData.forEach((item: any) => {
                        const DepartmentTitle = item?.ID + ";#" + item?.Title;

                        AssignmentDept +=
                            DepartmentTitle + "&&" + item?.URL + "&&" + item?.DueDate + "@@";
                    });
                };
                traverseData(filteredDanhSachTochucPhanCong);
            }
            const payload = {
                SubSite: subSite,
                Comment: yKienThuHoi,
                DeleteDept: deleteDeptList,
                AssignmentDept,
                ItemId,
                IsBoSung,
            };
            dispatch(submitActionForwallOrRecall(payload))
            onCloseOwnModal()
        }
    }, [filteredDanhSachTochucPhanCong, danhsachToChucPhanCong, tabName, deleteDeptList])

    return (
        <ModalCusTom
            transparent={true}
            visible={modalVisible}
            {...props}
            style={styles.centeredView}
            onCloseModalCustom={onCloseModal}
        >
            <KeyboardAvoidingView style={styles.centeredView}>
                <View style={styles.modalView}>
                    <View style={{
                        padding: dimensWidth(20),
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <Text style={{
                            flex: 1,
                            color: '#005FD4',
                            fontSize: FontSize.LARGE_X,
                            fontWeight: 700,
                        }}>Bổ sung / Thu hồi</Text>
                        <TouchableOpacity style={{
                            marginRight: dimensWidth(40)
                        }}
                            onPress={onConfirm}
                        >
                            <ConfirmIcon />
                        </TouchableOpacity>
                        <TouchableOpacity onPress={onCloseOwnModal}>
                            <CloseXIcon />
                        </TouchableOpacity>
                    </View>
                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        backgroundColor: '#F6F8FA'
                    }} />

                    <View style={styles.flexDirectionRowTab}>
                        <TouchableOpacity
                            activeOpacity={1}
                            onPress={onPressWaitProcesseDocx}
                            style={
                                tabName === "Bổ sung"
                                    ? styles.onPressActiveTab
                                    : styles.onPressInActiveTab
                            }
                        >
                            <Text
                                style={
                                    tabName === "Bổ sung"
                                        ? styles.titleActiveTab
                                        : styles.titleInActiveTab
                                }
                            >
                                Bổ sung
                            </Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            activeOpacity={1}
                            onPress={onPressProcessedDocx}
                            style={
                                tabName === "Thu hồi"
                                    ? styles.onPressActiveTab
                                    : styles.onPressInActiveTab
                            }
                        >
                            <Text
                                style={
                                    tabName === "Thu hồi"
                                        ? styles.titleActiveTab
                                        : styles.titleInActiveTab
                                }
                            >
                                Thu hồi
                            </Text>
                        </TouchableOpacity>
                    </View>
                    <ScrollView>
                        <Text style={styles.textType}>Ý kiến lãnh đạo</Text>
                        <TextInputCustom
                            placeholder="Vui lòng nhập ý kiến"
                            placeholderTextColor={colors.grey999}
                            multiline
                            onChangeText={(text) =>
                                tabName === "Bổ sung"
                                    ? onChangeComment(text)
                                    : onChangeYKienThuHoi(text)
                            }
                            value={tabName === "Bổ sung" ? comment : yKienThuHoi}
                            style={styles.commentInput}
                        />
                        {!arrayIsEmpty(CommentJson) && (
                            <FlatList
                                scrollEnabled={false}
                                nestedScrollEnabled={false}
                                style={styles.commentJsonFlatlist}
                                extraData={CommentJson}
                                keyExtractor={(item, index) => index.toString()}
                                data={CommentJson}
                                renderItem={({ item, index }) => (
                                    <ItemComment item={item} index={index} token={token} subSite={subSite} />
                                )}
                            />
                        )}
                        {tabName === "Bổ sung" ? (
                            <>
                                <Text style={styles.titleBoss}>
                                    Tổ chức phân công thực hiện
                                </Text>
                                <View style={styles.chooseTypeView}>
                                    <Text style={styles.textChooseType}>
                                        {"Vui lòng bấm vào nút để chọn Chi nhánh trực thuộc"}
                                    </Text>
                                    <TouchableOpacity
                                        style={styles.buttonPhongBan}
                                        onPress={onChooseToChucPhanCong}
                                    >
                                        <MemberIcon />
                                        <Text style={styles.textPhongBan} numberOfLines={1}>
                                            Chi nhánh trực thuộc
                                        </Text>
                                    </TouchableOpacity>
                                </View>
                                {!arrayIsEmpty(filteredDanhSachTochucPhanCong) && (
                                    <View style={[styles.flatlist]}>
                                        <SwipeListView
                                            extraData={filteredDanhSachTochucPhanCong}
                                            data={filteredDanhSachTochucPhanCong}
                                            renderItem={({ item, index }) =>
                                                ItemToChucPhanCong({ item, index })
                                            }
                                            renderHiddenItem={(data, rowMap) => {
                                                return (
                                                    <View style={styles.rowBack}>
                                                        <TouchableOpacity
                                                            style={styles.iconChange}
                                                            onPress={() => {
                                                                handleChooseDueDate(
                                                                    data?.item?.dummyID,
                                                                    data?.item?.DueDate
                                                                );
                                                            }}
                                                        >
                                                            <DueDateBlueIcon />
                                                        </TouchableOpacity>
                                                        <TouchableOpacity
                                                            style={styles.iconDelete}
                                                            onPress={() =>
                                                                onConfirmDeleteToChucPhanCong(data?.item?.dummyID)
                                                            }
                                                        >
                                                            <DeleteRedIcon />
                                                        </TouchableOpacity>
                                                    </View>
                                                );
                                            }}
                                            keyExtractor={(item, index) => item.ID}
                                            rightOpenValue={-100}
                                            disableRightSwipe
                                        />
                                    </View>
                                )}
                            </>
                        ) : (
                            <>
                                {!arrayIsEmpty(DonViXuLyJsonState) && (
                                    <Text style={styles.titleBoss}>
                                        Công ty, các đơn vị thành viên
                                    </Text>
                                )}
                                {!arrayIsEmpty(DonViXuLyJsonState) && (
                                    <View style={[styles.flatlist, { marginTop: 20 }]}>
                                        <SwipeListView
                                            extraData={DonViXuLyJsonState}
                                            data={DonViXuLyJsonState}
                                            renderItem={({ item, index }) =>
                                                ItemVBDenDonVi({ item, index })
                                            }
                                            renderHiddenItem={(data, rowMap) => {
                                                if (tabName === "Bổ sung") return null;
                                                return (
                                                    <View style={styles.rowBackDonVi}>
                                                        <TouchableOpacity
                                                            style={styles.iconDeleteDonVi}
                                                            onPress={() => onConfirmDeleteDSDonVi(data?.item)}
                                                        >
                                                            <DeleteRedIcon />
                                                        </TouchableOpacity>
                                                    </View>
                                                );
                                            }}
                                            keyExtractor={(item, index) => item?.DepartmentId}
                                            rightOpenValue={-dimensWidth(45)}
                                            disableRightSwipe
                                        />
                                    </View>
                                )}
                            </>
                        )}
                    </ScrollView>
                </View>
            </KeyboardAvoidingView>

            <RecallAssignmentDeptModal
                modalVisible={modalAssignmentDept}
                onCloseModal={onCloseAssignmentDeptModal}
                ItemId={ItemId}
                onConfirmModal={(data) => onConfirmAssignmentDeptModal(data)}
                distinctValue={DonViXuLyJson}
            />

            <CalendarPickerPhanCongModal
                modalCalendarVisible={isOpenCalendarPhanCongPicker}
                onDateChangeModal={onDueDateDateChangeModal}
                onCloseModal={onCloseCalendarPickerPhanCongModal}
                resetToday={resetToday}
                DueDate={DueDateParams}
                typePhanCong={EnumPhancong.BoSungThuHoi}
            />
        </ModalCusTom>
    )
}

const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(0,0,0,0.4)"
    },
    modalView: {
        height: dimnensHeight(640),
        width: dimensWidth(750),
        backgroundColor: 'white',
        borderRadius: 20,
        overflow: 'hidden'
    }
    ,
    chooseTypeView: {
        height: 100,
        borderWidth: 1,
        borderColor: "#005FD4",
        borderStyle: "dashed",
        marginBottom: 15,
        borderRadius: 8,
        justifyContent: "center",
        alignItems: "center",
        marginHorizontal: dimensWidth(20),
        marginTop: 10,
    },
    flexDirection: {
        // height: 67,
        flexDirection: "row",
        paddingHorizontal: dimensWidth(20),
        alignItems: "center",
    },
    stroke: {
        borderWidth: 0.5,
        borderColor: "#999999",
        borderStyle: "dashed",
    },
    textType: {
        fontSize: FontSize.SMALL,
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: dimensWidth(20),
        marginVertical: 10,
        marginTop: dimnensHeight(20)
    },
    tabBarLabelActive: {
        color: colors.white,
        fontWeight: "400",
        fontSize: FontSize.MEDIUM,
    },
    textPhongBan: {
        color: colors.white,
        fontWeight: "400",
        fontSize: FontSize.MEDIUM,
        marginLeft: 5,
    },
    viewTabBottomBar: {
        flexDirection: "row",
        // height: dimensWidth(66),
        borderRadius: 8,
        justifyContent: "flex-end",
    },
    buttonTransfer: {
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: colors.blueMedium,
        width: dimensWidth(130),
        height: dimensWidth(34),
        borderRadius: 4,
        marginEnd: 15,
    },
    buttonPhongBan: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: colors.blueMedium,
        height: 34,
        borderRadius: 4,
        marginTop: 10,
        paddingHorizontal: dimensWidth(20),
    },
    buttonExit: {
        alignItems: "center",
        justifyContent: "center",
        width: dimensWidth(130),
        height: dimensWidth(34),
        borderRadius: 4,
    },
    buttonExitText: {
        color: colors.red,
        fontWeight: "400",
        fontSize: FontSize.MEDIUM,
    },
    textAssign: {
        color: colors.blueMedium,
        fontWeight: "700",
        fontSize: FontSize.LARGE,
    },
    viewAssign: {
        backgroundColor: colors.lightBlue,
        padding: 15,
    },
    titleBoss: {
        fontSize: FontSize.LARGE,
        color: colors.black,
        fontWeight: "700",
        fontFamily: "arial",
        marginHorizontal: dimensWidth(20),
    },
    commentInput: {
        paddingHorizontal: 10,
        borderColor: colors.greyDDD,
        borderRadius: 3,
        height: dimensWidth(100),
        borderWidth: 1,
        marginHorizontal: dimensWidth(20),
        marginBottom: 10,
        textAlignVertical: "top",
    },
    typeChild: {
        paddingHorizontal: dimensWidth(20),
        flexDirection: "row",
        alignItems: "center",
        // height: 34,
        // borderColor: colors.greyDDD,
        // borderWidth: 1,
        // borderRadius: 3,
        marginHorizontal: dimensWidth(20),
        justifyContent: "space-between",
    },
    textFiltedType: {
        fontSize: FontSize.MEDIUM,
        color: colors.black,
        fontWeight: "400",
        fontFamily: "arial",
        marginRight: 9,
    },
    textChooseType: {
        fontSize: FontSize.MEDIUM,
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginRight: 9,
        marginHorizontal: 10,
    },
    onPressActiveTab: {
        flex: 1,
        paddingHorizontal: 12,
        borderBottomColor: colors.primary,
        borderBottomWidth: 3,
        borderRadius: 3,
        height: 50,
        justifyContent: "center",
    },
    onPressInActiveTab: {
        flex: 1,
        paddingVertical: 6,
        paddingHorizontal: 12,
        height: 50,
        justifyContent: "center",
    },
    titleActiveTab: {
        fontSize: FontSize.MEDIUM,
        color: colors.primary,
        fontWeight: "700",
        fontFamily: "arial",
        textAlign: "center",
    },
    titleInActiveTab: {
        fontSize: FontSize.MEDIUM,
        color: colors.grey999,
        fontWeight: "400",
        fontFamily: "arial",
        textAlign: "center",
    },
    flexDirectionRowTab: {
        height: 50,
        width: "100%",
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: colors.white,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
        opacity: 1,
    },
    flexDirectionRow: {
        flexDirection: "row",
        alignItems: "center",
    },
    titleNotifyCount: {
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.orange,
        fontWeight: "700",
        fontFamily: "arial",
    },
    flexDirectionRowBetween: {
        flexDirection: "row",
        justifyContent: "space-between",
        // alignItems: 'center'
        paddingBottom: 8,
    },
    rowBack: {
        width: 100,
        height: 100,
        alignSelf: "flex-end",
        flexDirection: "row",
    },
    rowBackTaskDetail: {
        width: dimensWidth(45),
        height: dimensWidth(70),
        alignSelf: "flex-end",
    },
    iconChange: {
        flex: 1,
        height: dimensWidth(70),
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#9DD5FF",
    },
    iconDelete: {
        flex: 1,
        height: dimensWidth(70),
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#FFD7D7",
    },
    iconDeleteDonVi: {
        flex: 1,
        height: dimensWidth(70),
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#FFD7D7",
    },
    rowBackDonVi: {
        width: dimensWidth(45),
        height: dimensWidth(70),
        alignSelf: "flex-end",
        flexDirection: "row",
    },
    flatlist: {
        borderColor: colors.greyDDD,
        borderWidth: 1,
        borderRadius: 8,
        marginHorizontal: dimensWidth(20),
        overflow: "hidden",
        marginBottom: 20,
        // paddingBottom: 20,
    },
    title: {
        fontSize: FontSize.MEDIUM,
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
    },
    blueText: {
        fontSize: dimensWidth(13),
        color: colors.scienceBlue,
        fontWeight: "400",
        fontFamily: "arial",
    },
    itemPhongBan: {
        height: dimensWidth(70),
    },
    itemPhongBanChild: {
        backgroundColor: colors.white,
        height: dimensWidth(70),
        padding: 15,
    },
    commentJsonFlatlist: {
        borderColor: colors.greyDDD,
        borderWidth: 1,
        borderRadius: 8,
        margin: dimensWidth(20),
        overflow: "hidden",
    },
    danhMucItemView: {
        backgroundColor: colors.white,
        padding: 15,
    },
    textTrichYeu: {
        flex: 1,
        fontSize: dimensWidth(16),
        color: colors.textBlack19,
        fontWeight: "400",
        fontFamily: "arial",
        marginRight: 10,
    },
    textTrangThai: {
        fontSize: dimensWidth(12),
        color: "#626262",
        fontWeight: "400",
        fontFamily: "arial",
    },
    flexOne: {
        flex: 1,
    },
    titleCommentJson: {
        fontSize: FontSize.MEDIUM,
        color: colors.textBlack19,
        fontWeight: "400",
        fontFamily: "arial",
        borderRadius: 4,
    },
    positionComment: {
        fontSize: dimensWidth(13),
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        borderRadius: 4,
    },
    viewTrangThai: {
        height: dimensWidth(22),
        width: dimensWidth(90),
        borderRadius: 3,
        backgroundColor: "#F0F0F0",
        justifyContent: "center",
        alignItems: "center",
    }
});

export default ForwardOrRecallModal