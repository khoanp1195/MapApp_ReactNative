import { StyleSheet } from "react-native";
import colors from "~/base/Colors";
import { FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: "#F2F2F2",
    },
    thongTinLuanChuyen: { padding: 3 },
    scrollView: {
      flex: 1,
      paddingBottom: 30,
    },
    cardView: {
      backgroundColor: "#FFFFFF",
      margin: 16,
      borderRadius: 8,
      paddingVertical: 15,
    },
    threeDotView: {
      alignSelf: "flex-end",
      marginRight: 10,
      padding: 10,
    },
    item: {},
    containerAttach: {
      borderColor: colors.greyDDD,
      borderWidth: 1,
      borderRadius: 8,
      marginHorizontal: 15,
      overflow: "hidden",
    },
    dashed: {
      //borderStyle: "dashed",
      borderTopWidth: 1,
      borderTopColor: "#E5E5E5",
      marginVertical: 15,
    },
    flexOne: {
      flex: 1,
    },
    content: {
      fontSize: FontSize.MEDIUM,
      color: colors.black,
      fontWeight: "400",
      fontFamily: "arial",
      marginLeft: 15,
      marginBottom: 10,
    },
    contenAttach: {
      fontSize: FontSize.MEDIUM,
      color: colors.black,
      fontWeight: "400",
      fontFamily: "arial",
      marginLeft: 15,
      marginTop: 5,
    },
    title: {
      fontSize: FontSize.SMALL,
      color: colors.lightBlack,
      fontWeight: "400",
      fontFamily: "arial",
      marginLeft: 15,
    },
    documentFile: {
      fontSize: FontSize.LARGE,
      color: colors.black,
      fontWeight: "700",
      fontFamily: "arial",
      marginLeft: 15,
      marginBottom: 10,
    },
    documentFileView: {
      padding: 15,
    },
    viewHeader: {
      backgroundColor: colors.primary,
      height: 55,
      justifyContent: "center",
      width: "100%",
      paddingRight: 15,
      paddingLeft: 7,
    },
    titleHeader: {
      fontSize: FontSize.MEDIUM,
      color: colors.scienceBlue,
      fontWeight: "700",
      fontFamily: "arial",
      paddingHorizontal: 15,
    },
    titleDocumentFile: {
      fontSize: FontSize.MEDIUM,
      color: colors.scienceBlue,
      fontWeight: "400",
      fontFamily: "arial",
      marginLeft: 15,
      borderRadius: 4,
    },
    sizeDocumentFile: {
      fontSize: FontSize.MEDIUM,
      color: colors.lightBlack,
      fontWeight: "400",
      fontFamily: "arial",
      marginLeft: 15,
      borderRadius: 4,
    },
    flexDirectionRowBetween: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
    },
    flexDirectionRow: {
      flexDirection: "row",
      alignItems: "center",
    },
    flexDirectionRowAction: {
      flex: 1,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      marginRight: dimensWidth(30)
    },
    backPress: {
      padding: 8,
    },
    tabBarLabelActive: {
      color: colors.white,
      fontWeight: "400",
      fontSize: FontSize.LARGE,
      marginLeft: 12,
    },
    viewTabBottomBar: {
      flexDirection: "row",
      height: dimensWidth(68),
      alignItems: "center",
      backgroundColor: colors.blueMedium,
    },
    bottomTab: {
      flex: 1,
      flexDirection: "row",
      alignItems: "center",
    },
    viewButton: {
      flex: 1,
      alignItems: "center",
    },
    actionMore: {
      padding: 8,
    },
    actionView: {
      justifyContent: "center",
      alignItems: "center",
      flexDirection: "row",
      marginRight: dimensWidth(30),
    },
    shareButton: {
      flex: 1,
    },
    commentInput: {
      paddingHorizontal: 10,
      borderColor: "#DDDDDD",
      borderWidth: 1,
      borderRadius: 3,
      height: 100,
      textAlignVertical: "top",
      marginTop: dimnensHeight(15)
    },
    titleVbDenTheoMuc: {
      fontSize: FontSize.MEDIUM,
      color: colors.lightBlack,
      fontWeight: "400",
      fontFamily: "arial",
      borderRadius: 4,
    },
    titleCommentJson: {
      fontSize: FontSize.MEDIUM,
      color: colors.textBlack19,
      fontWeight: "400",
      fontFamily: "arial",
      borderRadius: 4,
    },
    positionComment: {
      fontSize: dimensWidth(13),
      color: colors.lightBlack,
      fontWeight: "400",
      fontFamily: "arial",
      borderRadius: 4,
      marginTop: dimnensHeight(5)
    },
    viewTrangThai: {
      height: dimensWidth(22),
      width: dimensWidth(90),
      borderRadius: 3,
      marginTop: dimnensHeight(5),
      backgroundColor: "#F0F0F0",
      justifyContent: "center",
      alignItems: "center",
    },
    textTrichYeu: {
      flex: 1,
      fontSize: FontSize.MEDIUM,
      color: colors.textBlack19,
      fontWeight: "400",
      fontFamily: "arial",
      marginRight: 10,
    },
    textTrangThai: {
      fontSize: dimensWidth(12),
      color: "#626262",
      fontWeight: "400",
      fontFamily: "arial",
    },
    danhMucItemView: {
      backgroundColor: colors.white,
      padding: 15,
    },
    hoanTatTextColor: {
      color: "#3ABA32",
    },
    hoanTatBackGroundColor: {
      backgroundColor: "#E6FFE4",
    },
    danhMucFlatList: {
      borderColor: colors.greyDDD,
      borderWidth: 1,
      borderRadius: 8,
      overflow: "hidden",
    },
    commentJsonFlatlist: {
      borderColor: colors.greyDDD,
      borderWidth: 1,
      borderRadius: 8,
      marginTop: dimnensHeight(15),
      overflow: "hidden",
    },
    yKienLanhDaoTouch: {
      zIndex: 999,
      position: "absolute",
      height: "100%",
      width: "100%",
    },
    titleDoc : {
      fontSize: FontSize.SMALL,
      color: '#5E5E5E',
      lineHeight: 16,
      fontWeight: 400
    },
    valueDoc: { 
      fontSize: FontSize.MEDIUM,
      fontWeight: 400,
      color: '#19191E',
      marginTop: dimnensHeight(13),
      marginBottom: dimensWidth(22)
    }
  });

  export default styles