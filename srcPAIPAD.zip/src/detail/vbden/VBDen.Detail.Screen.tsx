import React, { useState, useCallback, useEffect, useMemo } from 'react';
import { View, Text, } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { dimnensHeight, dimensWidth } from '~/base/Constants';
import Colors from "../../base/Colors"
import { BASE_URL, FontSize } from '../../base/Constants'
import {
    isNullOrUndefined,
    calculateBetweenTwoDate,
    formatCreatedDate,
    format_mm_dd_hh_yy_mm_ss,
    arrayIsEmpty,
    checkTypeFiles,
    format_dd_mm_yy,
    byteConverter,
    removeSpecialCharacters,
    checkTrangThai,
    getExtension,
    checkMimeTypeFiles,
    DownloadFile,
} from '../../base/Functions'
import {
    BackIcon,
    FowardProcesscon,
    TransferProcessIcon,
    ClockWhiteIcon,
    ActionMoreIcon,
    ThreeDotIcon,
    ShareBlueIcon,
    AddRemoveIcon,
    ReAssignIcon,
    KetThucIcon,
    AssignGreenIcon,
    TabInComingDocxIcon,
    DownloadIcon,
    ViewFileFull,
} from "../../base/assets/svg/index";

import { LoadingView, TextInputCustom } from '~/base/components';
import { fetchDetailById, fetchAttachFile, submitActionShare, resetTaskVBDen } from '~/base/stories/vbden/reducer';
import styles from './VBDen.Detail.Style'
import LinearGradient from 'react-native-linear-gradient';
import { FlatList, TouchableOpacity } from 'react-native-gesture-handler';
import WorkflowHistoryModal from './components/WorkflowHistory.Modal'
import ActionModal from './components/Action.Modal'
import AssignmentModal from './components/Assigment.Modal';
import WebView from 'react-native-webview';
import { Action } from './VBDen.Enum';
import ShareModal from './components/Share.Modal';
import CompletedModal from './components/Completed.Modal';
import ForwardModal from './components/Forward.Modal';
import SubmitBODModal from './components/SubmitBOD.Modal';
import ReAssignmentModal from './components/ReAssignment.Modal';
import ForwardOrRecallModal from './components/ForwardOrRecall.Modal';
import VBDenTaskModal from './task/VBDen.Task.Modal';
import TaskModal from './task/VBDen.Task.Modal';
import FileModal from '~/base/components/File.Modal';
import DashedLine from 'react-native-dashed-line';
import FastImageCustom from '~/base/components/FastImageCustom';
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import { useFocusEffect } from '@react-navigation/native';
import colors from '../../base/Colors';
import { setIsCloseModalApp } from '~/base/stories/data/reducer';

const ItemFile = ({ item, index, selectedIndex, onItemPress, DownloadFile, token }: any) => {
    const {
        Title,
        Author,
        Created,
        Category,
        Size,
        Url,
        ListName
    } = item;
    const createdFormated = format_dd_mm_yy(Created);
    const FileIcon = () => {
        return checkTypeFiles(Url);
    };
    const fileSize = Size ? byteConverter(Size, 0) : null;
    const color = index % 2 == 0 ? '#EFF7FF' : '#FFFFFF'
    return (
        <View style={{
            flex: 1,
            flexDirection: 'row',
            height: dimnensHeight(40),
            backgroundColor: color,
            alignItems: 'center'
        }}>
            <View style={{
                backgroundColor: selectedIndex === index ? '#005FD4' : color,
                width: dimensWidth(5),
                height: '100%',
                marginRight: dimensWidth(20)
            }} />
            <View style={{
                flex: 0.3
            }}>
                <FileIcon />
            </View>
            <View style={{
                flex: 2,
            }}>
                <TouchableOpacity onPress={() => onItemPress(index)}>
                    <Text style={{
                        color: '#015DD1',
                        fontSize: FontSize.MEDIUM,
                        fontWeight: 400
                    }}
                        numberOfLines={1}>{Title}</Text>
                </TouchableOpacity>
            </View>

            <Text style={{
                flex: 0.5,
                color: '#5E5E5E',
                fontSize: FontSize.SMALL,
                marginLeft: dimensWidth(10)
            }}
                numberOfLines={1}>{fileSize}</Text>
            <Text style={{
                flex: 1,
                color: '#000000',
                fontSize: FontSize.MEDIUM,
                marginLeft: dimensWidth(10)
            }}
                numberOfLines={1}>{Category}</Text>

            <Text style={{
                flex: 1,
                color: '#000000',
                fontSize: FontSize.MEDIUM,
            }}
                numberOfLines={1}>{Author}</Text>

            <Text style={{
                flex: 0.8,
                color: '#5E5E5E',
                fontSize: FontSize.SMALL,
            }}
                numberOfLines={1}>{createdFormated}</Text>

            <TouchableOpacity style={{
                marginRight: dimensWidth(10)
            }}
                onPress={() => DownloadFile(item, token)}>
                <DownloadIcon color='#005FD4' />
            </TouchableOpacity>

        </View>
    )
}

const ItemComment = ({ item, index, token, subSite }: any) => {
    const { Title, Value, ImagePath, Position, Created } = item;
    const createdFormated = format_dd_mm_yy(Created);
    const isOdd = index % 2 === 0;
    const pos = !isNullOrUndefined(Position) ? Position.split(";#")[1] : "";
    return (
        <View
            style={{
                backgroundColor: isOdd ? Colors.alice_blue : Colors.white,
                padding: 15,
                flexDirection: 'row'
            }}>
            <FastImageCustom urlOnline={`${BASE_URL}/${subSite}/${ImagePath}`} token={token} />
            <View style={{
                flex: 1
            }}>
                <Text style={styles.titleCommentJson}>{Title}</Text>
                <Text style={styles.positionComment}>{pos}</Text>

                <Text style={{
                    marginTop: dimnensHeight(10),
                    fontSize: FontSize.MEDIUM,
                    color: Colors.textBlack19,
                    fontWeight: "400",
                    fontFamily: "arial",
                    borderRadius: 4,
                }}>{Value}</Text>
            </View>
            <Text style={styles.titleCommentJson}>{createdFormated}</Text>
        </View>
    );
}

const ItemTask = ({
    item,
    index,
    subSite,
    token,
    gotoNhiemVuDaPhanCongScreen,
}: any) => {
    const {
        AssignedToType,
        TrangThai,
        DepartmentTitle,
        Position,
        Created,
        DeThucHien,
        DueDate,
        ImagePath,
        ID,
    } = item;
    const createdFormated = format_dd_mm_yy(DueDate);
    const isOdd = index % 2 === 0;
    const customColor = checkTrangThai(TrangThai);
    const pos = !isNullOrUndefined(Position) ? Position.split(';#')[1] : Position;
    return (
        <TouchableOpacity
            onPress={gotoNhiemVuDaPhanCongScreen}
            style={{
                height: dimnensHeight(70),
                width: '100%',
                backgroundColor: index % 2 == 0 ? Colors.alice_blue : Colors.white
            }}>
            {
                AssignedToType == 1 ? (
                    <View style={{
                        flex: 1,
                        flexDirection: 'row',
                        alignItems: 'center',
                        paddingLeft: dimensWidth(15),
                        paddingRight: dimensWidth(15)
                    }}>
                        <Text style={{
                            flex: 1, fontSize: FontSize.MEDIUM,
                            color: Colors.textBlack19,
                            fontWeight: "400",
                            fontFamily: "arial",
                            borderRadius: 4
                        }}>{DepartmentTitle}</Text>
                        <Text style={{
                            flex: 1,
                            color: DeThucHien ? '#0072C6' : '#5E5E5E'
                        }}>{DeThucHien ? "Thực hiện" : "Phối hợp"}</Text>
                        <View>
                            <Text>{createdFormated}</Text>
                            <View
                                style={[
                                    styles.viewTrangThai,
                                    { backgroundColor: customColor?.backgroundColor },
                                ]}
                            >
                                <Text
                                    style={[styles.textTrangThai, { color: customColor?.color }]}
                                    numberOfLines={1}
                                >
                                    {TrangThai}
                                </Text>
                            </View>
                        </View>
                    </View>
                ) : <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    paddingLeft: dimensWidth(15),
                    paddingRight: dimensWidth(15),
                    alignItems: 'center'
                }}>
                    <View style={{
                        flex: 1,
                        flexDirection: 'row'
                    }}>
                        <FastImageCustom urlOnline={`${BASE_URL}/${subSite}/${ImagePath}`} token={token} />
                        <View style={{
                            flex: 1
                        }}>
                            <Text style={styles.titleCommentJson}>{DepartmentTitle}</Text>
                            <Text style={styles.positionComment}>{pos}</Text>
                        </View>
                    </View>
                    <Text style={{
                        flex: 1,
                        color: DeThucHien ? '#0072C6' : '#5E5E5E'
                    }}>{DeThucHien ? "Thực hiện" : "Phối hợp"}</Text>

                    <View>
                        <Text>{createdFormated}</Text>
                        <View
                            style={[
                                styles.viewTrangThai,
                                { backgroundColor: customColor?.backgroundColor },
                            ]}
                        >
                            <Text
                                style={[styles.textTrangThai, { color: customColor?.color }]}
                                numberOfLines={1}
                            >
                                {TrangThai}
                            </Text>
                        </View>
                    </View>
                </View>
            }
        </TouchableOpacity>
    );
};

const ItemDonVi = ({ item, index }: any) => {
    const { DepartmentName, TrangThai, VBId, Position, ThoiHanGQ } = item;
    const isOdd = index % 2 === 0;
    const customColor = checkTrangThai(TrangThai);
    const tmpCreated = format_dd_mm_yy(ThoiHanGQ)
    return (
        <TouchableOpacity
            style={[
                styles.danhMucItemView,
                isOdd && { backgroundColor: Colors.alice_blue },
            ]}
        >
            <View
                style={[styles.flexDirectionRowBetween, { alignItems: "flex-start" }]}
            >
                <View style={styles.flexDirectionRow}>
                    <Text style={styles.textTrichYeu} numberOfLines={1}>
                        {DepartmentName}
                    </Text>
                    <View>
                        <Text style={{
                            marginBottom: dimnensHeight(5),
                            color: '#5E5E5E'
                        }}>{tmpCreated}</Text>
                        <View
                            style={[
                                styles.viewTrangThai,
                                { backgroundColor: customColor?.backgroundColor },
                            ]}
                        >
                            <Text
                                style={[styles.textTrangThai, { color: customColor?.color }]}
                                numberOfLines={1}
                            >
                                {TrangThai}
                            </Text>
                        </View>
                    </View>
                </View>
            </View>
        </TouchableOpacity>
    );
};

const IconView = ({ ID }: any) => {
    if (ID === Action.ChuyenPhanCong) return <TransferProcessIcon />;
    if (ID === Action.ChuyenXuLy) return <FowardProcesscon />;
    if (ID === Action.PhanCong) return <AssignGreenIcon />;
    if (ID === Action.PhanCongLai) return <ReAssignIcon />;
    if (ID === Action.ChiaSe)
        return <ShareBlueIcon color={Colors.white} dimens={20} />;
    if (ID === Action.BoSungThuHoi) return <AddRemoveIcon />;
    if (ID === Action.KetThuc) return <KetThucIcon />;
    return <View />;
};

const ItemAction = ({ item, index, onActionPress, }: any) => {
    if (index >= 3) return null;
    const { Title, ID } = item;
    return (
        <TouchableOpacity
            key={ID}
            style={styles.shareButton}
            onPress={() => onActionPress(ID)}
        >
            <View style={styles.flexDirectionRowAction}>
                <IconView ID={ID} />
                <Text style={styles.tabBarLabelActive} numberOfLines={1}>
                    {Title}
                </Text>
            </View>
        </TouchableOpacity>
    );
};

const VBDenDetail = ({ route, navigation, selectedItemIndex }: any) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { dataDetail, dataFiles, isProcessTaskVbdenSuccess, isLoadingVBDenDetail, isProcessVbdenSuccess, isLoading } = useSelector((state: any) => state.vbden);
    const { subSite, token } = useSelector((state: any) => state.login);
    const [modalWorkflowHistory, setModalWorkflowHistory] = useState(false)
    const [ItemId, setItemId] = useState()
    const [ItemVB, setItemVB] = useState<any>({})
    const [dataAttachFiles, setDataAttachFiles] = useState([])
    const [dataAttachFileWebView, setDataAttachFileWebView] = useState({})
    const [dropdownAction, setDropdownAction] = useState(false)
    const [hiddenInfo, setHiddenInfo] = useState(false)
    const [modalShare, setModalShare] = useState(false)
    const [comment, setComment] = useState("")
    const [modalAssigment, setModalAssignment] = useState(false)
    const [modalCompleted, setModalCompleted] = useState(false)
    const [modalForward, setModalForward] = useState(false)
    const [modalSubmitBOD, setModalSubmitBOD] = useState(false)
    const [modalReAssignment, setModalReAssignment] = useState(false)
    const [modalForwardOrRecall, setModalForwardOrRecall] = useState(false)
    const [modalTask, setModalTask] = useState(false)
    const [taskId, setTaskId] = useState(0)
    const [fileModal, setFileModal] = useState(false)
    const [selectIndexFile, setSeletedIndexFile] = useState(0)

    const fetchData = useCallback(async (Id: any, sub: any) => {
        dispatch(fetchDetailById({
            subSite: sub,
            ItemId: Id
        }));
        dispatch(fetchAttachFile({
            subSite: sub,
            ItemId: Id
        }));
    }, [dispatch]);

    const onCloseModalWorkflowHistory = useCallback(() => {
        setModalWorkflowHistory(false)
    }, [modalWorkflowHistory, ItemId])

    useEffect(() => {
        setItemVB(dataDetail)
    }, [dataDetail])

    useEffect(() => {
        if (route.ItemId !== undefined) {
            setItemId(route.ItemId)
            fetchData(route.ItemId, subSite)
        }
    }, [dispatch, route.ItemId, subSite, selectedItemIndex])

    useEffect(() => {
        if (isProcessTaskVbdenSuccess || isProcessVbdenSuccess) {
            fetchData(ItemId, subSite)
            dispatch(resetTaskVBDen(null))
        }
    }, [dispatch, isProcessTaskVbdenSuccess, subSite, isProcessVbdenSuccess, ItemId])

    useEffect(() => {
        if (!arrayIsEmpty(dataFiles)) {
            setDataAttachFiles(dataFiles)
            setDataAttachFileWebView(dataFiles[0])
        }
    }, [dataFiles])

    const onOpenDropdownAction = useCallback(() => {
        setDropdownAction(!dropdownAction)
    }, [dropdownAction])

    const onHiddenInfo = useCallback(() => {
        setHiddenInfo(!hiddenInfo)
    }, [hiddenInfo])

    const onCloseShareModal = useCallback(() => {
        setModalShare(false)
    }, [modalShare])

    const onCloseAssigmentModal = useCallback(() => {
        setModalAssignment(false)
    }, [modalAssigment])

    const onConfirmAssigmentModal = useCallback(() => {
        setModalAssignment(false)
    }, [ItemId])

    const onCloseFileModal = useCallback(() => {
        setFileModal(false)
    }, [fileModal])

    const onItemFilePress = useCallback((index: number) => {
        const element = dataAttachFiles[index]
        setDataAttachFileWebView(element)
        setSeletedIndexFile(index)
    }, [dataAttachFiles, selectIndexFile])

    const onCloseCompletedModal = useCallback(() => {
        setModalCompleted(false)
    }, [modalCompleted])

    const onCloseForwardModal = useCallback(() => {
        setModalForward(false)
    }, [modalForward])

    const onCloseSubmitBODModal = useCallback(() => {
        setModalSubmitBOD(false)
    }, [modalSubmitBOD])

    const onCloseReAssignmentModal = useCallback(() => {
        setModalReAssignment(false)
    }, [modalReAssignment])

    const onCloseForwardOrRecallModal = useCallback(() => {
        setModalForwardOrRecall(false)
    }, [modalForwardOrRecall])

    const onActionPress = useCallback(
        (ID: number) => {
            setDropdownAction(false)
            if (ID === Action.ChiaSe) setModalShare(true)
            if (ID == Action.PhanCong) setModalAssignment(true)
            if (ID == Action.KetThuc) setModalCompleted(true)
            if (ID == Action.ChuyenPhanCong) setModalForward(true)
            if (ID == Action.ChuyenXuLy) setModalSubmitBOD(true)
            if (ID == Action.PhanCongLai) setModalReAssignment(true)
            if (ID == Action.BoSungThuHoi) setModalForwardOrRecall(true)
        },
        [modalShare, modalCompleted, modalAssigment, modalForward]
    );

    const onCommentChanged = useCallback((text: string) => {
        setComment(text)
    }, [comment])

    const goToTaskDetail = useCallback((ID: any) => {
        setTaskId(ID)
        setModalTask(true)
    }, [taskId])

    const onCloseTaskModal = useCallback(() => {
        setModalTask(false)
    }, [modalTask])

    return (
        <View style={{
            flex: 1,
            backgroundColor: Colors.white,
        }}>
            <LinearGradient style={{
                paddingLeft: dimensWidth(15),
                height: dimnensHeight(55),
                alignItems: 'center',
                flexDirection: 'row',
                justifyContent: 'flex-end',
                paddingRight: dimensWidth(15)
            }}
                colors={["#0262E9", "#0054AE"]}>
                {!arrayIsEmpty(ItemVB?.ActionJson) && !isLoadingVBDenDetail ? (
                    <View style={[styles.actionView]}>
                        {ItemVB?.ActionJson.map((item: any, index: any) => {
                            return (
                                <ItemAction
                                    key={index}
                                    item={item}
                                    index={index}
                                    onActionPress={onActionPress}
                                />
                            );
                        })}
                        {ItemVB?.ActionJson.length > 3 && (
                            <TouchableOpacity
                                style={styles.actionMore}
                                onPress={onOpenDropdownAction}
                            >
                                <ActionMoreIcon />
                            </TouchableOpacity>
                        )}
                    </View>
                ) : null}
                {
                    !isLoadingVBDenDetail &&
                    <TouchableOpacity style={{
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}
                        onPress={() => { setModalWorkflowHistory(true) }}>
                        <ClockWhiteIcon />
                    </TouchableOpacity>
                }

            </LinearGradient>
            <KeyboardAwareScrollView style={{
                flex: 1,
                backgroundColor: colors.white
            }}
            >
                <View style={{
                    paddingLeft: dimensWidth(15),
                    paddingRight: dimensWidth(15),
                    paddingTop: dimnensHeight(20),
                    paddingBottom: dimnensHeight(20)
                }}>
                    <View style={{
                        flex: 1,
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <Text style={{
                            color: '#005FD4',
                            fontWeight: 700,
                            fontSize: FontSize.LARGE_X,
                            flex: 1,
                        }}>{ItemVB?.TrichYeu}</Text>
                        <TouchableOpacity onPress={onHiddenInfo}>
                            <ThreeDotIcon color={!hiddenInfo ? "#C5C5C5" : '#0072C6'} />
                        </TouchableOpacity>
                    </View>

                    {
                        hiddenInfo ? <View style={{ marginTop: dimnensHeight(20) }} /> : <View>
                            <View style={{
                                marginTop: dimnensHeight(15)
                            }}>
                                <DashedLine dashLength={2} dashColor='#B3B3B3' />
                            </View>

                            <View style={{
                                flex: 1,
                                flexDirection: 'row',
                                marginTop: dimnensHeight(20)
                            }}>
                                <View style={{
                                    flex: 1
                                }}>
                                    <View>
                                        <Text style={styles.titleDoc}>Loại văn bản</Text>
                                        <Text style={styles.valueDoc}>{!isNullOrUndefined(ItemVB?.DocumentType) ? ItemVB?.DocumentType.split(';#')[1] : ''}</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.titleDoc}>Ngày trên VB</Text>
                                        <Text style={styles.valueDoc}>{format_dd_mm_yy(ItemVB?.DocumentDate)}</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.titleDoc}>Số đến</Text>
                                        <Text style={styles.valueDoc}>{ItemVB?.SoDen}</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.titleDoc}>Độ mật</Text>
                                        <Text style={styles.valueDoc}>{ItemVB?.DoMat}</Text>
                                    </View>
                                </View>
                                <View style={{
                                    flex: 1
                                }}>
                                    <View>
                                        <Text style={styles.titleDoc}>Nơi gửi</Text>
                                        <Text style={styles.valueDoc}>{!isNullOrUndefined(ItemVB?.CoQuanGui) ? ItemVB?.CoQuanGui.split(';#')[1] : ''}</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.titleDoc}>Ngày đến</Text>
                                        <Text style={styles.valueDoc}>{format_dd_mm_yy(ItemVB?.ReceivedDate)}</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.titleDoc}>Độ khẩn</Text>
                                        <Text style={styles.valueDoc}>{ItemVB?.DoKhan}</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.titleDoc}>Thời gian giải quyết</Text>
                                        <Text style={styles.valueDoc}>{format_dd_mm_yy(ItemVB?.ThoiHanGQ)}</Text>
                                    </View>
                                </View>
                            </View>
                        </View>
                    }
                    {
                        arrayIsEmpty(dataFiles) ? <View /> :
                            <View>
                                <View style={{
                                    flex: 1,
                                    width: '100%',
                                    height: dimnensHeight(400),
                                    backgroundColor: 'white',
                                    borderRadius: 8,
                                    shadowColor: '#000000',
                                    shadowOffset: {
                                        width: 0,
                                        height: 1
                                    },
                                    shadowRadius: 4,
                                    shadowOpacity: 0.3,
                                }}>
                                    <WebView
                                        source={{ uri: BASE_URL + dataAttachFileWebView?.Url }}
                                        style={{ flex: 1 }}
                                        sharedCookiesEnabled
                                    />
                                    <View style={{
                                        position: 'absolute',
                                        alignSelf: 'flex-end',
                                        bottom: 15,
                                        right: 15
                                    }}>
                                        <TouchableOpacity onPress={() => setFileModal(true)}>
                                            <ViewFileFull />
                                        </TouchableOpacity>
                                    </View>

                                </View>
                                <Text style={{
                                    marginTop: dimnensHeight(20),
                                    marginBottom: dimnensHeight(15),
                                    fontSize: FontSize.LARGE_X,
                                    color: '#000000',
                                    fontWeight: 700
                                }}>Tài liệu đính kèm</Text>
                                <FlatList
                                    style={{
                                        borderWidth: 1,
                                        borderRadius: 4,
                                        borderColor: '#DDDDDD'
                                    }}
                                    data={dataAttachFiles}
                                    renderItem={({ item, index }) => (
                                        <ItemFile
                                            item={item}
                                            index={index}
                                            token={token}
                                            selectedIndex={selectIndexFile}
                                            onItemPress={(index: number) => onItemFilePress(index)}
                                            DownloadFile={(item: any) => DownloadFile(item, token)} />
                                    )}
                                    extraData={dataAttachFiles}
                                    disableVirtualization
                                    nestedScrollEnabled
                                    scrollEnabled={false}
                                    keyExtractor={(item, index) => String(index)}
                                />
                            </View>
                    }
                    <View>
                        <Text style={{
                            marginTop: dimnensHeight(20),
                            color: '#000000',
                            fontSize: FontSize.LARGE,
                            fontWeight: 700
                        }}>Ý kiến lãnh đạo</Text>

                        <TextInputCustom
                            editable={true}
                            placeholder="Vui lòng nhập ý kiến"
                            placeholderTextColor={Colors.grey999}
                            multiline
                            onChangeText={onCommentChanged}
                            style={styles.commentInput}
                        />
                        {!arrayIsEmpty(ItemVB?.CommentJson) && (
                            <FlatList
                                nestedScrollEnabled
                                scrollEnabled={false}
                                style={styles.commentJsonFlatlist}
                                extraData={ItemVB?.CommentJson}
                                disableVirtualization
                                horizontal={false}
                                keyExtractor={(item, index) => index.toString()}
                                data={ItemVB?.CommentJson}
                                renderItem={({ item, index }) => (
                                    <ItemComment item={item} index={index} />
                                )}
                            />
                        )}
                    </View>
                    {
                        !arrayIsEmpty(ItemVB?.TaskJson) ?
                            <View>
                                <Text style={{
                                    marginTop: dimnensHeight(20),
                                    marginBottom: dimnensHeight(15),
                                    fontSize: FontSize.LARGE_X,
                                    color: '#000000',
                                    fontWeight: 700
                                }}>Tổ chức phân công thực hiện</Text>
                                <FlatList
                                    nestedScrollEnabled
                                    scrollEnabled={false}
                                    style={styles.danhMucFlatList}
                                    extraData={ItemVB?.TaskJson}
                                    disableVirtualization
                                    horizontal={false}
                                    keyExtractor={(item, index) => index.toString()}
                                    data={ItemVB?.TaskJson}
                                    renderItem={({ item, index }) => (
                                        <ItemTask
                                            item={item}
                                            index={index}
                                            gotoNhiemVuDaPhanCongScreen={() =>
                                                goToTaskDetail(item?.ID)
                                            }
                                        />
                                    )}
                                />
                            </View>
                            : null
                    }
                    {
                        !arrayIsEmpty(ItemVB?.DonViXuLyJson) ? <View>
                            <Text style={{
                                marginTop: dimnensHeight(20),
                                marginBottom: dimnensHeight(15),
                                fontSize: FontSize.LARGE_X,
                                color: '#000000',
                                fontWeight: 700
                            }}>Chi nhánh</Text>
                            <FlatList
                                nestedScrollEnabled
                                scrollEnabled={false}
                                style={styles.danhMucFlatList}
                                extraData={ItemVB?.DonViXuLyJson}
                                disableVirtualization
                                keyExtractor={(item) => item?.ID}
                                data={ItemVB?.DonViXuLyJson}
                                renderItem={({ item, index }) => (
                                    <ItemDonVi item={item} index={index} />
                                )}
                            />
                        </View>
                            : null
                    }
                </View>
            </KeyboardAwareScrollView>
            <LoadingView isLoading={isLoadingVBDenDetail} bgColor={colors.white} viewLoadingStyle={{ top: dimnensHeight(55), }} />

            <WorkflowHistoryModal
                modalVisible={modalWorkflowHistory}
                onCloseModal={onCloseModalWorkflowHistory}
                ItemId={route.ItemId} />
            <ActionModal
                modalVisible={dropdownAction}
                Actions={ItemVB?.ActionJson}
                onActionPress={onActionPress}
                onCloseModal={onOpenDropdownAction}
            />
            <ShareModal
                modalVisible={modalShare}
                ItemId={ItemId}
                onCloseModal={onCloseShareModal}
                Comment={comment}
            />
            <AssignmentModal
                modalVisible={modalAssigment}
                ItemId={ItemId}
                Comment={comment}
                onCloseModal={onCloseAssigmentModal}
                onConfirmModal={onConfirmAssigmentModal}
                BanLanhDao={ItemVB?.BanLanhDao} />

            <CompletedModal
                modalVisible={modalCompleted}
                ItemId={ItemId}
                Comment={comment}
                onCloseCompletedModal={onCloseCompletedModal}
            />

            <ForwardModal
                modalVisible={modalForward}
                ItemId={ItemId}
                yKienLanhDao={comment}
                onCloseForwardModal={onCloseForwardModal} />

            <SubmitBODModal
                modalVisible={modalSubmitBOD}
                ItemId={ItemId}
                BanLanhDao={ItemVB?.BanLanhDao}
                onCloseForwardModal={onCloseSubmitBODModal}
                yKienLanhDao={comment} />

            <ReAssignmentModal
                modalVisible={modalReAssignment}
                ItemId={ItemId}
                BanLanhDao={ItemVB?.BanLanhDao}
                TaskJson={ItemVB?.TaskJson}
                onCloseModal={onCloseReAssignmentModal}
                Comment={comment}
            />

            <ForwardOrRecallModal
                modalVisible={modalForwardOrRecall}
                ItemId={ItemId}
                DonViXuLyJson={ItemVB?.DonViXuLyJson}
                onCloseModal={onCloseForwardOrRecallModal}
                Comment={comment}
                CommentJson={ItemVB?.CommentJson}
            />

            <TaskModal
                modalVisible={modalTask}
                onCloseModal={onCloseTaskModal}
                TaskId={taskId}
                ItemVB={ItemVB}
                CommentJson={ItemVB?.CommentJson}
                AttachFiles={dataAttachFiles}
            />

            <FileModal
                modalVisible={fileModal}
                onCloseModal={onCloseFileModal}
                value={dataAttachFileWebView}
            />
        </View>
    )
}

export default VBDenDetail
