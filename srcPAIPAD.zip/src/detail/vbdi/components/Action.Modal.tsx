import {  StyleSheet, Text, View, TouchableOpacity,  } from 'react-native';
import React, { FC, } from "react";
import { FontSize, dimensWidth, dimnensHeight } from '~/base/Constants';
import { Action } from '../VBDi.Enum';
import {
    FowardProcesscon,
    ShareBlueIcon,
    DongYIcon,
    BoSungThongTinIcon,
    YeuCauHieuChinhIcon,
} from "../../../base/assets/svg";
import colors from '../../../base/Colors'
import ModalCusTom from '~/base/components/ModalCusTom';

interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    onActionPress: (ID: number) => void;
    Actions: any;
}

const ActionModal: FC<Props> = ({
    modalVisible,
    onCloseModal,
    onActionPress,
    Actions,
    ...props
}: Props) => {

    const IconView = ({ ID }: any) => {
        if (ID === Action.ChiaSe)
            return <ShareBlueIcon  dimens={20} />;
        if (ID === Action.PheDuyet) return <DongYIcon />;
        if (ID === Action.YeuCauBoSung) return <BoSungThongTinIcon />;
        if (ID === Action.YeuCauHieuChinh) return <YeuCauHieuChinhIcon />;
        if (ID === Action.DongY) return <DongYIcon />;
        if (ID === Action.ThuHoi) return <BoSungThongTinIcon color={'#6DD400'}/>;
        if (ID === Action.ChuyenXuLy) return <FowardProcesscon color='#6DD400' />;
        return <View />;
    };

    const ItemAction = ({ item, index, onChooseonActionMorePress }: any) => {
        if (index <= 2) return null;
        const { Title, ID } = item;

        return (
            <View style={styles.chooseTypeView}>
                <TouchableOpacity
                    style={styles.flexDirection}
                    onPress={() => onChooseonActionMorePress(item)}
                >
                    <IconView ID={ID} />
                    <Text style={styles.textType} numberOfLines={1}>
                        {Title}
                    </Text>
                </TouchableOpacity>
                {Actions.length !== index + 1 && <View style={styles.stroke} />}
            </View>
        );
    };

    return (
        <View style={styles.centeredView}>
            <ModalCusTom
                transparent={true}
                visible={modalVisible}
                onCloseModalCustom={onCloseModal}
                >
                <TouchableOpacity
                    activeOpacity={1}
                    onPress={onCloseModal}>
                    <View style={styles.centeredView}>
                        <View style={styles.modalView}>
                            <View style={styles.chooseTypeView}>
                                {Actions &&
                                    Actions.map((item: any, index: any) => {
                                        return (
                                            <ItemAction
                                                key={index}
                                                item={item}
                                                index={index}
                                                onChooseonActionMorePress={onActionPress}
                                            />
                                        );
                                    })}
                            </View>
                        </View>
                    </View>
                </TouchableOpacity>
            </ModalCusTom>
        </View>
    );
};

const styles = StyleSheet.create({
    centeredView: {
        width: '100%',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        position: 'absolute',
        },
    modalView: {
        marginRight: dimensWidth(50),
        backgroundColor: 'white',
        borderBottomLeftRadius: 4,
        borderBottomRightRadius: 4,
        marginTop: dimnensHeight(75),
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 2,
    },
    chooseTypeView: {
        backgroundColor: colors.white,
        borderRadius: 4,
    },
    flexDirection: {
        height: dimnensHeight(60),
        width: dimensWidth(200),
        flexDirection: "row",
        paddingHorizontal: 20,
        alignItems: "center",
    },
    stroke: {
        borderWidth: 0.5,
        borderColor: "#999",
    },
    textType: {
        fontSize: FontSize.LARGE,
        color: colors.black,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: dimensWidth(10),
    },
    tabBarLabelActive: {
        color: colors.white,
        fontWeight: "400",
        fontSize: FontSize.LARGE,
    },
    viewTabBottomBar: {
        flexDirection: "row",
        height: dimensWidth(66),
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: colors.blueMedium,
        borderRadius: 8,
    }
});

export default ActionModal