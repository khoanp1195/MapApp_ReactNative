import React, { FC, useState, useCallback, useEffect, useMemo } from "react";
import {
    Modal,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    KeyboardAvoidingView,
    Platform,
    Image
} from "react-native";
import colors from "~/base/Colors";
import { BASE_URL, FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";
import { BackIcon, CloseXIcon, ConfirmIcon, SearchIcon, SellectedBoxIcon, UnSellectedBoxIcon } from "~/base/assets/svg";
import { NoDataView,  } from "~/base/components";
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import SearchInput from "~/search/components/SearchInput";
import FastImage from "react-native-fast-image";
import { arrayIsEmpty, isNullOrEmpty, removeAccent, removeSpecialCharacters } from "base/Functions";
import { FlatList } from "react-native-gesture-handler";
import { fetchVBDiDSNguoiBoSungThongTin } from "~/base/stories/data/reducer";
import { RootState } from "~/base/stories";
import ModalCusTom from "~/base/components/ModalCusTom";

interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    onConfirmModal: (data: [],selectedId: number) => void;
    defaultValue: any;
    onlyUser?: Boolean
    titleModal?: string;
    ItemId: number;
}
const Item = ({ item, index, selectedId, onItemPress }: any) => {
    const { subSite, token } = useSelector((state: any) => state.login);
    const { AccountID, FullName, AccountName, Position, Type, ImagePath, Email, ID, IsSelected } = item
    const onItemPresss = () => {
        onItemPress(ID)
    }

    return (
        <TouchableOpacity onPress={() => onItemPresss()}>
            <View style={{
                flex: 1,
                flexDirection: 'row',
                height: dimnensHeight(70),
                alignItems: 'center',
                paddingLeft: dimensWidth(20),
                paddingRight: dimensWidth(20)
            }}>
                {Type == 0 ? <FastImage
                    style={{
                        height: dimensWidth(40),
                        width: dimensWidth(40),
                        marginRight: dimensWidth(10),
                        borderRadius: dimensWidth(20),
                    }}
                    source={{
                        uri: BASE_URL + '/' + subSite + ImagePath,
                        headers: { Authorization: `${token}` },
                        priority: FastImage.priority.normal,
                    }}
                    resizeMode={FastImage.resizeMode.contain}
                /> : <Image
                    style={{
                        height: dimensWidth(40),
                        width: dimensWidth(40),
                        marginRight: dimensWidth(10),
                        borderRadius: dimensWidth(20),
                        resizeMode: 'stretch',
                    }}
                    source={require('base/assets/images/icon_group.png')} />}

                <View style={styles.viewItemContent}>
                    <Text style={styles.title}>{FullName}</Text>
                    <Text style={styles.position}>{removeSpecialCharacters(Position)}</Text>
                </View>
                <View>
                    {selectedId === ID ? <SellectedBoxIcon /> : <UnSellectedBoxIcon />}
                </View>
            </View>
            <View style={{
                flex: 1,
                flexDirection: 'column',
                justifyContent: 'flex-start',
                borderColor: '#B3B3B3',
                borderStyle: 'dotted',
                borderWidth: 1.5,
                borderRadius: 1,
                position: 'relative',
            }}
            />
        </TouchableOpacity>
    )
}

const UserGroupModal: FC<Props> = ({
    titleModal = "Chọn người dùng và nhóm người dùng",
    modalVisible,
    onCloseModal,
    onConfirmModal,
    ItemId,
    defaultValue, onlyUser = false,
    ...props
}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { dataDSNguoiBosungThongtin } = useSelector((state: any) => state.data);
    const { dataCurrentUsers } = useSelector((state: RootState) => state.login);
    const { subSite, token } = useSelector((state: any) => state.login);
    const [filterText, setFilterText] = useState("");
    const [dataUserAndGroup, setDataUserAndGroup] = useState([])
    const [dataFiltered, setDataFiltered] = useState([])
    const [selectedId, setSelectId] = useState(-1)

    const onChangeFilterText = useCallback((text: string) => {
        setFilterText(text);
    }, [filterText]);

    const onItemPress = useCallback((id: number) => {
        if (selectedId === id) {
            setSelectId(-1)
        } else {
            setSelectId(id)
        }
    }, [selectedId])

    useEffect(() => {

        if (!isNullOrEmpty(filterText)) {
            const tmpText = removeAccent(filterText)
            const filteredArray = dataUserAndGroup.filter((item: any) =>
            removeAccent(item?.FullName).includes(tmpText) || removeAccent(item?.AccountName).includes(tmpText)
            );

            setDataFiltered(filteredArray)
        } else {
            setDataFiltered(dataUserAndGroup)
        }
    }, [filterText, dataUserAndGroup])

    const onConfirmOwnModal = useCallback(() => {
        let tmp = []
        for (let index = 0; index < dataUserAndGroup.length; index++) {
            const element = dataUserAndGroup[index];
            if (selectedId === element.ID) {
                tmp.push(element)
            }
        }
        onConfirmModal(tmp,selectedId)
    }, [dataUserAndGroup, selectedId])

    useEffect(() => {
        dispatch(fetchVBDiDSNguoiBoSungThongTin({ ItemId, subSite }));
    }, [dispatch, ItemId, subSite])

    useEffect(() => {
        if (!arrayIsEmpty(dataDSNguoiBosungThongtin)) {
            const data = dataDSNguoiBosungThongtin.filter((r: any) => r.ID !== dataCurrentUsers[0]?.ID)
            setDataUserAndGroup(data)
            setDataFiltered(data)
        }
    }, [dataDSNguoiBosungThongtin])
    useEffect(() => {
     setSelectId(defaultValue)
    }, [defaultValue, modalVisible])

    const onClose = useCallback(
        () => {
          setSelectId(defaultValue)
          onCloseModal();
        },
        [defaultValue],
      )
    return (
        <ModalCusTom
            transparent={true}
            visible={modalVisible}
            onCloseModalCustom={onClose}
            {...props}
            style={styles.centeredView}
        >
            <KeyboardAvoidingView style={styles.centeredView}>
                <View style={styles.modalView}>
                    <View style={{
                        padding: dimensWidth(20),
                        flexDirection: 'row',
                        alignItems: 'center'
                    }}>
                        <TouchableOpacity style={{
                            flex: 0.08
                        }}
                            onPress={onClose}>
                            <BackIcon />
                        </TouchableOpacity>
                        <Text style={{
                            flex: 1,
                            color: '#005FD4',
                            fontSize: FontSize.LARGE_X,
                            fontWeight: 700,
                        }}>{titleModal}</Text>
                        <TouchableOpacity style={{
                            marginRight: dimensWidth(40)
                        }}
                            onPress={onConfirmOwnModal}>
                            <ConfirmIcon />
                        </TouchableOpacity>
                        <TouchableOpacity onPress={onClose}>
                            <CloseXIcon />
                        </TouchableOpacity>
                    </View>
                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        backgroundColor: '#F6F8FA'
                    }} />
                    <View style={{
                        flexDirection: 'row',
                        height: dimnensHeight(50)
                    }}>
                        <View style={{
                            alignItems: 'center',
                            justifyContent: 'center',
                            marginLeft: dimensWidth(20)
                        }}>
                            <SearchIcon color='#000' />
                        </View>
                        <SearchInput
                            onChangeFilterText={onChangeFilterText}
                            filterText={filterText} />
                    </View>

                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        // backgroundColor: '#F6F8FA'
                    }} />
                    {
                        !arrayIsEmpty(dataFiltered) ?
                            <FlatList
                                data={dataFiltered}
                                extraData={dataFiltered}
                                renderItem={({ item, index }) => (
                                    <Item
                                        index={index}
                                        item={item}
                                        selectedId={selectedId}
                                        onItemPress={(ID: number) => onItemPress(ID)}
                                    />
                                )}
                                keyExtractor={(item: any) => item?.ID}
                            /> : <NoDataView />
                    }
                </View>
            </KeyboardAvoidingView>
        </ModalCusTom>
    )
}

const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(0,0,0,0.4)"
    },
    modalView: {
        height: dimnensHeight(640),
        width: dimensWidth(750),
        backgroundColor: 'white',
        borderRadius: 20,
        overflow: 'hidden'
    },
    flatlist: {
        backgroundColor: "#FFFFFF",
        margin: 16,
        borderRadius: 8,
    },
    viewItemContent: { alignItems: 'flex-start', flex: 1 },
    item: {
        height: 60,
        alignItems: "center",
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: 15,
        borderStyle: "dashed",
        borderTopWidth: 1,
        borderTopColor: "#E5E5E5",
    },
    title: {
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.black,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 15,
    },
    position: {
        fontSize: dimensWidth(13),
        lineHeight: dimensWidth(20),
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 15,
    },
    viewHeader: {
        backgroundColor: colors.primary,
        height: Platform.OS === "ios" ? 130 : 90,
        justifyContent: "center",
        width: "100%",
        padding: 10,
    },
    titleHeader: {
        flex: 1,
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.white,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 15,
    },
    flexDirectionRow: {
        flexDirection: "row",
        alignItems: "center",
    },
    backPress: {
        padding: 8,
    },
    iconDone: {
        marginEnd: 15,
    }
});

export default UserGroupModal