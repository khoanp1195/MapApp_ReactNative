import React, { FC, useMemo, useState, useCallback, useEffect } from "react";
import colors from "themes/Colors";
import {
  Alert,
  StyleSheet,
  Text,
  Modal,
  View,
  TouchableOpacity,
  TextStyle,
} from "react-native";
import { Calendar, LocaleConfig } from "react-native-calendars";
import { format_mm_dd_yy, checkIsBefore, checkIsAfter, randomIdFunc } from "helpers/formater";
import { dimensWidth, FontSize } from "themes/const";
import {
  CalendarLeftIcon,
  CalendarRightIcon,
  CalendarIcon,
  RemoveIcon,
  DeleteIcon,
} from "assets/SVG/index";
import moment from "moment";
import ModalCusTom from "~/base/components/ModalCusTom";
const dayNamesShort = ["T2", "T3", "T4", "T5", "T6", "T7", "CN"];
LocaleConfig.locales["fr"] = {
  monthNames: [
    "Tháng 01",
    "Tháng 02",
    "Tháng 03",
    "Tháng 04",
    "Tháng 05",
    "Tháng 06",
    "Tháng 7",
    "Tháng 08",
    "Tháng 09",
    "Tháng 10",
    "Tháng 11",
    "Tháng 12",
  ],
  monthNamesShort: [
    "Tháng 01",
    "Tháng 02",
    "Tháng 03",
    "Tháng 04",
    "Tháng 05",
    "Tháng 06",
    "Tháng 7",
    "Tháng 08",
    "Tháng 09",
    "Tháng 10",
    "Tháng 11",
    "Tháng 12",
  ],
  dayNames: ["Chủ Nhật", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"],
  dayNamesShort,
  today: "Ngày hôm nay",
};

LocaleConfig.defaultLocale = "fr";
const theme = {
  textDayFontFamily: "arial",
  textDayFontSize: 15,
  dayTextColor: "#1A1919",
};

interface Props {
  modalCalendarVisible: Boolean;
  onDateChangeModal: (date: string) => void;
  removeSelectedDate: () => void;
  onCloseModal: () => void;
  startDate: any;
  endDate: any;
  typeModal: string;
  resetToday: (date: string) => void;
}

const CalendarPickerModal: FC<Props> = ({
  modalCalendarVisible,
  onDateChangeModal,
  onCloseModal,
  startDate,
  endDate,
  typeModal,
  removeSelectedDate,
  resetToday,
}) => {
  const todayFormated = moment().format("YYYY-MM-DD");
  const [selectedDate, setSelectedDate] = useState(todayFormated);

  useEffect(() => {
    // if (typeModal === "startDate") {
    //   setSelectedDate(startDate);
    // } else {
    //   setSelectedDate(endDate);
    // }
    setSelectedDate(startDate);
    setSelectedDate(endDate);
  }, [startDate, endDate]);

  const _resetToday = useCallback(() => {
    resetToday(todayFormated);
    setSelectedDate(todayFormated);
  }, [selectedDate]);
  const _removeSelectedDate = useCallback(() => {
    setSelectedDate("");
    removeSelectedDate();
  }, [selectedDate]);
  const _onPressArrowLeft = useCallback(() => {
    let prevousMonth= '';
    if(selectedDate){
      prevousMonth = moment(selectedDate).add(-1, "M").format("YYYY-MM-DD");
    }else{
      prevousMonth = moment(todayFormated).add(-1, "M").format("YYYY-MM-DD");
    }
    setSelectedDate(prevousMonth);
  }, [selectedDate]);
  const _onPressArrowRight = useCallback(() => {
    let futureMonth= '';
    if(selectedDate){
      futureMonth = moment(selectedDate).add(1, "M").format("YYYY-MM-DD");
    }else{
      futureMonth = moment(todayFormated).add(1, "M").format("YYYY-MM-DD");
    }
    setSelectedDate(futureMonth);
  }, [selectedDate]);

  return (
    <ModalCusTom
      transparent={true}
      onCloseModalCustom={onCloseModal}
      visible={modalCalendarVisible}
      style={styles.centeredView}
    >
      <View style={styles.centeredView}>
        <View style={styles.modalView}>
          <Calendar
            // Initially visible month. Default = Date()
            style={styles.calendarContainer}
            initialDate={selectedDate}
            current={selectedDate}
            headerStyle={{ justifyContent: "center", alignItems: "center" }}
            theme={theme}
            selected={selectedDate}
            onMonthChange={(month) => {}}
            renderHeader={(date) => {
              const header = date.toString("MMMM/yyyy");
              const [month, year] = header.split(" ");
              return (
                <View style={styles.headerContainer} key={randomIdFunc()}>
                  <View style={styles.viewTopBarCalendar}>
                    <TouchableOpacity
                      style={styles.iconTopBar}
                      onPress={_resetToday}
                    >
                      <CalendarIcon />
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={styles.iconTopBar}
                      onPress={_removeSelectedDate}
                    >
                      <DeleteIcon />
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={styles.iconTopBar}
                      onPress={onCloseModal}
                    >
                      <RemoveIcon />
                    </TouchableOpacity>
                  </View>
                  <View style={styles.header}>
                    <TouchableOpacity
                      style={styles.calendarIconView}
                      activeOpacity={0.7}
                      onPress={_onPressArrowLeft}
                    >
                      <CalendarLeftIcon />
                    </TouchableOpacity>
                    <Text style={[styles.month]}>{`Tháng ${year}`}</Text>
                    <TouchableOpacity
                      style={styles.calendarIconView}
                      activeOpacity={0.7}
                      onPress={_onPressArrowRight}
                    >
                      <CalendarRightIcon />
                    </TouchableOpacity>
                  </View>
                  <View style={styles.dayNamesView}>
                    {dayNamesShort.map((day) => {
                      return <Text key={randomIdFunc()} style={styles.dayNamesText}>{day}</Text>;
                    })}
                  </View>
                  <View style={styles.bottomDashed} />
                </View>
              );
            }}
            // Handler which gets executed when visible month changes in calendar. Default = undefined
            // If firstDay=1 week starts from Monday. Note that dayNames and dayNamesShort should still start from Sunday.
           //firstDay={1}
            hideDayNames
            hideArrows
            dayComponent={({ date, state, marking, theme }: any) => {
              const isSelectedDay = date.dateString === selectedDate;
              let isDisable = false;
              if (typeModal === "startDate") {
                isDisable = checkIsAfter(date.dateString, endDate);
              } else {
                isDisable = checkIsBefore(date.dateString, startDate);
              }
              const isDisableDay = state === "disabled";
              const isToday = state === "today";
              return (
                <TouchableOpacity
                  key={date.dateString}
                  style={[
                    styles.dateView,
                    isDisable && styles.disableView,
                    isDisableDay && styles.disableDate,
                    isSelectedDay && styles.selectedDate,
                  ]}
                  disabled={isDisable}
                  onPress={() => {
                    setSelectedDate(date.dateString);
                    onDateChangeModal(date.dateString);
                  }}
                >
                  <Text
                    style={[
                      styles.dayText,
                      isSelectedDay && styles.selectedDateColor,
                      isToday && styles.today,
                    ]}
                  >
                    {date.day}
                  </Text>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      </View>
    </ModalCusTom>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    opacity: 1,
  },
  calendarContainer: {
    borderRadius: 8,
  },
  header: {
    flexDirection: "row",
    backgroundColor: "#025FDA",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 10,
    marginTop: 3,
  },
  month: {
    fontSize: 18,
    fontWeight: "700",
    color: "#fff",
    fontFamily: "arial",
  },
  year: {
    marginRight: 5,
  },
  calendarIconView: {
    width: dimensWidth(34),
    height: dimensWidth(34),
    backgroundColor: colors.white,
    borderRadius: dimensWidth(17),
    justifyContent: "center",
    alignItems: "center",
  },
  viewTopBarCalendar: {
    flexDirection: "row",
    width: "100%",
    justifyContent: "flex-end",
    marginVertical: 15,
  },
  iconTopBar: {
    marginRight: 25,
  },
  headerContainer: {
    width: dimensWidth(384),
    marginHorizontal: -dimensWidth(15),
  },
  dayNamesView: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 15,
    marginHorizontal: dimensWidth(15),
  },
  dayNamesText: {
    height: dimensWidth(34),
    width: dimensWidth(34),
    borderRadius: dimensWidth(17),
    fontSize: 16,
    color: "#1A1919",
    fontWeight: "400",
    fontFamily: "arial",
    textAlign: "center",
  },
  dayText: {
    fontSize: 15,
    color: "#1A1919",
    fontWeight: "400",
    fontFamily: "arial",
    textAlign: "center",
  },
  dateView: {
    justifyContent: "center",
    alignItems: "center",
    height: dimensWidth(34),
    width: dimensWidth(34),
    borderRadius: dimensWidth(17),
  },
  disableView: {
    opacity: 0.1,
  },
  selectedDate: {
    backgroundColor: "#C3DDFF",
  },
  today: {
    color: "#025FDA",
  },
  selectedDateColor: {
    color: "#025FDA",
  },
  disableDate: {
    opacity: 0.1,
  },
  bottomDashed: {
    borderBottomColor: "#1A1919",
    borderBottomWidth: 1,
    borderStyle: "dashed",
    marginHorizontal: dimensWidth(15),
    overflow: 'hidden'
  },
});
export default CalendarPickerModal;
