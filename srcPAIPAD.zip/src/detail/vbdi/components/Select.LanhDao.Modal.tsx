import React, { FC, useState, useCallback, useEffect } from "react";
import {
    Modal,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    KeyboardAvoidingView,
    TouchableWithoutFeedback,
    Keyboard,
    Platform,
    Image
} from "react-native";
import { FlatList } from "react-native-gesture-handler";
import colors from "~/base/Colors";
import { FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";
import { arrayIsEmpty, checkIsEmpty, isNullOrUndefined, removeSpecialCharacters, splitID } from "~/base/Functions";
import { BackIcon, CloseXIcon, ConfirmIcon, DeleteRedIcon, MemberIcon, MinusIcon, PlusIcon, RightBlueIcon, SelectedDisableIcon, SelectedEnalbleIcon, SellectedBoxIcon, UnSellectedBoxIcon, UserGreyIcon, UserPlusIcon } from "~/base/assets/svg";
import { TextInputCustom } from "~/base/components";
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { fetchBanLanhDao } from "~/base/stories/data/reducer";
import ModalCusTom from "~/base/components/ModalCusTom";

interface Props {
    modalVisible: Boolean;
    onCloseLanhDaoModal: () => void;
    onConfirmLanhDaoModal: (data: any) => void;
    BanLanhDao?: string;
}

const SelectLanhDaoModal: FC<Props> = ({
    modalVisible,
    onCloseLanhDaoModal,
    onConfirmLanhDaoModal,
    BanLanhDao,
    ...props
}: Props) => {
    type ItemProps = {
        item: any;
        lanhDaoCongTyNameData: any;
        chooseTypePress: ({ Title, ID }: any) => void;
        index: number;
        type: string;
        ID: string;
        selectedId: string
    };

    const Item = ({
        item,
        chooseTypePress,
        index,
        selectedId,
        ID,
    }: ItemProps) => {
        const { Title } = item;
        return (
            <TouchableOpacity
                style={[styles.item, index === 0 && { borderTopWidth: 0 }]}
                onPress={() => chooseTypePress(index)}
            >
                <Image
                    style={{
                        height: dimensWidth(40),
                        width: dimensWidth(40),
                        marginRight: dimensWidth(10),
                        borderRadius: dimensWidth(20),
                        resizeMode: 'stretch',
                    }}
                    source={require('../../../base/assets/images/icon_group.png')} />
                <View style={{flex: 1}}>
                    <Text style={styles.Title}>{Title}</Text>
                </View>
                <View>
                    {selectedId === ID ? <SelectedEnalbleIcon /> : <SelectedDisableIcon />}
                </View>
            </TouchableOpacity>
        );
    };

    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { subSite } = useSelector((state: any) => state.login);
    const { dataBanLanhDao } = useSelector((state: any) => state.data);
    const [dataLanhDaoState, setDataLanhDaoState] = useState([])
    const [selectId, setSelectdId] = useState(0)

    const onItemPress = useCallback((index) => {
        setSelectdId(dataLanhDaoState[index].ID)
    }, [dataLanhDaoState, selectId])

    const onClose = useCallback(() => {
        onCloseLanhDaoModal()
    }, [])

    const onConfirm = useCallback(() => {
        const temp = dataLanhDaoState.filter(r => r.ID === selectId)
        onConfirmLanhDaoModal(temp)
    }, [dataLanhDaoState, selectId])

    useEffect(() => {
        if (dataBanLanhDao) {
            const data = dataBanLanhDao.map((record) => ({
                ...record,
                IsSelected: false
            }));
            if (!isNullOrUndefined(BanLanhDao)) {
                const formatBLD = splitID(BanLanhDao);
                const tmp = data
                    .filter((it: any) => it?.ID != formatBLD)
                    .sort((a: any, b: any) => a?.Orders - b?.Orders);

                setDataLanhDaoState(tmp)
            } else {
                setDataLanhDaoState(data)
            }
        }
    }, [dataBanLanhDao])

    useEffect(() => {
        dispatch(fetchBanLanhDao(subSite))
    }, [])

    return (
        <ModalCusTom
            transparent={true}
            visible={modalVisible}
            {...props}
            onCloseModalCustom={onClose}
            style={styles.centeredView}
        >
            <TouchableWithoutFeedback
                accessible={false}
                style={{ flex: 1 }}
                onPress={Keyboard.dismiss}>
                <KeyboardAvoidingView
                    style={styles.centeredView}
                    behavior={Platform.OS === "ios" ? "padding" : "height"}
                >
                    <View style={styles.modalView}>
                        <View style={{
                            padding: dimensWidth(20),
                            flexDirection: 'row',
                            alignItems: 'center',
                            justifyContent: 'center'
                        }}>
                            <Text style={{
                                flex: 1,
                                color: '#005FD4',
                                fontSize: FontSize.LARGE_X,
                                fontWeight: 700,
                            }}>Lãnh đạo công ty</Text>
                            <TouchableOpacity style={{
                                marginRight: dimensWidth(40)
                            }}
                                onPress={onConfirm}
                            >
                                <ConfirmIcon />
                            </TouchableOpacity>
                            <TouchableOpacity onPress={onClose}>
                                <CloseXIcon />
                            </TouchableOpacity>
                        </View>
                        <View style={{
                            width: '100%',
                            height: dimnensHeight(10),
                            backgroundColor: '#F6F8FA',
                            marginBottom: dimnensHeight(10)
                        }} />
                        <FlatList
                            contentContainerStyle={styles.flatlist}
                            extraData={selectId}
                            data={dataLanhDaoState}
                            renderItem={({ item, index }) => (
                                <Item
                                    index={index}
                                    item={item}
                                    selectedId={selectId}
                                    ID={item?.ID}
                                    chooseTypePress={onItemPress}
                                />
                            )}
                            keyExtractor={(item) => item?.ID}
                        />
                    </View>
                </KeyboardAvoidingView>
            </TouchableWithoutFeedback>
        </ModalCusTom>
    );
};

const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(0,0,0,0.4)"
    },
    modalView: {
        height: dimnensHeight(640),
        width: dimensWidth(750),
        backgroundColor: 'white',
        borderRadius: 20,
        overflow: 'hidden'
    },
    chooseTypeView: {
        marginBottom: 15,
        borderRadius: 8,
    },
    flexDirection: {
        height: 67,
        flexDirection: "row",
        paddingHorizontal: dimensWidth(20),
        alignItems: "center",
    },
    stroke: {
        borderWidth: 0.5,
        borderColor: "#999",
        //borderStyle: "dashed",
    },
    textType: {
        fontSize: FontSize.SMALL,
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: dimensWidth(20),
        marginVertical: 10,
    },
    tabBarLabelActive: {
        color: colors.white,
        fontWeight: "400",
        fontSize: FontSize.LARGE,
    },
    textAssign: {
        color: colors.blueMedium,
        fontWeight: "700",
        fontSize: FontSize.LARGE,
    },
    viewAssign: {
        backgroundColor: colors.lightBlue,
        padding: 15,
    },
    titleBoss: {
        fontSize: FontSize.LARGE,
        color: colors.black,
        fontWeight: "700",
        fontFamily: "arial",
        marginHorizontal: dimensWidth(20),
    },
    commentInput: {
        paddingHorizontal: 10,
        borderColor: colors.greyDDD,
        borderRadius: 3,
        height: 100,
        borderWidth: 1,
        marginHorizontal: dimensWidth(20),
        marginBottom: 10,
        textAlignVertical: "top",
    },
    typeChild: {
        paddingHorizontal: 16,
        flexDirection: "row",
        alignItems: "center",
        height: 34,
        borderColor: colors.greyDDD,
        borderWidth: 1,
        borderRadius: 3,
        marginHorizontal: dimensWidth(20),
        justifyContent: "space-between",
    },
    textFiltedType: {
        fontSize: FontSize.MEDIUM,
        color: colors.black,
        fontWeight: "400",
        fontFamily: "arial",
        marginRight: 9,
    },
    item: {
        flex: 1,
        alignItems: 'center',
        flexDirection: "row",
        padding: 20,
        borderTopWidth: 1,
        borderTopColor: "#E5E5E5",
    },
    Title: {
        fontSize: FontSize.LARGE,
        lineHeight: dimensWidth(20),
        color: colors.black,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 15,
    },
    position: {
        fontSize: dimensWidth(13),
        lineHeight: dimensWidth(20),
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 15,
        marginTop: 5,
    },
    viewHeader: {
        backgroundColor: colors.primary,
        height: 55,
        justifyContent: "center",
        width: "100%",
        paddingHorizontal: 10,
    },
    TitleHeader: {
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.white,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 15,
    },
    flexDirectionRow: {
        flexDirection: "row",
        alignItems: "center",
    },
    backPress: {
        padding: 8,
    },
    flatlist: {
        backgroundColor: "#FFFFFF",
        borderRadius: 8,
    }
});

export default SelectLanhDaoModal