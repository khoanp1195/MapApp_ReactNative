import React, { FC, useCallback, useEffect, useMemo } from "react";
import {
    View,
    StyleSheet,
    Text,
    TouchableOpacity,
    SectionList
} from "react-native";
import { dimensWidth, dimnensHeight, FontSize, BASE_URL } from "~/base/Constants";
import { CloseXIcon, DashedLineIcon, RetangleGreenIcon } from "~/base/assets/svg";
import { useDispatch, useSelector } from "react-redux";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { NoDataView } from "../../../base/components";
import colors from "~/base/Colors";
import {
    format_yy_mm_mm_dd_hh,
    removeSpecialCharacters,
    arrayIsEmpty,
    isNullOrUndefined,
} from "~/base/Functions";
import FastImage from 'react-native-fast-image';
import { fetchThongTinLuanChuyen } from "~/base/stories/vbdi/reducer";
import { RootState } from "~/base/stories";
import ModalCusTom from "~/base/components/ModalCusTom";

interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    ItemId: any;
}

const WorkflowHistory: FC<Props> = ({
    modalVisible,
    onCloseModal,
    ItemId,
    ...props
}: Props) => {
    type ItemProps = {
        item: any;
        token: string,
        subSite: string
    };

    const Item = ({ item, subSite, token }: ItemProps) => {
        const { SubmitAction, ImagePath, Position, FullName, Created, isLast, Action, Note } = item;
        const formatSubmitActionText = useMemo(() => {
            const formatText = SubmitAction?.replaceAll("<br/>", "\n")
            return formatText
        }, [SubmitAction]);

        return (
            <View style={{ flex: 1, flexDirection: 'row' }}>
                <View style={{ marginLeft: 22 }}>
                    <DashedLineIcon color={isLast ? "#fff" : "#B3B3B3"} height="100%" width={2} />
                </View>
                <View
                    style={styles.item}
                >
                    <View style={[styles.flexDirectionRow, { marginTop: 10 }]}>
                        <FastImage
                            style={styles.itemAvatar}
                            source={{
                                uri: `${BASE_URL}/${subSite}${ImagePath}`,
                                headers: { Authorization: `${token}` },
                                priority: FastImage.priority.normal,
                            }}
                        />
                        <View style={{ flex: 1 }}>
                            <View style={styles.flexDirectionRow}>
                                <Text style={styles.titleContent} numberOfLines={1}>
                                    {FullName}
                                </Text>
                                <Text style={styles.date} numberOfLines={1}>
                                    {format_yy_mm_mm_dd_hh(Created)}
                                </Text>
                            </View>
                            <View style={styles.flexDirectionRow}>
                                <Text style={styles.titleContent} numberOfLines={1}>
                                    {removeSpecialCharacters(Position)}
                                </Text>
                                {
                                    SubmitAction && <View style={styles.viewSubmitAction}>
                                        <Text style={styles.textSubmitAction}>
                                            {formatSubmitActionText}
                                        </Text>
                                    </View>
                                }
                            </View>
                        </View>
                    </View>
                    {
                        Note && <Text style={styles.textNoted} numberOfLines={1}>
                            {Note}
                        </Text>
                    }
                </View>
            </View>

        );
    };

    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();

    const { dataThongtinluanchuyenVbdi } = useSelector((state: RootState) => state.vbdi);
    const { token, subSite } = useSelector((state: RootState) => state.login);

    const onClose = useCallback(() => {
        onCloseModal()
    }, [])

    useEffect(() => {
        dispatch(fetchThongTinLuanChuyen({
            subSite,
            ItemId
        }))
    }, [dispatch, subSite, ItemId])

    return (
        <ModalCusTom
            transparent={true}
            visible={modalVisible}
            onCloseModalCustom={onCloseModal}
        >
            <View style={styles.centeredView}>
                <View style={styles.modalView}>
                    <View style={{
                        padding: dimensWidth(20),
                        flexDirection: 'row'
                    }}>
                        <Text style={styles.modalText}>Thông tin luân chuyển</Text>
                        <TouchableOpacity onPress={onClose}>
                            <CloseXIcon />
                        </TouchableOpacity>
                    </View>

                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        backgroundColor: '#F6F8FA'
                    }} />

                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        overflow: 'hidden',
                        backgroundColor: '#F6F8FA',
                        marginBottom: dimnensHeight(20)
                    }} />
                    {arrayIsEmpty(dataThongtinluanchuyenVbdi) ? (
                        <NoDataView />
                    ) : (
                        <SectionList
                            style={{
                                margin: 15,
                                backgroundColor: 'white',
                                borderRadius: 8,
                                paddingTop: 10
                            }}
                            contentContainerStyle={{
                                paddingBottom: 20
                            }}
                            sections={dataThongtinluanchuyenVbdi}
                            keyExtractor={(item, index) => item + index}
                            renderItem={({ item, index }) => (
                                <Item
                                    item={item}
                                    subSite={subSite}
                                    token={token}
                                />
                            )}
                            renderSectionHeader={({ section: { item } }) => (
                                <View style={{
                                    marginLeft: 15,
                                    marginRight: 15
                                }}>
                                    <View style={styles.flexDirectionRow}>
                                        <View style={{
                                            marginRight: dimensWidth(10)
                                        }}>
                                            {
                                                !isNullOrUndefined(item?.SubmitAction) ? <RetangleGreenIcon /> : <RetangleGreenIcon color='#FFDA6C' />
                                            }
                                        </View>
                                        <Text style={styles.title} numberOfLines={1}>
                                            {item?.Action}
                                        </Text>
                                    </View>
                                </View>
                            )}
                        />
                    )}
                </View>
            </View>
        </ModalCusTom>
    )
}
const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(0,0,0,0.4)",
    },
    modalView: {
        height: dimnensHeight(770),
        width: dimensWidth(774),
        backgroundColor: 'white',
        borderRadius: 20,
        overflow: 'hidden'
    },
    textStyle: {
        color: 'white',
        fontWeight: 'bold',
        textAlign: 'center',
    },
    modalText: {
        flex: 1,
        color: '#005FD4',
        fontSize: FontSize.LARGE_X,
        fontWeight: 700,
    },
    container: {
        flex: 1,
        backgroundColor: "#F2F2F2",
    },
    viewUserName: { marginRight: 20, marginLeft: -8 },
    viewUserImage: {
        height: 40,
        width: 40,
        borderRadius: 20,
        marginLeft: 40,
    },
    flatlist: {
        borderRadius: 8,
        backgroundColor: colors.white,
        overflow: "hidden",
    },
    containerFlatlist: {
        margin: 15,
    },
    item: {
        flex: 1,
        paddingBottom: 20,
        paddingTop: 10
    },
    title: {
        fontSize: FontSize.MEDIUM,
        color: colors.textBlack19,
        fontWeight: "700",
        fontFamily: "arial",
    },
    titleContent: {
        fontSize: FontSize.MEDIUM,
        color: colors.textBlack19,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 15,
        flex: 1,
        alignSelf: 'flex-start'
    },
    textNoted: {
        fontSize: FontSize.MEDIUM,
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 30,
        alignSelf: 'flex-start',
        marginTop: 10
    },
    content: {
        flex: 1,
        fontSize: dimensWidth(12),
        color: colors.textBlack19,
        fontWeight: "400",
        fontFamily: "arial",
        marginHorizontal: 10,
        backgroundColor: colors.lightBlue,
        paddingHorizontal: 15,
        paddingVertical: 4,
        borderRadius: 5,
        overflow: 'hidden',
    },
    viewSubmitAction: {
        backgroundColor: colors.lightBlue,
        marginHorizontal: 10,
        paddingHorizontal: 15,
        paddingVertical: 4,
        borderRadius: 5,
        overflow: 'hidden',
    },
    textSubmitAction: {
        fontSize: dimensWidth(12),
        color: colors.textBlack19,
        fontWeight: "400",
        fontFamily: "arial",
        flex: 1,
    },
    date: {
        fontSize: dimensWidth(13),
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 15,
        paddingHorizontal: 6,
        paddingVertical: 4,
    },
    viewHeader: {
        backgroundColor: colors.primary,
        height: 55,
        justifyContent: "center",
        width: "100%",
        paddingHorizontal: 10,
    },
    titleHeader: {
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.white,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 15,
    },
    flexDirectionRow: {
        flexDirection: "row",
        alignItems: "center",
    },
    itemAvatar: {
        height: dimensWidth(40),
        width: dimensWidth(40),
        borderRadius: dimensWidth(20),
        marginLeft: 30,
        marginTop: 5,
        alignSelf: 'flex-start'
    },
    flexDirectionRowBetween: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
    },
    backPress: {
        padding: 8,
    },
    onPressActiveTab: {
        height: 60,
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: colors.white,
        borderBottomColor: colors.primary,
        borderBottomWidth: 1,
        paddingLeft: 20,
    },
    onPressInActiveTab: {
        height: 60,
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: colors.white,
        paddingLeft: 20,
    },
    titleActiveTab: {
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.primary,
        fontWeight: "700",
        fontFamily: "arial",
    },
    titleInActiveTab: {
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.grey999,
        fontWeight: "400",
        fontFamily: "arial",
    },
    titleContentVBdenDSNguoiXem: {
        fontSize: FontSize.MEDIUM,
        color: colors.textBlack19,
        fontWeight: "400",
        fontFamily: "arial",
        marginBottom: 4
    },
    contentVBDenDSNguoiXem: {
        fontSize: dimensWidth(13),
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
    },
    positionVBDenDSNguoiXem: {
        fontSize: dimensWidth(13),
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
    },
});

export default WorkflowHistory