import React, { FC, useState, useCallback, useEffect } from "react";
import {
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  KeyboardAvoidingView,
  TouchableWithoutFeedback,
  Keyboard,
  Platform
} from "react-native";
import { FlatList } from "react-native-gesture-handler";
import colors from "~/base/Colors";
import { FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";
import { arrayIsEmpty, checkIsEmpty, isNullOrUndefined } from "~/base/Functions";
import { BackIcon, CloseXIcon, ConfirmIcon, DeleteRedIcon, MemberIcon, MinusIcon, PlusIcon, RightBlueIcon, SellectedBoxIcon, UnSellectedBoxIcon, UserGreyIcon, UserPlusIcon } from "~/base/assets/svg";
import { TextInputCustom } from "~/base/components";
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import SelectLanhDaoModal from "./Select.LanhDao.Modal";
import UserGroupModal from "~/base/components/UserGroup.Modal";
import { vbDiPheDuyetApi } from "~/base/stories/vbdi/reducer";
import { Alert } from "react-native";
import ModalCusTom from "~/base/components/ModalCusTom";

interface Props {
  modalVisible: Boolean;
  onCloseForwardModal: () => void;
  yKienLanhDao: string;
  BanLanhDao: string;
  ItemId: any;
  actionTitle: string;
}

const SubmitBODModal: FC<Props> = ({
  modalVisible,
  onCloseForwardModal,
  yKienLanhDao,
  BanLanhDao,
  ItemId,
  actionTitle,
  ...props
}: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const { subSite } = useSelector((state: any) => state.login);
  const [userCCText, setUserCCText] = useState("")
  const [userGroupModal, setUserGroupModal] = useState(false)
  const [userCC, setUserCC] = useState([])

  const [text, setText] = useState("");
  const onChangeText = useCallback(
    (input: string) => {
      setText(input);
    },
    [text]
  );

  const onConfirm = useCallback(() => {
    let userCCTmp = ''
    for (let index = 0; index < userCC.length; index++) {
      const element: any = userCC[index];
      userCCTmp += element.AccountID + ';#' + element.AccountName + ';#'
    }
    const body = {
      Comment: text,
      UserCC: userCCTmp.substring(0, userCCTmp.length - 2),
      ItemId: ItemId,
      subSite
    };
    dispatch(vbDiPheDuyetApi(body));
    onCloseModal();

  }, [text, userCC, subSite, ItemId]);

  const onCloseModal = useCallback(() => {
    setText("");
    setUserCC([])
    setUserCCText("")
    onCloseForwardModal();
  }, []);

  const onOpenUserCCModal = useCallback(() => {
    setUserGroupModal(true)
  }, [userGroupModal])

  const onCloseUserGroupModal = useCallback(() => {
    setUserGroupModal(false)
  }, [])

  const onConfirmUserGroupModal = useCallback((data: any) => {
    if (!arrayIsEmpty(data)) {
      let tmpText = ''
      for (let index = 0; index < data.length; index++) {
        const element = data[index];

        tmpText += element.FullName + "; ";

      }

      tmpText = tmpText.substring(0, tmpText.length - 2)
      setUserCCText(tmpText)
      setUserCC(data)
      setUserGroupModal(false)
    }
  }, [userGroupModal, userCCText, userCC])

  useEffect(() => {
    setText(yKienLanhDao);
  }, [yKienLanhDao]);

  return (
    <ModalCusTom
      transparent={true}
      visible={modalVisible}
      {...props}
      onCloseModalCustom={onCloseModal}
      style={styles.centeredView}
    >
      <TouchableWithoutFeedback
        accessible={false}
        style={{ flex: 1 }}
        onPress={Keyboard.dismiss}>
        <KeyboardAvoidingView
          style={styles.centeredView}
          behavior={Platform.OS === "ios" ? "padding" : "height"}
        >
          <View style={styles.modalView}>
            <View style={{
              padding: dimensWidth(20),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <Text style={{
                flex: 1,
                color: '#005FD4',
                fontSize: FontSize.LARGE_X,
                fontWeight: 700,
              }}>{actionTitle}</Text>
              <TouchableOpacity style={{
                marginRight: dimensWidth(40)
              }}
                onPress={onConfirm}>
                <ConfirmIcon />
              </TouchableOpacity>
              <TouchableOpacity onPress={onCloseModal}>
                <CloseXIcon />
              </TouchableOpacity>
            </View>
            <View style={{
              width: '100%',
              height: dimnensHeight(10),
              backgroundColor: '#F6F8FA',
              marginBottom: dimnensHeight(10)
            }} />
            <Text style={styles.textType}>Ý kiến phản hồi</Text>
            <TextInputCustom
              placeholder="Vui lòng nhập ý kiến"
              placeholderTextColor={colors.grey999}
              multiline
              onChangeText={(text) => onChangeText(text)}
              value={text}
              style={styles.commentInput}
            />
            <Text style={styles.titleBoss}>Chọn người để biết</Text>
            <View style={styles.chooseTypeView}>
              <Text style={styles.textType} numberOfLines={1}>CC</Text>
              <TouchableOpacity
                onPress={onOpenUserCCModal}
                style={styles.typeChild}
              >
                <Text style={styles.textFiltedType} numberOfLines={1}>{userCCText}</Text>
                <UserGreyIcon />
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </TouchableWithoutFeedback>

      <UserGroupModal
        modalVisible={userGroupModal}
        onCloseModal={onCloseUserGroupModal}
        onConfirmModal={(data) => onConfirmUserGroupModal(data)}
        defaultValue=""
        onlyUser={true} />

    </ModalCusTom>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: "rgba(0,0,0,0.4)"
  },
  modalView: {
    height: dimnensHeight(640),
    width: dimensWidth(750),
    backgroundColor: 'white',
    borderRadius: 20,
    overflow: 'hidden'
  },
  chooseTypeView: {
    marginBottom: 15,
    borderRadius: 8,
  },
  flexDirection: {
    height: 67,
    flexDirection: "row",
    paddingHorizontal: dimensWidth(20),
    alignItems: "center",
  },
  stroke: {
    borderWidth: 0.5,
    borderColor: "#999",
  },
  textType: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: dimensWidth(20),
    marginVertical: 10,
  },
  tabBarLabelActive: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.LARGE,
  },
  textAssign: {
    color: colors.blueMedium,
    fontWeight: "700",
    fontSize: FontSize.LARGE,
  },
  viewAssign: {
    backgroundColor: colors.lightBlue,
    padding: 15,
  },
  titleBoss: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginHorizontal: dimensWidth(20),
    marginTop: dimnensHeight(10)
  },
  commentInput: {
    paddingHorizontal: 10,
    borderColor: colors.greyDDD,
    borderRadius: 3,
    height: 100,
    borderWidth: 1,
    marginHorizontal: dimensWidth(20),
    marginBottom: 10,
    textAlignVertical: "top",
  },
  typeChild: {
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "center",
    height: dimnensHeight(35),
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 3,
    marginHorizontal: dimensWidth(20),
    justifyContent: "space-between",
  },
  textFiltedType: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 9,
  }
});

export default SubmitBODModal