import React, { FC, useState, useCallback, useEffect } from "react";
import {
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  KeyboardAvoidingView,
  TouchableWithoutFeedback,
  Keyboard,
  Platform,
  Alert
} from "react-native";
import colors from "~/base/Colors";
import { FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";
import { arrayIsEmpty, checkIsEmpty, } from "~/base/Functions";
import { CloseXIcon, ConfirmIcon, RightBlueIcon, } from "~/base/assets/svg";
import { TextInputCustom } from "~/base/components";
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { vbDiChuyenXuLyApi } from "~/base/stories/vbdi/reducer";
import ModalCusTom from "~/base/components/ModalCusTom";
import UserGroupOnlyModal from "~/base/components/UserGroupOnly.Modal";
interface Props {
  modalVisible: Boolean;
  onCloseForwardModal: () => void;
  yKienLanhDao: string;
  ItemId: any;
}

const SubmitBODModal: FC<Props> = ({
  modalVisible,
  onCloseForwardModal,
  yKienLanhDao,
  ItemId,
  ...props
}: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const { subSite } = useSelector((state: any) => state.login);
  const [userCCText, setUserCCText] = useState("")
  const [userGroupModal, setUserGroupModal] = useState(false)
  const [userCC, setUserCC] = useState([])

  const [text, setText] = useState("");
  const onChangeText = useCallback(
    (input: string) => {
      setText(input);
    },
    [text]
  );

  const onConfirm = useCallback(() => {
    if (checkIsEmpty(userCCText)) {
      Alert.alert('Thông báo', 'Vui lòng chọn người để thực hiện chuyển xử lý', [
        {
          text: 'Đóng'
        }
      ])
    } else {
      let userCCTmp = ''
      for (let index = 0; index < userCC.length; index++) {
        const element = userCC[index];
        userCCTmp += element.AccountID + ';#' + element.AccountName + ';#'
      }
      const body = {
        ChooseUser: userCCTmp,
        Comment: text,
        ItemId,
        subSite
      };
      dispatch(vbDiChuyenXuLyApi(body));
      onCloseModal();
    }
  }, [text, ItemId, userCC, subSite]);

  const onCloseModal = useCallback(() => {
    setText("");
    setUserCCText("")
    setUserCC([])
    onCloseForwardModal();
  }, []);

  const onCloseUserGroupModal = useCallback(() => {
    setUserGroupModal(false)
  }, [])
  const onOpenUserCCModal = useCallback(() => {
    setUserGroupModal(true)
  }, [userGroupModal])

  const onConfirmUserGroupModal = useCallback((data: any) => {
    if (!arrayIsEmpty(data)) {
      let tmpText = ''
      for (let index = 0; index < data.length; index++) {
        const element = data[index];

        tmpText += element.FullName + "; ";

      }

      tmpText = tmpText.substring(0, tmpText.length - 2)
      setUserCCText(tmpText)
      setUserCC(data)
      setUserGroupModal(false)
    }
  }, [userGroupModal, userCCText, userCC])

  useEffect(() => {
    setText(yKienLanhDao);
  }, [yKienLanhDao]);

  return (
    <ModalCusTom
      transparent={true}
      visible={modalVisible}
      onCloseModalCustom={onCloseModal}
      {...props}
      style={styles.centeredView}
    >
      <TouchableWithoutFeedback
        accessible={false}
        style={{ flex: 1 }}
        onPress={Keyboard.dismiss}>
        <KeyboardAvoidingView
          style={styles.centeredView}
          behavior={Platform.OS === "ios" ? "padding" : "height"}
        >
          <View style={styles.modalView}>
            <View style={{
              padding: dimensWidth(20),
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <Text style={{
                flex: 1,
                color: '#005FD4',
                fontSize: FontSize.LARGE_X,
                fontWeight: 700,
              }}>Chuyển xử lý</Text>
              <TouchableOpacity style={{
                marginRight: dimensWidth(40)
              }}
                onPress={onConfirm}>
                <ConfirmIcon />
              </TouchableOpacity>
              <TouchableOpacity onPress={onCloseModal}>
                <CloseXIcon />
              </TouchableOpacity>
            </View>
            <View style={{
              width: '100%',
              height: dimnensHeight(10),
              backgroundColor: '#F6F8FA',
              marginBottom: dimnensHeight(10)
            }} />
            <View style={styles.chooseTypeView}>
              <Text style={styles.textType}>Người được chuyển xử lý (*)</Text>
              <TouchableOpacity
                style={styles.typeChild}
                onPress={onOpenUserCCModal}
              >
                <Text style={styles.textFiltedType}>{userCCText}</Text>
                <RightBlueIcon />
              </TouchableOpacity>
            </View>
            <Text style={styles.textType}>Ý kiến</Text>
            <TextInputCustom
              placeholder="Vui lòng nhập ý kiến"
              placeholderTextColor={colors.grey999}
              multiline
              onChangeText={(text) => onChangeText(text)}
              value={text}
              style={styles.commentInput}
            />

          </View>
        </KeyboardAvoidingView>
      </TouchableWithoutFeedback>

      <UserGroupOnlyModal
        titleModal={"Người được chuyển xử lý"}
        modalVisible={userGroupModal}
        onCloseModal={onCloseUserGroupModal}
        onConfirmModal={(data) => onConfirmUserGroupModal(data)}
        isUser={true}
      />
    </ModalCusTom>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: "rgba(0,0,0,0.4)"
  },
  modalView: {
    height: dimnensHeight(640),
    width: dimensWidth(750),
    backgroundColor: 'white',
    borderRadius: 20,
    overflow: 'hidden'
  },
  chooseTypeView: {
    marginBottom: 15,
    borderRadius: 8,
  },
  flexDirection: {
    height: 67,
    flexDirection: "row",
    paddingHorizontal: dimensWidth(20),
    alignItems: "center",
  },
  stroke: {
    borderWidth: 0.5,
    borderColor: "#999",
  },
  textType: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: dimensWidth(20),
    marginVertical: 10,
  },
  tabBarLabelActive: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.LARGE,
  },
  textAssign: {
    color: colors.blueMedium,
    fontWeight: "700",
    fontSize: FontSize.LARGE,
  },
  viewAssign: {
    backgroundColor: colors.lightBlue,
    padding: 15,
  },
  titleBoss: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginHorizontal: dimensWidth(20),
    marginTop: dimnensHeight(10)
  },
  commentInput: {
    paddingHorizontal: 10,
    borderColor: colors.greyDDD,
    borderRadius: 3,
    height: 100,
    borderWidth: 1,
    marginHorizontal: dimensWidth(20),
    marginBottom: 10,
    textAlignVertical: "top",
  },
  typeChild: {
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "center",
    height: dimnensHeight(35),
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 3,
    marginHorizontal: dimensWidth(20),
    justifyContent: "space-between",
  },
  textFiltedType: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 9,
  }
});

export default SubmitBODModal