import React, { useState, useCallback, useEffect, } from 'react';
import { View, Text, } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { dimnensHeight, dimensWidth } from '~/base/Constants';
import colors from "../../base/Colors"
import { BASE_URL, } from '../../base/Constants'
import {
    isNullOrUndefined,
    arrayIsEmpty,
    byteConverter,
    format_dd_mm_yy,
    checkTypeFiles,
    DownloadFile,
    removeSpecialCharacters,
} from '../../base/Functions'
import styles from './VBDi.Detail.Style'
import { fetchAttchFiles, fetchDetailById, resetVBDiScreen, setIsLoadingScrollToIndexVbdi } from '~/base/stories/vbdi/reducer';
import { FlatList, TouchableOpacity } from 'react-native-gesture-handler';
import { Action } from './VBDi.Enum';
import { ActionMoreIcon, BoSungThongTinIcon, ClockWhiteIcon, DongYIcon, DownloadIcon, FowardProcesscon, ShareBlueIcon, ThreeDotIcon, ViewFileFull, YeuCauHieuChinhIcon } from '~/base/assets/svg';
import ActionModal from './components/Action.Modal';
import WorkflowHistory from './components/WorkflowHistory.Modal';
import WebView from 'react-native-webview';
import { LoadingView, TextInputCustom } from '~/base/components';
import FileModal from '~/base/components/File.Modal';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import PheDuyetModal from './components/PheDuyetModal'
import ThuHoiModal from './components/ThuHoiModal'
import DongYModal from './components/DongYModal'
import ChuyenXuLyModal from './components/ChuyenXuLyModal'
import YeuCauHieuChinhModal from './components/YeuCauHieuChinhModal'
import ChiaSeModal from './components/ChiaSeModal'
import BoSungThongTinModal from './components/BoSungThongTinModal'
import TraoDoiLaiModal from './components/TraoDoiLai'
import { onChangeSellecteDocumentIDbDiAction } from '~/base/stories/home/reducer';
import LinearGradientView from '~/base/components/LinearGradientView';
import FastImageCustom from '~/base/components/FastImageCustom';

const IconView = ({ ID }: any) => {
    if (ID === Action.ChiaSe)
        return <ShareBlueIcon color={colors.white} dimens={20} />;
    if (ID === Action.PheDuyet) return <DongYIcon />;
    if (ID === Action.YeuCauBoSung) return <BoSungThongTinIcon />;
    if (ID === Action.YeuCauHieuChinh) return <YeuCauHieuChinhIcon />;
    if (ID === Action.DongY) return <DongYIcon />;
    if (ID === Action.ThuHoi) return <BoSungThongTinIcon />;
    if (ID === Action.ChuyenXuLy) return <FowardProcesscon />;
    return <View />;
};

const ItemAction = ({ item, index, onActionPress }: any) => {
    if (index >= 3) return null;
    const { Title, ID } = item;
    return (
        <TouchableOpacity
            key={ID}
            style={styles.shareButton}
            onPress={() => onActionPress(item)}
        >
            <View style={styles.flexDirectionRowAction}>
                <IconView ID={ID} />
                <Text style={styles.tabBarLabelActive} numberOfLines={1}>
                    {Title}
                </Text>
            </View>
        </TouchableOpacity>
    );
};

const ItemFile = ({ item, index, selectedIndex, onItemPress, DownloadFile, token }: any) => {
    const {
        Title,
        Author,
        Created,
        Category,
        Size,
        Url
    } = item;

    const createdFormated = format_dd_mm_yy(Created);
    const FileIcon = useCallback(() => {
        return checkTypeFiles(Url);
    }, []);
    const fileSize = Size ? byteConverter(Size, 0) : null;
    const color = index % 2 == 0 ? colors.alice_blue : colors.white
    return (
        <TouchableOpacity onPress={() => onItemPress(index)} style={{
            flex: 1,
            flexDirection: 'row',
            height: dimnensHeight(40),
            backgroundColor: index % 2 == 0 ? colors.alice_blue : colors.white,
            alignItems: 'center'
        }}>
            <View style={{
                backgroundColor: selectedIndex === index ? colors.scienceBlue : color,
                width: dimensWidth(5),
                height: '100%',
                marginRight: dimensWidth(20)
            }} />
            <View style={{
                flex: 0.3
            }}>
                <FileIcon />
            </View>
            <Text style={styles.titleAttach}
                numberOfLines={1}>{Title}</Text>

            <Text style={styles.textFileSize}
                numberOfLines={1}>{fileSize}</Text>
            <Text style={styles.textCategory}
                numberOfLines={1}>{removeSpecialCharacters(Category)}</Text>

            <Text style={styles.textAuthor}
                numberOfLines={1}>{removeSpecialCharacters(Author)}</Text>

            <Text style={styles.textCreateDate}
                numberOfLines={1}>{createdFormated}</Text>

            <TouchableOpacity onPress={() => DownloadFile(item, token)} style={styles.touchDownload}>
                <View>
                    <DownloadIcon color={colors.scienceBlue} />
                </View>
            </TouchableOpacity>

        </TouchableOpacity>
    )
}

const ItemComment = ({ item, index, token, subSite }: any) => {
    const { Title, Value, ImagePath, Position, Created } = item;
    const createdFormated = format_dd_mm_yy(Created);
    const isOdd = index % 2 === 0;
    const positionFormat = !isNullOrUndefined(Position) ? Position.split(";#")[1] : "";
    return (
        <View
            style={{
                backgroundColor: isOdd ? colors.alice_blue : colors.white,
                padding: 15,
                flexDirection: 'row'
            }}>
            <FastImageCustom
                urlOnline={`${BASE_URL}/${subSite}/${ImagePath}`}
                styleImg={{ marginRight: dimensWidth(10) }}
            />
            <View style={styles.flexOne}>
                <Text style={styles.titleCommentJson}>{Title}</Text>
                <Text style={styles.positionComment}>{positionFormat}</Text>

                <Text style={styles.textValue}>{Value}</Text>
            </View>
            <Text style={styles.titleCommentJson}>{createdFormated}</Text>
        </View>
    );
}

const VBDiDetail = ({ route, navigation, selectedItemIndex }: any) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { dataDetail, dataFiles, token, isRefreshVBDiScreen, isLoadingVBDiDetail, isRefreshVBDiState, isLoadingScrollToIndex, } = useSelector((state: any) => state.vbdi);
    const { subSite } = useSelector((state: any) => state.login);
    const { dataVBDiMenu } = useSelector((state: any) => state.home);
    const [ItemVB, setItemVB] = useState<any>({})
    const [ItemId, setItemId] = useState(0)
    const [dataAttachFiles, setDataAttachFiles] = useState([])
    const [dropdownAction, setDropdownAction] = useState(false)
    const [actionTitle, setActionTitle] = useState("")
    const [modalWorkflowHistory, setModalWorkflowHistory] = useState(false)
    const [hiddenInfo, setHiddenInfo] = useState(false)
    const [dataAttachFileWebView, setDataAttachFileWebView] = useState({})
    const [comment, setComment] = useState("")
    const [fileModal, setFileModal] = useState(false)
    const [modalPheDuyet, setModalPheDuyet] = useState(false)
    const [modalYeuCauBoSung, setModalYeuCauBoSung] = useState(false)
    const [modalYeuCauHieuChinh, setModalYeuCauHieuChinh] = useState(false)
    const [modalDongY, setModalDongY] = useState(false)
    const [modalThuHoi, setModalThuHoi] = useState(false)
    const [modalChiaSe, setModalChiaSe] = useState(false)
    const [modalChuyenXuLy, setModalChuyenXuLy] = useState(false)
    const [selectIndexFile, setSeletedIndexFile] = useState(0)
    const fetchData = useCallback(async (Id: any, sub: any) => {
        dispatch(fetchDetailById({
            subSite: sub,
            ItemId: Id
        }));
        dispatch(fetchAttchFiles({
            subSite: sub,
            ItemId: Id
        }));
    }, [dispatch]);
    useEffect(() => {
        if (isRefreshVBDiScreen || isRefreshVBDiState) {
            fetchData(ItemId, subSite)
            dispatch(resetVBDiScreen(null))
        }
    }, [dispatch, ItemId, subSite, isRefreshVBDiScreen, isRefreshVBDiState])
    useEffect(() => {
        if (route.ItemId !== undefined) {
            setItemId(route.ItemId)
            fetchData(route.ItemId, subSite)
        }
    }, [dispatch, route.ItemId, subSite, selectedItemIndex,])

    const onActionPress = useCallback(
        (item: any) => {
            const { ID, Title } = item;
            setDropdownAction(false)
            setActionTitle(Title);
            if (ID === Action.PheDuyet) setModalPheDuyet(true)
            if (ID === Action.YeuCauBoSung) setModalYeuCauBoSung(true);
            if (ID === Action.YeuCauHieuChinh) setModalYeuCauHieuChinh(true);
            if (ID === Action.DongY) setModalDongY(true);
            if (ID === Action.ThuHoi) setModalThuHoi(true);
            if (ID === Action.ChiaSe) setModalChiaSe(true);
            if (ID === Action.ChuyenXuLy) setModalChuyenXuLy(true);
        },
        []
    );
    const onCloseModalWorkflowHistory = useCallback(() => {
        setModalWorkflowHistory(false)
    }, [modalWorkflowHistory, ItemId])

    const onHiddenInfo = useCallback(() => {
        setHiddenInfo(!hiddenInfo)
    }, [hiddenInfo])

    const onOpenDropdownAction = useCallback(() => {
        setDropdownAction(!dropdownAction)
    }, [dropdownAction])

    const onCommentChanged = useCallback((text: string) => {
        setComment(text)
    }, [comment])

    const onCloseFileModal = useCallback(() => {
        setFileModal(false)
    }, [fileModal])

    const onClosePheDuyetModal = useCallback(() => {
        setModalPheDuyet(false)
    }, [])
    const onCloseYeuCauBoSungModal = useCallback(() => {
        setModalYeuCauBoSung(false)
    }, [])
    const onCloseYeuCauHieuChinhModal = useCallback(() => {
        setModalYeuCauHieuChinh(false)
    }, [])
    const onCloseModalThuHoi = useCallback(() => {
        setModalThuHoi(false)
    }, [])

    const onCloseChiaSeModal = useCallback(() => {
        setModalChiaSe(false)
    }, [])
    const onCloseChuyenXuLy = useCallback(() => {
        setModalChuyenXuLy(false)
    }, [])
    const onCloseDongY = useCallback(() => {
        setModalDongY(false)
    }, [])

    useEffect(() => {
        if (!isNullOrUndefined(dataFiles)) {
            setDataAttachFiles(dataFiles)
            setDataAttachFileWebView(dataFiles[0])
        }
    }, [dataFiles])

    useEffect(() => {
        setItemVB(dataDetail)
        if (dataVBDiMenu.sellectedDocumentID === ItemId) {
            dispatch(setIsLoadingScrollToIndexVbdi(false))
            dispatch(onChangeSellecteDocumentIDbDiAction(null))
        }
        if (selectedItemIndex > 19 && !isNullOrUndefined(dataVBDiMenu.sellectedDocumentID)) {
            dispatch(setIsLoadingScrollToIndexVbdi(false))
            dispatch(onChangeSellecteDocumentIDbDiAction(null))
        }
    }, [ItemId, dataDetail, selectedItemIndex, dataVBDiMenu.sellectedDocumentID])

    const onItemFilePress = useCallback((index: number) => {
        const element = dataAttachFiles[index]
        setDataAttachFileWebView(element)
        setSeletedIndexFile(index)
    }, [dataAttachFiles, selectIndexFile])

    return (
        <View style={styles.flexOne}>
            <LinearGradientView style={{
                paddingLeft: dimensWidth(15),
                height: dimnensHeight(55),
                alignItems: 'center',
                flexDirection: 'row',
                justifyContent: 'flex-end',
                paddingRight: dimensWidth(15)
            }}>
                {!arrayIsEmpty(ItemVB?.ActionJson) && !isLoadingVBDiDetail && !isLoadingScrollToIndex ? (
                    <View style={[styles.actionView]}>
                        {ItemVB?.ActionJson.map((item: any, index: any) => {
                            return (
                                <ItemAction
                                    key={index}
                                    item={item}
                                    index={index}
                                    onActionPress={onActionPress}
                                />
                            );
                        })}
                        {ItemVB?.ActionJson.length > 3 && (
                            <TouchableOpacity
                                style={styles.actionMore}
                                onPress={onOpenDropdownAction}
                            >
                                <ActionMoreIcon />
                            </TouchableOpacity>
                        )}
                    </View>
                ) : null}
                {
                    !isLoadingVBDiDetail &&
                    <TouchableOpacity style={{
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}
                        onPress={() => { setModalWorkflowHistory(true) }}>
                        <ClockWhiteIcon />
                    </TouchableOpacity>
                }

            </LinearGradientView>
            <KeyboardAwareScrollView style={styles.containerKeyboard}>
                <View style={styles.headerView}>
                    <View style={{
                        flex: 1,
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <Text style={styles.txtTrichYeu}>{ItemVB?.TrichYeu}</Text>
                        <TouchableOpacity onPress={onHiddenInfo}>
                            <ThreeDotIcon color={!hiddenInfo ? "#C5C5C5" : colors.scienceBlue} />
                        </TouchableOpacity>
                    </View>
                    {
                        hiddenInfo ? <View style={{ marginTop: dimnensHeight(20) }} /> : <View>
                            <View style={styles.fullInfoView} />
                            <View style={styles.flexRowInfo}>
                                <View style={styles.flexOne}>
                                    <View>
                                        <Text style={styles.titleDoc}>Loại văn bản</Text>
                                        <Text style={styles.valueDoc}>{!isNullOrUndefined(ItemVB?.LoaiVanBan) ? ItemVB?.LoaiVanBan.split(';#')[1] : ''}</Text>
                                    </View>
                                </View>
                                <View style={styles.flexOne}>
                                    <View>
                                        <Text style={styles.titleDoc}>Đơn vị soạn thảo</Text>
                                        <Text style={styles.valueDoc}>{!isNullOrUndefined(ItemVB?.DonVi) ? ItemVB?.DonVi.split(';#')[1] : ''}</Text>
                                    </View>
                                </View>
                            </View>
                        </View>
                    }
                    {
                        arrayIsEmpty(dataFiles) ? <View /> :
                            <View>
                                <View style={styles.FileContainer}>
                                    <WebView
                                        source={{ uri: BASE_URL + dataAttachFileWebView?.Url }}
                                        style={styles.flexOne}
                                        sharedCookiesEnabled
                                    />
                                    <View style={styles.touchFullInfo}>
                                        <TouchableOpacity onPress={() => setFileModal(true)}>
                                            <ViewFileFull />
                                        </TouchableOpacity>
                                    </View>

                                </View>
                                <Text style={styles.fileAttachText}>Tài liệu đính kèm</Text>
                                <FlatList
                                    style={styles.flatlistFileAttach}
                                    data={dataAttachFiles}
                                    renderItem={({ item, index }) => (
                                        <ItemFile item={item} index={index} oken={token}
                                            selectedIndex={selectIndexFile}
                                            onItemPress={onItemFilePress}
                                            DownloadFile={(item: any) => DownloadFile(item, token)} />
                                    )}
                                    extraData={dataAttachFiles}
                                    disableVirtualization
                                    nestedScrollEnabled
                                    scrollEnabled={false}
                                    keyExtractor={(item, index) => String(index)}
                                />
                            </View>
                    }
                    <View>
                        <Text style={styles.textYKien}>Ý kiến lãnh đạo</Text>

                        <TextInputCustom
                            editable={true}
                            placeholder="Vui lòng nhập ý kiến"
                            placeholderTextColor={colors.grey999}
                            multiline
                            onChangeText={onCommentChanged}
                            style={styles.commentInput}
                        />
                        {!arrayIsEmpty(ItemVB?.CommentJson) && (
                            <FlatList
                                nestedScrollEnabled
                                scrollEnabled={false}
                                style={styles.commentJsonFlatlist}
                                extraData={ItemVB?.CommentJson}
                                disableVirtualization
                                horizontal={false}
                                keyExtractor={(item, index) => index.toString()}
                                data={ItemVB?.CommentJson}
                                renderItem={({ item, index }) => (
                                    <ItemComment item={item} index={index} />
                                )}
                            />
                        )}
                    </View>
                </View>
            </KeyboardAwareScrollView>
            <LoadingView isLoading={isLoadingVBDiDetail || isLoadingScrollToIndex} bgColor={colors.white} viewLoadingStyle={{ top: dimnensHeight(55) }} />
            <ActionModal
                modalVisible={dropdownAction}
                Actions={ItemVB?.ActionJson}
                onActionPress={onActionPress}
                onCloseModal={onOpenDropdownAction} />

            <WorkflowHistory
                modalVisible={modalWorkflowHistory}
                onCloseModal={onCloseModalWorkflowHistory}
                ItemId={route.ItemId} />

            <FileModal
                modalVisible={fileModal}
                onCloseModal={onCloseFileModal}
                value={dataAttachFileWebView}
            />
            <PheDuyetModal
                modalVisible={modalPheDuyet}
                ItemId={ItemId}
                actionTitle={actionTitle}
                BanLanhDao={ItemVB?.BanLanhDao}
                onCloseForwardModal={onClosePheDuyetModal}
                yKienLanhDao={comment} />
            <BoSungThongTinModal
                modalVisible={modalYeuCauBoSung}
                ItemId={ItemId}
                onCloseForwardModal={onCloseYeuCauBoSungModal}
                yKienLanhDao={comment} />

            <ChiaSeModal
                modalVisible={modalChiaSe}
                ItemId={ItemId}
                onCloseModal={onCloseChiaSeModal}
                Comment={comment}
            />
            <ChuyenXuLyModal
                modalVisible={modalChuyenXuLy}
                ItemId={ItemId}
                onCloseForwardModal={onCloseChuyenXuLy}
                yKienLanhDao={comment}
            />
            <DongYModal
                modalVisible={modalDongY}
                ItemId={ItemId}
                onCloseForwardModal={onCloseDongY}
                actionTitle={actionTitle}
            />
            <TraoDoiLaiModal
                modalVisible={modalPheDuyet}
                ItemId={ItemId}
                BanLanhDao={ItemVB?.BanLanhDao}
                onCloseForwardModal={onClosePheDuyetModal}
                yKienLanhDao={comment} />
            <ThuHoiModal
                modalVisible={modalThuHoi}
                ItemId={ItemId}
                onCloseForwardModal={onCloseModalThuHoi}
            />
            <YeuCauHieuChinhModal
                modalVisible={modalYeuCauHieuChinh}
                ItemId={ItemId}
                onCloseForwardModal={onCloseYeuCauHieuChinhModal}
                yKienLanhDao={comment} />
        </View>
    )
}

export default React.memo(VBDiDetail)