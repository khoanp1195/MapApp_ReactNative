import { StyleSheet } from "react-native";
import colors from "~/base/Colors";
import { FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
  containerKeyboard: {
    flex: 1,
    backgroundColor: colors.white,
  },
  thongTinLuanChuyen: { padding: 3 },
  scrollView: {
    flex: 1,
    paddingBottom: 30,
  },
  cardView: {
    backgroundColor: "#FFFFFF",
    margin: 16,
    borderRadius: 8,
    paddingVertical: 15,
  },
  threeDotView: {
    alignSelf: "flex-end",
    marginRight: 10,
    padding: 10,
  },
  item: {},
  containerAttach: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    marginHorizontal: 15,
    overflow: "hidden",
  },
  dashed: {
    //borderStyle: "dashed",
    borderTopWidth: 1,
    borderTopColor: "#E5E5E5",
    marginVertical: 15,
  },
  flexOne: {
    flex: 1,
  },
  content: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginBottom: 10,
  },
  contenAttach: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginTop: 5,
  },
  title: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  documentFile: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginLeft: 15,
    marginBottom: 10,
  },
  documentFileView: {
    padding: 15,
  },
  viewHeader: {
    backgroundColor: colors.primary,
    height: 55,
    justifyContent: "center",
    width: "100%",
    paddingRight: 15,
    paddingLeft: 7,
  },
  titleHeader: {
    fontSize: FontSize.MEDIUM,
    color: colors.scienceBlue,
    fontWeight: "700",
    fontFamily: "arial",
    paddingHorizontal: 15,
  },
  titleDocumentFile: {
    fontSize: FontSize.MEDIUM,
    color: colors.scienceBlue,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    borderRadius: 4,
  },
  sizeDocumentFile: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    borderRadius: 4,
  },
  flexDirectionRowBetween: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  flexDirectionRowAction: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginRight: dimensWidth(30)
  },
  backPress: {
    padding: 8,
  },
  tabBarLabelActive: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.LARGE,
    marginLeft: 12,
  },
  viewTabBottomBar: {
    flexDirection: "row",
    height: dimensWidth(68),
    alignItems: "center",
    backgroundColor: colors.blueMedium,
  },
  bottomTab: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
  },
  viewButton: {
    flex: 1,
    alignItems: "center",
  },
  actionMore: {
    padding: 8,
  },
  actionView: {
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    marginRight: dimensWidth(30),
  },
  shareButton: {
    flex: 1,
  },
  commentInput: {
    paddingHorizontal: 10,
    borderColor: "#DDDDDD",
    borderWidth: 1,
    borderRadius: 3,
    height: 100,
    textAlignVertical: "top",
    marginTop: dimnensHeight(15)
  },
  titleVbDenTheoMuc: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    borderRadius: 4,
  },
  titleCommentJson: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    borderRadius: 4,
  },
  positionComment: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    borderRadius: 4,
    marginTop: dimnensHeight(5)
  },
  viewTrangThai: {
    height: dimensWidth(22),
    width: dimensWidth(90),
    borderRadius: 3,
    backgroundColor: "#F0F0F0",
    justifyContent: "center",
    alignItems: "center",
  },
  textTrangThai: {
    fontSize: dimensWidth(12),
    color: "#626262",
    fontWeight: "400",
    fontFamily: "arial",
  },
  danhMucItemView: {
    backgroundColor: colors.white,
    padding: 15,
  },
  hoanTatTextColor: {
    color: "#3ABA32",
  },
  hoanTatBackGroundColor: {
    backgroundColor: "#E6FFE4",
  },
  danhMucFlatList: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    overflow: "hidden",
  },
  commentJsonFlatlist: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    marginTop: dimnensHeight(15),
    overflow: "hidden",
  },
  yKienLanhDaoTouch: {
    zIndex: 999,
    position: "absolute",
    height: "100%",
    width: "100%",
  },
  titleDoc: {
    fontSize: FontSize.SMALL,
    color: '#5E5E5E',
    lineHeight: 16,
    fontWeight: '400'
  },
  valueDoc: {
    fontSize: FontSize.MEDIUM,
    fontWeight: '400',
    color: '#19191E',
    marginTop: dimnensHeight(13),
    marginBottom: dimensWidth(22)
  },
  headerView: {
    paddingLeft: dimensWidth(15),
    paddingRight: dimensWidth(15),
    paddingTop: dimnensHeight(20),
    paddingBottom: dimnensHeight(20)
  },
  txtTrichYeu: {
    color: '#005FD4',
    fontWeight: 700,
    fontSize: FontSize.LARGE_X,
    flex: 1,
  },
  fullInfoView: {
    width: '100%',
    height: 1,
    backgroundColor: '#B3B3B3',
    marginTop: dimnensHeight(15)
  },
  flexRowInfo: {
    flex: 1,
    flexDirection: 'row',
    marginTop: dimnensHeight(20)
  },
  FileContainer: {
    flex: 1,
    width: '100%',
    height: dimnensHeight(350),
    backgroundColor: 'white',
    borderRadius: 8,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 1
    },
    shadowRadius: 4,
    shadowOpacity: 0.3,
  },
  touchFullInfo: {
    position: 'absolute',
    alignSelf: 'flex-end',
    bottom: 15,
    right: 15
  },
  fileAttachText: {
    marginTop: dimnensHeight(20),
    marginBottom: dimnensHeight(15),
    fontSize: FontSize.LARGE_X,
    color: '#000000',
    fontWeight: 700
  },
  flatlistFileAttach: {
    borderWidth: 1,
    borderRadius: 4,
    borderColor: '#DDDDDD'
  },
  textYKien: {
    marginTop: dimnensHeight(20),
    color: '#000000',
    fontSize: FontSize.LARGE,
    fontWeight: 700
  },
  titleAttach: {
    flex: 2,
    color: '#015DD1',
    fontSize: FontSize.MEDIUM,
    fontWeight: '400'
  },
  textFileSize: {
    flex: 0.5,
    color: colors.lightBlack,
    fontSize: FontSize.SMALL,
    marginLeft: dimensWidth(10)
  },
  textCategory: {
    flex: 1,
    color: '#000000',
    fontSize: FontSize.MEDIUM,
    marginLeft: dimensWidth(10)
  },
  textAuthor: {
    flex: 1,
    color: '#000000',
    fontSize: FontSize.MEDIUM,
  },
  textCreateDate: {
    flex: 0.8,
    color: colors.lightBlack,
    fontSize: FontSize.SMALL,
  },
  touchDownload: {
    marginRight: dimensWidth(10)
  },
  textValue: {
    marginTop: dimnensHeight(10),
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    borderRadius: 4,
  }
});

export default styles