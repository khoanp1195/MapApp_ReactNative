export enum Action {
    null,
    DongY = 1,
    PheDuyet = 2,
    ChuyenXuLy = 4,
    YeuCauHieuChinh = 8,
    TuChoi = 16,
    ThuHoi = 32,
    YeuCauBoSung = 64,
    ThuHoiDaPheDuyet = 128,
    ChiaSe = 256,
  }
  export enum TaskVB {
    Luu = 1,
    PhanCong = 2,
    TraoDoiLai = 16,
    HoanTat = 32
  }
  export enum EnumPhancong {
    null,
    PhongBan = 0,
    ToChucPhanCong = 1,
    PhongBanPhanCongLai = 2,
    BoSungThuHoi = 128
  }
  export enum RoleVBDen {
    NguoiXem = 0,
    NguoiGiaoViec = 256 || 320,
    NguoiXuLy = 64
  }
  export enum EnumNguoiGiaoViecVBDen {
    Luu = 1,
    TraoDoiLai = 16,
  } 
  export enum TABNAME {
    VBChoXuLy = "VB chờ xử lý",
    VBDaXuLy = "VB đã xử lý",
  }