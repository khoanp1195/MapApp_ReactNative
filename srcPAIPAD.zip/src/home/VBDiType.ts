export enum ActionJsonType {
  null,
  DongY = 1,
  PheDuyet = 2,
  ChuyenXuLy = 4,
  YeuCauHieuChinh = 8,
  TuChoi = 16,
  ThuHoi = 32,
  YeuCauBoSung = 64,
  ChiaSe = 256,
}
export enum TaskVB {
  Luu = 1,
  PhanCong = 2,
  TraoDoiLai = 16,
  HoanTat = 32
}
export enum EnumPhancong {
  null,
  PhongBan = 0,
  ToChucPhanCong = 1,
  PhongBanPhanCongLai = 2,
  BoSungThuHoi = 128
}
export enum RoleVBDen {
  NguoiXem = 0,
  NguoiGiaoViec = 256 || 320,
  NguoiXuLy = 64
}
export enum EnumNguoiGiaoViecVBDen {
  Luu = 1,
  TraoDoiLai = 16,
} 
export enum TABNAME {
  VBChoXuLy = "VB chờ xử lý",
  VBDaXuLy = "VB đã xử lý",
}
export enum LoaiFilterType {
  TAT_CA = "Tất cả",
  CHO_PHE_DUYET = "Chờ phê duyệt",
  DA_PHE_DUYET = "Đã phê duyệt",
  DA_BAN_HANH = "Đã phát hành"
}