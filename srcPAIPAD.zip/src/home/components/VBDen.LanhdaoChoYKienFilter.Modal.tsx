import React, { FC, useState, useCallback, useMemo, useEffect } from "react";
import {
    Modal,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    KeyboardAvoidingView,
} from "react-native";
import { FlatList } from "react-native-gesture-handler";
import colors from "~/base/Colors";
import { FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";
import { BackIcon, CloseXIcon, SelectedDisableIcon, SelectedEnalbleIcon } from "~/base/assets/svg";
import { useDispatch, useSelector } from "react-redux";
import { fetchBanLanhDao } from "~/base/stories/data/reducer";
import { RootState } from "~/base/stories";
import { TrinhLanhDaoTypeProps } from "../VBDenType";
import { ThunkDispatch } from "redux-thunk";
import ModalCusTom from "~/base/components/ModalCusTom";
interface Props {
    modalVisible: Boolean;
    defaultValue: any;
    onCloseModal: () => void;
    onConfirmModal: (data: any) => void;
}

const HomeDocumentTypeModal: FC<Props> = ({
    modalVisible,
    onCloseModal,
    onConfirmModal,
    defaultValue,
    ...props
}: Props) => {
    const { subSite } = useSelector((state: RootState) => state.login);
    const { dataBanLanhDao } = useSelector((state: RootState) => state.data);
    const [banLanhDaoState, setBanLanhDaoState] = useState<any>([])
    const [sellecteId, setSelectId] = useState(999)
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();

    const Item = ({
        item,
        chooseTypePress,
        index,
        sellecteId,
    }: any) => {
        const { Title, ID, } = item;
        return (
            <TouchableOpacity
                style={[styles.item, index === 0 && { borderTopWidth: 0 }]}
                onPress={() => chooseTypePress(item)}
            >
                <View>
                    <Text style={styles.Title}>{Title}</Text>
                </View>
                <View>
                    {sellecteId == ID ? <SelectedEnalbleIcon /> : <SelectedDisableIcon />}
                </View>
            </TouchableOpacity>
        );
    };

    const chooseTypePress = useCallback(
        (item: any) => {
            setSelectId(item.ID)
            onConfirmModal(item)
        },
        []
    );
    const fetchBanLanhDaoRequest = useCallback(async () => {
        dispatch(fetchBanLanhDao(subSite));
    }, [dispatch]);
    useEffect(() => {
        fetchBanLanhDaoRequest();
    }, [fetchBanLanhDaoRequest, subSite]);

    useEffect(() => {
        const newData = [{ ID: 999, Title: TrinhLanhDaoTypeProps.TAT_CA }, ...dataBanLanhDao]
        setBanLanhDaoState(newData);
    }, [dataBanLanhDao])
    useEffect(() => {
        setSelectId(defaultValue?.ID)
    }, [defaultValue])

    return (
        <ModalCusTom transparent={true}
            visible={modalVisible}
            {...props}
            onCloseModalCustom={onCloseModal}
            style={styles.centeredView}>

            <KeyboardAvoidingView style={styles.centeredView}>
                <View style={styles.modalView}>
                    <View style={{
                        padding: dimensWidth(20),
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'center',
                        backgroundColor: 'white'
                    }}>
                        <TouchableOpacity onPress={onCloseModal}>
                            <BackIcon />
                        </TouchableOpacity>
                        <Text style={{
                            flex: 1,
                            color: '#005FD4',
                            fontSize: FontSize.LARGE_X,
                            fontWeight: 700,
                            marginLeft: dimensWidth(15)
                        }}>Lãnh đạo cho ý kiến</Text>


                        <TouchableOpacity onPress={onCloseModal}>
                            <CloseXIcon />
                        </TouchableOpacity>

                    </View>

                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        backgroundColor: '#F6F8FA'
                    }} />

                    <FlatList
                        contentContainerStyle={styles.flatlist}
                        data={banLanhDaoState}
                        extraData={banLanhDaoState || sellecteId}
                        renderItem={({ item, index }) => (
                            <Item
                                index={index}
                                item={item}
                                chooseTypePress={chooseTypePress}
                                sellecteId={sellecteId}
                            />
                        )}
                        keyExtractor={(item) => item.ID}
                    />
                </View>
            </KeyboardAvoidingView>
        </ModalCusTom>
    )
}

const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(0,0,0,0.4)"
    },
    modalView: {
        height: dimnensHeight(650),
        width: dimensWidth(700),
        backgroundColor: '#F6F8FA',
        borderRadius: 20,
        overflow: 'hidden'
    },
    item: {
        flexDirection: "row",
        justifyContent: "space-between",
        padding: dimensWidth(20),
    },
    Title: {
        fontSize: FontSize.LARGE,
        lineHeight: dimensWidth(20),
        color: colors.black,
        fontWeight: "400",
        fontFamily: "arial",
    },
    flatlist: {
        backgroundColor: "#FFFFFF",
        borderRadius: 8,
    }
});

export default HomeDocumentTypeModal