import React, { useState, useCallback, useEffect, } from 'react';
import { View, Text, ActivityIndicator, RefreshControl } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { dimnensHeight, dimensWidth } from '~/base/Constants';
import Colors from "../base/Colors"
import { BASE_URL, FontSize } from '../base/Constants'
import {
    isNullOrUndefined, calculateBetweenTwoDate,
    formatCreatedDate,
    arrayIsEmpty,
    checkIsEmpty,
    format_dd_mm_yy,
} from '../base/Functions'
import { FlatList, TouchableOpacity } from 'react-native-gesture-handler';
import styles from './Home.Procesing.Style';
import { fetchDataProcessing, fetchNotification } from '../base/stories/home/reducer'
import { LoadingView, NoDataView, TextCusTom, TopBarTab, } from '~/base/components';
import VBDenDetail from '~/detail/vbden/VBDen.Detail.Screen';
import VBDiDetail from '~/detail/vbdi/VBDi.Detail.Screen';
import VBBHDetail from '~/detail/vbbh/VBBH.Detail.Screen';
import LinearGradient from 'react-native-linear-gradient';
import colors from '../base/Colors';
import { FilterIcon, LaCoIcon, MenuIcon, SearchIcon } from '~/base/assets/svg';
import SearchInput from '~/search/components/SearchInput';
import HomeFilterModal from './components/Home.Filter.Modal';
import { RootState } from '~/base/stories';
import { useIsFocused } from '@react-navigation/native';
import FastImageCustom from '~/base/components/FastImageCustom';

const ItemLeft = ({ item, index, subSite, token, gotoDetail, selectedItemIndex, isVBChoXuLy }: any) => {
    const {
        ID,
        Title,
        SendUnit,
        ImagePath,
        Action,
        DocumentID,
        Category,
        Created,
        Priority,
        Read,
        ListName,
        DueDate,
        TaskCategory,
    } = item
    const gotoDetailPress = () => {
        gotoDetail(item, index);
    };

    const formatCreated = formatCreatedDate(Created);
    let dueDateFormat = ""
    let isExpired = false
    let isExpiredToday = false
    const distanceDate = calculateBetweenTwoDate(DueDate);
    if (!checkIsEmpty(distanceDate)) {
        if (parseInt(distanceDate) < 0) {
            dueDateFormat = format_dd_mm_yy(DueDate);
        } else if (parseInt(distanceDate) >= 0 && parseInt(distanceDate) < 1) {
            dueDateFormat = "Hạn hôm nay";
            isExpiredToday = true
        }
        else {
            isExpired = true
            dueDateFormat = "Quá hạn " + distanceDate + " ngày";
        }
    }
    const ListNameFormat = ListName === "List Văn bản đi" ? "Văn bản đi" : ListName
    return (
        <TouchableOpacity onPress={gotoDetailPress}>
            <View style={{
                flex: 1,
                flexDirection: 'row',
                marginHorizontal: dimensWidth(15),
            }}>
                <View style={styles.item}>
                    <View style={{
                        width: dimensWidth(5),
                        backgroundColor: selectedItemIndex == index ? '#015DD1' : null,
                    }} />

                    <View style={{
                        flex: 1,
                        flexDirection: 'row',
                        padding: dimensWidth(15),
                        borderRadius: 8,
                        justifyContent: 'center',
                    }}>
                        <FastImageCustom
                            styleImg={styles.itemAvatar}
                            urlOnline={`${BASE_URL}/${subSite}/${ImagePath}`}
                        />
                        <View style={{ flex: 1 }}>
                            <View style={styles.flexDirectionBetween}>
                                <TextCusTom style={styles.title} numberOfLines={1}>
                                    {SendUnit}
                                </TextCusTom>
                                <TextCusTom style={styles.date}>{formatCreated}</TextCusTom>
                            </View>

                            <View style={{
                                flex: 1,
                                flexDirection: 'row',
                                justifyContent: 'space-between',
                            }}>
                                <TextCusTom style={styles.category}>{ListNameFormat}</TextCusTom>
                                <TextCusTom style={styles.category} numberOfLines={1}>{TaskCategory}</TextCusTom>
                            </View>
                            <TextCusTom style={styles.title} numberOfLines={2}>{Title}</TextCusTom>
                            <View style={styles.flexDirectionBetween}>
                                <View style={styles.touchSendUnit}>
                                    <TextCusTom style={styles.textSendUnit}>{Action}</TextCusTom>
                                </View>
                                <View style={{ flex: 1, marginLeft: 10 }}>
                                    {(item?.Priority ==
                                        1) && <LaCoIcon />}
                                </View>
                                <TextCusTom
                                    style={[
                                        styles.date,
                                        isExpiredToday && styles.todayDeadlife,
                                        isExpired && styles.distanceDate,
                                    ]}
                                >
                                    {isVBChoXuLy ? dueDateFormat : ""}
                                </TextCusTom>
                            </View>
                        </View>
                    </View>

                </View>
            </View>

        </TouchableOpacity>
    )
}

const HomeNotification = ({ route, navigation }: any) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { subSite, token } = useSelector(
        (state: RootState) => state.login);

    const { dataNotification, isLoading } = useSelector(
        (state: RootState) => state.home);

    const [dataProcessing, setDataProcessing] = useState([])
    const [offset, setOffset] = useState(0)
    const [status, setStatus] = useState(0)
    const [totalRecordString, setTotalRecordString] = useState("0")
    const [Item, setItem] = useState<any>({})
    const [selectedItemIndex, setSelectedItemIndex] = useState(null)
    const [isShowSearch, setIsShowSearch] = useState(false)
    const [textSearch, setTextSearch] = useState("")
    const [modalFilter, setModalFilter] = useState(false)
    const [documentType, setDocumentType] = useState("")
    const [fromDate, setFromDate] = useState("")
    const [toDate, setToDate] = useState("")
    const [isRefresh, setIsRefresh] = useState(false)
    const isFocused = useIsFocused();
    const [isDefaultFilter, setIsDefaultFilter] = useState(true)
    
    useEffect(() => {
        if (isNullOrUndefined(fromDate) && isNullOrUndefined(toDate) && documentType == "Tất cả") {
            setIsDefaultFilter(true)
        } else {
            setIsDefaultFilter(false)
        }
    }, [fromDate, toDate, documentType,])

    const fetchDataLeftList = useCallback(async (
        status: number,
        offset: number,
        subSite: string,
        FilterText: string,
        DocumentType: string,
        FromDate: string,
        ToDate: string
    ) => {
        dispatch(fetchNotification({
            offset: offset,
            status: status,
            subSite: subSite,
            FilterText,
            DocumentType,
            FromDate,
            ToDate
        }));
    }, [dispatch, offset]);

    const onRefresh = useCallback(() => {
        setIsRefresh(true)
        setOffset(0)
        fetchDataLeftList(0,
            status,
            subSite,
            textSearch,
            documentType,
            fromDate,
            toDate)
        setIsRefresh(false)
    }, [dispatch, subSite, status, textSearch, documentType, fromDate, toDate])

    const onPressTabProcessing = useCallback(() => {
        setStatus(0)
        setOffset(0)
    }, []);

    const onPressTabProcessed = useCallback(() => {
        setStatus(1)
        setOffset(0)
    }, []);

    useEffect(() => {
        if (isFocused) {
            fetchDataLeftList(status, offset, subSite, textSearch, documentType, fromDate, toDate)
        }
    }, [dispatch, isFocused, status, offset, subSite, textSearch, documentType, fromDate, toDate]);

    useEffect(() => {
        setDataProcessing(dataNotification.data)
        if (!isNullOrUndefined(dataNotification.data)) {
            if (offset == 0) {
                setSelectedItemIndex(0)
                setItem(dataNotification.data[0])
            }
        }

        if (status == 0 && !isLoading) {
            setTotalRecordString(dataNotification.totalRecord)
        }
    }, [dataNotification, offset, isLoading]);

    const gotoDetailPress = useCallback((item, index) => {
        setSelectedItemIndex(index)

        setItem(item)
    }, []);

    const handleLoadmore = async () => {
        if (!arrayIsEmpty(dataProcessing)) {
            setOffset(dataProcessing.length);
        }
    };

    const openDrawer = useCallback(() => {
        navigation.openDrawer();
    }, [navigation]);

    const onSearchPress = useCallback(() => {
        setIsShowSearch(!isShowSearch)
    }, [isShowSearch])

    const onChangeFilterText = useCallback(
        (text: string) => {
            setTextSearch(text);
            setOffset(0)
        },
        [textSearch]
    );
    const onCloseFilterModal = useCallback(() => {
        setModalFilter(false)
    }, [modalFilter])

    const onConfirmFilterModal = useCallback((data) => {
        if (!isNullOrUndefined(data)) {
            setDocumentType(data.DocumentType === "Tất cả" ? "" : data.DocumentType)
            setToDate(data.ToDate)
            setFromDate(data.FromDate)
            setOffset(0)
        }

        setModalFilter(false)
    }, [])
    const renderFooter = (loading: boolean) => {
        return (
            <View style={{
                padding: 10,
                justifyContent: 'center',
                alignItems: 'center',
                flexDirection: 'row'
            }}>
                {loading ? (
                    <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
                ) : null}
            </View>
        );
    };
    const renderEmpty = () => {
        if (isLoading) return <LoadingView isLoading={isLoading} />
        return (
            <NoDataView />
        )
    }
    return (
        <View style={{
            flex: 1,
            backgroundColor: Colors.gray
        }}>
            <View style={{
                flex: 1,
                flexDirection: 'row',
            }}>
                <View style={{
                    width: '35%'
                }}>
                    <LinearGradient style={{
                        paddingLeft: dimensWidth(15),
                        height: dimnensHeight(55),
                    }}
                        colors={["#0262E9", "#0054AE"]}>
                        <View style={{
                            flex: 1,
                            flexDirection: 'row',
                            alignItems: "center",
                        }}>
                            <TouchableOpacity onPress={openDrawer} style={{
                                marginRight: dimensWidth(10),
                            }}>
                                <MenuIcon color={'#fff'} />
                            </TouchableOpacity>

                            <View style={{ flex: 1 }}>
                                <TextCusTom style={{
                                    color: Colors.white,
                                    fontSize: FontSize.LARGE,
                                    fontWeight: '400',
                                    fontFamily: 'arial',
                                }}>{subSite.toUpperCase()}</TextCusTom>
                                <TextCusTom style={{
                                    color: Colors.white,
                                    fontSize: FontSize.MEDIUM,
                                    fontWeight: '400',
                                    fontFamily: 'arial',
                                    marginTop: dimnensHeight(2)
                                }}>Trang chủ / Thông báo</TextCusTom>
                            </View>
                            <TouchableOpacity style={styles.filterIcon} onPress={() => setModalFilter(true)}>
                            <FilterIcon color={isDefaultFilter ? colors.white : colors.red}/>
                            </TouchableOpacity>
                            <View style={{
                                height: '50%',
                                width: 1,
                                backgroundColor: 'white'
                            }} />
                        </View>
                    </LinearGradient>
                    <TopBarTab
                        isShowSearch={isShowSearch}
                        textSearch={textSearch}
                        onChangeFilterText={onChangeFilterText}
                        onPressTabProcessing={onPressTabProcessing}
                        status={status}
                        totalRecordString={totalRecordString}
                        onPressTabProcessed={onPressTabProcessed}
                        onSearchPress={onSearchPress}
                    />
                    {
                        !arrayIsEmpty(dataProcessing) ?
                            <FlatList
                                data={dataProcessing}
                                extraData={selectedItemIndex || dataProcessing}
                                refreshControl={
                                    <RefreshControl refreshing={isRefresh} onRefresh={onRefresh} tintColor='#0054AE' />
                                }
                                onEndReachedThreshold={0.5}
                                onEndReached={handleLoadmore}
                                showsVerticalScrollIndicator={true}
                                keyExtractor={(item, index) => index.toString()}
                                ListFooterComponent={renderFooter(isLoading)}
                                renderItem={({ item, index }) => (
                                    <ItemLeft
                                        item={item}
                                        index={index}
                                        subSite={subSite}
                                        token={token}
                                        gotoDetail={gotoDetailPress}
                                        selectedItemIndex={selectedItemIndex}
                                        isVBChoXuLy={status === 0}
                                    />
                                )} /> : renderEmpty()
                    }
                </View>
                <View style={{
                    width: '65%',
                }}>
                    {(!isNullOrUndefined(Item)) && (Item.ListName == "Văn bản đi" || Item.ListName == "List Văn bản đi") ? <VBDiDetail route={{
                        ItemId: Item.DocumentID
                    }} navigation={navigation} sellectedIndex={selectedItemIndex} /> : (!isNullOrUndefined(Item) && Item.ListName == "Văn bản đến") ? <VBDenDetail route={{
                        ItemId: Item.DocumentID
                    }} navigation={navigation} sellectedIndex={selectedItemIndex} /> :
                        (!isNullOrUndefined(Item) && Item.ListName == "Văn bản ban hành") ? <VBBHDetail route={{
                            ItemId: Item.DocumentID
                        }} navigation={navigation} sellectedIndex={selectedItemIndex} /> : (<View style={{ flex: 1 }}>
                            <LinearGradient style={{
                                paddingLeft: dimensWidth(15),
                                height: dimnensHeight(55),
                                alignItems: 'center',
                                flexDirection: 'row',
                                justifyContent: 'flex-end',
                                paddingRight: dimensWidth(15)
                            }}
                                colors={["#0262E9", "#0054AE"]} />
                            <NoDataView />
                        </View>)}
                </View>
            </View>
            <HomeFilterModal
                modalVisible={modalFilter}
                onCloseModal={onCloseFilterModal}
                onConfirmModal={(data) => onConfirmFilterModal(data)}
            />
        </View>
    )
}

export default HomeNotification