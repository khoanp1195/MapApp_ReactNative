import React, { useState, useCallback, useEffect, } from 'react';
import { View, Text, ActivityIndicator, Alert } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { dimnensHeight, dimensWidth, funtionVBDiData } from '~/base/Constants';
import Colors from "../base/Colors"
import { BASE_URL, FontSize } from '../base/Constants'
import {
    isNullOrUndefined, calculateBetweenTwoDate,
    formatCreatedDate,
    arrayIsEmpty,
    checkIsEmpty,
    format_dd_mm_yy,
    isNullOrEmpty,
    removeSpecialCharacters,
} from '../base/Functions'
import { FlatList, RefreshControl, TouchableOpacity } from 'react-native-gesture-handler';
import styles from './Home.Procesing.Style';
import { LoadingView, NoDataView, TopBarTab, } from '~/base/components';
import VBDiDetail from '~/detail/vbdi/VBDi.Detail.Screen';
import LinearGradient from 'react-native-linear-gradient';
import colors from '../base/Colors';
import { FilterIcon, LaCoIcon, MenuIcon, SearchIcon } from '~/base/assets/svg';
import SearchInput from '~/search/components/SearchInput';
import { RootState } from '~/base/stories';
import VbDiFilterModal from './components/VbDi.Filter.Modal';
import { LoaiFilterType } from './VBDiType';
import { fetchVBDiMenu, onChangeSellecteDocumentIDbDiAction, onRefreshVbDiMenuAction } from '~/base/stories/home/reducer';
import { useIsFocused } from '@react-navigation/native';
import { resetVBDiScreen } from '~/base/stories/vbdi/reducer';
import FastImageCustom from '~/base/components/FastImageCustom';

const ItemLeft = ({ item, index, subSite, token, gotoDetail, selectedItemIndex }: any) => {
    const {
        ID,
        Title,
        ActionStatus,
        TrichYeu,
        DueDate,
        Created,
        Author,
        ImagePath,
    } = item
    const gotoDetailPress = () => {
        gotoDetail(item, index, "Văn bản đi");
    };

    const formatCreated = formatCreatedDate(Created);
    let dueDateFormat = ""
    let isExpired = false
    let isExpiredToday = false
    const distanceDate = calculateBetweenTwoDate(DueDate);
    if (!checkIsEmpty(distanceDate)) {
        if (parseInt(distanceDate) < 0) {
            dueDateFormat = format_dd_mm_yy(DueDate);
        } else if (parseInt(distanceDate) >= 0 && parseInt(distanceDate) < 1) {
            dueDateFormat = "Hạn hôm nay";
            isExpiredToday = true
        }
        else {
            isExpired = true
            dueDateFormat = "Quá hạn " + distanceDate + " ngày";
        }
    }

    return (
        <TouchableOpacity onPress={gotoDetailPress}>
            <View style={{
                flex: 1,
                flexDirection: 'row',
                marginHorizontal: dimensWidth(15),
                shadowColor: '#000000',
                shadowOffset: {
                    width: 0,
                    height: 0
                },
                shadowRadius: 8,
                shadowOpacity: 0.1,
                elevation: 1
            }}>
                <View style={styles.item}>
                    <View style={{
                        width: dimensWidth(5),
                        backgroundColor: selectedItemIndex == index ? '#015DD1' : null,
                    }} />

                    <View style={{
                        flex: 1,
                        flexDirection: 'row',
                        padding: dimensWidth(15),
                        borderRadius: 8,
                        justifyContent: 'center',
                    }}>
                        <FastImageCustom
                            styleImg={styles.itemAvatar}
                            urlOnline={`${BASE_URL}/${subSite}/${ImagePath}`}
                        />
                        <View style={{ flex: 1 }}>
                            <View style={styles.flexDirectionBetween}>
                                <Text style={styles.title} numberOfLines={1}>
                                    {!isNullOrEmpty(Author) ? removeSpecialCharacters(Author) : ""}
                                </Text>
                                <Text style={styles.date}>{formatCreated}</Text>
                            </View>

                            <Text style={[styles.category, { marginEnd: 20 }]}>{"Văn bản đi"}</Text>
                            <Text style={styles.title} numberOfLines={1}>{Title}</Text>
                            <View style={styles.flexDirectionBetween}>
                                <View style={styles.touchSendUnit}>
                                    <Text style={styles.textSendUnit}>{item?.Status}</Text>
                                </View>
                                <View style={{ flex: 1, marginLeft: 10 }}>
                                    {(item?.Priority ==
                                        1) && <LaCoIcon />}
                                </View>
                                <Text
                                    style={[
                                        styles.date,
                                        isExpiredToday && styles.todayDeadlife,
                                        isExpired && styles.distanceDate,
                                    ]}
                                >
                                    {dueDateFormat}
                                </Text>
                            </View>
                        </View>
                    </View>
                </View>
            </View>
        </TouchableOpacity>
    )
}

const VBDiScreen = ({ route, navigation }: any) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    let initialPayloadVBDi = {offset:0,FilterText:"", TinhTrang: "", FromDate: "", ToDate: ""}
    const { subSite, token } = useSelector(
        (state: RootState) => state.login);

    const { dataVBDiMenu, isLoadingVBDiMenu, isRefreshVBDiMenu } = useSelector(
        (state: RootState) => state.home);
    const { isRefreshVBDiScreen } = useSelector(
        (state: RootState) => state.vbdi);
    const { funtionVBDi, totalRecord, sellectedDocumentID } = dataVBDiMenu;
    const flatListRef = React.useRef()
    const [dataVBDiTabState, setDataVBDiTabState] = useState([])
    const [offset, setOffset] = useState(0)
    const [Item, setItem] = useState({})
    const [selectedItemIndex, setSelectedItemIndex] = useState<any>(null)
    const [textSearch, setTextSearch] = useState("")
    const [fromDate, setFromDate] = useState("")
    const [toDate, setToDate] = useState("")
    const [modalFilter, setModalFilter] = useState(false)
    const [funtionVBDiState, setfuntionVBDiState] = useState<any>(funtionVBDiData.TatCa);
    const isFocused = useIsFocused();
    const [isDefaultFilter, setIsDefaultFilter] = useState(true)

    const fetchDataLeftList = useCallback(async (
        offset: number,
        subSite: string,
        FilterText: string,
        funtionVBDi: any,
        TinhTrang: any,
        FromDate: string,
        ToDate: string,
    ) => {
        dispatch(fetchVBDiMenu({
            offset: offset,
            subSite: subSite,
            FilterText: FilterText,
            funtionVBDi,
            TinhTrang: TinhTrang === funtionVBDiData.TatCa ? "" : TinhTrang,
            FromDate,
            ToDate,
        }));
    }, [dispatch]);
    const onRefreshVBDi = useCallback(() => {
        dispatch(onChangeSellecteDocumentIDbDiAction(null))
        resetData()
        dispatch(onRefreshVbDiMenuAction(null))
        dispatch(fetchVBDiMenu({
            offset: offset,
            subSite: subSite,
            FilterText: "",
            funtionVBDi,
            TinhTrang: "",
            FromDate: "",
            ToDate: "",
        }));
    }, [dispatch, offset, funtionVBDi, subSite]);
    useEffect(() => {
        if (funtionVBDiState !== funtionVBDi) {
            setfuntionVBDiState(funtionVBDi);
            resetData()
        }
    }, [funtionVBDiState, funtionVBDi, subSite])
    useEffect(() => {
     if(isFocused){
        const TinhTrang = funtionVBDi.filterTitle
        fetchDataLeftList(
            offset, 
            subSite,
             textSearch,
             funtionVBDi,
            TinhTrang,
            fromDate,
            toDate,
        )
     }
    }, [isFocused, funtionVBDi, subSite, fromDate, toDate, offset, textSearch, dispatch]);
    useEffect(() => {
        if (isRefreshVBDiScreen) {
            resetData()
            dispatch(resetVBDiScreen(null))
            const TinhTrang = funtionVBDi.filterTitle
            dispatch(fetchVBDiMenu({
                ...initialPayloadVBDi,
                offset: 0,
                subSite: subSite,
                FilterText: "",
                funtionVBDi,
                TinhTrang,
                FromDate: "",
                ToDate: "",
            }));
        }
    }, [isRefreshVBDiScreen, isFocused, subSite, funtionVBDi, dispatch])

    useEffect(() => {

        if (isNullOrUndefined(fromDate)) {
            setIsDefaultFilter(true)
        } else {
            setIsDefaultFilter(false)
        }
    }, [fromDate, toDate, funtionVBDi.title,])
    const resetData = useCallback(() => {
        setOffset(0);
        setTextSearch("")
        setFromDate("")
        setFromDate("")
    }, []);
    useEffect(() => {
            setDataVBDiTabState(dataVBDiMenu.data)
            if (offset == 0 && isNullOrUndefined(dataVBDiMenu.sellectedDocumentID)) {
                setSelectedItemIndex(0)
                setItem(dataVBDiMenu.data[0])
            }
    }, [dataVBDiMenu, offset]);
    useEffect(() => {
        if (sellectedDocumentID && !isNullOrUndefined(dataVBDiMenu.data) && funtionVBDiState.key === funtionVBDiData.DaPheDuyet.key && !isLoadingVBDiMenu) {

            const sellectedIndex = dataVBDiTabState?.findIndex((it: any, idx: any) => {
                return it?.ID == sellectedDocumentID
            })
            if (sellectedIndex !== -1 && sellectedIndex < dataVBDiMenu.data.length) {
                flatListRef?.current?.scrollToIndex({ animated: true, index: selectedItemIndex })
                setItem(dataVBDiTabState[sellectedIndex])
                setSelectedItemIndex(sellectedIndex)
            }

        }
    }, [dataVBDiMenu.data, funtionVBDiState, sellectedDocumentID, isLoadingVBDiMenu])
    const gotoDetailPress = useCallback((item, index) => {
        setSelectedItemIndex(index)
        setItem(item)
    }, [Item]);

    const handleLoadmore = useCallback(() => {
        if (totalRecord > dataVBDiTabState.length) {
            setOffset(dataVBDiTabState.length);
        }
    }, [totalRecord, dataVBDiTabState]);

    const openDrawer = useCallback(() => {
        navigation.openDrawer();
    }, [navigation]);

    const onChangeFilterText = useCallback(
        (text: string) => {
            setTextSearch(text);
            setOffset(0)
        },
        [textSearch, offset]
    );
    const onCloseFilterModal = useCallback(() => {
        setModalFilter(false)
    }, [modalFilter])

    const onConfirmFilterModal = useCallback((data) => {
        if (!isNullOrUndefined(data)) {
            setToDate(data.ToDate)
            setFromDate(data.FromDate)
            setOffset(0)
        }

        setModalFilter(false)
    }, [])

    const renderFooter = (loading: boolean, offset: number) => {
        if (arrayIsEmpty(dataVBDiTabState)) return <View />
        return (
            <View style={{
                padding: 10,
                justifyContent: 'center',
                alignItems: 'center',
                flexDirection: 'row'
            }}>
                {loading && offset !== 0 ? (
                    <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
                ) : null}
            </View>
        );
    };
    const renderEmpty = () => {
        if (isLoadingVBDiMenu && !isRefreshVBDiScreen) return <LoadingView isLoading={isLoadingVBDiMenu} bgColor={colors.white} viewLoadingStyle={{ top: dimnensHeight(100) }} />
        return (
            <NoDataView />
        )
    }
    return (
        <View style={{
            flex: 1,
            backgroundColor: Colors.gray
        }}>
            <View style={{
                flex: 1,
                flexDirection: 'row',
            }}>
                <View style={{
                    width: '35%'
                }}>
                    <LinearGradient style={{
                        paddingLeft: dimensWidth(15),
                        height: dimnensHeight(55),
                    }}
                        colors={["#0262E9", "#0054AE"]}>
                        <View style={{
                            flex: 1,
                            flexDirection: 'row',
                            alignItems: "center",
                        }}>
                            <TouchableOpacity onPress={openDrawer} style={{
                                marginRight: dimensWidth(10),
                            }}>
                                <MenuIcon color={'#fff'} />
                            </TouchableOpacity>

                            <View style={{ flex: 1 }}>
                                <Text style={{
                                    color: Colors.white,
                                    fontSize: FontSize.LARGE,
                                    fontWeight: '400',
                                    fontFamily: 'arial',
                                }}>{subSite.toUpperCase()}</Text>
                                <Text style={{
                                    color: Colors.white,
                                    fontSize: FontSize.MEDIUM,
                                    marginTop: dimnensHeight(2),
                                    fontWeight: '400',
                                    fontFamily: 'arial',
                                }}>{`${funtionVBDi.title}`}</Text>
                            </View>
                            <TouchableOpacity style={styles.filterIcon} onPress={() => setModalFilter(true)}>
                                <FilterIcon color={isDefaultFilter ? colors.white : colors.red} />
                            </TouchableOpacity>
                            <View style={{
                                height: '50%',
                                width: 1,
                                backgroundColor: 'white'
                            }} />
                        </View>
                    </LinearGradient>
          
                    <TopBarTab
                        isShowSearch={true}
                        textSearch={textSearch}
                        onChangeFilterText={onChangeFilterText}
                        isHideButtonSearch
                    />
                    {
                        !arrayIsEmpty(dataVBDiTabState) ?
                            <FlatList
                                ref={flatListRef}
                                data={dataVBDiTabState}
                                extraData={dataVBDiTabState}
                                refreshControl={
                                    <RefreshControl refreshing={isRefreshVBDiMenu} onRefresh={onRefreshVBDi} tintColor='#0054AE' />
                                }
                                onEndReachedThreshold={0.5}
                                onEndReached={handleLoadmore}
                                showsVerticalScrollIndicator={true}
                                keyExtractor={(item, index) => index.toString()}
                                getItemLayout={(_, index) => ({
                                    length: dimnensHeight(134), //  WIDTH + (MARGIN_HORIZONTAL * 2)
                                    offset: dimnensHeight(134) * (index),  //  ( WIDTH + (MARGIN_HORIZONTAL*2) ) * (index)
                                    index,
                                })}
                                ListFooterComponent={renderFooter(isLoadingVBDiMenu, offset)}
                                renderItem={({ item, index }) =>
                                    <ItemLeft
                                        item={item}
                                        index={index}
                                        subSite={subSite}
                                        token={token}
                                        gotoDetail={gotoDetailPress}
                                        selectedItemIndex={selectedItemIndex}
                                    />
                                } /> : renderEmpty()
                    }
                </View>
                <View style={{
                    width: '65%',
                }}>
                    {Item ? <VBDiDetail route={{
                        ItemId: Item?.ID
                    }} navigation={navigation} token={token} selectedItemIndex={selectedItemIndex} /> : (<View style={{ flex: 1 }} >
                        <LinearGradient style={{
                            paddingLeft: dimensWidth(15),
                            height: dimnensHeight(55),
                            alignItems: 'center',
                            flexDirection: 'row',
                            justifyContent: 'flex-end',
                            paddingRight: dimensWidth(15)
                        }}
                            colors={["#0262E9", "#0054AE"]} />
                        <NoDataView />
                    </View>)}
                </View>
            </View>
            <VbDiFilterModal
                modalVisible={modalFilter}
                onCloseModal={onCloseFilterModal}
                onConfirmModal={(data) => onConfirmFilterModal(data)}
                loaiFilterType={funtionVBDi.filterTitle}
            />
        </View>
    )
}

export default VBDiScreen