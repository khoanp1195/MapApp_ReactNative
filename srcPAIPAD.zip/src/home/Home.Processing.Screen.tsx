import React, { useState, useCallback, useEffect } from 'react';
import { View, Text, ActivityIndicator } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { dimnensHeight, dimensWidth, enumDocumentType, enumTopBarTabStatus } from '~/base/Constants';
import Colors from "../base/Colors"
import { BASE_URL, FontSize } from '../base/Constants'
import {
    isNullOrUndefined, calculateBetweenTwoDate,
    formatCreatedDate,
    arrayIsEmpty,
    checkIsEmpty,
    format_dd_mm_yy,
} from '../base/Functions'
import { FlatList, RefreshControl, TouchableOpacity } from 'react-native-gesture-handler';
import styles from './Home.Procesing.Style';
import { fetchDataProcessing, setDataProcessingStatus, setSellectedProcessingIndex } from '../base/stories/home/reducer'
import { LoadingView, NoDataView, TopBarTab, } from '~/base/components';
import VBDenDetail from '~/detail/vbden/VBDen.Detail.Screen';
import VBDiDetail from '~/detail/vbdi/VBDi.Detail.Screen';
import VBBHDetail from '~/detail/vbbh/VBBH.Detail.Screen';
import colors from '../base/Colors';
import { FilterIcon, LaCoIcon, MenuIcon, SearchIcon } from '~/base/assets/svg';
import HomeFilterModal from './components/Home.Filter.Modal';
import { RootState } from "stores";
import { onResetVbDenDetailAction, resetVBDenScreen } from '~/base/stories/vbden/reducer';
import { resetVBDiScreen } from '~/base/stories/vbdi/reducer';
import { useIsFocused } from '@react-navigation/native';
import { setIsCloseModalApp, setRemoteMessage } from '~/base/stories/data/reducer';
import FastImageCustom from '~/base/components/FastImageCustom';
import LinearGradientView from '~/base/components/LinearGradientView';

const ItemLeft = ({ item, index, subSite, gotoDetail, selectedItemIndex, isVBChoXuLy }: any) => {
    const {
        ID,
        Title,
        SendUnit,
        ImagePath,
        Action,
        DocumentID,
        Category,
        Created,
        Priority,
        Read,
        ListName,
        DueDate,
        TaskCategory,
    } = item
    const gotoDetailPress = () => {
        gotoDetail(item, index);
    };

    const formatCreated = formatCreatedDate(Created);
    let dueDateFormat = ""
    let isExpired = false
    let isExpiredToday = false
    const distanceDate = calculateBetweenTwoDate(DueDate);
    if (!checkIsEmpty(distanceDate)) {
        if (parseInt(distanceDate) < 0) {
            dueDateFormat = format_dd_mm_yy(DueDate);
        } else if (parseInt(distanceDate) >= 0 && parseInt(distanceDate) < 1) {
            dueDateFormat = "Hạn hôm nay";
            isExpiredToday = true
        }
        else {
            isExpired = true
            dueDateFormat = "Quá hạn " + distanceDate + " ngày";
        }
    }
    const ListNameFormat = ListName === "List Văn bản đi" ? "Văn bản đi" : ListName


    return (
        <TouchableOpacity onPress={gotoDetailPress}>
            <View style={{
                flex: 1,
                flexDirection: 'row',
                marginHorizontal: dimensWidth(15),
                shadowColor: '#000000',
                shadowOffset: {
                    width: 0,
                    height: 0
                },
                shadowRadius: 8,
                shadowOpacity: 0.1,
                elevation: 1
            }}>
                <View style={styles.item}>
                    <View style={{
                        width: dimensWidth(5),
                        backgroundColor: selectedItemIndex == index ? '#015DD1' : null,
                    }} />

                    <View style={{
                        flex: 1,
                        flexDirection: 'row',
                        padding: dimensWidth(15),
                        borderRadius: 8,
                        justifyContent: 'center',
                    }}>
                        <FastImageCustom
                            styleImg={styles.itemAvatar}
                            urlOnline={`${BASE_URL}/${subSite}/${ImagePath}`}
                        />
                        <View style={{ flex: 1 }}>
                            <View style={styles.flexDirectionBetween}>
                                <Text style={styles.title} numberOfLines={1}>
                                    {SendUnit}
                                </Text>
                                <Text style={styles.date}>{formatCreated}</Text>
                            </View>

                            <View style={{
                                flex: 1,
                                flexDirection: 'row',
                                justifyContent: 'space-between',
                            }}>
                                <Text style={styles.category}>{ListNameFormat}</Text>
                                <Text style={styles.category} numberOfLines={1}>{TaskCategory}</Text>
                            </View>
                            <Text style={styles.title} numberOfLines={2}>{Title}</Text>
                            <View style={styles.flexDirectionBetween}>
                                <View style={styles.touchSendUnit}>
                                    <Text style={styles.textSendUnit}>{Action}</Text>
                                </View>
                                <View style={{ flex: 1, marginLeft: 10 }}>
                                    {(item?.Priority ==
                                        1) && <LaCoIcon />}
                                </View>
                                <Text
                                    style={[
                                        styles.date,
                                        isExpiredToday && styles.todayDeadlife,
                                        isExpired && styles.distanceDate,
                                    ]}
                                >
                                    {isVBChoXuLy ? dueDateFormat : ""}
                                </Text>
                            </View>
                        </View>
                    </View>

                </View>
            </View>

        </TouchableOpacity>
    )
}

const HomeProcessing = ({ route, navigation }: any) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();

    const { subSite, token } = useSelector(
        (state: RootState) => state.login);
    const { IsCloseModalApp } = useSelector((state: RootState) => state.data);
    const { dataDocProcessing, isLoading } = useSelector(
        (state: RootState) => state.home);
    const { status, totalRecordString } = dataDocProcessing;
    const { isProcessVbdenSuccess } = useSelector(
        (state: RootState) => state.vbden);
    const { isRefreshVBDiScreen } = useSelector(
        (state: RootState) => state.vbdi);
    const [dataProcessing, setDataProcessing] = useState([])
    const [offset, setOffset] = useState(0)
    const [Item, setItem] = useState<any>({})
    const [selectedItemIndex, setSelectedItemIndex] = useState<number>(0)
    const [isShowSearch, setIsShowSearch] = useState(false)
    const [textSearch, setTextSearch] = useState("")
    const [totalRecordNumber, setTotalRecordNumber] = useState(0)
    const [modalFilter, setModalFilter] = useState(false)
    const [documentType, setDocumentType] = useState(enumDocumentType.TatCa)
    const [fromDate, setFromDate] = useState("")
    const [toDate, setToDate] = useState("")
    const [isRefresh, setIsRefresh] = useState(false)
    const flatListRef = React.useRef(null);
    const { remoteMessage } = useSelector((state: RootState) => state.data);
    const isFocused = useIsFocused();
    const [isDefaultFilter, setIsDefaultFilter] = useState(true)
    useEffect(() => {
        if (isNullOrUndefined(fromDate) && isNullOrUndefined(toDate) && documentType == enumDocumentType.TatCa) {
            setIsDefaultFilter(true)
        } else {
            setIsDefaultFilter(false)
        }
    }, [fromDate, toDate, documentType,])

    const fetchDataLeftList = useCallback(async (
        status: number,
        offset: number,
        subSite: string,
        FilterText: string,
        DocumentType: string,
        FromDate: string,
        ToDate: string
    ) => {
        dispatch(fetchDataProcessing({
            offset: offset,
            status: status,
            subSite: subSite,
            FilterText: FilterText,
            DocumentType: DocumentType === enumDocumentType.TatCa ? "" : DocumentType,
            FromDate,
            ToDate
        }));
    }, [dispatch, offset, textSearch, documentType, fromDate, toDate]);

    const onPressTabProcessing = useCallback(() => {
        dispatch(setDataProcessingStatus(enumTopBarTabStatus.VBChoXuLy))
        setOffset(0)
    }, []);

    const onPressTabProcessed = useCallback(() => {
        dispatch(setDataProcessingStatus(enumTopBarTabStatus.VBDaXuLy))
        setOffset(0)
    }, []);
    const onRefresh = useCallback(() => {
        dispatch(setSellectedProcessingIndex(0))
        setIsRefresh(true)
        setOffset(0)
        fetchDataLeftList(0,
            status,
            subSite,
            textSearch,
            documentType,
            fromDate,
            toDate)
        setIsRefresh(false)
    }, [dispatch, subSite, status, textSearch, documentType, fromDate, toDate])

    useEffect(() => {
        if (isFocused) {
            console.log('renderEmptyrenderEmpty');
            fetchDataLeftList(status, offset, subSite, textSearch, documentType, fromDate, toDate)
            dispatch(onResetVbDenDetailAction(null))
        }
    }, [dispatch, isFocused, subSite, offset, status, textSearch, documentType, fromDate, toDate]);
    useEffect(() => {
        if (!isNullOrUndefined(remoteMessage?.data?.NotifyTitle)) {
            if (IsCloseModalApp) dispatch(setIsCloseModalApp(false));
            dispatch(fetchDataProcessing({
                offset: 0,
                status: 0,
                subSite: subSite,
                FilterText: "",
                DocumentType: "",
                FromDate: "",
                ToDate: ""
            }));
            dispatch(setRemoteMessage({}))
        }
    }, [remoteMessage, subSite])
    useEffect(() => {
        if (isProcessVbdenSuccess) {
            dispatch(setSellectedProcessingIndex(0))
            dispatch(resetVBDenScreen(null))
            setOffset(0)
            dispatch(fetchDataProcessing({
                offset: 0,
                status: status,
                subSite: subSite,
                FilterText: "",
                DocumentType: "",
                FromDate: "",
                ToDate: ""
            }));
            flatListRef?.current?.scrollToOffset({ animated: true, offset: 0 })
        }
        if (isRefreshVBDiScreen) {
            dispatch(setSellectedProcessingIndex(0))
            dispatch(resetVBDiScreen(null))
            setOffset(0)
            dispatch(fetchDataProcessing({
                offset: 0,
                status: status,
                subSite: subSite,
                FilterText: "",
                DocumentType: "",
                FromDate: "",
                ToDate: ""
            }));
        }
    }, [isProcessVbdenSuccess, isRefreshVBDiScreen, dispatch, status, subSite])
    useEffect(() => {
        if (!isNullOrUndefined(dataDocProcessing.data)) {
            setDataProcessing(dataDocProcessing.data)
            setTotalRecordNumber(dataDocProcessing.totalRecord)
        }
    }, [dataDocProcessing]);

    useEffect(() => {
        if (offset == 0 && !arrayIsEmpty(dataProcessing) && dataDocProcessing.sellectedIndex !== -1) {
            const index = dataDocProcessing.sellectedIndex
            setSelectedItemIndex(index)
            setItem(dataProcessing[index])
            flatListRef?.current?.scrollToIndex({ animated: true, index: index })

        }
    }, [dataProcessing, offset, dataDocProcessing.sellectedIndex])
    useEffect(() => {
        if (!isNullOrUndefined(route.params?.tabStatus)) {
            onPressTabProcessing()
        }
    }, [route.params?.tabStatus])

    const gotoDetailPress = useCallback((item: any, index: number) => {
        setSelectedItemIndex(index)
        setItem(item)
    }, [Item]);

    const handleLoadmore = async () => {
        if (totalRecordNumber > dataProcessing.length) {
            setOffset(dataProcessing.length);
        }
    };

    const openDrawer = useCallback(() => {
        navigation.openDrawer();
    }, [navigation]);

    const onSearchPress = useCallback(() => {
        setIsShowSearch(!isShowSearch)
    }, [isShowSearch])

    const onChangeFilterText = useCallback(
        (text: string) => {
            setTextSearch(text);
            setOffset(0)
        },
        [textSearch, offset]
    );

    const onCloseFilterModal = useCallback(() => {
        setModalFilter(false)
    }, [modalFilter])

    const onConfirmFilterModal = useCallback((data: { DocumentType: React.SetStateAction<string>; ToDate: React.SetStateAction<string>; FromDate: React.SetStateAction<string>; }) => {
        if (!isNullOrUndefined(data)) {
            setDocumentType(data.DocumentType)
            setToDate(data.ToDate)
            setFromDate(data.FromDate)
            setOffset(0)
        }

        setModalFilter(false)
    }, [])

    const renderFooter = (loading: boolean) => {
        if (arrayIsEmpty(dataDocProcessing)) return <View />
        return (
            <View style={{
                padding: 10,
                justifyContent: 'center',
                alignItems: 'center',
                flexDirection: 'row'
            }}>
                {loading ? (
                    <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
                ) : null}
            </View>
        );
    };
    const renderEmpty = () => {
        if (isLoading) return <LoadingView isLoading={isLoading} />
        return (
            <NoDataView />
        )
    }

    return (
        <View style={{
            flex: 1,
            backgroundColor: Colors.gray
        }}>
            <View style={{
                flex: 1,
                flexDirection: 'row',
            }}>
                <View style={{
                    width: '35%'
                }}>
                    <LinearGradientView style={{
                        paddingLeft: dimensWidth(15),
                        height: dimnensHeight(55),
                    }}>
                        <View style={{
                            flex: 1,
                            flexDirection: 'row',
                            alignItems: "center",
                        }}>
                            <TouchableOpacity onPress={openDrawer} style={{
                                marginRight: dimensWidth(10),
                            }}>
                                <MenuIcon color={'#fff'} />
                            </TouchableOpacity>

                            <View style={{
                                flex: 1
                            }}>
                                <Text style={{
                                    color: Colors.white,
                                    fontSize: FontSize.LARGE,
                                    fontWeight: '400',
                                    fontFamily: 'arial',
                                }}>{subSite.toUpperCase()}</Text>
                                <Text style={{
                                    color: Colors.white,
                                    fontSize: FontSize.MEDIUM,
                                    fontWeight: '400',
                                    fontFamily: 'arial',
                                    marginTop: dimnensHeight(2)
                                }}>Trang chủ / Văn bản cần xử lý</Text>
                            </View>
                            <TouchableOpacity style={styles.filterIcon} onPress={() => setModalFilter(true)}>
                                <FilterIcon color={isDefaultFilter ? colors.white : colors.red} />
                            </TouchableOpacity>
                            <View style={{
                                height: '50%',
                                width: 1,
                                backgroundColor: 'white'
                            }} />
                        </View>
                    </LinearGradientView>
                    
                    <TopBarTab
                        isShowSearch={isShowSearch}
                        textSearch={textSearch}
                        onChangeFilterText={onChangeFilterText}
                        onPressTabProcessing={onPressTabProcessing}
                        status={status}
                        totalRecordString={totalRecordString}
                        onPressTabProcessed={onPressTabProcessed}
                        onSearchPress={onSearchPress}
                    />
                    {
                        !arrayIsEmpty(dataProcessing) ?
                            <FlatList
                                ref={flatListRef}
                                data={dataProcessing}
                                extraData={selectedItemIndex || dataDocProcessing}
                                refreshControl={
                                    <RefreshControl refreshing={isRefresh} onRefresh={onRefresh} tintColor='#0054AE' />
                                }
                                onEndReachedThreshold={0.5}
                                onEndReached={handleLoadmore}
                                showsVerticalScrollIndicator={true}
                                keyExtractor={(item, index) => index.toString()}
                                ListFooterComponent={renderFooter(isLoading)}
                                getItemLayout={(_, index) => ({
                                    length: dimnensHeight(134), //  WIDTH + (MARGIN_HORIZONTAL * 2)
                                    offset: dimnensHeight(134) * (index),  //  ( WIDTH + (MARGIN_HORIZONTAL*2) ) * (index)
                                    index,
                                })}
                                renderItem={({ item, index }) => (
                                    <ItemLeft
                                        item={item}
                                        index={index}
                                        subSite={subSite}
                                        token={token}
                                        gotoDetail={gotoDetailPress}
                                        selectedItemIndex={selectedItemIndex}
                                        isVBChoXuLy={status === enumTopBarTabStatus.VBChoXuLy}
                                    />
                                )} /> :
                            renderEmpty()
                    }
                </View>
                <View style={{
                    width: '65%',
                }}>
                    {(!isNullOrUndefined(Item)) && (Item.ListName == "Văn bản đi" || Item.ListName == "List Văn bản đi") ? <VBDiDetail route={{
                        ItemId: Item.DocumentID
                    }} navigation={navigation} sellectedIndex={selectedItemIndex} /> : (!isNullOrUndefined(Item) && Item.ListName == "Văn bản đến") ? <VBDenDetail route={{
                        ItemId: Item.DocumentID
                    }} navigation={navigation} sellectedIndex={selectedItemIndex} /> :
                        (!isNullOrUndefined(Item) && Item.ListName == "Văn bản ban hành") ? <VBBHDetail route={{
                            ItemId: Item.DocumentID
                        }} navigation={navigation} sellectedIndex={selectedItemIndex} /> : (<View style={{ flex: 1 }}>
                            <LinearGradientView style={{
                                paddingLeft: dimensWidth(15),
                                height: dimnensHeight(55),
                                alignItems: 'center',
                                flexDirection: 'row',
                                justifyContent: 'flex-end',
                                paddingRight: dimensWidth(15)
                            }} />
                            <NoDataView />
                        </View>)}
                </View>
            </View>

            <HomeFilterModal
                modalVisible={modalFilter}
                onCloseModal={onCloseFilterModal}
                onConfirmModal={(data) => onConfirmFilterModal(data)}
            />
        </View>
    )
}

export default HomeProcessing