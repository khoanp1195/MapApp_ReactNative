import React, { useState, useCallback, useEffect, useMemo, FC, useRef } from 'react';
import { View, Text, ActivityIndicator, RefreshControl, Alert } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { dimnensHeight, dimensWidth, funtionVBDenData } from '~/base/Constants';
import Colors from "../base/Colors"
import { BASE_URL, FontSize } from '../base/Constants'
import {
    isNullOrUndefined, calculateBetweenTwoDate,
    formatCreatedDate,
    format_mm_dd_hh_yy_mm_ss,
    arrayIsEmpty,
    checkIsEmpty,
    format_dd_mm_yy,
    removeSpecialCharacters,
} from '../base/Functions'
import { FlatList, TouchableOpacity } from 'react-native-gesture-handler';
import styles from './Home.Procesing.Style';
import { LoadingView, NoDataView, TextInputCustom, TopBarTab } from '~/base/components';
import VBDenDetail from '~/detail/vbden/VBDen.Detail.Screen';
import LinearGradient from 'react-native-linear-gradient';
import colors from '../base/Colors';
import { FilterIcon, LaCoIcon, MenuIcon, SearchIcon } from '~/base/assets/svg';
import SearchInput from '~/search/components/SearchInput';
import { onRefreshVbDenAction, resetVBDenScreen } from '~/base/stories/vbden/reducer';
import { RootState } from '~/base/stories';
import FastImageCustom from '~/base/components/FastImageCustom';
import VBDenFilterModal from './components/VBDen.FilterModal'
import { TinhTrangType, TrinhLanhDaoTypeProps } from './VBDenType';
import { fetchVBDenMenu } from '~/base/stories/home/reducer';
import { useIsFocused } from '@react-navigation/native';

const ItemLeft = ({ item, index, subSite, token, gotoDetail, selectedItemIndex }: any) => {
    const {
        ID,
        ImagePath,
        Title,
        Created,
        TrangThai,
        TrichYeu,
        SoDen,
        DocumentID,
        CoQuanGui,
        DoKhan
    } = item
    const gotoDetailPress = () => {
        gotoDetail(item, index);
    };
    const formatCreated = formatCreatedDate(Created);
    return (
        <TouchableOpacity onPress={gotoDetailPress}>
            <View style={{
                flex: 1,
                flexDirection: 'row',
                marginHorizontal: dimensWidth(15),
                shadowColor: '#000000',
                shadowOffset: {
                    width: 0,
                    height: 0
                },
                shadowRadius: 8,
                shadowOpacity: 0.1,
                elevation: 1
            }}>
                <View style={styles.item}>
                    <View style={{
                        width: dimensWidth(5),
                        backgroundColor: selectedItemIndex == index ? '#015DD1' : null,
                    }} />

                    <View style={{
                        flex: 1,
                        flexDirection: 'row',
                        padding: dimensWidth(15),
                        borderRadius: 8,
                        justifyContent: 'center',
                    }}>

                        <FastImageCustom urlOnline={`${BASE_URL}/${subSite}/${ImagePath}`} token={token} />

                        <View style={{ flex: 1 }}>
                            <View style={styles.flexDirectionBetween}>
                                <Text style={styles.title} numberOfLines={1}>
                                    {removeSpecialCharacters(CoQuanGui)}
                                </Text>
                                <Text style={styles.date}>{formatCreated}</Text>
                            </View>

                            <View style={{
                                flex: 1,
                                flexDirection: 'row',
                                justifyContent: 'space-between',
                            }}>
                                <Text style={styles.category}>{"Văn bản đến"}</Text>
                                <Text style={[styles.category, { marginRight: 0, flex: 1, textAlign: 'right' }]} numberOfLines={1}>{Title}</Text>
                            </View>
                            <Text style={styles.title} numberOfLines={2}>{TrichYeu}</Text>

                            <View style={styles.flexDirectionBetween}>
                                <View style={styles.touchSendUnit}>
                                    <Text style={styles.textSendUnit}>{TrangThai}</Text>
                                </View>

                                <View style={{ flex: 1, marginLeft: 10 }}>
                                    {(DoKhan === "Thượng khẩn" || DoKhan === "Hỏa tốc") && <LaCoIcon />}
                                </View>
                            </View>
                        </View>
                    </View>
                </View>
            </View>
        </TouchableOpacity>
    )
}

const VBDenScreen = ({ route, navigation }: any) => {
    let initialPayloadVBDen = { TinhTrang: "", BanLanhDao: "", FromDate: "", ToDate: "" }
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { subSite, token } = useSelector(
        (state: RootState) => state.login);
    const { dataVBDenMenu } = useSelector(
        (state: RootState) => state.home);

    const { isLoading, isProcessVbdenSuccess, } = useSelector(
        (state: RootState) => state.vbden);
    const { totalRecord, funtionVBDen } = dataVBDenMenu
    const [dataVBDenTabState, setDataVBDenTabState] = useState([])
    const [offset, setOffset] = useState(0)
    const [Item, setItem] = useState<any>({})
    const [selectedItemIndex, setSelectedItemIndex] = useState<any>(null)
    const [isRefreshVBDen, setIsRefreshVBDen] = useState(false)
    const [textSearch, setTextSearch] = useState("")
    const [modalFilter, setModalFilter] = useState(false)
    const [tinhtrangSellectedState, setTinhtrangSellectedState] = useState<any>(TinhTrangType.TAT_CA)
    const [payloadVBDen, setPayloadVBDen] = useState<any>(initialPayloadVBDen);
    const [funtionVBDenState, setFuntionVBDenState] = useState<any>(funtionVBDenData.VBDenTatCa);
    const isFocused = useIsFocused();
    const [isDefaultFilter, setIsDefaultFilter] = useState(true)
    const flatListRef = React.useRef()

    useEffect(() => {
        if (initialPayloadVBDen.FromDate === payloadVBDen.FromDate && initialPayloadVBDen.BanLanhDao === payloadVBDen.BanLanhDao) {
            setIsDefaultFilter(true)
        } else {
            setIsDefaultFilter(false)
        }
    }, [payloadVBDen, funtionVBDen?.title])

    const fetchDataLeftList = useCallback((payload: any) => {
        dispatch(fetchVBDenMenu(payload));
    }, [dispatch]);

    useEffect(() => {
        if (funtionVBDen.key === funtionVBDenData.VBDenTitle.key || funtionVBDen.key === funtionVBDenData.VBDenTatCa.key) {
            setTinhtrangSellectedState(TinhTrangType.TAT_CA);
        } else if (funtionVBDen.key === funtionVBDenData.VBDenChoChoYKien.key) {
            setTinhtrangSellectedState(TinhTrangType.TRINH_LANH_DAO);
        } else if (funtionVBDen.key === funtionVBDenData.VBDenChoThucHien.key) {
            setTinhtrangSellectedState(TinhTrangType.CHUYEN_DON_VI);
        } else {
            setTinhtrangSellectedState(TinhTrangType.HOAN_TAT);
        }
    }, [funtionVBDen])
    useEffect(() => {
        if (isProcessVbdenSuccess) {
            dispatch(resetVBDenScreen(null))
            setOffset(0)
            dispatch(fetchVBDenMenu({
                offset: 0,
                subSite: subSite,
                funtionVBDen,
                FilterText: "",
                ...initialPayloadVBDen
            }));
            if (!arrayIsEmpty(dataVBDenTabState)) flatListRef?.current?.scrollToOffset({ animated: true, offset: 0 })
        }
    }, [isProcessVbdenSuccess, subSite, funtionVBDen, dataVBDenTabState, dispatch])
    useEffect(() => {
        if (isFocused) {
            setOffset(0)
            setTextSearch("")
            setPayloadVBDen(initialPayloadVBDen);
            dispatch(fetchVBDenMenu({
                offset: 0,
                subSite: subSite,
                funtionVBDen,
                FilterText: "",
                ...initialPayloadVBDen
            }));
        }
    }, [isFocused,subSite])
    const onRefreshVBDen = useCallback(() => {
        dispatch(onRefreshVbDenAction(null))
        setIsRefreshVBDen(true)
        setOffset(0)
        setTextSearch("")
        setPayloadVBDen(initialPayloadVBDen);
        fetchDataLeftList({ offset: 0, FilterText: "", subSite, funtionVBDen, ...initialPayloadVBDen })
        setIsRefreshVBDen(false)
    }, [subSite, funtionVBDen]);

    useEffect(() => {
        if (funtionVBDenState !== funtionVBDen) {
            onRefreshVBDen()
            setFuntionVBDenState(funtionVBDen);
        }
    }, [funtionVBDenState, funtionVBDen])
    useEffect(() => {
        const FilterText = textSearch
        fetchDataLeftList({ offset, subSite, FilterText, funtionVBDen, ...payloadVBDen })
    }, [offset, textSearch, subSite, funtionVBDen, payloadVBDen]);

    useEffect(() => {
        if (!isNullOrUndefined(dataVBDenMenu.data)) {
            setDataVBDenTabState(dataVBDenMenu.data)
            if (offset == 0) {
                setSelectedItemIndex(0)
                setItem(dataVBDenMenu?.data[0])
            }
        }
    }, [dataVBDenMenu.data, offset]);

    const gotoDetailPress = useCallback((item, index) => {
        setSelectedItemIndex(index)
        setItem(item)
    }, [Item]);

    const handleLoadmore = async () => {
        if (totalRecord > dataVBDenTabState.length) {
            setOffset(dataVBDenTabState.length);
        }
    }

    const openDrawer = useCallback(() => {
        navigation.openDrawer();
    }, [navigation]);

    const onChangeFilterText = useCallback(
        (text: string) => {
            setTextSearch(text);
            setOffset(0)
        },
        [textSearch, offset]
    );
    const onCloseFilterModal = useCallback(() => {
        setModalFilter(false)
    }, [modalFilter])

    const onConfirmFilterModal = useCallback((data) => {
        if (!isNullOrUndefined(data)) {
            const tinhTrang = data.TinhtrangType === TrinhLanhDaoTypeProps.TAT_CA ? "" : data.TinhtrangType
            const lanhdao = data.LanhDaoChoYKienType.Title === TrinhLanhDaoTypeProps.TAT_CA ? "" : data.LanhDaoChoYKienType.Title
            setOffset(0)
            setPayloadVBDen(
                {
                    TinhTrang: tinhTrang,
                    FromDate: data.FromDate,
                    ToDate: data.ToDate,
                    funtionVBDen,
                    BanLanhDao: lanhdao
                }
            )

        }

        setModalFilter(false)
    }, [subSite, funtionVBDen])
    const renderFooter = (loading: boolean) => {
        if (arrayIsEmpty(dataVBDenTabState)) return <View />
        return (
            <View style={{
                padding: 10,
                justifyContent: 'center',
                alignItems: 'center',
                flexDirection: 'row'
            }}>
                {loading ? (
                    <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
                ) : null}
            </View>
        );
    };
    const renderEmpty = () => {
        if (isLoading) return <LoadingView isLoading={isLoading} bgColor={colors.white} viewLoadingStyle={{ top: dimnensHeight(100) }} />
        return (
            <NoDataView />
        )
    }
    return (
        <View style={{
            flex: 1,
            backgroundColor: Colors.gray
        }}>
            <View style={{
                flex: 1,
                flexDirection: 'row',
            }}>
                <View style={{
                    width: '35%'
                }}>
                    <LinearGradient style={{
                        paddingLeft: dimensWidth(15),
                        height: dimnensHeight(55),
                    }}
                        colors={["#0262E9", "#0054AE"]}>
                        <View style={{
                            flex: 1,
                            flexDirection: 'row',
                            alignItems: "center",
                        }}>
                            <TouchableOpacity onPress={openDrawer} style={{
                                marginRight: dimensWidth(10),
                            }}>
                                <MenuIcon color={'#fff'} />
                            </TouchableOpacity>
                            <View style={{ flex: 1 }}>
                                <Text style={{
                                    color: Colors.white,
                                    fontSize: FontSize.LARGE,
                                    fontWeight: '400',
                                    fontFamily: 'arial',
                                }}>{subSite.toUpperCase()}</Text>
                                <Text style={{
                                    color: Colors.white,
                                    fontSize: FontSize.MEDIUM,
                                    fontWeight: '400',
                                    fontFamily: 'arial',
                                    marginTop: dimnensHeight(2)
                                }}>{funtionVBDen?.title}</Text>
                            </View>
                            <TouchableOpacity style={styles.filterIcon} onPress={() => setModalFilter(true)}>
                                <FilterIcon color={isDefaultFilter ? colors.white : colors.red} />
                            </TouchableOpacity>
                            <View style={{
                                height: '50%',
                                width: 1,
                                backgroundColor: 'white'
                            }} />
                        </View>
                    </LinearGradient>
                    <TopBarTab
                        isShowSearch={true}
                        textSearch={textSearch}
                        onChangeFilterText={onChangeFilterText}
                        isHideButtonSearch
                    />
                    {
                        !arrayIsEmpty(dataVBDenTabState) && (!isLoading || offset !== 0) ?
                            <FlatList
                                ref={flatListRef}
                                data={dataVBDenTabState}
                                extraData={dataVBDenTabState || selectedItemIndex}
                                refreshControl={
                                    <RefreshControl refreshing={isRefreshVBDen} onRefresh={onRefreshVBDen} tintColor='#0054AE' />
                                }
                                onEndReachedThreshold={0.5}
                                onEndReached={handleLoadmore}
                                showsVerticalScrollIndicator={true}
                                keyExtractor={(item, index) => index.toString()}
                                ListFooterComponent={renderFooter(isLoading)}
                                renderItem={({ item, index }) => {
                                    return (
                                        <ItemLeft
                                            item={item}
                                            index={index}
                                            subSite={subSite}
                                            token={token}
                                            gotoDetail={gotoDetailPress}
                                            selectedItemIndex={selectedItemIndex}
                                        />
                                    )

                                }}
                            /> : renderEmpty()
                    }
                </View>
                <View style={{
                    width: '65%',
                }}>
                    {Item ? <VBDenDetail route={{
                        ItemId: Item?.DocumentID ? Item?.DocumentID : Item?.ID
                    }} navigation={navigation} selectedItemIndex={selectedItemIndex} /> : (<View style={{ flex: 1 }}>
                        <LinearGradient style={{
                            paddingLeft: dimensWidth(15),
                            height: dimnensHeight(55),
                            alignItems: 'center',
                            flexDirection: 'row',
                            justifyContent: 'flex-end',
                            paddingRight: dimensWidth(15)
                        }}
                            colors={["#0262E9", "#0054AE"]} />
                        <NoDataView />
                    </View>)}
                </View>
            </View>
            <VBDenFilterModal
                modalVisible={modalFilter}
                onCloseModal={onCloseFilterModal}
                onConfirmModal={(data) => onConfirmFilterModal(data)}
                tinhTrangSellected={tinhtrangSellectedState}
            />
        </View>
    )
}

export default VBDenScreen