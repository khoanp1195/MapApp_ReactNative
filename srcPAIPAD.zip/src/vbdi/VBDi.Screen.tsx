import React, { useState, useCallback, useEffect,  } from 'react';
import { View, Text, ActivityIndicator,  } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { dimnensHeight, dimensWidth, funtionVBDiData } from '~/base/Constants';
import { BASE_URL, FontSize } from '../base/Constants'
import {
    isNullOrUndefined, calculateBetweenTwoDate,
    formatCreatedDate,
    arrayIsEmpty,
    checkIsEmpty,
    format_dd_mm_yy,
    isNullOrEmpty,
    removeSpecialCharacters,
} from '../base/Functions'
import { FlatList, RefreshControl, TouchableOpacity } from 'react-native-gesture-handler';
import { LoadingView, NoDataView, TopBarTab, } from '~/base/components';
import VBDiDetail from '~/detail/vbdi/VBDi.Detail.Screen';
import colors from '../base/Colors';
import { FilterIcon, LaCoIcon, MenuIcon, SearchIcon } from '~/base/assets/svg';
import SearchInput from '~/search/components/SearchInput';
import { fetchVBDiTab, onRefreshVbDiAction, } from '~/base/stories/vbdi/reducer';
import { RootState } from '~/base/stories';
import VbDiFilterModal from './components/VbDi.Filter.Modal';
import { LoaiFilterType } from './VBDiType';
import { useIsFocused } from '@react-navigation/native';
import FastImageCustom from '~/base/components/FastImageCustom';
import styles from './VBDi.Style'
import LinearGradientView from '~/base/components/LinearGradientView';
const ItemVbDiTitleLeft = ({ item, index, isVBChoXuLy, subSite, gotoDetail, selectedItemIndex }: any) => {
    const {
        SendUnit,
        ListName,
        ImagePath,
        Title,
        SiteName,
        Created,
        DueDate,
        Read,
        Action,
        DocumentID,
        TaskCategory
    } = item
    const gotoDetailPress = () => {
        gotoDetail(item, index, "Văn bản đi");
    };

    const formatCreated = formatCreatedDate(Created);
    let dueDateFormat = ""
    let isExpired = false
    let isExpiredToday = false
    const distanceDate: any = calculateBetweenTwoDate(DueDate);
    if (!checkIsEmpty(distanceDate) && isVBChoXuLy) {
        if (parseInt(distanceDate) < 0) {
            dueDateFormat = format_dd_mm_yy(DueDate);
        } else if (parseInt(distanceDate) >= 0 && parseInt(distanceDate) < 1) {
            dueDateFormat = "Hạn hôm nay";
            isExpiredToday = true
        }
        else {
            isExpired = true
            dueDateFormat = "Quá hạn " + distanceDate + " ngày";
        }
    }

    return (
        <TouchableOpacity onPress={gotoDetailPress}>
            <View style={styles.itemContainer}>
                <View style={styles.item}>
                    <View style={{
                        width: dimensWidth(5),
                        backgroundColor: selectedItemIndex == index ? '#015DD1' : null,
                    }} />

                    <View style={styles.avatarView}>
                        <FastImageCustom
                            styleImg={styles.itemAvatar}
                            urlOnline={`${BASE_URL}/${subSite}/${ImagePath}`}
                        />
                        <View style={styles.flexOne}>
                            <View style={styles.flexDirectionBetween}>
                                <Text style={styles.title} numberOfLines={1}>
                                    {SendUnit}
                                </Text>
                                <Text style={styles.date}>{formatCreated}</Text>
                            </View>

                            <View style={styles.flexRowBetween}>
                                <Text style={styles.category}>{ListName}</Text>
                                <Text style={styles.category} numberOfLines={1}>{TaskCategory}</Text>
                            </View>
                            <Text style={styles.title} numberOfLines={2}>{Title}</Text>
                            <View style={styles.flexDirectionBetween}>
                                <View style={styles.touchSendUnit}>
                                    <Text style={styles.textSendUnit}>{Action}</Text>
                                </View>
                                <View style={styles.laCoView}>
                                    {(item?.Priority ==
                                        1) && <LaCoIcon />}
                                </View>
                                <Text
                                    style={[
                                        styles.date,
                                        isExpiredToday && styles.todayDeadlife,
                                        isExpired && styles.distanceDate,
                                    ]}
                                >
                                    {dueDateFormat}
                                </Text>
                            </View>
                        </View>
                    </View>
                </View>
            </View>
        </TouchableOpacity>
    )
}
const ItemLeft = ({ item, index, subSite, token, gotoDetail, selectedItemIndex, isVBChoXuLy }: any) => {
    const {
        ID,
        Title,
        ActionStatus,
        TrichYeu,
        DueDate,
        Created,
        Status,
        Author,
        ImagePath,
    } = item
    const gotoDetailPress = () => {
        gotoDetail(item, index, "Văn bản đi");
    };

    const formatCreated = formatCreatedDate(Created);
    let dueDateFormat = ""
    let isExpired = false
    let isExpiredToday = false
    const distanceDate: any = calculateBetweenTwoDate(DueDate);
    if (!checkIsEmpty(distanceDate) && isVBChoXuLy) {
        if (parseInt(distanceDate) < 0) {
            dueDateFormat = format_dd_mm_yy(DueDate);
        } else if (parseInt(distanceDate) >= 0 && parseInt(distanceDate) < 1) {
            dueDateFormat = "Hạn hôm nay";
            isExpiredToday = true
        }
        else {
            isExpired = true
            dueDateFormat = "Quá hạn " + distanceDate + " ngày";
        }
    }

    return (
        <TouchableOpacity onPress={gotoDetailPress}>
            <View style={styles.itemContainer}>
                <View style={styles.item}>
                    <View style={{
                        width: dimensWidth(5),
                        backgroundColor: selectedItemIndex == index ? '#015DD1' : null,
                    }} />

                    <View style={styles.avatarView}>
                        <FastImageCustom
                            styleImg={styles.itemAvatar}
                            urlOnline={`${BASE_URL}/${subSite}/${ImagePath}`}
                        />
                        <View style={styles.flexOne}>
                            <View style={styles.flexDirectionBetween}>
                                <Text style={styles.title} numberOfLines={1}>
                                    {!isNullOrEmpty(Author) ? removeSpecialCharacters(Author) : ""}
                                </Text>
                                <Text style={styles.date}>{formatCreated}</Text>
                            </View>

                            <Text style={[styles.category, { marginEnd: 20 }]}>{"Văn bản đi"}</Text>
                            <Text style={styles.title} numberOfLines={1}>{Title}</Text>
                            <View style={styles.flexDirectionBetween}>
                                <View style={styles.touchSendUnit}>
                                    <Text style={styles.textSendUnit}>{item?.Status}</Text>
                                </View>
                                <View style={styles.laCoView}>
                                    {(item?.Priority ==
                                        1) && <LaCoIcon />}
                                </View>
                                <Text
                                    style={[
                                        styles.date,
                                        isExpiredToday && styles.todayDeadlife,
                                        isExpired && styles.distanceDate,
                                    ]}
                                >
                                    {dueDateFormat}
                                </Text>
                            </View>
                        </View>
                    </View>
                </View>
            </View>
        </TouchableOpacity>
    )
}

const VBDiScreen = ({ route, navigation }: any) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { subSite, token } = useSelector(
        (state: RootState) => state.login);

    const { dataVBDiTab, isRefreshVBDiScreen, isLoadingVBDi, isRefreshVBDiState } = useSelector(
        (state: RootState) => state.vbdi);
    const { totalRecord, totalRecordVBDiTitle, } = dataVBDiTab;
    const flatListRef = React.useRef()
    const [dataVBDiTabState, setDataVBDiTabState] = useState([])
    const [offset, setOffset] = useState(0)
    const [status, setStatus] = useState(0)
    const [Item, setItem] = useState<any>({})
    const [selectedItemIndex, setSelectedItemIndex] = useState(0)
    const [isShowSearch, setIsShowSearch] = useState(false)
    const [textSearch, setTextSearch] = useState("")
    const [LoaiFilterTypeState, setLoaiFilterTypeState] = useState("Tất cả");
    const [fromDate, setFromDate] = useState("")
    const [toDate, setToDate] = useState("")
    const [modalFilter, setModalFilter] = useState(false)
    const [funtionVBDiState, setFuntionVBDiState] = useState<any>(funtionVBDiData.VBDiTitle);
    const isFocused = useIsFocused();
    const [isDefaultFilter, setIsDefaultFilter] = useState(true)

    useEffect(() => {
        if (isNullOrUndefined(fromDate) && isNullOrUndefined(toDate) && LoaiFilterTypeState == "Tất cả") {
            setIsDefaultFilter(true)
        } else {
            setIsDefaultFilter(false)
        }
    }, [fromDate, toDate, LoaiFilterTypeState,])

    const fetchDataLeftList = useCallback(async (
        status: number,
        offset: number,
        subSite: string,
        FilterText: string,
        funtionVBDi: any,
        TinhTrang: any,
        FromDate: string,
        ToDate: string,
    ) => {
        dispatch(fetchVBDiTab({
            offset: offset,
            status: status,
            subSite: subSite,
            FilterText: FilterText,
            funtionVBDi,
            TinhTrang: TinhTrang === LoaiFilterType.TAT_CA ? "" : TinhTrang,
            FromDate,
            ToDate,
        }));
    }, [dispatch]);
    const onRefreshVBDi = useCallback(() => {
        dispatch(onRefreshVbDiAction(null))
        setFuntionVBDiState(funtionVBDiData.VBDiTitle)
        resetData()
        dispatch(fetchVBDiTab({
            offset: offset,
            status: status,
            subSite: subSite,
            FilterText: "",
            funtionVBDi: funtionVBDiData.VBDiTitle,
            TinhTrang: "",
            FromDate: "",
            ToDate: "",
        }));
    }, [dispatch, status, subSite]);

    const onPressTabProcessing = useCallback(() => {
        setStatus(0)
        setOffset(0)
    }, []);

    useEffect(() => {
        if (isRefreshVBDiScreen) {
            resetData()
            dispatch(fetchVBDiTab({
                offset: offset,
                status: status,
                subSite: subSite,
                FilterText: "",
                funtionVBDi: funtionVBDiState,
                TinhTrang: "",
                FromDate: "",
                ToDate: "",
            }));
        }
    }, [isRefreshVBDiScreen, status, subSite, funtionVBDiState, dispatch])

    const onPressTabProcessed = useCallback(() => {
        setStatus(1)
        setOffset(0)
    }, []);
    const resetData = useCallback(() => {
        setOffset(0);
        setTextSearch("")
        setLoaiFilterTypeState("Tất cả")
        setFromDate("")
        setFromDate("")
    }, []);

    useEffect(() => {
        const TinhTrang = LoaiFilterTypeState
        if (isFocused) {
            fetchDataLeftList(status, offset, subSite, textSearch, funtionVBDiState,
                TinhTrang,
                fromDate,
                toDate,
            )
        }
    }, [isFocused, LoaiFilterTypeState, funtionVBDiState, status, subSite, fromDate, toDate, offset, textSearch, dispatch]);

    useEffect(() => {
        if (!isNullOrUndefined(dataVBDiTab.data)) {
            setDataVBDiTabState(dataVBDiTab.data)
            if (offset == 0) {
                setSelectedItemIndex(0)
                setItem(dataVBDiTab.data[0])
            }
        }
    }, [dataVBDiTab, offset]);

    const gotoDetailPress = useCallback((item: any, index: number) => {
        setSelectedItemIndex(index)
        setItem(item)
    }, [Item]);

    const handleLoadmore = async () => {
        if (totalRecord > dataVBDiTabState.length) {
            setOffset(dataVBDiTabState.length);
        }
    };

    const openDrawer = useCallback(() => {
        navigation.openDrawer();
    }, [navigation]);

    const onSearchPress = useCallback(() => {
        setIsShowSearch(!isShowSearch)
    }, [isShowSearch])

    const onChangeFilterText = useCallback(
        (text: string) => {
            setTextSearch(text);
            setOffset(0)
        },
        [textSearch, offset]
    );
    const onCloseFilterModal = useCallback(() => {
        setModalFilter(false)
    }, [modalFilter])

    const onConfirmFilterModal = useCallback((data: any) => {
        if (!isNullOrUndefined(data)) {
            setLoaiFilterTypeState(data.DocumentType)
            setToDate(data.ToDate)
            setFromDate(data.FromDate)
            setOffset(0)
        }

        setModalFilter(false)
    }, [])

    const renderFooter = (loading: boolean, offset: number) => {
        if (arrayIsEmpty(dataVBDiTabState)) return <View />
        return (
            <View style={styles.viewFooter}>
                {loading && offset !== 0 ? (
                    <ActivityIndicator color={colors.blueMedium} style={{ marginLeft: 8 }} />
                ) : null}
            </View>
        );
    };
    const renderEmpty = () => {
        if (isLoadingVBDi && !isRefreshVBDiScreen) return <LoadingView isLoading={isLoadingVBDi || isRefreshVBDiScreen} bgColor={colors.white} viewLoadingStyle={{ top: dimnensHeight(100) }} />
        return (
            <NoDataView />
        )
    }
    return (
        <View style={styles.vbContainer}>
            <View style={styles.flexRowOne}>
                <View style={styles.leftContainer}>
                    <LinearGradientView style={{
                        paddingLeft: dimensWidth(15),
                        height: dimnensHeight(55),
                    }}>
                        <View style={styles.flexRowCenter}>
                            <TouchableOpacity onPress={openDrawer} style={styles.menuView}>
                                <MenuIcon color={colors.white} />
                            </TouchableOpacity>

                            <View style={styles.flexOne}>
                                <Text style={styles.txtSubSite}>{subSite.toUpperCase()}</Text>
                                <Text style={styles.textTitle}>{`${funtionVBDiState.title}`}</Text>
                            </View>
                            <TouchableOpacity style={styles.filterIcon} onPress={() => setModalFilter(true)}>
                                <FilterIcon color={isDefaultFilter ? colors.white : colors.red} />
                            </TouchableOpacity>
                            <View style={styles.dashWhite} />
                        </View>
                    </LinearGradientView>
                    <TopBarTab
                        isShowSearch={isShowSearch}
                        textSearch={textSearch}
                        onChangeFilterText={onChangeFilterText}
                        onPressTabProcessing={onPressTabProcessing}
                        status={status}
                        totalRecordString={totalRecordVBDiTitle}
                        onPressTabProcessed={onPressTabProcessed}
                        onSearchPress={onSearchPress}
                    />
                    {
                        !arrayIsEmpty(dataVBDiTabState) ?
                            <FlatList
                                ref={flatListRef}
                                data={dataVBDiTabState}
                                extraData={dataVBDiTabState}
                                refreshControl={
                                    <RefreshControl refreshing={isRefreshVBDiState} onRefresh={onRefreshVBDi} tintColor='#0054AE' />
                                }
                                onEndReachedThreshold={0.5}
                                onEndReached={handleLoadmore}
                                showsVerticalScrollIndicator={true}
                                keyExtractor={(item, index) => index.toString()}
                                getItemLayout={(_, index) => ({
                                    length: dimnensHeight(134), //  WIDTH + (MARGIN_HORIZONTAL * 2)
                                    offset: dimnensHeight(134) * (index),  //  ( WIDTH + (MARGIN_HORIZONTAL*2) ) * (index)
                                    index,
                                })}
                                ListFooterComponent={renderFooter(isLoadingVBDi, offset)}
                                renderItem={({ item, index }) => (
                                    funtionVBDiState.key === funtionVBDiData.VBDiTitle.key ? <ItemVbDiTitleLeft
                                        item={item}
                                        index={index}
                                        subSite={subSite}
                                        token={token}
                                        gotoDetail={gotoDetailPress}
                                        isVBChoXuLy={status === 0}
                                        selectedItemIndex={selectedItemIndex}
                                    /> :
                                        <ItemLeft
                                            item={item}
                                            index={index}
                                            subSite={subSite}
                                            token={token}
                                            gotoDetail={gotoDetailPress}
                                            isVBChoXuLy={status === 0}
                                            selectedItemIndex={selectedItemIndex}
                                        />
                                )} /> : renderEmpty()
                    }
                </View>
                <View style={styles.rightContainer}>
                    {Item ? <VBDiDetail route={{
                        ItemId: Item?.DocumentID ? Item?.DocumentID : Item?.ID
                    }} navigation={navigation} token={token} selectedItemIndex={selectedItemIndex} /> : (<View style={{ flex: 1 }} >
                        <LinearGradientView style={styles.noDataView}/>
                        <NoDataView />
                    </View>)}
                </View>
            </View>
            <VbDiFilterModal
                modalVisible={modalFilter}
                onCloseModal={onCloseFilterModal}
                onConfirmModal={(data) => onConfirmFilterModal(data)}
                loaiFilterType={LoaiFilterTypeState}
            />
        </View>
    )
}

export default React.memo(VBDiScreen)