import {StyleSheet, Platform} from 'react-native';
import colors from '../base/Colors';
import {dimensWidth, dimnensHeight, FontSize} from '../base/Constants' 
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.whiteLilac,
  },
  vbContainer: {
    flex: 1,
    backgroundColor: colors.gray,
  },
  containerFlatList:{
    marginTop: dimensWidth(15),
    paddingBottom: 100,
  },
  searchIcon:{
    marginRight:25
  },
  filterIcon:{
    marginRight:15
  },
  item: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: colors.white,
    //padding: dimensWidth(15),
    marginBottom: dimensWidth(10),
    borderRadius: 8,
    justifyContent: 'center',
  },
  title: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: '400',
    fontFamily: 'arial',
    marginBottom: 6,
    marginRight: dimensWidth(5),
    flex: 1
  },
  date: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: '400',
    fontFamily: 'arial',
    marginBottom: 6,
  },
  todayDeadlife: {
    color: colors.purple
  },
  category: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: '400',
    fontFamily: 'arial',
    marginBottom: 6,
    marginRight: dimensWidth(5)
  },
  distanceDate: {
    fontSize: dimensWidth(13),
    color: colors.red,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  textSendUnit:{
    fontSize: dimensWidth(12),
    color: colors.primary,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  touchSendUnit:{
    backgroundColor: colors.lightBlue,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 3,
    alignSelf: 'baseline'
  },
  viewAvatar: {
    backgroundColor: colors.primary,
    height: Platform.OS === 'ios' ? 160 : 120,
    justifyContent: 'center',
    width: '100%',
  },
  titleAvatar: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  avatar: {
    height: dimensWidth(36),
    width: dimensWidth(36),
    marginRight: dimensWidth(10),
    marginLeft: dimensWidth(15),
    borderRadius: dimensWidth(18),
  },
  itemAvatar: {
    height: dimensWidth(40),
    width: dimensWidth(40),
    marginRight: dimensWidth(10),
    borderRadius: dimensWidth(20),
  },
  flexDirectionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  flexDirectionRowTab: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'baseline',
    borderRadius: 27,
    marginLeft: 15,
    backgroundColor: colors.tab_bg_blue,
    borderColor: colors.white,
    borderWidth: 0.5,
  },
  onPressActiveTab: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    backgroundColor: colors.white,
    borderRadius: 27,
  },
  onPressInActiveTab: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 27,
  },
  titleActiveTab: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.primary,
    fontWeight: '700',
    fontFamily: 'arial',
  },
  titleInActiveTab: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  flexDirectionBetween:{
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  titleNotifyCount: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.orange,
    fontWeight: '700',
    fontFamily: 'arial',
  },
  footer: {
    padding: 10,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  flexRowOne:{
      flex: 1,
      flexDirection: 'row',
  },
  leftContainer:{
    width: '35%'
},
flexRowCenter:{
  flex: 1,
  flexDirection: 'row',
  alignItems: "center",
},
menuView: {
  marginRight: dimensWidth(10),
},
flexOne:{ flex: 1 },
txtSubSite: {
  color: colors.white,
  fontSize: FontSize.LARGE,
  fontWeight: '400',
  fontFamily: 'arial',
},
textTitle: {
  color: colors.white,
  fontSize: FontSize.MEDIUM,
  marginTop: dimnensHeight(2),
  fontWeight: '400',
  fontFamily: 'arial',
},
dashWhite: {
  height: '50%',
  width: 1,
  backgroundColor: 'white'
},
topTabContainer: {
  width: '100%',
  height: dimnensHeight(55),
  justifyContent: 'center'
},
flexRow:{
  flexDirection: 'row',
},
tabView:{
  height: dimnensHeight(35),
  borderWidth: 1,
  borderRadius: 20,
  borderColor: '#005FD4',
  marginLeft: dimensWidth(15),
  marginRight: dimensWidth(15),
  backgroundColor: colors.white,
  flexDirection: 'row',
  justifyContent: 'center',
  alignItems: 'center'
},
touchTabContainer:{
  flexDirection: 'row',
  alignItems: 'center',
  alignSelf: 'baseline',
  borderRadius: dimensWidth(18),
  height: dimnensHeight(35),
  marginLeft: 15,
  // width: dimensWidth(270),
  backgroundColor: colors.tab_bg_blue,
  borderColor: colors.white,
  borderWidth: 1,
  padding: 0,
},
tabInActive:{
  paddingVertical: 6,
  paddingHorizontal: 12,
  backgroundColor: colors.white,
  borderRadius: dimensWidth(18),
  margin: 1
},
tabActive:  {
  paddingVertical: 6,
  paddingHorizontal: 12,
  borderRadius: dimensWidth(18),
},
searchView: {
  flex: 1,
  justifyContent: 'center',
  marginRight: dimensWidth(15)
},
noDataView:{
  paddingLeft: dimensWidth(15),
  height: dimnensHeight(55),
  alignItems: 'center',
  flexDirection: 'row',
  justifyContent: 'flex-end',
  paddingRight: dimensWidth(15)
},
itemContainer:{
  flex: 1,
  flexDirection: 'row',
  marginHorizontal: dimensWidth(15),
  shadowColor: '#000000',
  shadowOffset: {
      width: 0,
      height: 0
  },
  shadowRadius: 8,
  shadowOpacity: 0.1,
  elevation: 1
},
avatarView :{
  flex: 1,
  flexDirection: 'row',
  padding: dimensWidth(15),
  borderRadius: 8,
  justifyContent: 'center',
},
flexRowBetween :{
  flex: 1,
  flexDirection: 'row',
  justifyContent: 'space-between',
},
laCoView: { flex: 1, marginLeft: 10 },
viewFooter: {
  padding: 10,
  justifyContent: 'center',
  alignItems: 'center',
  flexDirection: 'row'
},
rightContainer: {
  width: '65%',
}
});
export default styles;
