import React, { FC, useState, useCallback, useEffect } from "react";
import {
    Modal,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    KeyboardAvoidingView,
} from "react-native";
import { FlatList } from "react-native-gesture-handler";
import colors from "~/base/Colors";
import { FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";
import { isNullOrUndefined } from "~/base/Functions";
import { BackIcon, CloseXIcon, SelectedDisableIcon, SelectedEnalbleIcon } from "~/base/assets/svg";
import DashedLine from 'react-native-dashed-line';
import ModalCusTom from "~/base/components/ModalCusTom";

interface Props {
    modalVisible: Boolean;
    defaultValue: string;
    onCloseModal: () => void;
    onConfirmModal: (data: any) => void;
}

const HomeDocumentTypeModal: FC<Props> = ({
    modalVisible,
    onCloseModal,
    onConfirmModal,
    defaultValue,
    ...props
}: Props) => {

    const Item = ({ item, selectedId, isEnd, onItemPress }: any) => {
        const { ID, Title } = item

        const gotoDetailPress = () => {
            onItemPress(item);
        };

        return (
            <View>
                <TouchableOpacity
                    style={[styles.item, Title === "Tất cả" && { borderTopWidth: 0 }]}
                    onPress={gotoDetailPress}
                >
                    <Text style={styles.title}>{Title}</Text>
                    <View>
                        {ID === selectedId ? (
                            <SelectedEnalbleIcon />
                        ) : (
                            <SelectedDisableIcon />
                        )}
                    </View>
                </TouchableOpacity>
                {
                    isEnd ? <View /> : (
                        <View style={{ marginHorizontal: dimensWidth(20) }}>
                            <DashedLine dashLength={2} dashColor='#B3B3B3' />
                        </View>
                    )
                }

            </View>
        )
    }

    const data = [
        {
            "ID": 0,
            "Title": "Tất cả"
        },
        {
            "ID": 1,
            "Title": "Chờ phê duyệt"
        },
        {
            "ID": 2,
            "Title": "Đã phê duyệt"
        },
        {
            "ID": 3,
            "Title": "Đã phát hành"
        }
    ]

    const [selecteId, setSelectId] = useState(1)

    const onItemPress = useCallback((item: any) => {
        setSelectId(item.ID)
        onConfirmModal(item)
    }, [selecteId, data])

    useEffect(() => {
        if (!isNullOrUndefined(defaultValue)) {
            for (let index = 0; index < data.length; index++) {
                const element = data[index];
                if (element.Title === defaultValue) {
                    setSelectId(element.ID)
                }
            }
        }
    }, [defaultValue])

    return (
        <ModalCusTom transparent={true}
            visible={modalVisible}
            {...props}
            onCloseModalCustom={onCloseModal}
            style={styles.centeredView}>

            <KeyboardAvoidingView style={styles.centeredView}>
                <View style={styles.modalView}>
                    <View style={{
                        padding: dimensWidth(20),
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'center',
                        backgroundColor: 'white'
                    }}>
                        <TouchableOpacity onPress={onCloseModal}>
                            <BackIcon />
                        </TouchableOpacity>
                        <Text style={{
                            flex: 1,
                            color: '#005FD4',
                            fontSize: FontSize.LARGE_X,
                            fontWeight: 700,
                            marginLeft: dimensWidth(15)
                        }}>Tình trạng</Text>


                        <TouchableOpacity onPress={onCloseModal}>
                            <CloseXIcon />
                        </TouchableOpacity>

                    </View>

                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        backgroundColor: '#F6F8FA'
                    }} />

                    <FlatList
                        contentContainerStyle={styles.flatlist}
                        data={data}
                        extraData={selecteId}
                        renderItem={({ index, item }) => (
                            <Item
                                item={item}
                                selectedId={selecteId}
                                onItemPress={onItemPress}
                                isEnd={index === data.length - 1}
                            />
                        )}
                        keyExtractor={(item) => item.ID.toString()}
                    />
                </View>
            </KeyboardAvoidingView>
        </ModalCusTom>
    )
}

const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(0,0,0,0.4)"
    },
    modalView: {
        height: dimnensHeight(650),
        width: dimensWidth(700),
        backgroundColor: '#F6F8FA',
        borderRadius: 20,
        overflow: 'hidden'
    },
    item: {
        flexDirection: "row",
        justifyContent: "space-between",
        padding: dimensWidth(20),
    },
    title: {
        fontSize: FontSize.LARGE,
        lineHeight: dimensWidth(20),
        color: colors.black,
        fontWeight: "400",
        fontFamily: "arial",
    },
    flatlist: {
        backgroundColor: "#FFFFFF",
        borderRadius: 8,
    }
});

export default HomeDocumentTypeModal