import React, { useState, useCallback, useEffect, useMemo } from "react";
import {
  Text,
  SafeAreaView,
  Image,
  View,
  processColor,
  ImageBackground,
  TouchableOpacity,
  RefreshControl,
} from "react-native";
import { useDispatch, useSelector } from "react-redux";
import styles from "./Search.Style";
import { useNavigation } from "@react-navigation/native";
import CalendarPickerModal from "./components/CalendarPickerModal";
import { arrayIsEmpty, calculateBetweenTwoDate, checkIsEmpty, formatCreatedDate, format_dd_mm_yy, isNullOrEmpty, isNullOrUndefined, removeSpecialCharacters } from "../base/Functions";
import {
  ChevronDownIcon,
  DateIcon,
  LaCoIcon,
  MenuIcon,
  ThreeDotIcon,
} from "../base/assets/svg/index";
import colors from "../base/Colors";
import LinearGradient from "react-native-linear-gradient";
import { BASE_URL, FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";
import { FlatList, TextInput } from "react-native-gesture-handler";
import { defaulItemTatCa, fetchDataSearch } from "~/base/stories/search/reducer";
import { LoadingView, NoDataView } from "~/base/components";
import VBDiDentail from "~/detail/vbdi/VBDi.Detail.Screen";
import VBDenDetail from "~/detail/vbden/VBDen.Detail.Screen";
import VBBHDetail from "~/detail/vbbh/VBBH.Detail.Screen";
import { RootState } from "~/base/stories";
import NguoiKyModal from "./components/NguoiKy.Modal";
import CoQuanGuiModal from "./components/CoQuanGui.Modal";
import LoaiVanBanModal from "./components/LoaiVanBan.Modal";
import LoaiVBModal, { LoaiVBData } from "./components/LoaiVB.Modal";
import FastImageCustom from "~/base/components/FastImageCustom";

const ItemLeft = ({ item, index, gotoDetail, selectedItemIndex }: any) => {
  const {
    ID,
    Title,
    TrichYeu,
    CoQuanGui,
    NgayTrenVB,
    DueDate,
    ListName,
    TrangThai,
    SoDen,
    NgayDen,
    DoKhan
  } = item
  const gotoDetailPress = () => {
    gotoDetail(item, index);
  };

  const formatCreated = format_dd_mm_yy(NgayTrenVB);
  let dueDateFormat = ""
  let isExpired = false
  let isExpiredToday = false
  const distanceDate = calculateBetweenTwoDate(NgayDen);
  if (!checkIsEmpty(distanceDate)) {
    if (parseInt(distanceDate) < 0) {
      dueDateFormat = format_dd_mm_yy(NgayDen);
    } else if (parseInt(distanceDate) >= 0 && parseInt(distanceDate) < 1) {
      dueDateFormat = "Hạn hôm nay";
      isExpiredToday = true
    }
    else {
      isExpired = true
      dueDateFormat = "Quá hạn " + distanceDate + " ngày";
    }
  }
  const isDoKhan = (DoKhan === "Thượng khẩn" || DoKhan === "Hỏa tốc")
  return (
    <TouchableOpacity onPress={gotoDetailPress}>
      <View style={{
        flex: 1,
        flexDirection: 'row',
        marginHorizontal: dimensWidth(15)
      }}>
        <View style={styles.item}>
          <View style={{
            width: dimensWidth(5),
            backgroundColor: selectedItemIndex == index ? '#015DD1' : null,
          }} />
          <View style={{
            flex: 1,
            flexDirection: 'row',
            padding: dimensWidth(15),
            borderRadius: 8,
            justifyContent: 'center',
          }}>
            <FastImageCustom
              styleImg={styles.itemAvatar}
              urlOnline={""}
            />
            <View style={{ flex: 1 }}>
              <View style={styles.flexDirectionBetween}>
                <Text style={styles.title} numberOfLines={1}>
                  {removeSpecialCharacters(CoQuanGui)}
                </Text>
                <Text style={styles.dateNgayDen}>{formatCreated}</Text>
              </View>
              <View style={styles.flexDirectionBetween}>
                <Text style={styles.dateSearch} numberOfLines={1}>{ListName}</Text>
                <Text style={[styles.blueText, { flex: 1.5, textAlign: 'right' }]} numberOfLines={1}>{item?.SoVanBan?.toString()}</Text>

              </View>
              {/* <Text style={styles.category} numberOfLines={1}>{Title}</Text> */}
              <Text style={styles.title} numberOfLines={2}>{TrichYeu}</Text>

              <View style={styles.flexDirectionBetween}>
                <View style={styles.touchSendUnit}>
                  <Text style={styles.textSendUnit}>{TrangThai}</Text>
                </View>
                <View style={[styles.flexDirectionBetween, { flex: 1, marginLeft: 15, }]}>
                  <View>
                    {isDoKhan && <LaCoIcon />}
                  </View>
                  <Text
                    style={[
                      styles.dateNgayDen,
                      isExpiredToday && styles.todayDeadlife,
                      isExpired && styles.distanceDate,
                    ]}
                  >
                    {dueDateFormat}
                  </Text>
                </View>
              </View>
            </View>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  )
}

const SearchScreen = () => {
  const dispatch = useDispatch<any>();
  const initialLoaiVBString = {
    Title: 'Văn bản đến; Văn bản dự thảo; Văn bản ban hành',
    ID: ''
  }
  const { subSite, token } = useSelector(
    (state: RootState) => state.login);
  const { dataSearch, loadingSearch } = useSelector(
    (state: RootState) => state.search);
  const [selectedItemIndex, setSelectedItemIndex] = useState(-1)
  const [offset, setOffset] = useState(0)
  const [Item, setItem] = useState<any>({})
  const [hiddenInfo, setHiddenInfo] = useState(true)
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [isOpenCalendarPicker, setIsOpenCalendarPicker] = useState(false);
  const [typeModal, setTypeModal] = useState("startDate");
  const [modalNguoiKy, setModalNguoiKy] = useState(false)
  const [ItemNguoiKy, setItemNguoiKy] = useState(defaulItemTatCa[0])
  const [ItemNCoQuanGui, setItemNCoQuanGui] = useState<any>(defaulItemTatCa[0]);
  const [modalCoQuanGui, setModalCoQuanGui] = useState(false)
  const [ItemLoaiVanBan, setItemLoaiVanBan] = useState<any>(defaulItemTatCa[0]);
  const [modalLoaiVanBan, setModalLoaiVanBan] = useState(false)
  const [modalLoaiVB, setModalLoaiVB] = useState(false)
  const [loaiVBString, setLoaiVBString] = useState<any>(initialLoaiVBString);
  const [loaiVBparams, setLoaiVBParams] = useState<any>(LoaiVBData);
  const [filterText, setFilterText] = useState("");
  const [isRefreshVBDi, setIsRefreshVBDi] = useState(false)
  const onRefreshVBSearch = useCallback(() => {
    onReFilterModalPress();
    dispatch(fetchDataSearch({
      Content: "",
      SubSite: subSite,
      Offset: 0,
      LoaiVanBan: "",
      CoQuanGui: "",
      NguoiKyVanBan: "",
      Type: "",
      TuNgay: "",
      DenNgay: ""
    }))
  }, [dispatch, subSite])
  const onChangeFilterText = useCallback(
    (text: string) => {
      setFilterText(text);
    },
    [filterText]
  );
  const fetchSearchRequest = useCallback(() => {
    dispatch(fetchDataSearch({
      Content: "",
      SubSite: subSite,
      Offset: 0,
      LoaiVanBan: "",
      CoQuanGui: "",
      NguoiKyVanBan: "",
      Type: "",
      TuNgay: "",
      DenNgay: ""
    }))
  }, [dispatch, subSite])
  const onPressOpenCalendarPicker = useCallback((typeModal: string) => {
    setTypeModal(typeModal);
    setIsOpenCalendarPicker(true);
  }, []);
  const onDateChangeModal = useCallback(
    (date: any) => {
      if (typeModal == "startDate") {
        setStartDate(date);
      } else {
        console.log("datedate", typeModal, date);
        setEndDate(date);
      }
      setIsOpenCalendarPicker(false);
    },
    [typeModal, startDate, endDate]
  );
  const onCloseModal = useCallback(() => {
    setIsOpenCalendarPicker(false);
  }, []);
  const navigation = useNavigation();

  const openDrawer = useCallback(() => {
    navigation.openDrawer();
  }, [navigation]);

  const gotoDetailPress = useCallback((item, index) => {
    setSelectedItemIndex(index)
    setItem(item)
  }, [Item]);

  useEffect(() => {
    if (offset == 0 && !arrayIsEmpty(dataSearch)) {
      setSelectedItemIndex(0)
      setItem(dataSearch[0])
    }
  }, [dataSearch])

  useEffect(() => {
    fetchSearchRequest()
  }, [navigation, subSite])
  const handleLoadmore = async () => {
    setOffset(dataSearch.length);
  };
  const removeSelectedDate = useCallback(() => {
    if (typeModal == "startDate") {
      setStartDate("");
    } else {
      setEndDate("");
    }
  }, [typeModal, startDate, endDate]);
  const resetToday = useCallback(
    (today: any) => {
      // if (typeModal == "startDate") {
      //   setStartDate(today);
      // } else {
      //   setEndDate(today);
      // }
      setStartDate(today);
      setEndDate(today);
    },
    [typeModal, startDate, endDate]
  );

  const onConfirmNguoiKy = useCallback((data: any) => {
    setModalNguoiKy(false)
    setItemNguoiKy(data)
  }, [Item?.ID])
  const onConfirmCoQuanGui = useCallback((data: any) => {
    setModalCoQuanGui(false)
    setItemNCoQuanGui(data)
  }, [Item?.ID])
  const onConfirmLoaiVanBan = useCallback((data: any) => {
    setModalLoaiVanBan(false)
    setItemLoaiVanBan(data)
  }, [Item?.ID])
  const onConfirmLoaiVB = useCallback((data: any, dataParams: any) => {
    setModalLoaiVB(false)
    setLoaiVBString(data)
    setLoaiVBParams(dataParams)
  }, [Item?.ID])
  const onNguoiKyPress = useCallback(() => {
    setModalNguoiKy(!modalNguoiKy)
  }, [modalNguoiKy])
  const onConfirmSearch = useCallback(() => {
    const NguoiKyVanBan = ItemNguoiKy?.ID === 99999 ? "" : ItemNguoiKy?.ID
    const LoaiVanBan = ItemLoaiVanBan?.ID === 99999 ? "" : ItemLoaiVanBan?.ID
    const CoQuanGui = ItemNCoQuanGui?.ID === 99999 ? "" : ItemNCoQuanGui?.ID
    const Type = loaiVBString?.ID
    dispatch(fetchDataSearch({
      Offset: 0,
      Content: filterText,
      CoQuanGui,
      LoaiVanBan,
      NguoiKyVanBan,
      Type,
      TuNgay: startDate,
      DenNgay: endDate,
      SubSite: subSite,
    }))
    setHiddenInfo(true)
  }, [subSite, loaiVBString, offset, startDate, endDate, ItemNCoQuanGui, ItemNguoiKy, ItemLoaiVanBan, ItemLoaiVanBan, filterText])
  const onReFilterModalPress = useCallback(() => {
    setStartDate("");
    setEndDate("");
    setTypeModal("startDate")
    setFilterText("")
    setItemNCoQuanGui(defaulItemTatCa[0])
    setItemLoaiVanBan(defaulItemTatCa[0])
    setItemNguoiKy(defaulItemTatCa[0])
    setLoaiVBString(initialLoaiVBString)
  }, []);

  return (
    <View style={{
      flex: 1,
      backgroundColor: colors.gray
    }}>
      <View style={{
        flex: 1,
        flexDirection: 'row',
      }}>
        <View style={{
          width: '35%',
        }}>
          <LinearGradient style={{
            paddingLeft: dimensWidth(15),
            height: dimnensHeight(55),
          }}
            colors={["#0262E9", "#0054AE"]}>
            <View style={{
              flex: 1,
              flexDirection: 'row',
              alignItems: "center",
            }}>
              <TouchableOpacity onPress={openDrawer} style={{
                marginRight: dimensWidth(10),
              }}>
                <MenuIcon color={'#fff'} />
              </TouchableOpacity>

              <View style={{flex: 1}}> 
                <Text style={{
                  color: colors.white,
                  fontSize: FontSize.LARGE,
                  fontWeight: '400',
                  fontFamily: 'arial',
                }}>{subSite.toUpperCase()}</Text>
                <Text style={{
                  color: colors.white,
                  fontSize: FontSize.MEDIUM,
                  fontWeight: '400',
                  fontFamily: 'arial',
                  marginTop: dimnensHeight(2)
                }}>Tra cứu</Text>
              </View>
              <View style={{
                                height: '50%',
                                width: 1,
                                backgroundColor: 'white'
                            }} />
            </View>
          </LinearGradient>

          <View style={{
            padding: dimensWidth(15),
            backgroundColor: 'white',
            borderRadius: 8,
            margin: dimensWidth(15),
            shadowColor: '#000000',
            shadowOffset: {
              width: 0,
              height: 0
            },
            shadowRadius: 8,
            shadowOpacity: 0.2,
            elevation: 1,
          }}>
            <View style={{
              flexDirection: 'row',
              alignItems: 'center'
            }}>
              <Text style={{
                flex: 1,
                color: '#5E5E5E',
                fontSize: FontSize.SMALL,
                fontWeight: 400, paddingRight: 10
              }}>
                Từ khoá
              </Text>
              <TouchableOpacity onPress={() => setHiddenInfo(!hiddenInfo)} style={{ padding: 10 }}>
                <ThreeDotIcon color={hiddenInfo ? '#0072C6' : '#CDCDCD'} />
              </TouchableOpacity>
            </View>
            <TextInput
              onChangeText={onChangeFilterText}
              value={filterText}
              style={{
                height: dimnensHeight(35),
                borderWidth: 1,
                borderRadius: 3,
                borderColor: '#DDD',
                padding: dimensWidth(5),
                marginTop: dimnensHeight(8)
              }}
              placeholder="Tìm kiếm …"
            />
            {
              hiddenInfo ? <></> : (
                <View>
                  <View style={{
                    marginTop: dimnensHeight(15),
                  }}>
                    <Text style={{
                      color: '#5E5E5E',
                      fontSize: FontSize.SMALL,
                      fontWeight: 400
                    }}>
                      Loại văn bản
                    </Text>

                    <TouchableOpacity
                      onPress={() => { setModalLoaiVanBan(true) }}
                      style={{
                        flexDirection: 'row',
                        height: dimnensHeight(35),
                        borderWidth: 1,
                        borderRadius: 3,
                        borderColor: '#DDD',
                        alignItems: 'center',
                        padding: dimensWidth(5),
                        marginTop: dimnensHeight(8),
                        paddingHorizontal: dimensWidth(10)
                      }}>
                      <Text style={{ flex: 1, paddingRight: 10 }}>{ItemLoaiVanBan?.Title}</Text>
                      <View>
                        <ChevronDownIcon />
                      </View>
                    </TouchableOpacity>
                  </View>

                  <TouchableOpacity
                    onPress={() => setModalCoQuanGui(true)}
                    style={{
                      marginTop: dimnensHeight(15),
                    }}>
                    <Text style={{
                      color: '#5E5E5E',
                      fontSize: FontSize.SMALL,
                      fontWeight: 400
                    }}>
                      Cơ quan gửi
                    </Text>

                    <View style={{
                      flexDirection: 'row',
                      height: dimnensHeight(35),
                      borderWidth: 1,
                      borderRadius: 3,
                      borderColor: '#DDD',
                      alignItems: 'center',
                      padding: dimensWidth(5),
                      marginTop: dimnensHeight(8),
                      paddingHorizontal: dimensWidth(10)
                    }}>
                      <Text style={{ flex: 1, paddingRight: 10 }}>{ItemNCoQuanGui?.Title}</Text>
                      <View>
                        <ChevronDownIcon />
                      </View>
                    </View>
                  </TouchableOpacity>

                  <TouchableOpacity onPress={onNguoiKyPress} style={{
                    marginTop: dimnensHeight(15),
                  }}>
                    <Text style={{
                      color: '#5E5E5E',
                      fontSize: FontSize.SMALL,
                      fontWeight: 400
                    }}>
                      Người ký
                    </Text>

                    <View style={{
                      flexDirection: 'row',
                      height: dimnensHeight(35),
                      borderWidth: 1,
                      borderRadius: 3,
                      borderColor: '#DDD',
                      alignItems: 'center',
                      padding: dimensWidth(5),
                      marginTop: dimnensHeight(8),
                      paddingHorizontal: dimensWidth(10)
                    }}>
                      <Text style={{ flex: 1 }}>{ItemNguoiKy?.Title}</Text>
                      <View>
                        <ChevronDownIcon />
                      </View>
                    </View>
                  </TouchableOpacity>

                  <View style={{
                    marginTop: dimnensHeight(15),
                  }}>
                    <Text style={{
                      color: '#5E5E5E',
                      fontSize: FontSize.SMALL,
                      fontWeight: 400
                    }}>
                      Loại
                    </Text>

                    <TouchableOpacity
                      onPress={() => { setModalLoaiVB(true) }}
                      style={{
                        flexDirection: 'row',
                        height: dimnensHeight(35),
                        borderWidth: 1,
                        borderRadius: 3,
                        borderColor: '#DDD',
                        alignItems: 'center',
                        padding: dimensWidth(5),
                        marginTop: dimnensHeight(8),
                        paddingHorizontal: dimensWidth(10)
                      }}>
                      <Text style={{ flex: 1, paddingRight: 10 }} numberOfLines={1}>{loaiVBString?.Title}</Text>
                      <View>
                        <ChevronDownIcon />
                      </View>
                    </TouchableOpacity>
                  </View>
                  <Text style={{
                    color: '#5E5E5E',
                    fontSize: FontSize.SMALL,
                    fontWeight: 400,
                    marginTop: 15,
                    marginBottom: 15
                  }}>
                    Ngày trên VB
                  </Text>

                  <View style={styles.filterDateView}>
                    <TouchableOpacity
                      style={[styles.date,]}
                      onPress={() => onPressOpenCalendarPicker("startDate")}
                    >
                      {/* <Text style={styles.textTitleDate}>Từ ngày</Text> */}
                      <Text style={[styles.textDate, , checkIsEmpty(startDate) && styles.emptyText]}>{checkIsEmpty(startDate) ? "Từ ngày" : format_dd_mm_yy(startDate)}</Text>
                      <DateIcon />
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[styles.date, { marginHorizontal: 16, }]}
                      onPress={() => onPressOpenCalendarPicker("endDate")}
                    >
                      {/* <Text style={styles.textTitleDate}>Đến ngày</Text> */}
                      <Text style={[styles.textDate, checkIsEmpty(endDate) && styles.emptyText]}>{checkIsEmpty(endDate) ? "Đến ngày" : format_dd_mm_yy(endDate)}</Text>
                      <DateIcon />
                    </TouchableOpacity>
                  </View>
                </View>
              )
            }
            {/* Apply */}
            <View style={{
              flexDirection: 'row',
              marginTop: dimnensHeight(22),
              justifyContent: 'center',
              alignItems: 'center',
              width: '100%'
            }}>

              <View style={{ flex: 1 }} />
              <TouchableOpacity style={{
                flex: 1
              }} onPress={onReFilterModalPress}
              >
                <Text style={{
                  color: '#005FD4',
                  fontSize: FontSize.TEXT15,
                  fontStyle: 'italic',
                  fontWeight: 400
                }}>Thiết lập lại</Text>
              </TouchableOpacity>

              <TouchableOpacity style={{
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: '#005FD4',
                borderRadius: 4,
              }}
                onPress={onConfirmSearch}
              >
                <Text style={{
                  fontSize: FontSize.MEDIUM,
                  color: 'white',
                  padding: dimensWidth(10),
                }}>Tìm kiếm</Text>

              </TouchableOpacity>
            </View>
          </View>
          {
            !arrayIsEmpty(dataSearch) ?
              <FlatList
                contentContainerStyle={{ paddingBottom: 20 }}
                data={dataSearch}
                extraData={selectedItemIndex || dataSearch}
                refreshControl={
                  <RefreshControl refreshing={isRefreshVBDi} onRefresh={onRefreshVBSearch} tintColor='#0054AE' />
                }
                onEndReachedThreshold={0.5}
                // onEndReached={handleLoadmore}
                showsVerticalScrollIndicator={true}
                keyExtractor={(item, index) => index.toString()}
                renderItem={({ item, index }) => (
                  <ItemLeft
                    item={item}
                    index={index}
                    selectedItemIndex={selectedItemIndex}
                    gotoDetail={gotoDetailPress}
                  />
                )} />
              : <NoDataView />
          }
          <LoadingView isLoading={loadingSearch} />

        </View>
        <View style={{
          width: '65%',
        }}>
          {(!isNullOrEmpty(Item)) && (Item?.ListName == "Văn bản đi" || Item?.ListName == "List Văn bản đi") ? <VBDiDentail route={{
            ItemId: Item.ID
          }} navigation={navigation} selectedItemIndex={selectedItemIndex} /> : (!isNullOrUndefined(Item) && Item?.ListName == "Văn bản đến") ? <VBDenDetail route={{
            ItemId: Item.ID
          }} navigation={navigation} selectedItemIndex={selectedItemIndex} /> :
            (!isNullOrUndefined(Item) && Item?.ListName == "Văn bản ban hành") ? <VBBHDetail route={{
              ItemId: Item.ID
            }} navigation={navigation} selectedItemIndex={selectedItemIndex} /> : (<View style={{ flex: 1 }}>
              <LinearGradient style={{
                paddingLeft: dimensWidth(15),
                height: dimnensHeight(55),
                alignItems: 'center',
                flexDirection: 'row',
                justifyContent: 'flex-end',
                paddingRight: dimensWidth(15)
              }}
                colors={["#0262E9", "#0054AE"]} />
              <NoDataView />
            </View>)}
        </View>
      </View>
      <CalendarPickerModal
        modalCalendarVisible={isOpenCalendarPicker}
        onDateChangeModal={onDateChangeModal}
        onCloseModal={onCloseModal}
        startDate={startDate}
        endDate={endDate}
        typeModal={typeModal}
        removeSelectedDate={removeSelectedDate}
        resetToday={resetToday}
      />
      <NguoiKyModal
        modalVisible={modalNguoiKy}
        onCloseModal={onNguoiKyPress}
        onConfirmModal={(data) => onConfirmNguoiKy(data)}
        defaultitemNguoiKy={ItemNguoiKy}
      />
      <CoQuanGuiModal
        modalVisible={modalCoQuanGui}
        onCloseModal={() => setModalCoQuanGui(false)}
        onConfirmModal={(data) => onConfirmCoQuanGui(data)}
        defaultCoQuanGui={ItemNguoiKy}
      />
      <LoaiVanBanModal
        modalVisible={modalLoaiVanBan}
        onCloseModal={() => setModalLoaiVanBan(false)}
        onConfirmModal={(data) => onConfirmLoaiVanBan(data)}
        defaultItemLoaiVanBan={ItemLoaiVanBan}
      />
      <LoaiVBModal
        modalVisible={modalLoaiVB}
        onCloseModal={() => setModalLoaiVB(false)}
        onConfirmModal={(data, dataParams) => onConfirmLoaiVB(data, dataParams)}
        defaultLoaiVBParams={loaiVBparams}
      />

    </View>
  );
};

export default SearchScreen
