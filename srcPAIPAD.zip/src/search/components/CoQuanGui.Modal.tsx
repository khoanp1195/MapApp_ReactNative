import React, { FC, useState, useCallback, useEffect } from "react";
import {
    Modal,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    KeyboardAvoidingView,
} from "react-native";
import { FlatList } from "react-native-gesture-handler";
import colors from "~/base/Colors";
import { FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";
import { arrayIsEmpty, isNullOrEmpty, isNullOrUndefined } from "~/base/Functions";
import { BackIcon, CloseXIcon, ConfirmIcon, DeleteRedIcon, MemberIcon, MinusIcon, PlusIcon, SellectedBoxIcon, UnSellectedBoxIcon, UserPlusIcon } from "~/base/assets/svg";
import { TextInputCustom } from "~/base/components";
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { fetchCoQuanGui } from "~/base/stories/data/reducer";
import ModalCusTom from "~/base/components/ModalCusTom";

interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    onConfirmModal: (data: any) => void;
    defaultCoQuanGui: any
}

const CoQuanGuiModal: FC<Props> = ({
    modalVisible,
    onCloseModal,
    onConfirmModal,
    defaultCoQuanGui,
    ...props
}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { subSite } = useSelector((state: any) => state.login);
    const { dataCoQuanGui } = useSelector((state: any) => state.data);
    const [dataCoQuanGuiState, setDataCoQuanGuiState] = useState([])
    const [itemCoQuanGuiState, setItemCoQuanGuiState] = useState({})

    const Item = ({ item, index, itemCoQuanGuiState, onItemPress, level = 0 }: any) => {
        const hasChildren = item?.children && item.children.length > 0;
        const {
            Title,
            ID,
            IsRoot,
            isEnded = false,
            isExpanded,
            dummyID
        } = item;
        const onItemPresss = () => {
            onItemPress(item)
        }

        return (
            <View style={[styles.item, level === 0 && {
                marginStart: dimensWidth(20),
                marginEnd: dimensWidth(20)
            }]}>
                <View
                    style={[
                        styles.flexDirectionRowItem,
                        { paddingLeft: 20 + level * 20 },
                    ]}
                >
                    {!isEnded && (
                        <TouchableOpacity onPress={() => handleToggleExpanded(item.dummyID)}>
                            {isExpanded ? <MinusIcon /> : <PlusIcon />}
                        </TouchableOpacity>
                    )}
                    <View style={{ flex: 1 }}>
                        <Text style={{
                            fontSize: FontSize.MEDIUM,
                            lineHeight: dimensWidth(20),
                            color: colors.textBlack19,
                            fontWeight: IsRoot ? "500" : "400",
                            fontFamily: "arial",
                            marginLeft: 10,
                            marginRight: 10,
                        }} numberOfLines={1}>
                            {Title}
                        </Text>
                    </View>
                    <TouchableOpacity
                        style={styles.viewBox1}
                        onPress={onItemPresss}
                    >
                        {itemCoQuanGuiState?.dummyID === dummyID ? <SellectedBoxIcon /> : <UnSellectedBoxIcon />}
                    </TouchableOpacity>
                </View>
                {isExpanded && hasChildren && (
                    <FlatList
                        data={item?.children}
                        renderItem={({ item, index }) => (
                            <Item
                                index={index}
                                item={item}
                                itemCoQuanGuiState={itemCoQuanGuiState}
                                level={level + 1}
                                onItemPress={(index) => onItemPress(index)}
                            />
                        )}
                        keyExtractor={(child, index) => index.toString()}
                    />
                )}
            </View>
        );
    };
    useEffect(() => {
        setDataCoQuanGuiState(defaultCoQuanGui)
    }, [defaultCoQuanGui])

    const handleToggleExpanded = (itemId: any) => {
        setDataCoQuanGuiState((prevData: any) => {
            const newData = [...prevData];

            const findItemAndToggleExpanded = (items: any) => {
                for (let i = 0; i < items.length; i++) {
                    const item = items[i];

                    if (item.dummyID === itemId) {
                        const newValue = !item.isExpanded;
                        item.isExpanded = newValue;
                        return;
                    }

                    if (item?.children && item.children.length > 0) {
                        findItemAndToggleExpanded(item.children);
                    }
                }
            };
            findItemAndToggleExpanded(newData);
            return newData;
        });
    };

    const clone = (data: any, item: any) => {
        const children = data.filter(r => (!isNullOrEmpty(r.Parent_x003a_ID) && r.Parent_x003a_ID.split(';#')[0] == item.ID)).sort((a, b) => a.Title < b.Title ? -1 : 1);
        if (!isNullOrUndefined(children)) {
            item.children = children
            item.children.forEach(element => {
                clone(data, element)
            });
        }
    }

    useEffect(() => {
        if (!arrayIsEmpty(dataCoQuanGui)) {
            const data = dataCoQuanGui.map((record) => ({
                ...record,
                isExpanded: true,
                dummyID: record.ID,
                children: [],
            })).sort((a, b) => a.Title < b.Title ? -1 : 1);

            data.forEach(element => {
                clone(data, element)
            });

            setDataCoQuanGuiState(data)
        }
    }, [dataCoQuanGui])

    useEffect(() => {
        dispatch(fetchCoQuanGui(subSite));
    }, [subSite,dispatch])
    const onItemPress = useCallback((item: any) => {
        setItemCoQuanGuiState(item)
        onConfirmModal(item)
    }, [itemCoQuanGuiState])
    return (
        <ModalCusTom
            transparent={true}
            visible={modalVisible}
            {...props}
            onCloseModalCustom={onCloseModal}
            style={styles.centeredView}
        >
            <KeyboardAvoidingView style={styles.centeredView}>
                <View style={styles.modalView}>
                    <View style={{
                        padding: dimensWidth(20),
                        flexDirection: 'row',
                        alignItems: 'center'
                    }}>
                        <TouchableOpacity style={{
                            flex: 0.08
                        }}
                            onPress={onCloseModal}>
                            <BackIcon />
                        </TouchableOpacity>
                        <Text style={{
                            flex: 1,
                            color: '#005FD4',
                            fontSize: FontSize.LARGE_X,
                            fontWeight: 700,
                        }}>Cơ quan gửi</Text>

                        <TouchableOpacity onPress={onCloseModal}>
                            <CloseXIcon />
                        </TouchableOpacity>
                    </View>

                    <FlatList
                        contentContainerStyle={styles.flatlist}
                        data={dataCoQuanGuiState || itemCoQuanGuiState}
                        extraData={dataCoQuanGuiState}
                        renderItem={({ item, index }) => (
                            <Item
                                index={index}
                                item={item}
                                itemCoQuanGuiState={itemCoQuanGuiState}
                                onItemPress={(item) => onItemPress(item)}
                            />
                        )}
                        keyExtractor={(item, index) => index.toString()}
                    />
                </View>
            </KeyboardAvoidingView>
        </ModalCusTom>
    )
}

const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(0,0,0,0.4)"
    },
    modalView: {
        // height: dimnensHeight(780),
        width: dimensWidth(750),
        backgroundColor: 'white',
        borderRadius: 20,
        overflow: 'hidden',
        height: '75%'
    },
    flatlist: {
        flexGrow: 1,
        backgroundColor: "#FFFFFF",
        paddingBottom: 30,
        overflow: "hidden",
    },
    flatlistChild: {
        marginRight: 15,
    },
    selectedAll: {
        marginRight: dimensWidth(5),
    },
    viewListHeader: {
        flexDirection: 'row',
        alignItems: "center",
        justifyContent: "center",
    },
    item: {
        width: "100%",
        marginTop: 20,
        paddingTop: 20,
        borderTopWidth: 1,
        borderTopColor: "#E5E5E5",

    },
    itemChild: {
        flex: 1,
        width: "100%",
        padding: 20,
        borderTopWidth: 1,
        borderTopColor: "#E5E5E5",
    },
    header: {
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.textBlack19,
        fontWeight: "400",
        fontFamily: "arial",
        marginRight: 10,
    },
    title: {
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.textBlack19,
        fontWeight: "500",
        fontFamily: "arial",
        marginLeft: 10,
        marginRight: 10,
    },
    viewHeader: {
        backgroundColor: colors.primary,
        height: 55,
        justifyContent: "center",
        width: "100%",
        paddingHorizontal: 10,
    },
    titleHeader: {
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.white,
        fontWeight: "400",
        fontFamily: "arial",
        flex: 1,
    },
    flexDirectionRow: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
    },
    flexDirectionRowItem: {
        flex: 1,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        paddingHorizontal: 20,
    },
    flexDirectionRowHeader: {
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: colors.alice_blue,
        height: dimnensHeight(50),
        justifyContent: "flex-end",
    },
    viewBox: {
        width: dimensWidth(80),
    },
    viewBox1: {
        width: dimensWidth(75),
    }
});

export default CoQuanGuiModal