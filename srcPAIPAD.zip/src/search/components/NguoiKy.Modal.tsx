import React, { FC, useState, useCallback, useEffect, useMemo } from "react";
import {
    Modal,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    KeyboardAvoidingView,
    Platform,
} from "react-native";
import colors from "~/base/Colors";
import { FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";
import { BackIcon, CloseXIcon, SellectedBoxIcon, UnSellectedBoxIcon } from "~/base/assets/svg";
import { NoDataView } from "~/base/components";
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { arrayIsEmpty, removeSpecialCharacters } from "base/Functions";
import { FlatList } from "react-native-gesture-handler";
import { fetchNguoiKy } from "~/base/stories/search/reducer";
import ModalCusTom from "~/base/components/ModalCusTom";

interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    onConfirmModal: (data: []) => void;
    defaultitemNguoiKy: any;
}
const Item = ({ item, index, itemNguoiKyState, onItemPress }: any) => {
    const { Title, Position, ID, } = item
    const onItemPresss = () => {
        onItemPress(index)
    }

    return (
        <TouchableOpacity onPress={() => onItemPresss()}>
            <View style={{
                flex: 1,
                flexDirection: 'row',
                height: dimnensHeight(50),
                alignItems: 'center',
                paddingLeft: dimensWidth(20),
                paddingRight: dimensWidth(20)
            }}>
                <View style={styles.viewItemContent}>
                    <Text style={styles.title}>{Title}</Text>
                    <Text style={styles.position}>{removeSpecialCharacters(Position)}</Text>
                </View>
                <View>
                    {itemNguoiKyState?.ID === ID ? <SellectedBoxIcon /> : <UnSellectedBoxIcon />}
                </View>
            </View>
            <View style={{
                flex: 1,
                flexDirection: 'column',
                justifyContent: 'flex-start',
                borderColor: '#B3B3B3',
                borderStyle: 'dotted',
                borderWidth: 1.5,
                borderRadius: 1,
                position: 'relative',
                marginStart: dimensWidth(20),
                marginEnd: dimensWidth(20)
            }}
            />
        </TouchableOpacity>
    )
}

const NguoiKyModal: FC<Props> = ({
    modalVisible,
    onCloseModal,
    onConfirmModal,
    defaultitemNguoiKy,
    ...props
}: Props) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { dataNguoiKy } = useSelector((state: any) => state.search);
    const { subSite, } = useSelector((state: any) => state.login);
    const [itemNguoiKyState, setItemNguoiKyState] = useState({})

    const onItemPress = useCallback((index: number) => {
        const data = dataNguoiKy[index]
        setItemNguoiKyState(data)
        onConfirmModal(data)
    }, [itemNguoiKyState])
    useEffect(() => {
        if (defaultitemNguoiKy) {
            setItemNguoiKyState(defaultitemNguoiKy)
        }
    }, [defaultitemNguoiKy])

    useEffect(() => {
        dispatch(fetchNguoiKy(subSite));
    }, [dispatch, subSite])

    return (
        <ModalCusTom
            transparent={true}
            visible={modalVisible}
            {...props}
            onCloseModalCustom={onCloseModal}
            style={styles.centeredView}
        >
            <KeyboardAvoidingView style={styles.centeredView}>
                <View style={styles.modalView}>
                    <View style={{
                        padding: dimensWidth(20),
                        flexDirection: 'row',
                        alignItems: 'center',
                    }}>
                        <TouchableOpacity style={{
                            flex: 0.08
                        }}
                            onPress={onCloseModal}>
                            <BackIcon />
                        </TouchableOpacity>
                        <Text style={{
                            flex: 1,
                            color: '#005FD4',
                            fontSize: FontSize.LARGE_X,
                            fontWeight: 700,
                        }}>Người ký</Text>
                        <TouchableOpacity onPress={onCloseModal}>
                            <CloseXIcon />
                        </TouchableOpacity>
                    </View>
                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        backgroundColor: '#F6F8FA'
                    }} />

                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        backgroundColor: '#F6F8FA'
                    }} />
                    {
                        !arrayIsEmpty(dataNguoiKy) ?
                            <FlatList
                                data={dataNguoiKy}
                                extraData={itemNguoiKyState}
                                renderItem={({ item, index }) => (
                                    <Item
                                        index={index}
                                        item={item}
                                        itemNguoiKyState={itemNguoiKyState}
                                        onItemPress={(index: number) => onItemPress(index)}
                                    />
                                )}
                                keyExtractor={(item: any) => item?.ID}
                            /> : <NoDataView />
                    }
                </View>
            </KeyboardAvoidingView>
        </ModalCusTom>
    )
}

const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(0,0,0,0.4)"
    },
    modalView: {
        // height: dimnensHeight(640),
        width: dimensWidth(750),
        backgroundColor: 'white',
        borderRadius: 20,
        overflow: 'hidden',
        height: '65%'
    },
    flatlist: {
        backgroundColor: "#FFFFFF",
        margin: 16,
        borderRadius: 8,
    },
    viewItemContent: { alignItems: 'flex-start', flex: 1 },
    item: {
        height: 60,
        alignItems: "center",
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: 15,
        borderStyle: "dashed",
        borderTopWidth: 1,
        borderTopColor: "#E5E5E5",
    },
    title: {
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.black,
        fontWeight: "400",
        fontFamily: "arial",
    },
    position: {
        fontSize: dimensWidth(13),
        lineHeight: dimensWidth(20),
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 15,
    },
    viewHeader: {
        backgroundColor: colors.primary,
        height: Platform.OS === "ios" ? 130 : 90,
        justifyContent: "center",
        width: "100%",
        padding: 10,
    },
    titleHeader: {
        flex: 1,
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.white,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 15,
    },
    flexDirectionRow: {
        flexDirection: "row",
        alignItems: "center",
    },
    backPress: {
        padding: 8,
    },
    iconDone: {
        marginEnd: 15,
    }
});

export default NguoiKyModal