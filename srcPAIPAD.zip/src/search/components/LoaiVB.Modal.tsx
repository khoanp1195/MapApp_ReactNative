import React, { FC, useState, useCallback, useEffect, useMemo } from "react";
import {
    Modal,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    KeyboardAvoidingView,
    Platform,
    Alert,
} from "react-native";
import colors from "~/base/Colors";
import { FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";
import { BackIcon, CloseXIcon, ConfirmIcon, SellectedBoxIcon, UnSellectedBoxIcon } from "~/base/assets/svg";
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { FlatList } from "react-native-gesture-handler";
import ModalCusTom from "~/base/components/ModalCusTom";
import { sortedStringByID } from "~/base/Functions";
interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    onConfirmModal: (data: any, data2: any) => void;
    defaultLoaiVBParams: any;
}
enum TabNameType {
    VB_Den = "Văn bản đến",
    VB_DU_THAO = "VB dự thảo",
    VB_DA_BAN_HANH = "VB đã ban hành",
}
export const LoaiVBData = [
    { ID: 3, Title: TabNameType.VB_Den, isSellected: true },
    { ID: 1, Title: TabNameType.VB_DU_THAO, isSellected: true },
    { ID: 2, Title: TabNameType.VB_DA_BAN_HANH, isSellected: true },
];
const Item = ({ item, index, onItemPress }: any) => {
    const { Title, isSellected, ID } = item
    const onItemPresss = () => {
        onItemPress(item)
    }

    return (
        <TouchableOpacity onPress={onItemPresss}>
            <View style={{
                flex: 1,
                flexDirection: 'row',
                height: dimnensHeight(50),
                alignItems: 'center',
                marginLeft: dimensWidth(20),
                marginEnd: dimensWidth(20)
            }}>
                <View style={styles.viewItemContent}>
                    <Text style={styles.title}>{Title}</Text>
                </View>
                <View>
                    {isSellected ? <SellectedBoxIcon /> : <UnSellectedBoxIcon />}
                </View>
            </View>
            <View style={{
                flex: 1,
                flexDirection: 'column',
                justifyContent: 'flex-start',
                borderColor: '#B3B3B3',
                borderStyle: 'dotted',
                borderWidth: 1.5,
                borderRadius: 1,
                position: 'relative',
                marginLeft: dimensWidth(20),
                marginEnd: dimensWidth(20)
            }}
            />
        </TouchableOpacity>
    )
}

const LoaiVBModal: FC<Props> = ({
    modalVisible,
    onCloseModal,
    onConfirmModal,
    defaultLoaiVBParams,
    ...props
}: Props) => {
    const [dataLoaiVBState, setdataLoaiVBState] = useState(LoaiVBData)

    const onConfirmOwnModal = useCallback(async () => {
        let data = { ID: "", Title: "" }
        for (let index = 0; index < dataLoaiVBState.length; index++) {
            const element = dataLoaiVBState[index];
            if (element.isSellected) {
                data = {
                    ID: data.ID + element.ID + ",",
                    Title: data.Title + element.Title + ';'
                }
            }
        }

        if (data.ID.length === 0) {
            Alert.alert("Thông báo", "Vui lòng chọn ít nhất 1 điều kiện", [
                { text: "OK", onPress: () => { } },
            ]);
        } else {
            if (data.ID.replaceAll(',', '').length === 3) {
                data = { ID: '', Title: "Văn bản đến; Văn bản dự thảo; Văn bản ban hành" }
            } else {
                data = { ID: sortedStringByID(data.ID.substring(0, data.ID.length - 1)), Title: data.Title.substring(0, data.Title.length - 1) }
            }
            onConfirmModal(data, dataLoaiVBState)
        }
    }, [dataLoaiVBState]);

    const onItemPress = useCallback((itemSellected: any) => {
        let tmp = []
        tmp = dataLoaiVBState.map(it => {
            return it = it.ID === itemSellected.ID ? { ...it, isSellected: !it.isSellected } : it
        })
        setdataLoaiVBState(tmp)
    }, [dataLoaiVBState])

    useEffect(() => {
        if (defaultLoaiVBParams) {
            setdataLoaiVBState(defaultLoaiVBParams)
        }
    }, [defaultLoaiVBParams])
    const onClose = useCallback(
        () => {
            setdataLoaiVBState(defaultLoaiVBParams)
            onCloseModal()
        },
        [defaultLoaiVBParams],
    )
    return (
        <ModalCusTom
            transparent={true}
            visible={modalVisible}
            {...props}
            onCloseModalCustom={onClose}
            style={styles.centeredView}
        >
            <KeyboardAvoidingView style={styles.centeredView}>
                <View style={styles.modalView}>
                    <View style={{
                        padding: dimensWidth(20),
                        flexDirection: 'row',
                        alignItems: 'center',
                    }}>
                        <TouchableOpacity style={{
                            flex: 0.08
                        }}
                            onPress={onClose}>
                            <BackIcon />
                        </TouchableOpacity>
                        <Text style={{
                            flex: 1,
                            color: '#005FD4',
                            fontSize: FontSize.LARGE_X,
                            fontWeight: 700,
                        }}>Loại</Text>
                        <TouchableOpacity style={{
                            marginRight: dimensWidth(40)
                        }}
                            onPress={onConfirmOwnModal}>
                            <ConfirmIcon />
                        </TouchableOpacity>
                        <TouchableOpacity onPress={onClose}>
                            <CloseXIcon />
                        </TouchableOpacity>
                    </View>
                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        backgroundColor: '#F6F8FA'
                    }} />

                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        backgroundColor: '#F6F8FA'
                    }} />

                    <FlatList
                        data={dataLoaiVBState}
                        extraData={dataLoaiVBState}
                        renderItem={({ item, index }) => (
                            <Item
                                index={index}
                                item={item}
                                onItemPress={(itemSellected: any) => onItemPress(itemSellected)}
                            />
                        )}
                        keyExtractor={(item: any) => item?.ID}
                    />
                </View>
            </KeyboardAvoidingView>
        </ModalCusTom>
    )
}

const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(0,0,0,0.4)"
    },
    modalView: {
        // height: dimnensHeight(640),
        width: dimensWidth(750),
        backgroundColor: 'white',
        borderRadius: 20,
        overflow: 'hidden',
        height: '65%'
    },
    flatlist: {
        backgroundColor: "#FFFFFF",
        margin: 16,
        borderRadius: 8,
    },
    viewItemContent: { alignItems: 'flex-start', flex: 1 },
    item: {
        height: 60,
        alignItems: "center",
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: 15,
        borderStyle: "dashed",
        borderTopWidth: 1,
        borderTopColor: "#E5E5E5",
    },
    title: {
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.black,
        fontWeight: "400",
        fontFamily: "arial",
    },
    position: {
        fontSize: dimensWidth(13),
        lineHeight: dimensWidth(20),
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 15,
    },
    viewHeader: {
        backgroundColor: colors.primary,
        height: Platform.OS === "ios" ? 130 : 90,
        justifyContent: "center",
        width: "100%",
        padding: 10,
    },
    titleHeader: {
        flex: 1,
        fontSize: FontSize.MEDIUM,
        lineHeight: dimensWidth(20),
        color: colors.white,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 15,
    },
    flexDirectionRow: {
        flexDirection: "row",
        alignItems: "center",
    },
    backPress: {
        padding: 8,
    },
    iconDone: {
        marginEnd: 15,
    }
});

export default LoaiVBModal