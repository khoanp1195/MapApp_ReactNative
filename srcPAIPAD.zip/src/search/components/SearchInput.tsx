import { StyleSheet } from "react-native";
import React from "react";
import TextInputCustom from "../../base/components/TextInputCustom";
import colors from "../../base/Colors";
import { FontSize, dimnensHeight } from "~/base/Constants";
interface Props {
  filterText: string;
  onChangeFilterText: (text: string) => void;
}
const SearchInput = ({ filterText, onChangeFilterText }: Props) => {
  return (
    <TextInputCustom
      placeholder="Tìm kiếm …"
      placeholderTextColor={colors.grey999}
      numberOfLines={1}
      onChangeText={(text) => onChangeFilterText(text)}
      value={filterText}
      style={styles.userNameInput}
    />
  );
};
const styles = StyleSheet.create({
  userNameInput: {
    flex: 1,
    paddingHorizontal: 10,
    backgroundColor: colors.white,
    borderRadius: 17,
    color: colors.black,
    fontSize: FontSize.MEDIUM,
    height: dimnensHeight(32),
    margin: 1
  },
});
export default SearchInput;
