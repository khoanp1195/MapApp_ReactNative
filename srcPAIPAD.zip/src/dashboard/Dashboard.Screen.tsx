import React, { useState, useCallback, useEffect, useMemo } from "react";
import { useDispatch, useSelector } from 'react-redux';
import {
    Text,
    View,
    processColor,
    ImageBackground,
    TouchableOpacity,
    ActivityIndicator,
    Alert,
    RefreshControl
} from "react-native";
import Colors from "../base/Colors"
import styles from "./Dashboard.Style";
import { dimensWidth, dimnensHeight, FontSize, funtionVBDenData, funtionVBDiData, windowHeight, windowWidth } from '../base/Constants';
import LinearGradient from "react-native-linear-gradient";
import { PieChart } from "react-native-charts-wrapper";
import FastImage from 'react-native-fast-image';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { BASE_URL } from "../base/Constants"
import { fetchDataProcessed, fetchDataProccessing, fetchDataNewRelease, fetchCountDashboard, deleteNotifyProcessing } from '../base/stories/dashboard/reducer';
import { formatCreatedDate, arrayIsEmpty, isNullOrUndefined, format_dd_mm_yy } from '../base/Functions'
import { FlatList, ScrollView } from "react-native-gesture-handler";
import { NoDataView } from "~/base/components";
import colors from "../base/Colors";
import { DeleteRedIcon, MenuIcon } from "~/base/assets/svg";
import { menuAction } from "~/base/stories/menu/reducer";
import { RootState } from "stores";
import { fetchCurrentUser, setSubSite } from "~/base/stories/login/reducer";
import AsyncStorage from "@react-native-async-storage/async-storage";
import DeviceInfo from 'react-native-device-info';
// import * as RootContainer from "../base/navigation/RootContainer.Screen"

import { setIsCloseModalApp, setRemoteMessage } from "~/base/stories/data/reducer";
import { setSubSiteOwn } from "~/base/service/PushNotification";
import {  setDataProcessingStatus, setSellectedProcessingIndex } from "~/base/stories/home/reducer";
import { onResetVbDenDetailAction, resetVBDenScreen } from "~/base/stories/vbden/reducer";
import { resetVBDiScreen } from "~/base/stories/vbdi/reducer";
import { useIsFocused } from "@react-navigation/native";

const ItemProcessing = ({ item, index, gotoDetail, deleteNotify }: any) => {
    const {
        ID,
        SendUnit,
        ListName,
        ImagePath,
        Title,
        SiteName,
        Created,
        DueDate,
        Action,
        DocumentID,
    } = item;
    const gotoDetailPress = () => {
        const tabStatus = 0
        gotoDetail(DocumentID, tabStatus, index);
    };
    return (
        <TouchableOpacity style={{
            backgroundColor: index % 2 == 0 ? '#FFFFFF' : '#EFF7FF',
            paddingLeft: 15,
            paddingRight: 15,
            paddingTop: 20,
            paddingBottom: 20,
            flex: 1,
            flexDirection: 'row',
            alignItems: 'center'
        }} onPress={gotoDetailPress}>
            <Text style={{
                flex: 3,
            }}
                numberOfLines={1}>{Title}</Text>
            <Text style={{
                flex: 1
            }}>
                {ListName}
            </Text>
            <Text style={{
                flex: 1
            }}>
                {format_dd_mm_yy(DueDate)}
            </Text>
            <Text style={{
                flex: 1
            }}
                numberOfLines={1}>
                {SendUnit}
            </Text>
            <View style={{
                flex: 0.2
            }}>
                <TouchableOpacity onPress={() => deleteNotify(ID)}>
                    <DeleteRedIcon />
                </TouchableOpacity>
            </View>
        </TouchableOpacity>
    );
};

const ItemNewRelease = ({ item, index, subSite, token, gotoDetail }: any) => {
    const {
        ID,
        Title,
        TrichYeu,
        Created,
        TrangThai,
        ImagePath,
        FullName,
        ListName
    } = item;
    const formatCreated = formatCreatedDate(Created);
    const gotoDetailPress = () => {
        gotoDetail(index);
    };
    return (
        <TouchableOpacity onPress={gotoDetailPress} style={{
            flexDirection: 'row',
            backgroundColor: colors.white,
            padding: dimensWidth(15),
            marginBottom: dimensWidth(10),
            borderRadius: 8,
            justifyContent: 'center',
        }}>
            <FastImage
                style={{
                    height: dimensWidth(40),
                    width: dimensWidth(40),
                    marginRight: dimensWidth(10),
                    borderRadius: dimensWidth(20)
                }}
                source={{
                    uri: `${BASE_URL}/${subSite}/${ImagePath}`,
                    headers: { Authorization: `${token}` },
                    priority: FastImage.priority.normal,
                }}
                resizeMode={FastImage.resizeMode.contain}
                defaultSource={require("base/assets/images/avatar80.png")}
            />
            <View style={{ flex: 1 }}>
                <View style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>
                    <Text style={{
                        fontSize: FontSize.MEDIUM,
                        color: colors.textBlack19,
                        fontWeight: '400',
                        fontFamily: 'arial',
                        marginBottom: 6,
                        marginRight: dimensWidth(5),
                        flex: 1
                    }}>{FullName}</Text>
                    <Text style={{
                        fontSize: FontSize.MEDIUM,
                        color: colors.textBlack19,
                        fontWeight: '400',
                        fontFamily: 'arial',
                        marginBottom: 6,
                        marginRight: dimensWidth(5),
                    }}>{formatCreated}</Text>
                </View>
                <View style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>
                    <Text style={{
                        fontSize: FontSize.SMALL,
                        color: colors.textBlack19,
                        fontWeight: '400',
                        fontFamily: 'arial',
                        marginBottom: 6,
                        marginRight: dimensWidth(5),
                        flex: 1
                    }}>Văn bản ban hành</Text>
                    <Text style={{
                        fontSize: FontSize.SMALL,
                        color: colors.textBlack19,
                        fontWeight: '400',
                        fontFamily: 'arial',
                        marginBottom: 6,
                        marginRight: dimensWidth(5),
                    }}>{Title}</Text>
                </View>

                <Text style={{
                    fontSize: FontSize.MEDIUM,
                    color: colors.textBlack19,
                    fontWeight: '400',
                    fontFamily: 'arial',
                    marginBottom: 6,
                    marginRight: dimensWidth(5),
                    flex: 1
                }}
                    numberOfLines={1}>{TrichYeu}</Text>
                <View style={{
                    backgroundColor: colors.lightBlue,
                    paddingHorizontal: 6,
                    paddingVertical: 3,
                    borderRadius: 3,
                    alignSelf: 'baseline'
                }}>
                    <Text style={{
                        fontSize: dimensWidth(12),
                        color: colors.primary,
                        fontWeight: '400',
                        fontFamily: 'arial'
                    }}>
                        Đã phát hành
                    </Text>
                </View>

            </View>
        </TouchableOpacity>
    )
}

const ItemProcessed = ({ item, index, subSite, token, gotoDetail }: any) => {
    const {
        ImagePath,
        DocumentID,
        SendUnit,
        Content,
        Created,
        ListName,
        Action,
        TaskCategory,
        Title
    } = item;
    const formatCreated = formatCreatedDate(Created);
    const gotoDetailPress = () => {
        const tabStatus = 1;
        gotoDetail(DocumentID, tabStatus, index);
    }
    return (
        <TouchableOpacity onPress={gotoDetailPress} style={{
            flexDirection: 'row',
            backgroundColor: colors.white,
            padding: dimensWidth(15),
            marginBottom: dimensWidth(10),
            borderRadius: 8,
            justifyContent: 'center',
        }}>
            <FastImage
                style={{
                    height: dimensWidth(40),
                    width: dimensWidth(40),
                    marginRight: dimensWidth(10),
                    borderRadius: dimensWidth(20)
                }}
                source={{
                    uri: `${BASE_URL}/${subSite}/${ImagePath}`,
                    headers: { Authorization: `${token}` },
                    priority: FastImage.priority.normal,
                }}
                resizeMode={FastImage.resizeMode.contain}
                defaultSource={require("base/assets/images/avatar80.png")}
            />
            <View style={{ flex: 1 }}>
                <View style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>
                    <Text style={{
                        fontSize: FontSize.MEDIUM,
                        color: colors.textBlack19,
                        fontWeight: '400',
                        fontFamily: 'arial',
                        marginBottom: 6,
                        marginRight: dimensWidth(5),
                        flex: 1
                    }}
                        numberOfLines={1}>{SendUnit}</Text>
                    <Text style={{
                        fontSize: FontSize.MEDIUM,
                        color: colors.textBlack19,
                        fontWeight: '400',
                        fontFamily: 'arial',
                        marginBottom: 6,
                    }}>{formatCreated}</Text>
                </View>
                <View style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>
                    <Text style={{
                        flex: 1,
                        fontSize: FontSize.SMALL,
                        color: colors.textBlack19,
                        fontWeight: '400',
                        fontFamily: 'arial',
                        marginBottom: 6,
                    }}>{ListName}</Text>
                    <Text style={{
                        fontSize: FontSize.SMALL,
                        color: colors.textBlack19,
                        fontWeight: '400',
                        fontFamily: 'arial',
                        marginBottom: 6,
                        marginLeft: dimensWidth(15),
                    }} numberOfLines={1}>{TaskCategory}</Text>
                </View>

                <Text style={{
                    fontSize: FontSize.MEDIUM,
                    color: colors.textBlack19,
                    fontWeight: '400',
                    fontFamily: 'arial',
                    marginBottom: 6,
                    flex: 1
                }}
                    numberOfLines={1}>{Title}</Text>
                <View style={{
                    backgroundColor: colors.lightBlue,
                    paddingHorizontal: 6,
                    paddingVertical: 3,
                    borderRadius: 3,
                    alignSelf: 'baseline'
                }}>
                    <Text style={{
                        fontSize: dimensWidth(12),
                        color: colors.primary,
                        fontWeight: '400',
                        fontFamily: 'arial'
                    }}>
                        {Action}
                    </Text>
                </View>

            </View>
        </TouchableOpacity>
    )
}

const DashboardScreen = ({ navigation }: any) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { token, subSite } = useSelector((state: RootState) => state.login);
    const { remoteMessage } = useSelector((state: RootState) => state.data);
    const { isProcessVbdenSuccess } = useSelector(
        (state: RootState) => state.vbden);

    const { isRefreshVBDiScreen, } = useSelector(
        (state: RootState) => state.vbdi);
    const { dataDocProcessed, isLoading, totalRecord, dataDocProcessing, dataDocNewRelease, dashboardCountData } = useSelector((state: RootState) => state.dashboard);
    const [dataChart, setDataChart] = useState({});
    const [dataNewRelease, setDataNewRelease] = useState([])
    const [dataProcessed, setDataProcessed] = useState([])
    const [offset, setOffset] = useState(0)
    const [isRefreshDashboard, setIsRefreshDashboard] = useState(false)
    const [isHasableScreen, SetIsHasableScreen] = useState(false)
    const isFocused = useIsFocused();

    const fetchData = useCallback(async (body: any) => {
        const deviceToken = await AsyncStorage.getItem('deviceToken')
        const deviceId = await AsyncStorage.getItem('deviceId')

        const deviceInfo = {
            DeviceInfo: {
                DeviceId: deviceId,
                DevicePushToken: deviceToken,
                DeviceOS: 3,
                DeviceName: await DeviceInfo.getDeviceName(),
                DeviceModel: DeviceInfo.getModel()
            }
        }

        dispatch(fetchCurrentUser({ subSite: body, deviceInfo }));
        dispatch(fetchCountDashboard(body));
        dispatch(fetchDataNewRelease(body));
        dispatch(fetchDataProcessed(body));
    }, [dispatch, subSite])
    const fetchDataProcessing = useCallback(async () => {
        dispatch(fetchDataProccessing({
            subSite,
            offset
        }));
    }, [dispatch, subSite, offset])

    useEffect(() => {
        if (isProcessVbdenSuccess) {
            setOffset(0)
            fetchData(subSite);
            fetchDataProcessing();
            dispatch(resetVBDenScreen(null))
        }
        if (isRefreshVBDiScreen) {
            setOffset(0)
            fetchData(subSite);
            fetchDataProcessing();
            dispatch(resetVBDiScreen(null))
        }
    }, [isProcessVbdenSuccess, subSite, isRefreshVBDiScreen])

    const onRefreshDashboard = useCallback(async () => {
        setOffset(0)
        setIsRefreshDashboard(true)
        fetchData(subSite);
        fetchDataProcessing();
        setIsRefreshDashboard(false)
    }, [dispatch, subSite])
    useEffect(() => {
        if (isFocused) {
            onRefreshDashboard();
        }
    }, [isFocused])

    useEffect(() => {
        fetchData(subSite);
    }, [fetchData, subSite]);

    useEffect(() => {
        fetchDataProcessing();
    }, [subSite, offset]);

    useEffect(() => {
        if (isHasableScreen && Object.keys(remoteMessage).length > 0) {
            const data = remoteMessage.data
            if (subSite !== data.SiteName) {
                Alert.alert('Thông báo', 'Bạn đang xem Văn bản ở site khác. Bạn có muốn chuyển site không ?', [
                    {
                        text: "Hủy",
                        style: "cancel"
                    },
                    {
                        text: "Đồng ý",
                        onPress: () => onChange(remoteMessage)
                    }
                ])
            } else {
                RootContainer.navigate('HomeProcessingScreen', {
                    DocumentID: data.ResourceId,
                    tabStatus: 0
                });

                //dispatch(setRemoteMessage({}))
            }
        }
    }, [dispatch, subSite, isHasableScreen, remoteMessage])

    const onChange = useCallback((remoteMessage: any) => {
        const data = remoteMessage.data
        dispatch(setSubSite(data.SiteName))
        setSubSiteOwn(data.SiteName)
        RootContainer.navigate('HomeProcessingScreen', {
            DocumentID: data.ResourceId,
            tabStatus: 0
        });
        // dispatch(setRemoteMessage({}))
        dispatch(setIsCloseModalApp(true));
    }, [dispatch])

    const openDrawer = useCallback(() => {
        navigation.openDrawer();
    }, [navigation]);

    const ViecCanXuLy = useMemo(() => {
        if (isNullOrUndefined(dashboardCountData?.ViecCanXuLy)) return 0
        return dashboardCountData?.ViecCanXuLy;
    }, [dashboardCountData]);
    const ThongBao = useMemo(() => {
        if (isNullOrUndefined(dashboardCountData?.ThongBao)) return 0
        return dashboardCountData?.ThongBao;
    }, [dashboardCountData]);
    const VanBanPhoiHop = useMemo(() => {
        if (isNullOrUndefined(dashboardCountData?.VanBanPhoiHop)) return 0
        return dashboardCountData?.VanBanPhoiHop;
    }, [dashboardCountData]);

    const gotoDetailPress = useCallback((selectedItemIndex: any) => {
        navigation.navigate({
            name: "VBDaBanHanhScreen",
            params: { selectedItemIndex }
        });
    }, []);

    const gotoProcessingScreenPress = useCallback((DocumentID: Number, tabStatus: number, index: number) => {
        dispatch(onResetVbDenDetailAction(null));
        dispatch(setDataProcessingStatus(tabStatus));
        if (index < 20) {
            dispatch(setSellectedProcessingIndex(index))
        } else {
            dispatch(setSellectedProcessingIndex(0))
        }
        navigation.navigate({
            name: "HomeProcessingScreen",
        });
    }, []);

    const deleteNotify = useCallback((id: any) => {

        Alert.alert('', 'Bạn có chắc chắn muốn Loại bỏ Văn bản/Công việc chờ xử lý của cá nhân ra khỏi danh sách công việc?', [
            {
                text: 'Cancel',
                style: 'cancel',
            },
            {
                text: 'OK',
                onPress: () =>  dispatch(deleteNotifyProcessing({ subSite, ItemId: id })) ,
            },
        ]);
    }, [subSite])

    const loadMore = useCallback(() => {
        if (!arrayIsEmpty(dataDocProcessing) && dataDocProcessing.legend < totalRecord) {
            setOffset(dataDocProcessing.length);
        }
    }, [totalRecord, dataDocProcessing])

    const renderFooter = (loading: boolean) => {
        return (
            <View style={{
                padding: 10,
                justifyContent: 'center',
                alignItems: 'center',
                flexDirection: 'row'
            }}>
                {loading ? (
                    <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
                ) : null}
            </View>
        );
    };

    const gotoProcessing = useCallback(() => {
        dispatch(menuAction("VB chờ xử lý"))
        navigation.navigate({ name: "HomeProcessingScreen", params: { tabStatus: 0 } })
    }, [dispatch, navigation])

    useEffect(() => {
        const data = {
            dataSets: [
                {
                    values: [
                        {
                            value: ViecCanXuLy,
                            label: "VB cần xử lý",
                        },
                        {
                            value: VanBanPhoiHop,
                            label: "VB phối hợp",
                        },
                        {
                            value: ThongBao,
                            label: "Thông báo",
                        },
                    ],
                    label: "",
                    config: {
                        colors: [
                            processColor("#006BCF"),
                            processColor("#00C94C"),
                            processColor("#FF4040"),
                        ],
                        drawValues: true,
                        valueTextSize: 15,
                        valueTextColor: processColor("#5E5E5E"),
                        valueFormatter: "#.#'%'",
                        sliceSpace: 5,
                        selectionShift: 100,
                        yValuePosition: "OUTSIDE_SLICE"

                    },
                },
            ],
        };
        setDataNewRelease(dataDocNewRelease)
        setDataProcessed(dataDocProcessed)
        setDataChart(data);
        SetIsHasableScreen(true)
        //alert('dataDocProcessing', dataDocProcessing.length)
    }, [ViecCanXuLy, VanBanPhoiHop, ThongBao, dataDocProcessing, dataDocNewRelease, dataDocProcessed]);

    return (
        <View style={styles.container}>
            <LinearGradient style={styles.viewAvatar}
                colors={["#0262E9", "#0054AE"]}
            >
                <TouchableOpacity onPress={openDrawer} style={{
                    marginRight: dimensWidth(12),
                    marginLeft: dimensWidth(15),
                }}>
                    <MenuIcon color={'#fff'} />
                </TouchableOpacity>
                <View style={{ flexDirection: 'column', alignItems: 'flex-start', justifyContent: 'flex-start' }}>
                    <Text style={styles.titleAvatar}>{subSite.toUpperCase()}</Text>
                    <Text style={{
                        fontSize: FontSize.MEDIUM,
                        lineHeight: dimensWidth(20),
                        color: Colors.white,
                        fontWeight: '400',
                        fontFamily: 'arial',
                    }}>Trang chủ</Text>
                </View>
            </LinearGradient>
            <ScrollView contentContainerStyle={{ flex: 1, flexDirection: 'row' }} refreshControl={
                <RefreshControl refreshing={isRefreshDashboard} onRefresh={onRefreshDashboard} tintColor='#0054AE' />
            } >
                <View style={{ flex: 0.25 }}>
                    <Text style={{
                        fontSize: FontSize.LARGE_X,
                        lineHeight: dimensWidth(26),
                        color: '#00408F',
                        fontWeight: '700',
                        fontFamily: 'arial',
                        marginLeft: dimensWidth(15),
                        marginBottom: 8,
                        marginTop: dimensWidth(15)
                    }}>Dashboard</Text>

                    <View style={{
                        flex: 1,
                    }}>
                        <View style={{
                            flex: 1,
                            paddingLeft: dimensWidth(10),
                            marginBottom: dimnensHeight(10),
                        }}>
                            <TouchableOpacity onPress={gotoProcessing}>
                                <ImageBackground
                                    style={{
                                        height: dimnensHeight(145),
                                        alignItems: 'flex-start',
                                        justifyContent: 'center',
                                        borderRadius: dimensWidth(10),
                                        marginBottom: dimnensHeight(10),
                                        overflow: 'hidden'
                                    }}
                                    source={require("../base/assets/images/bg_dashboard_processing.png")}
                                >
                                    <Text style={[{ marginLeft: dimensWidth(30) }, styles.titleDashboard]}>{ViecCanXuLy}</Text>
                                    <Text style={[{ marginLeft: dimensWidth(35) }, styles.contentDashboard]}>Văn bản chờ xử lý</Text>
                                </ImageBackground>
                            </TouchableOpacity>

                            <View style={{
                                // flex: 1,
                                flexDirection: 'row',
                                justifyContent: 'space-between',
                                alignContent: 'space-between',
                            }}>
                                <TouchableOpacity
                                    onPress={() => {
                                        dispatch(menuAction("VB phối hợp"))
                                        navigation.navigate("HomeCombinationScreen")
                                    }}
                                    style={{ flex: 1, }}>
                                    <ImageBackground
                                        style={{
                                            height: dimnensHeight(145 * 300 / 302),
                                            // width: dimensWidth(133),
                                            marginRight: dimnensHeight(5),
                                            paddingTop: dimnensHeight(15),
                                            alignItems: 'center',
                                            borderRadius: dimensWidth(10),
                                            overflow: 'hidden'
                                        }}
                                        source={require("../base/assets/images/bg_dashboard_combine.png")}
                                    >
                                        <Text style={styles.titleDashboard}>{VanBanPhoiHop}</Text>
                                        <Text style={styles.contentVanban}>{`Văn bản\nphối hợp`}</Text>
                                    </ImageBackground>
                                </TouchableOpacity>

                                <TouchableOpacity
                                    onPress={() => {
                                        dispatch(menuAction("Thông báo"))
                                        navigation.navigate("HomeNotificationScreen")
                                    }}
                                    style={{ flex: 1 }}>
                                    <ImageBackground
                                        style={{
                                            height: dimnensHeight(145),
                                            // width: dimensWidth(133),
                                            marginLeft: dimnensHeight(5),
                                            paddingTop: dimnensHeight(15),
                                            alignItems: 'center',
                                            borderRadius: dimensWidth(10),
                                            overflow: 'hidden'
                                        }}
                                        source={require("../base/assets/images/bg_dashboard_notify.png")}
                                    >
                                        <Text style={styles.titleDashboard}>{ThongBao}</Text>
                                        <Text style={styles.contentVanban}>Thông báo</Text>
                                    </ImageBackground>
                                </TouchableOpacity>

                            </View>
                        </View>

                        <View style={styles.viewContainerChart}>
                            <View style={styles.viewTitleChart}>
                                <Text style={styles.titleChart}>Tình hình xử lý văn bản</Text>
                            </View>
                            {ViecCanXuLy + ThongBao + VanBanPhoiHop > 0 && (
                                <PieChart
                                    style={[
                                        styles.viewChartIos,
                                    ]}
                                    logEnabled={true}
                                    chartBackgroundColor={processColor("white")}
                                    chartDescription={{ text: "" }}
                                    data={dataChart}
                                    legend={{ enabled: true }}
                                    noDataText={"No data chart !"}
                                    entryLabelColor={processColor("#10a8b2")}
                                    entryLabelTextSize={12}
                                    touchEnabled={false}
                                    drawEntryLabels={false}
                                    usePercentValues={true}
                                    centerText={""}
                                    onSelect={() => { }}
                                    centerTextRadiusPercent={0}
                                    holeRadius={40}
                                    transparentCircleRadius={45}
                                    holeColor={processColor('#FFFFFF')}
                                    transparentCircleColor={processColor('#f0f0f088')}
                                    rotationEnabled={true}
                                    maxAngle={360}
                                    rotationAngle={45}
                                />
                            )}

                            <View style={styles.viewDescription}>
                                <View style={styles.flexOne}>
                                    <View style={{ flex: 1, flexDirection: 'row' }}>
                                        <LinearGradient
                                            style={styles.squareDescription}
                                            colors={["#4CD9ED", "#006BCF"]}
                                        />
                                        <Text style={styles.contentDescription}>VB cần xử lý</Text>

                                        <View style={{
                                            width: '100%',
                                            flexDirection: 'row',
                                            marginLeft: dimensWidth(15)
                                        }}>
                                            <LinearGradient
                                                style={styles.squareDescription}
                                                colors={["#00C94C", "#5AFFF8"]}
                                            />
                                            <Text style={styles.contentDescription}>VB phối hợp</Text>
                                        </View>
                                    </View>

                                </View>

                                <View style={{
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    marginTop: dimnensHeight(10)
                                }}>
                                    <LinearGradient
                                        style={styles.squareDescription}
                                        colors={["#FFC386", "#FF4040"]}
                                    />
                                    <Text style={styles.contentDescription}>Thông báo</Text>
                                </View>
                            </View>
                        </View>
                    </View>

                </View>

                <View style={{
                    flex: 0.75,
                    marginLeft: dimensWidth(15),
                    marginRight: dimensWidth(15)
                }}>
                    <View style={{ flex: 1, flexDirection: 'row' }}>
                        <View style={{ flex: 1 }}>
                            <Text style={{
                                fontSize: FontSize.LARGE_X,
                                lineHeight: dimensWidth(26),
                                color: '#00408F',
                                fontWeight: '700',
                                fontFamily: 'arial',
                                marginBottom: dimnensHeight(8),
                                marginTop: dimensWidth(15)
                            }}>Văn bản đã ban hành</Text>
                            {!isNullOrUndefined(dataNewRelease) ?
                                <FlatList
                                    style={{
                                        // marginBottom: dimnensHeight(10),
                                        marginRight: dimensWidth(15),
                                    }}
                                    extraData={dataNewRelease}
                                    data={dataNewRelease?.slice(0, 3)}
                                    renderItem={({ item, index }) => (
                                        <ItemNewRelease item={item} index={index} subSite={subSite} token={token} gotoDetail={gotoDetailPress} />
                                    )}
                                    keyExtractor={(item, index) => String(index)}
                                    showsVerticalScrollIndicator={false} />
                                : <NoDataView />
                            }
                        </View>
                        <View style={{ flex: 1 }}>
                            <Text style={{
                                fontSize: FontSize.LARGE_X,
                                lineHeight: dimensWidth(26),
                                color: '#00408F',
                                fontWeight: '700',
                                fontFamily: 'arial',
                                marginBottom: dimnensHeight(8),
                                marginTop: dimensWidth(15)
                            }}>Văn bản đã xử lý</Text>
                            {!isNullOrUndefined(dataProcessed) ?
                                <FlatList
                                    style={{
                                        // marginBottom: dimnensHeight(10),
                                    }}
                                    extraData={dataProcessed}
                                    data={dataProcessed}
                                    renderItem={({ item, index }) => (
                                        <ItemProcessed item={item} index={index} subSite={subSite} token={token} gotoDetail={gotoProcessingScreenPress} />
                                    )}
                                    keyExtractor={(item, index) => String(index)}
                                    showsVerticalScrollIndicator={false} />
                                : <NoDataView />
                            }
                        </View>
                    </View>
                    <View style={{
                        flex: 1,
                        height: '50%',
                        width: '100%'
                    }}>
                        <Text style={{
                            fontSize: FontSize.LARGE_X,
                            lineHeight: dimensWidth(26),
                            color: '#00408F',
                            fontWeight: '700',
                            fontFamily: 'arial',
                            marginBottom: dimnensHeight(8),
                            marginTop: dimensWidth(15)
                        }}>Văn bản / Công việc chờ xử lý</Text>
                        <View style={{
                            backgroundColor: '#E6E6E6',
                            width: '100%',
                            paddingTop: dimnensHeight(15),
                            paddingBottom: dimnensHeight(15),
                            paddingLeft: dimensWidth(15),
                            paddingRight: dimensWidth(15),
                            borderTopLeftRadius: 8,
                            borderTopRightRadius: 8,
                            flexDirection: 'row',
                            shadowColor: '#000000',
                            shadowOpacity: 0.2,
                        }}>
                            <Text style={{
                                flex: 3,
                                fontSize: 14,
                                fontWeight: 'bold'
                            }}>Tiêu đề</Text>
                            <Text style={{
                                flex: 1,
                                fontSize: 14,
                                fontWeight: 'bold'
                            }}>Nhóm</Text>
                            <Text style={{
                                flex: 1,
                                fontSize: 14,
                                fontWeight: 'bold'
                            }}>Hạn hoàn tất</Text>
                            <Text style={{
                                flex: 1,
                                fontSize: 14,
                                fontWeight: 'bold'
                            }}>Từ</Text>
                            <Text style={{ flex: 0.2 }} />
                        </View>
                        {!arrayIsEmpty(dataDocProcessing) ?
                            <FlatList
                                style={{
                                    marginBottom: dimnensHeight(8),
                                    shadowColor: '#000000',
                                    shadowOpacity: 0.2
                                }}
                                extraData={dataDocProcessing}
                                data={dataDocProcessing}
                                renderItem={({ item, index }) => (
                                    <ItemProcessing
                                        item={item}
                                        index={index}
                                        gotoDetail={gotoProcessingScreenPress}
                                        deleteNotify={() => deleteNotify(item.ID)}
                                    />
                                )}
                                initialNumToRender={20}
                                keyExtractor={(item, index) => String(index)}
                                showsVerticalScrollIndicator={false}
                                onEndReached={loadMore}
                                ListFooterComponent={renderFooter(isLoading)}
                                onEndReachedThreshold={0.5} />
                            : <NoDataView />
                        }
                    </View>
                </View>
            </ScrollView>
        </View>
    )
}

export default DashboardScreen