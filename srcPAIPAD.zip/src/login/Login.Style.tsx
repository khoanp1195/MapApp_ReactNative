import {StyleSheet} from 'react-native';
import { FontSize, dimnensHeight, windowHeight, windowWidth } from '~/base/Constants';

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  text: {
    fontSize: FontSize.MEDIUM,
  },
  bg_login: {
    alignItems: 'center',
    width: windowWidth,
    height: windowHeight,
  },
  logoPetrolimex: {
    marginBottom: 80,
    marginTop: 80,
    resizeMode: 'cover',
  },
  containerTextInput: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 50,
    width: 350,
    backgroundColor: '#fff',
    paddingLeft: 18,
    borderRadius: 8,
    marginBottom: 20,
  },
  userNameInput: {
    paddingHorizontal: 10,
    flex: 1,
  },
});
export default styles;
