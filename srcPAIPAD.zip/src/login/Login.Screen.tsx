import React, { useState, useCallback, useEffect } from 'react';
import { ImageBackground, Image, SafeAreaView, View, Alert, KeyboardAvoidingView } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import styles from './Login.Style';
import TextInputCustom from '../base/components/TextInputCustom';
import { UserIcon, PasswordIcon } from '../base/assets/svg/index';
import LinearGradientButton from '../base/components/LinearGradientButton';
import Colors from '../base/Colors';
import { loginRequestApi, fetchCurrentUser, logoutAction, setIsLogging, fetchRealSite } from '../base/stories/login/reducer';
import { RootState } from 'stores';
import { checkIsEmpty, isNullOrUndefined } from '~/base/Functions';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

const LoginScreen = () => {
  const dispatch: any = useDispatch();
  const { isAuth, isLogging } = useSelector((state: RootState) => state.login);
  const [userName, onChangeUserName] = useState(''); //eoff.pa.ct
  const [password, onChangePassword] = useState(''); //VTlamson123!@#

  const loginRequest = useCallback(async (userName: any, password: any) => {
    dispatch(setIsLogging(true))
    dispatch(
      loginRequestApi({
        userName,
        password,
      }),
    );
  }, [dispatch]);

  const onLoginPress = useCallback(() => {
    if (checkIsEmpty(userName) || checkIsEmpty(password)) {
      Alert.alert("Thông báo", 'Vui lòng nhập tài khoản/mật khẩu', [
      ]);
    } else {
      loginRequest(userName, password)
    }
  }, [dispatch, userName, password])

  useEffect(() => {
    const retriveUserInfo = async () => {
      dispatch(setIsLogging(true))
      let username = await AsyncStorage.getItem('username')
      let password = await AsyncStorage.getItem('password')
      if (!isNullOrUndefined(username) && !isNullOrUndefined(password)) {
        onChangeUserName(username)
        onChangePassword(password)
        loginRequest(username, password)
      }
    }
    retriveUserInfo()
  }, []);

  useEffect(() => {
    if (isAuth) {
      const saveUserInfo = async () => {
        await AsyncStorage.setItem('username', userName)
        await AsyncStorage.setItem('password', password)
      };

      saveUserInfo()
      dispatch(fetchRealSite(userName))
    }
  }, [userName, isAuth]);
  return (
    <KeyboardAwareScrollView>
      <ImageBackground
        source={require('../base/assets/images/background.png')}
        style={styles.bg_login}>
          <Image
            style={styles.logoPetrolimex}
            source={require('../base/assets/images/logo_login.png')}
          />
          {isLogging ? <View /> : <View>
            <View style={styles.containerTextInput}>
              <UserIcon />
              <TextInputCustom
                placeholder="Tên đăng nhập"
                placeholderTextColor={Colors.grey999}
                numberOfLines={1}
                onChangeText={text => onChangeUserName(text)}
                value={userName}
                style={styles.userNameInput}
              />
            </View>
            <View style={styles.containerTextInput}>
              <PasswordIcon />
              <TextInputCustom
                placeholder="Mật khẩu"
                placeholderTextColor={'#999999'}
                numberOfLines={1}
                onChangeText={text => onChangePassword(text)}
                value={password}
                style={styles.userNameInput}
                secureTextEntry
              />
            </View>
            <LinearGradientButton
              onPress={onLoginPress}
              title={'Đăng nhập'.toUpperCase()}
              colorList={['#0054AE', '#0262E9']}
            /></View>}
      </ImageBackground>
    </KeyboardAwareScrollView>
  );
};

export default LoginScreen
