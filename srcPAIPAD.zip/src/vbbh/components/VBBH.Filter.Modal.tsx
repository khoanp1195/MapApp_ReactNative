import React, { FC, useState, useCallback, useMemo, useEffect } from "react";
import {
    Modal,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    KeyboardAvoidingView,
    ScrollView,
    Animated,
    Alert
} from "react-native";
import colors from "~/base/Colors";
import { FontSize, dimensWidth, dimnensHeight } from "~/base/Constants";
import { arrayIsEmpty, checkIsAfter, checkIsBefore, checkIsEmpty, format_dd_mm_yy, isNullOrUndefined, randomIdFunc, removeSpecialCharacters } from "~/base/Functions";
import { CalendarFilterIcon, CalendarIcon, CalendarLeftIcon, CalendarRightIcon, CloseXIcon, ConfirmIcon, DeleteIcon, DeleteRedIcon, DueDateBlueIcon, MemberIcon, RemoveIcon, ResetFilterIcon, RightBlueIcon, TypeIcon, UserPlusIcon } from "~/base/assets/svg";
import { Calendar, CalendarList, LocaleConfig } from "react-native-calendars";
import moment from "moment";
import DashedLine from 'react-native-dashed-line';
import ModalCusTom from "~/base/components/ModalCusTom";

const dayNamesShort = ["CN", "T2", "T3", "T4", "T5", "T6", "T7"];
LocaleConfig.locales["fr"] = {
    monthNames: [
        "Tháng 01",
        "Tháng 02",
        "Tháng 03",
        "Tháng 04",
        "Tháng 05",
        "Tháng 06",
        "Tháng 7",
        "Tháng 08",
        "Tháng 09",
        "Tháng 10",
        "Tháng 11",
        "Tháng 12",
    ],
    monthNamesShort: [
        "Tháng 01",
        "Tháng 02",
        "Tháng 03",
        "Tháng 04",
        "Tháng 05",
        "Tháng 06",
        "Tháng 7",
        "Tháng 08",
        "Tháng 09",
        "Tháng 10",
        "Tháng 11",
        "Tháng 12",
    ],
    dayNames: ["Chủ Nhật", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"],
    dayNamesShort,
    today: "Ngày hôm nay",
};

LocaleConfig.defaultLocale = "fr";
const theme = {
    textDayFontFamily: "arial",
    textDayFontSize: 15,
    dayTextColor: "#1A1919",
};

interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    onConfirmModal: (data: any) => void;
}

const VBBHFilterModal: FC<Props> = ({
    modalVisible,
    onCloseModal,
    onConfirmModal,
    ...props
}: Props) => {
    const toDateFormatted = moment().format("YYYY-MM-DD")
    const fromDateFromatted = moment().add(-30, 'days').format("YYYY-MM-DD");
    const [selectedFromDate, setSelectedFromDate] = useState(fromDateFromatted);
    const [selectedToDate, setSelectedToDate] = useState(toDateFormatted);
    const [isSelectedFromDate, setIsSelectedFromDate] = useState(false)
    const [isSelectedToDate, setIsSelectedToDate] = useState(false)
    const [modalDocumentType, setModalDocumentType] = useState(false)
    const [documentType, setDocumentType] = useState("Tất cả")

    const _onPressFromDateArrowLeft = useCallback(() => {
        let prevousMonth = "";
        if (selectedFromDate) {
            prevousMonth = moment(selectedFromDate).add(-1, "M").format("YYYY-MM-DD");
        } else {
            prevousMonth = moment(selectedFromDate).add(-1, "M").format("YYYY-MM-DD");
        }
        setSelectedFromDate(prevousMonth);
    }, [selectedFromDate]);

    const _onPressFromDateArrowRight = useCallback(() => {
        let futureMonth = "";
        if (selectedFromDate) {
            futureMonth = moment(selectedFromDate).add(1, "M").format("YYYY-MM-DD");
        } else {
            futureMonth = moment(selectedFromDate).add(1, "M").format("YYYY-MM-DD");
        }
        setSelectedFromDate(futureMonth);
    }, [selectedFromDate]);

    const _onPressToDateArrowLeft = useCallback(() => {
        let prevousMonth = "";
        if (selectedToDate) {
            prevousMonth = moment(selectedToDate).add(-1, "M").format("YYYY-MM-DD");
        } else {
            prevousMonth = moment(selectedToDate).add(-1, "M").format("YYYY-MM-DD");
        }
        setSelectedToDate(prevousMonth);
    }, [selectedToDate]);

    const _onPressToDateArrowRight = useCallback(() => {
        let futureMonth = "";
        if (selectedToDate) {
            futureMonth = moment(selectedToDate).add(1, "M").format("YYYY-MM-DD");
        } else {
            futureMonth = moment(selectedToDate).add(1, "M").format("YYYY-MM-DD");
        }
        setSelectedToDate(futureMonth);
    }, [selectedToDate]);

    const fromDateFormat = useMemo(() => {
        if (!selectedToDate) return ""
        return format_dd_mm_yy(selectedFromDate)
    }, [selectedFromDate])

    const toDateFormat = useMemo(() => {
        if (!selectedToDate) return ""
        return format_dd_mm_yy(selectedToDate)
    }, [selectedToDate])

    const onFromDatePress = useCallback(() => {
        setIsSelectedFromDate(!isSelectedFromDate)
    }, [isSelectedFromDate])

    const onToDatePress = useCallback(() => {
        setIsSelectedToDate(!isSelectedToDate)
    }, [isSelectedToDate])

    const onCloseDocumentTypeModal = useCallback(() => {
        setModalDocumentType(false)
    }, [modalDocumentType])

    const onConfirmDocumentTypeModal = useCallback((data) => {
        if (!isNullOrUndefined(data)) {
            setDocumentType(data.Title)
        }
        setModalDocumentType(false)
    }, [modalDocumentType, documentType])

    const onResetFilter = useCallback(() => {
        setDocumentType("Tất cả")
        setSelectedFromDate(fromDateFromatted)
        setSelectedToDate(toDateFormatted)
    }, [])

    const onConfirmOwnModal = useCallback(() => {
        const data = {
            DocumentType: documentType,
            FromDate: selectedFromDate,
            ToDate: selectedToDate
        }

        onConfirmModal(data)
    }, [selectedFromDate, selectedToDate, documentType])

    return (
        <ModalCusTom transparent={true}
            visible={modalVisible}
            {...props}
            onCloseModalCustom={onCloseModal}
            style={styles.centeredView}>

            <KeyboardAvoidingView style={styles.centeredView}>
                <View style={styles.modalView}>
                    <View style={{
                        padding: dimensWidth(20),
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'center',
                        backgroundColor: 'white'
                    }}>
                        <Text style={{
                            flex: 1,
                            color: '#005FD4',
                            fontSize: FontSize.LARGE_X,
                            fontWeight: 700,
                        }}>Bộ lọc</Text>
                        <TouchableOpacity style={{
                            marginRight: dimensWidth(40)
                        }}
                            onPress={onResetFilter}
                        >
                            <ResetFilterIcon />
                        </TouchableOpacity>
                        <TouchableOpacity style={{
                            marginRight: dimensWidth(40)
                        }}
                            onPress={onConfirmOwnModal}
                        >
                            <ConfirmIcon />
                        </TouchableOpacity>
                        <TouchableOpacity onPress={onCloseModal}>
                            <CloseXIcon />
                        </TouchableOpacity>
                    </View>
                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        backgroundColor: '#F6F8FA'
                    }} />

                    <View style={{
                        flexDirection: 'row',
                        padding: dimensWidth(20),
                        alignItems: 'center',
                        backgroundColor: 'white',
                        opacity: 0.5
                    }}>
                        <TypeIcon />
                        <Text style={{
                            color: '#5E5E5E',
                            fontWeight: 400,
                            fontSize: FontSize.MEDIUM,
                            marginLeft: dimensWidth(15),
                            flex: 1
                        }}>Tình trạng</Text>
                        <TouchableOpacity disabled={true} onPress={() => setModalDocumentType(true)}>
                            <Text style={{
                                color: '#000000',
                                fontWeight: 400,
                                fontSize: FontSize.MEDIUM,
                                marginRight: dimensWidth(20)
                            }}>{"Đã phát hành"}</Text>
                        </TouchableOpacity>
                        <RightBlueIcon />
                    </View>

                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        backgroundColor: '#F6F8FA'
                    }} />
                    <View style={{
                        flexDirection: 'row',
                        padding: dimensWidth(20),
                        alignItems: 'center',
                        backgroundColor: 'white'
                    }}>
                        <CalendarFilterIcon />
                        <Text style={{
                            color: '#5E5E5E',
                            fontWeight: 400,
                            fontSize: FontSize.MEDIUM,
                            marginLeft: dimensWidth(15),
                            flex: 1
                        }}>Ngày đến</Text>
                    </View>

                    <View style={{
                        marginHorizontal: dimensWidth(20)
                    }}>
                        <DashedLine dashLength={2} dashColor="#B3B3B3" />
                    </View>

                    <View style={{
                        flexDirection: 'row',
                        padding: dimensWidth(20),
                        backgroundColor: 'white'
                    }}>
                        <View
                            style={{
                                flex: 1
                            }}>

                            <Text style={{
                                color: '#5E5E5E',
                                fontWeight: 400,
                                fontSize: FontSize.MEDIUM,
                                marginLeft: dimensWidth(15),
                            }}>Từ ngày</Text>
                            <TouchableOpacity onPress={onFromDatePress}>
                                <Text style={{
                                    color: '#000000',
                                    fontWeight: 400,
                                    fontSize: FontSize.MEDIUM,
                                    marginLeft: dimensWidth(15),
                                    marginRight: dimensWidth(20),
                                    marginTop: dimnensHeight(10)
                                }}>{fromDateFormat}</Text>
                            </TouchableOpacity>
                        </View>

                        <DashedLine axis='vertical' dashLength={2} dashColor="#B3B3B3" />

                        <View style={{
                            flex: 1
                        }}>
                            <Text style={{
                                color: '#5E5E5E',
                                fontWeight: 400,
                                fontSize: FontSize.MEDIUM,
                                marginLeft: dimensWidth(15),
                            }}>Đến ngày</Text>
                            <TouchableOpacity onPress={onToDatePress}>
                                <Text style={{
                                    color: '#000000',
                                    fontWeight: 400,
                                    fontSize: FontSize.MEDIUM,
                                    marginRight: dimensWidth(20),
                                    marginLeft: dimensWidth(15),
                                    marginTop: dimnensHeight(10)
                                }}>{toDateFormat}</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                    <View style={{
                        flex: 1,
                        flexDirection: 'row'
                    }}>
                        <ScrollView style={{
                            flex: 1
                        }}>
                            {isSelectedFromDate ? (<Calendar
                                // Initially visible month. Default = Date()
                                style={styles.calendarContainer}
                                initialDate={selectedFromDate}
                                current={selectedFromDate}
                                headerStyle={{ justifyContent: "center", alignItems: "center" }}
                                theme={theme}
                                selected={selectedFromDate}
                                onMonthChange={(month) => { }}
                                renderHeader={(date) => {
                                    const header = date.toString("MMMM/yyyy");
                                    const [month, year] = header.split(" ");
                                    return (
                                        <View style={styles.headerContainer} key={randomIdFunc()}>
                                            <View style={styles.header}>
                                                <TouchableOpacity
                                                    style={styles.calendarIconView}
                                                    activeOpacity={0.7}
                                                    onPress={_onPressFromDateArrowLeft}
                                                >
                                                    <CalendarLeftIcon />
                                                </TouchableOpacity>
                                                <Text style={[styles.month]}>{`Tháng ${year}`}</Text>
                                                <TouchableOpacity
                                                    style={styles.calendarIconView}
                                                    activeOpacity={0.7}
                                                    onPress={_onPressFromDateArrowRight}
                                                >
                                                    <CalendarRightIcon />
                                                </TouchableOpacity>
                                            </View>
                                            <View style={styles.dayNamesView}>
                                                {dayNamesShort.map((day) => {
                                                    return (
                                                        <Text key={randomIdFunc()} style={styles.dayNamesText}>
                                                            {day}
                                                        </Text>
                                                    );
                                                })}
                                            </View>

                                            <View style={styles.bottomDashed} >
                                                <DashedLine dashLength={2} dashColor="#B3B3B3" />
                                            </View>
                                        </View>
                                    );
                                }}
                                // Handler which gets executed when visible month changes in calendar. Default = undefined
                                // If firstDay=1 week starts from Monday. Note that dayNames and dayNamesShort should still start from Sunday.
                                //firstDay={1}
                                hideDayNames
                                hideArrows
                                dayComponent={({ date, state, marking, theme }: any) => {
                                    const isSelectedDay = date.dateString === selectedFromDate;
                                    const isDisable = checkIsAfter(date.dateString, selectedToDate);
                                    const isDisableDay = state === "disabled";
                                    const isToday = state === "today";
                                    return (
                                        <TouchableOpacity
                                            key={date.dateString}
                                            style={[
                                                styles.dateView,
                                                isDisable && styles.disableView,
                                                isDisableDay && styles.disableDate,
                                                isSelectedDay && styles.selectedDate,
                                            ]}
                                            disabled={isDisable}
                                            onPress={() => {
                                                setSelectedFromDate(date.dateString);
                                                setIsSelectedFromDate(false)
                                            }}
                                        >
                                            <Text
                                                style={[
                                                    styles.dayText,
                                                    isSelectedDay && styles.selectedDateColor,
                                                    isToday && styles.today,
                                                ]}
                                            >
                                                {date.day}
                                            </Text>
                                        </TouchableOpacity>
                                    );
                                }}
                            />) : <View />}

                        </ScrollView>
                        <ScrollView style={{
                            flex: 1,
                        }}>
                            {isSelectedToDate ? (<Calendar
                                // Initially visible month. Default = Date()
                                style={styles.calendarContainer}
                                initialDate={selectedToDate}
                                current={selectedToDate}
                                headerStyle={{ justifyContent: "center", alignItems: "center" }}
                                theme={theme}
                                selected={selectedToDate}
                                onMonthChange={(month) => { }}
                                renderHeader={(date) => {
                                    const header = date.toString("MMMM/yyyy");
                                    const [month, year] = header.split(" ");
                                    return (
                                        <View style={styles.headerContainer} key={randomIdFunc()}>
                                            <View style={styles.header}>
                                                <TouchableOpacity
                                                    style={styles.calendarIconView}
                                                    activeOpacity={0.7}
                                                    onPress={_onPressToDateArrowLeft}
                                                >
                                                    <CalendarLeftIcon />
                                                </TouchableOpacity>
                                                <Text style={[styles.month]}>{`Tháng ${year}`}</Text>
                                                <TouchableOpacity
                                                    style={styles.calendarIconView}
                                                    activeOpacity={0.7}
                                                    onPress={_onPressToDateArrowRight}
                                                >
                                                    <CalendarRightIcon />
                                                </TouchableOpacity>
                                            </View>
                                            <View style={styles.dayNamesView}>
                                                {dayNamesShort.map((day) => {
                                                    return (
                                                        <Text key={randomIdFunc()} style={styles.dayNamesText}>
                                                            {day}
                                                        </Text>
                                                    );
                                                })}
                                            </View>
                                            <View style={styles.bottomDashed} >
                                                <DashedLine dashLength={2} dashColor="#B3B3B3" />
                                            </View>
                                        </View>
                                    );
                                }}
                                // Handler which gets executed when visible month changes in calendar. Default = undefined
                                // If firstDay=1 week starts from Monday. Note that dayNames and dayNamesShort should still start from Sunday.
                                //firstDay={1}
                                hideDayNames
                                hideArrows
                                dayComponent={({ date, state, marking, theme }: any) => {
                                    const isSelectedDay = date.dateString === selectedToDate;
                                    const isDisable = checkIsBefore(date.dateString, selectedFromDate);
                                    const isDisableDay = state === "disabled";
                                    const isToday = state === "today";
                                    return (
                                        <TouchableOpacity
                                            key={date.dateString}
                                            style={[
                                                styles.dateView,
                                                isDisable && styles.disableView,
                                                isDisableDay && styles.disableDate,
                                                isSelectedDay && styles.selectedDate,
                                            ]}
                                            disabled={isDisable}
                                            onPress={() => {
                                                setSelectedToDate(date.dateString);
                                                setIsSelectedToDate(false)
                                            }}
                                        >
                                            <Text
                                                style={[
                                                    styles.dayText,
                                                    isSelectedDay && styles.selectedDateColor,
                                                    isToday && styles.today,
                                                ]}
                                            >
                                                {date.day}
                                            </Text>
                                        </TouchableOpacity>
                                    );
                                }}
                            />) : <View />}
                        </ScrollView>
                    </View>
                </View>
            </KeyboardAvoidingView>
        </ModalCusTom>
    )
}

const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(0,0,0,0.4)"
    },
    modalView: {
        height: dimnensHeight(650),
        width: dimensWidth(700),
        backgroundColor: '#F6F8FA',
        borderRadius: 20,
        overflow: 'hidden'
    },
    calendarContainer: {
    },
    header: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        padding: 10,
        marginTop: 3,
        marginLeft: dimensWidth(10)
    },
    month: {
        fontSize: 18,
        fontWeight: "700",
        color: "#000000",
        fontFamily: "arial",
    },
    year: {
        marginRight: 5,
    },
    calendarIconView: {
        width: dimensWidth(34),
        height: dimensWidth(34),
        backgroundColor: colors.white,
        borderRadius: dimensWidth(17),
        justifyContent: "center",
        alignItems: "center",
    },
    viewTopBarCalendar: {
        flexDirection: "row",
        width: "100%",
        justifyContent: "flex-end",
        marginVertical: 15,
    },
    iconTopBar: {
        marginRight: 25,
    },
    headerContainer: {
        flex: 1,
        marginHorizontal: -dimensWidth(15),
    },
    dayNamesView: {
        flexDirection: "row",
        justifyContent: "space-between",
        paddingVertical: 15,
        marginHorizontal: dimensWidth(15),
    },
    dayNamesText: {
        height: dimensWidth(34),
        width: dimensWidth(34),
        borderRadius: dimensWidth(17),
        fontSize: 16,
        color: "#1A1919",
        fontWeight: "400",
        fontFamily: "arial",
        textAlign: "center",
    },
    dayText: {
        fontSize: 15,
        color: "#1A1919",
        fontWeight: "400",
        fontFamily: "arial",
        textAlign: "center",
    },
    dateView: {
        justifyContent: "center",
        alignItems: "center",
        height: dimensWidth(34),
        width: dimensWidth(34),
        borderRadius: dimensWidth(17),
    },
    disableView: {
        opacity: 0.1,
    },
    selectedDate: {
        backgroundColor: "#C3DDFF",
    },
    today: {
        color: "#025FDA",
    },
    selectedDateColor: {
        color: "#025FDA",
    },
    disableDate: {
        opacity: 0.1,
    },
    bottomDashed: {
        marginHorizontal: dimensWidth(15),
        overflow: "hidden",
    },
});

export default VBBHFilterModal