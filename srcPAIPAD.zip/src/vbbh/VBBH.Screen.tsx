import React, { useState, useCallback, useEffect, } from 'react';
import { View, Text, ActivityIndicator } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { dimnensHeight, dimensWidth } from '~/base/Constants';
import Colors from "../base/Colors"
import { BASE_URL, FontSize } from '../base/Constants'
import {
    isNullOrUndefined, calculateBetweenTwoDate,
    formatCreatedDate,
    arrayIsEmpty,
    checkIsEmpty,
    format_dd_mm_yy,
    isNullOrEmpty,
} from '../base/Functions'
import { FlatList, RefreshControl, TouchableOpacity } from 'react-native-gesture-handler';
import styles from '../home/Home.Procesing.Style';
import { LoadingView, NoDataView, TopBarTab, } from '~/base/components';
import VBBHDetail from '~/detail/vbbh/VBBH.Detail.Screen';
import LinearGradient from 'react-native-linear-gradient';
import colors from '../base/Colors';
import { FilterIcon, LaCoIcon, MenuIcon, } from '~/base/assets/svg';
import SearchInput from '~/search/components/SearchInput';
import { fetchVBDaBanHanhApi } from '~/base/stories/vbbh/reducer';
import { RootState } from '~/base/stories';
import VBBHFilterModal from './components/VBBH.Filter.Modal';
import { useIsFocused } from '@react-navigation/native';
import FastImageCustom from '~/base/components/FastImageCustom';

const ItemLeft = ({ item, index, subSite, token, gotoDetail, selectedItemIndex }: any) => {
    const {
        FullName,
        TrichYeu,
        ImagePath,
        TrangThai,
        Created,
        DueDate,
        Action,
        ID,
        TaskCategory
    } = item;
    const gotoDetailPress = () => {
        gotoDetail(item, index);
    };

    const formatCreated = formatCreatedDate(Created);
    let dueDateFormat = ""
    let isExpired = false
    let isExpiredToday = false
    const distanceDate = calculateBetweenTwoDate(DueDate);
    if (!checkIsEmpty(distanceDate)) {
        if (parseInt(distanceDate) < 0) {
            dueDateFormat = format_dd_mm_yy(DueDate);
        } else if (parseInt(distanceDate) >= 0 && parseInt(distanceDate) < 1) {
            dueDateFormat = "Hạn hôm nay";
            isExpiredToday = true
        }
        else {
            isExpired = true
            dueDateFormat = "Quá hạn " + distanceDate + " ngày";
        }
    }

    return (
        <TouchableOpacity onPress={gotoDetailPress}>
            <View style={{
                flex: 1,
                flexDirection: 'row',
                marginHorizontal: dimensWidth(15),
                shadowColor: '#000000',
                shadowOffset: {
                    width: 0,
                    height: 0
                },
                shadowRadius: 8,
                shadowOpacity: 0.1,
                elevation: 1
            }}>
                <View style={styles.item}>
                    <View style={{
                        width: dimensWidth(5),
                        backgroundColor: selectedItemIndex == index ? '#015DD1' : null,
                    }} />

                    <View style={{
                        flex: 1,
                        flexDirection: 'row',
                        padding: dimensWidth(15),
                        borderRadius: 8,
                        justifyContent: 'center',
                    }}>
                        <FastImageCustom
                            styleImg={styles.itemAvatar}
                            urlOnline={`${BASE_URL}/${subSite}/${ImagePath}`}
                        />
                        <View style={{ flex: 1 }}>
                            <View style={styles.flexDirectionBetween}>
                                <Text style={styles.title} numberOfLines={1}>
                                    {FullName}
                                </Text>
                                <Text style={styles.date}>{formatCreated}</Text>
                            </View>

                            <View style={{
                                flex: 1,
                                flexDirection: 'row',
                                justifyContent: 'space-between',
                            }}>
                                <Text style={styles.category}>{'Văn bản ban hành'}</Text>
                                <Text style={styles.category} numberOfLines={1}>{TaskCategory}</Text>
                            </View>
                            <Text style={styles.title} numberOfLines={2}>{TrichYeu}</Text>
                            <View style={styles.flexDirectionBetween}>
                                <View style={styles.touchSendUnit}>
                                    <Text style={styles.textSendUnit}>{TrangThai}</Text>
                                </View>
                                <View style={{ flex: 1, marginLeft: 10 }}>
                                    {(item?.Priority ==
                                        1) && <LaCoIcon />}
                                </View>
                                <Text
                                    style={[
                                        styles.date,
                                        isExpiredToday && styles.todayDeadlife,
                                        isExpired && styles.distanceDate,
                                    ]}
                                >
                                    {dueDateFormat}
                                </Text>
                            </View>
                        </View>
                    </View>
                </View>
            </View>
        </TouchableOpacity>
    )
}

const VBDiScreen = ({ route, navigation }: any) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { subSite, token } = useSelector(
        (state: RootState) => state.login);

    const { dataVBDaBanHanh, isLoadingVBBH, totalRecordVbbh } = useSelector(
        (state: RootState) => state.vbbh);
    const [offset, setOffset] = useState(0)
    const [Item, setItem] = useState<any>({})
    const [selectedItemIndex, setSelectedItemIndex] = useState(null)
    const [textSearch, setTextSearch] = useState("")
    const [modalFilter, setModalFilter] = useState(false)
    const [fromDate, setFromDate] = useState("")
    const [toDate, setToDate] = useState("")
    const [isRefreshVBBH, setisRefreshVBBH] = useState(false)
    const flatListRef = React.useRef()
    const isFocused = useIsFocused();
    const [isDefaultFilter, setIsDefaultFilter] = useState(true)
    useEffect(() => {
        if (isNullOrUndefined(fromDate) && isNullOrUndefined(toDate)) {
            setIsDefaultFilter(true)
        } else {
            setIsDefaultFilter(false)
        }
    }, [fromDate, toDate,])

    const fetchDataLeftList = useCallback(async (
        offset: number,
        _subSite: string,
        FilterText: string,
        fromDate: string,
        toDate: string
    ) => {
        dispatch(fetchVBDaBanHanhApi({
            offset: offset,
            subSite: _subSite,
            FilterText: FilterText,
            fromDate,
            toDate
        }));
    }, [dispatch, offset, textSearch]);

    useEffect(() => {
        if (isFocused) {
            fetchDataLeftList(offset, subSite, textSearch, fromDate, toDate)
        }
    }, [dispatch, isFocused, subSite, textSearch, fromDate, toDate]);
    const onRefreshVBBH = useCallback(() => {
        setisRefreshVBBH(true)
        setTextSearch("")
        setFromDate("")
        setToDate("")
        dispatch(fetchVBDaBanHanhApi({
            offset: offset,
            subSite: subSite,
            FilterText: "",
            fromDate: "",
            toDate: ""
        }));
        setisRefreshVBBH(false)
    }, [subSite, offset]);

    useEffect(() => {
        if (!arrayIsEmpty(dataVBDaBanHanh)) {
            setSelectedItemIndex(0)
            setItem(dataVBDaBanHanh[0])
        }else{
            setItem({})
        }
    }, [dataVBDaBanHanh]);

    useEffect(() => {
        if (offset === 0 && route.params?.selectedItemIndex >= 0 && !arrayIsEmpty(dataVBDaBanHanh)) {
            if (dataVBDaBanHanh.length >= route.params?.selectedItemIndex) {
                flatListRef?.current?.scrollToIndex({ animated: true, index: 0 })
                setItem(dataVBDaBanHanh[route.params?.selectedItemIndex])
                setSelectedItemIndex(route.params?.selectedItemIndex)
            } else {
                setItem({})
            }
        }
    }, [dataVBDaBanHanh, route.params, offset])
    const gotoDetailPress = useCallback((item, index) => {
        setSelectedItemIndex(index)
        setItem(item)
    }, [Item]);

    const handleLoadmore = async () => {
        if (totalRecordVbbh > dataVBDaBanHanh.length) {
            setOffset(dataVBDaBanHanh.length);
        }
    };

    const openDrawer = useCallback(() => {
        navigation.openDrawer();
    }, [navigation]);

    const onChangeFilterText = useCallback(
        (text: string) => {
            setTextSearch(text);
            setOffset(0)
        },
        [textSearch, offset]
    );

    const renderFooter = (loading: boolean) => {
        if (arrayIsEmpty(dataVBDaBanHanh)) return <View />
        return (
            <View style={{
                padding: 10,
                justifyContent: 'center',
                alignItems: 'center',
                flexDirection: 'row'
            }}>
                {loading ? (
                    <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
                ) : null}
            </View>
        );
    };

    const onCloseFilterModal = useCallback(() => {
        setModalFilter(false)
    }, [modalFilter])

    const onConfirmFilterModal = useCallback((data) => {
        if (!isNullOrUndefined(data)) {
            setToDate(data.ToDate)
            setFromDate(data.FromDate)
            setOffset(0)
        }

        setModalFilter(false)
    }, [])
    const renderEmpty = () => {
        if (isLoadingVBBH) return <LoadingView isLoading={isLoadingVBBH} bgColor={colors.white} viewLoadingStyle={{ top: dimnensHeight(100) }} />
        return (
            <NoDataView />
        )
    }
    return (
        <View style={{
            flex: 1,
            backgroundColor: Colors.gray
        }}>
            <View style={{
                flex: 1,
                flexDirection: 'row',
            }}>
                <View style={{
                    width: '35%'
                }}>
                    <LinearGradient style={{
                        paddingLeft: dimensWidth(15),
                        height: dimnensHeight(55),
                    }}
                        colors={["#0262E9", "#0054AE"]}>
                        <View style={{
                            flex: 1,
                            flexDirection: 'row',
                            alignItems: "center",
                        }}>
                            <TouchableOpacity onPress={openDrawer} style={{
                                marginRight: dimensWidth(10),
                            }}>
                                <MenuIcon color={'#fff'} />
                            </TouchableOpacity>

                            <View style={{
                                flex: 1,
                            }}>
                                <Text style={{
                                    color: Colors.white,
                                    fontSize: FontSize.LARGE,
                                    fontWeight: '400',
                                    fontFamily: 'arial',
                                }}>{`${subSite.toUpperCase()}`}</Text>
                                <Text style={{
                                    color: Colors.white,
                                    fontSize: FontSize.MEDIUM,
                                    fontWeight: '400',
                                    fontFamily: 'arial',
                                    marginTop: dimnensHeight(2)
                                }}>Văn bản đi / Đã phát hành</Text>
                            </View>
                            <TouchableOpacity style={styles.filterIcon} onPress={() => setModalFilter(true)}>
                                <FilterIcon color={isDefaultFilter ? colors.white : colors.red} />
                            </TouchableOpacity>
                            <View style={{
                                height: '50%',
                                width: 1,
                                backgroundColor: 'white'
                            }} />
                        </View>
                    </LinearGradient>
                    <TopBarTab
                        isShowSearch={true}
                        textSearch={textSearch}
                        onChangeFilterText={onChangeFilterText}
                        isHideButtonSearch
                    />
                    {
                        !arrayIsEmpty(dataVBDaBanHanh) ?
                            <FlatList
                                ref={flatListRef}
                                data={dataVBDaBanHanh}
                                extraData={dataVBDaBanHanh}
                                refreshControl={
                                    <RefreshControl refreshing={isRefreshVBBH} onRefresh={onRefreshVBBH} tintColor='#0054AE' />
                                }
                                onEndReachedThreshold={0.5}
                                onEndReached={handleLoadmore}
                                showsVerticalScrollIndicator={true}
                                getItemLayout={(_, index) => ({
                                    length: dimnensHeight(134), //  WIDTH + (MARGIN_HORIZONTAL * 2)
                                    offset: dimnensHeight(134) * (index),  //  ( WIDTH + (MARGIN_HORIZONTAL*2) ) * (index)
                                    index,
                                })}
                                keyExtractor={(item, index) => index.toString()}
                                ListFooterComponent={renderFooter(isLoadingVBBH)}
                                renderItem={({ item, index }) => (
                                    <ItemLeft
                                        item={item}
                                        index={index}
                                        subSite={subSite}
                                        token={token}
                                        gotoDetail={gotoDetailPress}
                                        selectedItemIndex={selectedItemIndex}
                                    />
                                )} /> : renderEmpty()
                    }
                </View>
                <View style={{
                    width: '65%',
                }}>
                    {(!isNullOrEmpty(Item)) ? <VBBHDetail route={{
                        ItemId: Item.ID
                    }} navigation={navigation} token={token} selectedItemIndex={selectedItemIndex} /> : (<View style={{ flex: 1 }}>
                        <LinearGradient style={{
                            paddingLeft: dimensWidth(15),
                            height: dimnensHeight(55),
                            alignItems: 'center',
                            flexDirection: 'row',
                            justifyContent: 'flex-end',
                            paddingRight: dimensWidth(15)
                        }}
                            colors={["#0262E9", "#0054AE"]} />
                        <NoDataView />
                    </View>)}
                </View>
            </View>
            <VBBHFilterModal
                modalVisible={modalFilter}
                onCloseModal={onCloseFilterModal}
                onConfirmModal={(data) => onConfirmFilterModal(data)}
            />
        </View>
    )
}

export default VBDiScreen