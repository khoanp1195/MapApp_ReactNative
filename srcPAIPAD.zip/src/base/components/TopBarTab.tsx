import React from 'react';
import { StyleSheet, View, } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import SearchInput from '~/search/components/SearchInput';
import { SearchIcon } from '../assets/svg';
import { ACTIVE_OPACITY, FontSize, TITLE_TAB_CHOXULY, TITLE_TAB_DAXULY, dimensWidth, dimnensHeight, enumTopBarTabStatus } from '../Constants';
import colors from '../Colors';
import { TextCusTom } from '.';

interface Props {
    isShowSearch: Boolean;
    textSearch: string;
    onChangeFilterText: (text: string) => void;
    onPressTabProcessing?: () => void;
    onPressTabProcessed?: () => void;
    onSearchPress?: () => void;
    status?: number;
    totalRecordString?: string;
    isHideButtonSearch?: Boolean;
}

const TopBarTab: any = ({
    isShowSearch,
    textSearch,
    onChangeFilterText,
    onPressTabProcessing,
    status,
    totalRecordString,
    onPressTabProcessed,
    onSearchPress,
    isHideButtonSearch = false
}: Props) => {

    return (
        <View style={styles.container}>
            <View style={styles.flexRow}>
                <View style={styles.flexOne}>
                    {
                        isShowSearch ? (<View style={styles.SearchInputView}>
                            <SearchInput
                                onChangeFilterText={onChangeFilterText}
                                filterText={textSearch} />
                        </View>) : (
                            <View style={styles.tabContainerr}>
                                <TouchableOpacity
                                    activeOpacity={ACTIVE_OPACITY}
                                    onPress={onPressTabProcessing}
                                    style={status == enumTopBarTabStatus.VBChoXuLy ? styles.onPressActiveTab : styles.onPressInActiveTab}
                                >
                                    <TextCusTom style={status == enumTopBarTabStatus.VBChoXuLy ? styles.titleActiveTab : styles.titleInActiveTab}>{TITLE_TAB_CHOXULY}
                                        <TextCusTom style={styles.titleNotifyCount}>{` (${totalRecordString})`}</TextCusTom>
                                    </TextCusTom>
                                </TouchableOpacity>
                                <TouchableOpacity
                                    activeOpacity={ACTIVE_OPACITY}
                                    style={status == enumTopBarTabStatus.VBDaXuLy ? styles.onPressActiveTab : styles.onPressInActiveTab}
                                    onPress={onPressTabProcessed}>
                                    <TextCusTom style={status == enumTopBarTabStatus.VBDaXuLy ? styles.titleActiveTab : styles.titleInActiveTab}>{TITLE_TAB_DAXULY}</TextCusTom>
                                </TouchableOpacity>
                            </View>
                        )
                    }
                </View>
                {
                    !isHideButtonSearch &&
                    <TouchableOpacity
                    onPress={onSearchPress}
                    style={styles.searchIconView}>
                    <SearchIcon color={isShowSearch ? colors.blueLight : colors.black} />
                </TouchableOpacity>
                }
            </View>
        </View>
    );
};
const styles = StyleSheet.create({
    container: {
        width: '100%',
        height: dimnensHeight(55),
        justifyContent: 'center'
    },
    flexRow: { flexDirection: 'row' },
    SearchInputView: {
        height: dimnensHeight(35),
        borderWidth: 1,
        borderRadius: dimensWidth(18),
        borderColor: '#005FD4',
        marginLeft: dimensWidth(15),
        marginRight: dimensWidth(15),
        backgroundColor: colors.white,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center'
    },
    flexOne: { flex: 1 },
    tabContainerr: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'baseline',
        borderRadius: dimensWidth(18),
        height: dimensWidth(35),
        marginLeft: 15,
        // width: dimensWidth(270),
        backgroundColor: colors.tab_bg_blue,
        borderColor: colors.white,
        borderWidth: 1,
        padding: 0,
    },
    searchIconView: {
        flex: 1,
        justifyContent: 'center',
        marginRight: dimensWidth(15)
    },
    onPressActiveTab: {
        paddingVertical: 6,
        paddingHorizontal: 12,
        backgroundColor: colors.white,
        borderRadius: dimensWidth(18),
        margin: 1
    },
    onPressInActiveTab: {
        paddingVertical: 6,
        paddingHorizontal: 12,
        borderRadius: dimensWidth(18),
    },
    titleActiveTab: {
        fontSize: FontSize.MEDIUM,
        color: colors.primary,
        fontWeight: '700',
        fontFamily: 'arial',
    },
    titleInActiveTab: {
        fontSize: FontSize.MEDIUM,
        color: colors.white,
        fontWeight: '400',
        fontFamily: 'arial',
    },
    titleNotifyCount: {
        fontSize: FontSize.MEDIUM,
        color: colors.orange,
        fontWeight: '700',
    },
});
export default React.memo(TopBarTab);
