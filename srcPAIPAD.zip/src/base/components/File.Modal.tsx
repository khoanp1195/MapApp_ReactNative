import React, { FC, useState, useCallback, useEffect } from "react";
import {
    Modal,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    KeyboardAvoidingView,
    Platform,
    TouchableWithoutFeedback,
    Keyboard,
    Image,
    Dimensions
} from "react-native";
import colors from "~/base/Colors";
import { BASE_URL, FontSize, dimensWidth, dimnensHeight, windowHeight, windowWidth } from "~/base/Constants";
import { BackIcon, CloseXIcon, ConfirmIcon, DownloadIcon, SearchIcon, SellectedBoxIcon, UnSellectedBoxIcon } from "~/base/assets/svg";
import { NoDataView, TextInputCustom } from "~/base/components";
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from "@reduxjs/toolkit";
import SearchInput from "~/search/components/SearchInput";
import FastImage from "react-native-fast-image";
import { fetchUserGroup } from "../stories/data/reducer";
import moment from "moment";
import { arrayIsEmpty, checkMimeTypeFiles, format_mm_dd_hh_yy_mm_ss, format_yy_mm_dd, getExtension, removeSpecialCharacters } from "../Functions";
import { FlatList } from "react-native-gesture-handler";
import WebView from "react-native-webview";
// import RNFetchBlob from 'react-native-fetch-blob';

interface Props {
    modalVisible: Boolean;
    onCloseModal: () => void;
    value: any;
}

const FileModal: FC<Props> = ({
    modalVisible,
    onCloseModal,
    value,
    ...props
}: Props) => {
    const { token } = useSelector((state: any) => state.login);

    const DownloadFile = () => {
        const replaceTitle = value?.Title.replaceAll(" ", "_");
        const { fs, config } = RNFetchBlob;
        const { dirs } = RNFetchBlob.fs;
        const downloadDir = Platform.OS == 'ios' ? dirs.DocumentDir : dirs.DownloadDir
        const typeFile = getExtension(value?.Url)
        const mimeType = checkMimeTypeFiles(value?.Url);
        const options = {
            fileCache: true,
            useDownloadManager: true,
            notification: true,
            mediaScannable: true,
            mime: mimeType,
            title: `${replaceTitle}.${typeFile}`,
            path: `${downloadDir}/${replaceTitle}.${typeFile}`, // Replace with the desired download destination and filename
            description: 'Downloading file...',
        };
        const configOptions = Platform.select({
            ios: {
                fileCache: options.fileCache,
                title: options.title,
                path: options.path,
                appendExt: typeFile,
            },
            android: options
        });
        config(configOptions)
            .fetch('GET', encodeURI(BASE_URL + value?.Url), {
                Authorization: `${token}`,
                "Content-Type": "multipart/form-data",
            })
            .then((res) => {
                if (Platform.OS === "ios") {
                    alert('Tải tệp thành công!')
                    RNFetchBlob.fs.writeFile(options.path, res.data, 'base64');
                    RNFetchBlob.ios.previewDocument(options.path);
                }
            })
            .catch((error) => {
                alert("Tải tệp thất bại!")
            });
    }
    return (
        <Modal
            transparent={true}
            visible={modalVisible}
            {...props}
            style={styles.centeredView}
        >
            <KeyboardAvoidingView style={styles.centeredView}>
                <View style={styles.modalView}>
                    <View style={{
                        padding: dimensWidth(20),
                        flexDirection: 'row',
                        alignItems: 'center'
                    }}>

                        <Text style={{
                            flex: 1,
                            color: '#005FD4',
                            fontSize: FontSize.LARGE_X,
                            fontWeight: 700,
                        }}>{value?.Title}</Text>
                        <TouchableOpacity style={{
                            marginRight: dimensWidth(40)
                        }}
                            onPress={DownloadFile}
                        >
                            <DownloadIcon color='#005FD4' />
                        </TouchableOpacity>
                        <TouchableOpacity onPress={onCloseModal}>
                            <CloseXIcon />
                        </TouchableOpacity>
                    </View>
                    <View style={{
                        width: '100%',
                        height: dimnensHeight(10),
                        backgroundColor: '#F6F8FA'
                    }} />
                    <WebView
                        source={{ uri: BASE_URL + value?.Url }}
                        style={{ flex: 1 }}
                        sharedCookiesEnabled
                    />
                </View>
            </KeyboardAvoidingView>
        </Modal>
    )
}

const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(0,0,0,0.4)"
    },
    modalView: {
        height: dimnensHeight(740),
        width: dimensWidth(850),
        backgroundColor: 'white',
        borderRadius: 20,
        overflow: 'hidden'
    }
});

export default FileModal