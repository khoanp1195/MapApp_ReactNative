import React, { FC } from 'react';
import { Text } from 'react-native';
import { TextProps } from 'react-native-svg';

const TextInputCustom: any = ({
    children,
    ...props
}: any) => {
    return (
        <Text
            allowFontScaling={false}
            {...props}
        >
            {children}
        </Text>
    );
};
export default TextInputCustom;
