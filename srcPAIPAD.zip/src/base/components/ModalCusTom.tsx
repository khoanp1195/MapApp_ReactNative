import React, { Children, FC, useEffect, useState } from 'react';
import { Modal, View } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../stories';
import { setIsCloseModalApp } from '../stories/data/reducer';

interface Props {
  children: React.ReactNode;
  visible: Boolean;
  transparent?: Boolean;
  props: FC<Props>;
  onCloseModalCustom: () => void
}
const ModalCusTom: FC<Props> = ({
  children,
  visible = false,
  transparent,
  onCloseModalCustom,
  ...props
}: Props) => {
  const { IsCloseModalApp } = useSelector((state: RootState) => state.data);
  const dispatch = useDispatch();
  const [modalVisible, setModalVisible] = useState(false)

  useEffect(() => {
    setModalVisible(visible)
  }, [visible])
  useEffect(() => {
    if (IsCloseModalApp && modalVisible) {
      dispatch(setIsCloseModalApp(false))
      onCloseModalCustom();
    }
  }, [IsCloseModalApp, dispatch, modalVisible])

  return (
    <Modal
      transparent={true}
      visible={modalVisible}
      {...props}>
      <>
        {children}
      </>
    </Modal>
  );
};
export default ModalCusTom;
