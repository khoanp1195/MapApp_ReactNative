import React, { FC, } from 'react';
import { StyleProp, ViewProps } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';

interface Props {
    children: React.ReactNode;
    props: FC<Props>;
    colors: Array<string>
}
const LinearGradientView: any = ({
    children,
    colors = ["#0262E9", "#0054AE"],
    ...props
}: Props) => {

    return (
        <LinearGradient
            colors={colors}
            {...props}>
            <>
                {children}
            </>
        </LinearGradient>
    );
};
export default React.memo(LinearGradientView);
