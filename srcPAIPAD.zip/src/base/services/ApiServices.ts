import axios from 'axios';
import { BASE_URL } from '../Constants'

export const get = async (url: String) => {
  const response = await axios({
    method: "get",
    url: BASE_URL + url,
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
    }
  })

  return response
}
export const post = async (url: String, data: any) => {
  var body = new FormData();
  body.append('data', JSON.stringify(data));
  const response = await axios({
    method: "post",
    url: BASE_URL + url,
    data: body,
    headers: {
      'Accept': 'application/json',
      'Content-Type': `multipart/form-data`,
    }
  })
  console.log('response', response);

  return response
}
