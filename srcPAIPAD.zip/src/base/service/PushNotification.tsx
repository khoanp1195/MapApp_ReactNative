// import { FC, useEffect, useState, useCallback, useRef } from 'react';
// import PushNotification, { Importance } from "react-native-push-notification";
// import messaging from '@react-native-firebase/messaging';
// import { Alert, AppState, Linking, } from 'react-native';
// import AsyncStorage from '@react-native-async-storage/async-storage';
// import md5 from 'md5';
// import PushNotificationIOS from "@react-native-community/push-notification-ios";
// import { ThunkDispatch } from "@reduxjs/toolkit";
// import { useDispatch, useSelector } from "react-redux";
// import { VersionCompare, arrayIsEmpty, isNullOrUndefined } from '../Functions';
// import { RootState } from "stores";
// import * as RootContainer from "../navigation/RootContainer.Screen"
// import { setIsCloseModalApp, setRemoteMessage } from '../stories/data/reducer';
// import { setSubSite } from '../stories/login/reducer';
// import DeviceInfo from 'react-native-device-info';
// import { get } from "services/ApiServices"

// const Configure = () => {
//     const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
//     const { subSite, isLogin, token } = useSelector((state: RootState) => state.login);
//     const appState = useRef(AppState.currentState)
//     const [isForceUpdate, setIsForceUpdate] = useState(true)
//     const checkAppVersion = () => {
//         const appKey = 'IPad_AppVer'
//         get(`/${getSubSiteOwn()}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=SettingByKey&params=SettingKey&SettingKey=${appKey}`).then(res => {
//             if (res.data.data && !arrayIsEmpty(res.data.data)) {
//                 const appVer = DeviceInfo.getVersion()
//                 const serverVer = res.data.data[0].VALUE
//                 const ver = VersionCompare(serverVer, appVer)
//                 if (ver === 1 && isForceUpdate) {
//                     Alert.alert('Thông báo', 'Đã có phiên bản mới. Vui lòng cập nhật để có trải nghiệm tốt hơn!', [
//                         {
//                             text: 'Đồng ý',
//                             onPress: () => {
//                                 let urlStore = `https://apps.apple.com/us/app/eofficepa-hd/id6462018269`
//                                 Linking.canOpenURL(urlStore)
//                                     .then(() => {
//                                         Linking.openURL(urlStore);
//                                     })
//                                     .catch();

//                                 setIsForceUpdate(true)
//                             }
//                         }
//                     ])

//                     setIsForceUpdate(false)
//                 }
//             }
//         })
//     }
//     useEffect(() => {
//         if (isLogin) {
//             checkAppVersion()
//             const subscription = AppState.addEventListener('change', nextAppState => {
//                 if (appState.current.match(/inactive|background/) && nextAppState === 'active') {
//                     checkAppVersion()
//                 }

//                 appState.current = nextAppState;
//             });

//             return () => {
//                 subscription.remove();
//             };
//         }
//     }, [isLogin, isForceUpdate])


//     const configureNotificationiOS = () => {
//         messaging().onMessage((remoteMessage: any) => {
//             PushNotification.localNotification({
//                 title: remoteMessage.data.NotifyTitle,
//                 message: remoteMessage.data.NotifyContent,
//                 userInfo: remoteMessage.data
//             });
//         });
//     }

//     const redirect = useCallback(async (remoteMessage: any) => {
//         const data = remoteMessage.data
//         if (RootContainer.navigationRef.isReady()) {
//             try {
//                 if (!isNullOrUndefined(remoteMessage.messageId)) {
//                     const lastInitialNotificationId = await AsyncStorage.getItem('AS_KEY_LAST_INITIAL_NOTIFICATION_ID')

//                     if (lastInitialNotificationId !== null) {
//                         if (lastInitialNotificationId === remoteMessage.messageId) {
//                             return
//                         }
//                     }

//                     await AsyncStorage.setItem('AS_KEY_LAST_INITIAL_NOTIFICATION_ID', remoteMessage.messageId)
//                 }
//             } catch (e) {
//                 // don't mind, this is a problem only if the current RN instance has been reloaded by a CP mandatory update
//             }

//             if (getSubSiteOwn() !== data.SiteName) {
//                 Alert.alert('Thông báo', 'Bạn đang xem Văn bản ở site khác. Bạn có muốn chuyển site không ?', [
//                     {
//                         text: "Hủy",
//                         style: "cancel"
//                     },
//                     {
//                         text: "Đồng ý",
//                         onPress: () => onChange(remoteMessage)
//                     }
//                 ])
//             } else {
//                 RootContainer.navigate('HomeProcessingScreen', {
//                     DocumentID: data.ResourceId,
//                     tabStatus: 0
//                 });
//                 dispatch(setRemoteMessage(remoteMessage))
//                 dispatch(setIsCloseModalApp(true));
//             }
//         } else {
//             dispatch(setRemoteMessage(remoteMessage))
//         }
//     }, [dispatch])

//     const onChange = useCallback(async (remoteMessage: any) => {
//         const data = remoteMessage.data
//         dispatch(setSubSite(data.SiteName))
//         await AsyncStorage.removeItem('AS_KEY_LAST_INITIAL_NOTIFICATION_ID')
//         redirect(remoteMessage)
//     }, [dispatch])

//     useEffect(() => {
//         PushNotification.configure({
//             // Click banner for foreground
//             onNotification: (remoteMessage: any) => {
//                 if (remoteMessage.userInteraction && remoteMessage.foreground) {
//                     redirect(remoteMessage)
//                 }
//                 const result = PushNotificationIOS.FetchResult.NoData;
//                 remoteMessage.finish(result);
//             }
//         });

//         configureNotificationiOS()

//         messaging().onNotificationOpenedApp(remoteMessage => {
//             console.log('onNotificationOpenedApp')
//             redirect(remoteMessage)
//         });

//         messaging()
//             .getInitialNotification()
//             .then(remoteMessage => {
//                 if (remoteMessage) {
//                     redirect(remoteMessage)
//                 }
//             });
//     }, [])

//     useEffect(() => {
//         setSubSiteOwn(subSite)
//     }, [subSite])

//     return null
// }

// export const getFcmToken = () => {
//     messaging().getToken().then(fcmToken => {
//         if (fcmToken) {
//             AsyncStorage.setItem('deviceToken', fcmToken)
//         } else {
//             PushNotification.configure({
//                 // (optional) Called when Token is generated (iOS and Android)
//                 onRegister: (token: any) => {
//                     AsyncStorage.setItem('deviceToken', token.token)
//                 },
//                 requestPermissions: true,
//             });
//         }
//     });
// }

// export const getDeviceId = () => {
//     AsyncStorage.getItem('deviceId').then(deviceId => {
//         if (deviceId === null || deviceId === undefined) {
//             const newDeviceId = md5(Date.now())
//             AsyncStorage.setItem('deviceId', newDeviceId);
//         }
//     })
// }

// export const requestUserPermission = async () => {
//     try {
//       await messaging().requestPermission();
//       getFcmToken()
//     } catch (err) {
//         console.log(err)
//     }
// }

// let subs = ''
// export const setSubSiteOwn = (sub: any) => {
//     subs = sub;
// }

// export const getSubSiteOwn = () => {
//     return subs
// }

// export default Configure
