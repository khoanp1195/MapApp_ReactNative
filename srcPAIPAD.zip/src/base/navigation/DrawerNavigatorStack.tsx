import React, { useCallback } from "react";
import { View, Text, TouchableOpacity, Platform } from "react-native";
import { bottomTabName, dimensWidth, funtionVBDenData, funtionVBDiData } from "../../base/Constants";
import { createStackNavigator } from "@react-navigation/stack";
import { createDrawerNavigator } from "@react-navigation/drawer";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import DrawerView from "./DrawerView.Screen";
import {
  TabHomeIcon,
  TabSearchIcon,
  TabInComingDocxIcon,
  TabOutGoingDocxIcon,
} from "../../base/assets/svg/index";
import styles from "./RootContainer.Style";
import SearchScreen from "../../search/Search.Screen"
import DashboardScreen from "../../dashboard/Dashboard.Screen"
import HomeProcessingScreen from "../../home/Home.Processing.Screen"
import LinearGradient from 'react-native-linear-gradient';
import HomeNotificationScreen from "../../home/Home.Notifications.Screen"
import HomeCombinationScreen from "../../home/Home.Combination.Screen"
import VBDenScreen from "~/vbden/VBDen.Screen";
import VBDenMenuScreen from "~/home/VBDenMenu.Screen";
import VBDiScreen from "~/vbdi/VBDi.Screen";
import VBDiMenu from "~/home/VBDiMenu.Screen";
import VBDaBanHanhScreen from "~/vbbh/VBBH.Screen";
import { useDispatch } from "react-redux";
import { ThunkDispatch } from "redux-thunk";

const Stack = createStackNavigator();
const DrawerStack = createDrawerNavigator();
const BottomStack = createBottomTabNavigator();

function AppDrawerStack() {
  return (
    <DrawerStack.Navigator drawerContent={(props) => <DrawerView {...props} />}>
      <DrawerStack.Screen
        options={{ headerShown: false }}
        name="AppBottomStack"
        component={AppBottomStack}
      />
    </DrawerStack.Navigator>
  );
}

const renderTabIcon = (isFocused: Boolean, label: String) => {
  switch (label) {
    case bottomTabName.VanBanDen:
      return <TabInComingDocxIcon color={isFocused ? "#025ED8" : "#fff"} />;
    case bottomTabName.VanBanDi:
      return <TabOutGoingDocxIcon color={isFocused ? "#025ED8" : "#fff"} />;
    case bottomTabName.Tracuu:
      return <TabSearchIcon color={isFocused ? "#025ED8" : "#fff"} />;
    default:
      return <TabHomeIcon color={isFocused ? "#025ED8" : "#fff"} />;
  }
};
function MyTabBar({ state, descriptors, navigation }: any) {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();

  return (
    <LinearGradient
      style={styles.viewTabBottomBar}
      colors={["#0054AE", "#0262E9"]}
    >
      {state.routes.map((route: any, index: number) => {
        const { options } = descriptors[route.key];
        const label =
          options.tabBarLabel !== undefined
            ? options.tabBarLabel
            : options.title !== undefined
              ? options.title
              : route.name;

        const isFocused = state.index === index;

        const onPress = () => {
          const event = navigation.emit({
            type: "tabPress",
            target: route.key,
            canPreventDefault: true,
          });

          if (!isFocused && !event.defaultPrevented) {
            // The `merge: true` option makes sure that the params inside the tab screen are preserved
            navigation.navigate({ name: route.name, merge: true });
          }
        };

        const onLongPress = () => {
          navigation.emit({
            type: "tabLongPress",
            target: route.key,
          });
        };

        return (
          <TouchableOpacity
            key={label}
            activeOpacity={1}
            accessibilityRole="button"
            accessibilityState={
              isFocused ? { selected: true } : { selected: false }
            }
            accessibilityLabel={options.tabBarAccessibilityLabel}
            testID={options.tabBarTestID}
            onPress={onPress}
            onLongPress={onLongPress}
            style={{ flex: 1, justifyContent: "center", alignItems: "center" }}
          >
            <View
              style={[
                styles.tabBarIconView,
                isFocused && {
                  backgroundColor: "#fff",
                  shadowColor: '#A9D1FF',
                  shadowOffset: {
                    width: 0,
                    height: 3
                  },
                  shadowRadius: 5,
                  shadowOpacity: 1.0
                },
              ]}
            >
              {renderTabIcon(isFocused, label)}
            </View>
            <Text
              style={
                isFocused
                  ? styles.tabBarLabelActive
                  : styles.tabBarLabelInActive
              }
            >
              {label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </LinearGradient>
  );
}
function AppBottomStack() {
  return (
    <BottomStack.Navigator
      options={{
        headerShown: false,
      }}
      tabBar={(props) => {
        return <MyTabBar {...props} />;
      }}
    >
      <BottomStack.Screen
        options={{
          headerShown: false,
          tabBarActiveBackgroundColor: "#025ED8",
          tabBarInactiveBackgroundColor: "#025ED8",
          tabBarLabelStyle: styles.tabBarLabelActive,
          tabBarStyle: { display: "flex" },
          tabBarIcon: ({ focused }) => (
            <View
              style={[
                styles.tabBarIconView,
                focused && { backgroundColor: "#fff" },
              ]}
            >
              <TabHomeIcon color={focused ? "#025ED8" : "#fff"} />
            </View>
          ),
        }}
        name={bottomTabName.TrangChu}
        component={HomeStack}
      />
      <BottomStack.Screen
        name={bottomTabName.VanBanDen}
        component={VBDenStack}
        options={{
          headerShown: false,
          tabBarActiveBackgroundColor: "#025ED8",
          tabBarInactiveBackgroundColor: "#025ED8",
          tabBarLabelStyle: styles.tabBarLabelActive,
          tabBarIcon: ({ focused }) => (
            <View
              style={[
                styles.tabBarIconView,
                focused && { backgroundColor: "#fff" },
              ]}
            >
              <TabInComingDocxIcon color={focused ? "#025ED8" : "#fff"} />
            </View>
          ),
        }}
      />
      <BottomStack.Screen
        name={bottomTabName.VanBanDi}
        component={VBDiStack}
        options={{
          headerShown: false,
          tabBarActiveBackgroundColor: "#025ED8",
          tabBarInactiveBackgroundColor: "#025ED8",
          tabBarLabelStyle: styles.tabBarLabelActive,
          tabBarIcon: ({ focused }) => (
            <View
              style={[
                styles.tabBarIconView,
                focused && { backgroundColor: "#fff" },
              ]}
            >
              <TabOutGoingDocxIcon color={focused ? "#025ED8" : "#fff"} />
            </View>
          ),
        }}
      />
      <BottomStack.Screen
        name={bottomTabName.Tracuu}
        component={SearchScreen}
        options={{
          headerShown: false,
          tabBarActiveBackgroundColor: "#025ED8",
          tabBarInactiveBackgroundColor: "#025ED8",
          tabBarLabelStyle: styles.tabBarLabelActive,
          tabBarIcon: ({ focused }) => (
            <View
              style={[
                styles.tabBarIconView,
                focused && { backgroundColor: "#fff" },
              ]}
            >
              <TabSearchIcon color={focused ? "#025ED8" : "#fff"} />
            </View>
          ),
        }}
      />
    </BottomStack.Navigator>
  );
}

function HomeStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        options={{ headerShown: false }}
        name="DashboardScreen"
        component={DashboardScreen}
      />

      <Stack.Screen
        options={{ headerShown: false }}
        name="HomeProcessingScreen"
        component={HomeProcessingScreen}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name="HomeNotificationScreen"
        component={HomeNotificationScreen}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name="HomeCombinationScreen"
        component={HomeCombinationScreen}
      />
      <Stack.Screen
        options={{ headerShown: false }}
        name="VBDenMenuScreen"
        component={VBDenMenuScreen}
        initialParams={{ type: "Tab" }}
      />
      <Stack.Screen
        name="VBDiMenu"
        component={VBDiMenu}
        options={{
          gestureEnabled: true,
          gestureDirection: "horizontal",
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="VBDaBanHanhScreen"
        component={VBDaBanHanhScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal", headerShown: false }}
      />
    </Stack.Navigator>
  );
}

function VBDenStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        options={{ headerShown: false }}
        name="VBDenScreen"
        component={VBDenScreen}
        initialParams={{ type: "Tab" }}
      />
    </Stack.Navigator>
  );
}
function VBDiStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        options={{ headerShown: false }}
        name="VBDiScreen"
        component={VBDiScreen}
        initialParams={{ type: "Tab" }}
      />
    </Stack.Navigator>
  );
}

export default function DrawerNavigatorStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        options={{ headerShown: false }}
        name="AppDrawerStack"
        component={AppDrawerStack}
      />
    </Stack.Navigator>
  );
}
