import React, { useState, useEffect } from "react";
import styles from "./RootContainer.Style";
import { View, StatusBar } from "react-native";
import { NavigationContainer, createNavigationContainerRef } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import LoginScreen from "../../login/Login.Screen";
import { RootState } from "stores";
import { useSelector } from "react-redux";
import DrawerNavigatorStack from "./DrawerNavigatorStack";
export type StackParamList = {
  LoginScreen: undefined;
  DrawerNavigatorStack: undefined;
};
import type { StatusBarStyle } from "react-native";
import {
  SafeAreaProvider,
  SafeAreaView,
  useSafeAreaInsets,
} from "react-native-safe-area-context";
import colors from "../Colors";

export const navigationRef = createNavigationContainerRef()
export const navigate = (name: any, params: any) => {
  if (navigationRef.isReady()) {
    navigationRef.navigate(name, params);
  }
}

const Stack = createStackNavigator<StackParamList>();

const RootContainerScreen = () => {
  const { isLogin } = useSelector((state: RootState) => state.login);

  return (
    <SafeAreaProvider>
      {
        isLogin ? <SafeAreaView style={styles.mainContainer}>
          <StatusBar barStyle='light-content' backgroundColor={colors.primary} />
          <DrawerNavigatorStack />
        </SafeAreaView> :
          <>
            <StatusBar barStyle='light-content' backgroundColor='transparent' translucent={true} />
            <Stack.Navigator
              initialRouteName="LoginScreen"
              screenOptions={{
                headerShown: false,
              }}
            >
              <Stack.Screen
                name="LoginScreen"
                component={LoginScreen}
                options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
              />
            </Stack.Navigator>
          </>
      }
    </SafeAreaProvider>
  );
};

export default RootContainerScreen
