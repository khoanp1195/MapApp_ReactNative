import React, { useCallback, useState, useMemo, useEffect } from "react";
import { View, Text, Image, StyleSheet, TouchableOpacity, ScrollView, Alert } from "react-native";
import { useDispatch, useSelector } from "react-redux";
import {
  ChevronDownIcon,
  ProcessingDocxIcon,
  CoordinationDocxIcon,
  NotificationIcon,
  WaitingCommentIcon,
  MainDocxIcon,
  ProcessedIcon,
  WaitingActionIcon,
  AllActionIcon,
  PublishedIcon,
  WaitForApprovedIcon,
  LogOutPrimaryIcon,
  SelectedEnalbleIcon,
  SelectedDisableIcon,
  VBDiIcon,
} from "../../base/assets/svg/index";
import colors from "../../base/Colors";
import { bottomTabName, dimensWidth, FontSize, funtionVBDenData, funtionVBDiData } from "../../base/Constants";
import { arrayIsEmpty, removeSpecialCharacters } from "../../base/Functions";
import { fetchCurrentUser, logOut, logoutAction, setSubSite } from "~/base/stories/login/reducer";
import { RootState } from "stores";
import FastImage from 'react-native-fast-image';
import { BASE_URL } from '../Constants'
import { isNullOrUndefined } from '../Functions'
import { menuAction } from "../stories/menu/reducer";
import SelectDropdown from 'react-native-select-dropdown';
import DeviceInfo from "react-native-device-info";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { onChangeFuntionVBDenMenu, onChangeFuntionVBDiMenu, onChangeSellecteDocumentIDbDiAction } from "../stories/home/reducer";

const DrawerView = ({ route, navigation }: any) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const { dataCurrentUsers, subSite, token } = useSelector(
    (state: RootState) => state.login
  );
  const { tabName } = useSelector(
    (state: RootState) => state.menu
  );
  const { dashboardCountData } = useSelector(
    (state: RootState) => state.dashboard
  );
  const [sites, setSites] = useState<any>([])
  const [selectedSite, setSelectedSite] = useState()

  const signOut = async () => {
    const deviceId = await AsyncStorage.getItem('deviceId')
    await AsyncStorage.removeItem('username')
    await AsyncStorage.removeItem('password')
    dispatch(logOut({ deviceId, subSite }))
    dispatch(logoutAction(""));
  }

  const onLogout = useCallback(() => {
    Alert.alert('Thông báo', 'Vui lòng xác nhận thoát khỏi tài khoản', [
      {
        text: "Đăng xuất",
        onPress: () => signOut()
      },
      {
        text: "Hủy",
        style: 'cancel'
      }
    ])
  }, []);

  const FullName = useMemo(() => {
    if (!dataCurrentUsers) return null;
    return dataCurrentUsers[0]?.FullName;
  }, [dataCurrentUsers]);

  const Position = useMemo(() => {
    if (!dataCurrentUsers) return null;
    return removeSpecialCharacters(dataCurrentUsers[0]?.Position);
  }, [dataCurrentUsers]);

  const ViecCanXuLy = useMemo(() => {
    return isNullOrUndefined(dashboardCountData?.ViecCanXuLy) ? 0 : dashboardCountData?.ViecCanXuLy;
  }, [dashboardCountData]);

  const ThongBao = useMemo(() => {
    return isNullOrUndefined(dashboardCountData?.ThongBao) ? 0 : dashboardCountData?.ThongBao;
  }, [dashboardCountData]);

  const VanBanPhoiHop = useMemo(() => {
    return isNullOrUndefined(dashboardCountData?.VanBanPhoiHop) ? 0 : dashboardCountData?.VanBanPhoiHop;
  }, [dashboardCountData]);

  const tab = useMemo(() => {
    return tabName
  }, [tabName])

  const onGoToVBDaBanHanhScreen = useCallback(() => {
    navigation.navigate({
      name: "VBDaBanHanhScreen",
      params: { selectedItemIndex: 0 }
    });
  }, [navigation]);
  const onGoToVBDicreen = (funtionVBDi: any) => {
    dispatch(onChangeFuntionVBDiMenu(funtionVBDi))
    navigation.navigate(bottomTabName.TrangChu, {
      screen: "VBDiMenu",
      params: { funtionVBDi }
    });
  };
  const onGoToVBDenScreen = useCallback((funtionVBDen: any) => {
    dispatch(onChangeFuntionVBDenMenu(funtionVBDen))
    navigation.navigate(bottomTabName.TrangChu, {
      screen: "VBDenMenuScreen",
    });
  }, [navigation]);
  useEffect(() => {
    if (!arrayIsEmpty(dataCurrentUsers)) {
      const siteNames = dataCurrentUsers[0].SiteName.split(';')
      let tmp = []
      for (let index = 0; index < siteNames.length; index++) {
        const element = siteNames[index];
        tmp.push({
          title: element,
          checked: index == 0
        })
      }

      setSelectedSite(!isNullOrUndefined(selectedSite) ? selectedSite : tmp[0].title)
      setSites(tmp)

    }
  }, [dataCurrentUsers, selectedSite])

  const onChange = useCallback((selectedItem: any, index: any) => {
    dispatch(setSubSite(selectedItem.title))
    dispatch(fetchCurrentUser(subSite))
    setSelectedSite(selectedItem.title.toLowerCase())
    navigation.closeDrawer();
  }, [dispatch, subSite])
  const versionAppstore = useMemo(() => DeviceInfo.getVersion(), [DeviceInfo])
  return (
    <ScrollView style={styles.container}>
      <View style={styles.viewAvatar}>
        <FastImage
          style={styles.avatar}
          source={{
            uri: BASE_URL + "/" + subSite + dataCurrentUsers[0]?.ImagePath,
            headers: { Authorization: `${token}` },
            priority: FastImage.priority.normal,
          }}
          resizeMode={FastImage.resizeMode.contain}
        />
        <View>
          <Text style={styles.titleAvatar}>{FullName}</Text>
          <Text style={styles.position}>{Position}</Text>
        </View>
      </View>
      {/* <TouchableOpacity style={styles.viewCoporation}>
          <View
            style={styles.linearCoporation}
          >
            <Text style={{
              fontSize: FontSize.MEDIUM,
              color: colors.primary,
              fontWeight: "800",
              fontFamily: "arial",
            }}>{subSite.toUpperCase()}</Text>
            <View style={styles.chevronDown}>
              <ChevronDownIcon />
            </View>
          </View>
        </TouchableOpacity> */}
      <SelectDropdown
        data={sites}

        onSelect={(selectedItem: any, index: number) => { onChange(selectedItem, index) }}
        buttonTextAfterSelection={(selectedItem: any, index: number) => {
          return selectedItem.title.toUpperCase();
        }}
        rowTextForSelection={(item: any, index: number) => {
          return item.title.toUpperCase();
        }}
        renderDropdownIcon={(isOpened: Boolean) => {
          return <ChevronDownIcon />;
        }}
        defaultButtonText={subSite.toUpperCase()}
        buttonStyle={styles.dropdown1BtnStyle}
        renderCustomizedRowChild={(item: any, index: number) => {
          return (
            <View style={{
              flexDirection: 'row',
              marginLeft: 10,
            }}>
              {selectedSite === item.title ? <SelectedEnalbleIcon /> : <SelectedDisableIcon />}
              <Text style={{
                marginLeft: 10,
                color: '#000000',
                fontWeight: 400,
                fontSize: FontSize.MEDIUM
              }}>{item.title.toUpperCase()}</Text>
            </View>
          );
        }}
        buttonTextStyle={{
          fontSize: FontSize.MEDIUM,
          color: '#015DD1',
          textAlign: 'left',
          fontWeight: "700",
          fontFamily: "arial"
        }}

        dropdownIconPosition={'right'}
        dropdownStyle={styles.dropdown1DropdownStyle}
        rowStyle={styles.dropdown1RowStyle}
        rowTextStyle={styles.dropdown1RowTxtStyle}
      />
      <TouchableOpacity style={tab === 'VB chờ xử lý' ? styles.flexDirectionSelected : styles.flexDirectionBetween} onPress={() => {
        dispatch(menuAction("VB chờ xử lý"))
        navigation.navigate('HomeProcessingScreen')
      }}>
        <View style={styles.flexDirectionBetween1}>
          <ProcessingDocxIcon />
          <Text style={styles.content}>VB chờ xử lý</Text>
        </View>
        <Text style={styles.notify}>{ViecCanXuLy}</Text>
      </TouchableOpacity>
      <TouchableOpacity style={tab === 'VB phối hợp' ? styles.flexDirectionSelected : styles.flexDirectionBetween} onPress={() => {
        dispatch(menuAction("VB phối hợp"))
        navigation.navigate('HomeCombinationScreen')
      }}>
        <View style={styles.flexDirectionBetween1}>
          <CoordinationDocxIcon />
          <Text style={styles.content}> VB phối hợp</Text>
        </View>
        <Text style={styles.notify}>{VanBanPhoiHop}</Text>
      </TouchableOpacity>
      <TouchableOpacity style={tab === 'Thông báo' ? styles.flexDirectionSelected : styles.flexDirectionBetween} onPress={() => {
        dispatch(menuAction("Thông báo"))
        navigation.navigate('HomeNotificationScreen')
      }}>
        <View style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          padding: dimensWidth(15),
          paddingHorizontal: dimensWidth(30)
        }}>
          <NotificationIcon />
          <Text style={styles.content}>Thông báo</Text>
        </View>
        <Text style={styles.notify}>{ThongBao}</Text>
      </TouchableOpacity>
      {/* VĂN BẢN ĐẾN */}
      <TouchableOpacity style={styles.flexDirectionDocx}>
        <MainDocxIcon />
        <Text style={styles.txtDocx}>VĂN BẢN ĐẾN</Text>
      </TouchableOpacity >
      <TouchableOpacity style={tab === 'Chờ cho ý kiến' ? styles.flexDirectionSellected : styles.flexDirection} onPress={() => {
        dispatch(menuAction("Chờ cho ý kiến"))
        onGoToVBDenScreen(funtionVBDenData.VBDenChoChoYKien)
      }}>
        <WaitingCommentIcon />
        <Text style={styles.content}>Chờ cho ý kiến</Text>
      </TouchableOpacity>
      <TouchableOpacity style={tab === 'Chờ thực hiện' ? styles.flexDirectionSellected : styles.flexDirection} onPress={() => {
        dispatch(menuAction("Chờ thực hiện"))
        onGoToVBDenScreen(funtionVBDenData.VBDenChoThucHien)
      }}>
        <WaitingActionIcon />
        <Text style={styles.content}>Chờ thực hiện</Text>
      </TouchableOpacity>
      <TouchableOpacity style={tab === 'Đã xử lý' ? styles.flexDirectionSellected : styles.flexDirection} onPress={() => onGoToVBDenScreen(funtionVBDenData.VBDenDaXuLy)}>
        <ProcessedIcon />
        <Text style={styles.content}>Đã xử lý</Text>
      </TouchableOpacity>
      <TouchableOpacity style={tab === 'Tất cả' ? styles.flexDirectionSellected : styles.flexDirection} onPress={() => {
        dispatch(menuAction("Tất cả"))
        onGoToVBDenScreen(funtionVBDenData.VBDenTatCa)
      }}>
        <AllActionIcon />
        <Text style={styles.content}>Tất cả</Text>
      </TouchableOpacity>
      {/* VĂN BẢN ĐI */}
      <TouchableOpacity style={styles.flexDirectionDocx}>
        <VBDiIcon />
        <Text style={styles.txtDocx}>VĂN BẢN ĐI</Text>
      </TouchableOpacity>
      <TouchableOpacity style={tab === 'Chờ phê duyệt' ? styles.flexDirectionSellected : styles.flexDirection} onPress={() => {
        dispatch(menuAction("Chờ phê duyệt"))
        onGoToVBDicreen(funtionVBDiData.Chopheduyet)
      }}>
        <WaitForApprovedIcon />
        <Text style={styles.content}>Chờ phê duyệt</Text>
      </TouchableOpacity>
      <TouchableOpacity style={tab === 'Đã phê duyệt' ? styles.flexDirectionSellected : styles.flexDirection} onPress={() => {
        dispatch(menuAction("Đã phê duyệt"))
        onGoToVBDicreen(funtionVBDiData.DaPheDuyet)
      }}>
        <ProcessedIcon />
        <Text style={styles.content}>Đã phê duyệt</Text>
      </TouchableOpacity>
      <TouchableOpacity style={tab === 'Đã phát hành' ? styles.flexDirectionSellected : styles.flexDirection} onPress={() => {
        dispatch(menuAction("Đã phát hành"))
        onGoToVBDaBanHanhScreen()
      }}>
        <PublishedIcon />
        <Text style={styles.content}>Đã phát hành</Text>
      </TouchableOpacity>
      <TouchableOpacity style={tab === 'Tất cả vbdi' ? styles.flexDirectionSellected : styles.flexDirection} onPress={() => {
        dispatch(menuAction("Tất cả vbdi"))
        onGoToVBDicreen(funtionVBDiData.TatCa)
      }}>
        <AllActionIcon />
        <Text style={styles.content}>Tất cả</Text>
      </TouchableOpacity>

      <View
        style={{
          width: '100%',
          height: 2,
          backgroundColor: 'rgba(245,245,245,1)'
        }}
      />

      <TouchableOpacity style={styles.flexDirection} onPress={onLogout}>
        <LogOutPrimaryIcon />
        <Text style={styles.logOut}>Đăng xuất</Text>
      </TouchableOpacity>

      <Text style={styles.txtVersion}>Phiên bản {versionAppstore}</Text>

      {/* <AlertModal
        alertTitle={"Thông báo"}
        alertContent={"Vui lòng xác nhận thoát khỏi tài khoản"}
        confirmText={"Đăng xuất"}
        cancelText={"Huỷ"}
        modalVisible={visbleModalLogout}
        onConfirmModal={onConfirmModalPress}
        onCancelModal={onCancelModalPress}
      /> */}
    </ScrollView>
  );
};
const styles = StyleSheet.create({
  container: {
    //paddingHorizontal: 20,
  },
  imgVBChoXuLy: {
    with: 18,
    height: 18,
  },
  flexDirectionBetween: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  flexDirectionSelected: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: '#E6F5FF80',
    borderLeftWidth: 6,
    borderLeftColor: '#0072C6'
  },
  flexDirectionBetween1: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: dimensWidth(15),
    paddingHorizontal: dimensWidth(30)
  },
  flexDirection: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 15,
    paddingHorizontal: dimensWidth(30)
  },
  flexDirectionSellected: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 15,
    paddingHorizontal: dimensWidth(30),
    backgroundColor: '#E6F5FF80',
  },
  viewCoporation: {
    marginBottom: 20,
    height: 34,
    marginHorizontal: dimensWidth(30),
    borderColor: colors.primary,
  },
  linearCoporation: {
    flex: 1,
    paddingLeft: 20,
    justifyContent: "center",
    borderRadius: 5,
    borderWidth: 0.5,
    backgroundColor: '#EEF6FF',
    borderColor: '#015DD1'
  },
  chevronDown: {
    position: "absolute",
    right: 12,
    top: 12,
  },
  flexDirectionDocx: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.greyF5,
    height: 45,
    // marginHorizontal: -20,
    paddingHorizontal: dimensWidth(27)
  },
  title: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginLeft: dimensWidth(15),
  },
  content: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  txtVersion: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: dimensWidth(30),
  },
  notify: {
    fontSize: FontSize.MEDIUM,
    color: colors.orange,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: dimensWidth(15)
  },
  viewAvatar: {
    flexDirection: "row",
    marginTop: 20,
    marginBottom: dimensWidth(25),
    alignItems: "center",
    paddingHorizontal: dimensWidth(30)
  },
  titleAvatar: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
  },
  avatar: {
    height: dimensWidth(36),
    width: dimensWidth(36),
    marginRight: dimensWidth(12),
    borderRadius: dimensWidth(18),
  },
  position: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
  },
  txtDocx: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginLeft: 15,
  },
  logOut: {
    fontSize: FontSize.MEDIUM,
    color: colors.primary,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  dropdown1BtnStyle: {
    height: 34,
    width: dimensWidth(270),
    backgroundColor: '#EEF6FF',
    marginBottom: 30,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#015DD1',
    marginHorizontal: dimensWidth(30)
  },
  dropdown1DropdownStyle: {
    marginBottom: 30,
    borderRadius: 8,
    borderWidth: 1,
    marginTop: 5,
    borderColor: '#015DD1',
    width: dimensWidth(270),
  },

  dropdown1RowStyle: {
    backgroundColor: 'white',

  },
  dropdown1RowTxtStyle: { color: '#000', textAlign: 'left' },
});
export default DrawerView;
