import { StyleSheet, StatusBar, Platform } from "react-native";
import ApplicationStyle from "../Application.Style";
import { dimensWidth } from "../Constants";
const STATUSBAR_HEIGHT = StatusBar.currentHeight;
const APPBAR_HEIGHT = Platform.OS === "ios" ? 44 : 56;

export default StyleSheet.create({
  ...ApplicationStyle,
  viewNetworkErr: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    alignItems: "center",
    justifyContent: "center",
  },
  btnRetry: {
    width: 150,
    height: 40,
    backgroundColor: "white",
    borderRadius: 4,
    alignItems: "center",
    justifyContent: "center",
  },
  textRetry: {
    color: "black",
    fontWeight: "bold",
  },
  tabBarIconView: {
    height: dimensWidth(32),
    width: dimensWidth(32),
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#025ED8",
    borderRadius: 6,
    marginBottom: dimensWidth(2),
  },
  tabBarLabelActive: {
    color: "rgba(255, 255, 255, 1)",
    fontWeight: "700",
    fontSize: 14,
  },
  tabBarLabelInActive: {
    color: "rgba(255, 255, 255, 0.7)",
    fontWeight: "400",
    fontSize: 14,
  },
  viewTabBottomBar: {
    flexDirection: "row",
    height: dimensWidth(68),
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#025ED8",
  },
  container: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: "#ECF0F1",
  },
  buttonsContainer: {
    padding: 10,
  },
  textStyle: {
    textAlign: "center",
    marginBottom: 8,
  },
  statusBar: {
    height: STATUSBAR_HEIGHT,
  },
  appBar: {
    backgroundColor:'#79B45D',
    height: APPBAR_HEIGHT,
  },
  content: {
    flex: 1,
    backgroundColor: '#33373B',
  }
});
