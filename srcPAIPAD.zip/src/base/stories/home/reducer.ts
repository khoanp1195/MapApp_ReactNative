import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { isNullOrUndefined } from "../../Functions"
import { get } from "../../services/ApiServices"
import { BASE_URL, RESONSE_STATUS_SUCCESS, funtionVBDenData, funtionVBDiData } from "../../Constants"


export const fetchDataProcessing = createAsyncThunk(
  'home/fetchDataProcessing', async (item: any) => {
    const res = await get(`/${item.subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=HomeNotify&status=${item.status}&Limit=20&Offset=${item.offset}&DocumentType=${item.DocumentType}&FromDate=${item.FromDate}&ToDate=${item.ToDate}&IsCount=0&FilterText=${item.FilterText}&params=Limit,Offset,IsCount,Status,FilterText,DocumentType,ToDate,FromDate`)
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return {
          data: {
            data: res.data.data.Data,
            offset: item.offset,
            totalRecord: res.data.data.MoreInfo[0].totalRecord
          }
        }
      }
    }
  }
)

export const fetchNotification = createAsyncThunk(
  'home/fetchNotification', async (item: any) => {
    const res = await get(`/${item.subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=Notification&status=${item.status}&limit=20&Offset=${item.offset}&DocumentType=${item.DocumentType}&FromDate=${item.FromDate}&ToDate=${item.ToDate}&IsCount=0&FilterText=${item.FilterText}&params=Limit,Offset,IsCount,Status,FilterText,DocumentType,ToDate,FromDate`)
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {

        return {
          data: {
            data: res.data.data.Data,
            offset: item.offset,
            totalRecord: res.data.data.MoreInfo[0].totalRecord
          }
        }
      }
    }
  }
)

export const fetchCombination = createAsyncThunk(
  'home/fetchCombination', async (item: any) => {
    const res = await get(`/${item.subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=HomeCombination&status=${item.status}&Limit=20&Offset=${item.offset}&DocumentType=${item.DocumentType}&FromDate=${item.FromDate}&ToDate=${item.ToDate}&IsCount=0&FilterText=${item.FilterText}&params=Limit,Offset,IsCount,Status,FilterText,DocumentType,ToDate,FromDate`)
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return {
          data: {
            data: res.data.data.Data,
            offset: item.offset,
            totalRecord: res.data.data.MoreInfo[0].totalRecord
          }
        }
      }
    }
  }
)
export const fetchVBDiMenu = createAsyncThunk(
  'vbdi/fetchVBDiMenu', async (item: any) => {
    const {
      TinhTrang,
      FromDate,
      ToDate,
      FilterText,
      offset,
      funtionVBDi,
      subSite
    } = item;
    const reponseVBDi = await get(
      `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&viewname=${funtionVBDi.key}&Limit=10&Offset=${offset}&TinhTrang=}&FromDate=${FromDate}&ToDate=${ToDate}&FilterText=${FilterText}`,
    );

    if (!isNullOrUndefined(reponseVBDi)) {
      if (reponseVBDi.data.status === RESONSE_STATUS_SUCCESS) {
        return {
          data: {
            data: reponseVBDi.data.data.Data,
            offset: item.offset,
            funtionVBDi: item.funtionVBDi,
            totalRecord: reponseVBDi?.data?.data?.totalRecord,
          }
        }
      }
    }
  }
)
export const fetchVBDenMenu = createAsyncThunk(
  'home/fetchVBDenMenu', async (item: any) => {
    const { TinhTrang, BanLanhDao, FromDate, ToDate, FilterText, offset, funtionVBDen, subSite } = item

    const res = await get(`/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=${funtionVBDen.key}&status=0&Limit=20&Offset=${offset}&IsCount=0&params=Limit,Offset,IsCount,Status,TinhTrang,FromDate,ToDate,BanLanhDao,FilterText&TinhTrang=${TinhTrang}&BanLanhDao=${BanLanhDao}&FromDate=${FromDate}&ToDate=${ToDate}&FilterText=${FilterText}`)

    if (isNullOrUndefined(res?.data?.data)) {
      return {
        data: [],
        offset: 0,
        totalRecord: 0,
        funtionVBDen: item.funtionVBDen,
      }
    }
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return {
          data: {
            data: res.data.data.Data,
            offset: item.offset,
            funtionVBDen: item.funtionVBDen,
            totalRecord: res.data.data.MoreInfo[0].totalRecord,
          }
        }
      }
    }
  }
)
const homeSlice = createSlice({
  name: 'home',
  initialState: {
    dataDocProcessing: {
      data: [],
      totalRecord: 0,
      totalRecordString: 0,
      sellectedIndex: 0,
      status: 0
    },
    dataNotification: {
      data: [],
      totalRecord: 0
    },
    dataCombination: {
      data: [],
      totalRecord: 0,
      status: 0
    },
    isLoading: false,
    dataVBDenMenu: {
      data: [],
      totalRecord: 0,
      totalRecordVbDenTitle: 0,
      funtionVBDen: funtionVBDenData.VBDenTatCa
    },
    isLoadingVBDenMenu: false,
    dataVBDiMenu: {
      data: [],
      totalRecord: 0,
      totalRecordVBDiTitle: 0,
      funtionVBDi: funtionVBDiData.TatCa,
      sellectedDocumentID: null
    },
    isLoadingVBDiMenu: false,
    isRefreshVBDiMenu: false
  },
  reducers: {
    setSellectedProcessingIndex(state, action) {
      state.dataDocProcessing.sellectedIndex = action.payload;
    },
    setDataProcessingStatus(state, action) {
      state.dataDocProcessing.status = action.payload;
    },
    onChangeFuntionVBDiMenu(state, action) {
      state.isLoadingVBDiMenu = true;
      state.dataVBDiMenu = {
        data: [],
        totalRecord: 0,
        totalRecordVBDiTitle: 0,
        funtionVBDi: action.payload,
        sellectedDocumentID: null
      }
    },
    onChangeSellecteDocumentIDbDiAction(state, action) {
      state.dataVBDiMenu.sellectedDocumentID = action.payload
    },
    onRefreshVbDiMenuAction(state, action) {
      state.isRefreshVBDiMenu = true
    },
    onChangeFuntionVBDenMenu(state, action) {
      state.dataVBDenMenu.funtionVBDen = action.payload
    },
  },
  extraReducers: builder => {
    builder
      .addCase(fetchDataProcessing.pending, (state: any, action) => {
        state.isLoading = true
      })
      .addCase(fetchDataProcessing.fulfilled, (state: any, action) => {
        state.dataDocProcessing.data = action.payload?.data.offset > 0 ? state.dataDocProcessing.data.concat(action.payload?.data.data) : action.payload?.data.data
        state.dataDocProcessing.totalRecord = action.payload?.data.totalRecord
        state.dataDocProcessing.totalRecordString = state.dataDocProcessing.status === 0 ? action.payload?.data.totalRecord : state.dataDocProcessing.totalRecordString
        state.isLoading = false
      })
      .addCase(fetchNotification.pending, (state: any, action) => {
        state.isLoading = true
      })
      .addCase(fetchNotification.fulfilled, (state: any, action) => {
        state.dataNotification.data = action.payload?.data.offset > 0 ? state.dataNotification.data.concat(action.payload?.data.data) : action.payload?.data.data
        state.dataNotification.totalRecord = action.payload?.data.totalRecord
        state.isLoading = false
      })
      .addCase(fetchNotification.rejected, (state: any, action) => {
        state.dataNotification = {
          data: [],
          totalRecord: 0
        },
          state.isLoading = false
      })
      .addCase(fetchCombination.pending, (state: any, action) => {
        state.isLoading = true
      })
      .addCase(fetchCombination.fulfilled, (state: any, action) => {
        state.dataCombination.data = action.payload?.data.offset > 0 ? state.dataCombination.data.concat(action.payload?.data.data) : action.payload?.data.data
        state.dataCombination.totalRecord = action.payload?.data.totalRecord
        state.isLoading = false
      })
      .addCase(fetchVBDiMenu.pending, (state: any, action) => {
        state.isLoadingVBDiMenu = true;
      })
      .addCase(fetchVBDiMenu.fulfilled, (state: any, action) => {
        state.dataVBDiMenu.data = action.payload?.data.offset > 0 ? state.dataVBDiMenu.data.concat(action.payload?.data.data) : action.payload?.data.data
        state.dataVBDiMenu.totalRecord = action.payload?.data.totalRecord
        state.isLoadingVBDiMenu = false
        state.isRefreshVBDiMenu = false
      })
      .addCase(fetchVBDiMenu.rejected, (state: any, action) => {
        state.dataVBDiMenu = {
          data: [],
          totalRecord: 0,
          totalRecordVBDiTitle: 0,
          funtionVBDi: state.dataVBDiMenu.funtionVBDi,
          sellectedDocumentID: null
        },
          state.isLoadingVBDiMenu = false;
        state.isRefreshVBDiMenu = false;
      })
      .addCase(fetchVBDenMenu.pending, (state: any, action) => {
        state.isLoadingVBDenMenu = true;
      })
      .addCase(fetchVBDenMenu.fulfilled, (state: any, action: any) => {
        state.dataVBDenMenu.data = action.payload?.data.offset > 0 ? state.dataVBDenMenu.data.concat(action.payload?.data.data) : action.payload?.data.data
        state.dataVBDenMenu.totalRecord = action.payload?.data.totalRecord
        state.isLoadingVBDenMenu = false
      })
      .addCase(fetchVBDenMenu.rejected, (state: any, action) => {
        state.isLoadingVBDenMenu = false;
      })
  },
});
export const { onChangeFuntionVBDenMenu, onRefreshVbDiMenuAction, setSellectedProcessingIndex, onChangeSellecteDocumentIDbDiAction, setDataProcessingStatus, onChangeFuntionVBDiMenu } = homeSlice.actions;

const { reducer } = homeSlice;
export default reducer;