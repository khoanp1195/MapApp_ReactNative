import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    tabName: "",
};


const menuSlice = createSlice({
    name: 'menu',
    initialState: initialState,
    reducers: {
        menuAction: (state, action) => {
            return {
                ...state,
                tabName: action.payload,
            };
        },
    },
});
export const { menuAction } = menuSlice.actions;
const { reducer } = menuSlice;
export default reducer;