import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { isNullOrUndefined } from "../../Functions"
import { get, post } from "../../services/ApiServices"
import { BASE_URL, RESONSE_STATUS_SUCCESS } from "../../Constants"

export const fetchVBDaBanHanhApi = createAsyncThunk(
    'vbBh/fetchVBDaBanHanhApi',
    async (payload: any) => {
        const {
            FilterText,
            offset,
            subSite,
            fromDate,
            toDate
        } = payload
        const reponseVBDaBanHanh = await get(
            `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=VBBanHanh&Limit=20&Offset=${offset}&IsCount=0&params=Limit,offset,IsCount,ToDate,FromDate,FilterText&FilterText=${FilterText}&FromDate=${fromDate}&ToDate=${toDate}`,
        );
        
        return {
            data: reponseVBDaBanHanh?.data?.data?.Data,
            offset,
            totalRecord: reponseVBDaBanHanh?.data?.data?.MoreInfo[0].totalRecord,
        }
    },
);
export const fetchDetailById = createAsyncThunk(
    'vbbh/fetchDetailById', async (item: any) => {
        const res = await get(`/${item.SubSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBBanHanh&rid=${item.ItemId}&vbaction=ById&cmt=1&task=1&actionPer=1`)
        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return res.data.data
            }
        }

        return null
    }
)

export const fetchAttachFiles = createAsyncThunk(
    'vbbh/fetchAttachFiles', async (item: any) => {
        const res = await get(`/${item.SubSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBBanHanh&rid=${item.ItemId}&vbaction=AttachFile`)
        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return res.data.data
            }
        }

        return null
    }
)

export const fetchThongTinLuanChuyen = createAsyncThunk(
    'vbbh/fetchThongTinLuanChuyen', async (item: any) => {
        const res = await get(`/${item.SubSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=VBBanHanhWorkflowHistory&ItemId=${item.ItemId}&params=ItemId`)

        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return res.data.data
            }
        }

        return null
    }
)

export const fetchThongTinLuanChuyenDonViKhac = createAsyncThunk(
    'vbbh/fetchThongTinLuanChuyenDonViKhac', async (item: any) => {
        const res = await get(`/${item.SubSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBBanHanh&vbaction=WorkflowHistoryOtherDepartment&rid=${item.ItemId}`)

        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return res.data.data
            }
        }

        return null
    }
)

export const fetchNguoiXem = createAsyncThunk(
    'vbbh/fetchNguoiXem', async (item: any) => {
        const res = await get(`/${item.SubSite}/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=VBBanHanhNguoiXem&params=Limit,offset,ItemId&ItemId=${item.ItemId}`)
        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return res.data.data
            }
        }

        return null
    }
)

export const submitActionShare = createAsyncThunk(
    'vbbh/submitActionShare', async (payload: any) => {
        const { UserShared, Comment, ItemId, SubSite } = payload;
        const data = {
            UserShared,
            Comment
        }

        const res = await post(`/${SubSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBBanHanh&vbaction=submit&action=1&rid=${ItemId}`, data)
        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return false
            }
        }

        return true
    }
)

const groupList = (data: any) => {
    let ret = []

    let itemSup = {
        title: data[0].Position,
        data: []
    }
    ret.push(itemSup)

    for (let index = 0; index < data.length; index++) {
        const r = data[index];
        if (r.Position !== itemSup.title) {
            const a = []
            a.push(r)

            itemSup = {
                title: r.Position,
                data: a
            }
            ret.push(itemSup)
        } else {
            itemSup.data.push(r)
        }
    }

    return ret
}

const vbbhSlice = createSlice({
    name: 'vbbh',
    initialState: {
        dataDetailVB: {},
        dataFiles: [],
        dataThongTinLuanChuyen: [],
        dataNguoiXem: [],
        dataThongTinLuanChuyenDonViKhac: [],
        isLoadingVBBH: false,
        isLoadmoreVBBH: false,
        isGoBackVBBhScreen: false,
        dataVBDaBanHanh: [],
        isLoadingVBBHDetail: false,
        totalRecordVbbh: 0,
    },
    reducers: {
        onResetVbbhDetailAction(state, action) {
            state.dataDetailVB = {}
            state.dataFiles = []
        },
    },
    extraReducers: builder => {
        // --- Xử lý trong reducer với case pending / fulfilled / rejected ---
        builder
            .addCase(fetchDetailById.pending, (state: any, action) => {
                state.isLoadingVBBHDetail = true
            })
            .addCase(fetchDetailById.fulfilled, (state: any, action) => {
                state.dataDetailVB = action.payload
                state.isLoadingVBBHDetail = false
            })
            .addCase(fetchDetailById.rejected, (state: any, action) => {
                state.isLoadingVBBHDetail = false
                state.dataDetailVB = {}
            })
            .addCase(fetchAttachFiles.fulfilled, (state: any, action) => {
                state.dataFiles = action.payload
            })
            .addCase(fetchAttachFiles.rejected, (state: any, action) => {
                state.dataFiles = []
            })
            .addCase(fetchThongTinLuanChuyen.fulfilled, (state: any, action) => {
                state.dataThongTinLuanChuyen = groupList(action.payload)
            })
            .addCase(fetchNguoiXem.fulfilled, (state: any, action) => {
                state.dataNguoiXem = action.payload
            })
            .addCase(fetchThongTinLuanChuyenDonViKhac.fulfilled, (state: any, action) => {
                state.dataThongTinLuanChuyenDonViKhac = action.payload
            })
        builder
            .addCase(fetchVBDaBanHanhApi.pending, (state: any, action: any) => {
                state.isLoadingVBBH = true;
                state.dataVBDaBanHanh = action.meta.arg.offset === 0 ? [] : state.dataVBDaBanHanh
            })
        builder.addCase(fetchVBDaBanHanhApi.fulfilled, (state: any, action: any) => {
            state.dataVBDaBanHanh = action.payload.offset !== 0 ? state.dataVBDaBanHanh.concat(action.payload.data) : action.payload.data;
            state.isLoadingVBBH = false;
            state.isLoadmoreVBBH = action.payload.data.length !== 0,
                state.totalRecordVbbh = action.payload?.totalRecord
        });
        builder.addCase(fetchVBDaBanHanhApi.rejected, (state: any, action) => {
            state.isLoadingVBBH = false;
        });
    },
});
export const {
    onResetVbbhDetailAction
} = vbbhSlice.actions;
const { reducer } = vbbhSlice;
export default reducer;