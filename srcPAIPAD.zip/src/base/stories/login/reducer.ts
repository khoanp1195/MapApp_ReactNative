import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { isNullOrUndefined } from "../../Functions"
import { get, post } from "../../services/ApiServices"
import { BASE_URL, RESONSE_STATUS_SUCCESS } from "../../Constants"
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Alert } from 'react-native';
import { getFcmToken } from '~/base/service/PushNotification';
interface PayloadAction {
  userName: String;
  password: String;
}

export const loginRequestApi = createAsyncThunk(
  'login/loginRequest',
  async (payload: PayloadAction) => {
    let xmls = `<?xml version="1.0" encoding="utf-8"?>\
      <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">\
      <soap:Body>\
        <Login xmlns="http://schemas.microsoft.com/sharepoint/soap/">\
          <username>${payload.userName}</username>\
          <password><![CDATA[${payload.password}]]></password>\
        </Login>\
        </soap:Body>\
</soap:Envelope>`;
    let SOAPAction = 'http://schemas.microsoft.com/sharepoint/soap/Login';
    const response = await axios.post(
      BASE_URL + "/_vti_bin/authentication.asmx",
      xmls,
      {
        headers: {
          'Content-Type': 'text/xml; charset=utf-8',
          SOAPAction: SOAPAction,
        },
      },
    );

    if (!isNullOrUndefined(response.headers["set-cookie"])) {
      return {
        token: response.headers["set-cookie"],
        username: payload.userName,
        password: payload.password
      }
    }

    return null
  },
);

export const fetchCurrentUser = createAsyncThunk(
  'home/currentUser',
  async ({ subSite, deviceInfo }: any) => {
    const res = await post(`/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=CurrentUser`, deviceInfo)
    if (!isNullOrUndefined(res)) {
      if (res.data.status.toString() === RESONSE_STATUS_SUCCESS) {
        return res.data.data
      }
    }

    return null
  }
)
export const fetchRealSite = createAsyncThunk(
  'fetchRealSite', async (accountName: any) => {
    const url = `/pa/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetRealSite`
    const data = { AccountName: accountName }
    const response = await post(url, data);
    if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
      return response.data.data
    }
  }
)

export const logOut = createAsyncThunk(
  'logOut', async ({ deviceId, subSite }: any) => {
    const res = await get(`/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=SignOut&DeviceId=${deviceId}&params=DeviceId`)
    return res
  }
)

const saveUserInfo = async (userName: any, password: any) => {
  await AsyncStorage.setItem('username', userName)
  await AsyncStorage.setItem('password', password)
}

const loginSlice = createSlice({
  name: 'login',
  initialState: {
    isLogin: false,
    isAuth: false,
    token: '',
    subSite: 'pa',
    dataCurrentUsers: [],
    isLogging: false
  },
  reducers: {
    logoutAction(state, action) {
      state.isLogin = false
      state.isAuth = false
      state.token = ''
      state.isLogging = false
    },
    setSubSite(state, action) {
      return { ...state, subSite: action.payload }
    },
    setIsLogging(state, action) {
      return { ...state, isError: action.payload }
    },
  },
  extraReducers: builder => {
    builder
      .addCase(loginRequestApi.pending, (state: any) => {
        state.isLoading = true;
        state.isLogging = true
      })
      .addCase(loginRequestApi.fulfilled, (state: any, action: any) => {
        if (!isNullOrUndefined(action.payload)) {
          state.token = action.payload.token
          saveUserInfo(action.payload?.username, action.payload?.password)
          state.isAuth = true
          state.isLogging = true;
          // getFcmToken();
        } else {
          state.isAuth = false
          state.isLogging = false;
          Alert.alert("Thông báo", 'Tài khoản hoặc mật khẩu không chính xác');
        }
      })
      .addCase(loginRequestApi.rejected, (state: any) => {
        state.isLoading = false;
        state.isLogging = false
      })
      .addCase(fetchCurrentUser.fulfilled, (state: any, action) => {
        if (!isNullOrUndefined(action.payload)) {
          state.dataCurrentUsers = action.payload
        }
      })
      .addCase(fetchRealSite.pending, (state: any) => {
        state.isLogin = false
      })
      .addCase(fetchRealSite.fulfilled, (state: any, action) => {
        if (!isNullOrUndefined(action.payload)) {
          state.subSite = action.payload[0].RealSite
          state.isLogin = true
        } else {
          state.isLogin = false
        }
      })
      .addCase(fetchRealSite.rejected, (state: any) => {
        state.isLogin = false
      });
  },
});
export const { logoutAction, setSubSite, setIsLogging } = loginSlice.actions;
const { reducer } = loginSlice;
export default reducer;
