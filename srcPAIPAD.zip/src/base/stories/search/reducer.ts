import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { arrayIsEmpty, isNullOrUndefined } from "../../Functions"
import { get, post } from "../../services/ApiServices"
import { RESONSE_STATUS_SUCCESS } from "../../Constants"
export const defaulItemTatCa = [{
  ID: 99999,
  Title: 'Tất cả',
  dummyID: 99999
}]
export const fetchDataSearch = createAsyncThunk(
  'search/fetchDataSearch', async (payload: any) => {
    const { Offset, Content, CoQuanGui, LoaiVanBan, NguoiKyVanBan, Type, TuNgay, DenNgay, SubSite } = payload;
    const data = { Content, CoQuanGui, LoaiVanBan, NguoiKyVanBan, Type, TuNgay, DenNgay }
    const res = await post(`/${SubSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=SearchVB&limit=100&offset=${Offset}`, data)
    
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data
      }
    }
  }
)
export const fetchNguoiKy = createAsyncThunk(
  'search/fetchNguoiKy',
  async (subSite: any) => {
    const VbTimKiem = await get(
      `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetSPList&listname=Người Ký Văn bản&cols=["ID","Title"]`,
    );
    return VbTimKiem?.data?.data
  },
);
export const fetchVbTimKiemLoaiVanBan = createAsyncThunk(
  'search/fetchVbTimKiemLoaiVanBan',
  async (subSite: any) => {
    const VbTimKiem = await get(
      `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetSPList&listname=Loại văn bản&cols=["ID","Title"]`,
    );
    return VbTimKiem?.data?.data
  },
);
const sortSearchDataByDate = (data: any) => {

  if (!data) return [];
  const filterData = data?.sort(
    (a: any, b: any) => new Date(b?.NgayTrenVB) - new Date(a?.NgayTrenVB)
  );
  return filterData;
}

const searchSlice = createSlice({
  name: 'search',
  initialState: {
    dataSearch: [],
    dataNguoiKy: [],
    dataLoaiVanBan: [],
    loadingSearch: false
  },
  reducers: {

  },
  extraReducers: builder => {
    builder
    .addCase(fetchDataSearch.pending, (state: any, action) => {        
      state.loadingSearch = true
    })
    .addCase(fetchDataSearch.fulfilled, (state: any, action) => {        
      state.dataSearch = sortSearchDataByDate(action.payload)
      state.loadingSearch = false
    })
      .addCase(fetchDataSearch.rejected, (state: any, action) => {        
        state.loadingSearch = false
      })
    builder.addCase(fetchNguoiKy.fulfilled, (state: any, action) => {
      state.loadingSearch = false
      state.dataNguoiKy = action.payload ? [...defaulItemTatCa, ...action.payload] : state.dataNguoiKy
    });
    builder.addCase(fetchVbTimKiemLoaiVanBan.fulfilled, (state: any, action) => {
      state.loadingSearch = false
      state.dataLoaiVanBan = action.payload ? [...defaulItemTatCa, ...action.payload] : state.dataLoaiVanBan
    });
  },
});

const { reducer } = searchSlice;
export default reducer;