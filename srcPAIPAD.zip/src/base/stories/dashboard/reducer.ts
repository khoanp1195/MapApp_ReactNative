import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { arrayIsEmpty, isNullOrUndefined } from "../../Functions"
import { get } from "../../services/ApiServices"
import { BASE_URL, RESONSE_STATUS_SUCCESS } from "../../Constants"

export const fetchCountDashboard = createAsyncThunk(
    'dashboard/fetchCountDashboard',
    async (subSite: any) => {
        const res = await get(`/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=GetCountNotify&status=0&params=Status`)

        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return res.data.data[0]
            }
        }
        return null
    },
)

export const fetchDataNewRelease = createAsyncThunk(
    'dashboard/fetchDataNewRelease',
    async (subSite: any) => {
        const res = await get(`/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=VBMoiBanHanh&status=0&Limit=1&Offset=0&IsCount=0&params=Limit,Offset,IsCount,Status`)
        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return res.data.data
            }
        }
        return null
    }
)

export const fetchDataProccessing = createAsyncThunk(
    'dashboard/fetchDataProccessing',
    async ({ subSite, offset }: any) => {
        const res = await get(`/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=HomeNotify&status=0&Limit=20&Offset=${offset}&IsCount=0&params=Limit,Offset,IsCount,Status`)
        return {
            data: res.data.data.Data,
            totalRecord: res.data.data.MoreInfo[0].totalRecord,
            offset: offset
        }
    }
)
export const deleteNotifyProcessing = createAsyncThunk(
    'home/deleteNotifyProcessing', async ({ subSite, ItemId }: any) => {
        const res = await get(`/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=DeleteNotify&rid=${ItemId}`)

        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return ItemId
            }
        }

        return null
    }
)
export const fetchDataProcessed = createAsyncThunk(
    'dashboard/fetchDataProcessed',
    async (subSite: any) => {
        const res = await get(`/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=HomeNotify&status=1&Limit=3&Offset=0&IsCount=0&params=Limit,Offset,IsCount,Status`)
        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return res.data.data.Data
            }
        }
    }
)

const dashBoardSlice = createSlice({
    name: 'dashboard',
    initialState: {
        dashboardCountData: {
            ViecCanXuLy: 0,
            ThongBao: 0,
            VanBanPhoiHop: 0
        },
        dataDocNewRelease: [],
        dataDocProcessing: [],
        dataDocProcessed: [],
        isLoading: false,
        totalRecord: 0
    },
    reducers: {

    },
    extraReducers: builder => {
        builder
            .addCase(fetchCountDashboard.fulfilled, (state: any, action) => {
                state.dashboardCountData = action.payload
            })
            .addCase(fetchDataNewRelease.fulfilled, (state: any, action) => {
                state.dataDocNewRelease = action.payload
            })
        builder.addCase(fetchDataProccessing.pending, (state, action) => {
            state.isLoading = true;
        })
            .addCase(fetchDataProccessing.fulfilled, (state: any, action: any) => {
                state.isLoading = false;
                state.totalRecord = action.payload.totalRecord
                state.dataDocProcessing = action.payload.offset > 0 ? [...state.dataDocProcessing, ...action.payload.data] : action.payload.data
            })
            .addCase(deleteNotifyProcessing.fulfilled, (state: any, action) => {
                const id = action.payload
                state.totalRecord = state.totalRecord - 1
                state.dashboardCountData.ViecCanXuLy = state.dashboardCountData?.ViecCanXuLy > 0 ? state.dashboardCountData?.ViecCanXuLy - 1 : state.dashboardCountData?.ViecCanXuLy
                state.dataDocProcessing = !isNullOrUndefined(id) ? state.dataDocProcessing.filter((it: any) => it.ID !== id) : state.dataDocProcessing
            })
            .addCase(fetchDataProcessed.fulfilled, (state: any, action) => {

                state.dataDocProcessed = action.payload
            })
    },
});

const { reducer } = dashBoardSlice;
export default reducer;