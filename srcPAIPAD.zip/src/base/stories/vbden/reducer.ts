import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { isNullOrUndefined } from "../../Functions"
import { get, post } from "../../services/ApiServices"
import { RESONSE_STATUS_SUCCESS, funtionVBDenData, } from "../../Constants"
import { factory } from 'typescript';

export const fetchDetailById = createAsyncThunk(
  'vbden/fetchDetailById', async (item: any) => {
    const res = await get(`/${item.subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=ById&rid=${item.ItemId}&actionPer=1&task=1&department=1&cmt=1`)
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data
      }
    }
  }
)

export const fetchThongtinluanchuyen = createAsyncThunk(
  'vbden/fetchThongtinluanchuyen', async (item: any) => {
    const res = await get(`/${item.subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=VBDenWorkflowHistory&ItemId=${item.ItemId}&params=ItemId`)

    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data
      }
    }
  }
)

export const fetchNguoixem = createAsyncThunk(
  'vbden/fetchNguoixem', async (item: any) => {
    const res = await get(`/${item.subSite}/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=VBDenNguoiXem&params=Limit,Offset,ItemId&ItemId=${item.ItemId}`)
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data
      }
    }
  }
)

export const submitActionShare = createAsyncThunk(
  'vbden/submitActionShare', async (payload: any) => {
    const { UserShared, Comment, ItemId, SubSite } = payload;
    const data = {
      UserShared,
      Comment
    }
    const res = await post(`/${SubSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=submit&action=64&rid=${ItemId}`, data)
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return false
      }
    }

    return true
  }
)

export const fetchTaskById = createAsyncThunk(
  'vbden/fetchTaskById', async (item: any) => {
    const res = await get(`/${item.SubSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetTaskVBDen&taskaction=ById&rid=${item.TaskId}`)
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data
      }
    }
    return null
  }
)

export const submitActionAssigment = createAsyncThunk(
  'vbden/submitActionAssigment', async (payload: any) => {
    const { SubSite, BanLanhDao, Comment, UserCC, AssignmentUser, AssignmentDept, ItemId } = payload;
    const data = {
      BanLanhDao, Comment, UserCC, AssignmentUser, AssignmentDept
    };
    const res = await post(`/${SubSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=submit&action=4&rid=${ItemId}`, data)

    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return true
      }
    }

    return false
  }
)

export const submitActionCompleted = createAsyncThunk(
  'vbden/submitActionCompleted', async (payload: any) => {
    const { SubSite, Comment, ItemId } = payload;
    const data = {
      Comment
    };
    const res = await post(`/${SubSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=submit&action=256&rid=${ItemId}`, data)
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return false
      }
    }

    return true
  }
)

export const submitActionForward = createAsyncThunk(
  'vbden/submitActionForward', async (payload: any) => {
    const { SubSite, Comment, ItemId } = payload;
    const data = {
      Comment
    };

    const res = await post(`/${SubSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=submit&action=1&rid=${ItemId}`, data)
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return false
      }
    }

    return true
  }
)

export const submitActionBOD = createAsyncThunk(
  'vbden/submitActionBOD', async (payload: any) => {
    const { ItemId, SubSite, BanLanhDao, Comment, UserCC } = payload;
    const data = {
      BanLanhDao,
      Comment,
      UserCC
    }
    const res = await post(`/${SubSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=submit&action=2&rid=${ItemId}`, data)
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return false
      }
    }

    return true
  }
)

export const submitActionReAssignment = createAsyncThunk(
  'vbden/submitActionReAssignment', async (payload: any) => {
    const {
      SubSite,
      Comment,
      deleteDept,
      BanLanhDao,
      AssignmentUser,
      ItemId,
    } = payload;

    const data = {
      Comment,
      DeleteDept: deleteDept,
      BanLanhDao,
      AssignmentUser,
    }
    const res = await post(`/${SubSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=submit&action=8&rid=${ItemId}`, data)
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return false
      }
    }

    return true
  }
)

export const submitActionForwallOrRecall = createAsyncThunk(
  'vden/submitActionForwallOrRecall', async (payload: any) => {
    const {
      SubSite,
      Comment,
      DeleteDept,
      AssignmentDept,
      ItemId,
      IsBoSung,
    } = payload;

    let data = {}
    if (IsBoSung) {
      data = {
        IsBoSung,
        Comment,
        AssignmentDept,
      }
    } else {
      data = {
        IsBoSung,
        Comment,
        DeleteDept,
      }
    }

    const res = await post(`/${SubSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=submit&action=128&rid=${ItemId}`, data)
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return false
      }
    }

    return true

  }
)

export const fetchThongtindonvinhan = createAsyncThunk(
  'vden/fetchThongtindonvinhan', async (item: any) => {
    const res = await get(`/${item.subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=WorkflowHistoryOtherDepartment&rid=${item.ItemId}`)

    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data
      }
    }
  }
)

export const fetchAttachFile = createAsyncThunk(
  'vbden/fetchAttachFile', async (item: any) => {
    const res = await get(`/${item.subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=AttachFile&rid=${item.ItemId}`)

    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data
      }
    }
  }
)

export const fetchVBDenTab = createAsyncThunk(
  'vbden/fetchVBDenTab', async (item: any) => {
    const { status, TinhTrang, BanLanhDao, FromDate, ToDate, FilterText, offset, subSite } = item

    const res = await get(`/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=${funtionVBDenData.VBDenTitle.key}&status=${status}&Limit=20&Offset=${offset}&IsCount=0&params=Limit,Offset,IsCount,Status,TinhTrang,FromDate,ToDate,BanLanhDao,FilterText&TinhTrang=${TinhTrang}&BanLanhDao=${BanLanhDao}&FromDate=${FromDate}&ToDate=${ToDate}&FilterText=${FilterText}`)

    if (isNullOrUndefined(res?.data?.data)) {
      return {
        data: [],
        offset: 0,
        totalRecord: 0,
        status
      }
    }
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return {
          data: {
            data: res.data.data.Data,
            offset: item.offset,
            totalRecord: res.data.data.MoreInfo[0].totalRecord,
            status
          }
        }
      }
    }
  }
)

export const submitActionTaskSave = createAsyncThunk(
  'vbden/submitActionTaskSave', async (payload: any) => {
    const { SubSite, TaskId, TrangThai, YKienChiDao, isNguoiGiaoViec, YKienCuaNguoiGiaiQuyet, ThoiHanGiaiQuyet, NguoiXuLy, TienDo } = payload;

    const formData = isNguoiGiaoViec ? { TrangThai, YKienChiDao, ThoiHanGiaiQuyet, NguoiXuLy } : { TrangThai, YKienCuaNguoiGiaiQuyet, TienDo }
    const res = await post(`/${SubSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetTaskVBDen&taskaction=submit&rid=${TaskId}&action=1`, formData)

    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return true
      }
    }

    return false
  }
)
export const taskVbDenPhanCongApi = createAsyncThunk(
  'taskVbDenPhanCongApi',
  async (payload: any) => {
    const { BanLanhDao, Comment, UserCC, AssignmentUser, AssignmentDept, taskID, subSite } = payload;

    const formData = {
      BanLanhDao, Comment, UserCC, AssignmentUser, AssignmentDept,
    };
    const url = `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetTaskVBDen&taskaction=submit&rid=${taskID}&action=2`
    const res = await post(url, formData)

    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return true
      }
    }
    return false
  }
);
export const submitActionTaskFeedback = createAsyncThunk(
  'vbden/submitActionTaskFeedback', async (payload: any) => {
    const { SubSite, TrangThai, YKienChiDao, TaskId, ThoiHanGiaiQuyet, NguoiXuLy, YKienCuaNguoiGiaiQuyet, TienDo, isNguoiGiaoViec } = payload;

    const formData = isNguoiGiaoViec ? { TrangThai, YKienChiDao, ThoiHanGiaiQuyet, NguoiXuLy } : { TrangThai, YKienCuaNguoiGiaiQuyet, TienDo }
    const res = await post(`/${SubSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetTaskVBDen&taskaction=submit&rid=${TaskId}&action=16`, formData)
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return true
      }
    }

    return false
  }
)
export const submitActionTaskCompleted = createAsyncThunk(
  'vbden/submitActionTaskCompleted', async (payload: any) => {
    const { SubSite, TaskId, YKienCuaNguoiGiaiQuyet } = payload;
    const data = {
      YKienCuaNguoiGiaiQuyet
    }
    const res = await post(`/${SubSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetTaskVBDen&taskaction=submit&rid=${TaskId}&action=32`, data)

    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return true
      }
    }

    return false
  }
)

export const fetchIsGroupAssignmentDept = createAsyncThunk(
  'vbden/fetchIsGroupAssignmentDept', async (subSite: any) => {
    const res = await get(`/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetTaskVBDen&taskaction=IsGroupAssignmentDept&rid=18324`)
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data
      }
    }
  }
)

export const fetchCheckUserInGroup = createAsyncThunk(
  'data/fetchCheckUserInGroup', async (item: any) => {
    const res = await get(`/${item.subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GroupName&groupname=${item.groupName}`)
    if (!isNullOrUndefined(res.data.data)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data
      }
    }
  }
)

const groupList = (data: any) => {
  let ret = []

  let itemSup = {
    title: data[0].Position,
    data: []
  }
  ret.push(itemSup)

  for (let index = 0; index < data.length; index++) {
    const r = data[index];
    if (r.Position !== itemSup.title) {
      const a = []
      a.push(r)

      itemSup = {
        title: r.Position,
        data: a
      }
      ret.push(itemSup)
    } else {
      itemSup.data.push(r)
    }
  }

  return ret
}
export const fetchDanhSachDaChiaSeVbDen = createAsyncThunk(
  'home/fetchDanhSachDaChiaSeVbDen',
  async ({ ItemId, subSite }: any) => {
    const responseDanhSachDaChiaSeVbDen = await get(
      `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=UserShared&rid=${ItemId}`,
    );
    return responseDanhSachDaChiaSeVbDen?.data?.data
  },
);
const vbdenSlice = createSlice({
  name: 'vbden',
  initialState: {
    dataDetail: {},
    dataThongTinLuanChuyen: [],
    dataNguoixem: [],
    dataThongtindonvinhan: [],
    dataFiles: [],
    isLoading: false,
    dataTask: {},
    dataVBDenTab: {
      data: [],
      totalRecord: 0,
      totalRecordVbDenTitle: 0,
    },
    IsGroupAssignmentDept: false,
    IsGroupAssignmentFull: false,
    isProcessVbdenSuccess: false,
    isProcessTaskVbdenSuccess: false,
    isRefreshShareModal: false,
    dataDanhSachDaChiaSeVbDen: [],
    isLoadingVBDenDetail: false
  },
  reducers: {
    resetVBDenScreen(state, action) {
      state.isProcessVbdenSuccess = false;
    },
    resetTaskVBDen(state, action) {
      state.isProcessTaskVbdenSuccess = false
      state.isProcessVbdenSuccess = false
    },
    resetShareModalVBDen(state, action) {
      state.isRefreshShareModal = false
    },
    onRefreshVbDenAction(state, action) {
      state.isProcessVbdenSuccess = true
    },
    onResetVbDenDetailAction(state, action) {
      state.dataTask = {}
      state.dataFiles = []
    },
    setLoadingVbDenScreen(state, action) {
      state.isLoading = true
    }

  },
  extraReducers: builder => {
    builder
      .addCase(fetchDetailById.pending, (state: any, action) => {
        state.isLoadingVBDenDetail = true
        state.dataDetail = {}
      })
      .addCase(fetchDetailById.fulfilled, (state: any, action) => {
        state.dataDetail = action.payload
        state.isLoadingVBDenDetail = false
      })
      .addCase(fetchDetailById.rejected, (state: any, action) => {
        state.isLoadingVBDenDetail = false
      })
      .addCase(fetchThongtinluanchuyen.fulfilled, (state: any, action) => {
        state.dataThongTinLuanChuyen = groupList(action.payload)
      })
      .addCase(fetchNguoixem.fulfilled, (state: any, action) => {
        state.dataNguoixem = action.payload
      })
      .addCase(fetchThongtindonvinhan.fulfilled, (state: any, action) => {
        state.dataThongtindonvinhan = action.payload
      })
      .addCase(fetchAttachFile.pending, (state: any, action) => {
        state.dataFiles = []
      })
      .addCase(fetchAttachFile.fulfilled, (state: any, action) => {
        state.dataFiles = action.payload
      })
      .addCase(fetchAttachFile.rejected, (state: any, action) => {

      })
      .addCase(submitActionShare.pending, (state: any) => {
        state.isLoading = true;
      })
      .addCase(submitActionShare.fulfilled, (state: any, action) => {
        state.isLoading = action.payload
        state.isRefreshShareModal = true
      })
      .addCase(submitActionAssigment.pending, (state: any) => {
        state.isLoading = true;
      })
      .addCase(submitActionAssigment.fulfilled, (state: any, action) => {
        state.isLoading = false
        state.isProcessVbdenSuccess = true;
      })
      .addCase(submitActionCompleted.pending, (state: any) => {
        state.isLoading = true;
        state.isProcessVbdenSuccess = false;
      })
      .addCase(submitActionCompleted.fulfilled, (state: any, action) => {
        state.isLoading = false
        state.isProcessVbdenSuccess = true;
      })
      .addCase(submitActionForward.pending, (state: any) => {
        state.isLoading = true;
        state.isProcessVbdenSuccess = false;
      })
      .addCase(submitActionForward.fulfilled, (state: any, action) => {
        state.isLoading = false
        state.isProcessVbdenSuccess = true;
      })
      .addCase(submitActionBOD.pending, (state: any) => {
        state.isLoading = true;
        state.isProcessVbdenSuccess = false;
      })
      .addCase(submitActionBOD.fulfilled, (state: any, action) => {
        state.isLoading = false
        state.isProcessVbdenSuccess = true;
      })
      .addCase(submitActionReAssignment.pending, (state: any) => {
        state.isLoading = true;
        state.isProcessVbdenSuccess = false;
      })
      .addCase(submitActionReAssignment.fulfilled, (state: any, action) => {
        state.isLoading = false
        state.isProcessVbdenSuccess = true;
      })
      .addCase(submitActionForwallOrRecall.pending, (state: any) => {
        state.isLoading = true;
        state.isProcessVbdenSuccess = false;
      })
      .addCase(submitActionForwallOrRecall.fulfilled, (state: any, action) => {
        state.isLoading = false
        state.isProcessVbdenSuccess = true;
      })
      .addCase(fetchTaskById.fulfilled, (state: any, action) => {
        state.dataTask = action.payload
      })
      .addCase(fetchVBDenTab.pending, (state: any, action) => {
        state.isLoading = true;
      })
      .addCase(fetchVBDenTab.fulfilled, (state: any, action: any) => {
        state.dataVBDenTab.data = action.payload?.data.offset > 0 ? state.dataVBDenTab.data.concat(action.payload?.data.data) : action.payload?.data.data
        state.dataVBDenTab.totalRecord = action.payload?.data.totalRecord
        state.dataVBDenTab.totalRecordVbDenTitle = action.payload?.data.status === 0 ? action.payload?.data.totalRecord : state.dataVBDenTab.totalRecordVbDenTitle
        state.isLoading = false
      })
      .addCase(fetchVBDenTab.rejected, (state: any, action) => {
        state.isLoading = false;
      })
      .addCase(fetchIsGroupAssignmentDept.fulfilled, (state: any, action) => {
        state.IsGroupAssignmentDept = action.payload
      })
      .addCase(fetchCheckUserInGroup.fulfilled, (state: any, action) => {
        state.IsGroupAssignmentFull = action.payload
      })
      .addCase(submitActionTaskCompleted.fulfilled, (state: any, action) => {
        state.isProcessVbdenSuccess = action.payload
        state.isProcessTaskVbdenSuccess = true
      })
      .addCase(submitActionTaskFeedback.fulfilled, (state: any, action) => {
        state.isProcessTaskVbdenSuccess = true
      })
      .addCase(submitActionTaskSave.fulfilled, (state: any, action) => {
        state.isProcessTaskVbdenSuccess = true
      })
      .addCase(taskVbDenPhanCongApi.fulfilled, (state: any, action) => {
        state.isProcessTaskVbdenSuccess = true
        state.isProcessVbdenSuccess = true
      })
      .addCase(fetchDanhSachDaChiaSeVbDen.fulfilled, (state: any, action) => {
        state.dataDanhSachDaChiaSeVbDen = action.payload;
      })
  },
});
export const {
  resetVBDenScreen,
  resetTaskVBDen,
  resetShareModalVBDen,
  onRefreshVbDenAction,
  onResetVbDenDetailAction,
  setLoadingVbDenScreen
} = vbdenSlice.actions;

const { reducer } = vbdenSlice;

export default reducer;