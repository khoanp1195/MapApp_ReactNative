import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { arrayIsEmpty, isNullOrUndefined } from "../../Functions"
import { get, post } from "../../services/ApiServices"
import { BASE_URL, RESONSE_STATUS_SUCCESS, funtionVBDiData } from "../../Constants"

export const fetchDetailById = createAsyncThunk(
  'vbdi/fetchDetailById', async (item: any) => {

    const res = await get(`/${item.subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&rid=${item.ItemId}&vbaction=ById&cmt=1&actionPer=1`)
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data
      }
    }
    return null
  }
)

export const fetchAttchFiles = createAsyncThunk(
  'vbdi/fetchAttchFiles', async (item: any) => {
    const res = await get(`/${item.subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&rid=${item.ItemId}&vbaction=AttachFile`)

    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data
      }
    }
    return null
  }
)

export const fetchThongTinLuanChuyen = createAsyncThunk(
  'vbdi/fetchThongTinLuanChuyen', async (item: any) => {
    const res = await get(`/${item.subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&rid=${item.ItemId}&vbaction=WorkflowHistory`)
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data
      }
    }
    return null
  }
)

export const fetchVBDiTab = createAsyncThunk(
  'vbdi/fetchVBDiTab', async (item: any) => {
    let reponseVBDi;
    const {
      status,
      TinhTrang,
      FromDate,
      ToDate,
      FilterText,
      offset,
      funtionVBDi,
      subSite
    } = item;

    if (funtionVBDi.key === 'VBDiTitle') {
      reponseVBDi = await get(
        `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=${funtionVBDi.key}&Limit=20&Offset=${offset}&IsCount=0&params=Limit,Offset,IsCount,Status,TinhTrang,FromDate,ToDate,FilterText&Status=${status}&TinhTrang=${TinhTrang}&FromDate=${FromDate}&ToDate=${ToDate}&FilterText=${FilterText}`,
      );
    } else {
      reponseVBDi = await get(
        `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&viewname=${funtionVBDi.key}&Limit=20&Offset=${offset}&TinhTrang=${TinhTrang}&FromDate=${FromDate}&ToDate=${ToDate}&FilterText=${FilterText}`,
      );

    }

    if (!isNullOrUndefined(reponseVBDi)) {
      if (reponseVBDi.data.status === RESONSE_STATUS_SUCCESS) {
        return {
          data: {
            data: reponseVBDi.data.data.Data,
            offset: item.offset,
            funtionVBDi: item.funtionVBDi,
            status,
            totalRecord: funtionVBDi.key === funtionVBDiData.VBDiTitle.key ? reponseVBDi?.data?.data?.MoreInfo[0].totalRecord : reponseVBDi?.data?.data?.totalRecord,
          }
        }
      }
    }
  }
)

const groupList = (data: any) => {
  let ret = []

  if (arrayIsEmpty(data)) return ret

  let itemSup = {
    item: data[0],
    data: []
  }

  ret.push(itemSup)

  for (let index = 0; index < data.length; index++) {
    const r = data[index];

    if (r.Action !== itemSup.item.Action) {
      const a = []
      const r1 = { ...r, isLast: false }
      a.push(r1)

      itemSup = {
        item: r1,
        data: a
      }
      ret.push(itemSup)
    } else {
      const r1 = { ...r, isLast: false }
      itemSup.data.push(r1)
    }
  }

  for (let index = 0; index < ret[ret.length - 1].data.length; index++) {
    const element = ret[ret.length - 1].data[index];
    element.isLast = true
  }
  return ret
}

export const fetchVBDiDSDaChiaSe = createAsyncThunk(
  'vbDi/fetchVBDiDSDaChiaSe',
  async ({ ItemId, subSite }: any) => {
    //7541
    const resVBDiDSDaChiaSe = await get(
      `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&vbaction=UserShared&rid=${ItemId}`,
    );
    return resVBDiDSDaChiaSe?.data?.data
  },
);
export const fetchVBDiDSNguoiBoSungThongTin = createAsyncThunk(
  'vbDi/fetchVBDiDSNguoiBoSungThongTin',
  async ({ ItemId, subSite }: any) => {
    const resVBDiDSNguoiBoSungThongTin = await get(
      `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&vbaction=UserRequestInformation&rid=${ItemId}`,
    );
    return resVBDiDSNguoiBoSungThongTin?.data?.data
  },
);
export const vbDiChiaSeApi = createAsyncThunk(
  'vbDi/vbDiChiaSeApi',
  async (payload: any) => {
    const { UserShared, Comment, ItemId, subSite } = payload;
    const data = {
      UserShared,
      Comment
    }
    const url = `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&vbaction=submit&action=256&rid=${ItemId}`
    const res = await post(url, data)
    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return true
      }
    }

  }
);
export const fetchVBDiAttachFile = createAsyncThunk(
  'vbDi/fetchVBDiAttachFile',
  async ({ ItemId, subSite }: any) => {
    const responseVBDiAttachFile = await get(
      `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&rid=${ItemId}&vbaction=AttachFile`,
    );
    return responseVBDiAttachFile?.data?.data;
  },
);
export const vbDiBoSungThongTinApi = createAsyncThunk(
  'vbDi/vbDiBoSungThongTinApi',
  async (payload: any) => {
    const { ChooseUser, Comment, ItemId, subSite } = payload;
    const formData = {
      ChooseUser,
      Comment
    }
    const url = `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&vbaction=submit&action=64&rid=${ItemId}`
    try {
      const response = await post(url, formData)

      let isRefreshVBDiScreen = false;
      if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
        isRefreshVBDiScreen = true;
      }
      return isRefreshVBDiScreen;
    } catch (error) {
      console.log('error', error);
    }

  }
);
export const vbDiYeuCauHieuChinhApi = createAsyncThunk(
  'vbDi/vbDiYeuCauHieuChinhApi',
  async (payload: any) => {
    const { UserCC, Comment, ItemId, subSite } = payload;
    const formData = {
      UserCC,
      Comment
    }
    const url = `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&vbaction=submit&action=8&rid=${ItemId}`
    try {
      const response = await post(url, formData)

      let isRefreshVBDiScreen = false;
      if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
        isRefreshVBDiScreen = true;
      }
      return isRefreshVBDiScreen;
      // return response;

    } catch (error) {
      console.log('error', error);
    }

  }
);
export const vbDiChuyenXuLyApi = createAsyncThunk(
  'vbDi/vbDiChuyenXuLyApi',
  async (payload: any) => {
    const { ChooseUser, Comment, ItemId, subSite } = payload;
    const formData = {
      ChooseUser,
      Comment
    }
    const url = `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&vbaction=submit&action=4&rid=${ItemId}`
    try {
      const response = await post(url, formData)
      let isRefreshVBDiScreen = false;
      if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
        isRefreshVBDiScreen = true;
      }
      return isRefreshVBDiScreen;
    } catch (error) {
      console.log('error', error);
    }
  }
);
export const vbDiDongYApi = createAsyncThunk(
  'vbDi/vbDiDongYApi',
  async (payload: any) => {
    const { UserCC, Comment, ItemId, subSite } = payload;
    const data = {
      UserCC,
      Comment
    }

    const url = `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&vbaction=submit&action=1&rid=${ItemId}`
    try {
      const response = await post(url, data)

      let isRefreshVBDiScreen = false;
      if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
        isRefreshVBDiScreen = true;
      }
      return isRefreshVBDiScreen;
    } catch (error) {
      console.log('error', error);
    }

  }
);
export const vbDiPheDuyetApi = createAsyncThunk(
  'vbDi/vbDiPheDuyetApi',
  async (payload: any) => {
    const { UserCC, Comment, ItemId, subSite } = payload;
    const data = {
      UserCC,
      Comment
    }
    const url = `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&vbaction=submit&action=2&rid=${ItemId}`
    try {
      const response = await post(url, data)
      let isRefreshVBDiScreen = false;
      if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
        isRefreshVBDiScreen = true;
      }
      return isRefreshVBDiScreen;
    } catch (error) {
      console.log('error', error);
    }

  }
);
export const vbDiThuHoiApi = createAsyncThunk(
  'vbDi/vbDiThuHoiApi',
  async (payload: any) => {
    const { Comment, ItemId, subSite } = payload;

    const formData = {
      Comment
    }
    const url = `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&vbaction=submit&action=32&rid=${ItemId}`

    try {
      const response = await post(url, formData)

      let isRefreshVBDiScreen = false;
      if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
        isRefreshVBDiScreen = true;
      }
      return isRefreshVBDiScreen;
    } catch (error) {
      console.log('error', error);
    }

  }
);

const vbdiSlice = createSlice({
  name: 'vbdi',
  initialState: {
    dataDetail: {},
    dataFiles: [],
    dataThongtinluanchuyenVbdi: [],
    dataVBDiTab: {
      data: [],
      totalRecord: 0,
      totalRecordVBDiTitle: 0,
      funtionVBDi: funtionVBDiData.VBDiTitle,
      sellectedDocumentID: -1
    },
    isLoadingVBDi: false,
    isRefreshVBDiScreen: false,
    isLoadMoreVbDi: true,
    dataVBDiDSDaChiaSe: [],
    isChiaSeVBDiSuccess: false,
    dataVBDiAttachFile: [],
    dataDSNguoiBosungThongtin: [],
    isThuHoiVBDiSuccess: false,
    isLoadingVBDiDetail: false,
    isRefreshVBDiState: false,
    isLoadingScrollToIndex: false
  },
  reducers: {
    resetVBDiScreen(state, action) {
      state.isRefreshVBDiScreen = false;
      state.isThuHoiVBDiSuccess = false;
    },
    onChangeFuntionVBDi(state, action) {
      state.dataVBDiTab.funtionVBDi = action.payload
      state.dataVBDiTab.data = []
      state.isLoadingVBDiDetail = true
    },
    onRefreshVbDiAction(state, action) {
      state.isRefreshVBDiState = true
    },
    setIsLoadingScrollToIndexVbdi(state, action) {
      state.isLoadingScrollToIndex = action.payload
    },
  },
  extraReducers: builder => {
    builder
      .addCase(fetchDetailById.pending, (state: any, action) => {
        state.isLoadingVBDiDetail = true
      })
      .addCase(fetchDetailById.fulfilled, (state: any, action) => {
        state.dataDetail = action.payload
        state.isLoadingVBDiDetail = false
      })
      .addCase(fetchDetailById.rejected, (state: any, action) => {
        state.isLoadingVBDiDetail = false
      })
      .addCase(fetchAttchFiles.fulfilled, (state: any, action) => {
        state.dataFiles = action.payload
      })
      .addCase(fetchThongTinLuanChuyen.fulfilled, (state: any, action) => {
        state.dataThongtinluanchuyenVbdi = groupList(action.payload)
      })
      .addCase(fetchVBDiTab.pending, (state: any, action) => {
        state.isLoadingVBDi = true;
      })
      .addCase(fetchVBDiTab.fulfilled, (state: any, action) => {
        state.dataVBDiTab.data = action.payload?.data.offset > 0 ? state.dataVBDiTab.data.concat(action.payload?.data.data) : action.payload?.data.data
        state.dataVBDiTab.totalRecord = action.payload?.data.totalRecord
        state.dataVBDiTab.totalRecordVBDiTitle = action.payload?.data.status === 0 && action.payload?.data.funtionVBDi.key === funtionVBDiData.VBDiTitle.key ? action.payload?.data.totalRecord : state.dataVBDiTab.totalRecordVBDiTitle
        state.isLoadingVBDi = false
        state.isRefreshVBDiState = false
      })
      .addCase(fetchVBDiTab.rejected, (state: any, action) => {
        state.isLoadingVBDi = false;
        state.isRefreshVBDiState = false
      })

    builder.addCase(fetchVBDiDSDaChiaSe.fulfilled, (state: any, action) => {
      state.dataVBDiDSDaChiaSe = !isNullOrUndefined(action.payload) ? action.payload : [];
    });
    builder.addCase(fetchVBDiDSNguoiBoSungThongTin.fulfilled, (state: any, action) => {
      state.dataDSNguoiBosungThongtin = action.payload;
    });

    builder.addCase(vbDiChiaSeApi.pending, (state: any, action) => {
      state.isLoadingVBDi = true;
    });
    builder.addCase(vbDiChiaSeApi.fulfilled, (state: any, action) => {
      state.isChiaSeVBDiSuccess = true;
      state.isLoadingVBDi = false
    });
    builder.addCase(vbDiChiaSeApi.rejected, (state: any, action) => {
      state.isLoadingVBDi = false;
    });

    builder.addCase(fetchVBDiAttachFile.fulfilled, (state: any, action) => {
      state.dataVBDiAttachFile = action.payload;
    });

    builder.addCase(vbDiChuyenXuLyApi.pending, (state: any, action) => {
      state.isLoadingVBDi = true;
    });

    builder.addCase(vbDiChuyenXuLyApi.fulfilled, (state: any, action) => {
      state.isRefreshVBDiScreen = true;
      state.isLoadingVBDi = false;
    });

    builder.addCase(vbDiChuyenXuLyApi.rejected, (state: any, action) => {
      state.isLoadingVBDi = false;
    });

    builder.addCase(vbDiDongYApi.pending, (state: any, action) => {
      state.isLoadingVBDi = true;
    });
    builder.addCase(vbDiDongYApi.fulfilled, (state: any, action) => {
      state.isRefreshVBDiScreen = action.payload;
      state.isLoadingVBDi = false;
    });
    builder.addCase(vbDiDongYApi.rejected, (state: any, action) => {
      state.isLoadingVBDi = false;
    });

    builder.addCase(vbDiYeuCauHieuChinhApi.pending, (state: any, action) => {
      state.isLoadingVBDi = true;
    });
    builder.addCase(vbDiYeuCauHieuChinhApi.fulfilled, (state: any, action) => {
      state.isRefreshVBDiScreen = action.payload;
      state.isLoadingVBDi = false;
    });
    builder.addCase(vbDiYeuCauHieuChinhApi.rejected, (state: any, action) => {
      state.isLoadingVBDi = false;
    });

    builder.addCase(vbDiBoSungThongTinApi.pending, (state: any, action) => {
      state.isLoadingVBDi = true;
    });
    builder.addCase(vbDiBoSungThongTinApi.fulfilled, (state: any, action) => {
      state.isRefreshVBDiScreen = action.payload;
      state.isLoadingVBDi = false;
    });
    builder.addCase(vbDiBoSungThongTinApi.rejected, (state: any, action) => {
      state.isLoadingVBDi = false;
    });

    builder.addCase(vbDiThuHoiApi.pending, (state: any, action) => {
      state.isLoadingVBDi = true;
    });
    builder.addCase(vbDiThuHoiApi.fulfilled, (state: any, action) => {
      state.isRefreshVBDiScreen = action.payload;
      state.isThuHoiVBDiSuccess = action.payload;
      state.isLoadingVBDi = false;
    });
    builder.addCase(vbDiThuHoiApi.rejected, (state: any, action) => {
      state.isLoadingVBDi = false;
    });
    builder.addCase(vbDiPheDuyetApi.pending, (state: any, action) => {
      state.isLoadingVBDi = true;
      state.isRefreshVBDiScreen = false
    });
    builder.addCase(vbDiPheDuyetApi.fulfilled, (state: any, action) => {
      state.isRefreshVBDiScreen = action.payload;
      state.isLoadingVBDi = false
    });
    builder.addCase(vbDiPheDuyetApi.rejected, (state: any, action) => {
      state.isLoadingVBDi = false;
      state.isRefreshVBDiScreen = false
    });
  },
});
export const { setIsLoadingScrollToIndexVbdi, resetVBDiScreen, onChangeFuntionVBDi, onRefreshVbDiAction } = vbdiSlice.actions;

const { reducer, } = vbdiSlice;
export default reducer;