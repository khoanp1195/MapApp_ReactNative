import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { isNullOrUndefined } from "../../Functions"
import { get } from "../../services/ApiServices"
import { RESONSE_STATUS_SUCCESS } from "../../Constants"
import { create } from 'react-test-renderer';

export const fetchUserGroup = createAsyncThunk(
    'data/fetchUserGroup', async (subSite: any) => {
        const res = await get(`/${subSite}/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=UserGroup&params=Limit,Offset,IsCount,Status,BeanName,Modified`)

        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return res.data.data
            }
        }
    }
)

export const fetchDepartment = createAsyncThunk(
    'data/fetchDepartment', async (subSite: any) => {
        const res = await get(`/${subSite}/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetSPList&listname=Đơn vị&cols=["ID","Title", "MultipleManager", "LanhDao","IsRoot","URL","Nhom","MaDonVi","Status","ParentDept","Manager"]`)

        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return res.data.data
            }
        }
    }
)

export const fetchBanLanhDao = createAsyncThunk(
    'home/fetchBanLanhDao',
    async (subSite: any) => {
        const fetchBanLanhDao = await get(
            `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetSPList&listname=Ban lãnh đạo&cols=["ID","Title","LanhDao","DonVi","Orders"]`,
        );
        return fetchBanLanhDao?.data?.data;
    },
);

export const fetchCoQuanGui = createAsyncThunk(
    'data/fetchCoQuanGui', async (subSite: any) => {
        const res = await get(`/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetSPList&listname=Cơ quan gửi&cols=["ID","Title","Parent_x003a_ID"]`)
      
        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return res.data.data
            }
        }
    }
)

export const fetchSetting = createAsyncThunk(
    'data/fetchSetting', async (subSite: any) => {
        const res = await get(`/${subSite}/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=MasterData&params=BeanName,Modified&BeanName=beansetting`)
        if (!isNullOrUndefined(res)) {
            if (res.data.status === RESONSE_STATUS_SUCCESS) {
                return res.data.data
            }
        }
    }
)
export const fetchVBDiDSNguoiBoSungThongTin = createAsyncThunk(
    'vbDi/fetchVBDiDSNguoiBoSungThongTin',
    async ({ ItemId, subSite }: any) => {
        const resVBDiDSNguoiBoSungThongTin = await get(
            `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&vbaction=UserRequestInformation&rid=${ItemId}`,
        );
        console.log('resVBDiDSNguoiBoSungThongTinresVBDiDSNguoiBoSungThongTin', resVBDiDSNguoiBoSungThongTin);

        return resVBDiDSNguoiBoSungThongTin?.data?.data
    },
);
const dataSlice = createSlice({
    name: 'data',
    initialState: {
        dataUserGroup: [],
        dataDepartment: [],
        dataBanLanhDao: [],
        dataCoQuanGui: [],
        dataSetting: [],
        dataDSNguoiBosungThongtin: [],
        remoteMessage: {},
        IsCloseModalApp: false
    },
    reducers: {
        clearData(state, action) {
            state.dataUserGroup = [],
                state.dataDepartment = [],
                state.dataBanLanhDao = [],
                state.dataCoQuanGui = [],
                state.dataSetting = []
            state.dataDSNguoiBosungThongtin = []
        },
        setRemoteMessage(state, action) {
            return { ...state, remoteMessage: action.payload }
        },
        setChangeSiteNotification(state, action) {
            return { ...state, changeSiteNotification: action.payload }
        },
        setIsCloseModalApp(state, action) {
            return { ...state, IsCloseModalApp: action.payload }
        }
    },
    extraReducers: builder => {
        builder
            .addCase(fetchUserGroup.fulfilled, (state: any, action) => {
                state.dataUserGroup = action.payload
            })
            .addCase(fetchDepartment.fulfilled, (state: any, action) => {
                state.dataDepartment = action.payload
            })
            .addCase(fetchBanLanhDao.fulfilled, (state: any, action) => {
                state.dataBanLanhDao = action.payload
            })
            .addCase(fetchCoQuanGui.fulfilled, (state: any, action) => {
                state.dataCoQuanGui = action.payload
            })
            .addCase(fetchSetting.fulfilled, (state: any, action) => {
                state.dataSetting = action.payload
            })
            .addCase(fetchVBDiDSNguoiBoSungThongTin.fulfilled, (state: any, action) => {
                state.dataDSNguoiBosungThongtin = action.payload
            })
    },
});

export const { setRemoteMessage, setChangeSiteNotification, clearData, setIsCloseModalApp } = dataSlice.actions;
const { reducer } = dataSlice;
export default reducer;