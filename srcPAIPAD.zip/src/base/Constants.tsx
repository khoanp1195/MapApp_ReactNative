import { Dimensions } from 'react-native';
const DEV_URL = "https://papetrolimex.vuthao.com"
const UAT_URL = "https://papetrolimexuat.vuthao.com"
const MIG_url = 'https://eofficeuat.petrolimexaviation.com.vn';  /// UAT MIG
const LIVE_url = 'https://eoffice.petrolimexaviation.com.vn';         // LIVE
export const BASE_URL = UAT_URL
export const RESONSE_STATUS_SUCCESS = "SUCCESS";
export const RESONSE_STATUS_NONE = "NONE";
export const RESONSE_STATUS_ERROR = "ERR";

export const windowWidth = Dimensions.get('window').width;
export const dimensWidth = (width: any) => (width * windowWidth) / 1194;
export const windowHeight = Dimensions.get('window').height;
export const dimnensHeight = (height: any) => (height * windowHeight) / 834;
export const FontSize = {
  SMALL1: dimensWidth(12),
  SMALL: dimensWidth(14),
  TEXT15: dimensWidth(15),
  MEDIUM: dimensWidth(16),
  LARGE: dimensWidth(18),
  LARGE_X: dimensWidth(20),
  LARGE_XX: dimensWidth(22),
  LARGE_XXX: dimensWidth(24),
};

export enum BarStyle {
  darkContent = 'dark-content',
  lightContent = 'light-content',
}
export const funtionVBDenData = {
  VBDenChoChoYKien: {
    key: "VBDenChoChoYKien",
    title: "Văn bản đến / Chờ cho ý kiến",
  },
  VBDenChoThucHien: {
    key: "VBDenChoThucHien",
    title: "Văn bản đến / Chờ thực hiện",
  },
  VBDenDaXuLy: {
    key: "VBDenDaXuLy",
    title: "Văn bản đến / Đã xử lý",
  },
  VBDenTatCa: {
    key: "VBDenTatCa",
    title: "Văn bản đến / Tất cả",
  },
  VBDenTitle: {
    key: "VBDenTitle",
    title: "Văn bản đến",
  },
}
export const funtionVBDiData = {
  Chopheduyet: {
    key: "Chopheduyet",
    title: "Văn bản đi / Chờ phê duyệt",
    filterTitle: "Chờ phê duyệt"
  },
  DaPheDuyet: {
    key: "DaPheDuyet",
    title: "Văn bản đi / Đã phê duyệt",
    filterTitle: "Đã phê duyệt"
  },
  TatCa: {
    key: "TatCa",
    title: "Văn bản đi / Tất cả",
    filterTitle: "Tất cả"
  },
  VBDiTitle: {
    key: "VBDiTitle",
    title: "Văn bản đi",
    filterTitle: "Tất cả"
  },
}
export const bottomTabName = {
  TrangChu: "Trang chủ",
  VanBanDen: "Văn bản đến",
  VanBanDi: "Văn bản đi",
  Tracuu: "Tra cứu"
}
export const enumDocumentType = {
  TatCa: "Tất cả",
  VanBanDen: "Văn bản đến",
  VanBanDi: "Văn bản đi",
}
export const enumTopBarTabStatus = {
  VBChoXuLy: 0,
  VBDaXuLy: 1
}
export const ACTIVE_OPACITY = 1;
export const TITLE_TAB_CHOXULY = "VB chờ xử lý";
export const TITLE_TAB_DAXULY = "VB đã xử lý";
