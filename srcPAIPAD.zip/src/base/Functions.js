import moment from "moment";
import { ExcelIcon, PDFIcon, WordBlueIcon } from "./assets/svg/index";
// import RNFetchBlob from "react-native-fetch-blob";
import { BASE_URL } from "./Constants";
import { Alert } from "react-native";

export const removeSpecialCharacters = (str) => {
  if (!str) return "";
  if (str.includes(";#")) {
    const separator = ";#";
    return str.split(separator)[1];
  } else {
    return str;
  }
};

export const removeNumbersAndHashes = (str) => {
  if (!str) return "";
  // Remove numbers
  str = str.replace(/\d+/g, "");

  // Remove '#'
  str = str.replace(/#/g, "");

  // Remove extra semicolons
  str = str.replace(/;;/g, ";");

  // Remove leading and trailing semicolons
  str = str.replace(/(^;)|(;$)/g, "");

  return str;
};

export const calculateBetweenTwoDate = (dueDate) => {
  if (!dueDate) return "";
  let date_1 = new Date(moment().format("YYYY-MM-DD"));
  let date_2 = new Date(moment(dueDate).format("YYYY-MM-DD"));
  // Calculate the time difference in milliseconds
  var timeDiff = Math.ceil(date_1.getTime() - date_2.getTime());
  // Convert the time difference from milliseconds to days
  var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
  return diffDays;
};
export const formatCreatedDate = (createdDate) => {
  if (!createdDate) return "";
  let date_1 = new Date(createdDate);
  let date_2 = new Date();
  let difference = date_2.getTime() - date_1.getTime();
  let distanceDate = Math.ceil(difference / (1000 * 3600 * 24));
  if (distanceDate === 0) {
    return date_1.getHours() + ":" + date_1.getMinutes();
  } else {
    return format_yy_mm_mm_dd_hh(date_1);
  }
};
export const format_dd_mm_yyyy_hh_mm = (date) => {
  if (isNullOrUndefined(date)) return "";
  return moment(date).format("DD/MM/YYYY HH:mm");
};
export const format_dd_mm_yy = (date) => {
  return date ? moment(date).format("DD/MM/YYYY") : "";
};
export const format_mm_dd_yy = (date) => {
  return moment(date).format("MM/DD/YYYY");
};
export const format_mm_dd_hh_yy_mm_ss = (date) => {
  return moment(date).format("MM/DD/YYYY HH:mm:ss");
};
export const format_yy_mm_mm_dd_hh = (date) => {
  return moment(date).format("HH:mm DD/MM/YYYY");
};
export const formatDate = (date, format) => {
  return moment(date).format(format);
};

export const format_yy_mm_dd = "YYYY-MM-DD";
export const arrayIsEmpty = (array) => {
  if (!Array.isArray(array)) {
    return true;
  }
  if (array.length === 0) {
    return true;
  }
  return false;
};
export const checkIsEmpty = (text) => {
  if (text?.length === 0 || text === undefined || text === null) {
    return true;
  }
  return false;
};
export function checkIsBefore(date1, date2) {
  return moment(date1).isBefore(date2);
}
export function checkIsAfter(date1, date2) {
  return moment(date1).isAfter(date2);
}
export function randomIdFunc() {
  return Math.random().toString(36).slice(2, 7);
}
export function formatDataPhongBan(data) {
  data.map((it) => {
    const tmp = { ...it, SPNhomUserId: it.SPNhomUserId };
  });
  return;
}
export function getExtension(filename) {
  var parts = filename.split(".");
  return parts[parts.length - 1];
}
export function checkTypeFiles(filename) {
  var ext = getExtension(filename);
  switch (ext.toLowerCase()) {
    case "doc":
      return <WordBlueIcon />;
    case "docx":
      return <WordBlueIcon />;
    case "xlsx":
      return <ExcelIcon />;
    case "pdf":
      return <PDFIcon />;
    case "png":
      return <WordBlueIcon />;
    case "jpg":
      return <WordBlueIcon />;
  }
  return null;
}
export function checkMimeTypeFiles(filename) {
  var ext = getExtension(filename);
  switch (ext.toLowerCase()) {
    case "doc":
      return "application/msword";
    case "dot":
      return "application/msword";
    case "docx":
      return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    case "dotx":
      return "application/vnd.openxmlformats-officedocument.wordprocessingml.template";
    case "docm":
      return "application/vnd.ms-word.document.macroEnabled.12";
    case "dotm":
      return "application/vnd.ms-word.template.macroEnabled.12";
    case "xls":
      return "application/vnd.ms-excel";
    case "xlt":
      return "application/vnd.ms-excel";
    case "xla":
      return "application/vnd.ms-excel";
    case "xlsx":
      return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    case "xltx":
      return "application/vnd.openxmlformats-officedocument.spreadsheetml.template";
    case "xlsm":
      return "application/vnd.ms-excel.sheet.macroEnabled.12";
    case "xltm":
      return "application/vnd.ms-excel.template.macroEnabled.12";
    case "xlam":
      return "application/vnd.ms-excel.addin.macroEnabled.12";
    case "xlsb":
      return "application/vnd.ms-excel.sheet.binary.macroEnabled.12";
    case "ppt":
      return "application/vnd.ms-powerpoint";
    case "pot":
      return "application/vnd.ms-powerpoint";
    case "pps":
      return "application/vnd.ms-powerpoint";
    case "ppa":
      return "application/vnd.ms-powerpoint";
    case "pptx":
      return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
    case "potx":
      return "application/vnd.openxmlformats-officedocument.presentationml.template";
    case "ppsx":
      return "application/vnd.openxmlformats-officedocument.presentationml.slideshow";
    case "ppam":
      return "application/vnd.ms-powerpoint.addin.macroEnabled.12";
    case "pptm":
      return "application/vnd.ms-powerpoint.presentation.macroEnabled.12";
    case "potm":
      return "application/vnd.ms-powerpoint.template.macroEnabled.12";
    case "ppsm":
      return "application/vnd.ms-powerpoint.slideshow.macroEnabled.12";
    case "mdb":
      return "application/vnd.ms-access";
  }
  return null;
}
export function checkTrangThai(TrangThai) {
  let custom = {
    backgroundColor: "#F0F0F0",
    color: "#626262",
  };
  switch (TrangThai) {
    case "Hoàn tất":
      return (custom = {
        backgroundColor: "#E6FFE4",
        color: "#3ABA32",
      });
    case "Đang thực hiện":
      return (custom = {
        backgroundColor: "#D1E9FF",
        color: "#015DD1",
      });
      return null;
  }
  return custom;
}

export const sortDateDecrease = (data) => {
  if (!data) return [];
  const filterData = data?.sort(
    (a, b) => new Date(b?.Modified) - new Date(a?.Modified)
  );
  return filterData;
};

export const splitID = (text) => {
  return text?.split(";")[0];
};

export const datisNullOrUndefined = (data) => {
  return data === null || data === "" || data === undefined;
};

export const isNullOrEmpty = (text) => {
  return text === null || text === "";
};

export const checkNotNullAndEmpty = (text) => {
  if (text?.length !== 0 && text !== null) {
    return true;
  }
  return false;
};
export const convertDataPhongBan = (danhSachPhongBan, item) => {
  let newItem = {
    ...item,
    children: [],
  };
  const filterData = danhSachPhongBan.filter(
    (it) => checkNotNullAndEmpty(it?.ID) && splitID(it?.ParentDept) == item?.ID
  );
  if (filterData?.length > 0) {
    filterData.forEach((it) => {
      newItem.children.push(it);
      item.children.map((itc) => {
        it = this.convertDataPhongBan(danhSachPhongBan, itc);
      });
    });
  }
  return newItem;
};

export function byteConverter(bytes, decimals, only) {
  const K_UNIT = 1024;
  const SIZES = ["Bytes", "KB", "MB", "GB", "TB", "PB"];

  if (bytes == 0) return "0 Byte";

  if (only === "MB")
    return (bytes / (K_UNIT * K_UNIT)).toFixed(decimals) + " MB";

  let i = Math.floor(Math.log(bytes) / Math.log(K_UNIT));
  let resp =
    parseFloat((bytes / Math.pow(K_UNIT, i)).toFixed(decimals)) +
    " " +
    SIZES[i];

  return resp;
}

export const DownloadFile = (value, token) => {
  const replaceTitle = value?.Title.replaceAll(" ", "_");
  const { fs, config } = RNFetchBlob;
  const { dirs } = RNFetchBlob.fs;
  const typeFile = getExtension(value?.Url);
  const date = new Date();
  const localPath = `${dirs.DocumentDir}/${Math.floor(
    date.getTime() + date.getSeconds() / 2
  )}_${replaceTitle}`;

  const options = {
    fileCache: true,
    title: `${replaceTitle}`,
    path: localPath, // Replace with the desired download destination and filename
    appendExt: typeFile,
  };
  const configOptions = Platform.select({
    ios: {
      fileCache: options.fileCache,
      title: options.title,
      path: options.path,
      appendExt: typeFile,
    },
    android: options,
  });
  config(configOptions)
    .fetch("GET", encodeURI(BASE_URL + value?.Url), {
      Authorization: `${token}`,
      "Content-Type": "multipart/form-data",
    })
    .then((res) => {
      RNFetchBlob.fs.writeFile(options.path, res.data, "base64");
      RNFetchBlob.ios.previewDocument(options.path);
    })
    .catch((error) => {
      Alert.alert("Thông báo", "Đã có lỗi xảy ra. Vui lòng thử lại", [
        { text: "Đóng" },
      ]);
    });
};

export const VersionCompare = (version1, version2) => {
  var regExStrip0 = /(\.0+)+$/;
  var segmentsA = version1.replace(regExStrip0, "").split(".");
  var segmentsB = version2.replace(regExStrip0, "").split(".");

  if (segmentsA > segmentsB) {
    return 1;
  } else if (segmentsA < segmentsB) {
    return -1;
  } else {
    return 0;
  }
};
export const sortedStringByID = (data) => {
  const numberArray = data.split(",").map(Number); // Chuyển chuỗi thành mảng số
  numberArray.sort((a, b) => a - b); // Sắp xếp mảng số

  const sortedString = numberArray.join(",");
  return sortedString;
};
export const removeAccent = (str) => {
  var from =
      "àáãảạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệđùúủũụưừứửữựòóỏõọôồốổỗộơờớởỡợìíỉĩịäëïîöüûñçýỳỹỵỷ",
    to =
      "aaaaaaaaaaaaaaaaaeeeeeeeeeeeduuuuuuuuuuuoooooooooooooooooiiiiiaeiiouuncyyyyy";
  for (var i = 0, l = from.length; i < l; i++) {
    str = str.replace(RegExp(from[i], "gi"), to[i]);
  }

  str = str.toLowerCase().trim();
  // .replace(/[^a-z0-9\-]/g, "-")
  // .replace(/-+/g, "-");

  return str;
};
