import * as React from 'react';
import Svg, {Path} from 'react-native-svg';

function SvgComponent(props) {
  return (
    <Svg
      width={19}
      height={18}
      viewBox="0 0 19 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}>
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M17.375 14.063V8.436H18.5v5.626A3.938 3.938 0 0114.562 18H4.438A3.938 3.938 0 01.5 14.062V3.938A3.938 3.938 0 014.438 0h5.625v1.125H4.436a2.812 2.812 0 00-2.812 2.813v10.124a2.812 2.812 0 002.813 2.813h10.125a2.813 2.813 0 002.812-2.813zM4.038 8.274l.799-.798 3.538 3.543 8.6-8.606.794.799-9 9a.562.562 0 01-.793 0L4.038 8.274z"
        fill="#5E5E5E"
      />
    </Svg>
  );
}

export default SvgComponent;
