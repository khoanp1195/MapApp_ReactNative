import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
  return (
    <Svg
      width={22}
      height={22}
      viewBox="0 0 19 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M2.341 0h13.323a2.342 2.342 0 012.342 2.341V15.61a2.342 2.342 0 01-2.342 2.341H2.341A2.341 2.341 0 010 15.61V2.34A2.341 2.341 0 012.341 0zm13.323 17.108c.862 0 1.561-.699 1.561-1.56V2.278c0-.862-.699-1.561-1.56-1.561H2.34c-.862 0-1.56.699-1.56 1.561v13.268c0 .862.698 1.561 1.56 1.561h13.323z"
        fill="#7B7B7B"
      />
    </Svg>
  )
}

export default SvgComponent
