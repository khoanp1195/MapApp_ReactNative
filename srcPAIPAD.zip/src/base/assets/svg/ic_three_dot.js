import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
  const {color = '#0072C6' } = props
  return (
    <Svg
      width={24}
      height={6}
      viewBox="0 0 18 5"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M2.25 4.5a2.25 2.25 0 110-4.5 2.25 2.25 0 010 4.5zm4.5-2.25a2.25 2.25 0 104.5 0 2.25 2.25 0 00-4.5 0zm6.75 0a2.25 2.25 0 104.5 0 2.25 2.25 0 00-4.5 0z"
        fill= {color}
      />
    </Svg>
  )
}

export default SvgComponent
