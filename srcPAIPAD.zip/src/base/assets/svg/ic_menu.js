import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
    const { color = '#0072C6' } = props
  return (
    <Svg
      width={28}
      height={20}
      viewBox="0 0 18 14"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M17 2H1c-.6 0-1-.4-1-1s.4-1 1-1h16c.6 0 1 .4 1 1s-.4 1-1 1zm0 6H7c-.6 0-1-.4-1-1s.4-1 1-1h10c.6 0 1 .4 1 1s-.4 1-1 1zM3 14h14c.6 0 1-.4 1-1s-.4-1-1-1H3c-.6 0-1 .4-1 1s.4 1 1 1z"
        fill={color}
      />
    </Svg>
  )
}

export default SvgComponent
