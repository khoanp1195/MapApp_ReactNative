import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
  return (
    <Svg
      width={10}
      height={18}
      viewBox="0 0 10 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        d="M9.789 8.506L1.225.204A.733.733 0 00.21.205a.684.684 0 00.001.987L8.266 9 .21 16.808a.684.684 0 00-.002.987c.14.137.325.205.509.205a.726.726 0 00.507-.204l8.564-8.302a.687.687 0 000-.988z"
        fill="#025FDA"
      />
    </Svg>
  )
}

export default SvgComponent
