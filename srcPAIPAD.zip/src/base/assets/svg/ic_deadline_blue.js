import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  const { color = "#005FD4" } = props;
  return (
    <Svg
      width={20}
      height={20}
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M10 0C4.486 0 0 4.486 0 10s4.486 10 10 10 10-4.486 10-10S15.514 0 10 0zm0 19.13C4.965 19.13.87 15.035.87 10 .87 4.965 4.965.87 10 .87c5.035 0 9.13 4.095 9.13 9.13 0 5.035-4.095 9.13-9.13 9.13zm.435-9.31l3.786 3.786a.435.435 0 01-.616.615l-3.913-3.913A.438.438 0 019.565 10V3.043a.435.435 0 01.87 0V9.82z"
        fill={color}
      />
    </Svg>
  );
}

export default SvgComponent;
