import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
  return (
    <Svg
      width={30}
      height={30}
      viewBox="0 0 23 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        d="M20.838.233L7.4 14.083l-6.084-6.27a.754.754 0 00-1.09 0c-.3.31-.3.813 0 1.123l6.63 6.832a.757.757 0 001.09 0L21.927 1.356c.301-.31.301-.813 0-1.123a.754.754 0 00-1.09 0z"
        fill="#005FD4"
      />
    </Svg>
  )
}

export default SvgComponent