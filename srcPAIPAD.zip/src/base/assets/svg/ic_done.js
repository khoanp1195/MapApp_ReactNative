import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
  return (
    <Svg
      width={18}
      height={13}
      viewBox="0 0 18 13"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        d="M16.931.189L6.011 11.443 1.07 6.348a.613.613 0 00-.886 0 .66.66 0 000 .913l5.386 5.55a.615.615 0 00.886 0l11.362-11.71a.66.66 0 000-.912.613.613 0 00-.886 0z"
        fill="#fff"
      />
    </Svg>
  )
}

export default SvgComponent