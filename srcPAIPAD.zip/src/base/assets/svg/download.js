import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
  const { color } = props
  return (
    <Svg
      width={22}
      height={22}
      viewBox="0 0 18 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M9 18c-4.963 0-9-4.037-9-9s4.037-9 9-9 9 4.037 9 9-4.037 9-9 9zM9 .75C4.451.75.75 4.451.75 9c0 4.549 3.701 8.25 8.25 8.25 4.549 0 8.25-3.701 8.25-8.25C17.25 4.451 13.549.75 9 .75zM4.5 13.125c0 .207.168.375.375.375h8.25a.375.375 0 000-.75h-8.25a.375.375 0 00-.375.375zm4.875-2.405V4.125a.375.375 0 00-.75 0v6.595L6.64 8.735a.375.375 0 00-.53.53l2.625 2.625a.376.376 0 00.53 0l2.625-2.625a.375.375 0 00-.53-.53L9.375 10.72z"
        fill= {color ? color : "#fff"}
      />
    </Svg>
  )
}

export default SvgComponent
