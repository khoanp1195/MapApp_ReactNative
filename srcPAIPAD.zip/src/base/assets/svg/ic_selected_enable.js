import * as React from "react"
import Svg, { Rect } from "react-native-svg"

function SvgComponent(props) {
  return (
    <Svg
      width={22}
      height={22}
      viewBox="0 0 18 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Rect
        x={0.5}
        y={0.5}
        width={17}
        height={17}
        rx={8.5}
        fill="#fff"
        stroke="#015DD1"
      />
      <Rect
        x={3.375}
        y={3.375}
        width={11.25}
        height={11.25}
        rx={5.625}
        fill="#015DD1"
      />
    </Svg>
  )
}

export default SvgComponent
