import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
    return (
        <Svg
            width={22}
            height={22}
            viewBox="0 0 20 20"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            {...props}
        >
            <Path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M.172 19.828a.59.59 0 00.832 0L10 10.832l8.996 8.995a.59.59 0 00.831 0 .589.589 0 000-.831L10.831 10l8.996-8.996a.589.589 0 00-.831-.832L10 9.168 1.004.172a.589.589 0 00-.832.832L9.168 10 .172 18.996a.589.589 0 000 .832z"
                fill="#000"
            />
        </Svg>
    )
}

export default SvgComponent
