import React, { FC, useMemo, useCallback } from "react";
import {
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Image,
} from "react-native";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import { useSelector } from "react-redux";
import { RootState } from "stores";
import { useNavigation } from "@react-navigation/native";
import { format_dd_mm_yy } from "helpers/formater";
import {
  FowardProcesscon,
  TransferProcessIcon,
  ShareBlueIcon,
  AddRemoveIcon,
  ReAssignIcon,
  AssignGreenIcon,
  KetThucIcon,
} from "assets/SVG/index";
import { ActionJsonType } from "../VBDenType";
import {
  SafeAreaProvider,
  SafeAreaView,
  useSafeAreaInsets,
} from "react-native-safe-area-context";
interface Props {
  modalVisible: Boolean;
  onCloseModal: () => void;
  onChooseonActionMorePress: (ID: number) => void;
  ActionJson: any;
}
const FilterModal: FC<Props> = ({
  modalVisible,
  onCloseModal,
  onChooseonActionMorePress,
  ActionJson,
  ...props
}: Props) => {
  const IconView = ({ ID }: any) => {
    if (ID === ActionJsonType.ChuyenPhanCong)
      return <TransferProcessIcon color={colors.green} />;
    if (ID === ActionJsonType.ChuyenXuLy)
      return <FowardProcesscon color={colors.green} />;
    if (ID === ActionJsonType.PhanCong)
      return <AssignGreenIcon color={colors.green} />;
    if (ID === ActionJsonType.PhanCongLai)
      return <ReAssignIcon color={colors.green} />;
    if (ID === ActionJsonType.ChiaSe)
      return <ShareBlueIcon color={"#0091FF"} dimens={20} />;
    if (ID === ActionJsonType.BoSungThuHoi)
      return <AddRemoveIcon color={colors.green} />;
    if (ID === ActionJsonType.KetThuc)
      return <KetThucIcon color={colors.green} />;
    return <View />;
  };
  const ItemAction = ({ item, index, onChooseonActionMorePress }: any) => {
    if (index <= 1) return null;
    const { Title, ID } = item;
    // if(Title === 'Chia sẻ') return ShareBlueIcon
    
    return (
      <View style={styles.chooseTypeView}>
        <TouchableOpacity
          style={styles.flexDirection}
          onPress={() => onChooseonActionMorePress(ID)}
        >
          <IconView ID={ID} />
          <Text style={styles.textType} numberOfLines={1}>
            {Title}
          </Text>
        </TouchableOpacity>
        {ActionJson.length !== index + 1 && <View style={styles.stroke} />}
      </View>
    );
  };
  const insets = useSafeAreaInsets();
  return (
    <Modal
      transparent={true}
      visible={modalVisible}
      {...props}
      style={styles.centeredView}
    >
      <View style={styles.centeredView}>
      <View style={[styles.modalView,{marginBottom: insets.bottom}]}>
          {/* coppy header */}

          <View style={styles.chooseTypeView}>
            {ActionJson &&
              ActionJson.map((item: any, index: any) => {
                return (
                  <ItemAction
                    key={index}
                    item={item}
                    index={index}
                    onChooseonActionMorePress={onChooseonActionMorePress}
                  />
                );
              })}
          </View>
          <TouchableOpacity
            activeOpacity={1}
            style={styles.viewTabBottomBar}
            onPress={onCloseModal}
          >
            <Text style={styles.tabBarLabelActive} numberOfLines={1}>
              {"Thoát"}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "flex-end",
  },
  modalView: {
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    opacity: 1,
    marginHorizontal: 15,
  },
  chooseTypeView: {
    marginBottom: 15,
    backgroundColor: colors.white,
    borderRadius: 8,
  },
  flexDirection: {
    height: 67,
    flexDirection: "row",
    paddingHorizontal: 20,
    alignItems: "center",
  },
  stroke: {
    borderWidth: 0.5,
    borderColor: "#999",
    borderStyle: "dashed",
  },
  textType: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 9,
  },
  tabBarLabelActive: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.LARGE,
  },
  viewTabBottomBar: {
    flexDirection: "row",
    height: dimensWidth(66),
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.blueMedium,
    borderRadius: 8,
  },
});

export default FilterModal;
