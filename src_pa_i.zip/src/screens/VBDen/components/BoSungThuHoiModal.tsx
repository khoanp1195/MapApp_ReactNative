import React, { FC, useState, useCallback, useEffect } from "react";
import {
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Animated,
  Alert,
  ScrollView,
  FlatList
} from "react-native";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import { MemberIcon, DeleteRedIcon, DueDateBlueIcon } from "assets/SVG/index";
import {
  arrayIsEmpty,
  format_dd_mm_yy,
  checkIsEmpty,
  removeSpecialCharacters,
  checkTrangThai,
  format_dd_mm_yyyy_hh_mm,
} from "helpers/formater";
import TextInputCustom from "components/TextInputCustom";
import { SwipeListView } from "react-native-swipe-list-view";
import {
  SafeAreaProvider,
  SafeAreaView,
  useSafeAreaInsets,
} from "react-native-safe-area-context";
import { EnumPhancong } from "../VBDenType";
import FastImage from "react-native-fast-image";
import { BaseUrl } from "~/services/api";
import { useDispatch, useSelector } from "react-redux";
interface Props {
  modalVisible: Boolean;
  onCloseBoSungThuHoiModal: () => void;
  onChooseToChucPhanCong: () => void;
  onConfirmModalBoSung: (comment: string, IsBoSung: boolean) => void;
  onConfirmModalThuHoi: (
    comment: string,
    IsBoSung: boolean,
    deleteDeptList: string
  ) => void;
  handleToggleDeleteToChucPhanCong: (itemId: number) => void;
  handleToggleDeleteTaskJsonDetail: (itemId: number) => void;
  handleChooseDueDate: (
    itemId: number,
    DueDate: string,
    typeModal: EnumPhancong
  ) => void;
  filteredDanhSachTochucPhanCong: any[];
  DonViXuLyJson: any[];
  DocumentID: any;
  CommentJson: any[];
  ykienlanhdao: any
}
const FilterModal: FC<Props> = ({
  modalVisible,
  onCloseBoSungThuHoiModal,
  onChooseToChucPhanCong,
  handleToggleDeleteToChucPhanCong,
  handleToggleDeleteTaskJsonDetail,
  handleChooseDueDate,
  filteredDanhSachTochucPhanCong,
  DonViXuLyJson,
  DocumentID,
  ykienlanhdao,
  CommentJson,
  onConfirmModalBoSung,
  onConfirmModalThuHoi,
  ...props
}: Props) => {
  const [tabName, setTabName] = useState("Bổ sung");
  const [comment, setComment] = useState("");
  const [yKienThuHoi, setYKienThuHoi] = useState("");
  const [DonViXuLyJsonState, setDonViXuLyJsonState] = useState<any>([]);
  const [deleteDeptList, setDeleteDeptList] = useState("");
  const { subSite, token } = useSelector(
    (state: any) => state.login
  );
  
  const onChangeComment = useCallback((text: string) => {
    setComment(text);
  }, []);
  const onChangeYKienThuHoi = useCallback((text: string) => {
    setYKienThuHoi(text);
  }, []);
  const onPressProcessedDocx = useCallback(() => {
    setTabName("Thu hồi");
  }, []);
  const onPressWaitProcesseDocx = useCallback(() => {
    setTabName("Bổ sung");
  }, []);
  const onConfirm = useCallback(() => {
    const IsBoSung = tabName === "Bổ sung";
    if (IsBoSung) {
      onConfirmModalBoSung(comment, IsBoSung);
    } else {
      onConfirmModalThuHoi(yKienThuHoi, IsBoSung, deleteDeptList);
    }
  }, [comment, yKienThuHoi, tabName, deleteDeptList,filteredDanhSachTochucPhanCong]);

  useEffect(() => {
    if (!arrayIsEmpty(DonViXuLyJson)) {
      setDonViXuLyJsonState(DonViXuLyJson);
      setYKienThuHoi("");
      setComment("");
      setTabName("Bổ sung");
    }
  }, [DonViXuLyJson]);
  
  useEffect(() => {
    setComment(ykienlanhdao)
    setYKienThuHoi(ykienlanhdao)
  }, [ykienlanhdao])
  
  const ItemToChucPhanCong = ({ item, index }) => {
    const { Title, ParentDept, Created, DueDate } = item;
    const DueDateFormated = checkIsEmpty(DueDate)
      ? DueDate
      : format_dd_mm_yy(DueDate);
    let isOdd = index % 2 === 0;

    return (
      <Animated.View
        style={[
          styles.itemPhongBanChild,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
      >
        <View style={styles.flexDirectionRowBetween}>
          <Text style={styles.title} numberOfLines={1}>
            {Title}
          </Text>
          <Text style={styles.blueText} numberOfLines={1}>
            {DueDateFormated}
          </Text>
        </View>
        <Text style={styles.blueText} numberOfLines={1}>
          {removeSpecialCharacters(ParentDept)}
        </Text>
      </Animated.View>
    );
  };
  const ItemVBDenDonVi = ({ item, index }: any) => {
    const { DepartmentName, TrangThai, VBId, Position, Created } = item;
    const isOdd = index % 2 === 0;
    const customColor = checkTrangThai(TrangThai);
    const createdFormated = format_dd_mm_yy(Created);

    return (
      <View
        style={[
          styles.donViItemView,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
      >
        <View
          style={[styles.flexDirectionRowBetween, {  }]}
        >
            <Text style={styles.textTrichYeu} numberOfLines={1}>
              {DepartmentName}
            </Text>

              <Text
                style={[styles.positionComment,]}
                numberOfLines={1}
              >
                {createdFormated}
              </Text>
          </View>
        <Text
                style={[styles.positionComment,]}
                numberOfLines={1}
              >
                {'Đơn vị thành viên'}
              </Text>
      </View>
    );
  };
  const onConfirmDeleteToChucPhanCong = useCallback((ID: any) => {
    Alert.alert("Thông báo", "Bạn thực sự muốn xóa?", [
      {
        text: "Cancel",
        style: "cancel",
      },
      { text: "OK", onPress: () => handleToggleDeleteToChucPhanCong(ID) },
    ]);
  }, []);
  const onConfirmDeleteDSDonVi = useCallback((selectedItem: any) => {
    Alert.alert("Thông báo", "Bạn thực sự muốn xóa?", [
      {
        text: "Cancel",
        style: "cancel",
      },
      { text: "OK", onPress: () => handleDeleteDonVi(selectedItem) },
    ]);
  }, []);
  const handleDeleteDonVi = useCallback(
    (selectedItem: any) => {
      setDonViXuLyJsonState((prevData: any) => {
        const newState = prevData.filter(
          (it) => it?.DepartmentId !== selectedItem?.DepartmentId
        );
        return newState;
      });
      setDeleteDeptList((prevData: any) => {
        const newString =
          prevData +
          selectedItem?.ID +
          ";#" +
          selectedItem?.DepartmentId +
          ";#" +
          selectedItem?.DepartmentName +
          ";#" +
          selectedItem?.DepartmentUrl +
          "|";
        return newString;
      });
    },
    [DonViXuLyJsonState, deleteDeptList]
  );
  const insets = useSafeAreaInsets();

  const ItemVBDenCommentJson = ({ item, index, token, subSite }: any) => {
    const { Title, Value, UpdateFields, Position, Created,ImagePath } = item;
    const createdFormated = format_dd_mm_yyyy_hh_mm(Created);
    const isOdd = index % 2 === 0;
    return (
      <View
        style={[
          styles.danhMucItemView,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
      >
        <FastImage
            style={styles.itemAvatar}
            source={{
              uri: BaseUrl + `/${subSite}` + ImagePath,
              headers: { Authorization: `${token}` },
              priority: FastImage.priority.normal,
            }}
          />
          <View style={styles.flexOne}>
            <View style={styles.flexDirectionRowBetween}>
              <Text style={styles.titleCommentJson} numberOfLines={1}>
                {Title}
              </Text>
              <Text style={styles.positionComment} numberOfLines={1}>
                {createdFormated}
              </Text>
            </View>
            <Text style={styles.positionComment} numberOfLines={1}>
              {removeSpecialCharacters(Position)}
            </Text>
            <View style={styles.flexDirectionRow}>
              <Text style={styles.titleCommentJson} numberOfLines={2}>
                {Value}
              </Text>
            </View>
        </View>
      </View>
    );
  };
  
  return (
    <Modal
      transparent={true}
      visible={modalVisible}
      {...props}
      style={styles.centeredView}
    >
      <View style={styles.centeredView}>
        <View
          style={[
            styles.modalView,
            {
              flex: 1,
              paddingBottom: insets.bottom,
              marginTop: 55 + insets.top,
            },
          ]}
        >
          {/* coppy header */}
          <View style={styles.viewAssign}>
            <Text style={styles.textAssign}>Bổ sung / Thu hồi </Text>
          </View>
          <View style={styles.flexDirectionRowTab}>
            <TouchableOpacity
              activeOpacity={1}
              onPress={onPressWaitProcesseDocx}
              style={
                tabName === "Bổ sung"
                  ? styles.onPressActiveTab
                  : styles.onPressInActiveTab
              }
            >
              <Text
                style={
                  tabName === "Bổ sung"
                    ? styles.titleActiveTab
                    : styles.titleInActiveTab
                }
              >
                Bổ sung
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              activeOpacity={1}
              onPress={onPressProcessedDocx}
              style={
                tabName === "Thu hồi"
                  ? styles.onPressActiveTab
                  : styles.onPressInActiveTab
              }
            >
              <Text
                style={
                  tabName === "Thu hồi"
                    ? styles.titleActiveTab
                    : styles.titleInActiveTab
                }
              >
                Thu hồi
              </Text>
            </TouchableOpacity>
          </View>
          <ScrollView contentContainerStyle={{flexGrow: 1, paddingBottom: 20}}>
            <Text style={styles.textType}>Ý kiến lãnh đạo</Text>
            <TextInputCustom
              placeholder="Vui lòng nhập ý kiến"
              placeholderTextColor={colors.grey999}
              multiline
              onChangeText={(text) =>
                tabName === "Bổ sung"
                  ? onChangeComment(text)
                  : onChangeYKienThuHoi(text)
              }
              value={tabName === "Bổ sung" ? comment : yKienThuHoi}
              style={styles.commentInput}
            />
            {!arrayIsEmpty(CommentJson) && (
              <FlatList
                style={styles.commentJsonFlatlist}
                extraData={CommentJson}
                keyExtractor={(item, index) => index.toString()}
                data={CommentJson}
                renderItem={({ item, index }) => (
                  <ItemVBDenCommentJson item={item} index={index} token={token} subSite={subSite} />
                )}
              />
            )}
            {tabName === "Bổ sung" ? (
              <>
                <Text style={styles.titleBoss}>
                  Tổ chức phân công thực hiện
                </Text>
                <View style={styles.chooseTypeView}>
                  <Text style={styles.textChooseType}>
                    {"Vui lòng bấm vào nút để chọn Chi nhánh trực thuộc"}
                  </Text>
                  <TouchableOpacity
                    style={styles.buttonPhongBan}
                    onPress={onChooseToChucPhanCong}
                  >
                    <MemberIcon />
                    <Text style={styles.textPhongBan} numberOfLines={1}>
                    Chi nhánh trực thuộc
                    </Text>
                  </TouchableOpacity>
                </View>
                {!arrayIsEmpty(filteredDanhSachTochucPhanCong) && (
                  <View style={[styles.flatlist]}>
                    <SwipeListView
                      extraData={filteredDanhSachTochucPhanCong}
                      data={filteredDanhSachTochucPhanCong}
                      renderItem={({ item, index }) =>
                        ItemToChucPhanCong({ item, index })
                      }
                      renderHiddenItem={(data, rowMap) => {
                        return (
                          <View style={styles.rowBack}>
                            <TouchableOpacity
                              style={styles.iconChange}
                              onPress={() => {
                                handleChooseDueDate(
                                  data?.item?.ID,
                                  data?.item?.DueDate,
                                  EnumPhancong.BoSungThuHoi
                                );
                              }}
                            >
                              <DueDateBlueIcon />
                            </TouchableOpacity>
                            <TouchableOpacity
                              style={styles.iconDelete}
                              onPress={() =>
                                onConfirmDeleteToChucPhanCong(data?.item?.ID)
                              }
                            >
                              <DeleteRedIcon />
                            </TouchableOpacity>
                          </View>
                        );
                      }}
                      keyExtractor={(item, index) => item.ID}
                      rightOpenValue={-75}
                      disableRightSwipe
                    />
                  </View>
                )}
              </>
            ) : (
              <>
                {!arrayIsEmpty(DonViXuLyJsonState) && (
                  <Text style={styles.titleBoss}>
                    Công ty, các đơn vị thành viên
                  </Text>
                )}
                {!arrayIsEmpty(DonViXuLyJsonState) && (
                  <View style={[styles.flatlist, { marginTop: 20 }]}>
                    <SwipeListView
                      extraData={DonViXuLyJsonState}
                      data={DonViXuLyJsonState}
                      renderItem={({ item, index }) =>
                        ItemVBDenDonVi({ item, index })
                      }
                      renderHiddenItem={(data, rowMap) => {
                        if (tabName === "Bổ sung") return null;
                        return (
                          <View style={styles.rowBackDonVi}>
                            <TouchableOpacity
                              style={styles.iconDeleteDonVi}
                              onPress={() => onConfirmDeleteDSDonVi(data?.item)}
                            >
                              <DeleteRedIcon />
                            </TouchableOpacity>
                          </View>
                        );
                      }}
                      keyExtractor={(item, index) => item?.DepartmentId}
                      rightOpenValue={-dimensWidth(45)}
                      disableRightSwipe
                    />
                  </View>
                )}
              </>
            )}
                      <View style={styles.viewTabBottomBar}>
            <TouchableOpacity
              style={styles.buttonExit}
              onPress={onCloseBoSungThuHoiModal}
            >
              <Text style={styles.buttonExitText} numberOfLines={1}>
                Thoát
              </Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.buttonTransfer} onPress={onConfirm}>
              <Text style={styles.tabBarLabelActive} numberOfLines={1}>
                {tabName}
              </Text>
            </TouchableOpacity>
          </View>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "flex-end",
  },
  modalView: {
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    opacity: 1,
    backgroundColor: colors.white,
    borderTopEndRadius: 12,
    borderTopStartRadius: 12,
    overflow: "hidden",
  },
  chooseTypeView: {
    height: 100,
    borderWidth: 1,
    borderColor: "#005FD4",
    borderStyle: "dashed",
    marginBottom: 15,
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
    marginHorizontal: 15,
    marginTop: 10,
  },
  flexDirection: {
    // height: 67,
    flexDirection: "row",
    paddingHorizontal: 20,
    alignItems: "center",
  },
  stroke: {
    borderWidth: 0.5,
    borderColor: "#999999",
    borderStyle: "dashed",
  },
  textType: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginVertical: 10,
  },
  tabBarLabelActive: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
  },
  textPhongBan: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
    marginLeft: 5,
  },
  viewTabBottomBar: {
    flexDirection: "row",
    // height: dimensWidth(66),
    borderRadius: 8,
    justifyContent: "flex-end",
    marginTop: 20
  },
  buttonTransfer: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.blueMedium,
    width: dimensWidth(130),
    height: dimensWidth(34),
    borderRadius: 4,
    marginEnd: 15,
  },
  buttonPhongBan: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.blueMedium,
    height: 34,
    borderRadius: 4,
    marginTop: 10,
    paddingHorizontal: 20,
  },
  buttonExit: {
    alignItems: "center",
    justifyContent: "center",
    width: dimensWidth(130),
    height: dimensWidth(34),
    borderRadius: 4,
  },
  buttonExitText: {
    color: colors.red,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
  },
  textAssign: {
    color: colors.blueMedium,
    fontWeight: "700",
    fontSize: FontSize.LARGE,
  },
  viewAssign: {
    backgroundColor: colors.lightBlue,
    padding: 15,
  },
  titleBoss: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginHorizontal: 15,
  },
  commentInput: {
    paddingHorizontal: 10,
    borderColor: colors.greyDDD,
    borderRadius: 3,
    height: dimensWidth(100),
    borderWidth: 1,
    marginHorizontal: 15,
    marginBottom: 10,
    textAlignVertical: "top",
  },
  typeChild: {
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "center",
    // height: 34,
    // borderColor: colors.greyDDD,
    // borderWidth: 1,
    // borderRadius: 3,
    marginHorizontal: 15,
    justifyContent: "space-between",
  },
  textFiltedType: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 9,
  },
  textChooseType: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 9,
    marginHorizontal: 10,
  },
  onPressActiveTab: {
    flex: 1,
    paddingHorizontal: 12,
    borderBottomColor: colors.primary,
    borderBottomWidth: 3,
    borderRadius: 3,
    height: 50,
    justifyContent: "center",
  },
  onPressInActiveTab: {
    flex: 1,
    paddingVertical: 6,
    paddingHorizontal: 12,
    height: 50,
    justifyContent: "center",
  },
  titleActiveTab: {
    fontSize: FontSize.MEDIUM,
    color: colors.primary,
    fontWeight: "700",
    fontFamily: "arial",
    textAlign: "center",
  },
  titleInActiveTab: {
    fontSize: FontSize.MEDIUM,
    color: colors.grey999,
    fontWeight: "400",
    fontFamily: "arial",
    textAlign: "center",
  },
  flexDirectionRowTab: {
    height: 50,
    width: "100%",
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.white,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    opacity: 1,
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  titleNotifyCount: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.orange,
    fontWeight: "700",
    fontFamily: "arial",
  },
  flexDirectionRowBetween: {
    flexDirection: "row",
    justifyContent: "space-between",
    // alignItems: 'center'
    paddingBottom: 8,
  },
  rowBack: {
    width: dimensWidth(75),
    height: dimensWidth(70),
    alignSelf: "flex-end",
    flexDirection: "row",
  },
  rowBackTaskDetail: {
    width: dimensWidth(45),
    height: dimensWidth(70),
    alignSelf: "flex-end",
  },
  iconChange: {
    flex: 1,
    height: dimensWidth(70),
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#9DD5FF",
  },
  iconDelete: {
    flex: 1,
    height: dimensWidth(70),
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#FFD7D7",
  },
  iconDeleteDonVi: {
    flex: 1,
    height: dimensWidth(70),
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#FFD7D7",
  },
  rowBackDonVi: {
    width: dimensWidth(45),
    height: dimensWidth(70),
    alignSelf: "flex-end",
    flexDirection: "row",
  },
  flatlist: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    marginHorizontal: 15,
    overflow: "hidden",
    marginBottom: 20,
    // paddingBottom: 20,
  },
  title: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
  },
  blueText: {
    fontSize: dimensWidth(13),
    color: colors.scienceBlue,
    fontWeight: "400",
    fontFamily: "arial",
  },
  itemPhongBan: {
    height: dimensWidth(70),
  },
  itemPhongBanChild: {
    backgroundColor: colors.white,
    height: dimensWidth(70),
    padding: 15,
  },
  commentJsonFlatlist: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    margin: 15,
    overflow: "hidden",
  },
  danhMucItemView: {
    flexDirection: 'row',
    backgroundColor: colors.white,
    padding: 15,
  },
  donViItemView: {
    backgroundColor: colors.white,
    padding: 15,
  },
  textTrichYeu: {
    flex: 1,
    fontSize: dimensWidth(13),
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 10,
  },
  textTrangThai: {
    fontSize: dimensWidth(12),
    color: "#626262",
    fontWeight: "400",
    fontFamily: "arial",
  },
  flexOne: {
    flexDirection: "column",
    flex: 1
  },
  titleCommentJson: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    borderRadius: 4,
  },
  positionComment: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    borderRadius: 4,
  },
  viewTrangThai: {
    height: dimensWidth(22),
    width: dimensWidth(90),
    borderRadius: 3,
    backgroundColor: "#F0F0F0",
    justifyContent: "center",
    alignItems: "center",
  },
  itemAvatar: {
    height: dimensWidth(40),
    width: dimensWidth(40),
    marginRight: dimensWidth(10),
    borderRadius: dimensWidth(20),
  },
});

export default FilterModal;
