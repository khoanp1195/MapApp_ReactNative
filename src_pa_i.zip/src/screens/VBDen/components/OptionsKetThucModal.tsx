import React, { FC, useMemo, useCallback } from "react";
import {
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Platform,
} from "react-native";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import {
  TraoDoiLaiIcon,
  SaveIcon
} from "assets/SVG/index";
interface Props {
  modalVisible: Boolean;
  onCloseModal: () => void;
  onChooseOptionsKetThuc: (Title: string) => void;
  ActionJson: any;
}
const OptionsKetThucModal: FC<Props> = ({
  modalVisible,
  onCloseModal,
  onChooseOptionsKetThuc,
  ActionJson,
  ...props
}: Props) => {
  const IconView = ({ Title }: any) => {
    if (Title === "Lưu")
      return <SaveIcon />;
    if (Title === "Trao đổi lại") return <TraoDoiLaiIcon />;
    return <View />;
  };
  const ItemAction = ({ item, index, onChooseOptionsKetThuc }: any) => {
    const { Title, ID } = item;
    // if(Title === 'Chia sẻ') return ShareBlueIcon
    return (
      <View style={styles.chooseTypeView}>
        <TouchableOpacity
          style={styles.flexDirection}
          onPress={() => onChooseOptionsKetThuc(Title)}
        >
          <IconView Title={Title} />
          <Text style={styles.textType} numberOfLines={1}>
            {Title}
          </Text>
        </TouchableOpacity>
        {ActionJson.length !== index + 1 && <View style={styles.stroke} />}
      </View>
    );
  };

  return (
    <Modal
      transparent={true}
      visible={modalVisible}
      {...props}
      style={styles.centeredView}
    >
      <View style={styles.centeredView}>
        <View style={styles.modalView}>
          {/* coppy header */}

          <View style={styles.chooseTypeView}>
            {true &&
              [{ID: 1, Title: 'Lưu'},{ ID: 2, Title: 'Trao đổi lại'}].map((item: any, index: any) => {
                return (
                  <ItemAction
                    key={index}
                    item={item}
                    index={index}
                    onChooseOptionsKetThuc={onChooseOptionsKetThuc}
                  />
                );
              })}
          </View>
          <TouchableOpacity
            activeOpacity={1}
            style={styles.viewTabBottomBar}
            onPress={onCloseModal}
          >
            <Text style={styles.tabBarLabelActive} numberOfLines={1}>
              {"Thoát"}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "flex-end",
  },
  modalView: {
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    opacity: 1,
    marginHorizontal: 15,
    paddingBottom: Platform.OS === "ios" ? 20 : 0,
  },
  chooseTypeView: {
    marginBottom: 15,
    backgroundColor: colors.white,
    borderRadius: 8,
  },
  flexDirection: {
    height: 67,
    flexDirection: "row",
    paddingHorizontal: 20,
    alignItems: "center",
  },
  stroke: {
    borderWidth: 0.5,
    borderColor: "#999",
    borderStyle: "dashed",
  },
  textType: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 9,
  },
  tabBarLabelActive: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.LARGE,
  },
  viewTabBottomBar: {
    flexDirection: "row",
    height: dimensWidth(66),
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.blueMedium,
    borderRadius: 8,
  },
});

export default OptionsKetThucModal;
