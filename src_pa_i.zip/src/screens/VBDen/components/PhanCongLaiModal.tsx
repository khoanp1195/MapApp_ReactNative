import React, { FC, useState, useCallback, useEffect } from "react";
import {
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  Animated,
  ScrollView,
  Alert,
} from "react-native";
import colors from "themes/Colors";
import { dimensWidth, FontSize, dimnensHeight } from "themes/const";
import { MemberIcon, UserPlusIcon } from "assets/SVG/index";
import {
  arrayIsEmpty,
  checkIsEmpty,
  format_dd_mm_yy,
  removeSpecialCharacters,
} from "helpers/formater";
import TextInputCustom from "components/TextInputCustom";
import { SwipeListView } from "react-native-swipe-list-view";
import { DueDateBlueIcon, DeleteRedIcon } from "assets/SVG";
import {ActionJsonType, EnumPhancong} from '../VBDenType'
import {
  SafeAreaProvider,
  SafeAreaView,
  useSafeAreaInsets,
} from "react-native-safe-area-context";
interface Props {
  modalVisible: Boolean;
  onClosePhanCongLaiModal: () => void;
  onChoosePhongBan: () => void;
  onChooseToChucPhanCong: () => void;
  onConfirmModalPhanCongLai: (text: string) => void;
  handleToggleDeletePhongban: (itemId: number) => void;
  handleToggleDeleteTaskJsonDetail: (itemId: number) => void;
  handleChooseDueDate: (
    itemId: number,
    DueDate: string,
    typeModal: EnumPhancong
  ) => void;
  handleToggleDeleteDSToChucPhanCong: (itemId: number) => void;
  dataPhongBanParams: any[];
  taskJsonDetail: any[];
  DocumentID: any;
  ykienlanhdao: any
}
const PhanCongLaiModal: FC<Props> = ({
  modalVisible,
  onClosePhanCongLaiModal,
  onChoosePhongBan,
  onConfirmModalPhanCongLai,
  onChooseToChucPhanCong,
  handleToggleDeletePhongban,
  handleToggleDeleteTaskJsonDetail,
  handleChooseDueDate,
  dataPhongBanParams,
  taskJsonDetail,
  ykienlanhdao,
  DocumentID,
  handleToggleDeleteDSToChucPhanCong,
  ...props
}: Props) => {
  const [yKienLanhDao, setYKienLanhDao] = useState<string>("");

  const onChangeYKienLanhDao = useCallback(
    (input: string) => {
      setYKienLanhDao(input);
    },
    [yKienLanhDao]
  );
  const onDismiss = useCallback(() => {
    Keyboard.dismiss();
  }, []);
  const onConfirm = useCallback(() => {
    onConfirmModalPhanCongLai(yKienLanhDao);
  }, [yKienLanhDao, dataPhongBanParams]);
  useEffect(() => {
    if (!checkIsEmpty(DocumentID)) {
      setYKienLanhDao("");
    }
  }, [DocumentID]);

  const ItemPhongBan = ({ item, index }) => {
    const { Title, DepartmentTitle, DueDate, Created, isThucHien, DeThucHien } =
      item;

    const DueDateFormated = checkIsEmpty(DueDate)
      ? DueDate
      : format_dd_mm_yy(DueDate);
    const isOdd = index % 2 === 0;
    const PhanCongTitle = DepartmentTitle ? DepartmentTitle : Title;
    return (
      <Animated.View
        style={[
          styles.itemPhongBanChild,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
      >
        <View style={styles.flexDirectionRowBetween}>
          <Text style={styles.title} numberOfLines={1}>
            {PhanCongTitle}
          </Text>
          <Text style={styles.blueText} numberOfLines={1}>
            {DueDateFormated}
          </Text>
        </View>
        {DeThucHien === undefined && (
          <Text style={styles.blueText} numberOfLines={1}>
            {isThucHien ? "Thực Hiện" : "Phối Hợp"}
          </Text>
        )}

        {isThucHien === undefined && (
          <Text style={styles.blueText} numberOfLines={1}>
            {DeThucHien ? "Thực Hiện" : "Phối Hợp"}
          </Text>
        )}
      </Animated.View>
    );
  };
  const onConfirmDeletePhongBan = useCallback((dummyID: any) => {
    Alert.alert("Thông báo", "Bạn thực sự muốn xóa?", [
      {
        text: "Cancel",
        style: "cancel",
      },
      { text: "OK", onPress: () => handleToggleDeletePhongban(dummyID) },
    ]);
  }, []);
  const onConfirmDeleteTaskJsonDetail = useCallback((ID: any) => {
    Alert.alert("Thông báo", "Bạn thực sự muốn xóa?", [
      {
        text: "Cancel",
        style: "cancel",
      },
      { text: "OK", onPress: () => handleToggleDeleteTaskJsonDetail(ID) },
    ]);
  }, []);

  useEffect(() => {
    setYKienLanhDao(ykienlanhdao)
  }, [ykienlanhdao])
  const insets = useSafeAreaInsets();
  
  return (
    <Modal
      transparent={true}
      visible={modalVisible}
      {...props}
      style={styles.centeredView}
    >
      <TouchableWithoutFeedback style={styles.centeredView} onPress={onDismiss}>
        <KeyboardAvoidingView
          style={styles.centeredView}
          behavior={Platform.OS === "ios" ? "padding" : "height"}
        >
          <View style={[styles.modalView,
            {
              flex: 1,
              paddingBottom: insets.bottom,
              marginTop: 55 + insets.top,
            },
          ]}>
            {/* coppy header */}
            <View style={styles.viewAssign}>
              <Text style={styles.textAssign}>Phân công lại</Text>
            </View>
            <ScrollView>
              <Text style={styles.textType}>Ý kiến lãnh đạo</Text>

              <TextInputCustom
                placeholder="Vui lòng nhập ý kiến"
                placeholderTextColor={colors.grey999}
                multiline
                onChangeText={(text) => onChangeYKienLanhDao(text)}
                value={yKienLanhDao}
                style={styles.commentInput}
              />
              <View>
                <Text style={styles.titleBoss}>
                  Các Phòng/Ban nghiệp vụ Công ty
                </Text>
                <View style={styles.chooseTypeView}>
                  <Text style={styles.textChooseType}>
                    {"Vui lòng bấm vào nút để chọn phòng/ban"}
                  </Text>
                  <TouchableOpacity
                    style={styles.buttonPhongBan}
                    onPress={onChoosePhongBan}
                  >
                    <UserPlusIcon />
                    <Text style={styles.textPhongBan} numberOfLines={1}>
                      Phòng/ban
                    </Text>
                  </TouchableOpacity>
                </View>
                {(!arrayIsEmpty(dataPhongBanParams) ||
                  !arrayIsEmpty(taskJsonDetail)) && (
                  <View style={styles.flatlist}>
                    <SwipeListView
                      extraData={dataPhongBanParams}
                      data={dataPhongBanParams}
                      renderItem={({ item, index }) =>
                        ItemPhongBan({ item, index })
                      }
                      renderHiddenItem={(data, rowMap) => {
                        return (
                          <View style={styles.rowBack}>
                            <TouchableOpacity
                              style={styles.iconChange}
                              onPress={() => {
                                handleChooseDueDate(
                                  data?.item?.dummyID,
                                  data?.item?.DueDate,
                                  EnumPhancong.PhongBanPhanCongLai
                                );
                              }}
                            >
                              <DueDateBlueIcon />
                            </TouchableOpacity>
                            <TouchableOpacity
                              style={styles.iconDelete}
                              onPress={() =>
                                onConfirmDeletePhongBan(data?.item?.dummyID)
                              }
                            >
                              <DeleteRedIcon />
                            </TouchableOpacity>
                          </View>
                        );
                      }}
                      keyExtractor={(item, index) => item.dummyID}
                      rightOpenValue={-75}
                      disableRightSwipe
                    />
                    <SwipeListView
                      extraData={taskJsonDetail}
                      data={taskJsonDetail}
                      renderItem={({ item, index }) =>
                        ItemPhongBan({ item, index })
                      }
                      renderHiddenItem={(data, rowMap) => {
                        return (
                          <View style={styles.rowBackTaskDetail}>
                            {/* <TouchableOpacity
                              style={styles.iconChange}
                              onPress={() => {
                                handleChooseDueDatePhongBanPhanCongLai(
                                  data?.item?.dummyID ,
                                  data?.item?.DueDate
                                );
                              }}
                            >
                              <DueDateBlueIcon />
                            </TouchableOpacity> */}
                            <TouchableOpacity
                              style={styles.iconDelete}
                              onPress={() => {
                                onConfirmDeleteTaskJsonDetail(data?.item?.dummyID );
                              }}
                            >
                              <DeleteRedIcon />
                            </TouchableOpacity>
                          </View>
                        );
                      }}
                      keyExtractor={(item, index) => item.dummyID}
                      rightOpenValue={-dimensWidth(45)}
                      disableRightSwipe
                    />
                  </View>
                )}
              </View>
            </ScrollView>
            <View style={styles.viewTabBottomBar}>
              <TouchableOpacity
                style={styles.buttonExit}
                onPress={onClosePhanCongLaiModal}
              >
                <Text style={styles.buttonExitText} numberOfLines={1}>
                  Thoát
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.buttonTransfer}
                onPress={onConfirm}
              >
                <Text style={styles.tabBarLabelActive} numberOfLines={1}>
                  Phân công
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "flex-end",
  },
  modalView: {
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    opacity: 1,
    backgroundColor: colors.white,
    borderTopEndRadius: 12,
    borderTopStartRadius: 12,
    overflow: "hidden",
  },
  chooseTypeView: {
    height: 100,
    borderWidth: 1,
    borderColor: "#005FD4",
    borderStyle: "dashed",
    marginBottom: 15,
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
    marginHorizontal: 15,
    marginTop: 10,
  },
  flexDirection: {
    // height: 67,
    flexDirection: "row",
    paddingHorizontal: 20,
    alignItems: "center",
  },
  stroke: {
    borderWidth: 0.5,
    borderColor: "#999999",
    borderStyle: "dashed",
  },
  textType: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginVertical: 10,
  },
  tabBarLabelActive: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
  },
  textPhongBan: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
    marginLeft: 5,
  },
  viewTabBottomBar: {
    flexDirection: "row",
    // height: dimensWidth(66),
    borderRadius: 8,
    justifyContent: "flex-end",
    marginBottom: 30,
  },
  buttonTransfer: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.blueMedium,
    width: dimensWidth(130),
    height: dimensWidth(34),
    borderRadius: 4,
    marginEnd: 15,
  },
  buttonPhongBan: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.blueMedium,
    height: 34,
    borderRadius: 4,
    marginTop: 10,
    paddingHorizontal: 20,
  },
  buttonExit: {
    alignItems: "center",
    justifyContent: "center",
    width: dimensWidth(130),
    height: dimensWidth(34),
    borderRadius: 4,
  },
  buttonExitText: {
    color: colors.red,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
  },
  textAssign: {
    color: colors.blueMedium,
    fontWeight: "700",
    fontSize: FontSize.LARGE,
  },
  viewAssign: {
    backgroundColor: colors.lightBlue,
    padding: 15,
  },
  titleBoss: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginHorizontal: 15,
  },
  commentInput: {
    paddingHorizontal: 10,
    borderColor: colors.greyDDD,
    borderRadius: 3,
    height: dimensWidth(100),
    borderWidth: 1,
    marginHorizontal: 15,
    marginBottom: 10,
    textAlignVertical: "top",
  },
  typeChild: {
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "center",
    // height: 34,
    // borderColor: colors.greyDDD,
    // borderWidth: 1,
    // borderRadius: 3,
    marginHorizontal: 15,
    justifyContent: "space-between",
  },
  textFiltedType: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 9,
  },
  textChooseType: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 9,
    marginHorizontal: 10,
  },
  title: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
  },
  blueText: {
    fontSize: dimensWidth(13),
    color: colors.scienceBlue,
    fontWeight: "400",
    fontFamily: "arial",
  },
  itemPhongBan: {
    height: dimensWidth(70),
  },
  itemPhongBanChild: {
    backgroundColor: colors.white,
    height: dimensWidth(70),
    padding: 15,
  },
  flexDirectionRowBetween: {
    flexDirection: "row",
    justifyContent: "space-between",
    // alignItems: 'center'
    paddingBottom: 8,
  },
  rowBack: {
    width: dimensWidth(75),
    height: dimensWidth(70),
    alignSelf: "flex-end",
    flexDirection: "row",
  },
  rowBackTaskDetail: {
    width: dimensWidth(45),
    height: dimensWidth(70),
    alignSelf: "flex-end",
  },
  iconChange: {
    flex: 1,
    height: dimensWidth(70),
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#9DD5FF",
  },
  iconDelete: {
    flex: 1,
    height: dimensWidth(70),
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#FFD7D7",
  },
  flatlist: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    marginHorizontal: 15,
    overflow: "hidden",
    marginBottom: 20,
    paddingBottom: 20,
  },
});

export default PhanCongLaiModal;
