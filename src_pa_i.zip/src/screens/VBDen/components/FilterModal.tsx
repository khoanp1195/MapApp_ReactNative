import React, { FC, useMemo, useCallback } from "react";
import {
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Platform,
} from "react-native";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import {
  RightBlueIcon,
  ChoYKienLanhDaoIcon,
  TinhTrangIcon,
} from "assets/SVG/index";
import stylesMain from "../WaitProcessDocx.Style";
import { useSelector } from "react-redux";
import { RootState } from "stores";
import { useNavigation } from "@react-navigation/native";
import { format_dd_mm_yy } from "helpers/formater";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";

interface Props {
  modalVisible: Boolean;
  onConfirmModal: () => void;
  onReFilterModal: () => void;
  confirmText: String;
  refilterText: String;
  props: FC<Props>;
  tabName: String;
  onPressProcessedDocx: () => void;
  onPressWaitProcesseDocx: () => void;
  onPressChooseType: () => void;
  onPressFilter: () => void;
  onPressSearch: () => void;
  onPressOpenCalendarPicker: (typeModal: string) => void;
  onPressChooseLanhDao: () => void;
  tinhTrangSellected: String;
  navigation: any;
  startDate: any;
  endDate: any;
  funtionVBDen: any;
  lanhDaoNameSellectedFilter: any;
}
const FilterModal: FC<Props> = ({
  modalVisible,
  onConfirmModal,
  onReFilterModal,
  confirmText,
  refilterText,
  onPressFilter,
  tabName,
  onPressWaitProcesseDocx,
  onPressProcessedDocx,
  tinhTrangSellected,
  onPressChooseType,
  onPressSearch,
  onPressOpenCalendarPicker,
  startDate,
  endDate,
  funtionVBDen,
  onPressChooseLanhDao,
  lanhDaoNameSellectedFilter,
  ...props
}: Props) => {

  const startDateFormat = useMemo(() => {
    if (!startDate) return "";
    const dateFormat = format_dd_mm_yy(startDate);
    return dateFormat;
  }, [startDate]);
  const endDateFormat = useMemo(() => {
    if (!endDate) return "";
    const dateFormat = format_dd_mm_yy(endDate);
    return dateFormat;
  }, [endDate]);

  const onPressChooseTypePress = useCallback(() => {
    onPressChooseType();
  }, [onPressChooseType]);

  return (
    <Modal
      transparent={true}
      visible={modalVisible}
      {...props}
      style={styles.centeredView}
    >
      <SafeAreaProvider style={styles.centeredView}>
        <SafeAreaView>
          <View style={styles.modalView}>

            <TouchableOpacity
              style={styles.chooseTypeView}
              onPress={onPressChooseLanhDao}
            >
              <View style={styles.typeChild}>
                <ChoYKienLanhDaoIcon />
                <Text style={styles.textType}>Lãnh đạo cho ý kiến</Text>
              </View>
              <View style={styles.typeChild}>
                <Text style={styles.textFiltedType}>
                  {lanhDaoNameSellectedFilter}
                </Text>
                <RightBlueIcon />
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.chooseTypeView}
              onPress={onPressChooseTypePress}
            >
              <View style={styles.typeChild}>
                <TinhTrangIcon />
                <Text style={styles.textType}>Tình trạng</Text>
              </View>
              <View style={styles.typeChild}>
                <Text style={[styles.textFiltedType, {opacity: funtionVBDen.key === 'VBDenTitle' || funtionVBDen.key === 'VBDenTatCa' ? 1 : 0.3}]}>{tinhTrangSellected}</Text>
                <RightBlueIcon opacity={funtionVBDen.key === 'VBDenTitle' || funtionVBDen.key === 'VBDenTatCa' ? 1 : 0.3}/>
              </View>
            </TouchableOpacity>
            <View style={styles.dashed} />
            <View style={styles.filterDateView}>
              <View style={styles.dateView}>
                <TouchableOpacity
                  style={[styles.date, { marginLeft: 16 }]}
                  onPress={() => onPressOpenCalendarPicker("startDate")}
                >
                  <Text style={styles.textTitleDate}>Từ ngày</Text>
                  <Text style={styles.textDate}>{startDateFormat}</Text>
                </TouchableOpacity>
              </View>
              <View style={styles.stroke} />
              <View style={styles.dateView}>
                <TouchableOpacity
                  style={[styles.date, { marginRight: 16, paddingLeft: 16 }]}
                  onPress={() => onPressOpenCalendarPicker("endDate")}
                >
                  <Text style={styles.textTitleDate}>Đến ngày</Text>
                  <Text style={styles.textDate}>{endDateFormat}</Text>
                </TouchableOpacity>
              </View>
            </View>
            <View style={styles.flexDirection}>
              <View style={styles.button} />
              <View style={styles.button}>
                <TouchableOpacity
                  onPress={onReFilterModal}
                  style={styles.buttonReFilter}
                >
                  <Text style={styles.modalReFilterText}>{refilterText}</Text>
                </TouchableOpacity>
              </View>
              <View style={styles.button}>
                <TouchableOpacity
                  onPress={onConfirmModal}
                  style={styles.buttonConfirm}
                >
                  <Text style={styles.modalConfirmText}>{confirmText}</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </SafeAreaView>
      </SafeAreaProvider>

    </Modal>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
  },
  modalView: {
    width: "100%",
    backgroundColor: colors.whiteLilac,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    paddingBottom: 40,
    opacity: 1,
    marginTop: 100,
  },
  button: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  typeChild: {
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "center",
  },
  dateView: {
    flex: 1,
    margin: -1,
  },
  dashed: {
    borderWidth: 1,
    borderColor: "#E5E5E5",
    borderStyle: "dashed",
    overflow: "visible",
    width: "70%",
    marginTop: dimensWidth(10),
  },
  date: {},
  chooseTypeView: {
    flexDirection: "row",
    marginTop: dimensWidth(10),
    backgroundColor: colors.white,
    justifyContent: "space-between",
    width: "100%",
    paddingVertical: dimensWidth(17),
    alignItems: "center",
  },
  filterDateView: {
    flexDirection: "row",
    backgroundColor: colors.white,
  },
  flexDirection: {
    height: dimensWidth(50),
    flexDirection: "row",
    marginTop: dimensWidth(10),
  },
  modalConfirmText: {
    fontSize: FontSize.MEDIUM,
    color: colors.white,
    fontWeight: "400",
    fontFamily: "arial",
  },
  modalReFilterText: {
    fontSize: FontSize.LARGE,
    color: colors.scienceBlue,
    fontWeight: "400",
    fontFamily: "arial",
  },
  stroke: {
    borderWidth: 1,
    borderColor: "#E5E5E5",
    marginVertical: dimensWidth(7.5),
    borderStyle: "dashed",
  },
  buttonReFilter: {
    height: dimensWidth(34),
    paddingHorizontal: dimensWidth(12),
    borderRadius: dimensWidth(4),
    alignItems: "center",
    justifyContent: "center",
  },
  buttonConfirm: {
    backgroundColor: colors.scienceBlue,
    height: dimensWidth(34),
    paddingHorizontal: dimensWidth(12),
    borderRadius: dimensWidth(4),
    alignItems: "center",
    justifyContent: "center",
  },
  textDate: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginVertical: dimensWidth(14),
  },
  textTitleDate: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginTop: dimensWidth(14),
  },
  textType: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 9,
  },
  textFiltedType: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 9,
  },
});

export default FilterModal;
