import React, { FC, useState, useCallback, useEffect } from "react";
import {
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  Animated,
  ScrollView,
  Alert
} from "react-native";
import colors from "themes/Colors";
import { dimensWidth, FontSize, dimnensHeight } from "themes/const";
import { MemberIcon, UserPlusIcon } from "assets/SVG/index";
import {
  arrayIsEmpty,
  checkIsEmpty,
  format_dd_mm_yy,
  removeSpecialCharacters,
} from "helpers/formater";
import TextInputCustom from "components/TextInputCustom";
import { SwipeListView } from "react-native-swipe-list-view";
import { DueDateBlueIcon, DeleteRedIcon } from "assets/SVG";
import { EnumPhancong} from '../VBDenType';
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
interface Props {
  modalVisible: Boolean;
  onClosePhanCongModal: () => void;
  onChoosePhongBan: () => void;
  onChooseToChucPhanCong: () => void;
  onConfirmModalPhanCong: (text: string) => void;
  handleToggleDeletePhongban: (itemId: number) => void;
  handleChooseDueDate: (itemId: number, DueDate: string, typeModal: EnumPhancong) => void;
  handleToggleDeleteDSToChucPhanCong: (itemId: number) => void;
  dataPhongBanParams: Array<any>;
  filteredDanhSachTochucPhanCong: Array<any>;
  DocumentID: any,
  ykienlanhdao: any
}
const PhanCongModal: FC<Props> = ({
  modalVisible,
  onClosePhanCongModal,
  onChoosePhongBan,
  onConfirmModalPhanCong,
  onChooseToChucPhanCong,
  handleToggleDeletePhongban,
  handleChooseDueDate,
  ykienlanhdao,
  filteredDanhSachTochucPhanCong,
  dataPhongBanParams,
  handleToggleDeleteDSToChucPhanCong,
  DocumentID,
  ...props
}: Props) => {
  const [yKienLanhDao, setYKienLanhDao] = useState<string>("");

  const onChangeYKienLanhDao = useCallback(
    (input: string) => {
      setYKienLanhDao(input);
    },
    [yKienLanhDao]
  );
  const onDismiss = useCallback(() => {
    Keyboard.dismiss();
  }, []);
  const onConfirm = useCallback(() => {
    onConfirmModalPhanCong(yKienLanhDao);
  }, [yKienLanhDao, dataPhongBanParams,filteredDanhSachTochucPhanCong]);
  useEffect(() => {
    if(!checkIsEmpty(DocumentID)){
     setYKienLanhDao("");
    }
   }, [DocumentID])

   useEffect(() => {
    setYKienLanhDao(ykienlanhdao)
   }, [ykienlanhdao])
  const ItemPhongBan = ({ item, index }) => {
    const { Title, DueDate, Created, isThucHien } = item;
    const DueDateFormated = checkIsEmpty(DueDate)
      ? DueDate
      : format_dd_mm_yy(DueDate);
    const isOdd = index % 2 === 0;

    return (
      <Animated.View
        style={[
          styles.itemPhongBanChild,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
      >
        <View style={styles.flexDirectionRowBetween}>
          <Text style={styles.title} numberOfLines={1}>
            {Title}
          </Text>
          <Text style={styles.blueText} numberOfLines={1}>
            {DueDateFormated}
          </Text>
        </View>
        <Text style={styles.blueText} numberOfLines={1}>
          {isThucHien ? "Thực Hiện" : "Phối Hợp"}
        </Text>
      </Animated.View>
    );
  };
  const ItemToChucPhanCong = ({ item, index }) => {
    const { Title, ParentDept, Created, DueDate } = item;
    const DueDateFormated = checkIsEmpty(DueDate)
      ? DueDate
      : format_dd_mm_yy(DueDate);
    const isOdd = index % 2 === 0;

    return (
      <Animated.View
        style={[
          styles.itemPhongBanChild,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
      >
        <View style={styles.flexDirectionRowBetween}>
          <Text style={styles.title} numberOfLines={1}>
            {Title}
          </Text>
          <Text style={styles.blueText} numberOfLines={1}>
            {DueDateFormated}
          </Text>
        </View>
        <Text style={styles.blueText} numberOfLines={1}>
          {removeSpecialCharacters(ParentDept)}
        </Text>
      </Animated.View>
    );
  };
  const onConfirmDeletePhongBan = useCallback((dummyID: any) => {
    Alert.alert("Thông báo", "Bạn thực sự muốn xóa?", [
      {
        text: "Cancel",
        style: "cancel",
      },
      { text: "OK", onPress: () => handleToggleDeletePhongban(dummyID) },
    ]);
  }, []);
  const onConfirmDeleteDSToChucPhanCong = useCallback((dummyID: any) => {
    Alert.alert("Thông báo", "Bạn thực sự muốn xóa?", [
      {
        text: "Cancel",
        style: "cancel",
      },
      { text: "OK", onPress: () => handleToggleDeleteDSToChucPhanCong(dummyID) },
    ]);
  }, []);
  return (
    <Modal
      transparent={true}
      visible={modalVisible}
      {...props}
      style={styles.centeredView}
    >
      <TouchableWithoutFeedback style={styles.centeredView} onPress={onDismiss}>
        <View
          style={styles.centeredView}
        >
          <View style={styles.modalView}>
            <View style={styles.viewAssign}>
              <Text style={styles.textAssign}>Phân công</Text>
            </View>
            <KeyboardAwareScrollView>
              <Text style={styles.textType}>Ý kiến lãnh đạo</Text>

              <TextInputCustom
                placeholder="Vui lòng nhập ý kiến"
                placeholderTextColor={colors.grey999}
                multiline
                onChangeText={(text) => onChangeYKienLanhDao(text)}
                value={yKienLanhDao}
                style={styles.commentInput}
              />
              <View>
                <Text style={styles.titleBoss}>
                  Các Phòng/Ban nghiệp vụ Công ty
                </Text>
                <View style={styles.chooseTypeView}>
                  <Text style={styles.textChooseType}>
                    {"Vui lòng bấm vào nút để chọn phòng/ban"}
                  </Text>
                  <TouchableOpacity
                    style={styles.buttonPhongBan}
                    onPress={onChoosePhongBan}
                  >
                    <UserPlusIcon />
                    <Text style={styles.textPhongBan} numberOfLines={1}>
                      Phòng/ban
                    </Text>
                  </TouchableOpacity>
                </View>
                {!arrayIsEmpty(dataPhongBanParams) && (
                  <View style={styles.flatlist}>
                    <SwipeListView
                      extraData={dataPhongBanParams}
                      data={dataPhongBanParams}
                      renderItem={({ item, index }) =>
                        ItemPhongBan({ item, index })
                      }
                      renderHiddenItem={(data, rowMap) => {
                        return (
                          <View style={styles.rowBack}>
                            <TouchableOpacity
                              style={styles.iconChange}
                              onPress={() => {
                                handleChooseDueDate(
                                  data?.item?.dummyID,
                                  data?.item?.DueDate,
                                  EnumPhancong.PhongBan
                                );
                              }}
                            >
                              <DueDateBlueIcon />
                            </TouchableOpacity>
                            <TouchableOpacity
                              style={styles.iconDelete}
                              onPress={() => {
                                onConfirmDeletePhongBan(data?.item?.dummyID);
                              }}
                            >
                              <DeleteRedIcon />
                            </TouchableOpacity>
                          </View>
                        );
                      }}
                      keyExtractor={(item, index) => item.dummyID}
                      rightOpenValue={-75}
                      disableRightSwipe
                    />
                  </View>
                )}

                <Text style={styles.titleBoss}>
                  Tổ chức phân công thực hiện
                </Text>

                <View style={styles.chooseTypeView}>
                  <Text style={styles.textChooseType}>
                    {"Vui lòng bấm vào nút để chọn Chi nhánh trực thuộc"}
                  </Text>
                  <TouchableOpacity
                    style={styles.buttonPhongBan}
                    onPress={onChooseToChucPhanCong}
                  >
                    <MemberIcon />

                    <Text style={styles.textPhongBan} numberOfLines={1}>
                    Chi nhánh trực thuộc
                    </Text>
                  </TouchableOpacity>
                </View>
                {!arrayIsEmpty(filteredDanhSachTochucPhanCong) && (
                  <View style={styles.flatlist}>
                    <SwipeListView
                      extraData={filteredDanhSachTochucPhanCong}
                      data={filteredDanhSachTochucPhanCong}
                      renderItem={({ item, index }) =>
                        ItemToChucPhanCong({ item, index })
                      }
                      renderHiddenItem={(data, rowMap) => {
                        return (
                          <View style={styles.rowBack}>
                            <TouchableOpacity
                              style={styles.iconChange}
                              onPress={() => {
                                handleChooseDueDate(
                                  data?.item?.ID ,
                                  data?.item?.DueDate,
                                  EnumPhancong.ToChucPhanCong
                                );
                              }}
                            >
                              <DueDateBlueIcon />
                            </TouchableOpacity>
                            <TouchableOpacity
                              style={styles.iconDelete}
                              onPress={() => {
                                onConfirmDeleteDSToChucPhanCong(
                                  data?.item?.ID 
                                );
                              }}
                            >
                              <DeleteRedIcon />
                            </TouchableOpacity>
                          </View>
                        );
                      }}
                      keyExtractor={(item, index) => item.ID}
                      rightOpenValue={-75}
                      disableRightSwipe
                    />
                  </View>
                )}
              </View>
            </KeyboardAwareScrollView>
            <View style={styles.viewTabBottomBar}>
              <TouchableOpacity
                style={styles.buttonExit}
                onPress={onClosePhanCongModal}
              >
                <Text style={styles.buttonExitText} numberOfLines={1}>
                  Thoát
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.buttonTransfer}
                onPress={onConfirm}
              >
                <Text style={styles.tabBarLabelActive} numberOfLines={1}>
                  Phân công
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "flex-end",
  },
  modalView: {
    maxHeight: dimnensHeight(800),
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    opacity: 1,
    backgroundColor: colors.white,
    borderTopEndRadius: 12,
    borderTopStartRadius: 12,
    overflow: "hidden",
  },
  chooseTypeView: {
    height: 100,
    borderWidth: 1,
    borderColor: "#005FD4",
    borderStyle: "dashed",
    marginBottom: 15,
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
    marginHorizontal: 15,
    marginTop: 10,
  },
  flexDirection: {
    // height: 67,
    flexDirection: "row",
    paddingHorizontal: 20,
    alignItems: "center",
  },
  stroke: {
    borderWidth: 0.5,
    borderColor: "#999999",
    borderStyle: "dashed",
  },
  textType: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginVertical: 10,
  },
  tabBarLabelActive: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
  },
  textPhongBan: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
    marginLeft: 5,
  },
  viewTabBottomBar: {
    flexDirection: "row",
    // height: dimensWidth(66),
    borderRadius: 8,
    justifyContent: "flex-end",
    marginBottom: 30,
  },
  buttonTransfer: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.blueMedium,
    width: dimensWidth(130),
    height: dimensWidth(34),
    borderRadius: 4,
    marginEnd: 15,
  },
  buttonPhongBan: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.blueMedium,
    height: 34,
    borderRadius: 4,
    marginTop: 10,
    paddingHorizontal: 20,
  },
  buttonExit: {
    alignItems: "center",
    justifyContent: "center",
    width: dimensWidth(130),
    height: dimensWidth(34),
    borderRadius: 4,
  },
  buttonExitText: {
    color: colors.red,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
  },
  textAssign: {
    color: colors.blueMedium,
    fontWeight: "700",
    fontSize: FontSize.LARGE,
  },
  viewAssign: {
    backgroundColor: colors.lightBlue,
    padding: 15,
  },
  titleBoss: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginHorizontal: 15,
  },
  commentInput: {
    paddingHorizontal: 10,
    borderColor: colors.greyDDD,
    borderRadius: 3,
    height: dimensWidth(100),
    borderWidth: 1,
    marginHorizontal: 15,
    marginBottom: 10,
    textAlignVertical: "top",
  },
  typeChild: {
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "center",
    // height: 34,
    // borderColor: colors.greyDDD,
    // borderWidth: 1,
    // borderRadius: 3,
    marginHorizontal: 15,
    justifyContent: "space-between",
  },
  textFiltedType: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 9,
  },
  textChooseType: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 9,
    marginHorizontal: 10,
  },
  title: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
  },
  blueText: {
    fontSize: dimensWidth(13),
    color: colors.scienceBlue,
    fontWeight: "400",
    fontFamily: "arial",
  },
  itemPhongBan: {
    height: dimensWidth(70),
  },
  itemPhongBanChild: {
    backgroundColor: colors.white,
    height: dimensWidth(70),
    padding: 15,
  },
  flexDirectionRowBetween: {
    flexDirection: "row",
    justifyContent: "space-between",
    // alignItems: 'center'
    paddingBottom: 8,
  },
  rowBack: {
    width: dimensWidth(75),
    height: dimensWidth(70),
    alignSelf: "flex-end",
    flexDirection: "row",
  },
  iconChange: {
    flex: 1,
    height: dimensWidth(70),
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#9DD5FF",
  },
  iconDelete: {
    flex: 1,
    height: dimensWidth(70),
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#FFD7D7",
  },
  flatlist: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    marginHorizontal: 15,
    overflow: "hidden",
    maxHeight: 250,
    marginBottom: 20,
    paddingBottom: 20,
  },
  itemAvatar: {
    height: dimensWidth(40),
    width: dimensWidth(40),
    marginRight: dimensWidth(10),
    borderRadius: dimensWidth(20),
  },
});

export default PhanCongModal;
