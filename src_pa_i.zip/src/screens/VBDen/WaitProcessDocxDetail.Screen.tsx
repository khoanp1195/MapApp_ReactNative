import React, { useCallback, useState, useEffect, useMemo } from "react";
import {
  View,
  FlatList,
  StyleSheet,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
  Linking,
  Platform
} from "react-native";
import {
  BackIcon,
  FowardProcesscon,
  TransferProcessIcon,
  ClockWhiteIcon,
  ActionMoreIcon,
  ThreeDotIcon,
  ShareBlueIcon,
  AddRemoveIcon,
  ReAssignIcon,
  KetThucIcon,
  AssignGreenIcon,
} from "assets/SVG/index";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import TextInputCustom from "components/TextInputCustom";
import { useDispatch, useSelector } from "react-redux";
import ActionOptionalModal from "./components/ActionOptionalModal";
import ChuyenXuLyModal from "./components/ChuyenXuLyModal";
import PhanCongModal from "./components/PhanCongModal";
import PhanCongLaiModal from "./components/PhanCongLaiModal";
import ChoYKienLanhDaoModal from "./components/ChoYKienLanhDaoModal";
import KetThucModal from "./components/KetThucModal";
import ChiaSeModal from "./components/ChiaSeModal";
import BoSungThuHoiModal from "./components/BoSungThuHoiModal";
import ChuyenPhanCongModal from "./components/ChuyenPhanCongModal";

import {
  format_dd_mm_yy,
  removeSpecialCharacters,
  checkTypeFiles,
  checkTrangThai,
  checkIsEmpty,
  arrayIsEmpty,
  format_date_yy_mm_dd,
  format_dd_mm_yyyy_hh_mm,
  format_mm_dd_hh_yy_mm_ss,
  format_yy_mm_mm_dd_hh,
  getExtension,
  checkMimeTypeFiles,
  isNullOrUndefined,
  byteConverter,
} from "helpers/formater";
import { ThunkDispatch } from "@reduxjs/toolkit";
import OptionsKetThucModal from "./components/OptionsKetThucModal";
import TraoDoiLaiModal from "./components/TraoDoiLaiModal";
import { ActionJsonType } from "./VBDenType";
import {
  vbDenChiaSeApi,
  vbChuyenXuLyTrinhLanhDaoApi,
  vbDenKetThucApi,
  vbChuyenPhanCongApi,
  goBackWaitProcessDocxScreen,
  vbDenPhanCongApi,
  vbDenPhanCongLaiApi,
  vbDenThuHoiBoSungApi,
  fetchWaitProcessDocxDetail,
  fetchWaitProcessDocxAttachFile,
  fetchDanhSachVBDenTheoMuc,
  postReadVanBan,
  SetisLoadingVBDen,
  checkIsEnableCollaboratorAssignment
} from "stores/vbDen/reducer";
import { goBackWaitProcessDocxDetailScreen } from "stores/taskVBDen/reducer";
import CalendarPickerPhanCongModal from "./components/CalendarPickerPhanCongModal";
import { EnumPhancong } from "./VBDenType";
// import RNFetchBlob from 'react-native-fetch-blob';
import FastImage from "react-native-fast-image";
import { BaseUrl } from "~/services/api";
import { LoadingView } from "~/components";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import FileViewer from "react-native-file-viewer";
import axios from "axios";
import { SetisLoadingDetail } from "~/stores/VBBH/reducer";
import moment from "moment";

type Props = {
  navigation: any;
  route: any;
};

const App = ({ route, navigation }: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();

  const {
    isLoadingVBDen,
    isGoBackVBDenScreen,
    isChiaSeVBDenDetailSuccess,
    dataWaitProcessDocxDetail,
    dataWaitProcessDocxAttachFile,
    IsEnableCollaboratorAssignment,
    dataDanhSachVBDenTheoMuc,
  } = useSelector((state: any) => state.vbDenReducer);
  const { isGoBackWaitProcessDocxDetailScreen } = useSelector(
    (state: any) => state.taskVBDenReducer
  );
  const { subSite, token } = useSelector(
    (state: any) => state.login
  );

  const {
    CoQuanGui,
    DocumentDate,
    ReceivedDate,
    SoDen,
    DoKhan,
    DoMat,
    ThoiHanGQ,
    TrichYeu,
    ActionJson,
    DocumentType,
    ID,
  } = dataWaitProcessDocxDetail;
  const initialState = {
    chiaSeStringList: {
      UserShared: "",
      displayString: "",
    },
    chuyenXuLyStringList: {
      userCCString: "",
      UserCC: "",
    },
    lanhDaoCongTyNameData: {
      ID: "",
      Title: "",
    },
  };
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [isOpenCalendarPhanCongPicker, setIsOpenCalendarPhanCongPicker] =
    useState(false);
  const [sellectedItemId, setSellectedItemId] = useState<number>(-1);
  const [typePhanCong, setTypePhanCong] = useState<EnumPhancong | null>(null);
  const [DueDateParams, setDueDateDateParams] = useState<string>("");
  const [chuyenPhanCongModal, setChuyenPhanCongModal] = useState(false);
  const [modalActionOptional, setModalActionOptional] = useState(false);
  const [modalChuyenXuLy, setChuyenXuLyModal] = useState(false);
  const [modalChiaSe, setModalChiaSe] = useState(false);
  const [modalPhanCong, setPhanCongModal] = useState(false);
  const [modalPhanCongLai, setPhanCongLaiModal] = useState(false);
  const [deleteDeptList, setDeleteDeptList] = useState("");
  const [taskJsonDetail, setTaskJsonDetail] = useState<any>([]);
  const [modalYKienLanhDao, setModalYKienLanhDao] = useState(false);
  const [modalBoSungThuHoi, setModalBoSungThuHoi] = useState(false);
  const [modalKetThuc, setKetThucModal] = useState(false);
  const [modalOptionsKetThuc, setOptionsKetThucModal] = useState(false);
  const [modalTraoDoiLai, setModalTraoDoiLai] = useState(false);
  const [dataPhongBanParams, setDataBanLanhDaoParams] = useState<any>([]);
  const [danhsachToChucPhanCong, setDanhsachToChucPhanCong] = useState<any>([]);
  const [lanhDaoCongTyNameData, setLanhDaoCongTyNameData] = useState<any>(
    initialState.lanhDaoCongTyNameData
  );
  const [yKienLanhDao, setYKienLanhDao] = useState("");
  const [chiaSeStringList, setChiaSeStringList] = useState(
    initialState.chiaSeStringList
  );
  const [chuyenXuLyStringList, setChuyenXuLyStringList] = useState<any>(
    initialState.chuyenXuLyStringList
  );
  const [DocumentID, setDocumentID] = useState("");

  const resetNewScreen = useCallback(() => {
    setYKienLanhDao("");
    setLanhDaoCongTyNameData(initialState.lanhDaoCongTyNameData);
    setChiaSeStringList(initialState.chiaSeStringList);
    setChuyenXuLyStringList(initialState.chuyenXuLyStringList);
    setIsFullScreen(false);
    setDataBanLanhDaoParams([]);
    setDeleteDeptList("");
    setTaskJsonDetail([]);
    setDanhsachToChucPhanCong([]);
    setTypePhanCong(null);
    setDueDateDateParams("");
    setSellectedItemId(-1);
  }, []);
  useEffect(() => {
    if (!arrayIsEmpty(route.params?.danhsachToChucPhanCong)) {
      setDanhsachToChucPhanCong(route.params?.danhsachToChucPhanCong);
    }
  }, [route.params?.danhsachToChucPhanCong]);
  useEffect(() => {
    if (route?.params?.lanhDaoCongTyNameData) {
      setLanhDaoCongTyNameData(route?.params?.lanhDaoCongTyNameData);
      setChuyenXuLyModal(true);
    }
  }, [route.params?.lanhDaoCongTyNameData, navigation]);
  const fetchDanhSachVBDenTheoMucRequest = useCallback(async (subSite: string) => {
    dispatch(fetchDanhSachVBDenTheoMuc(subSite));
  }, [dispatch]);
  const fetchWaitProcessDocxAttachFileRequest = useCallback(
    ({ DocumentID, subSite }: any) => {
      dispatch(
        fetchWaitProcessDocxAttachFile(
          {
            DocumentID,
            subSite
          }
        )
      );
    },
    [dispatch]
  );
  const postReadVanBanRequest = useCallback(
    ({ DocumentID, subSite, ListName }: any) => {
      dispatch(
        postReadVanBan(
          {
            DocumentID,
            subSite,
            ListName
          }
        )
      );
    },
    [dispatch]
  );

  const onGoBack = useCallback(() => {
    navigation.goBack();
  }, []);

  const gotoThongTinLuanChuyenScreen = useCallback(() => {
    navigation.navigate({
      name: "ThongTinLuanChuyenScreen",
      params: { itemId: dataWaitProcessDocxDetail?.ID },
    });
  }, [dataWaitProcessDocxDetail]);

  const openModalActionOptional = useCallback(() => {
    setModalActionOptional(true);
  }, [modalActionOptional]);
  const onActionPress = useCallback(
    (ID: number) => {
      if (modalActionOptional) setModalActionOptional(false);
      if (ID === ActionJsonType.ChuyenPhanCong) setChuyenPhanCongModal(true);
      if (ID === ActionJsonType.ChuyenXuLy) setChuyenXuLyModal(true);
      if (ID === ActionJsonType.PhanCong) setPhanCongModal(true);
      if (ID === ActionJsonType.PhanCongLai) setPhanCongLaiModal(true);
      if (ID === ActionJsonType.ChiaSe) setModalChiaSe(true);
      if (ID === ActionJsonType.BoSungThuHoi) setModalBoSungThuHoi(true);
      if (ID === ActionJsonType.KetThuc) setKetThucModal(true);
    },
    [
      modalPhanCong,
      modalChiaSe,
      modalBoSungThuHoi,
      modalChuyenXuLy,
      modalOptionsKetThuc,
      modalActionOptional,
      route.params?.typeModal,
    ]
  );
  const onChooseOptionsKetThuc = useCallback(
    (Title: string) => {
      setOptionsKetThucModal(false);
      if (Title === "Lưu") setKetThucModal(true);
      if (Title === "Trao đổi lại") setModalTraoDoiLai(true);
    },
    [modalTraoDoiLai, modalKetThuc, OptionsKetThucModal]
  );

  const onCloseOptionsKetThucModal = useCallback(() => {
    setOptionsKetThucModal(false);
  }, [modalOptionsKetThuc]);
  const onCloseActionOptionalModal = useCallback(() => {
    setModalActionOptional(false);
  }, [modalActionOptional]);
  const onCloseChuyenXuLyModal = useCallback(() => {
    setChuyenXuLyModal(false);
  }, [modalChuyenXuLy]);

  const onChooseLanhDaoCongTy = useCallback(() => {
    setChuyenXuLyModal(false);
    navigation.navigate({
      name: "ChooseLanhDaoCongTyScreen",
      params: {
        lanhDaoCongTyNameData,
        BanLanhDao: dataWaitProcessDocxDetail?.BanLanhDao,
      },
    });
  }, [lanhDaoCongTyNameData, dataWaitProcessDocxDetail]);
  const onChooseCCLanhDaoCongTy = useCallback(() => {
    setChuyenXuLyModal(false);
    navigation.navigate({
      name: "ChooseNhomNguoiDungScreen",
      params: {
        danhSachUsersAndGroup: route?.params?.danhSachUsersAndGroup,
        typeModal: ActionJsonType.ChuyenXuLy,
        chuyenXuLyStringList,
      },
    });
  }, [route?.params?.danhSachUsersAndGroup]);

  const onChoosePhongBan = useCallback(
    (typeModal: any) => {
      if (typeModal === ActionJsonType.BoSungThuHoi) {
        setModalBoSungThuHoi(false);
      } else {
        setPhanCongModal(false);
      }
      navigation.navigate({
        name: "ChoosePhongBanPhanCongScreen",
        params: {
          dataPhongBanParams: dataPhongBanParams,
          typeModal: typeModal,
        },
      });
    },
    [dataPhongBanParams]
  );
  const onChoosePhanConglaiPhongBan = useCallback(() => {
    setPhanCongLaiModal(false);
    navigation.navigate({
      name: "ChoosePhongBanPhanCongScreen",
      params: {
        dataPhongBanParams: dataPhongBanParams,
        typeModal: ActionJsonType.PhanCongLai,
      },
    });
  }, [dataPhongBanParams]);

  const onChooseToChucPhanCong = useCallback(
    (typeModal: any) => {
      if (typeModal === ActionJsonType.BoSungThuHoi) {
        setModalBoSungThuHoi(false);
      }
      if (typeModal === ActionJsonType.PhanCong) {
        setPhanCongModal(false);
      }
      navigation.navigate({
        name: "ToChucPhanCongThucHienScreen",
        params: {
          danhsachToChucPhanCong,
          DonViXuLyJson: dataWaitProcessDocxDetail?.DonViXuLyJson,
          typeModal,
        },
      });
    },
    [danhsachToChucPhanCong, dataWaitProcessDocxDetail?.DonViXuLyJson]
  );

  const onChooseTypeChiaSe = useCallback(() => {
    setModalChiaSe(false);
    navigation.navigate({
      name: "ChooseNhomNguoiDungScreen",
      params: {
        danhSachUsersAndGroup: route?.params?.danhSachUsersAndGroup,
        typeModal: ActionJsonType.ChiaSe,
        chiaSeStringList,


      },
    });
  }, [route?.params?.danhSachUsersAndGroup]);

  const onClosePhanCongModal = useCallback(() => {
    setPhanCongModal(false);
  }, []);
  const onClosePhanCongLaiModal = useCallback(() => {
    setPhanCongLaiModal(false);
  }, []);
  const onCloseModalYKienLanhDao = useCallback(() => {
    setModalYKienLanhDao(false);
  }, []);
  const onCloseModalChuyenPhanCong = useCallback(() => {
    setChuyenPhanCongModal(false);
  }, []);
  const onCloseModalTraoDoiLai = useCallback(() => {
    setModalTraoDoiLai(false);
    setOptionsKetThucModal(false);
  }, []);
  const onCloseModalKetThuc = useCallback(() => {
    setKetThucModal(false);
    setOptionsKetThucModal(false);
  }, []);
  const onCloseBoSungThuHoiModal = useCallback(() => {
    setModalBoSungThuHoi(false);
  }, []);
  const onChangeYKienLanhDao = useCallback(
    (text: string) => {
      setModalYKienLanhDao(false);
      setYKienLanhDao(text);
    },
    []
  );
  const onConfirmModalChuyenPhanCong = useCallback(
    (text: string) => {
      if (checkIsEmpty(text)) {
        Alert.alert('Thông báo', 'Vui lòng nhập ý kiến', [
          { text: 'Đóng' },
        ]);
      } else {
        setChuyenPhanCongModal(false);
        const body = {
          Comment: text,
          DocumentID,
          subSite
        };
        dispatch(vbChuyenPhanCongApi(body));
      }
    },
    [DocumentID, subSite]
  );
  const onDueDateDateChangeModal = useCallback(
    (date: string, typePhanCong: EnumPhancong) => {
      setIsOpenCalendarPhanCongPicker(false);
      if (typePhanCong === EnumPhancong.PhongBanPhanCongLai) {
        setPhanCongLaiModal(true);
        setDataBanLanhDaoParams((prevData: any) => {
          const newData = [...prevData];
          const findItemAndToggleDueDate = (items: any) => {
            for (let i = 0; i < items.length; i++) {
              const item = items[i];

              if (item.dummyID === sellectedItemId) {
                item.DueDate = date;
                return;
              }
              if (item.children && item.children.length > 0) {
                findItemAndToggleDueDate(item.children);
              }
            }
          };
          findItemAndToggleDueDate(newData);

          return newData;
        });
      } else {
        if (typePhanCong === EnumPhancong.PhongBan) {
          setPhanCongModal(true);
          setDataBanLanhDaoParams((prevData: any) => {
            const newData = [...prevData];
            const findItemAndToggleDueDate = (items: any) => {
              for (let i = 0; i < items.length; i++) {
                const item = items[i];

                if (item.dummyID === sellectedItemId) {
                  item.DueDate = date;
                  return;
                }
                if (item.children && item.children.length > 0) {
                  findItemAndToggleDueDate(item.children);
                }
              }
            };
            findItemAndToggleDueDate(newData);

            return newData;
          });
        }
        if (typePhanCong === EnumPhancong.BoSungThuHoi) {
          setModalBoSungThuHoi(true);
          setDanhsachToChucPhanCong((prevData: any) => {
            const newData = [...prevData];

            const findItemAndToggleToChucPhanCong = (items: any) => {
              for (let i = 0; i < items.length; i++) {
                const item = items[i];

                if (item?.ID === sellectedItemId) {
                  item.DueDate = date;
                  return;
                }
              }
            };
            findItemAndToggleToChucPhanCong(newData);
            return newData;
          });
        }
        if (typePhanCong === EnumPhancong.ToChucPhanCong) {
          setPhanCongModal(true);
        }

        setDanhsachToChucPhanCong((prevData: any) => {
          const newData = [...prevData];

          const findItemAndToggleToChucPhanCong = (items: any) => {
            for (let i = 0; i < items.length; i++) {
              const item = items[i];

              if (item?.ID === sellectedItemId) {
                item.DueDate = date;
                return;
              }
            }
          };
          findItemAndToggleToChucPhanCong(newData);
          return newData;
        });

      }
    },
    [sellectedItemId, dataPhongBanParams, danhsachToChucPhanCong]
  );
  const filteredDanhSachTochucPhanCong = useMemo(() => {
    if (!arrayIsEmpty(danhsachToChucPhanCong)) {
      const filteredData = danhsachToChucPhanCong.filter(
        (it) => it.isSellectedToChucPhanCong
      );
      return filteredData;
    }
  }, [danhsachToChucPhanCong]);

  const onCloseCalendarPickerPhanCongModal = useCallback(() => {
    setIsOpenCalendarPhanCongPicker(false);
    if (typePhanCong === EnumPhancong.PhongBanPhanCongLai) {
      setPhanCongLaiModal(true);
    }
    if (typePhanCong === EnumPhancong.ToChucPhanCong || typePhanCong === EnumPhancong.PhongBan) {
      setPhanCongModal(true);
    }
  }, [typePhanCong]);

  const onRemoveSelectedDate = useCallback(() => {
    onDueDateDateChangeModal("", typePhanCong)
  }, [typePhanCong])

  const resetToday = useCallback((today: any) => {
    onDueDateDateChangeModal(today, typePhanCong)
  }, [typePhanCong]);

  const onConfirmModalTraoDoiLai = useCallback((text: string) => {
    setModalTraoDoiLai(false);
    setOptionsKetThucModal(false);
  }, []);
  const onConfirmModalKetThuc = useCallback(
    (text: string, DocumentID: any) => {
      const body = {
        Comment: text,
        DocumentID,
        subSite
      };
      dispatch(vbDenKetThucApi(body));
      setKetThucModal(false);
      setOptionsKetThucModal(false);
    },
    [subSite]
  );
  const onConfirmModalChiaSe = useCallback(
    (text: string) => {
      if (checkIsEmpty(chiaSeStringList?.UserShared)) {
        Alert.alert("Thông báo", "Vui lòng chọn người bạn muốn chia sẻ!", [
          {
            text: 'Đóng'
          }
        ]);
      } else {
        dispatch(
          vbDenChiaSeApi({
            UserShared: chiaSeStringList?.UserShared,
            Comment: text,
            DocumentID,
            subSite
          })
        );
        setModalChiaSe(false);
        setChiaSeStringList(null);
      }
    },
    [chiaSeStringList, DocumentID, subSite]
  );

  const onConfirmChuyenXuLyModal = useCallback(
    (text: string, lanhDaoCongTyNameDataParams: any) => {
      if (checkIsEmpty(lanhDaoCongTyNameDataParams?.Title)) {
        Alert.alert('Thông báo', 'Vui lòng chọn Lãnh đạo', [
          { text: 'Đóng' },
        ]);
      } else {
        const BanLanhDao =
          lanhDaoCongTyNameDataParams?.ID +
          ";#" +
          lanhDaoCongTyNameDataParams?.Title;
        const body = {
          BanLanhDao,
          Comment: text,
          UserCC: chuyenXuLyStringList?.UserCC,
          DocumentID,
          subSite
        };
        dispatch(vbChuyenXuLyTrinhLanhDaoApi(body));
        setChuyenXuLyModal(false);
      }
    },
    [chuyenXuLyStringList, DocumentID, dispatch, subSite]
  );

  const onCloseModalChiaSe = useCallback(() => {
    setModalChiaSe(false);
  }, [yKienLanhDao]);

  const onOpenModalYKienLanhDao = useCallback(() => {
    setModalYKienLanhDao(true);
  }, []);

  const saveBase64AsFile = async (base64Data, filePath) => {
    const base64Image = `${base64Data}`;
    const { fs } = RNFetchBlob;

    // Tạo thư mục nếu chưa tồn tại
    await fs.mkdir(filePath.substring(0, filePath.lastIndexOf('/')));

    // Giải mã base64 thành dữ liệu nhị phân
    const data = await fs.readFile(base64Image, 'base64');

    // Ghi dữ liệu vào file
    await fs.createFile(filePath, data, 'base64');
  };
  const downloadFile = useCallback(async (dataAttach: any) => {
    dispatch(SetisLoadingDetail(true))
    const { config, fs } = RNFetchBlob;
    const date = new Date();
    const typeFile = getExtension(dataAttach?.Url)
    const mimeType = checkMimeTypeFiles(dataAttach?.Url);
    const { DownloadDir } = fs.dirs;
    const filename = dataAttach?.Url.substring(dataAttach?.Url.lastIndexOf('/') + 1, dataAttach?.Url.length)
    const milisecond = moment().valueOf()
    const localPath = `${DownloadDir}/${milisecond}_${filename}`
    const options = {
      fileCache: true,
      mime: mimeType,
      appendExt: typeFile,
      path: localPath,
    };
    const encodeUri = encodeURI(dataAttach?.Url)
    const url = `${BaseUrl}/_layouts/15/VuThao.PA.Api/ApiDownload.ashx?file=${encodeUri}`
    config(options)
      .fetch('GET', url)
      .then((res) => {
        FileViewer.open(localPath, {
        }).catch(error => {
          dispatch(SetisLoadingDetail(false))
          Alert.alert('Thông báo', 'Đã có lỗi xảy ra. Vui lòng thử lại', [
            { text: 'Đóng' }
          ])
        });

        dispatch(SetisLoadingDetail(false))
      })
      .catch((error) => {
        dispatch(SetisLoadingDetail(false))
        Alert.alert('Thông báo', 'Đã có lỗi xảy ra. Vui lòng thử lại', [
          { text: 'Đóng' }
        ])
      });
  }, []);

  const gotoFileViewScreen = useCallback((item: any) => {
    if (Platform.OS !== "ios") {
      downloadFile({ ...item, Url: BaseUrl + item?.Url })
    } else {
      navigation.navigate({
        name: "FileViewScreen",
        params: { item },
      });
    }
  }, []);

  const onChangeIsFullScren = useCallback(
    (item: any) => {
      setIsFullScreen(!isFullScreen);
    },
    [isFullScreen]
  );

  const DocumentDateFormat = useMemo(() => {
    if (!DocumentDate) return "";
    return format_dd_mm_yy(DocumentDate);
  }, [DocumentDate]);

  const ReceivedDateFormat = useMemo(() => {
    if (!ReceivedDate) return "";
    return format_dd_mm_yy(ReceivedDate);
  }, [ReceivedDate]);

  const ThoiHanGQFormat = useMemo(() => {
    if (!ThoiHanGQ) return "";
    return format_dd_mm_yy(ThoiHanGQ);
  }, [ThoiHanGQ]);

  const DocumentTypeFormat = useMemo(() => {
    if (!DocumentType) return "";
    return removeSpecialCharacters(DocumentType);
  }, [DocumentType]);
  const CoQuanGuiFormat = useMemo(() => {
    if (!CoQuanGui) return "";
    return removeSpecialCharacters(CoQuanGui);
  }, [CoQuanGui]);

  useEffect(() => {
    if (route?.params?.typeModal) {
      const typeModal = route.params?.typeModal;
      onActionPress(typeModal);
    }
  }, [route.params?.typeModal, navigation, route?.params]);

  useEffect(() => {
    if (route?.params?.danhSachUsersAndGroup) {
      let tmp = route?.params?.danhSachUsersAndGroup;

      if (route.params?.typeModal == ActionJsonType.ChiaSe) {
        let displayString = "";
        let UserShared = "";
        tmp = tmp.filter((it: any) => it?.isSellectedCChiaSe);
        const dataLength = tmp.length;
        tmp.forEach((it: any, index: any) => {
          displayString =
            index + 1 !== dataLength
              ? displayString + it?.FullName + "; "
              : displayString + it?.FullName;
          UserShared = checkIsEmpty(UserShared)
            ? it?.AccountID + ";#" + it?.AccountName
            : UserShared + ";#" + it?.AccountID + ";#" + it?.AccountName;
        });

        setChiaSeStringList({ UserShared, displayString });
        setModalChiaSe(true);
      }
      if (route.params?.typeModal == ActionJsonType.ChuyenXuLy) {
        let userCCString = "";
        let UserCC = "";
        tmp = tmp.filter((it: any) => it?.isSellectedChuyenXuLy);
        const dataLength = tmp.length;
        const plusString = checkIsEmpty(UserCC) ? "" : ";#";
        tmp.forEach((it: any, index: number) => {
          userCCString =
            index + 1 !== dataLength
              ? userCCString + it?.FullName + "; "
              : userCCString + it?.FullName;
          UserCC =
            index + 1 !== dataLength
              ? UserCC + plusString + it?.AccountID + ";#" + it?.AccountName
              : UserCC + it?.AccountID + ";#" + it?.AccountName;
        });
        setChuyenXuLyStringList({ userCCString, UserCC });
        setChuyenXuLyModal(true);
      }
    }
  }, [route.params?.danhSachUsersAndGroup, route?.params?.typeModal]);
  const fetchWaitProcessDocxDetailRequest = useCallback(
    ({ DocumentID, subSite }: any) => {
      dispatch(
        fetchWaitProcessDocxDetail(
          {
            DocumentID,
            subSite
          }
        )
      );
    },
    [dispatch, onConfirmModalKetThuc]
  );
  useEffect(() => {
    if (route.params?.DocumentID) {
      setDocumentID(route?.params?.DocumentID);
      resetNewScreen();
    }
  }, [route?.params?.DocumentID]);
  useEffect(() => {
    if (
      isGoBackVBDenScreen ||
      isChiaSeVBDenDetailSuccess
    ) {
      resetNewScreen();
      onGoBack();
    }
  }, [
    isGoBackVBDenScreen,
    isChiaSeVBDenDetailSuccess,
  ]);

  useEffect(() => {
    if (DocumentID || isGoBackWaitProcessDocxDetailScreen || isGoBackVBDenScreen) {
      if (isGoBackWaitProcessDocxDetailScreen) {
        resetNewScreen();
      }
      fetchWaitProcessDocxDetailRequest({ DocumentID, subSite });
      fetchWaitProcessDocxAttachFileRequest({ DocumentID, subSite });
      postReadVanBanRequest({ DocumentID, ListName: "Văn bản đến", subSite });
      fetchDanhSachVBDenTheoMucRequest(subSite);
      dispatch(goBackWaitProcessDocxScreen({}));
      dispatch(goBackWaitProcessDocxDetailScreen({}));
    }
  }, [
    fetchWaitProcessDocxDetailRequest,
    fetchWaitProcessDocxAttachFileRequest,
    fetchDanhSachVBDenTheoMucRequest,
    DocumentID,
    isChiaSeVBDenDetailSuccess,
    isGoBackVBDenScreen,
    isGoBackWaitProcessDocxDetailScreen,
    subSite,
    route.params?.ListName
  ]);
  const handleToggleDeletePhongban = useCallback(
    (itemId: any) => {
      setDataBanLanhDaoParams((prevData: any) => {
        const newData = [...prevData];

        const findItemAndTogglePhoiHop = (items: any) => {
          for (let i = 0; i < items.length; i++) {
            const item = items[i];

            if (item.dummyID === itemId) {
              item.isPhoiHop = false;
              item.isThucHien = false;
              item.DueDate = "";
              return;
            }

            if (item.children && item.children.length > 0) {
              findItemAndTogglePhoiHop(item.children);
            }
          }
        };
        findItemAndTogglePhoiHop(newData);

        return newData;
      });
    },
    [dataPhongBanParams]
  );
  const handleToggleDeleteTaskJsonDetail = useCallback(
    (itemId: any) => {
      setTaskJsonDetail((prevData: any) => {
        const newData = prevData.filter((it) => it.dummyID !== itemId);
        return newData;
      });

      setDeleteDeptList((prevData: any) => {
        const newString = prevData + itemId + "|";

        return newString;
      });
    },
    [taskJsonDetail, deleteDeptList]
  );
  const handleChooseDueDate = useCallback(
    (itemId: number, DueDate: string, typePhanCong: EnumPhancong) => {
      setPhanCongModal(false);
      if (typePhanCong === EnumPhancong.ToChucPhanCong) {
        setPhanCongModal(false);
      }
      if (typePhanCong === EnumPhancong.PhongBanPhanCongLai) {
        setPhanCongLaiModal(false);
      }
      if (typePhanCong === EnumPhancong.BoSungThuHoi) {
        setModalBoSungThuHoi(false);
      }

      setIsOpenCalendarPhanCongPicker(true);
      setTypePhanCong(typePhanCong);
      setDueDateDateParams(DueDate);
      setSellectedItemId(itemId);
    },
    [typePhanCong, sellectedItemId]
  );

  const findItemsWithPhongBan = (data) => {
    const result = [];

    const traverseData = (data) => {
      data.forEach((item) => {
        if (item.isThucHien || item.isPhoiHop) {
          result.push(item);
        }

        if (item.children && item.children.length > 0) {
          traverseData(item.children); // Đệ quy duyệt qua các phần tử con
        }
      });
    };

    traverseData(data); // Bắt đầu duyệt từ mảng data

    return result;
  };
  const filteredDataPhongBan = useMemo(() => {
    let filteredData: any[] = [];
    if (!arrayIsEmpty(dataPhongBanParams)) {
      filteredData = findItemsWithPhongBan(dataPhongBanParams);
      return filteredData;
    }
    return filteredData;
  }, [dataPhongBanParams]);

  useEffect(() => {
    if (!arrayIsEmpty(route.params?.dataPhongBanParams)) {
      setDataBanLanhDaoParams(route.params?.dataPhongBanParams);
    }
  }, [route.params?.dataPhongBanParams]);
  useEffect(() => {
    if (!arrayIsEmpty(dataWaitProcessDocxDetail?.TaskJson)) {
      const TaskJson = dataWaitProcessDocxDetail?.TaskJson
        ? dataWaitProcessDocxDetail?.TaskJson.map(
          (it) =>
          (it = {
            ...it,
            dummyID: it?.ID,
          })
        )
        : [];

      setTaskJsonDetail(TaskJson);
    }
  }, [dataWaitProcessDocxDetail?.TaskJson]);
  const onConfirmModalBoSung = useCallback(
    (text: string, IsBoSung: boolean) => {
      let AssignmentDept = "";
      if (arrayIsEmpty(filteredDanhSachTochucPhanCong)) {
        Alert.alert("Thông báo", "Vui lòng chọn Chi nhánh trực thuộc!", [
          { text: "Đóng" },
        ]);
        return;
      } else {
        const traverseData = (filterData: any) => {
          filterData.forEach((item: any) => {
            const DepartmentTitle = item?.ID + ";#" + item?.Title;

            AssignmentDept +=
              DepartmentTitle + "&&" + item?.URL + "&&" + item?.DueDate + "@@";
          });
        };
        traverseData(filteredDanhSachTochucPhanCong); // Bắt đầu duyệt từ mảng data
      }
      const payload = {
        Comment: text,
        AssignmentDept,
        DocumentID,
        IsBoSung,
        subSite
      };
      setModalBoSungThuHoi(false);
      dispatch(vbDenThuHoiBoSungApi(payload));
    },
    [DocumentID, filteredDanhSachTochucPhanCong, danhsachToChucPhanCong, subSite]
  );
  const onConfirmModalThuHoi = useCallback(
    (text: string, IsBoSung: boolean, deleteDept: string) => {
      if (checkIsEmpty(deleteDept)) {
        Alert.alert("Thông báo", "Vui lòng chọn đơn vị bạn muốn thu hồi!", [
          { text: "Đóng" },
        ]);
        return;
      }
      const payload = {
        Comment: text,
        DeleteDept: deleteDept,
        DocumentID,
        IsBoSung,
        subSite
      };
      setModalBoSungThuHoi(false);
      dispatch(vbDenThuHoiBoSungApi(payload));
    },
    [DocumentID, subSite]
  );
  const onShowFullTrichYeu = useCallback(() => {
    Alert.alert("", TrichYeu, [{ text: "OK", onPress: () => { } }]);
  }, [TrichYeu]);
  const onConfirmModalPhanCong = useCallback(
    (text: string) => {
      let AssignmentUser = "";
      let AssignmentDept = "";

      if (arrayIsEmpty(filteredDataPhongBan)) {
        if (arrayIsEmpty(filteredDanhSachTochucPhanCong)) {
          Alert.alert("Thông báo", "Vui lòng chọn phòng ban!", [
            { text: "Đóng", onPress: () => { } },
          ]);
          return;
        }
      }

      const Comment = "";
      const traverseData = (filterData: any) => {
        filterData.forEach((item: any) => {
          const DepartmentTitle = item.ID + ";#" + item.Title;
          const assignmentType = item.isThucHien
            ? "&&1&&0&&0&&"
            : "&&0&&0&&1&&";
          if (item.isUser) {
            AssignmentUser +=
              DepartmentTitle +
              assignmentType +
              item?.DueDate +
              "&&" +
              item.Manager +
              "&&" +
              Comment +
              "@@";
          } else {
            AssignmentUser +=
              item.Manager +
              assignmentType +
              item?.DueDate +
              "&&" +
              DepartmentTitle +
              "&&" +
              Comment +
              "@@";
          }
        });
      };
      traverseData(filteredDataPhongBan); // Bắt đầu duyệt từ mảng data

      if (!arrayIsEmpty(filteredDanhSachTochucPhanCong)) {
        const traverseData = (filterData: any) => {
          filterData.forEach((item: any) => {
            const DepartmentTitle = item?.ID + ";#" + item?.Title;

            AssignmentDept +=
              DepartmentTitle + "&&" + item?.URL + "&&" + item?.DueDate + "@@";
          });
        };
        traverseData(filteredDanhSachTochucPhanCong); // Bắt đầu duyệt từ mảng data
      }
      const payload = {
        Comment: text,
        BanLanhDao: "",
        UserCC: "",
        AssignmentUser,
        AssignmentDept,
        DocumentID,
        subSite
      };
      setPhanCongModal(false);
      dispatch(vbDenPhanCongApi(payload));
    },
    [
      filteredDataPhongBan,
      DocumentID,
      danhsachToChucPhanCong,
      filteredDanhSachTochucPhanCong,
      subSite
    ]
  );

  const onConfirmModalPhanCongLai = useCallback(
    (text: string) => {
      let AssignmentUser = "";
      if (arrayIsEmpty(filteredDataPhongBan)) {
        Alert.alert("Thông báo", "Vui lòng chọn phòng ban!", [
          { text: "OK", onPress: () => { } },
        ]);
        return;
      } else {
        const Comment = "";
        const traverseData = (filterData: any) => {
          filterData.forEach((item: any) => {
            const DepartmentTitle = item.ID + ";#" + item.Title;
            const assignmentType = item.isThucHien
              ? "&&1&&0&&0&&"
              : "&&0&&0&&1&&";
            if (item.isUser) {
              AssignmentUser +=
                // AssignmentUser +
                // plusString +
                DepartmentTitle +
                assignmentType +
                item?.DueDate +
                "&&" +
                item.Manager +
                "&&" +
                Comment +
                "@@";
            } else {
              AssignmentUser +=
                // AssignmentUser +
                // plusString +
                item.Manager +
                assignmentType +
                item?.DueDate +
                "&&" +
                DepartmentTitle +
                "&&" +
                Comment +
                "@@";
            }
          });
        };
        traverseData(filteredDataPhongBan); // Bắt đầu duyệt từ mảng data
      }
      const payload = {
        Comment: text,
        deleteDept: deleteDeptList,
        BanLanhDao: "",
        AssignmentUser,
        DocumentID,
        subSite
      };
      setPhanCongLaiModal(false);
      dispatch(vbDenPhanCongLaiApi(payload));
    },
    [
      filteredDataPhongBan,
      DocumentID,
      filteredDanhSachTochucPhanCong,
      deleteDeptList,
      taskJsonDetail,
      subSite
    ]
  );

  const handleToggleDeleteDSToChucPhanCong = (itemId: any) => {
    setDanhsachToChucPhanCong((prevData: any) => {
      const newData = prevData.map((it) =>
        it.ID == itemId ? { ...it, isSellectedToChucPhanCong: false } : it
      );
      return newData;
    });
  };
  const gotoNhiemVuDaPhanCongScreen = useCallback(
    (item: any, ID: number) => {
      if (!item.DeThucHien) {
        axios.get(`${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=SettingByKey&params=SettingKey&SettingKey=IsEnableCollaboratorAssignment`, {
          headers: { Authorization: `${token}` }
        })
          .then(function (response) {
            if (!isNullOrUndefined(response.data.data) && !arrayIsEmpty(response.data.data)) {
              const IsEnableCollaboratorAssignment = response.data.data[0].VALUE === "1"
              if (IsEnableCollaboratorAssignment) {
                navigation.navigate({
                  name: "NhiemVuDaPhanCongScreen",
                  params: { DocumentID, taskID: ID },
                });
              }
            }
          })
      } else {
        navigation.navigate({
          name: "NhiemVuDaPhanCongScreen",
          params: { DocumentID, taskID: ID },
        });
      }
    },
    [DocumentID]
  );

  const ItemAttach = ({ item, index }: any) => {
    const { Author, Created, Category, Size, Url, Title } = item;
    const createdFormated = Created ? format_dd_mm_yy(Created) : null;
    const sizeFormated = !isNullOrUndefined(Size) ? byteConverter(Size) : "";
    const FileIcon = () => {
      return checkTypeFiles(Url);
    };
    const isOdd = index % 2 === 0;
    return (
      <TouchableOpacity
        style={[
          styles.documentFileView,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
        onPress={() => gotoFileViewScreen(item)}
      >
        <View
          style={[styles.flexDirectionRowBetween, { alignItems: "flex-start" }]}
        >
          <View style={{ marginTop: 5 }}>
            <FileIcon />
          </View>
          <View style={styles.flexOne}>
            <Text style={styles.titleDocumentFile} numberOfLines={1}>
              {Title}
            </Text>
            <View style={styles.flexDirectionRow}>
              <Text style={styles.sizeDocumentFile} numberOfLines={1}>
                {sizeFormated}
              </Text>
              <Text style={{
                fontSize: FontSize.MEDIUM,
                color: colors.lightBlack,
                fontWeight: "400",
                fontFamily: "arial",
                marginLeft: 15,
                marginTop: 5
              }} numberOfLines={1}>
                {Category}
              </Text>
            </View>
          </View>
          <View>
            <Text style={styles.contenAttach} numberOfLines={1}>
              {Author}
            </Text>
            <Text style={{
              fontSize: FontSize.MEDIUM,
              color: colors.lightBlack,
              fontWeight: "400",
              fontFamily: "arial",
              marginLeft: 15,
              marginTop: 5
            }} numberOfLines={1}>
              {createdFormated}
            </Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };
  const ItemVBDenCommentJson = ({ item, index }: any) => {
    const { Title, Value, ImagePath, Position, Created } = item;
    const createdFormated = format_dd_mm_yyyy_hh_mm(Created);
    const isOdd = index % 2 === 0;
    return (
      <View
        style={[
          styles.danhMucItemView,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
      >
        <View
          style={[styles.flexDirectionRowBetween, { alignItems: "flex-start" }]}
        >
          <View style={styles.flexOne}>
            <View style={styles.flexDirectionRowBetween}>
              <Text style={styles.titleCommentJson} numberOfLines={1}>
                {Title}
              </Text>
              <Text style={styles.positionComment} numberOfLines={1}>
                {createdFormated}
              </Text>
            </View>
            <Text style={styles.positionComment} numberOfLines={1}>
              {removeSpecialCharacters(Position)}
            </Text>
            <View style={styles.flexDirectionRow}>
              <Text style={styles.titleCommentJson}>
                {Value}
              </Text>
            </View>
          </View>
        </View>
      </View>
    );
  };
  const ItemVBDenTaskJson = ({
    item,
    index,
    gotoNhiemVuDaPhanCongScreen,
  }: any) => {
    const {
      AssignedToType,
      TrangThai,
      DepartmentTitle,
      Position,
      Created,
      DeThucHien,
      DueDate,
      ImagePath,
      ID,
    } = item;
    const PositionFormat = checkIsEmpty(Position)
      ? ""
      : removeSpecialCharacters(Position) + " - ";
    const textThucHien = DeThucHien ? "Thực hiện" : "Phối hợp";
    const isOdd = index % 2 === 0;
    const customColor = checkTrangThai(TrangThai);
    const DueDateFormat = useMemo(() => {
      if (DueDate) return format_dd_mm_yy(DueDate)
      return "";
    }, [DueDate])
    return (
      <TouchableOpacity
        onPress={gotoNhiemVuDaPhanCongScreen}
        style={[
          styles.danhMucItemView,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
      >
        {
          AssignedToType === 1 ? (
            <View
              style={[styles.flexDirectionRowBetween, { alignItems: "flex-start" }]}
            >
              <View style={styles.flexOne}>
                <View style={styles.flexDirectionRowBetween}>
                  <Text style={styles.titleVbDenTheoMuc} numberOfLines={1}>
                    {DepartmentTitle}
                  </Text>
                  <Text style={styles.positionComment} numberOfLines={1}>
                    {DueDateFormat}
                  </Text>
                </View>
                <View style={styles.flexDirectionRow}>
                  <Text style={[styles.textPosition,]} numberOfLines={1}>
                    {PositionFormat}
                    <Text style={[{}, DeThucHien && { color: colors.scienceBlue }]}>{textThucHien}</Text>
                  </Text>
                  <View
                    style={[
                      styles.viewTrangThai,
                      { backgroundColor: customColor?.backgroundColor },
                    ]}
                  >
                    <Text
                      style={[styles.textTrangThai, { color: customColor?.color }]}
                      numberOfLines={1}
                    >
                      {TrangThai}
                    </Text>
                  </View>
                </View>
              </View>
            </View>
          ) : (<View style={{
            flex: 1,
            flexDirection: 'row'
          }}>
            <View style={{
              flex: 1,
              flexDirection: 'row'
            }}>
              <FastImage
                style={{
                  height: dimensWidth(40),
                  width: dimensWidth(40),
                  marginRight: dimensWidth(10),
                  borderRadius: dimensWidth(20),
                }}
                source={{
                  uri: `${BaseUrl}/${subSite}${ImagePath}`,
                  headers: { Authorization: `${token}` },
                  priority: FastImage.priority.normal,
                }}
                resizeMode={FastImage.resizeMode.contain}
              />

              <View style={{
                flex: 1
              }}>
                <Text style={styles.titleCommentJson} numberOfLines={1}>{DepartmentTitle}</Text>
                <View style={{ flexDirection: 'row' }}>
                  <Text style={styles.positionComment} numberOfLines={1}>{PositionFormat}</Text>
                  <Text style={[styles.positionComment, DeThucHien && { color: colors.scienceBlue }]}>{textThucHien}</Text>
                </View>
              </View>
            </View>

            <View style={{ flex: 1, alignItems: 'flex-end' }}>
              <Text style={styles.positionComment} numberOfLines={1}>
                {DueDateFormat}
              </Text>
              <View
                style={[
                  styles.viewTrangThai,
                  { backgroundColor: customColor?.backgroundColor },
                ]}
              >
                <Text
                  style={[styles.textTrangThai, { color: customColor?.color }]}
                  numberOfLines={1}
                >
                  {TrangThai}
                </Text>
              </View>
            </View>
          </View>
          )
        }
      </TouchableOpacity>
    );
  };
  const ItemVBDenDonVi = ({ item, index }: any) => {
    const { DepartmentName, TrangThai, VBId, Position, Created } = item;
    const isOdd = index % 2 === 0;
    const customColor = checkTrangThai(TrangThai);
    return (
      <View
        style={[
          styles.danhMucItemView,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
      >
        <View
          style={[styles.flexDirectionRowBetween, { alignItems: "flex-start" }]}
        >
          <View style={styles.flexDirectionRow}>
            <Text style={styles.textTrichYeu} numberOfLines={1}>
              {DepartmentName}
            </Text>
            <View
              style={[
                styles.viewTrangThai,
                { backgroundColor: customColor?.backgroundColor },
              ]}
            >
              <Text
                style={[styles.textTrangThai, { color: customColor?.color }]}
                numberOfLines={1}
              >
                {TrangThai}
              </Text>
            </View>
          </View>
        </View>
      </View>
    );
  };

  const IconView = ({ ID }: any) => {
    if (ID === ActionJsonType.ChuyenPhanCong) return <TransferProcessIcon />;
    if (ID === ActionJsonType.ChuyenXuLy) return <FowardProcesscon />;
    if (ID === ActionJsonType.PhanCong) return <AssignGreenIcon />;
    if (ID === ActionJsonType.PhanCongLai) return <ReAssignIcon />;
    if (ID === ActionJsonType.ChiaSe)
      return <ShareBlueIcon color={colors.white} dimens={20} />;
    if (ID === ActionJsonType.BoSungThuHoi) return <AddRemoveIcon />;
    if (ID === ActionJsonType.KetThuc) return <KetThucIcon />;
    return <View />;
  };
  const ItemAction = ({ item, index, onActionPress }: any) => {
    if (index >= 2) return null;
    const { Title, ID } = item;
    // if(Title === 'Chia sẻ') return ShareBlueIcon
    return (
      <TouchableOpacity
        key={ID}
        style={styles.shareButton}
        onPress={() => onActionPress(ID)}
      >
        <View style={styles.flexDirectionRowAction}>
          <IconView ID={ID} />
          <Text style={styles.tabBarLabelActive} numberOfLines={1}>
            {Title}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  // renderView
  return (
    <View style={styles.container}>
      <View style={styles.viewHeader}>
        <View style={styles.flexDirectionRowBetween}>
          <TouchableOpacity
            style={styles.backPress}
            activeOpacity={1}
            onPress={onGoBack}
          >
            <BackIcon />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={gotoThongTinLuanChuyenScreen}
            style={styles.thongTinLuanChuyen}
          >
            <ClockWhiteIcon />
          </TouchableOpacity>
        </View>
      </View>
      <KeyboardAwareScrollView
        bounces={false}
        showsVerticalScrollIndicator={false}
        enableOnAndroid={true}
        scrollEnabled={true}
        extraScrollHeight={100}
        keyboardShouldPersistTaps='handled'
        scrollToOverflowEnabled={true}
        enableAutomaticScroll={true}
        style={styles.cardView} >
        <TouchableOpacity onPress={onShowFullTrichYeu}>
          <Text style={styles.titleHeader} numberOfLines={2}>
            {TrichYeu}
          </Text>
        </TouchableOpacity>
        <View style={styles.dashed} />
        <TouchableOpacity
          style={styles.threeDotView}
          onPress={onChangeIsFullScren}
        >
          <ThreeDotIcon />
        </TouchableOpacity>
        {isFullScreen && (
          <View>
            <Text style={styles.title}>Loại văn bản</Text>
            <Text style={styles.content} numberOfLines={1}>
              {DocumentTypeFormat}
            </Text>
            <Text style={styles.title}>Nơi gửi</Text>
            <Text style={styles.content} numberOfLines={1}>
              {CoQuanGuiFormat}
            </Text>

            <View>
              <View style={styles.flexDirectionRowBetween}>
                <View style={styles.flexOne}>
                  <Text style={styles.title}>Ngày trên VB</Text>
                  <Text style={styles.content} numberOfLines={1}>
                    {DocumentDateFormat}
                  </Text>
                </View>
                <View style={styles.flexOne}>
                  <Text style={styles.title}>Ngày đến</Text>
                  <Text style={styles.content} numberOfLines={1}>
                    {ReceivedDateFormat}
                  </Text>
                </View>
              </View>
            </View>

            <View>
              <View style={styles.flexDirectionRowBetween}>
                <View style={styles.flexOne}>
                  <Text style={styles.title}>Số đến</Text>
                  <Text style={styles.content} numberOfLines={1}>
                    {SoDen}
                  </Text>
                </View>
                <View style={styles.flexOne}>
                  <Text style={styles.title}>Độ khẩn</Text>
                  <Text style={styles.content} numberOfLines={1}>
                    {DoKhan}
                  </Text>
                </View>
              </View>
            </View>
            <View>
              <View style={styles.flexDirectionRowBetween}>
                <View style={styles.flexOne}>
                  <Text style={styles.title}>Độ mật</Text>
                  <Text style={styles.content} numberOfLines={1}>
                    {DoMat}
                  </Text>
                </View>
                <View style={styles.flexOne}>
                  <Text style={styles.title}>Thời gian giải quyết</Text>
                  <Text style={styles.content} numberOfLines={1}>
                    {ThoiHanGQFormat}
                  </Text>
                </View>
              </View>
            </View>
            <View style={[styles.dashed, { marginHorizontal: 15 }]} />
          </View>
        )}

        {!checkIsEmpty(dataWaitProcessDocxAttachFile) && (
          <Text style={styles.documentFile}>Tài liệu đính kèm</Text>
        )}
        {!checkIsEmpty(dataWaitProcessDocxAttachFile) && (
          <FlatList
            style={styles.containerAttach}
            nestedScrollEnabled
            extraData={dataWaitProcessDocxAttachFile}
            disableVirtualization
            keyExtractor={(item, index) => item?.ID + index.toString()}
            data={dataWaitProcessDocxAttachFile}
            renderItem={({ item, index }) => (
              <ItemAttach item={item} index={index} />
            )}
          />
        )}
        <Text style={[styles.documentFile, { marginVertical: 15 }]}>
          Ý kiến lãnh đạo
        </Text>
        <View>
          {/* <TouchableOpacity
            onPress={onOpenModalYKienLanhDao}
            style={styles.yKienLanhDaoTouch}
          /> */}
          <TextInputCustom
            placeholder="Vui lòng nhập ý kiến"
            placeholderTextColor={colors.grey999}
            multiline
            onChangeText={onChangeYKienLanhDao}
            value={yKienLanhDao}
            style={styles.commentInput}
          />
        </View>
        {!arrayIsEmpty(dataWaitProcessDocxDetail?.CommentJson) && (
          <FlatList
            nestedScrollEnabled
            style={styles.commentJsonFlatlist}
            extraData={dataWaitProcessDocxDetail?.CommentJson}
            disableVirtualization
            horizontal={false}
            keyExtractor={(item) => item?.ID}
            data={dataWaitProcessDocxDetail?.CommentJson}
            renderItem={({ item, index }) => (
              <ItemVBDenCommentJson item={item} index={index} />
            )}
          />
        )}
        <View>
          {!arrayIsEmpty(dataWaitProcessDocxDetail?.TaskJson) && (
            <Text style={[styles.documentFile, { marginTop: 15 }]}>
              Tổ chức phân công thực hiện
            </Text>
          )}
          {!arrayIsEmpty(dataWaitProcessDocxDetail?.TaskJson) && (
            <FlatList
              nestedScrollEnabled
              style={styles.danhMucFlatList}
              extraData={dataWaitProcessDocxDetail?.TaskJson}
              disableVirtualization
              horizontal={false}
              keyExtractor={(item) => item?.ID}
              data={dataWaitProcessDocxDetail?.TaskJson}
              renderItem={({ item, index }) => (
                <ItemVBDenTaskJson
                  item={item}
                  index={index}
                  gotoNhiemVuDaPhanCongScreen={() =>
                    gotoNhiemVuDaPhanCongScreen(item, item?.ID)
                  }
                />
              )}
            />
          )}
          {!arrayIsEmpty(dataWaitProcessDocxDetail?.DonViXuLyJson) && (
            <Text style={[styles.documentFile, { marginTop: 15 }]}>Đơn vị</Text>
          )}
          {!arrayIsEmpty(dataWaitProcessDocxDetail?.DonViXuLyJson) && (
            <FlatList
              nestedScrollEnabled
              scrollEnabled={false}
              style={styles.danhMucFlatList}
              extraData={dataWaitProcessDocxDetail?.DonViXuLyJson}
              disableVirtualization
              keyExtractor={(item) => item?.ID}
              data={dataWaitProcessDocxDetail?.DonViXuLyJson}
              renderItem={({ item, index }) => (
                <ItemVBDenDonVi item={item} index={index} />
              )}
            />
          )}
        </View>
        <View style={{ marginBottom: 30 }} />
      </KeyboardAwareScrollView>

      {/* <FlatList
        nestedScrollEnabled
        scrollEnabled={false}
        extraData={ActionJson}
        disableVirtualization
        keyExtractor={(item) => String(item?.ID)}
        horizontal
        data={ActionJson}
        renderItem={({ item, index }) => (
          <ItemAction item={item} index={index} key={index} />
        )}
      /> */}
      {ActionJson && (
        <View style={[styles.actionView]}>
          {ActionJson?.map((item: any, index: any) => {
            return (
              <ItemAction
                key={index}
                item={item}
                index={index}
                onActionPress={onActionPress}
              />
            );
          })}
          {/* ActionJson.length >= 3 */}
          {ActionJson.length >= 3 && (
            <TouchableOpacity
              style={styles.actionMore}
              onPress={openModalActionOptional}
            >
              <ActionMoreIcon />
            </TouchableOpacity>
          )}
        </View>
      )}

      <LoadingView isLoading={isLoadingVBDen} />

      <OptionsKetThucModal
        ActionJson={ActionJson}
        modalVisible={modalOptionsKetThuc}
        onCloseModal={onCloseOptionsKetThucModal}
        onChooseOptionsKetThuc={onChooseOptionsKetThuc}
      />
      <ActionOptionalModal
        ActionJson={ActionJson}
        modalVisible={modalActionOptional}
        onCloseModal={onCloseActionOptionalModal}
        onChooseonActionMorePress={onActionPress}
      />
      <ChuyenXuLyModal
        modalVisible={modalChuyenXuLy}
        chuyenXuLyStringList={chuyenXuLyStringList}
        onCloseChuyenXuLyModal={onCloseChuyenXuLyModal}
        onChooseLanhDaoCongTy={onChooseLanhDaoCongTy}
        ykienlanhdao={yKienLanhDao}
        lanhDaoCongTyNameData={lanhDaoCongTyNameData}
        onChooseCCLanhDaoCongTy={onChooseCCLanhDaoCongTy}
        onConfirmChuyenXuLyModal={onConfirmChuyenXuLyModal}
      />
      <PhanCongModal
        modalVisible={modalPhanCong}
        onClosePhanCongModal={onClosePhanCongModal}
        onChoosePhongBan={() => onChoosePhongBan(ActionJsonType.PhanCong)}
        onChooseToChucPhanCong={() =>
          onChooseToChucPhanCong(ActionJsonType.PhanCong)
        }
        ykienlanhdao={yKienLanhDao}
        onConfirmModalPhanCong={(text) => onConfirmModalPhanCong(text)}
        dataPhongBanParams={filteredDataPhongBan}
        filteredDanhSachTochucPhanCong={filteredDanhSachTochucPhanCong}
        handleToggleDeletePhongban={handleToggleDeletePhongban}
        handleChooseDueDate={handleChooseDueDate}
        handleToggleDeleteDSToChucPhanCong={handleToggleDeleteDSToChucPhanCong}
        DocumentID={DocumentID}
      />
      <CalendarPickerPhanCongModal
        modalCalendarVisible={isOpenCalendarPhanCongPicker}
        onDateChangeModal={onDueDateDateChangeModal}
        onCloseModal={onCloseCalendarPickerPhanCongModal}
        resetToday={resetToday}
        removeSelectedDate={onRemoveSelectedDate}
        DueDate={DueDateParams}
        typePhanCong={typePhanCong}
      />
      <PhanCongLaiModal
        modalVisible={modalPhanCongLai}
        onClosePhanCongLaiModal={onClosePhanCongLaiModal}
        onChoosePhongBan={onChoosePhanConglaiPhongBan}
        onConfirmModalPhanCongLai={(text) => onConfirmModalPhanCongLai(text)}
        dataPhongBanParams={filteredDataPhongBan}
        taskJsonDetail={taskJsonDetail}
        handleToggleDeleteTaskJsonDetail={handleToggleDeleteTaskJsonDetail}
        handleToggleDeletePhongban={handleToggleDeletePhongban}
        handleChooseDueDate={handleChooseDueDate}
        DocumentID={DocumentID}
        ykienlanhdao={yKienLanhDao}
      />
      <BoSungThuHoiModal
        modalVisible={modalBoSungThuHoi}
        onConfirmModalBoSung={onConfirmModalBoSung}
        onConfirmModalThuHoi={onConfirmModalThuHoi}
        onCloseBoSungThuHoiModal={onCloseBoSungThuHoiModal}
        filteredDanhSachTochucPhanCong={filteredDanhSachTochucPhanCong}
        DonViXuLyJson={dataWaitProcessDocxDetail?.DonViXuLyJson}
        handleToggleDeleteTaskJsonDetail={handleToggleDeleteTaskJsonDetail}
        handleToggleDeleteToChucPhanCong={handleToggleDeleteDSToChucPhanCong}
        handleChooseDueDate={handleChooseDueDate}
        DocumentID={DocumentID}
        ykienlanhdao={yKienLanhDao}
        onChooseToChucPhanCong={() =>
          onChooseToChucPhanCong(ActionJsonType.BoSungThuHoi)
        }
        CommentJson={dataWaitProcessDocxDetail?.CommentJson}
      />
      <TraoDoiLaiModal
        modalVisible={modalTraoDoiLai}
        onCloseModalTraoDoiLai={onCloseModalTraoDoiLai}
        onConfirmModalTraoDoiLai={(text) => onConfirmModalTraoDoiLai(text)}
        yKienLanhDao={yKienLanhDao}
      />
      <KetThucModal
        modalVisible={modalKetThuc}
        onCloseModalKetThuc={onCloseModalKetThuc}
        onConfirmModalKetThuc={(text, DocumentID) => onConfirmModalKetThuc(text, DocumentID)}
        DocumentID={DocumentID}
        ykienlanhdao={yKienLanhDao}
      />
      <ChiaSeModal
        modalVisible={modalChiaSe}
        onCloseModalChiaSe={onCloseModalChiaSe}
        onConfirmModalChiaSe={(text) => onConfirmModalChiaSe(text)}
        DocumentID={DocumentID}
        ykienlanhdao={yKienLanhDao}
        onChooseTypeChiaSe={onChooseTypeChiaSe}
        chiaSeStringList={chiaSeStringList}
      />

      <ChuyenPhanCongModal
        modalVisible={chuyenPhanCongModal}
        onCloseModalChuyenPhanCong={onCloseModalChuyenPhanCong}
        onConfirmModalChuyenPhanCong={onConfirmModalChuyenPhanCong}
        yKienLanhDao={yKienLanhDao}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
  thongTinLuanChuyen: { padding: 3 },
  scrollView: {
    flex: 1,
    paddingBottom: 30,
  },
  cardView: {
    backgroundColor: "#FFFFFF",
    margin: 16,
    borderRadius: 8,
    paddingVertical: 15,
  },
  threeDotView: {
    alignSelf: "flex-end",
    marginRight: 10,
    padding: 10,
  },
  item: {},
  containerAttach: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    marginHorizontal: 15,
    overflow: "hidden",
  },
  dashed: {
    borderStyle: "dashed",
    borderTopWidth: 1,
    borderTopColor: "#E5E5E5",
    marginVertical: 15,
  },
  flexOne: {
    flex: 1,
  },
  content: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginBottom: 10,
  },
  contenAttach: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  title: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  documentFile: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginLeft: 15,
    marginBottom: 10,
  },
  documentFileView: {
    padding: 15,
  },
  viewHeader: {
    backgroundColor: colors.primary,
    height: 55,
    justifyContent: "center",
    width: "100%",
    paddingRight: 15,
    paddingLeft: 7,
  },
  titleHeader: {
    fontSize: FontSize.MEDIUM,
    color: colors.scienceBlue,
    fontWeight: "700",
    fontFamily: "arial",
    paddingHorizontal: 15,
  },
  titleDocumentFile: {
    fontSize: FontSize.MEDIUM,
    color: colors.scienceBlue,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    borderRadius: 4,
  },
  sizeDocumentFile: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    borderRadius: 4,
    marginTop: 5
  },
  flexDirectionRowBetween: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  flexDirectionRowAction: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  backPress: {
    padding: 8,
  },
  tabBarLabelActive: {
    color: colors.white,
    fontWeight: "400",
    fontSize: 18,
    marginLeft: 12,
  },
  viewTabBottomBar: {
    flexDirection: "row",
    height: dimensWidth(68),
    alignItems: "center",
    backgroundColor: colors.blueMedium,
  },
  bottomTab: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
  },
  viewButton: {
    flex: 1,
    alignItems: "center",
  },
  actionMore: {
    padding: 8,
  },
  actionView: {
    height: dimensWidth(68),
    backgroundColor: colors.blueMedium,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  shareButton: {
    flex: 1,
  },
  commentInput: {
    paddingHorizontal: 10,
    borderColor: "#DDDDDD",
    borderWidth: 1,
    borderRadius: 3,
    height: 100,
    marginHorizontal: 15,
    textAlignVertical: "top",
  },
  titleVbDenTheoMuc: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    borderRadius: 4,
    marginBottom: 4,
  },
  titleCommentJson: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    borderRadius: 4,
  },
  positionComment: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    borderRadius: 4,
  },
  viewTrangThai: {
    height: dimensWidth(22),
    width: dimensWidth(90),
    borderRadius: 3,
    backgroundColor: "#F0F0F0",
    justifyContent: "center",
    alignItems: "center",
  },
  textTrichYeu: {
    flex: 1,
    fontSize: dimensWidth(13),
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 10,
  },
  textPosition: {
    flex: 1,
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 10,
  },
  textTrangThai: {
    fontSize: dimensWidth(12),
    color: "#626262",
    fontWeight: "400",
    fontFamily: "arial",
  },
  danhMucItemView: {
    backgroundColor: colors.white,
    padding: 15,
  },
  hoanTatTextColor: {
    color: "#3ABA32",
  },
  hoanTatBackGroundColor: {
    backgroundColor: "#E6FFE4",
  },
  danhMucFlatList: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    marginHorizontal: 15,
    overflow: "hidden",
  },
  commentJsonFlatlist: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    margin: 15,
    overflow: "hidden",
  },
  yKienLanhDaoTouch: {
    zIndex: 999,
    position: "absolute",
    height: "100%",
    width: "100%",
  },
});

export default App;
