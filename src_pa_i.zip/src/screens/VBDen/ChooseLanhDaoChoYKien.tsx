import React, { useCallback, useState, useEffect } from "react";
import {
  SafeAreaView,
  View,
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  Platform,
} from "react-native";
import {
  BackIcon,
  SelectedDisableIcon,
  SelectedEnalbleIcon,
} from "assets/SVG/index";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import {
  arrayIsEmpty,
  format_yy_mm_dd,
  removeSpecialCharacters,
} from "helpers/formater";
import moment from "moment";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { splitID } from "helpers/formater";

type ItemProps = {
  item: any;
  lanhDaoCongTyNameData: any;
  chooseTypePress: ({ Title, ID }: any) => void;
  index: number;
  type: string;
  ID: string;
};
type Props = {
  navigation: any;
  route: any;
};

const Item = ({
  item,
  chooseTypePress,
  index,
  ID,
}: ItemProps) => {
  const { Title, Position, isSellected = false } = item;
  return (
    <TouchableOpacity
      style={[styles.item, index === 0 && { borderTopWidth: 0 }]}
      onPress={() => chooseTypePress(ID)}
    >
      <View>
        <Text style={styles.Title}>{Title}</Text>
        <Text style={styles.position}>{removeSpecialCharacters(Position)}</Text>
      </View>
      <View>
        {isSellected ? <SelectedEnalbleIcon /> : <SelectedDisableIcon />}
      </View>
    </TouchableOpacity>
  );
};

const App = ({ navigation, route }: Props) => {
  // const navigation = useNavigation();
  const [listBanLanhDao, setListBanLanhDao] = useState<any>([]);
  const chooseTypePress = useCallback(
    (ID: number) => {
      const newData = listBanLanhDao.map((it: any) => {
        const newIT =
          it.ID === ID
            ? { ...it, isSellected: true }
            : { ...it, isSellected: false };
        return newIT;
      });

      navigation.navigate({
        name: "VBDenScreen",
        params: { lanhDaoNameSellectedParam: newData },
      });
    },

    [navigation, listBanLanhDao]
  );
  const onGoBack = useCallback(() => {
    navigation.navigate({
      name: "VBDenScreen",
      params: {
        lanhDaoNameSellectedParam: route.params?.lanhDaoNameSellectedParam,
      },
    });
  }, [route.params?.lanhDaoNameSellectedParam]);
  useEffect(() => {
    if (!arrayIsEmpty(route.params?.lanhDaoNameSellectedParam)) {
      setListBanLanhDao(route.params?.lanhDaoNameSellectedParam);
    }
  }, [route.params?.lanhDaoNameSellectedParam]);

  return (
    <View style={styles.container}>
      <View style={styles.viewHeader}>
        <View style={styles.flexDirectionRow}>
          <TouchableOpacity
            style={styles.backPress}
            activeOpacity={1}
            onPress={onGoBack}
          >
            <BackIcon />
          </TouchableOpacity>
          <Text style={styles.TitleHeader}>Lãnh đạo cho ý kiến</Text>
        </View>
      </View>

      <FlatList
        contentContainerStyle={styles.flatlist}
        extraData={listBanLanhDao}
        data={listBanLanhDao}
        renderItem={({ item, index }) => (
          <Item
            index={index}
            item={item}
            ID={item?.ID}
            lanhDaoCongTyNameData={route?.params?.lanhDaoCongTyNameData}
            chooseTypePress={chooseTypePress}
          />
        )}
        keyExtractor={(item) => item?.ID}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
  flatlist: {
    backgroundColor: "#FFFFFF",
    margin: 16,
    borderRadius: 8,
  },
  item: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 20,
    borderStyle: "dashed",
    borderTopWidth: 1,
    borderTopColor: "#E5E5E5",
  },
  Title: {
    fontSize: FontSize.LARGE,
    lineHeight: dimensWidth(20),
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  position: {
    fontSize: dimensWidth(13),
    lineHeight: dimensWidth(20),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginTop: 5,
  },
  viewHeader: {
    backgroundColor: colors.primary,
    height: 55,
    justifyContent: "center",
    width: "100%",
    paddingHorizontal: 10,
  },
  TitleHeader: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  backPress: {
    padding: 8,
  },
});

export default App;
