import React, { useCallback, useState, useEffect, useMemo, useLayoutEffect } from "react";
import {
  SafeAreaView,
  View,
  FlatList,
  Text,
  StatusBar,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  RefreshControl,
  StyleSheet,
} from "react-native";
import styles from "./WaitProcessDocx.Style";
import {
  calculateBetweenTwoDate,
  formatCreatedDate,
  arrayIsEmpty,
  checkIsEmpty,
  format_yy_mm_mm_dd_hh,
  format_dd_mm_yy,
  removeSpecialCharacters,
  isNullOrUndefined
} from "helpers/formater";
import { SearchIcon, FilterIcon, LaCoIcon, MenuIcon } from "assets/SVG/index";
import FilterModal from "./components/FilterModal";
import { RootState } from "stores";
import SearchInput from "~/components/SearchInput";
import colors from "themes/Colors";
import { fetchBanLanhDao } from "stores/home/reducer";
import { fetchVBDenApi, } from "stores/vbDen/reducer";
import { useDispatch, useSelector } from "react-redux";
import CalendarPickerModal from "./components/CalendarPickerModal";
import moment from "moment";
import { NoDataView } from "components";
import { ThunkDispatch } from "@reduxjs/toolkit";
import FastImage from "react-native-fast-image";
import { BaseUrl } from "~/services/api";
import { TABNAME, TinhTrangType, TrinhLanhDaoType } from './VBDenType'
import { funtionVBDenData } from "~/themes/const";
import CachedImage from "~/components/CacheImage";
import ImageLoad from "~/components/ImageLoad";

type Props = {
  navigation: any;
  route: any;
};

const Item = ({ item, token, subSite, gotoDetail }: any) => {
  const {
    ID,
    ImagePath,
    Title,
    Created,
    TrangThai,
    TrichYeu,
    SoDen,
    DocumentID,
    CoQuanGui,
    DoKhan
  } = item;
  const gotoDetailPress = () => {
    gotoDetail(ID);
  };

  const formatCreated = formatCreatedDate(Created);
  return (
    <TouchableOpacity style={styles.item} onPress={gotoDetailPress}>
      <ImageLoad
        style={styles.itemAvatar}
        source={{
          uri: BaseUrl + `/${subSite}` + ImagePath,
          headers: { Authorization: `${token}` },
          priority: FastImage.priority.normal
        }}
      />
      <View style={{ flex: 1 }}>
        <View style={styles.flexDirectionBetween}>
          <Text style={styles.title} numberOfLines={2}>
            {removeSpecialCharacters(CoQuanGui)}
          </Text>
          <Text style={styles.date}>{formatCreated}</Text>
        </View>
        <View style={styles.flexDirectionBetween}>
          <Text style={styles.category}>{"Văn bản đến"}</Text>
          <Text style={styles.textSoDen}>{Title}</Text>
        </View>

        <Text style={styles.title}>{TrichYeu}</Text>
        <View style={styles.chuyenDonViRow}>
          <View style={styles.touchSendUnit}>
            <Text style={styles.textSendUnit}>{TrangThai}</Text>
          </View>
          {(DoKhan === "Thượng khẩn" || DoKhan === "Hỏa tốc") && <LaCoIcon />}
        </View>
      </View>
    </TouchableOpacity>
  );
};

const ItemVbDenTitle = ({ item, gotoDetail, tabName, token, subSite }: any) => {
  const {
    SendUnit,
    ListName,
    ImagePath,
    Title,
    Status,
    SiteName,
    Created,
    DueDate,
    Action,
    Read,
    DocumentID,
    Priority,
    TaskCategory
  } = item;
  const gotoDetailPress = () => {
    gotoDetail(DocumentID);
  };
  let dueDateFormat = ""
  let isExpired = false
  let isExpiredToday = false
  const distanceDate = calculateBetweenTwoDate(DueDate);
  if (!checkIsEmpty(distanceDate)) {
    if (parseInt(distanceDate) < 0) {
      dueDateFormat = format_dd_mm_yy(DueDate);
    } else if (parseInt(distanceDate) >= 0 && parseInt(distanceDate) < 1) {
      dueDateFormat = "Hạn hôm nay";
      isExpiredToday = true
    }
    else {
      isExpired = true
      dueDateFormat = "Quá hạn " + distanceDate + " ngày";
    }
  }
  const formatCreated = formatCreatedDate(Created);
  return (
    <TouchableOpacity style={styles.item} onPress={gotoDetailPress}>
      <ImageLoad
        style={styles.itemAvatar}
        source={{
          uri: BaseUrl + `/${subSite}` + ImagePath,
          headers: { Authorization: `${token}` },
          priority: FastImage.priority.normal
        }}
      />
      <View style={{ flex: 1 }}>
        <View style={styles.flexDirectionBetween}>
          <Text style={styles.title} numberOfLines={2}>
            {SendUnit}
          </Text>
          <Text style={styles.date}>{formatCreated}</Text>
        </View>

        <View style={{
          flexDirection: 'row'
        }}>
          <Text style={[{ flex: 1 }, styles.category]}>{ListName}</Text>
          <Text style={styles.category} numberOfLines={1}>{TaskCategory}</Text>
        </View>
        <Text style={[styles.title, tabName === TABNAME.VBChoXuLy && !Read && { fontWeight: '700' }]}>{Title}</Text>

        <View style={[styles.chuyenDonViRow, Priority && {
          justifyContent: 'space-between',
        }]}>
          <View style={styles.touchSendUnit}>
            <Text style={styles.textSendUnit}>{Action}</Text>
          </View>
          <View style={[styles.flexDirectionBetween, Priority ==
            1 && { flex: 1 }]}>
            {Priority ==
              1 && <LaCoIcon />}
            <Text
              style={[
                styles.date,
                isExpiredToday && styles.todayDeadlife,
                isExpired && styles.distanceDate,
              ]}
            >
              {Status === 1 ? "" : dueDateFormat}
            </Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const renderFooter = (isLoading: boolean, refreshing: boolean, isLoadMoreVbDen: boolean, Offset: any) => {
  return (
    //Footer View with Load More button
    <View style={styles.footer}>
      {isLoading && !refreshing && isLoadMoreVbDen && Offset !== 0 ? (
        <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
      ) : null}
    </View>
  );
};

const VBDenScreen = ({ route, navigation }: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  let initialPayloadVBDen = { status: 0, FilterText: "", TinhTrang: "", BanLanhDao: "", FromDate: "", ToDate: "" }
  const { totalRecord, isLoadingVBDen, isLoadMoreVbDen, isGoBackVBDenScreen, dataVBDen, totalRecordVbDen } = useSelector(
    (state: any) => state.vbDenReducer
  );
  const { subSite, token } = useSelector(
    (state: any) => state.login
  );
  const todayFormated = moment().format("YYYY-MM-DD");
  const prevMonth = moment(todayFormated).add(-1, "M").format("YYYY-MM-DD");
  const [tabName, setTabName] = useState(TABNAME.VBChoXuLy);
  const [funtionVBDen, setFuntionVBDen] = useState(funtionVBDenData.VBDenTitle);
  const [visbleModalFilter, setVisbleModalFiltert] = useState(false);
  const [dataVBDenState, setDataVBDenState] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [tinhTrangSellectedState, settinhTrangSellectedState] = useState(TinhTrangType.TAT_CA);
  const [lanhDaoNameSellectedState, setLanhDaoNameSellectedState] =
    useState<any>([]);
  const [startDate, setStartDate] = useState(prevMonth);
  const [endDate, setEndDate] = useState(todayFormated);
  const [isOpenCalendarPicker, setIsOpenCalendarPicker] = useState(false);
  const [typeModal, setTypeModal] = useState("startDate");
  const [filterText, setFilterText] = useState("");
  const [Offset, setOffset] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const [payloadVBDen, setPayloadVBDen] = useState<any>(initialPayloadVBDen);
  const { dataBanLanhDao } = useSelector((state: RootState) => state.home);
  const [isFilter, setIsFilter] = useState(false)

  useEffect(() => {
    if (route.params?.funtionVBDen) {
      setFuntionVBDen(route.params?.funtionVBDen)
      setOffset(0)
    }
  }, [route.params])

  const fetchVBDenRequest = useCallback((payload: any) => {
    dispatch(fetchVBDenApi(payload));
  }, [dispatch]);
  const fetchBanLanhDaoRequest = useCallback(async (subSite: any) => {
    dispatch(fetchBanLanhDao(subSite));
  }, [dispatch]);
  useEffect(() => {
    fetchBanLanhDaoRequest(subSite);
  }, [fetchBanLanhDaoRequest, subSite]);
  useEffect(() => {
    if (!arrayIsEmpty(route.params?.lanhDaoNameSellectedParam)) {
      setVisbleModalFiltert(true);
      setLanhDaoNameSellectedState(route.params?.lanhDaoNameSellectedParam);
    } else {
      if (!arrayIsEmpty(dataBanLanhDao)) {
        const newData = dataBanLanhDao.map((it: any) => it = { ...it, isSellected: false })
        setLanhDaoNameSellectedState([{ ID: 999, LanhDao: TrinhLanhDaoType.TAT_CA, Orders: -1, Title: TrinhLanhDaoType.TAT_CA, isSellected: true }, ...newData]);
      }
    }

  }, [dataBanLanhDao, route.params?.lanhDaoNameSellectedParam]);
  const lanhDaoNameSellectedFilter = useMemo(
    () => {
      if (!arrayIsEmpty(lanhDaoNameSellectedState)) {
        const newData = lanhDaoNameSellectedState?.find((it: any) => it.isSellected)?.Title;
        return newData ? newData : ""
      }
      return "Tất cả"
    },
    [navigation, lanhDaoNameSellectedState]
  );

  useEffect(() => {
    const status = tabName === TABNAME.VBChoXuLy ? 0 : 1
    const FilterText = filterText
    fetchVBDenRequest({ ...payloadVBDen, status, FilterText, Offset, funtionVBDen, subSite });
  }, [payloadVBDen, tabName, filterText, Offset, funtionVBDen, subSite]);

  useEffect(() => {
    if (route?.params?.tinhTrangSellected) {
      setVisbleModalFiltert(true);
      settinhTrangSellectedState(route?.params?.tinhTrangSellected);
    }
  }, [route]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    setOffset(0);
    setPayloadVBDen(initialPayloadVBDen)
    onReFilterModalPress();
    setFilterText("")
    dispatch(fetchVBDenApi(initialPayloadVBDen));
  }, [refreshing,]);

  const onPressFilter = useCallback(() => {
    if (isSearching) setIsSearching(false);
    setVisbleModalFiltert(true);
  }, [visbleModalFilter]);
  const onPressSearch = useCallback(() => {
    if (visbleModalFilter) setVisbleModalFiltert(false);
    if (funtionVBDen.key === 'VBDenTitle' && isSearching) {
      setOffset(0)
      setFilterText("")
    }
    setIsSearching(!isSearching);
  }, [isSearching, visbleModalFilter, funtionVBDen]);

  const onConfirmModalPress = useCallback(() => {
    const TinhTrang = tinhTrangSellectedState === TinhTrangType.TAT_CA ? "" : tinhTrangSellectedState
    const BanLanhDao = lanhDaoNameSellectedFilter === TinhTrangType.TAT_CA ? "" : lanhDaoNameSellectedFilter
    const FromDate = startDate
    const ToDate = endDate
    const newPayload = { ...payloadVBDen, BanLanhDao, TinhTrang, FromDate, ToDate }

    setPayloadVBDen(newPayload)
    setVisbleModalFiltert(false);
    setIsFilter(true)
  }, [payloadVBDen, tinhTrangSellectedState, lanhDaoNameSellectedFilter, startDate, endDate]);

  const onReFilterModalPress = useCallback(() => {
    setStartDate(prevMonth);
    setEndDate(todayFormated);
    if (!arrayIsEmpty(dataBanLanhDao)) {
      const newData = dataBanLanhDao.map((it: any) => it = { ...it, isSellected: false })
      setLanhDaoNameSellectedState([{ ID: 999, LanhDao: TrinhLanhDaoType.TAT_CA, Orders: -1, Title: TrinhLanhDaoType.TAT_CA, isSellected: true }, ...newData]);
    }

    if (funtionVBDen.key === 'VBDenTitle' || funtionVBDen.key === 'VBDenTatCa') {
      settinhTrangSellectedState(TinhTrangType.TAT_CA);
    } else if (funtionVBDen.key === 'VBDenChoChoYKien') {
      settinhTrangSellectedState(TinhTrangType.TRINH_LANH_DAO);
    } else if (funtionVBDen.key === 'VBDenChoThucHien') {
      settinhTrangSellectedState(TinhTrangType.CHUYEN_DON_VI);
    } else {
      settinhTrangSellectedState(TinhTrangType.HOAN_TAT);
    }

    setIsFilter(false)
    setOffset(0)
    setVisbleModalFiltert(false)
    let initialPayloadVBDen = { status: 0, FilterText: "", TinhTrang: "", BanLanhDao: "", FromDate: "", ToDate: "" }
    setPayloadVBDen(initialPayloadVBDen)
  }, [dataBanLanhDao, funtionVBDen]);

  const onPressProcessedDocx = useCallback(() => {
    if (funtionVBDen.key === 'VBDenTitle' && isFilter) {
      onReFilterModalPress()
    }

    setOffset(0)
    setTabName(TABNAME.VBDaXuLy);
  }, [isFilter, funtionVBDen]);
  const onPressWaitProcesseDocx = useCallback(() => {
    if (funtionVBDen.key === 'VBDenTitle' && isFilter) {
      onReFilterModalPress()
    }

    setOffset(0)
    setTabName(TABNAME.VBChoXuLy);
  }, [isFilter, funtionVBDen]);

  useEffect(() => {
    setDataVBDenState(dataVBDen);
    setRefreshing(false);
  }, [dataVBDen]);

  useEffect(() => {
    if (funtionVBDen.key === 'VBDenTitle' || funtionVBDen.key === 'VBDenTatCa') {
      settinhTrangSellectedState(TinhTrangType.TAT_CA);
    } else if (funtionVBDen.key === 'VBDenChoChoYKien') {
      settinhTrangSellectedState(TinhTrangType.TRINH_LANH_DAO);
    } else if (funtionVBDen.key === 'VBDenChoThucHien') {
      settinhTrangSellectedState(TinhTrangType.CHUYEN_DON_VI);
    } else {
      settinhTrangSellectedState(TinhTrangType.HOAN_TAT);
    }
  }, [funtionVBDen])

  useEffect(() => {
    if (isGoBackVBDenScreen) {
      setStartDate("");
      setEndDate("");
      settinhTrangSellectedState(TinhTrangType.TAT_CA);
      setFilterText("");
      setOffset(0)
      setPayloadVBDen(initialPayloadVBDen);
    }
  }, [isGoBackVBDenScreen, fetchVBDenRequest]);

  const onPressChooseType = useCallback(() => {
    if (funtionVBDen.key === 'VBDenTitle' || funtionVBDen.key === 'VBDenTatCa') {
      setVisbleModalFiltert(false);
      navigation.navigate({
        name: "TinhTrangFilterScreen",
        params: { tinhTrangSellected: tinhTrangSellectedState },
      });
    }
  }, [tinhTrangSellectedState, funtionVBDen]);

  const onPressChooseLanhDao = useCallback(() => {
    setVisbleModalFiltert(false);
    navigation.navigate({
      name: "ChooseLanhDaoChoYKienScreen",
      params: { lanhDaoNameSellectedParam: lanhDaoNameSellectedState },
    });
  }, [lanhDaoNameSellectedState]);

  const onPressOpenCalendarPicker = useCallback(
    (typeModal: string) => {
      setVisbleModalFiltert(false);
      setTypeModal(typeModal);
      setIsOpenCalendarPicker(true);
    },
    [isOpenCalendarPicker, typeModal]
  );

  const onDateChangeModal = useCallback(
    (date: any) => {
      if (typeModal == "startDate") {
        setStartDate(date);
      } else {
        setEndDate(date);
      }
      setIsOpenCalendarPicker(false);
      setVisbleModalFiltert(true);
    },
    [typeModal, startDate, endDate]
  );
  const onCloseModal = useCallback(() => {
    setIsOpenCalendarPicker(false);
  }, []);
  const onChangeFilterText = useCallback(
    (text: string) => {
      if (Offset != 0) setOffset(0)
      setFilterText(text);
    },
    [Offset]
  );
  const removeSelectedDate = useCallback(() => {
    if (typeModal == "startDate") {
      setStartDate("");
    } else {
      setEndDate("");
    }
  }, [typeModal, startDate, endDate]);
  const resetToday = useCallback(
    (today: any) => {
      if (typeModal == "startDate") {
        setStartDate(today);
      } else {
        setEndDate(today);
      }
    },
    [typeModal, startDate, endDate]
  );
  const gotoDetailPress = useCallback((DocumentID: Number, ListName: string) => {
    navigation.navigate({
      name: "WaitProcessDocxDetailScreen",
      params: { DocumentID, ListName },
    });
    const newData = dataVBDen.map((it: any) => it.DocumentID === DocumentID ? { ...it, Read: true } : it)
    setDataVBDenState(newData);
  }, [dataVBDen]);
  const handleLoadmore = (() => {
    if (totalRecord > dataVBDen.length) {
      const newOffset = dataVBDen.length;
      setOffset(newOffset);
      setPayloadVBDen({ ...payloadVBDen, Offset: newOffset })
    }
  });
  const openDrawer = useCallback(() => {
    navigation.openDrawer();
  }, [navigation]);

  return (
    <View style={styles.container}>
      <View style={styles.viewAvatar}>
        <View style={styles.flexDirectionRow}>
          <View style={styles.flexDirectionRow}>
            <TouchableOpacity onPress={openDrawer}>
              <View
                style={styles.avatar}
              >
                <MenuIcon color='#fff' />
              </View>
            </TouchableOpacity>
            <Text style={styles.titleAvatar}>{`${funtionVBDen.title} - ${subSite.toUpperCase()}`} </Text>
          </View>
          <View style={styles.flexDirectionRow}>
            <TouchableOpacity style={styles.searchIcon} onPress={onPressSearch}>
              <SearchIcon color={!isSearching ? colors.white : 'red'} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.filterIcon} onPress={onPressFilter}>
              <FilterIcon color={isFilter ? 'red' : '#fff'} />
            </TouchableOpacity>
          </View>
        </View>
        {!isSearching && funtionVBDen.key === 'VBDenTitle' ? (
          <View style={styles.flexDirectionRowTab}>
            <TouchableOpacity
              activeOpacity={1}
              onPress={onPressWaitProcesseDocx}
              style={
                tabName === TABNAME.VBChoXuLy
                  ? styles.onPressActiveTab
                  : styles.onPressInActiveTab
              }
            >
              <Text
                style={
                  tabName === TABNAME.VBChoXuLy
                    ? styles.titleActiveTab
                    : styles.titleInActiveTab
                }
              >
                {TABNAME.VBChoXuLy}
                <Text style={styles.titleNotifyCount}>{` (${totalRecordVbDen})`}</Text>
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              activeOpacity={1}
              onPress={onPressProcessedDocx}
              style={
                tabName === TABNAME.VBDaXuLy
                  ? styles.onPressActiveTab
                  : styles.onPressInActiveTab
              }
            >
              <Text
                style={
                  tabName === TABNAME.VBDaXuLy
                    ? styles.titleActiveTab
                    : styles.titleInActiveTab
                }
              >
                {TABNAME.VBDaXuLy}
              </Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={{ marginTop: 10 }}>
            <SearchInput
              onChangeFilterText={onChangeFilterText}
              filterText={filterText}
            />
          </View>
        )}
      </View>
      {!arrayIsEmpty(dataVBDenState) ? (
        <FlatList
          contentContainerStyle={styles.containerFlatList}
          data={dataVBDenState}
          extraData={dataVBDenState}
          refreshControl={
            <RefreshControl refreshing={isLoadingVBDen} onRefresh={onRefresh} tintColor='#0054AE' />
          }
          renderItem={({ item }) => {
            if (funtionVBDen === funtionVBDenData.VBDenTitle) {
              return (
                <ItemVbDenTitle item={item} token={token} subSite={subSite} gotoDetail={gotoDetailPress} tabName={tabName} />
              )
            } else {
              return (
                <Item item={item} token={token} subSite={subSite} gotoDetail={gotoDetailPress} />
              )
            }
          }}
          keyExtractor={(item, index) => String(index)}
          showsVerticalScrollIndicator={false}
          onEndReachedThreshold={0.5}
          onEndReached={handleLoadmore}
          ListFooterComponent={renderFooter(isLoadingVBDen, refreshing, isLoadMoreVbDen, Offset)}
        />
      ) : (
        <NoDataView />
      )}

      <FilterModal
        onPressWaitProcesseDocx={onPressWaitProcesseDocx}
        onPressProcessedDocx={onPressProcessedDocx}
        onPressFilter={onPressFilter}
        confirmText={"Áp dụng"}
        refilterText={"Thiết lập lại"}
        modalVisible={visbleModalFilter}
        onConfirmModal={onConfirmModalPress}
        onReFilterModal={onReFilterModalPress}
        tinhTrangSellected={tinhTrangSellectedState}
        funtionVBDen={funtionVBDen}
        onPressChooseType={onPressChooseType}
        onPressChooseLanhDao={onPressChooseLanhDao}
        onPressSearch={onPressSearch}
        onPressOpenCalendarPicker={onPressOpenCalendarPicker}
        startDate={startDate}
        endDate={endDate}
        lanhDaoNameSellectedFilter={lanhDaoNameSellectedFilter}
      />
      <CalendarPickerModal
        modalCalendarVisible={isOpenCalendarPicker}
        onDateChangeModal={onDateChangeModal}
        onCloseModal={onCloseModal}
        startDate={startDate}
        endDate={endDate}
        typeModal={typeModal}
        removeSelectedDate={removeSelectedDate}
        resetToday={resetToday}
      />
    </View>
  );
};

export default VBDenScreen;
