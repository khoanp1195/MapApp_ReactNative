import React, { useCallback, useState, useEffect } from "react";
import {
  SafeAreaView,
  View,
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  Platform,
} from "react-native";
import stylesMain from "./WaitProcessDocx.Style";
import {
  BackIcon,
  SellectedBoxIcon,
  UnSellectedBoxIcon,
  DoneIcon,
} from "assets/SVG/index";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import { fetchUsersAndGroup } from "stores/home/reducer";
import { useDispatch, useSelector } from "react-redux";
import SearchInput from "~/components/SearchInput"
import { ActionJsonType } from "./VBDenType";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { format_yy_mm_dd, removeAccent, removeSpecialCharacters } from "helpers/formater";
import moment from "moment";
import FastImage from 'react-native-fast-image'
import { BaseUrl } from "~/services/api";

type ItemProps = {
  index: number;
  typeModal: any;
  item: any;
  token: any;
  subSite: any;
  chooseTypePress: (ID: string) => void;
};
type Props = {
  navigation: any;
  route: any;
};

const Item = ({ item, chooseTypePress, token, subSite, index, typeModal }: ItemProps) => {
  const { FullName, ID, isSellectedCChiaSe, isSellectedChuyenXuLy, Position, ImagePath } =
    item;
  const selected =
    typeModal === ActionJsonType.ChiaSe
      ? isSellectedCChiaSe
      : isSellectedChuyenXuLy;
  return (
    <TouchableOpacity
      style={[styles.item, index === 0 && { borderTopWidth: 0 }]}
      onPress={() => chooseTypePress(ID)}
    >
      <FastImage
        style={{ width: 40, height: 40 }}
        source={{
          uri: BaseUrl + `/${subSite}` + ImagePath,
          headers: { Authorization: `${token}` },
          priority: FastImage.priority.normal,
        }}
        resizeMode={FastImage.resizeMode.contain}
      />
      <View style={styles.viewItemContent}>
        <Text style={styles.title} numberOfLines={1}>{FullName}</Text>
        <Text style={styles.position}>{removeSpecialCharacters(Position)}</Text>
      </View>
      <View>{selected ? <SellectedBoxIcon /> : <UnSellectedBoxIcon />}</View>
    </TouchableOpacity>
  );
};

const App = ({ navigation, route }: Props) => {
  const { dataUsersAndGroup } = useSelector((state: RootState) => state.home);
  const [danhSachUsersAndGroup, SetDanhSachUsersAndGroup] = useState([]);
  const [filterdanhSachUsersAndGroup, setFilterdanhSachUsersAndGroup] =
    useState([]);
  const [filterText, setFilterText] = useState("");
  const { subSite, token } = useSelector(
    (state: any) => state.login
  );
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const fetchUsersAndGroupRequest = useCallback((payload: any) => {
    dispatch(fetchUsersAndGroup(payload));
  }, [dispatch]);
  useEffect(() => {
    if (!route?.params?.danhSachUsersAndGroup && subSite && dataUsersAndGroup) {
      fetchUsersAndGroupRequest(subSite);
    }
  }, [fetchUsersAndGroupRequest, subSite, route?.params?.danhSachUsersAndGroup]);
  useEffect(() => {
    if (route?.params?.danhSachUsersAndGroup) {
      if (route.params.chiaSeStringList || route.params.chuyenXuLyStringList) {
        SetDanhSachUsersAndGroup(route.params?.danhSachUsersAndGroup);
      } else {
        const newData = route.params?.danhSachUsersAndGroup.map(
          (it) =>
          (it = {
            ...it,
            isSellectedCChiaSe: false,
            isSellectedChuyenXuLy: false,
          })
        );
        SetDanhSachUsersAndGroup(newData);
      }
    }

    if (!route?.params?.danhSachUsersAndGroup && dataUsersAndGroup) {
      const tmp = dataUsersAndGroup.map(
        (it) =>
        (it = {
          ...it,
          isSellectedCChiaSe: false,
          isSellectedChuyenXuLy: false,
        })
      );
      SetDanhSachUsersAndGroup(tmp);
    }
  }, [
    dataUsersAndGroup,
    route?.params?.danhSachUsersAndGroup,
    navigation,
    route.params?.chiaSeStringList,
    route.params?.chuyenXuLyStringList,
  ]);

  const onGoBack = useCallback(() => {
    navigation.navigate({
      name: "WaitProcessDocxDetailScreen",
      params: {
        typeModal: route.params?.typeModal,
        danhSachUsersAndGroup: route?.params?.danhSachUsersAndGroup,
      },
    });
  }, []);
  const chooseTypePress = useCallback(
    (ID) => {
      let tmp = [];
      if (route?.params?.typeModal === ActionJsonType.ChiaSe) {
        tmp = danhSachUsersAndGroup.map((it: any) =>
          it.ID === ID
            ? { ...it, isSellectedCChiaSe: !it.isSellectedCChiaSe }
            : it
        );
        SetDanhSachUsersAndGroup(tmp);
      } else {
        tmp = danhSachUsersAndGroup.map((it: any) =>
          it.ID === ID
            ? { ...it, isSellectedChuyenXuLy: !it.isSellectedChuyenXuLy }
            : it
        );
      }
      SetDanhSachUsersAndGroup(tmp);
    },
    [danhSachUsersAndGroup]
  );

  const onDonePress = useCallback(() => {
    navigation.navigate({
      name: "WaitProcessDocxDetailScreen",
      params: { danhSachUsersAndGroup, typeModal: route.params?.typeModal },
    });
  }, [navigation, danhSachUsersAndGroup]);

  const onChangeFilterText = useCallback(
    (text: string) => {
      setFilterText(text);
    },
    [filterText]
  );
  useEffect(() => {
    const tmp = removeAccent(filterText)
    const filteredArray = danhSachUsersAndGroup.filter((item: any) =>
    removeAccent(item?.FullName).includes(tmp) || item?.AccountName.includes(tmp)
    );
    setFilterdanhSachUsersAndGroup(filteredArray);
  }, [filterText, danhSachUsersAndGroup]);

  return (
    <View style={styles.container}>
      <View style={styles.viewHeader}>
        <View style={styles.flexDirectionRow}>
          <TouchableOpacity
            style={styles.backPress}
            activeOpacity={1}
            onPress={onGoBack}
          >
            <BackIcon />
          </TouchableOpacity>
          <Text style={styles.titleHeader}>
            Chọn người dùng và nhóm người dùng
          </Text>
          <TouchableOpacity style={styles.iconDone} onPress={onDonePress}>
            <DoneIcon />
          </TouchableOpacity>
        </View>
        <SearchInput
          onChangeFilterText={onChangeFilterText}
          filterText={filterText}
        />
      </View>

      <FlatList
        contentContainerStyle={styles.flatlist}
        data={
          filterdanhSachUsersAndGroup
            ? filterdanhSachUsersAndGroup
            : danhSachUsersAndGroup
        }
        extraData={danhSachUsersAndGroup}
        renderItem={({ item, index }) => (
          <Item
            index={index}
            item={item}
            token={token}
            subSite={subSite}
            chooseTypePress={(ID) => chooseTypePress(ID)}
            typeModal={route?.params?.typeModal}
          />
        )}
        keyExtractor={(item: any) => item?.ID}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
  flatlist: {
    backgroundColor: "#FFFFFF",
    margin: 16,
    borderRadius: 8,
  },
  viewItemContent: { alignItems: 'flex-start', flex: 1 },
  item: {
    height: 60,
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 15,
    borderStyle: "dashed",
    borderTopWidth: 1,
    borderTopColor: "#E5E5E5",
  },
  title: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginRight: 5
  },
  position: {
    fontSize: dimensWidth(13),
    lineHeight: dimensWidth(20),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginRight: 5
  },
  viewHeader: {
    backgroundColor: colors.primary,
    height: 100,
    justifyContent: "center",
    width: "100%",
    padding: 10,
  },
  titleHeader: {
    flex: 1,
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  backPress: {
    padding: 8,
  },
  iconDone: {
    marginEnd: 15,
  },
});

export default App;
