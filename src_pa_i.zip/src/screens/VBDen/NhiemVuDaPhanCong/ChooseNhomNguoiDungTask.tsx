import React, { useCallback, useState, useEffect, useRef } from "react";
import {
  SafeAreaView,
  View,
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  Platform,
} from "react-native";
import {
  BackIcon,
  SellectedBoxIcon,
  UnSellectedBoxIcon,
  DoneIcon,
} from "assets/SVG/index";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import { fetchUsersAndGroup } from "stores/home/reducer";
import { useDispatch, useSelector } from "react-redux";
import SearchInput from "~/components/SearchInput";
import { ActionJsonType } from "../VBDenType";
import { ThunkDispatch } from "@reduxjs/toolkit";
import {
  arrayIsEmpty,
  checkIsEmpty,
  format_yy_mm_dd,
  removeSpecialCharacters,
} from "helpers/formater";
import moment from "moment";
import FastImage from 'react-native-fast-image'
import { BaseUrl } from "~/services/api";

type ItemProps = {
  index: number;
  item: any;
  token: any;
  subSite: any;
  chooseTypePress: (ID: string) => void;
};
type Props = {
  navigation: any;
  route: any;
};

const Item = ({ item, chooseTypePress, token, subSite, index }: ItemProps) => {
  if (!item) return null;
  const { FullName, ID, isSellected, Position, ImagePath } = item;
  return (
    <TouchableOpacity
      style={[styles.item, index === 0 && { borderTopWidth: 0 }]}
      onPress={() => chooseTypePress(ID)}
    >
      <FastImage
        style={{ width: 40, height: 40 }}
        source={{
          uri: BaseUrl + `/${subSite}` + ImagePath,
          headers: { Authorization: `${token}` },
          priority: FastImage.priority.normal,
        }}
        resizeMode={FastImage.resizeMode.contain}
      />
      <View style={styles.viewItemContent}>
        <Text style={styles.title}>{FullName}</Text>
        <Text style={styles.position}>{removeSpecialCharacters(Position)}</Text>
      </View>
      <View>{isSellected ? <SellectedBoxIcon /> : <UnSellectedBoxIcon />}</View>
    </TouchableOpacity>
  );
};
const MemoreiItem = React.memo(Item);
const App = ({ navigation, route }: Props) => {
  const { dataUsersAndGroup } = useSelector((state: any) => state.home);
  const [danhSachUsersAndGroup, SetDanhSachUsersAndGroup] = useState([]);
  const [filterdanhSachUsersAndGroup, setFilterdanhSachUsersAndGroup] =
    useState([]);
  const [filterText, setFilterText] = useState("");
  const [ref, setRef] = useState<any>(null);
  const [scrollToIndex, setScrollToIndex] = useState<any>(0);
  const { subSite, token } = useSelector(
    (state: any) => state.login
  );
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const fetchUsersAndGroupRequest = useCallback((payload: any) => {
    dispatch(fetchUsersAndGroup(payload));
  }, [dispatch]);

  useEffect(() => {
    if (arrayIsEmpty(danhSachUsersAndGroup) && subSite) {
      fetchUsersAndGroupRequest(subSite);
    }
  }, [route?.params?.danhSachUsersAndGroup,subSite, danhSachUsersAndGroup, dispatch]);

  useEffect(() => {
    if (
      route.params?.danhSachUsersAndGroup &&
      route.params?.AssignedToTextJsonParam
    ) {
      const param = route.params?.AssignedToTextJsonParam;
      const newData = route.params?.danhSachUsersAndGroup.map((it) =>
        it.AccountID == param.AccountID
          ? {
            ...it,
            isSellected: true,
          }
          : {
            ...it,
            isSellected: false,
          }
      );
      SetDanhSachUsersAndGroup(newData);
      const newScrollToIndex = newData.findIndex(
        (it) => it?.AccountID == param?.AccountID
      );
      setScrollToIndex(newScrollToIndex);
    }
    if (!route?.params?.danhSachUsersAndGroup && dataUsersAndGroup) {
      const param = route.params?.AssignedToTextJsonParam;
      const tmp = dataUsersAndGroup.map((it) => {
        return (it =
          it?.AccountID == param?.AccountID
            ? {
              ...it,
              isSellected: true,
            }
            : {
              ...it,
              isSellected: false,
            });
      });
      SetDanhSachUsersAndGroup(tmp);
      const newScrollToIndex = tmp.findIndex(
        (it) => it?.AccountID == param?.AccountID
      );
      setScrollToIndex(newScrollToIndex);
    }
  }, [
    route?.params?.danhSachUsersAndGroup,
    route?.params?.AssignedToTextJsonParam,
    dataUsersAndGroup,
  ]);
  useEffect(() => {
    if (scrollToIndex > 0) {
      ref?.scrollToIndex({ index: scrollToIndex, animated: true });
    }
  }, [scrollToIndex]);

  const onGoBack = useCallback(() => {
    navigation.navigate({
      name: "NhiemVuDaPhanCongScreen",
      params: {
        danhSachUsersAndGroup: route?.params?.danhSachUsersAndGroup,
      },
    });
  }, [route?.params?.danhSachUsersAndGroup]);
  const chooseTypePress = useCallback(
    (ID) => {
      let tmp = [];
      tmp = danhSachUsersAndGroup.map((it: any) =>
        it.ID === ID
          ? { ...it, isSellected: !it.isSellected }
          : { ...it, isSellected: false }
      );
      SetDanhSachUsersAndGroup(tmp);
    },
    [danhSachUsersAndGroup]
  );

  const onDonePress = useCallback(() => {
    navigation.navigate({
      name: "NhiemVuDaPhanCongScreen",
      params: { danhSachUsersAndGroup },
    });
  }, [navigation, danhSachUsersAndGroup]);

  const onChangeFilterText = useCallback(
    (text: string) => {
      setFilterText(text);
    },
    [filterText]
  );
  useEffect(() => {
    if (!checkIsEmpty(filterText)) {
      const filteredArray = danhSachUsersAndGroup.filter((item: any) =>
        item?.FullName.includes(filterText)
      );
      setFilterdanhSachUsersAndGroup(filteredArray);
    }
  }, [filterText, danhSachUsersAndGroup]);

  return (
    <View style={styles.container}>
      <View style={styles.viewHeader}>
        <View style={styles.flexDirectionRow}>
          <TouchableOpacity
            style={styles.backPress}
            activeOpacity={1}
            onPress={onGoBack}
          >
            <BackIcon />
          </TouchableOpacity>
          <Text style={styles.titleHeader}>
            Chọn người dùng và nhóm người dùng
          </Text>
          <TouchableOpacity style={styles.iconDone} onPress={onDonePress}>
            <DoneIcon />
          </TouchableOpacity>
        </View>
        <SearchInput
          onChangeFilterText={onChangeFilterText}
          filterText={filterText}
        />
      </View>

      <FlatList
        ref={(ref) => {
          setRef(ref);
        }}
        contentContainerStyle={styles.flatlist}
        data={
          !arrayIsEmpty(filterdanhSachUsersAndGroup)
            ? filterdanhSachUsersAndGroup
            : danhSachUsersAndGroup
        }
        extraData={danhSachUsersAndGroup}
        renderItem={({ item, index }) => (
          <MemoreiItem
            index={index}
            item={item}
            token={token}
            subSite={subSite}
            chooseTypePress={(ID) => chooseTypePress(ID)}
          />
        )}
        getItemLayout={(_, index) => ({
          length: 60, //  itemLength = 60;
          offset: 60 * index, // itemLength = 60;* (index)
          index,
        })}
        keyExtractor={(item: any) => item?.ID}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
  flatlist: {
    backgroundColor: "#FFFFFF",
    margin: 16,
    borderRadius: 8,
  },
  item: {
    height: 60,
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 15,
    borderStyle: "dashed",
    borderTopWidth: 1,
    borderTopColor: "#E5E5E5",
  },
  title: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  viewItemContent: { alignItems: 'flex-start', flex: 1 },
  position: {
    fontSize: dimensWidth(13),
    lineHeight: dimensWidth(20),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  viewHeader: {
    backgroundColor: colors.primary,
    height: 100,
    justifyContent: "center",
    width: "100%",
    padding: 10,
  },
  titleHeader: {
    flex: 1,
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  backPress: {
    padding: 8,
  },
  iconDone: {
    marginEnd: 15,
  },
});

export default App;
