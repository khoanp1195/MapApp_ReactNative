import React, { FC, useState, useCallback, useEffect } from "react";
import {
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Platform,
  TouchableWithoutFeedback,
  Keyboard,
  KeyboardAvoidingView
} from "react-native";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import { checkIsEmpty } from "helpers/formater";
import TextInputCustom from "components/TextInputCustom";

interface Props {
  modalVisible: Boolean;
  onCloseModalKetThuc: () => void;
  onConfirmModalKetThuc: (text: string,TaskID: any) => void;
  DocumentID: any;
  TaskID: any;
  ketThucComment: string;
  onChangeKetThucComment: (text: string) => void;
}
const KetThucModal: FC<Props> = ({
  modalVisible,
  onCloseModalKetThuc,
  onConfirmModalKetThuc,
  DocumentID,
  ketThucComment,
  TaskID,
  onChangeKetThucComment,
  ...props
}: Props) => {
  const [text, setText] = useState("");
  const onChangeText = useCallback(
    (input: string) => {
      setText(input);
      onChangeKetThucComment(input)
    },
    [text]
  );
  const onConfirm = useCallback(() => {
    onConfirmModalKetThuc(ketThucComment,TaskID);
  }, [ketThucComment,TaskID]);
  const onCloseModal = useCallback(() => {
    onCloseModalKetThuc();
  }, [text]);
  useEffect(() => {
    if (!checkIsEmpty(DocumentID)) {
      setText("");
    }
  }, [DocumentID]);


  return (
    <Modal
      transparent={true}
      visible={modalVisible}
      {...props}
      style={styles.centeredView}
    >
      <TouchableWithoutFeedback
        onPress={Keyboard.dismiss}
        accessible={false}
        style={{ flex: 1, backgroundColor: "red" }}
      >
        <KeyboardAvoidingView
          style={styles.centeredView}
          behavior={Platform.OS === "ios" ? "padding" : "height"}
        >
          <View style={styles.modalView}>
            {/* coppy header */}

            <View style={{flex: 1}}>
              <View style={styles.viewAssign}>
                <Text style={styles.textAssign}>Kết thúc</Text>
              </View>
             
              <Text style={styles.textWarning}>
                Anh/Chị xác nhận kết thúc luồng xử lý của văn bản này?
              </Text>
            </View>

            <View style={styles.viewTabBottomBar}>
              <TouchableOpacity
                style={styles.buttonExit}
                onPress={onCloseModal}
              >
                <Text style={styles.buttonExitText} numberOfLines={1}>
                  Thoát
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.buttonTransfer}
                onPress={onConfirm}
              >
                <Text style={styles.tabBarLabelActive} numberOfLines={1}>
                  Kết thúc
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "flex-end",
  },
  modalView: {
    height: dimensWidth(200),
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    opacity: 1,
    backgroundColor: colors.white,
    borderTopEndRadius: 12,
    borderTopStartRadius: 12,
    overflow: "hidden",
  },
  chooseTypeView: {
    height: 100,
    borderWidth: 1,
    borderColor: "#005FD4",
    marginBottom: 15,
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
    marginHorizontal: 15,
    marginTop: 10,
  },
  flexDirection: {
    // height: 67,
    flexDirection: "row",
    paddingHorizontal: 20,
    alignItems: "center",
  },
  stroke: {
    borderWidth: 0.5,
    borderColor: "#999999",
    borderStyle: "dashed",
  },
  textType: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginVertical: 10,
  },
  textWarning: {
    fontSize: FontSize.SMALL,
    color: colors.red,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginVertical: 10,
  },
  tabBarLabelActive: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
  },
  textPhongBan: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
    marginLeft: 5,
  },
  viewTabBottomBar: {
    flexDirection: "row",
    // height: dimensWidth(66),
    borderRadius: 8,
    justifyContent: "flex-end",
    marginBottom: 20
  },
  buttonTransfer: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.blueMedium,
    width: dimensWidth(130),
    height: dimensWidth(34),
    borderRadius: 4,
    marginEnd: 15,
  },
  buttonPhongBan: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.blueMedium,
    height: 34,
    borderRadius: 4,
    marginTop: 10,
    paddingHorizontal: 20,
  },
  buttonExit: {
    alignItems: "center",
    justifyContent: "center",
    width: dimensWidth(130),
    height: dimensWidth(34),
    borderRadius: 4,
  },
  buttonExitText: {
    color: colors.red,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
  },
  textAssign: {
    color: colors.blueMedium,
    fontWeight: "700",
    fontSize: FontSize.LARGE,
  },
  viewAssign: {
    backgroundColor: colors.lightBlue,
    padding: 15,
  },
  titleBoss: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginHorizontal: 15,
  },
  yKienLanhDaoInput: {
    paddingHorizontal: 10,
    borderColor: colors.greyDDD,
    borderRadius: 3,
    height: dimensWidth(100),
    borderWidth: 1,
    marginHorizontal: 15,
    marginBottom: 10,
    textAlignVertical: "top",
  },
  typeChild: {
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "center",
    // height: 34,
    // borderColor: colors.greyDDD,
    // borderWidth: 1,
    // borderRadius: 3,
    marginHorizontal: 15,
    justifyContent: "space-between",
  },
  textFiltedType: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 9,
  },
  textChooseType: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 9,
    marginHorizontal: 10,
  },
});

export default KetThucModal;
