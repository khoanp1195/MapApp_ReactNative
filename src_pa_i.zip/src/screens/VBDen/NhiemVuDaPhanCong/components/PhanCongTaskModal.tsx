import React, { FC, useState, useCallback, useEffect } from "react";
import {
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  Animated,
  ScrollView,
  Alert,
} from "react-native";
import colors from "themes/Colors";
import { dimensWidth, FontSize, dimnensHeight } from "themes/const";
import { MemberIcon, UserPlusIcon, CommentIcon } from "assets/SVG/index";
import {
  arrayIsEmpty,
  checkIsEmpty,
  format_dd_mm_yy,
  removeSpecialCharacters,
} from "helpers/formater";
import TextInputCustom from "components/TextInputCustom";
import { SwipeListView } from "react-native-swipe-list-view";
import { DueDateBlueIcon, DeleteRedIcon } from "assets/SVG";
import FastImage from "react-native-fast-image";
import { BaseUrl } from "~/services/api";
import { useDispatch, useSelector } from "react-redux";

interface Props {
  modalVisible: Boolean;
  onClosePhanCongModal: () => void;
  onChoosePhongBan: () => void;
  handleChooseComment: (itemId: number, Comment: string) => void;
  onChooseToChucPhanCong: () => void;
  onConfirmModalPhanCong: (text: string) => void;
  handleToggleDeletePhongban: (itemId: number) => void;
  handleChooseDueDate: (itemId: number, DueDate: string) => void;
  handleChooseDueDateDonVi: (itemId: number, DueDate: string) => void;
  dataPhongBanParams: Array<any>;
  filteredDanhSachTochucPhanCong: Array<any>;
  DepartmentId: any;
  handleToggleDeleteDSToChucPhanCong: (itemId: number) => void;
  IsGroupAssignmentDept: boolean;
}
const PhanCongModal: FC<Props> = ({
  modalVisible,
  onClosePhanCongModal,
  onChoosePhongBan,
  onConfirmModalPhanCong,
  onChooseToChucPhanCong,
  handleToggleDeletePhongban,
  handleChooseDueDate,
  handleChooseDueDateDonVi,
  handleChooseComment,
  filteredDanhSachTochucPhanCong,
  dataPhongBanParams,
  handleToggleDeleteDSToChucPhanCong,
  IsGroupAssignmentDept,
  DepartmentId,
  ...props
}: Props) => {
  const [yKienLanhDao, setYKienLanhDao] = useState<string>("");
  const { subSite, token } = useSelector(
    (state: any) => state.login
  );
  const onChangeYKienLanhDao = useCallback(
    (input: string) => {
      setYKienLanhDao(input);
    },
    [yKienLanhDao]
  );
  const onDismiss = useCallback(() => {
    Keyboard.dismiss();
  }, []);
  const onConfirm = useCallback(() => {
    onConfirmModalPhanCong(yKienLanhDao);
  }, [yKienLanhDao, dataPhongBanParams, filteredDanhSachTochucPhanCong]);
  useEffect(() => {
    if (!checkIsEmpty(DepartmentId)) {
      setYKienLanhDao("");
    }
  }, [DepartmentId]);

  const ItemPhongBan = ({ item, index, token, subSite }) => {
    const { Title, DueDate, Created, isThucHien, ImagePath, Position, isUser } = item;
    const DueDateFormated = checkIsEmpty(DueDate)
      ? DueDate
      : format_dd_mm_yy(DueDate);
    const isOdd = index % 2 === 0;
    const positionFormat = Position ? removeSpecialCharacters(Position) + ' - ' : ''
    return (
      <View>

        <View
          style={[
            styles.itemPhongBanChild,
            isOdd && { backgroundColor: colors.alice_blue },
          ]}
        >
          {isUser && <FastImage
            style={styles.itemAvatar}
            source={{
              uri: BaseUrl + `/${subSite}` + ImagePath,
              headers: { Authorization: `${token}` },
              priority: FastImage.priority.normal,
            }}
          />}
          <View style={styles.flexDirectionRowBetween}>
            <View style={{ flex: 1 }}>
              <Text style={styles.titlePhongBan} numberOfLines={1}>
                {Title}
              </Text>
              <Text style={styles.blueText} numberOfLines={1}>
                {`${positionFormat}${isThucHien ? "Thực Hiện" : "Phối Hợp"}`}
              </Text>
              {!checkIsEmpty(item?.Comment) &&
                <TouchableOpacity onPress={() => {
                  handleChooseComment(item?.dummyID, item?.Comment);
                }}>
                  <Text style={styles.commentText} >
                    {item?.Comment}
                  </Text>
                </TouchableOpacity>
              }
            </View>
            <View style={styles.flexRowPhongBan}>
              <View style={styles.flexRow}>
                {checkIsEmpty(item?.Comment) &&
                  <TouchableOpacity
                    style={styles.iconChange}
                    onPress={() => {
                      handleChooseComment(item?.dummyID, item?.Comment);
                    }}
                  >
                    <CommentIcon />
                  </TouchableOpacity>
                }
                <TouchableOpacity
                  style={styles.iconChange}
                  onPress={() => {
                    handleChooseDueDate(item?.dummyID, item?.DueDate);
                  }}
                >
                  {!checkIsEmpty(DueDateFormated) ? (
                    <Text style={styles.blueText}>
                      {DueDateFormated}
                    </Text>
                  ) : (
                    <DueDateBlueIcon />
                  )}
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </View>
      </View>
    );
  };
  const ItemToChucPhanCong = ({ item, index }) => {
    const { Title, ParentDept, Created, DueDate } = item;
    const DueDateFormated = checkIsEmpty(DueDate)
      ? DueDate
      : format_dd_mm_yy(DueDate);
    const isOdd = index % 2 === 0;

    return (
      <Animated.View
        style={[
          styles.itemPhongBanChild,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
      >
        <View style={styles.flexDirectionRowBetween}>
          <Text style={styles.title} numberOfLines={1}>
            {Title}
          </Text>
          <Text style={styles.blueText} numberOfLines={1}>
            {DueDateFormated}
          </Text>
        </View>
        <Text style={styles.blueText} numberOfLines={1}>
          {removeSpecialCharacters(ParentDept)}
        </Text>
      </Animated.View>
    );
  };
  const onConfirmDeletePhongBan = useCallback((dummyID: any) => {
    Alert.alert("Thông báo", "Bạn thực sự muốn xóa?", [
      {
        text: "Cancel",
        style: "cancel",
      },
      { text: "OK", onPress: () => handleToggleDeletePhongban(dummyID) },
    ]);
  }, []);
  const onConfirmDeleteDSToChucPhanCong = useCallback((dummyID: any) => {
    Alert.alert("Thông báo", "Bạn thực sự muốn xóa?", [
      {
        text: "Cancel",
        style: "cancel",
      },
      {
        text: "OK",
        onPress: () => handleToggleDeleteDSToChucPhanCong(dummyID),
      },
    ]);
  }, []);

  return (
    <Modal
      transparent={true}
      visible={modalVisible}
      {...props}
      style={styles.centeredView}
    >
      <TouchableWithoutFeedback style={styles.centeredView} onPress={onDismiss}>
        <KeyboardAvoidingView
          style={styles.centeredView}
          behavior={Platform.OS === "ios" ? "padding" : "height"}
        >
          <View style={styles.modalView}>
            {/* coppy header */}
            <View style={styles.viewAssign}>
              <Text style={styles.textAssign}>Phân công</Text>
            </View>
            <ScrollView>
              <>
                <Text style={styles.titleBoss}>
                  Chọn người dùng để phân công
                </Text>
                <View style={styles.chooseTypeView}>
                  <Text style={styles.textChooseType}>
                    {"Vui lòng bấm vào nút để chọn người dùng"}
                  </Text>
                  <TouchableOpacity
                    style={styles.buttonPhongBan}
                    onPress={onChoosePhongBan}
                  >
                    <UserPlusIcon />
                    <Text style={styles.textPhongBan} numberOfLines={1}>
                      Người dùng
                    </Text>
                  </TouchableOpacity>
                </View>
                {!arrayIsEmpty(dataPhongBanParams) && (
                  <SwipeListView
                    contentContainerStyle={styles.flatlist}
                    extraData={dataPhongBanParams}
                    data={dataPhongBanParams}
                    renderItem={({ item, index }) =>
                      ItemPhongBan({ item, index, token, subSite })
                    }
                    renderHiddenItem={(data, rowMap) => {
                      return (
                        <View style={styles.rowBack}>
                          <TouchableOpacity
                            style={styles.iconDelete}
                            onPress={() => {
                              onConfirmDeletePhongBan(data?.item?.dummyID);
                            }}
                          >
                            <DeleteRedIcon />
                          </TouchableOpacity>
                        </View>
                      );
                    }}
                    keyExtractor={(item, index) => item.dummyID}
                    rightOpenValue={-45}
                    disableRightSwipe
                  />
                )}
              </>

              {IsGroupAssignmentDept && (
                <>
                  <Text style={styles.titleBoss}>
                    Tổ chức phân công thực hiện
                  </Text>
                  <View style={styles.chooseTypeView}>
                    <Text style={styles.textChooseType}>
                      {"Vui lòng bấm vào nút để chọn Chi nhánh trực thuộc"}
                    </Text>
                    <TouchableOpacity
                      style={styles.buttonPhongBan}
                      onPress={onChooseToChucPhanCong}
                    >
                      <MemberIcon />

                      <Text style={styles.textPhongBan} numberOfLines={1}>
                      Chi nhánh trực thuộc
                      </Text>
                    </TouchableOpacity>
                  </View>
                </>
              )}
              {!arrayIsEmpty(filteredDanhSachTochucPhanCong) &&
                IsGroupAssignmentDept && (
                  <View style={styles.flatlist}>
                    <SwipeListView
                      extraData={filteredDanhSachTochucPhanCong}
                      data={filteredDanhSachTochucPhanCong}
                      renderItem={({ item, index }) =>
                        ItemToChucPhanCong({ item, index })
                      }
                      renderHiddenItem={(data, rowMap) => {
                        return (
                          <View style={styles.rowBack}>
                            <TouchableOpacity
                              style={styles.iconChange}
                              onPress={() => {
                                handleChooseDueDateDonVi(
                                  data?.item?.dummyID,
                                  data?.item?.DueDate
                                );
                              }}
                            >
                              <DueDateBlueIcon />
                            </TouchableOpacity>
                            <TouchableOpacity
                              style={styles.iconDelete}
                              onPress={() => {
                                onConfirmDeleteDSToChucPhanCong(
                                  data?.item?.dummyID
                                );
                              }}
                            >
                              <DeleteRedIcon />
                            </TouchableOpacity>
                          </View>
                        );
                      }}
                      keyExtractor={(item, index) => item?.dummyID}
                      rightOpenValue={-45}
                      disableRightSwipe
                    />
                  </View>
                )}
            </ScrollView>
            <View style={styles.viewTabBottomBar}>
              <TouchableOpacity
                style={styles.buttonExit}
                onPress={onClosePhanCongModal}
              >
                <Text style={styles.buttonExitText} numberOfLines={1}>
                  Thoát
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.buttonTransfer}
                onPress={onConfirm}
              >
                <Text style={styles.tabBarLabelActive} numberOfLines={1}>
                  Chuyển
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "flex-end",
  },
  modalView: {
    maxHeight: dimnensHeight(800),
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    opacity: 1,
    backgroundColor: colors.white,
    borderTopEndRadius: 12,
    borderTopStartRadius: 12,
    overflow: "hidden",
  },
  chooseTypeView: {
    height: 100,
    borderWidth: 1,
    borderColor: "#005FD4",
    borderStyle: "dashed",
    marginBottom: 15,
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
    marginHorizontal: 15,
    marginTop: 10,
  },
  flexDirection: {
    // height: 67,
    flexDirection: "row",
    paddingHorizontal: 20,
    alignItems: "center",
  },
  stroke: {
    borderWidth: 0.5,
    borderColor: "#999999",
    borderStyle: "dashed",
  },
  textType: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginVertical: 10,
  },
  tabBarLabelActive: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
  },
  textPhongBan: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
    marginLeft: 5,
  },
  viewTabBottomBar: {
    flexDirection: "row",
    // height: dimensWidth(66),
    borderRadius: 8,
    justifyContent: "flex-end",
    marginBottom: 30,
  },
  buttonTransfer: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.blueMedium,
    width: dimensWidth(130),
    height: dimensWidth(34),
    borderRadius: 4,
    marginEnd: 15,
  },
  buttonPhongBan: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.blueMedium,
    height: 34,
    borderRadius: 4,
    marginTop: 10,
    paddingHorizontal: 20,
  },
  buttonExit: {
    alignItems: "center",
    justifyContent: "center",
    width: dimensWidth(130),
    height: dimensWidth(34),
    borderRadius: 4,
  },
  buttonExitText: {
    color: colors.red,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
  },
  textAssign: {
    color: colors.blueMedium,
    fontWeight: "700",
    fontSize: FontSize.LARGE,
  },
  viewAssign: {
    backgroundColor: colors.lightBlue,
    padding: 15,
  },
  titleBoss: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginHorizontal: 15,
    marginTop: 10,
  },
  commentInput: {
    paddingHorizontal: 10,
    borderColor: colors.greyDDD,
    borderRadius: 3,
    height: dimensWidth(100),
    borderWidth: 1,
    marginHorizontal: 15,
    marginBottom: 10,
    textAlignVertical: "top",
  },
  typeChild: {
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "center",
    // height: 34,
    // borderColor: colors.greyDDD,
    // borderWidth: 1,
    // borderRadius: 3,
    marginHorizontal: 15,
    justifyContent: "space-between",
  },
  textFiltedType: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 9,
  },
  textChooseType: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 9,
    marginHorizontal: 10,
  },
  title: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
  },
  titlePhongBan: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
  },
  blueText: {
    fontSize: dimensWidth(13),
    color: colors.scienceBlue,
    fontWeight: "400",
    fontFamily: "arial",
    maxWidth: 250,
  },
  commentText: {
    fontSize: dimensWidth(13),
    color: colors.scienceBlue,
    fontWeight: "400",
    fontFamily: "arial",
  },
  itemPhongBan: {
    height: dimensWidth(70),
  },
  itemPhongBanChild: {
    flexDirection: 'row',
    backgroundColor: colors.white,
    height: dimensWidth(70),
    padding: 15,
  },
  flexDirectionRowBetween: {
    flexDirection: "row",
    justifyContent: "space-between",
    // alignItems: 'center'
    paddingBottom: 8,
    alignItems: "center",
    flex: 1
  },
  rowBack: {
    width: 45,
    height: dimensWidth(70),
    alignSelf: "flex-end",
    flexDirection: "row",
  },
  flexRowPhongBan: {
    flexDirection: "row",
  },
  flexRow: {
    flexDirection: "row",
  },
  iconChange: {
    // justifyContent: "center",
    // alignItems: "center",
    marginHorizontal: 10,
  },
  iconDelete: {
    flex: 1,
    height: dimensWidth(70),
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#FFD7D7",
  },
  flatlist: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    marginHorizontal: 15,
    overflow: "hidden",
    marginBottom: 20,
  },
  itemAvatar: {
    height: dimensWidth(40),
    width: dimensWidth(40),
    marginRight: dimensWidth(10),
    borderRadius: dimensWidth(20),
  },
});

export default PhanCongModal;
