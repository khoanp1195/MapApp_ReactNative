import React, { FC, useState, useCallback, useEffect } from "react";
import {
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Keyboard,
  Platform,
  KeyboardAvoidingView,
} from "react-native";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import { MemberIcon, UserPlusIcon } from "assets/SVG/index";
import { format_dd_mm_yy } from "helpers/formater";
import TextInputCustom from "components/TextInputCustom";

interface Props {
  modalVisible: Boolean;
  onCloseModalTraoDoiLai: () => void;
  onConfirmModalTraoDoiLai: (text: string) => void;
  NguoiGiaoViecComment: string;
  onChangeNguoiGiaoViecComment: (text: string) => void;
}
const FilterModal: FC<Props> = ({
  modalVisible,
  onCloseModalTraoDoiLai,
  NguoiGiaoViecComment,
  onConfirmModalTraoDoiLai,
  onChangeNguoiGiaoViecComment,
  ...props
}: Props) => {
  const [text, setText] = useState("");
  const onChangeText = useCallback(
    (input: string) => {
      setText(input);
      onChangeNguoiGiaoViecComment(input)
    },
    [text]
  );
  const onConfirm = useCallback(() => {
    onConfirmModalTraoDoiLai(NguoiGiaoViecComment);
  }, [NguoiGiaoViecComment]);
  const onCloseModal = useCallback(() => {
    setText(NguoiGiaoViecComment);
    onCloseModalTraoDoiLai();
  }, [text]);
  useEffect(() => {
    setText(NguoiGiaoViecComment);
  }, [NguoiGiaoViecComment]);
  const onDismiss = useCallback(() => {
    Keyboard.dismiss();
  }, []);
  return (
    <Modal
      transparent={true}
      visible={modalVisible}
      {...props}
      style={styles.centeredView}
    >
      <TouchableWithoutFeedback style={styles.centeredView} onPress={onDismiss}>
        <KeyboardAvoidingView
          style={styles.centeredView}
          behavior={Platform.OS === "ios" ? "padding" : "height"}
        >
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              {/* coppy header */}

              <View>
                <View style={styles.viewAssign}>
                  <Text style={styles.textAssign}>Trao đổi lại</Text>
                </View>
                <Text style={styles.textType}>Ý kiến phản hồi</Text>
                <TextInputCustom
                  placeholder="Vui lòng nhập ý kiến"
                  placeholderTextColor={colors.grey999}
                  multiline
                  onChangeText={(text) => onChangeText(text)}
                  value={text}
                  style={styles.NguoiGiaoViecCommentInput}
                />
              </View>

              <View style={styles.viewTabBottomBar}>
                <TouchableOpacity
                  style={styles.buttonExit}
                  onPress={onCloseModal}
                >
                  <Text style={styles.buttonExitText} numberOfLines={1}>
                    Thoát
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.buttonTransfer}
                  onPress={onConfirm}
                >
                  <Text style={styles.tabBarLabelActive} numberOfLines={1}>
                    Trao đổi
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </KeyboardAvoidingView>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "flex-end",
  },
  modalView: {
    height: dimensWidth(400),
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    opacity: 1,
    backgroundColor: colors.white,
    borderTopEndRadius: 12,
    borderTopStartRadius: 12,
    overflow: "hidden",
  },
  chooseTypeView: {
    height: 100,
    borderWidth: 1,
    borderColor: "#005FD4",
    marginBottom: 15,
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
    marginHorizontal: 15,
    marginTop: 10,
  },
  flexDirection: {
    // height: 67,
    flexDirection: "row",
    paddingHorizontal: 20,
    alignItems: "center",
  },
  stroke: {
    borderWidth: 0.5,
    borderColor: "#999999",
    borderStyle: "dashed",
  },
  textType: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginVertical: 10,
  },
  textWarning: {
    fontSize: FontSize.SMALL,
    color: colors.red,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginVertical: 10,
  },
  tabBarLabelActive: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
  },
  textPhongBan: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
    marginLeft: 5,
  },
  viewTabBottomBar: {
    flexDirection: "row",
    // height: dimensWidth(66),
    borderRadius: 8,
    justifyContent: "flex-end",
  },
  buttonTransfer: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.blueMedium,
    width: dimensWidth(130),
    height: dimensWidth(34),
    borderRadius: 4,
    marginEnd: 15,
  },
  buttonPhongBan: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.blueMedium,
    height: 34,
    borderRadius: 4,
    marginTop: 10,
    paddingHorizontal: 20,
  },
  buttonExit: {
    alignItems: "center",
    justifyContent: "center",
    width: dimensWidth(130),
    height: dimensWidth(34),
    borderRadius: 4,
  },
  buttonExitText: {
    color: colors.red,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
  },
  textAssign: {
    color: colors.blueMedium,
    fontWeight: "700",
    fontSize: FontSize.LARGE,
  },
  viewAssign: {
    backgroundColor: colors.lightBlue,
    padding: 15,
  },
  titleBoss: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginHorizontal: 15,
  },
  NguoiGiaoViecCommentInput: {
    paddingHorizontal: 10,
    borderColor: colors.greyDDD,
    borderRadius: 3,
    height: dimensWidth(100),
    borderWidth: 1,
    marginHorizontal: 15,
    marginBottom: 10,
    textAlignVertical: "top",
  },
  typeChild: {
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "center",
    // height: 34,
    // borderColor: colors.greyDDD,
    // borderWidth: 1,
    // borderRadius: 3,
    marginHorizontal: 15,
    justifyContent: "space-between",
  },
  textFiltedType: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 9,
  },
  textChooseType: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 9,
    marginHorizontal: 10,
  },
});

export default FilterModal;
