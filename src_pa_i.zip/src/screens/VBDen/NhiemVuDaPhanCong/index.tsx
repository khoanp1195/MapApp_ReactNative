import React, { useCallback, useState, useEffect, useMemo } from "react";
import {
  View,
  FlatList,
  StyleSheet,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  TouchableWithoutFeedback,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from "react-native";
import {
  BackIcon,
  ClockWhiteIcon,
  ActionMoreIcon,
  RightBlueIcon,
  KetThucIcon,
  AssignGreenIcon,
  TraoDoiLaiIcon,
  SaveIcon,
  ChevronDownIcon,
} from "assets/SVG/index";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import { fetchTaskVBDen } from "stores/home/reducer";
import { useDispatch, useSelector } from "react-redux";
import ActionOptionalModal from "./components/ActionOptionalModal";
import KetThucModal from "./components/KetThucModal";
import {
  format_dd_mm_yy,
  removeSpecialCharacters,
  checkTypeFiles,
  checkTrangThai,
  checkIsEmpty,
  arrayIsEmpty,
  format_date_yy_mm_dd,
  format_yy_mm_dd,
  isNullOrUndefined,
  byteConverter,
} from "helpers/formater";
import { ThunkDispatch } from "@reduxjs/toolkit";
import OptionsKetThucModal from "./components/OptionsKetThucModal";
import TraoDoiLaiModal from "./components/TraoDoiLaiModal";
import CalendarPickerTaskModal from "./components/CalendarPickerTaskModal";
import PhanCongTaskModal from "./components/PhanCongTaskModal";
import { TaskVB, RoleVBDen } from "../VBDenType";
import {
  NguoiGiaoViecTaskVBDenApi,
  NguoiXuLyTaskVBDenApi,
  goBackWaitProcessDocxDetailScreen,
  fetchIsGroupAssignmentDept,
  taskVbDenNguoiXuLyKetThucApi,
  taskVbDenPhanCongApi
} from "stores/taskVBDen/reducer";
import { LoadingView } from "~/components";
import ChoYKienChiDaoModal from "./components/ChoYKienChiDao";
import TextInputCustom from "components/TextInputCustom";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";

type Props = {
  navigation: any;
  route: any;
};

const NhiemVuDaPhanCongScreen = ({ route, navigation }: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const {
    dataTaskVBDen,
    dataCurrentUsers,
  } = useSelector((state: any) => state.home);
  const {
    dataWaitProcessDocxDetail,
    dataWaitProcessDocxAttachFile,
  } = useSelector((state: any) => state.vbDenReducer);
  const {
    isLoading,
    isGoBackWaitProcessDocxDetailScreen,
    IsGroupAssignmentDept,
  } = useSelector((state: any) => state.taskVBDenReducer);
  const {
    subSite
  } = useSelector((state: any) => state.login);

  const { TrichYeu, ID } = dataWaitProcessDocxDetail;

  const [modalActionOptional, setModalActionOptional] = useState(false);
  const [modalPhanCong, setPhanCongModal] = useState(false);
  const [modalYKienChiDao, setYKienChiDaoModal] = useState(false);
  const [modalKetThuc, setKetThucModal] = useState(false);
  const [modalOptionsKetThuc, setOptionsKetThucModal] = useState(false);
  const [modalTraoDoiLai, setModalTraoDoiLai] = useState(false);
  const [isOpenCalendarTaskPicker, setIsOpenCalendarTaskPicker] =
    useState(false);
  const [DocumentID, setDocumentID] = useState("");
  const [taskIDState, setTaskIDState] = useState("");
  const [AssignedToTextJsonState, setAssignedToTextJsonState] = useState<any>(
    {}
  );
  const [phanCongComment, setphanCongComment] = useState("");
  const [NguoiGiaoViecComment, setNguoiGiaoViecComment] = useState("");
  const [NguoiXuLyComment, setNguoiXuLyComment] = useState("");
  const [percentState, setPercentState] = useState(null);
  const [trangThaiState, setTrangThaiState] = useState("");
  const [dueDateTask, setDueDateTask] = useState("");
  const [dueDateDonVi, setDueDateDonVi] = useState("");
  const [dueDateState, setDueDateState] = useState("");
  const [dataPhongBanParams, setDataBanLanhDaoParams] = useState<any>([]);
  const [sellectedItemId, setSellectedItemId] = useState<number>(-1);
  const [typeDate, setTypeDate] = useState<number>(0);
  const [danhsachToChucPhanCong, setDanhsachToChucPhanCong] = useState<any>([]);
  const [danhSachUsersAndGroup, setDanhSachUsersAndGroup] =
    useState<any>(undefined);
  const FullNameCurrentUser = useMemo(() => {
    if (!dataCurrentUsers) return null;
    return dataCurrentUsers[0]?.FullName;
  }, [dataCurrentUsers]);
  useEffect(() => {
    if (route.params?.DocumentID) {
      setDocumentID(route?.params?.DocumentID);
    }
    if (route.params?.taskID) {
      setTaskIDState(route?.params?.taskID);
    }
  }, [route?.params]);

  useEffect(() => {
    if (route.params?.danhSachUsersAndGroup) {
      const item = route?.params?.danhSachUsersAndGroup.find(
        (it: any) => it?.isSellected
      );
      setDanhSachUsersAndGroup(route.params?.danhSachUsersAndGroup);
      setAssignedToTextJsonState(item);
    }
  }, [route.params?.danhSachUsersAndGroup]);
  const fetchTaskVBDenRequest = useCallback(
    (taskID: any) => {
      dispatch(fetchTaskVBDen({taskID, subSite}));
      dispatch(fetchIsGroupAssignmentDept({taskID, subSite}));
    },
    [dispatch]
  );
  useEffect(() => {
    if (route.params?.taskID) {
      fetchTaskVBDenRequest(route.params?.taskID);
    }
  }, [fetchTaskVBDenRequest, route?.params]);
  useEffect(() => {
    if (route?.params?.titleSelected) {
      setTrangThaiState(route?.params?.titleSelected);
    }
  }, [route?.params?.titleSelected]);
  useEffect(() => {
    if (isGoBackWaitProcessDocxDetailScreen) {
      dispatch(goBackWaitProcessDocxDetailScreen({}));
      navigation.goBack();
    }
  }, [isGoBackWaitProcessDocxDetailScreen]);

  useEffect(() => {
    let data = {};
    if (dataTaskVBDen?.Role === RoleVBDen.NguoiGiaoViec) {
      data = dataTaskVBDen?.AssignedToTextJson;
    } else {
      data = dataTaskVBDen?.NguoiNhanJson;
    }
    setAssignedToTextJsonState(data);
  }, [
    dataTaskVBDen?.AssignedToTextJson,
    dataTaskVBDen?.Role,
    dataTaskVBDen?.NguoiNhanJson,
  ]);
  const onActionPress = useCallback(
    (ID: number) => {
      if (modalActionOptional) setModalActionOptional(false);
      if (ID === TaskVB.Luu) onConfirmLuu();
      if (ID === TaskVB.HoanTat) setKetThucModal(true);
      if (ID === TaskVB.PhanCong) setPhanCongModal(true);
      if (ID === TaskVB.TraoDoiLai) setModalTraoDoiLai(true);
    },
    [
      modalPhanCong,
      modalOptionsKetThuc,
      modalActionOptional,
      taskIDState,
      dueDateState,
      trangThaiState,
      percentState,
      AssignedToTextJsonState,
      NguoiGiaoViecComment,
      dataTaskVBDen,
      route.params?.typeModal,
    ]
  );
  const onChangeNguoiGiaoViecComment = useCallback(
    (input: string) => {
      dataTaskVBDen?.Role == RoleVBDen.NguoiGiaoViec ? setNguoiGiaoViecComment(input) : setNguoiXuLyComment(input)
    },
    [NguoiGiaoViecComment, NguoiXuLyComment]
  );
  const onChangeNguoiXuLyComment = useCallback(
    (input: string) => {
      setNguoiXuLyComment(input);
    },
    [NguoiXuLyComment]
  );

  const onConfirmLuu = useCallback(() => {
    if (dataTaskVBDen?.Role === RoleVBDen.NguoiGiaoViec) {
      const NguoiXuLy = !checkIsEmpty(AssignedToTextJsonState?.AccountName)
        ? AssignedToTextJsonState?.AccountID +
        ";#" +
        AssignedToTextJsonState?.AccountName
        : "";
      const payload = {
        TrangThai: trangThaiState,
        YKienChiDao: NguoiGiaoViecComment,
        ThoiHanGiaiQuyet: dueDateState,
        NguoiXuLy,
        TienDo: percentState,
        taskID: taskIDState,
        isTraoDoiLai: false,
        subSite: subSite
      };

      dispatch(NguoiGiaoViecTaskVBDenApi(payload));
      setOptionsKetThucModal(false);
    }
    if (dataTaskVBDen?.Role === RoleVBDen.NguoiXuLy) {
      const NguoiXuLy = !checkIsEmpty(AssignedToTextJsonState?.AccountName) ?
        AssignedToTextJsonState?.AccountID +
        ";#" +
        AssignedToTextJsonState?.AccountName : "";
      const payload = {
        TrangThai: trangThaiState,
        YKienCuaNguoiGiaiQuyet: NguoiXuLyComment,
        NguoiXuLy,
        TienDo: percentState,
        taskID: taskIDState,
        isTraoDoiLai: false,
        subSite: subSite
      };

      dispatch(NguoiXuLyTaskVBDenApi(payload));
      setOptionsKetThucModal(false);
    }
  }, [
    taskIDState,
    dueDateState,
    trangThaiState,
    percentState,
    AssignedToTextJsonState,
    NguoiGiaoViecComment,
    dataTaskVBDen,
    NguoiXuLyComment,
    dispatch,
  ]);
  useEffect(() => {
    if (!arrayIsEmpty(route.params?.dataPhongBanParams)) {
      setDataBanLanhDaoParams(route.params?.dataPhongBanParams);
      setPhanCongModal(true);
    }
    if (!arrayIsEmpty(route.params?.danhsachToChucPhanCong)) {
      setDanhsachToChucPhanCong(route.params?.danhsachToChucPhanCong);
      setPhanCongModal(true);
    }
  }, [route.params, navigation]);

  const onGoBack = useCallback(() => {
    navigation.goBack();
  }, []);
  const onChangePercentState = useCallback(
    (number: any) => {
      setPercentState(number.toString());
    },
    [percentState]
  );
  useEffect(() => {
    setPercentState(dataTaskVBDen?.Percent?.toString());
    setTrangThaiState(dataTaskVBDen?.TrangThai);
  }, [dataTaskVBDen?.Percent, dataTaskVBDen?.TrangThai]);

  const handleWarningPercentState = useCallback(() => {
    if (percentState > 100) {
      Alert.alert("Thông báo", "Vui lòng nhập dưới 100", [
        { text: "OK", onPress: () => { } },
      ]);
    }
  }, [percentState]);
  const gotoThongTinLuanChuyenScreen = useCallback(() => {
    navigation.navigate({
      name: "ThongTinLuanChuyenScreen",
      params: { itemId: dataWaitProcessDocxDetail?.ID },
    });
  }, [dataWaitProcessDocxDetail]);

  const openModalActionOptional = useCallback(() => {
    setModalActionOptional(true);
  }, [modalActionOptional]);

  const onChooseOptionsKetThuc = useCallback(
    (Title: string) => {
      setOptionsKetThucModal(false);
      if (Title === "Lưu") setKetThucModal(true);
      if (Title === "Trao đổi lại") setModalTraoDoiLai(true);
    },
    [modalTraoDoiLai, modalKetThuc, OptionsKetThucModal]
  );

  const onCloseCalendarPickerTaskModal = useCallback(() => {
    setIsOpenCalendarTaskPicker(false);
    setPhanCongModal(true)
  }, []);
  const onCloseOptionsKetThucModal = useCallback(() => {
    setOptionsKetThucModal(false);
  }, [modalOptionsKetThuc]);
  const onOpenDateTaskModal = useCallback(() => {
    setTypeDate(0);
    setIsOpenCalendarTaskPicker(true);
  }, []);
  const chooseNguoiNhanTaskVBDen = useCallback(() => {
    navigation.navigate({
      name: "ChooseNhomNguoiDungTaskScreen",
      params: {
        danhSachUsersAndGroup: danhSachUsersAndGroup,
        AssignedToTextJsonParam: AssignedToTextJsonState,
      },
    });
  }, [AssignedToTextJsonState, danhSachUsersAndGroup]);
  const onCloseModalTraoDoiLai = useCallback(() => {
    setModalTraoDoiLai(false);
    setOptionsKetThucModal(false);
  }, []);
  const onCloseModalYKienChiDao = useCallback(() => {
    setPhanCongModal(true);
    setYKienChiDaoModal(false);
  }, []);
  const onConfirmModalYKienChiDao = useCallback(
    (comment: string) => {
      setYKienChiDaoModal(false);
      setDataBanLanhDaoParams((prevData: any) => {
        const newData = [...prevData];
        const findItemAndToggleComment = (items: any) => {
          for (let i = 0; i < items.length; i++) {
            const item = items[i];

            if (item.dummyID === sellectedItemId) {
              item.Comment = comment;
              return;
            }
            if (item.children && item.children.length > 0) {
              findItemAndToggleComment(item.children);
            }
          }
        };
        findItemAndToggleComment(newData);
        return newData;
      });
      setPhanCongModal(true);
    },
    [dataPhongBanParams, sellectedItemId]
  );
  const onCloseModalKetThuc = useCallback(() => {
    setKetThucModal(false);
    setOptionsKetThucModal(false);
  }, []);
  const onCloseActionOptionalModal = useCallback(() => {
    setModalActionOptional(false);
  }, []);

  const onConfirmModalTraoDoiLai = useCallback(
    () => {
      if (dataTaskVBDen?.Role === RoleVBDen.NguoiGiaoViec) {
        const NguoiXuLy = !checkIsEmpty(AssignedToTextJsonState?.AccountName) ?
          AssignedToTextJsonState?.AccountID +
          ";#" +
          AssignedToTextJsonState?.AccountName : "";
        const payload = {
          TrangThai: trangThaiState,
          YKienChiDao: NguoiGiaoViecComment,
          NguoiXuLy,
          ThoiHanGiaiQuyet: dueDateState,
          taskID: taskIDState,
          isTraoDoiLai: true,
          subSite: subSite
        };

        if (checkIsEmpty(payload.YKienChiDao)) {
          Alert.alert("Thông báo", "Vui lòng nhập ý kiến", [
            { text: "Đóng" },
          ]);
        } else {
          dispatch(NguoiGiaoViecTaskVBDenApi(payload));
          setModalTraoDoiLai(false);
        }
      }

      //nguoi xu ly
      if (dataTaskVBDen?.Role === RoleVBDen.NguoiXuLy) {
        const payload = {
          TrangThai: trangThaiState,
          YKienCuaNguoiGiaiQuyet: NguoiXuLyComment,
          TienDo: percentState,
          taskID: taskIDState,
          isTraoDoiLai: true,
          subSite: subSite
        };

        if (checkIsEmpty(payload.YKienCuaNguoiGiaiQuyet)) {
          Alert.alert("Thông báo", "Vui lòng nhập ý kiến", [
            { text: "Đóng" },
          ]);
        } else {
          dispatch(NguoiXuLyTaskVBDenApi(payload));
          setModalTraoDoiLai(false);
        }
      }
      if (modalOptionsKetThuc) setOptionsKetThucModal(false);
    },
    [
      modalOptionsKetThuc,
      taskIDState,
      dueDateState,
      trangThaiState,
      AssignedToTextJsonState,
      NguoiGiaoViecComment,
      NguoiXuLyComment
    ]
  );

  const onConfirmModalKetThuc = useCallback(
    (text: string, TaskID: any) => {
      const body = {
        taskID: TaskID,
        subSite: subSite
      };

      dispatch(taskVbDenNguoiXuLyKetThucApi(body));
      setKetThucModal(false);
      setOptionsKetThucModal(false);
    },
    [NguoiXuLyComment]
  );
  const onClosePhanCongModal = useCallback(() => {
    setPhanCongModal(false);
  }, []);
  const handleToggleDeleteDSToChucPhanCong = (itemId: any) => {
    setDanhsachToChucPhanCong((prevData: any) => {
      const newData = prevData.map((it) =>
        it.ID == itemId ? { ...it, isSellectedToChucPhanCong: false } : it
      );
      return newData;
    });
  };
  const filteredDanhSachTochucPhanCong = useMemo(() => {
    if (!arrayIsEmpty(danhsachToChucPhanCong)) {
      const filteredData = danhsachToChucPhanCong.filter(
        (it) => it.isSellectedToChucPhanCong
      );
      return filteredData;
    }
    return [];
  }, [danhsachToChucPhanCong]);
  const onChooseToChucPhanCong = useCallback(() => {
    setPhanCongModal(false);
    navigation.navigate({
      name: "ToChucPhanCongThucHienTaskScreen",
      params: {
        danhsachToChucPhanCong,
        DonViXuLyJson: dataWaitProcessDocxDetail?.DonViXuLyJson,
      },
    });
  }, [danhsachToChucPhanCong, dataWaitProcessDocxDetail?.DonViXuLyJson]);

  const gotoFileViewScreen = useCallback((item: any) => {
    navigation.navigate({
      name: "FileViewScreen",
      params: { item },
    });
  }, []);
  const gotoChooseTrangThaiScreen = useCallback(() => {
    navigation.navigate({
      name: "ChooseTrangThaiScreen",
      params: { titleSelected: trangThaiState },
    });
  }, [trangThaiState]);
  const onChoosePhongBan = useCallback(() => {
    setPhanCongModal(false);
    navigation.navigate({
      name: "ChoosePhongBanPhanCongTaskScreen",
      params: {
        dataPhongBanParams: dataPhongBanParams,
        DepartmentId: dataTaskVBDen?.DepartmentId,
      },
    });
  }, [dataPhongBanParams, dataTaskVBDen]);

  const findItemsWithPhongBan = (data) => {
    const result = [];

    const traverseData = (data) => {
      data.forEach((item) => {
        if (item.isThucHien || item.isPhoiHop) {
          result.push(item);
        }

        if (item.children && item.children.length > 0) {
          traverseData(item.children); // Đệ quy duyệt qua các phần tử con
        }
      });
    };

    traverseData(data); // Bắt đầu duyệt từ mảng data

    return result;
  };

  const filteredDataPhongBan = useMemo(() => {
    let filteredData: any[] = [];
    if (!arrayIsEmpty(dataPhongBanParams)) {
      filteredData = findItemsWithPhongBan(dataPhongBanParams);
      return filteredData;
    }
    return filteredData;
  }, [dataPhongBanParams]);

  const handleChooseDueDate = useCallback((itemId: number, DueDate: string) => {
    setPhanCongModal(false);
    setIsOpenCalendarTaskPicker(true);
    setTypeDate(1);
    setDueDateTask(DueDate);
    setSellectedItemId(itemId);
  }, []);
  const handleChooseComment = useCallback(
    (itemId: number, comment: string) => {
      setphanCongComment(comment);
      setPhanCongModal(false);
      setSellectedItemId(itemId);
      setYKienChiDaoModal(true);
    },
    [sellectedItemId, phanCongComment]
  );

  const handleChooseDueDateDonVi = useCallback(
    (itemId: number, DueDate: string) => {
      setPhanCongModal(false);
      setIsOpenCalendarTaskPicker(true);
      setTypeDate(2);
      setDueDateDonVi(DueDate);
      setSellectedItemId(itemId);
    },
    []
  );

  const onDateChangeModal = useCallback(
    (date: string) => {
      setIsOpenCalendarTaskPicker(false);
      if (typeDate === 0) {
        setDueDateState(date);
      } else if (typeDate === 1) {
        setDataBanLanhDaoParams((prevData: any) => {
          const newData = [...prevData];
          const findItemAndToggleDueDate = (items: any) => {
            for (let i = 0; i < items.length; i++) {
              const item = items[i];

              if (item.dummyID === sellectedItemId) {
                item.DueDate = date;
                return;
              }
              if (item.children && item.children.length > 0) {
                findItemAndToggleDueDate(item.children);
              }
            }
          };
          findItemAndToggleDueDate(newData);
          return newData;
        });
        setPhanCongModal(true);
      } else {
        setDanhsachToChucPhanCong((prevData: any) => {
          const newData = [...prevData];

          const findItemAndToggleToChucPhanCong = (items: any) => {
            for (let i = 0; i < items.length; i++) {
              const item = items[i];

              if (item?.dummyID === sellectedItemId) {
                item.DueDate = date;
                return;
              }
            }
          };
          findItemAndToggleToChucPhanCong(newData);
          return newData;
        });
        setPhanCongModal(true);
      }
    },
    [typeDate, sellectedItemId]
  );
  const handleToggleDeletePhongban = useCallback(
    (itemId: any) => {
      setDataBanLanhDaoParams((prevData: any) => {
        const newData = [...prevData];

        const findItemAndTogglePhoiHop = (items: any) => {
          for (let i = 0; i < items.length; i++) {
            const item = items[i];

            if (item.dummyID === itemId) {
              item.isPhoiHop = false;
              item.isThucHien = false;
              return;
            }

            if (item.children && item.children.length > 0) {
              findItemAndTogglePhoiHop(item.children);
            }
          }
        };
        findItemAndTogglePhoiHop(newData);

        return newData;
      });
    },
    [dataPhongBanParams]
  );

  const onConfirmModalPhanCong = useCallback(
    () => {
      let AssignmentUser = "";
      let AssignmentDept = "";
      if (arrayIsEmpty(filteredDataPhongBan)) {
        Alert.alert("Thông báo", "Vui lòng chọn Người dùng!", [
          { text: "OK", onPress: () => { } },
        ]);
        return;
      } else {
        const traverseData = (filterData: any) => {
          filterData.forEach((item: any) => {
            const DepartmentTitle = item.ID + ";#" + item.Title;
            const assignmentType = item.isThucHien
              ? "&&1&&0&&0&&"
              : "&&0&&0&&1&&";
            if (item.isUser) {
              AssignmentUser +=
                DepartmentTitle +
                assignmentType +
                item?.DueDate +
                "&&" +
                item.Manager +
                "&&" +
                item?.Comment +
                "@@";
            } else {
              AssignmentUser +=
                item.Manager +
                assignmentType +
                item?.DueDate +
                "&&" +
                DepartmentTitle +
                "&&" +
                item?.Comment +
                "@@";
            }
          });
        };
        traverseData(filteredDataPhongBan); // Bắt đầu duyệt từ mảng data
      }
      if (!arrayIsEmpty(filteredDanhSachTochucPhanCong)) {
        const traverseData = (filterData: any) => {
          filterData.forEach((item: any) => {
            const DepartmentTitle = item?.ID + ";#" + item?.Title;

            AssignmentDept +=
              DepartmentTitle + "&&" + item?.URL + "&&" + item?.DueDate + "@@";
          });
        };
        traverseData(filteredDanhSachTochucPhanCong); // Bắt đầu duyệt từ mảng data
      }
      const payload = {
        Comment: NguoiXuLyComment,
        BanLanhDao: "",
        UserCC: "",
        AssignmentUser,
        AssignmentDept,
        taskID: taskIDState,
        subSite: subSite
      };
      setPhanCongModal(false);
      dispatch(taskVbDenPhanCongApi(payload));
    },
    [filteredDataPhongBan, filteredDanhSachTochucPhanCong, taskIDState, NguoiXuLyComment]
  );
  const dateParams = useMemo(() => {
    let date = "";
    if (typeDate === 0) date = dueDateState;
    if (typeDate === 1) date = dueDateTask;
    if (typeDate === 2) date = dueDateDonVi;
    return date;
  }, [typeDate, dueDateState, dueDateTask, dueDateDonVi]);

  const StartDateFormat = useMemo(() => {
    if (!dataTaskVBDen?.StartDate) return "";
    return format_dd_mm_yy(dataTaskVBDen.StartDate);
  }, [dataTaskVBDen?.StartDate]);

  const DueDateFormat = useMemo(() => {
    if (dueDateState) return format_dd_mm_yy(dueDateState);
    return "";
  }, [dueDateState]);

  const HoSoDuThao = useMemo(() => {
    if (!isNullOrUndefined(dataTaskVBDen?.HoSoDuThaoUrl)) {
      const obj = JSON.parse(dataTaskVBDen?.HoSoDuThaoUrl)
      return obj?.Title;
    }
  }, [dataTaskVBDen?.HoSoDuThaoUrl])

  useEffect(() => {
    setDueDateState(format_date_yy_mm_dd(dataTaskVBDen?.DueDate))
  }, [dataTaskVBDen?.DueDate])

  const AssignorTextFormat = useMemo(() => {
    if (dataTaskVBDen?.Role === RoleVBDen.NguoiGiaoViec)
      return FullNameCurrentUser;
    if (dataTaskVBDen?.Role === RoleVBDen.NguoiXuLy || dataTaskVBDen?.Role === RoleVBDen.NguoiXem) {
      return dataTaskVBDen?.NguoiChuyenJson?.FullName;
    }
    if (!dataTaskVBDen?.AssignorText) return "";
    return removeSpecialCharacters(dataTaskVBDen?.AssignorText);
  }, [dataTaskVBDen?.AssignorText, FullNameCurrentUser]);

  const ItemAttach = ({ item, index }: any) => {
    const { Author, Created, Category, Size, Url, Title } = item;
    const createdFormated = Created ? format_dd_mm_yy(Created) : null;
    const sizeFormated = !isNullOrUndefined(Size) ? byteConverter(Size) : "";
    const FileIcon = () => {
      return checkTypeFiles(Url);
    };
    const isOdd = index % 2 === 0;
    return (
      <TouchableOpacity
        style={[
          styles.documentFileView,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
        onPress={() => gotoFileViewScreen(item)}
      >
        <View
          style={[styles.flexDirectionRowBetween, { alignItems: "flex-start" }]}
        >
          <FileIcon />
          <View style={styles.flexOne}>
            <Text style={styles.titleDocumentFile} numberOfLines={1}>
              {Title}
            </Text>
            <View style={styles.flexDirectionRow}>
              <Text style={styles.sizeDocumentFile} numberOfLines={1}>
                {sizeFormated}
              </Text>
              <Text style={styles.contenAttach} numberOfLines={1}>
                {Category}
              </Text>
            </View>
          </View>
          <View>
            <Text style={styles.contenAttach} numberOfLines={1}>
              {Author}
            </Text>
            <Text style={styles.contenAttach} numberOfLines={1}>
              {createdFormated}
            </Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };
  const ItemVBDenCommentJson = ({ item, index }: any) => {
    const { Title, Value, UpdateFields, Position, Created } = item;
    const createdFormated = format_dd_mm_yy(Created);
    const isOdd = index % 2 === 0;
    return (
      <View
        style={[
          styles.danhMucItemView,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
      >
        <View
          style={[styles.flexDirectionRowBetween, { alignItems: "flex-start" }]}
        >
          <View style={styles.flexOne}>
            <View style={styles.flexDirectionRowBetween}>
              <Text style={styles.titleCommentJson} numberOfLines={1}>
                {Title}
              </Text>
              <Text style={styles.positionComment} numberOfLines={1}>
                {createdFormated}
              </Text>
            </View>
            <Text style={styles.positionComment} numberOfLines={1}>
              {removeSpecialCharacters(Position)}
            </Text>
            <View style={styles.flexDirectionRow}>
              <Text style={styles.titleCommentJson} numberOfLines={1}>
                {Value}
              </Text>
            </View>
          </View>
        </View>
      </View>
    );
  };

  const IconView = ({ ID }: any) => {
    if (ID === TaskVB.TraoDoiLai)
      return <TraoDoiLaiIcon color={colors.white} />;
    if (ID === TaskVB.PhanCong) return <AssignGreenIcon color={colors.white} />;
    if (ID === TaskVB.Luu) return <SaveIcon color={colors.white} />;
    if (ID === TaskVB.HoanTat) return <KetThucIcon color={colors.white} />;
    return <View />;
  };
  const ItemAction = ({ item, index, onActionPress }: any) => {
    if (index >= 2) return null;
    const { Title, ID } = item;
    // if(Title === 'Chia sẻ') return ShareBlueIcon
    return (
      <TouchableOpacity
        key={ID}
        style={styles.shareButton}
        onPress={() => onActionPress(ID)}
      >
        <View style={styles.flexDirectionRowAction}>
          <IconView ID={ID} />
          <Text style={styles.tabBarLabelActive} numberOfLines={1}>
            {Title}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };
  const onDismiss = useCallback(() => {
    Keyboard.dismiss();
  }, []);
  return (
    <View
      style={styles.container}
    >
      <View style={styles.viewHeader}>
        <View style={styles.flexDirectionRowBetween}>
          <TouchableOpacity
            style={styles.backPress}
            activeOpacity={1}
            onPress={onGoBack}
          >
            <BackIcon />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={gotoThongTinLuanChuyenScreen}
            style={styles.thongTinLuanChuyen}
          >
            <ClockWhiteIcon />
          </TouchableOpacity>
        </View>
      </View>
      <KeyboardAwareScrollView style={styles.cardView} contentContainerStyle={styles.contentScrollView}>
        <Text style={styles.titleHeader}>{TrichYeu}</Text>
        {!checkIsEmpty(dataWaitProcessDocxAttachFile) && (
          <Text style={styles.documentFile}>Tài liệu đính kèm</Text>
        )}
        {!checkIsEmpty(dataWaitProcessDocxAttachFile) && (
          <FlatList
            nestedScrollEnabled
            scrollEnabled={false}
            disableVirtualization
            style={styles.containerAttach}
            extraData={dataWaitProcessDocxAttachFile}
            keyExtractor={(item, index) => item?.ID}
            data={dataWaitProcessDocxAttachFile}
            renderItem={({ item, index }) => (
              <ItemAttach item={item} index={index} />
            )}
          />
        )}
        {!checkIsEmpty(dataWaitProcessDocxDetail?.CommentJson) && (
          <Text style={styles.documentFile}>Ý kiến lãnh đạo</Text>
        )}
        {!arrayIsEmpty(dataWaitProcessDocxDetail?.CommentJson) && (
          <FlatList
            nestedScrollEnabled
            scrollEnabled={false}
            disableVirtualization
            style={styles.commentJsonFlatlist}
            extraData={dataWaitProcessDocxDetail?.CommentJson}
            keyExtractor={(item) => item?.ID}
            data={dataWaitProcessDocxDetail?.CommentJson}
            renderItem={({ item, index }) => (
              <ItemVBDenCommentJson item={item} index={index} />
            )}
          />
        )}
        <View>
          {dataTaskVBDen && (
            <View>
              <Text style={styles.title}>Người chuyển</Text>
              <Text style={styles.content} numberOfLines={1}>
                {AssignorTextFormat}
              </Text>
              {dataTaskVBDen?.Role !== RoleVBDen.NguoiGiaoViec ||
                dataTaskVBDen?.Percent === 100 ? (
                <>
                  <Text style={styles.title}>Người nhận</Text>
                  <Text style={styles.content} numberOfLines={1}>
                    {AssignedToTextJsonState?.FullName
                      ? AssignedToTextJsonState?.FullName
                      : dataTaskVBDen?.DepartmentTitle}
                  </Text>
                </>
              ) : (
                <>
                  <Text style={styles.title}>Người nhận</Text>
                  <TouchableOpacity
                    style={[{}, styles.viewSelectedNguoiNhan]}
                    onPress={chooseNguoiNhanTaskVBDen}
                  >
                    <Text
                      style={[styles.content, { minWidth: 70 }]}
                      numberOfLines={1}
                    >
                      {AssignedToTextJsonState?.FullName
                        ? AssignedToTextJsonState?.FullName
                        : dataTaskVBDen?.DepartmentTitle}
                    </Text>
                  </TouchableOpacity>
                </>
              )}
              <Text style={styles.title}>Ý kiến người giải quyết</Text>
              {
                dataTaskVBDen?.Role == RoleVBDen.NguoiGiaoViec ?
                  <TextInputCustom
                    placeholder="Vui lòng nhập ý kiến"
                    placeholderTextColor={colors.grey999}
                    multiline
                    onChangeText={(text) => onChangeNguoiGiaoViecComment(text)}
                    value={NguoiGiaoViecComment}
                    style={styles.yKienChiDaoInput}
                  /> :

                  <Text style={styles.content}>{dataTaskVBDen?.YKienChiDao}</Text>
              }
              <Text style={styles.title}>Ý kiến người nhận</Text>
              {
                dataTaskVBDen?.Role == RoleVBDen.NguoiXuLy ?
                  <TextInputCustom
                    placeholder="Vui lòng nhập ý kiến"
                    placeholderTextColor={colors.grey999}
                    multiline
                    onChangeText={(text) => onChangeNguoiXuLyComment(text)}
                    value={NguoiXuLyComment}
                    style={styles.yKienChiDaoInput}
                  /> :

                  <Text style={styles.content}>{dataTaskVBDen?.YKienCuaNguoiGiaiQuyet}</Text>
              }
              <View>
                <View style={styles.flexDirectionRowBetween}>
                  <View style={styles.flexOne}>
                    <Text style={styles.title}>Ngày bắt đầu</Text>
                    <Text style={styles.content} numberOfLines={1}>
                      {StartDateFormat}
                    </Text>
                  </View>
                  <View style={styles.flexOne}>
                    {dataTaskVBDen?.Role !== RoleVBDen.NguoiGiaoViec ||
                      dataTaskVBDen?.Percent === 100 ? (
                      <View style={[styles.viewSelected]}>
                        <Text style={styles.textSelected}>
                          Hạn hoàn tất
                        </Text>
                        <Text
                          style={styles.titleSelected}
                          numberOfLines={1}
                        >
                          {DueDateFormat}
                        </Text>
                      </View>
                    ) : (
                      <View style={[styles.viewSelected]}>
                        <Text style={styles.textSelected}>
                          Hạn hoàn tất
                        </Text>
                        <TouchableOpacity
                          onPress={() => onOpenDateTaskModal(false)}
                          style={styles.viewSelectedChild}
                        >
                          <Text style={styles.content} numberOfLines={1}>
                            {DueDateFormat}
                          </Text>
                        </TouchableOpacity>
                      </View>
                    )}
                  </View>
                </View>
              </View>
              <View>
                <Text style={styles.title}>Hồ sơ dự thảo</Text>
                <Text style={styles.content} numberOfLines={1}>
                  {HoSoDuThao}
                </Text>
              </View>
              <>
                {dataTaskVBDen?.Role !== RoleVBDen.NguoiXuLy ||
                  dataTaskVBDen?.Percent === 100 ? (
                  <View style={styles.viewTinhTrang}>
                    <View style={styles.flexOne}>
                      <Text style={styles.textSelected}>Tình trạng</Text>
                      <Text style={styles.titleSelected} numberOfLines={1}>
                        {dataTaskVBDen?.TrangThai}
                      </Text>
                    </View>
                    <View style={styles.flexOne}>
                      <Text style={styles.textSelected}>Tiến độ</Text>
                      <Text style={styles.titleSelected} numberOfLines={1}>
                        {dataTaskVBDen?.Percent}%
                      </Text>
                    </View>
                  </View>
                ) : (
                  <View style={styles.viewTinhTrang}>
                    <TouchableOpacity
                      style={styles.flexOne}
                      onPress={gotoChooseTrangThaiScreen}
                    >
                      <Text style={styles.textSelected}>Tình trạng</Text>
                      <View style={styles.viewTinhTrangChild}>
                        <Text
                          style={styles.titleSelected}
                          numberOfLines={1}
                        >
                          {trangThaiState}
                        </Text>
                        <ChevronDownIcon />
                      </View>
                    </TouchableOpacity>
                    <View style={styles.flexOne}>
                      <Text style={styles.textSelected}>Tiến độ</Text>
                      <View style={styles.viewTinhTrangChild}>
                        <TextInput
                          placeholderTextColor={colors.grey999}
                          numberOfLines={1}
                          onChangeText={onChangePercentState}
                          onBlur={handleWarningPercentState}
                          keyboardType="numeric"
                          value={percentState}
                          style={styles.userNameInput}
                        />
                        <Text
                          style={styles.titleSelected}
                          numberOfLines={1}
                        >
                          %
                        </Text>
                      </View>
                    </View>
                  </View>
                )}
              </>
            </View>
          )}
        </View>
      </KeyboardAwareScrollView>

      {dataTaskVBDen?.ActionJson && (
        <View style={[styles.actionView]}>
          {/* test concat({ ID: 256, Title: "Kết thúc" }) */}
          {dataTaskVBDen?.ActionJson?.map((item: any, index: any) => {
            return (
              <ItemAction
                key={index}
                item={item}
                index={index}
                onActionPress={onActionPress}
              />
            );
          })}
          {/* ActionJson.length >= 3 */}
          {dataTaskVBDen?.ActionJson.length >= 3 && (
            <TouchableOpacity
              style={styles.actionMore}
              onPress={openModalActionOptional}
            >
              <ActionMoreIcon />
            </TouchableOpacity>
          )}
        </View>
      )}

      <LoadingView isLoading={isLoading} />
      <CalendarPickerTaskModal
        modalCalendarVisible={isOpenCalendarTaskPicker}
        onDateChangeModal={onDateChangeModal}
        onCloseModal={onCloseCalendarPickerTaskModal}
        dateParams={dateParams}
        typeModalDate={typeDate}
      />
      <ActionOptionalModal
        ActionJson={dataTaskVBDen?.ActionJson}
        modalVisible={modalActionOptional}
        onCloseModal={onCloseActionOptionalModal}
        onChooseonActionMorePress={onActionPress}
      />
      <OptionsKetThucModal
        ActionJson={dataTaskVBDen?.ActionJson}
        modalVisible={modalOptionsKetThuc}
        onCloseModal={onCloseOptionsKetThucModal}
        onChooseOptionsKetThuc={onChooseOptionsKetThuc}
      />
      <TraoDoiLaiModal
        modalVisible={modalTraoDoiLai}
        onCloseModalTraoDoiLai={onCloseModalTraoDoiLai}
        onConfirmModalTraoDoiLai={onConfirmModalTraoDoiLai}
        NguoiGiaoViecComment={dataTaskVBDen?.Role == RoleVBDen.NguoiGiaoViec ? NguoiGiaoViecComment : NguoiXuLyComment}
        onChangeNguoiGiaoViecComment={onChangeNguoiGiaoViecComment}
      />
      <KetThucModal
        modalVisible={modalKetThuc}
        onCloseModalKetThuc={onCloseModalKetThuc}
        onConfirmModalKetThuc={onConfirmModalKetThuc}
        DocumentID={DocumentID}
        TaskID={taskIDState}
        ketThucComment={NguoiXuLyComment}
        onChangeKetThucComment={onChangeNguoiXuLyComment}
      />
      <PhanCongTaskModal
        modalVisible={modalPhanCong}
        onClosePhanCongModal={onClosePhanCongModal}
        onChoosePhongBan={onChoosePhongBan}
        onConfirmModalPhanCong={(text) => onConfirmModalPhanCong(text)}
        dataPhongBanParams={filteredDataPhongBan}
        handleToggleDeletePhongban={handleToggleDeletePhongban}
        handleChooseDueDate={handleChooseDueDate}
        handleChooseComment={handleChooseComment}
        handleChooseDueDateDonVi={handleChooseDueDateDonVi}
        DepartmentId={dataTaskVBDen?.DepartmentId}
        onChooseToChucPhanCong={onChooseToChucPhanCong}
        IsGroupAssignmentDept={IsGroupAssignmentDept}
        handleToggleDeleteDSToChucPhanCong={
          handleToggleDeleteDSToChucPhanCong
        }
        filteredDanhSachTochucPhanCong={filteredDanhSachTochucPhanCong}
      />
      <ChoYKienChiDaoModal
        modalVisible={modalYKienChiDao}
        phanCongComment={phanCongComment}
        sellectedItemId={sellectedItemId}
        onCloseModalYKienChiDao={onCloseModalYKienChiDao}
        onConfirmModalYKienChiDao={(text) =>
          onConfirmModalYKienChiDao(text)
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
  thongTinLuanChuyen: { padding: 3 },
  scrollView: {
    flex: 1,
  },
  cardView: {
    backgroundColor: "#fff",
    margin: 16,
    borderRadius: 8,
    paddingVertical: 15,
  },
  contentScrollView: { paddingBottom: 30, },
  threeDotView: {
    alignSelf: "flex-end",
    marginRight: 10,
    padding: 10,
  },
  item: {},
  containerAttach: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    marginHorizontal: 15,
    overflow: "hidden",
  },
  dashed: {
    borderStyle: "dashed",
    borderTopWidth: 1,
    borderTopColor: "#E5E5E5",
    marginVertical: 15,
  },
  flexOne: {
    flex: 1,
  },
  content: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginBottom: 10,
  },
  titleSelected: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
  },
  contenAttach: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginTop: 5,
  },
  title: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  documentFile: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginLeft: 15,
    marginBottom: 10,
    marginTop: 15,
  },
  documentFileView: {
    padding: 15,
  },
  viewHeader: {
    backgroundColor: colors.primary,
    height: 55,
    justifyContent: "center",
    width: "100%",
    paddingRight: 15,
    paddingLeft: 7,
  },
  titleHeader: {
    fontSize: FontSize.MEDIUM,
    color: colors.scienceBlue,
    fontWeight: "700",
    fontFamily: "arial",
    paddingHorizontal: 15,
  },
  titleDocumentFile: {
    fontSize: FontSize.MEDIUM,
    color: colors.scienceBlue,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    borderRadius: 4,
  },
  sizeDocumentFile: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    borderRadius: 4,
  },
  flexDirectionRowBetween: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  viewTinhTrang: {
    height: 40,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginLeft: 15,
    marginTop: 10,
    marginBottom: 20
  },
  viewSelected: {
    // height: 40,
    marginLeft: 15,
  },
  viewSelectedChild: {
    height: 40,
    alignItems: "flex-start",
    justifyContent: "center",
    borderRadius: 3,
    borderWidth: 1,
    borderColor: colors.greyDDD,
    marginRight: 15,
    marginVertical: 10,
  },
  viewSelectedNguoiNhan: {
    height: 40,
    alignItems: "flex-start",
    justifyContent: "center",
    borderRadius: 3,
    borderWidth: 1,
    borderColor: colors.greyDDD,
    marginRight: 15,
    marginVertical: 10,
    alignSelf: "baseline",
    marginLeft: 15,
    paddingRight: 15,
  },
  viewTinhTrangChild: {
    height: 40,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 15,
    borderRadius: 3,
    borderWidth: 1,
    borderColor: colors.greyDDD,
    marginRight: 15,
    marginTop: 10,
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  flexDirectionRowAction: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  backPress: {
    padding: 8,
  },
  tabBarLabelActive: {
    color: colors.white,
    fontWeight: "400",
    fontSize: 18,
    marginLeft: 12,
  },
  viewTabBottomBar: {
    flexDirection: "row",
    height: dimensWidth(68),
    alignItems: "center",
    backgroundColor: colors.blueMedium,
  },
  bottomTab: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
  },
  viewButton: {
    flex: 1,
    alignItems: "center",
  },
  actionMore: {
    padding: 8,
  },
  actionView: {
    height: dimensWidth(68),
    backgroundColor: colors.blueMedium,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  shareButton: {
    flex: 1,
  },
  commentInput: {
    paddingHorizontal: 10,
    borderColor: "#DDDDDD",
    borderWidth: 1,
    borderRadius: 3,
    height: 100,
    marginHorizontal: 15,
    textAlignVertical: "top",
  },
  titleVbDenTheoMuc: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    borderRadius: 4,
  },
  titleCommentJson: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    borderRadius: 4,
  },
  positionComment: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    borderRadius: 4,
  },
  textSelected: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
  },
  danhMucItemView: {
    backgroundColor: colors.white,
    padding: 15,
  },
  hoanTatTextColor: {
    color: "#3ABA32",
  },
  hoanTatBackGroundColor: {
    backgroundColor: "#E6FFE4",
  },
  danhMucFlatList: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    marginHorizontal: 15,
    overflow: "hidden",
  },
  commentJsonFlatlist: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    margin: 15,
    overflow: "hidden",
  },
  userNameInput: {
    flex: 1,
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
  },
  yKienChiDaoInput: {
    paddingHorizontal: 10,
    borderColor: colors.greyDDD,
    borderRadius: 3,
    height: dimensWidth(100),
    borderWidth: 1,
    marginHorizontal: 15,
    marginBottom: 10,
    marginTop: 10,
    textAlignVertical: "top",
  },
  textType: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginVertical: 10,
  },
});

export default NhiemVuDaPhanCongScreen;
