import React, { useCallback, useState } from "react";
import {
  SafeAreaView,
  View,
  FlatList,
  StyleSheet,
  Text,
  StatusBar,
} from "react-native";
import {
  BackIcon,
  SelectedDisableIcon,
  SelectedEnalbleIcon,
} from "assets/SVG/index";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import { TouchableOpacity } from "react-native-gesture-handler";

const DATA = [
  {
    id: "bd7acbea-c1b1-46c2-aed5-3ad53abb28ba",
    title: "Chưa bắt đầu",
  },
  {
    id: "3ac68afc-c605-48d3-a4f8-fbd91aa97f63",
    title: "Đang thực hiện",
  },
  {
    id: "58694a0f-3da1-471f-bd96-145571e29d72",
    title: "Tạm hoãn",
  },
];

type ItemProps = {
  title: String;
  titleSelected: String;
  chooseTypePress: (title: String) => void;
};
type Props = {
  navigation: any;
  route: any;
};

const Item = ({ title, titleSelected, chooseTypePress }: ItemProps) => (
  <TouchableOpacity
    style={[styles.item, title === "Chưa bắt đầu" && { borderTopWidth: 0 }]}
    onPress={() => chooseTypePress(title)}
  >
    <Text style={styles.title}>{title}</Text>
    <View>
      {titleSelected === title ? (
        <SelectedEnalbleIcon />
      ) : (
        <SelectedDisableIcon />
      )}
    </View>
  </TouchableOpacity>
);

const App = ({ navigation, route }: Props) => {
  // const navigation = useNavigation();
  const [titleSelected, setTitleSelected] = useState(
    route?.params?.titleSelected
  );
  const chooseTypePress = useCallback(
    (title: String) => {      
      setTitleSelected(title);
      navigation.navigate({
        name: "NhiemVuDaPhanCongScreen",
        params: { titleSelected: title },
      });
    },
    [titleSelected, navigation]
  );

  const onGoBack = useCallback(() => {
    navigation.navigate({
      name: "NhiemVuDaPhanCongScreen",
      params: { titleSelected },
    });
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.viewHeader}>
        <View style={styles.flexDirectionRow}>
          <TouchableOpacity
            style={styles.backPress}
            activeOpacity={1}
            onPress={onGoBack}
          >
            <BackIcon />
          </TouchableOpacity>
          <Text style={styles.titleHeader}>Tình trạng</Text>
        </View>
      </View>

      <FlatList
        contentContainerStyle={styles.flatlist}
        data={DATA}
        renderItem={({ item }) => (
          <Item
            title={item.title}
            titleSelected={titleSelected}
            chooseTypePress={(title) => chooseTypePress(title)}
          />
        )}
        keyExtractor={(item) => item.id}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
  flatlist: {
    backgroundColor: "#FFFFFF",
    margin: 16,
    borderRadius: 8,
  },
  item: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 20,
    borderStyle: "dashed",
    borderTopWidth: 1,
    borderTopColor: "#E5E5E5",
  },
  title: {
    fontSize: FontSize.LARGE,
    lineHeight: dimensWidth(20),
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  viewHeader: {
    backgroundColor: colors.primary,
     height: 55,
    justifyContent: "center",
    width: "100%",
    paddingHorizontal: 10,
  },
  titleHeader: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  backPress: {
    padding: 8,
  },
});

export default App;
