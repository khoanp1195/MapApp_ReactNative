import React, { useCallback, useState, useEffect } from "react";
import {
  SafeAreaView,
  View,
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  Platform,
} from "react-native";
import {
  BackIcon,
  SelectedDisableIcon,
  SelectedEnalbleIcon,
} from "assets/SVG/index";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import { fetchBanLanhDao } from "stores/home/reducer";
import { useDispatch, useSelector } from "react-redux";
import {
  arrayIsEmpty,
  format_yy_mm_dd,
  removeSpecialCharacters,
} from "helpers/formater";
import { ActionJsonType } from "./VBDenType";
import moment from "moment";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { splitID } from "helpers/formater";

type ItemProps = {
  item: any;
  lanhDaoCongTyNameData: any;
  chooseTypePress: ({ Title, ID }: any) => void;
  index: number;
  type: string;
  ID: string;
};
type Props = {
  navigation: any;
  route: any;
};

const Item = ({
  item,
  lanhDaoCongTyNameData,
  chooseTypePress,
  index,
  ID,
}: ItemProps) => {
  const { Title, Position } = item;
  return (
    <TouchableOpacity
      style={[styles.item, index === 0 && { borderTopWidth: 0 }]}
      onPress={() => chooseTypePress(item)}
    >
      <View style={{ flex: 1 }}>
        <Text style={styles.Title} numberOfLines={1}>{Title}</Text>
        <Text style={styles.position} numberOfLines={1}>{removeSpecialCharacters(Position)}</Text>
      </View>
      <View>
        {Title === lanhDaoCongTyNameData?.Title ? (
          <SelectedEnalbleIcon />
        ) : (
          <SelectedDisableIcon />
        )}
      </View>
    </TouchableOpacity>
  );
};

const App = ({ navigation, route }: Props) => {
  // const navigation = useNavigation();
  const { dataBanLanhDao } = useSelector((state: RootState) => state.home);
  const [listBanLanhDao, setListBanLanhDao] = useState([]);
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const { subSite } = useSelector(
    (state: any) => state.login
  );
  const fetchBanLanhDaoRequest = useCallback(async () => {
    dispatch(fetchBanLanhDao(subSite));
  }, [dispatch]);
  useEffect(() => {
    fetchBanLanhDaoRequest();
  }, [fetchBanLanhDaoRequest]);
  const chooseTypePress = useCallback(
    (item: any) => {
      navigation.navigate({
        name: "WaitProcessDocxDetailScreen",
        params: { lanhDaoCongTyNameData: item },
      });
    },

    [navigation]
  );

  const onGoBack = useCallback(() => {
    navigation.navigate({
      name: "WaitProcessDocxDetailScreen",
      params: { typeModal: ActionJsonType.ChuyenXuLy },
    });
  }, []);
  useEffect(() => {
    if (!arrayIsEmpty(dataBanLanhDao) && route.params?.BanLanhDao) {
      const formatBLD = splitID(route.params?.BanLanhDao);
      const tmp = dataBanLanhDao
        .filter((it: any) => it?.ID != formatBLD)
        .sort((a: any, b: any) => a?.Orders - b?.Orders);
      setListBanLanhDao(tmp);
    }
  }, [dataBanLanhDao, route.params?.BanLanhDao]);

  return (
    <View style={styles.container}>
      <View style={styles.viewHeader}>
        <View style={styles.flexDirectionRow}>
          <TouchableOpacity
            style={styles.backPress}
            activeOpacity={1}
            onPress={onGoBack}
          >
            <BackIcon />
          </TouchableOpacity>
          <Text style={styles.TitleHeader}>Lãnh đạo công ty</Text>
        </View>
      </View>

      <FlatList
        contentContainerStyle={styles.flatlist}
        extraData={listBanLanhDao}
        data={listBanLanhDao}
        renderItem={({ item, index }) => (
          <Item
            index={index}
            item={item}
            ID={item?.ID}
            lanhDaoCongTyNameData={route?.params?.lanhDaoCongTyNameData}
            chooseTypePress={chooseTypePress}
          />
        )}
        keyExtractor={(item) => item?.ID}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
  flatlist: {
    backgroundColor: "#FFFFFF",
    margin: 16,
    borderRadius: 8,
  },
  item: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 20,
    borderStyle: "dashed",
    borderTopWidth: 1,
    borderTopColor: "#E5E5E5",
  },
  Title: {
    fontSize: FontSize.LARGE,
    lineHeight: dimensWidth(20),
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  position: {
    fontSize: dimensWidth(13),
    lineHeight: dimensWidth(20),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginTop: 5,
  },
  viewHeader: {
    backgroundColor: colors.primary,
    height: 55,
    justifyContent: "center",
    width: "100%",
    paddingHorizontal: 10,
  },
  TitleHeader: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  backPress: {
    padding: 8,
  },
});

export default App;
