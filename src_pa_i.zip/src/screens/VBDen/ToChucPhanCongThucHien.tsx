import React, { useCallback, useState, useEffect } from "react";
import {
  SafeAreaView,
  View,
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  Platform,
} from "react-native";
import {
  BackIcon,
  SellectedBoxIcon,
  UnSellectedBoxIcon,
  DoneIcon,
} from "assets/SVG/index";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import { fetchToChucPhanCong } from "stores/home/reducer";
import { useDispatch, useSelector } from "react-redux";
import { ActionJsonType } from "./VBDenType";
import { ThunkDispatch } from "@reduxjs/toolkit";
import {
  format_yy_mm_dd,
  removeSpecialCharacters,
  splitID,
  checkNotNullAndEmpty,
  arrayIsEmpty,
  checkIsEmpty,
} from "helpers/formater";
import moment from "moment";
import { Positions } from "react-native-calendars/src/expandableCalendar";
import { NoDataView } from "~/components";

type ItemProps = {
  index: number;
  typeModal: any;
  item: any;
  chooseTypePress: (ID: string) => void;
};
type Props = {
  navigation: any;
  route: any;
};

const Item = ({ item, chooseTypePress, index, typeModal }: ItemProps) => {
  const { Title, ID, isSellectedToChucPhanCong, Position } = item;

  return (
    <TouchableOpacity
      style={[styles.item, index === 0 && { borderTopWidth: 0 }]}
      onPress={() => chooseTypePress(ID)}
    >
      <View>
        <Text style={styles.title}>{Title}</Text>
        <Text style={styles.position}>{removeSpecialCharacters(Position)}</Text>
      </View>
      <View>
        {isSellectedToChucPhanCong ? (
          <SellectedBoxIcon />
        ) : (
          <UnSellectedBoxIcon />
        )}
      </View>
    </TouchableOpacity>
  );
};

const App = ({ navigation, route }: Props) => {
  const { dataToChucPhanCong } = useSelector((state: RootState) => state.home);
  const { subSite } = useSelector(
    (state: any) => state.login
  );
  const [danhsachToChucPhanCong, setDanhSachToChucPhanCong] = useState([]);
  const [isAllSellectedToChucPhanCong, setIsAllSellectedToChucPhanCong] =
    useState(false);

  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const fetchToChucPhanCongRequest = useCallback(async () => {
    const date = moment().format(format_yy_mm_dd);
    dispatch(fetchToChucPhanCong(subSite));
  }, [dispatch]);
  useEffect(() => {
    if (arrayIsEmpty(route.params?.danhsachToChucPhanCong))
      fetchToChucPhanCongRequest();
  }, [
    fetchToChucPhanCongRequest,
    navigation,
    route.params?.danhsachToChucPhanCong,
  ]);

  useEffect(() => {
    const IDHaveIsRoot = dataToChucPhanCong?.find((it) => it?.IsRoot)?.ID;
    const DonViXuLyJson = route.params?.DonViXuLyJson;
    const checkIsExist = (ID: number) => {
    
      const isExist = DonViXuLyJson?.some((a) => a?.DepartmentId === ID);
      return !isExist; //check don vi is exist in DonViXuLyJson
    };
    const dataTmp = dataToChucPhanCong
      ?.filter(
        (it) =>
          checkNotNullAndEmpty(it?.URL) &&
          splitID(it?.ParentDept) == IDHaveIsRoot &&
          checkIsExist(it?.ID)
      )
      .map((it) => (it = { ...it, isSellectedToChucPhanCong: false }));
    setDanhSachToChucPhanCong(dataTmp);
  }, [dataToChucPhanCong, route.params?.DonViXuLyJson]);

  const onGoBack = useCallback(() => {
    navigation.navigate({
      name: "WaitProcessDocxDetailScreen",
      params: {
        typeModal: route.params?.typeModal,
      },
    });
  }, [route.params?.typeModal]);

  const chooseTypePress = useCallback(
    (ID) => {
      let tmp = [];
      tmp = danhsachToChucPhanCong.map((it: any) =>
        it.ID === ID
          ? {
              ...it,
              isSellectedToChucPhanCong: !it.isSellectedToChucPhanCong,
              DueDate: "",
            }
          : it
      );
      setDanhSachToChucPhanCong(tmp);
    },
    [danhsachToChucPhanCong]
  );
  const onChangeAllSellectedToChucPhanCong = useCallback(() => {
    setIsAllSellectedToChucPhanCong(!isAllSellectedToChucPhanCong);
    setDanhSachToChucPhanCong((prevData: any) => {
      const newData = [...prevData];

      const findItemAndToggleToChucPhanCong = (items: any) => {
        for (let i = 0; i < items.length; i++) {
          const item = items[i];

          const newValue = !isAllSellectedToChucPhanCong;
          item.isSellectedToChucPhanCong = newValue;
        }
      };
      findItemAndToggleToChucPhanCong(newData);
      return newData;
    });
  }, [isAllSellectedToChucPhanCong, danhsachToChucPhanCong]);
  const onDonePress = useCallback(() => {
    navigation.navigate({
      name: "WaitProcessDocxDetailScreen",
      params: {
        danhsachToChucPhanCong: danhsachToChucPhanCong,
        typeModal: route.params?.typeModal,
      },
    });
  }, [navigation, danhsachToChucPhanCong, route.params?.typeModal]);
  useEffect(() => {
    if (!arrayIsEmpty(route.params?.danhsachToChucPhanCong)) {
      setDanhSachToChucPhanCong(route.params?.danhsachToChucPhanCong);
    }
  }, [route.params?.danhsachToChucPhanCong]);
  return (
    <View style={styles.container}>
      <View style={styles.viewHeader}>
        <View style={styles.flexDirectionRow}>
          <TouchableOpacity
            style={styles.backPress}
            activeOpacity={1}
            onPress={onGoBack}
          >
            <BackIcon />
          </TouchableOpacity>
          <Text style={styles.titleHeader}>Tổ chức phân công thực hiện</Text>
          <TouchableOpacity style={styles.iconDone} onPress={onDonePress}>
            <DoneIcon />
          </TouchableOpacity>
        </View>
      </View>
       {!arrayIsEmpty(danhsachToChucPhanCong) ?  <FlatList
        contentContainerStyle={styles.flatlist}
        ListHeaderComponent={() => {
          return (
            <View style={styles.flexDirectionRowHeader}>
              <View style={styles.viewListHeader}>
                <Text style={styles.header} numberOfLines={2}>
                  {"Thực\nhiện"}
                </Text>
                <TouchableOpacity
                  style={styles.selectedAll}
                  onPress={onChangeAllSellectedToChucPhanCong}
                >
                  {isAllSellectedToChucPhanCong ? (
                    <SellectedBoxIcon />
                  ) : (
                    <UnSellectedBoxIcon />
                  )}
                </TouchableOpacity>
              </View>
            </View>
          );
        }}
        data={danhsachToChucPhanCong}
        extraData={danhsachToChucPhanCong}
        renderItem={({ item, index }) => (
          <Item
            index={index}
            item={item}
            chooseTypePress={(ID) => chooseTypePress(ID)}
            typeModal={route?.params?.typeModal}
          />
        )}
        keyExtractor={(item: any) => item?.ID}
      /> : <NoDataView />}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
  flatlist: {
    backgroundColor: "#FFFFFF",
    margin: 16,
    borderRadius: 8,
    marginBottom: 30
  },
  item: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 20,
    borderStyle: "dashed",
    borderTopWidth: 1,
    borderTopColor: "#E5E5E5",
  },
  title: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  position: {
    fontSize: dimensWidth(13),
    lineHeight: dimensWidth(20),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  viewHeader: {
    backgroundColor: colors.primary,
    height: 55,
    justifyContent: "center",
    width: "100%",
    paddingHorizontal: 10,
  },
  titleHeader: {
    flex: 1,
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  backPress: {
    padding: 8,
  },
  iconDone: {
    marginEnd: 15,
  },
  flexDirectionRowHeader: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.alice_blue,
    paddingVertical: 10,
    justifyContent: "flex-end",
  },
  header: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 10,
  },
  selectedAll: {
    marginTop: 5,
    marginRight: 15,
  },
  viewListHeader: {
    alignItems: "center",
    justifyContent: "center",
  },
});

export default App;
