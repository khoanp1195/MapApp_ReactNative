import React, { useCallback, useState, useEffect } from "react";
import {
  SafeAreaView,
  View,
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
} from "react-native";
import stylesMain from "./WaitProcessDocx.Style";
import {
  BackIcon,
  SellectedBoxIcon,
  UnSellectedBoxIcon,
  DoneIcon,
  MinusIcon,
  PlusIcon,
} from "assets/SVG/index";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import { fetchPhongBanPhanCong } from "stores/home/reducer";
import { useDispatch, useSelector } from "react-redux";
import {
  arrayIsEmpty,
  checkIsEmpty,
  checkNotNullAndEmpty,
  convertDataPhongBan,
} from "~/helpers/formater";
import moment from "moment";
import { splitID } from "helpers/formater";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { ActionJsonType } from "./VBDenType";

type Props = {
  navigation: any;
  route: any;
};

const App = ({ navigation, route }: Props) => {
  // const navigation = useNavigation();
  const { dataPhongBan } = useSelector((state: RootState) => state.home);
  const { subSite } = useSelector((state: RootState) => state.login);
  const [dataPhongBanState, setdataPhongBanState] = useState<any>([]);
  const [isAllThucHien, setIsAllThucHien] = useState(false);
  const [isAllPhoiHop, setIsAllPhoiHop] = useState(false);
  const handleToggleExpanded = (itemId: any) => {
    setdataPhongBanState((prevData: any) => {
      const newData = [...prevData];

      const findItemAndToggleExpanded = (items: any) => {
        for (let i = 0; i < items.length; i++) {
          const item = items[i];

          if (item.dummyID === itemId) {
            const newValue = !item.isExpanded;
            item.isExpanded = newValue;
            return;
          }

          if (item.children && item.children.length > 0) {
            findItemAndToggleExpanded(item.children);
          }
        }
      };
      findItemAndToggleExpanded(newData);
      return newData;
    });
  };

  const handleToggleThucHien = (itemId: any, level: number) => {
    setdataPhongBanState((prevData: any) => {
      const newData = [...prevData];

      const findItemAndToggleThucHien = (items: any) => {
        for (let i = 0; i < items.length; i++) {
          const item = items[i];

          if (item.dummyID === itemId) {
            const newValue = !item.isThucHien;
            item.isThucHien = newValue;
            if (item.isThucHien && item.isPhoiHop) item.isPhoiHop = false;
            if (level === 0 && newValue)
              toggleChildrenThucHien(item.children, newValue);
            return;
          }

          if (item.children && item.children.length > 0) {
            findItemAndToggleThucHien(item.children);
          }
        }
      };

      const toggleChildrenThucHien = (children: any, value: any) => {
        for (let i = 0; i < children.length; i++) {
          const childItem = children[i];
          childItem.isThucHien = value;
          if (childItem.isThucHien && childItem.isPhoiHop)
            childItem.isPhoiHop = false;
          if (childItem.children && childItem.children.length > 0) {
            toggleChildrenThucHien(childItem.children, value);
          }
        }
      };

      findItemAndToggleThucHien(newData);

      return newData;
    });
  };

  //            if (item.isThucHien && item.isPhoiHop) item.isPhoiHop = false;

  const handleTogglePhoiHop = (itemId: any, level: number) => {
    setdataPhongBanState((prevData: any) => {
      const newData = [...prevData];

      const findItemAndTogglePhoiHop = (items: any) => {
        for (let i = 0; i < items.length; i++) {
          const item = items[i];

          if (item.dummyID === itemId) {
            const newValue = !item.isPhoiHop;
            item.isPhoiHop = newValue;
            if (item.isThucHien && item.isPhoiHop) item.isThucHien = false;
            if (level === 0 && newValue)
              toggleChildrenPhoiHop(item.children, newValue);
            return;
          }

          if (item.children && item.children.length > 0) {
            findItemAndTogglePhoiHop(item.children);
          }
        }
      };

      const toggleChildrenPhoiHop = (children: any, value: any) => {
        for (let i = 0; i < children.length; i++) {
          const childItem = children[i];
          childItem.isPhoiHop = value;
          if (childItem.isThucHien && childItem.isPhoiHop)
            childItem.isThucHien = false;
          if (childItem.children && childItem.children.length > 0) {
            toggleChildrenPhoiHop(childItem.children, value);
          }
        }
      };

      findItemAndTogglePhoiHop(newData);

      return newData;
    });
  };
  const onChangeAllThucHien = useCallback(() => {
    setIsAllThucHien(!isAllThucHien);
    setdataPhongBanState((prevData: any) => {
      const newData = [...prevData];

      const findItemAndToggleThucHien = (items: any) => {
        for (let i = 0; i < items.length; i++) {
          const item = items[i];

          const newValue = !isAllThucHien;
          if (!item.isPhoiHop) item.isThucHien = newValue;
          toggleChildrenThucHien(item.children, newValue);
          return;
        }

        if (item.children && item.children.length > 0) {
          findItemAndToggleThucHien(item.children);
        }
      };

      const toggleChildrenThucHien = (children: any, value: any) => {
        for (let i = 0; i < children.length; i++) {
          const childItem = children[i];
          if (!childItem.isPhoiHop) childItem.isThucHien = value;
          if (childItem.children && childItem.children.length > 0) {
            toggleChildrenThucHien(childItem.children, value);
          }
        }
      };

      findItemAndToggleThucHien(newData);

      return newData;
    });
  }, [isAllThucHien]);
  const onChangeAllPhoiHop = useCallback(() => {
    setIsAllPhoiHop(!isAllPhoiHop);
    setdataPhongBanState((prevData: any) => {
      const newData = [...prevData];

      const findItemAndTogglePhoiHop = (items: any) => {
        for (let i = 0; i < items.length; i++) {
          const item = items[i];

          const newValue = !isAllPhoiHop;
          if (!item.isThucHien) item.isPhoiHop = newValue;
          toggleChildrenPhoiHop(item.children, newValue);
          return;
        }

        if (item.children && item.children.length > 0) {
          findItemAndTogglePhoiHop(item.children);
        }
      };

      const toggleChildrenPhoiHop = (children: any, value: any) => {
        for (let i = 0; i < children.length; i++) {
          const childItem = children[i];
          if (!childItem.isThucHien) childItem.isPhoiHop = value;
          if (childItem.children && childItem.children.length > 0) {
            toggleChildrenPhoiHop(childItem.children, value);
          }
        }
      };

      findItemAndTogglePhoiHop(newData);

      return newData;
    });
  }, [isAllPhoiHop]);

  const renderItem = ({ item, index }: any) => {
    const hasChildren = item.children && item.children.length > 0;
    const {
      Title,
      children,
      ID,
      isThucHien,
      isPhoiHop,
      level,
      isEnded = false,
      isExpanded,
    } = item;

    return (
      <View style={styles.item}>
        <View
          style={[
            styles.flexDirectionRowItem,
            { paddingLeft: 20 + level * 20 },
          ]}
        >
          {!isEnded && (
            <TouchableOpacity onPress={() => handleToggleExpanded(item.dummyID)}>
              {isExpanded ? <MinusIcon /> : <PlusIcon />}
            </TouchableOpacity>
          )}
          <TouchableOpacity onPress={() => alert(Title)} style={{ flex: 1 }}>
            <Text style={styles.title} numberOfLines={1}>
              {Title}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.viewBox}
            onPress={() => handleToggleThucHien(item.dummyID, level)}
          >
            {isThucHien ? <SellectedBoxIcon /> : <UnSellectedBoxIcon />}
          </TouchableOpacity>
          <TouchableOpacity onPress={() => handleTogglePhoiHop(item.dummyID, level)}>
            {isPhoiHop ? <SellectedBoxIcon /> : <UnSellectedBoxIcon />}
          </TouchableOpacity>
        </View>
        { isExpanded && hasChildren && (
          <FlatList
            data={item?.children}
            renderItem={({ item, index }) =>
              renderItem({ item, index })
            }
            keyExtractor={(child, index) => index.toString()}
          />
        )}
      </View>
    );
  };

  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const fetchPhongBanPhanCongRequest = useCallback(() => {
    dispatch(fetchPhongBanPhanCong(subSite));
  }, [dispatch]);
  useEffect(() => {
    if (arrayIsEmpty(route.params?.dataPhongBanParams)) {
      fetchPhongBanPhanCongRequest();
    }
  }, [fetchPhongBanPhanCongRequest, route.params?.dataPhongBanParams]);

  const clone = (data: any, item: any) => {
    if (item && data) {
      item.isExpanded = item.level === 0
      const items = data.filter(
        (r) =>
          (r.URL === null || r.URL === "") &&
          r.ParentDept != null &&
          r.ParentDept.split(";")[0] === item.ID.toString()
      ).map((record) => ({
        ...record,
        level: item.level
      }));

      if (items?.length > 0) {
        item.children = items;
        item.isUser = false;
        item.dummyID = item.ID;
        for (let index = 0; index < item.children.length; index++) {
          const element = item.children[index];
          element.level = element.level + 1
          element.isExpanded = element.level === 1
          clone(data, element);
        }
      } else {
        if (item.MultipleManagers?.length > 0) {
          item.MultipleManagers.forEach((r) => {
            item.children.push({
              Title: r.FullName,
              ID: r.AccountID,
              Manager: item.ID + ";#" + item.Title,
              isThucHien: false,
              isPhoiHop: false,
              isExpanded: false,
              level: item.level + 1,
              DueDate: "",
              isUser: true,
              children: [],
              isEnded: true,
              dummyID: item.ID + ";#" + r.AccountID,
            });
          });
        }
      }
    }
  };
  useEffect(() => {
    if (dataPhongBan) {
      const data = dataPhongBan.map((record) => ({
        ...record,
        isThucHien: false,
        isPhoiHop: false,
        isExpanded: false,
        isUser: false,
        level: 0,
        DueDate: "",
        dummyID: record.ID,
        children: [],
      }));
      const newItem = data?.filter((it) => it.IsRoot)
      clone(data, newItem[0]);
      setdataPhongBanState(newItem);
    }
  }, [dataPhongBan]);
  
  const onGoBack = useCallback(() => {
    navigation.navigate({
      name: "WaitProcessDocxDetailScreen",
      params: {
        typeModal: route.params?.typeModal,
      },
    });
  }, [route.params?.dataPhongBanParams, route.params?.typeModal]);
  const onDoneSelected = useCallback(() => {
    navigation.navigate({
      name: "WaitProcessDocxDetailScreen",
      params: {
        dataPhongBanParams: dataPhongBanState,
        typeModal: route.params?.typeModal,
      },
    });
  }, [dataPhongBanState, route.params?.typeModal]);
  useEffect(() => {
    if (!arrayIsEmpty(route.params?.dataPhongBanParams)) {
      setdataPhongBanState(route.params?.dataPhongBanParams);
    }
  }, [route.params?.dataPhongBanParams]);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.viewHeader}>
        <View style={styles.flexDirectionRow}>
          <TouchableOpacity
            style={styles.backPress}
            activeOpacity={1}
            onPress={onGoBack}
          >
            <BackIcon />
          </TouchableOpacity>
          <Text style={styles.titleHeader}>
            Các phòng/ban nghiệp vụ công ty
          </Text>
          <TouchableOpacity style={styles.iconDone} onPress={onDoneSelected}>
            <DoneIcon />
          </TouchableOpacity>
        </View>
      </View>

      <FlatList
        ListHeaderComponent={() => {
          return (
            <View style={styles.flexDirectionRowHeader}>
              <View style={styles.viewListHeader}>
                <Text style={styles.header} numberOfLines={2}>
                  {"Thực\nhiện"}
                </Text>
                <TouchableOpacity
                  style={styles.selectedAll}
                  onPress={onChangeAllThucHien}
                >
                  {isAllThucHien ? (
                    <SellectedBoxIcon />
                  ) : (
                    <UnSellectedBoxIcon />
                  )}
                </TouchableOpacity>
              </View>
              <View style={styles.viewListHeader}>
                <Text style={styles.header} numberOfLines={2}>
                  {"Phối\nhợp"}
                </Text>
                <TouchableOpacity
                  style={styles.selectedAll}
                  onPress={onChangeAllPhoiHop}
                >
                  {isAllPhoiHop ? <SellectedBoxIcon /> : <UnSellectedBoxIcon />}
                </TouchableOpacity>
              </View>
            </View>
          );
        }}
        contentContainerStyle={styles.flatlist}
        data={dataPhongBanState}
        extraData={dataPhongBanState}
        renderItem={renderItem}
        keyExtractor={(item, index) => item?.ID + index}
      />
    </SafeAreaView>
  );
};

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
  flatlist: {
    flexGrow: 1,
    backgroundColor: "#FFFFFF",
    margin: 16,
    paddingBottom: 30,
    borderRadius: 8,
    overflow: "hidden",
  },
  flatlistChild: {
    marginRight: 15,
  },
  selectedAll: {
    marginTop: 5,
    marginRight: 20,
  },
  viewListHeader: {
    alignItems: "center",
    justifyContent: "center",
  },
  item: {
    width: "100%",
    marginTop: 20,
    // flexDirection: "row",
    paddingTop: 20,
    borderStyle: "dashed",
    borderTopWidth: 1,
    borderTopColor: "#E5E5E5",
  },
  itemChild: {
    flex: 1,
    width: "100%",
    padding: 20,
    borderStyle: "dashed",
    borderTopWidth: 1,
    borderTopColor: "#E5E5E5",
    // paddingLeft: 40,
  },
  header: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 10,
  },
  title: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.textBlack19,
    fontWeight: "700",
    fontFamily: "arial",
    marginLeft: 10,
    marginRight: 10,
  },
  viewHeader: {
    backgroundColor: colors.primary,
    height: 55,
    justifyContent: "center",
    width: "100%",
    paddingHorizontal: 10,
  },
  titleHeader: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    flex: 1,
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  flexDirectionRowItem: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 20,
  },
  flexDirectionRowHeader: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.alice_blue,
    paddingVertical: 10,
    justifyContent: "flex-end",
  },
  backPress: {
    padding: 8,
  },
  iconDone: {
    marginEnd: 15,
  },
  viewBox: {
    width: 50,
  },
});

export default App;
