import React, { useCallback, useState, useEffect } from "react";
import {
  SafeAreaView,
  View,
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  Platform,
} from "react-native";
import {
  BackIcon,
  SellectedBoxIcon,
  UnSellectedBoxIcon,
  DoneIcon,
} from "assets/SVG/index";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import { fetchUsersAndGroup } from "stores/home/reducer";
import { useDispatch, useSelector } from "react-redux";
import SearchInput from "~/components/SearchInput"
import { ActionJsonType } from "./VBBHType";
import { ThunkDispatch } from "@reduxjs/toolkit";
import {
  arrayIsEmpty,
  format_yy_mm_dd,
  removeSpecialCharacters,
} from "helpers/formater";
import moment from "moment";
import FastImage from "react-native-fast-image";
import { BaseUrl } from "~/services/api";

type ItemProps = {
  index: number;
  screenName: any;
  item: any;
  chooseTypePress: (ID: string) => void;
  token: any;
  subSite: any
};
type Props = {
  navigation: any;
  route: any;
};

const Item = ({ item, chooseTypePress, index, token, subSite, screenName }: ItemProps) => {
  const {
    FullName,
    ID,
    isSellectedVBBH,
    isSellectedVBDi,
    Position,
    ImagePath,
  } = item;
  const selected =
    screenName === "VBDaBanHanhDetailScreen"
      ? isSellectedVBBH
      : isSellectedVBDi;
  return (
    <TouchableOpacity
      style={[styles.item, index === 0 && { borderTopWidth: 0 }]}
      onPress={() => chooseTypePress(ID)}
    >
      <FastImage
        style={{ width: 40, height: 40 }}
        source={{
          uri: BaseUrl + `/${subSite}` + ImagePath,
          headers: { Authorization: `${token}` },
          priority: FastImage.priority.normal,
        }}
        resizeMode={FastImage.resizeMode.contain}
      />
      <View style={styles.viewItemContent}>
        <Text style={styles.title}>{FullName}</Text>
        <Text style={styles.position}>{removeSpecialCharacters(Position)}</Text>
      </View>
      <View>{selected ? <SellectedBoxIcon /> : <UnSellectedBoxIcon />}</View>
    </TouchableOpacity>
  );
};

const App = ({ navigation, route }: Props) => {
  // const navigation = useNavigation();
  const { dataUsersAndGroup } = useSelector((state: RootState) => state.home);
  const [danhSachUsersAndGroup, SetDanhSachUsersAndGroup] = useState([]);
  const [filterdanhSachUsersAndGroup, setFilterdanhSachUsersAndGroup] =
    useState([]);
  const [filterText, setFilterText] = useState("");
  const { subSite, token } = useSelector(
    (state: any) => state.login
  );
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const fetchUsersAndGroupRequest = useCallback((payload: any) => {
    dispatch(fetchUsersAndGroup(payload));
  }, [dispatch]);

  useEffect(() => {
    if (
      arrayIsEmpty(route?.params?.danhSachUsersAndGroup) &&
      arrayIsEmpty(dataUsersAndGroup) && subSite
    ) {
      fetchUsersAndGroupRequest(subSite);
    }
  }, [fetchUsersAndGroupRequest, subSite, route?.params?.danhSachUsersAndGroup]);
  useEffect(() => {
    if (!arrayIsEmpty(route.params?.danhSachUsersAndGroup)) {
      SetDanhSachUsersAndGroup(route.params?.danhSachUsersAndGroup);
    }
    if (
      arrayIsEmpty(route?.params?.danhSachUsersAndGroup) &&
      dataUsersAndGroup
    ) {
      const tmp = dataUsersAndGroup.map(
        (it) =>
        (it = {
          ...it,
          isSellectedVBBH: false,
          isSellectedVBDi: false,
        })
      );
      SetDanhSachUsersAndGroup(tmp);
    }
  }, [
    dataUsersAndGroup,
    route?.params?.danhSachUsersAndGroup,
    navigation,
  ]);

  const onGoBack = useCallback(() => {
    navigation.goBack();
  }, []);
  const chooseTypePress = useCallback(
    (ID) => {
      let tmp = [];
      if (route?.params?.screenName === "VBDaBanHanhDetailScreen") {
        tmp = danhSachUsersAndGroup.map((it: any) =>
          it.ID === ID ? { ...it, isSellectedVBBH: !it.isSellectedVBBH } : it
        );
        SetDanhSachUsersAndGroup(tmp);
      } else {
        tmp = danhSachUsersAndGroup.map((it: any) =>
          it.ID === ID ? { ...it, isSellectedVBDi: !it.isSellectedVBDi } : it
        );
      }
      SetDanhSachUsersAndGroup(tmp);
    },
    [danhSachUsersAndGroup]
  );

  const onDonePress = useCallback(() => {
    navigation.navigate({
      name: "VBDaBanHanhDetailScreen",
      params: { danhSachUsersAndGroup },
    });
  }, [navigation, danhSachUsersAndGroup]);

  const onChangeFilterText = useCallback(
    (text: string) => {
      setFilterText(text);
    },
    [filterText]
  );
  useEffect(() => {
    const filteredArray = danhSachUsersAndGroup.filter((item: any) =>
      item?.FullName.includes(filterText)
    );
    setFilterdanhSachUsersAndGroup(filteredArray);
  }, [filterText, danhSachUsersAndGroup]);

  return (
    <View style={styles.container}>
      <View style={styles.viewHeader}>
        <View style={styles.flexDirectionRow}>
          <TouchableOpacity
            style={styles.backPress}
            activeOpacity={1}
            onPress={onGoBack}
          >
            <BackIcon />
          </TouchableOpacity>
          <Text style={styles.titleHeader}>
            Chọn người dùng và nhóm người dùng
          </Text>
          <TouchableOpacity style={styles.iconDone} onPress={onDonePress}>
            <DoneIcon />
          </TouchableOpacity>
        </View>
        <SearchInput
          onChangeFilterText={onChangeFilterText}
          filterText={filterText}
        />
      </View>

      <FlatList
        contentContainerStyle={styles.flatlist}
        data={
          filterdanhSachUsersAndGroup
            ? filterdanhSachUsersAndGroup
            : danhSachUsersAndGroup
        }
        extraData={danhSachUsersAndGroup}
        renderItem={({ item, index }) => (
          <Item
            index={index}
            item={item}
            token={token}
            subSite={subSite}
            chooseTypePress={(ID) => chooseTypePress(ID)}
            screenName={route?.params?.screenName}
          />
        )}
        keyExtractor={(item: any) => item?.ID}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
  flatlist: {
    backgroundColor: "#FFFFFF",
    margin: 16,
    borderRadius: 8,
  },
  viewItemContent: { alignItems: "flex-start", flex: 1 },
  item: {
    height: 60,
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 15,
    borderStyle: "dashed",
    borderTopWidth: 1,
    borderTopColor: "#E5E5E5",
  },
  title: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  position: {
    fontSize: dimensWidth(13),
    lineHeight: dimensWidth(20),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  viewHeader: {
    backgroundColor: colors.primary,
    height: 100,
    justifyContent: "center",
    width: "100%",
    padding: 10,
  },
  titleHeader: {
    flex: 1,
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  backPress: {
    padding: 8,
  },
  iconDone: {
    marginEnd: 15,
  },
});

export default App;
