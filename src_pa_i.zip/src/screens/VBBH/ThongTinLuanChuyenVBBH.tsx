import React, { useCallback, useState, useEffect, useMemo } from "react";
import {
  View,
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  Alert,
  Image,
  SectionList,
} from "react-native";
import { BackIcon, DashedLine, RetangleGreenIcon } from "assets/SVG/index";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import { useDispatch, useSelector } from "react-redux";
import {
  format_yy_mm_mm_dd_hh,
  format_mm_dd_yy,
  removeSpecialCharacters,
  arrayIsEmpty,
  groupThongTinLuanChuyen,
  format_dd_mm_yyyy_hh_mm,
  isNullOrUndefined,
  stripHtml,
} from "helpers/formater";
import {
  fetchThongTinLuanChuyenVbBh,
  fetchNguoiXemVbBh,
  fetchThongTinLuanChuyenVbBhDonViNhan,
} from "stores/VBBH/reducer";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { create } from "react-test-renderer";
import { NoDataView } from "components";
import FastImage from "react-native-fast-image";
import { BaseUrl } from "~/services/api";

type ItemProps = {
  index: number;
  item: any;
  token: any,
  subSite: any;
};
type Props = {
  navigation: any;
  route: any;
};

const Item = ({ item, index, subSite, token }: ItemProps) => {
  const {
    Action,
    ImagePath,
    Position,
    UserName,
    isLast,
    Created,
  } = item;
  const formatActionText = useMemo(() => {
    const formatText = stripHtml(Action)
    return formatText
  }, [Action]);
  return (
    <View style={{ flex: 1, flexDirection: 'row' }}>
       <View style={{ marginLeft: 22 }}>
        <DashedLine color={isLast ? "#fff" : "#B3B3B3"} height="100%" width={2} />
      </View>
      <View
        style={styles.item}
      >
        <View style={{
          flex: 1,
          flexDirection: 'row'
        }}>
          <View style={{ flex: 1 }}>
            <View style={{ flexDirection: 'row' }}>
              <FastImage
                source={{
                  uri: BaseUrl + "/" + subSite + ImagePath,
                  headers: {
                    Authorization: `${token}`
                  }
                }}
                style={styles.viewUserImage}
                resizeMode={FastImage.resizeMode.contain}
                defaultSource={require("../../assets/images/avatar80.png")}
              />
              <View style={{ flex: 1 }}>
                <Text style={styles.titleContent} numberOfLines={1}>
                  {UserName}
                </Text>
                <Text style={styles.textPosition} numberOfLines={1}>
                  {removeSpecialCharacters(Position)}
                </Text>
              </View>
            </View>
          </View>

          <View style={{ flex: 1 }}>
            <Text style={styles.date} numberOfLines={1}>
              {format_dd_mm_yyyy_hh_mm(Created)}
            </Text>
            <View style={styles.content}>
              <Text style={{
                color: colors.textBlack19,
                fontSize: dimensWidth(12),
                fontWeight: "400",
                fontFamily: "arial",
              }}>
                {formatActionText}
              </Text>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};

const ItemTab = ({ item, onChangeSelectedTab }: any) => {
  return (
    <TouchableOpacity
      activeOpacity={1}
      style={
        item.isSelected ? styles.onPressActiveTab : styles.onPressInActiveTab
      }
      onPress={() => onChangeSelectedTab(item.id)}
    >
      <Text
        style={[
          item.isSelected ? styles.titleActiveTab : styles.titleInActiveTab,
          item.id == 2 && { marginEnd: 20 },
        ]}
      >
        {item.tabName}
      </Text>
    </TouchableOpacity>
  );
};
const ItemVBDenNguoiXem = ({ item, index, token, subSite }: any) => {
  const { UserName, Position, ImagePath, ID, Created } = item;
  const isOdd = index % 2 === 0;
  return (
    <View
      style={[
        styles.flexDirectionRow,
        isOdd && { backgroundColor: colors.alice_blue },
      ]}
    >
      <View>
        {ImagePath && (
          <FastImage
            style={{
              height: 40,
              width: 40,
              borderRadius: 20,
              marginLeft: 15,
            }}
            source={{
              uri: `${BaseUrl}/${subSite}${ImagePath}`,
              headers: { Authorization: `${token}` },
              priority: FastImage.priority.normal,
            }}
          />
        )}
      </View>
      <View style={{ flex: 1, padding: 15 }}>
        <View style={styles.flexDirectionRowBetween}>
          <Text style={styles.titleContentVBdenDSNguoiXem} numberOfLines={1}>
            {UserName}
          </Text>
          <Text style={[styles.contentVBDenDSNguoiXem]} numberOfLines={1}>
            {format_yy_mm_mm_dd_hh(Created)}
          </Text>
        </View>
        <Text style={[styles.positionVBDenDSNguoiXem]} numberOfLines={1}>
          {removeSpecialCharacters(Position)}
        </Text>
      </View>
    </View>
  );
};
const ItemVBThongTinDonViNhan = ({ item, index, subSite, token }: any) => {
  const { SiteName, Position, ImagePath, ID, Created } = item;
  const isOdd = index % 2 === 0;
  return (
    <View
      style={[
        styles.flexDirectionRow,
        isOdd && { backgroundColor: colors.alice_blue },
      ]}
    >
      <View>
        {ImagePath && (
          <FastImage
            style={{
              height: 40,
              width: 40,
              borderRadius: 20,
              marginLeft: 15,
            }}
            source={{
              uri: `${BaseUrl}/${subSite}${ImagePath}`,
              headers: { Authorization: `${token}` },
              priority: FastImage.priority.normal,
            }}
          />
        )}
      </View>
      <View style={{ flex: 1, padding: 15 }}>
        <Text style={styles.titleContentVBdenDSNguoiXem} numberOfLines={1}>
          {SiteName}
        </Text>
        <View style={styles.flexDirectionRowBetween}>
          <Text style={[styles.positionVBDenDSNguoiXem]} numberOfLines={1}>
            {"Đơn vị thành viên"}
          </Text>
          <Text style={[styles.contentVBDenDSNguoiXem]} numberOfLines={1}>
            {format_mm_dd_yy(Created)}
          </Text>
        </View>
      </View>
    </View>
  );
};

const ThongTinLuanChuyen = ({ navigation, route }: Props) => {
  const {
    dataThongTinLuyenChuyenVbBh,
    dataDanhSachNguoiXemVbBh,
    dataThongTinLuyenChuyenVbBhDonViNhanVbBh,
  } = useSelector((state: RootState) => state.vbBhReducer);
  const {
    subSite,
    token
  } = useSelector((state: RootState) => state.login);
  const [dataTab, setdataTab] = useState([
    {
      tabName: "Thông tin luân chuyển",
      id: 0,
      isSelected: true,
    },
    {
      tabName: "Danh sách người xem",
      id: 1,
      isSelected: false,
    },
    {
      tabName: "Thông tin đơn vị nhận",
      id: 2,
      isSelected: false,
    },
  ]);
  const [selectedIndexTab, setselectedIndexTab] = useState(0);
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const fetchThongTinLuanChuyenVbBhRequest = useCallback(
    (itemId: any) => {
      dispatch(
        fetchThongTinLuanChuyenVbBh({
          itemId,
          subSite
        })
      );
    },
    [dispatch]
  );
  const fetchNguoiXemVbBhRequest = useCallback(
    (itemId: any) => {
      dispatch(fetchNguoiXemVbBh({ itemId, subSite }));
    },
    [dispatch]
  );
  const fetchThongTinLuanChuyenVbBhDonViNhanRequest = useCallback(
    (itemId: any) => {
      dispatch(fetchThongTinLuanChuyenVbBhDonViNhan({ itemId, subSite }));
    },
    [dispatch]
  );
  const thongTinLuanChuyenConvertData = useMemo(() => {
    const data = groupThongTinLuanChuyen(dataThongTinLuyenChuyenVbBh);
    return data;
  }, [dataThongTinLuyenChuyenVbBh]);
  useEffect(() => {
    if (route?.params?.itemId) {
      if (selectedIndexTab === 0) {
        fetchThongTinLuanChuyenVbBhRequest(route?.params?.itemId);
      } else if (selectedIndexTab === 1) {
        fetchNguoiXemVbBhRequest(route?.params?.itemId);
      } else {
        fetchThongTinLuanChuyenVbBhDonViNhanRequest(route?.params?.itemId);
      }
    }
  }, [
    fetchThongTinLuanChuyenVbBhRequest,
    route?.params?.itemId,
    selectedIndexTab,
  ]);

  const onGoBack = useCallback(() => {
    navigation.goBack();
  }, [navigation]);

  const onChangeSelectedTab = useCallback((id: number) => {
    const tmp = dataTab.map((it: any) =>
      it.id === id ? { ...it, isSelected: true } : { ...it, isSelected: false }
    );
    const newSelectedIndexTab = tmp.findIndex((it) => it.isSelected === true);
    setselectedIndexTab(newSelectedIndexTab);
    setdataTab(tmp);
  }, []);


  const lastItem = useMemo(() => {
    if (!arrayIsEmpty(dataThongTinLuyenChuyenVbBh)) {
      const last = dataThongTinLuyenChuyenVbBh[dataThongTinLuyenChuyenVbBh.length - 1].data;
      return last[last.length - 1];
    }
  }, [dataThongTinLuyenChuyenVbBh])

  return (
    <View style={styles.container}>
      <View style={styles.viewHeader}>
        <View style={styles.flexDirectionRow}>
          <TouchableOpacity style={styles.backPress} onPress={onGoBack}>
            <BackIcon />
          </TouchableOpacity>
          <Text style={styles.titleHeader}>Thông tin luân chuyển</Text>
        </View>
      </View>

      <View>
        <FlatList
          data={dataTab}
          extraData={dataTab}
          horizontal
          renderItem={({ item, index }) => (
            <ItemTab item={item} onChangeSelectedTab={onChangeSelectedTab} />
          )}
          showsHorizontalScrollIndicator={false}
          keyExtractor={(item) => item?.id}
        />
      </View>
      {selectedIndexTab === 0 && (
        <>
          {arrayIsEmpty(dataThongTinLuyenChuyenVbBh) ? (
            <NoDataView />
          ) : (
            <SectionList
              style={{
                backgroundColor: 'white',
                borderRadius: 8,
                shadowColor: '#000000',
                shadowOffset: {
                  width: 0,
                  height: 0
                },
                shadowRadius: 8,
                shadowOpacity: 0.1,
                elevation: 1,
                margin: 20,
                paddingTop: 10
              }}
              sections={dataThongTinLuyenChuyenVbBh}
              keyExtractor={(item, index) => item + index}
              renderItem={({ item, index }) => (
                <Item
                  item={item}
                  index={index}
                  subSite={subSite}
                  token={token}
                />
              )}
              renderSectionHeader={({ section: { title } }) => (
                <View style={styles.containerFlatlist}>
                  <View style={styles.flexDirectionRow}>

                    <View style={{
                      marginRight: dimensWidth(10)
                    }}>
                      <RetangleGreenIcon />
                    </View>
                    <Text style={styles.title} numberOfLines={1}>
                      {!isNullOrUndefined(title) ? title.split(';#')[1] : ""}
                    </Text>
                  </View>
                </View>
              )}
            />
          )}
        </>
      )}
      {selectedIndexTab === 1 && (
        <>
          {arrayIsEmpty(dataDanhSachNguoiXemVbBh) ? (
            <NoDataView />
          ) : (
            <FlatList
              style={[styles.containerFlatlist, { marginTop: 15 }]}
              contentContainerStyle={styles.viewDSNguoiXem}
              extraData={dataDanhSachNguoiXemVbBh}
              disableVirtualization
              keyExtractor={(item) => item?.ID}
              data={dataDanhSachNguoiXemVbBh}
              renderItem={({ item, index }) => (
                <ItemVBDenNguoiXem item={item} index={index} subSite={subSite} token={token} />
              )}
            />
          )}
        </>
      )}
      {selectedIndexTab === 2 && (
        <>
          {arrayIsEmpty(dataThongTinLuyenChuyenVbBhDonViNhanVbBh) ? (
            <NoDataView />
          ) : (
            <FlatList
              style={styles.containerFlatlist}
              contentContainerStyle={styles.viewDSNguoiXem}
              extraData={dataThongTinLuyenChuyenVbBhDonViNhanVbBh}
              disableVirtualization
              keyExtractor={(item) => item?.ID}
              data={dataThongTinLuyenChuyenVbBhDonViNhanVbBh}
              renderItem={({ item, index }) => (
                <ItemVBThongTinDonViNhan item={item} index={index} subSite={subSite} token={token} />
              )}
            />
          )}
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
  viewDSNguoiXem: {
    borderRadius: 8,
    overflow: "hidden",
    backgroundColor: colors.white,
  },
  viewUserName: { marginRight: 20, marginLeft: -8 },
  viewUserImage: {
    height: 40,
    width: 40,
    borderRadius: 20,
    marginLeft: 40,
  },
  flatlist: {
    borderRadius: 8,
    backgroundColor: colors.white,
    overflow: "hidden",
  },
  containerFlatlist: {
    marginLeft: 15,
    marginRight: 15,
  },
  item: {
    flex: 1,
    paddingBottom: 20,
    paddingTop: 10
    // borderLeftColor: "#B3B3B3",
    // borderLeftWidth: 1,
    // borderStyle: "dashed",
  },
  title: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: "700",
    fontFamily: "arial",
  },
  titleContent: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 10,
    backgroundColor: colors.lightBlue,
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderRadius: 3
  },
  date: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    flex: 1,
    marginLeft: 15,
    alignSelf: 'flex-end',
    marginRight: 10,
    paddingVertical: 4,
  },
  viewHeader: {
    backgroundColor: colors.primary,
    height: 55,
    justifyContent: "center",
    width: "100%",
    paddingHorizontal: 10,
  },
  titleHeader: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  flexDirectionRowBetween: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  backPress: {
    padding: 8,
  },
  onPressActiveTab: {
    height: 60,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.white,
    borderBottomColor: colors.primary,
    borderBottomWidth: 1,
    paddingLeft: 20,
  },
  onPressInActiveTab: {
    height: 60,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.white,
    paddingLeft: 20,
  },
  titleActiveTab: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.primary,
    fontWeight: "700",
    fontFamily: "arial",
  },
  titleInActiveTab: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.grey999,
    fontWeight: "400",
    fontFamily: "arial",
  },
  titleContentVBdenDSNguoiXem: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
  },
  contentVBDenDSNguoiXem: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
  },
  positionVBDenDSNguoiXem: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
  },
  textPosition: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginTop: 5
  },
});

export default ThongTinLuanChuyen;
