import React, { useCallback, useState, useEffect, useMemo } from "react";
import {
  SafeAreaView,
  View,
  FlatList,
  Text,
  StatusBar,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  RefreshControl,
} from "react-native";
import styles from "./VBBH.Style";
import {
  calculateBetweenTwoDate,
  formatCreatedDate,
  arrayIsEmpty,
  checkIsEmpty,
  format_yy_mm_mm_dd_hh,
  isNullOrEmpty
} from "helpers/formater";
import { SearchIcon, FilterIcon, MenuIcon } from "assets/SVG/index";
import FilterModal from "./components/FilterModal";
import { RootState } from "stores";
import SearchInput from "~/components/SearchInput";
import colors from "themes/Colors";
import { fetchVBDaBanHanhApi, resetVBBhDaBanHanhData } from "stores/VBBH/reducer";
import { useDispatch, useSelector } from "react-redux";
import CalendarPickerModal from "./components/CalendarPickerModal";
import moment from "moment";
import { NoDataView } from "components";
import { ThunkDispatch } from "@reduxjs/toolkit";
import FastImage from "react-native-fast-image";
import { BaseUrl } from "~/services/api";
import { sub } from "react-native-reanimated";
import ImageLoad from "~/components/ImageLoad";

type Props = {
  navigation: any;
  route: any;
};
const Item = ({ item, token, subSite, gotoDetail }: any) => {
  const {
    FullName,
    TrichYeu,
    ImagePath,
    TrangThai,
    Created,
    DueDate,
    Action,
    ID,
  } = item;
  const gotoDetailPress = () => {
    gotoDetail(ID);
  };
  let dueDateFormat = ""
  let isExpired = false
  let isExpiredToday = false
  const distanceDate = calculateBetweenTwoDate(DueDate);
  if (!checkIsEmpty(distanceDate)) {
    if (parseInt(distanceDate) < 0) {
      dueDateFormat = format_yy_mm_mm_dd_hh(DueDate);
    } else if (parseInt(distanceDate) >= 0 && parseInt(distanceDate) < 1) {
      dueDateFormat = "Hạn hôm nay";
      isExpiredToday = true
    }
    else {
      isExpired = true
      dueDateFormat = "Quá hạn " + distanceDate + " ngày";
    }
  }
  const formatCreated = formatCreatedDate(Created);
  return (
    <TouchableOpacity style={styles.item} onPress={gotoDetailPress}>
      <ImageLoad
        style={styles.itemAvatar}
        source={{
          uri: BaseUrl + `/${subSite}` + ImagePath,
          headers: { Authorization: `${token}` },
          priority: FastImage.priority.normal
        }}
      />
      <View style={{ flex: 1 }}>
        <View style={styles.flexDirectionBetween}>
          <Text style={styles.title} numberOfLines={2}>
            {FullName}
          </Text>
          <Text style={styles.date}>{formatCreated}</Text>
        </View>

        <Text style={styles.category}>{'Văn bản ban hành'}</Text>
        <Text style={styles.title}>{TrichYeu}</Text>
        <View style={styles.flexDirectionBetween}>
          <View style={styles.touchSendUnit}>
            <Text style={styles.textSendUnit}>{TrangThai}</Text>
          </View>
          <Text
            style={[
              styles.date,
              isExpiredToday && styles.todayDeadlife,
              isExpired && styles.distanceDate,
            ]}
          >
            {dueDateFormat}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const VBDaBanHanhScreen = ({ route, navigation }: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const { dataVBDaBanHanh, isLoadmoreVBBH, isLoadingVBBh, isGoBackVBBhScreen, isRefreshing } = useSelector((state: any) => state.vbBhReducer);
  const todayFormated = moment().format("YYYY-MM-DD");
  const prevMonth = moment(todayFormated).add(-1, "M").format("YYYY-MM-DD");
  const { subSite, token } = useSelector(
    (state: any) => state.login
  );
  let initialPayloadVBBH = { TinhTrang: "Đã phát hành", FromDate: "", ToDate: "" }
  const [payloadVBBH, setPayloadVBBH] = useState(initialPayloadVBBH);
  const [visbleModalFilter, setVisbleModalFilter] = useState(false);
  const [dataVBDaBanHanhState, setDataVBDaBanHanhState] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [lanhDaoNameSellectedState, setLanhDaoNameSellectedState] =
    useState("");
  const [startDate, setStartDate] = useState(prevMonth);
  const [endDate, setEndDate] = useState(todayFormated);
  const [isOpenCalendarPicker, setIsOpenCalendarPicker] = useState(false);
  const [typeModal, setTypeModal] = useState("startDate");
  const [filterText, setFilterText] = useState("");
  const [Offset, setOffset] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const [isFilter, setIsFilter] = useState(false)

  const fetchVBDaBanHanhRequest = useCallback((payload: any) => {
    dispatch(fetchVBDaBanHanhApi(payload));
  }, [dispatch]);

  useEffect(() => {
    const FilterText = filterText
    const payload = { ...payloadVBBH, FilterText, subSite, Offset }
    fetchVBDaBanHanhRequest(payload);
  }, [dispatch, payloadVBBH, filterText, subSite, Offset]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    setOffset(0);
    setFilterText("");
    setPayloadVBBH(initialPayloadVBBH);
    onReFilterModalPress();
  }, [refreshing]);

  useEffect(() => {
    setRefreshing(isRefreshing);
  }, [refreshing, isRefreshing])

  useEffect(() => {
    if (isGoBackVBBhScreen) {
      onRefresh()
    }
  }, [isGoBackVBBhScreen])

  const onPressFilter = useCallback(() => {
    if (isSearching) setIsSearching(false);
    setVisbleModalFilter(true);
  }, [visbleModalFilter]);
  const onPressSearch = useCallback(() => {
    if (visbleModalFilter) setVisbleModalFilter(false);
    setIsSearching(!isSearching);
  }, [isSearching, visbleModalFilter]);

  const onConfirmModalPress = useCallback(() => {
    setOffset(0)
    setFilterText("")
    setPayloadVBBH({ ...initialPayloadVBBH, FromDate: startDate, ToDate: endDate })
    setVisbleModalFilter(false);
    setIsFilter(true)
  }, [startDate, endDate]);

  const onReFilterModalPress = useCallback(() => {
    setStartDate(prevMonth);
    setEndDate(todayFormated);
    setIsFilter(false)
    setOffset(0)
    setVisbleModalFilter(false)
    let initialPayloadVBBH = { TinhTrang: "Đã phát hành", FromDate: "", ToDate: "" }
    setPayloadVBBH(initialPayloadVBBH)
  }, []);

  useEffect(() => {
    if (dataVBDaBanHanh) {
      setDataVBDaBanHanhState(dataVBDaBanHanh);
      if (refreshing) setRefreshing(false);
    }
  }, [dataVBDaBanHanh]);

  useEffect(() => {
    if (route.params?.lanhDaoNameSellectedParam) {
      setVisbleModalFilter(true);
      setLanhDaoNameSellectedState(route.params?.lanhDaoNameSellectedParam);
    }
  }, [route.params?.lanhDaoNameSellectedParam]);

  const onPressOpenCalendarPicker = useCallback(
    (typeModal: string) => {
      setVisbleModalFilter(false);
      setTypeModal(typeModal);
      setIsOpenCalendarPicker(true);
    },
    [isOpenCalendarPicker, typeModal]
  );

  const onDateChangeModal = useCallback(
    (date: any) => {
      if (typeModal == "startDate") {
        setStartDate(date);
      } else {
        setEndDate(date);
      }
      setIsOpenCalendarPicker(false);
      setVisbleModalFilter(true);
    },
    [typeModal, startDate, endDate]
  );
  const onCloseModal = useCallback(() => {
    setIsOpenCalendarPicker(false);
  }, []);
  const onChangeFilterText = useCallback(
    (text: string) => {
      setFilterText(text);
    },
    [filterText]
  );
  const removeSelectedDate = useCallback(() => {
    if (typeModal == "startDate") {
      setStartDate("");
    } else {
      setEndDate("");
    }
  }, [typeModal, startDate, endDate]);
  const resetToday = useCallback(
    (today: any) => {
      setStartDate(today);
      setEndDate(today);
    },
    [typeModal, startDate, endDate]
  );
  const gotoDetailPress = useCallback((DocumentID: Number, ListName: string) => {
    navigation.navigate({
      name: "VBDaBanHanhDetailScreen",
      params: { DocumentID, ListName },
    });
    const newData = dataVBDaBanHanh.map((it: any) => it.DocumentID === DocumentID ? { ...it, Read: true } : it)
    setDataVBDaBanHanhState(newData);
  }, [dataVBDaBanHanh]);

  const handleLoadmore = async () => {
    if (!isLoadingVBBh && isLoadmoreVBBH) {
      const newOffset = dataVBDaBanHanh.length;
      setOffset(newOffset)
    }
  };

  const openDrawer = useCallback(() => {
    navigation.openDrawer();
  }, [navigation]);
  const renderFooter = (isLoadingVBBh: boolean, refreshing: boolean, isLoadMoreVbDi: boolean, Offset: any) => {
    return (
      //Footer View with Load More button
      <View style={styles.footer}>
        {isLoadingVBBh && !refreshing && isLoadMoreVbDi && Offset !== 0 ? (
          <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
        ) : null}
      </View>
    );
  };
  return (
    <View style={styles.container}>
      <View style={styles.viewAvatar}>
        <View style={styles.flexDirectionRow}>
          <View style={styles.flexDirectionRow}>
            <TouchableOpacity onPress={openDrawer}>
              <View
                style={styles.avatar}
              >
                <MenuIcon color='#fff' />
              </View>
            </TouchableOpacity>
            <Text style={styles.titleAvatar}>{`Đã phát hành - ${subSite.toUpperCase()}`}</Text>
          </View>
          <View style={styles.flexDirectionRow}>
            <TouchableOpacity style={styles.searchIcon} onPress={onPressSearch}>
              <SearchIcon color={!isSearching ? colors.white : 'red'} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.filterIcon} onPress={onPressFilter}>
              <FilterIcon color={isFilter ? 'red' : '#fff'} />
            </TouchableOpacity>
          </View>
        </View>
        <View style={{ marginTop: 10 }}>
          <SearchInput
            onChangeFilterText={onChangeFilterText}
            filterText={filterText}
          />
        </View>
      </View>
      {!arrayIsEmpty(dataVBDaBanHanhState) ? (
        <FlatList
          contentContainerStyle={styles.containerFlatList}
          data={dataVBDaBanHanhState}
          extraData={dataVBDaBanHanhState}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor='#0054AE' />
          }
          renderItem={({ item }) => (
            <Item item={item} token={token} subSite={subSite} gotoDetail={gotoDetailPress} />
          )}
          keyExtractor={(item, index) => String(index)}
          showsVerticalScrollIndicator={false}
          onEndReachedThreshold={0.5}
          onEndReached={handleLoadmore}
          ListFooterComponent={renderFooter(isLoadingVBBh, refreshing, isLoadmoreVBBH, Offset)}
        />
      ) : (
        <NoDataView />
      )}

      <FilterModal
        onPressFilter={onPressFilter}
        confirmText={"Áp dụng"}
        refilterText={"Thiết lập lại"}
        modalVisible={visbleModalFilter}
        onConfirmModal={onConfirmModalPress}
        onReFilterModal={onReFilterModalPress}
        titleSelected={initialPayloadVBBH.TinhTrang}
        onPressOpenCalendarPicker={onPressOpenCalendarPicker}
        startDate={startDate}
        endDate={endDate}
        lanhDaoNameSellectedState={lanhDaoNameSellectedState}
      />
      <CalendarPickerModal
        modalCalendarVisible={isOpenCalendarPicker}
        onDateChangeModal={onDateChangeModal}
        onCloseModal={onCloseModal}
        startDate={startDate}
        endDate={endDate}
        typeModal={typeModal}
        removeSelectedDate={removeSelectedDate}
        resetToday={resetToday}
      />
    </View>
  );
};

export default VBDaBanHanhScreen;
