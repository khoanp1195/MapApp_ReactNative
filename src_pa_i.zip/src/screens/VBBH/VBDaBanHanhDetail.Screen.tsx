import React, { useCallback, useState, useEffect, useMemo } from "react";
import {
  View,
  FlatList,
  StyleSheet,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
  Platform,
} from "react-native";
import {
  BackIcon,
  ClockWhiteIcon,
  ThreeDotIcon,
  ShareBlueIcon,
  HoSoDuThaoIcon,
} from "assets/SVG/index";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import TextInputCustom from "components/TextInputCustom";
// import RNFetchBlob from 'react-native-fetch-blob';
import {
  SetisLoadingDetail,
  fetchVBBHAttachFile,
  fetchVBDaBanHanhDetailApi,
  vbDaBanHanhChiaSeApi,
} from "stores/VBBH/reducer";
import { useDispatch, useSelector } from "react-redux";
import ChoYKienLanhDaoModal from "./components/ChoYKienLanhDaoModal";
import ChiaSeModal from "./components/ChiaSeModal";
import {
  format_dd_mm_yy,
  removeSpecialCharacters,
  checkTypeFiles,
  checkTrangThai,
  checkIsEmpty,
  arrayIsEmpty,
  removeNumbersAndHashes,
  splitID,
  isNullOrUndefined,
  byteConverter,
  getExtension,
  checkMimeTypeFiles
} from "helpers/formater";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { EnumPhancong, ActionJsonType } from "./VBBHType";
import { useFocusEffect } from "@react-navigation/native";
import { postReadVanBan } from "~/stores/vbDen/reducer";
import { LoadingView } from "~/components";
import { BaseUrl } from "~/services/api";
import FileViewer from "react-native-file-viewer";

type Props = {
  navigation: any;
  route: any;
};

const App = ({ route, navigation }: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const { dataVBDaBanHanhDetail, isChiaSeVBBHSuccess, dataVBBHAttachFile, isLoadingDetail } = useSelector(
    (state: any) => state.vbBhReducer
  );
  const { subSite } = useSelector(
    (state: any) => state.login
  );
  const {
    isGoBackWaitProcessDocxScreen,
    isChiaSeVBDenDetailSuccess,
    isKetThucVBDenDetailSuccess,
  } = useSelector((state: any) => state.vbDenReducer);
  const { isGoBackWaitProcessDocxDetailScreen } = useSelector(
    (state: any) => state.taskVBDenReducer
  );
  const {
    CoQuanGui,
    DocumentDate,
    ReceivedDate,
    SoDen,
    DoKhan,
    DoMat,
    ThoiHanGQ,
    TrichYeu,
    ActionJson,
    DocumentType,
    SoVanBan,
    SoVanBanText,
    ID,
    InfoVBDi
  } = dataVBDaBanHanhDetail;
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [modalChiaSe, setModalChiaSe] = useState(false);
  const [modalYKienLanhDao, setModalYKienLanhDao] = useState(false);
  const [danhsachToChucPhanCong, setDanhsachToChucPhanCong] = useState<any>([]);
  const [yKienLanhDao, setYKienLanhDao] = useState("");
  const [danhSachUsersAndGroupState, setDanhSachUsersAndGroupState] = useState(
    []
  );
  const [chiaSeStringList, setChiaSeStringList] = useState("");
  const [typeModal, setTypeModal] = useState<ActionJsonType>(null);

  const [DocumentID, setDocumentID] = useState("");
  useFocusEffect(
    React.useCallback(() => {
      if (typeModal === ActionJsonType.ChiaSe) {
        setModalChiaSe(true);
      }
    }, [typeModal])
  );

  const resetNewScreen = useCallback(() => {
    setYKienLanhDao("");
    setIsFullScreen(false);
    setDanhsachToChucPhanCong([]);
  }, []);
  useEffect(() => {
    if (!arrayIsEmpty(route.params?.danhsachToChucPhanCong)) {
      setDanhsachToChucPhanCong(route.params?.danhsachToChucPhanCong);
    }
  }, [route.params?.danhsachToChucPhanCong]);

  const fetchVBBHAttachFileRequest = useCallback(
    (DocumentID: number) => {
      dispatch(
        fetchVBBHAttachFile({
          DocumentID,
          subSite
        })
      );
    },
    [dispatch]
  );

  const onGoBack = useCallback(() => {
    navigation.goBack();
  }, []);
  const gotoThongTinLuanChuyenVBBHScreen = useCallback(() => {
    navigation.navigate({
      name: "ThongTinLuanChuyenVBBHScreen",
      params: { itemId: dataVBDaBanHanhDetail?.ID },
    });
  }, [dataVBDaBanHanhDetail]);

  const onActionPress = useCallback(
    (ID: number) => {
      if (ID === ActionJsonType.ChiaSe) setModalChiaSe(true);
      if (ID === ActionJsonType.HoSoDuThao) onConfirmHoSoDuThao();
    },
    [modalChiaSe, route.params?.typeModal, dataVBDaBanHanhDetail]
  );
  const onConfirmHoSoDuThao = useCallback(
    () => {
      if (!isNullOrUndefined(dataVBDaBanHanhDetail?.InfoVBDi)) {
        const DocumentID = splitID(dataVBDaBanHanhDetail?.InfoVBDi)
        navigation.navigate({
          name: "VBDiDetailScreen",
          params: { DocumentID, ListName: "Văn bản đi" },
        });
      }
    }, [dataVBDaBanHanhDetail],
  )

  const onChooseTypeChiaSe = useCallback(() => {
    setModalChiaSe(false);
    setTypeModal(ActionJsonType.ChiaSe);
    navigation.navigate({
      name: "ChooseNhomNguoiDungVBBHScreen",
      params: {
        danhSachUsersAndGroup: danhSachUsersAndGroupState,
        screenName: "VBDaBanHanhDetailScreen",
      },
    });
  }, [danhSachUsersAndGroupState]);
  useEffect(() => {
    setDanhSachUsersAndGroupState(route?.params?.danhSachUsersAndGroup);
  }, [route?.params?.danhSachUsersAndGroup]);
  useEffect(() => {
    if (isChiaSeVBBHSuccess) {
      setDanhSachUsersAndGroupState((prevState: any) => {
        const newData = prevState?.map(
          (it: any) => (it = { ...it, isSellectedVBBH: false })
        );
        return newData;
      });
      setChiaSeStringList("");
    }
  }, [isChiaSeVBBHSuccess, danhSachUsersAndGroupState]);

  const filterdanhSachUsersAndGroup = useMemo(() => {
    const data = danhSachUsersAndGroupState?.filter(
      (it: any) => it?.isSellectedVBBH
    );
    return data;
  }, [danhSachUsersAndGroupState]);
  useEffect(() => {
    if (!arrayIsEmpty(filterdanhSachUsersAndGroup)) {
      let displayString = "";
      const dataLength = filterdanhSachUsersAndGroup?.length;
      filterdanhSachUsersAndGroup.forEach((it: any, index: any) => {
        displayString =
          index + 1 !== dataLength
            ? displayString + it?.FullName + "; "
            : displayString + it?.FullName;
      });
      setChiaSeStringList(displayString);
    }
  }, [filterdanhSachUsersAndGroup]);

  const onCloseModalYKienLanhDao = useCallback(() => {
    setModalYKienLanhDao(false);
  }, []);

  const onConfirmModalYKienLanhDao = useCallback(
    (text: string) => {
      setModalYKienLanhDao(false);
      setYKienLanhDao(text);
    },
    [yKienLanhDao]
  );

  const onConfirmModalChiaSe = useCallback(
    (text: string) => {
      if (arrayIsEmpty(filterdanhSachUsersAndGroup)) {
        alert("Vui lòng chọn người bạn muốn chia sẻ!");
      } else {
        let UserShared = "";
        filterdanhSachUsersAndGroup.forEach((it: any, index: any) => {
          UserShared = checkIsEmpty(UserShared)
            ? it?.AccountID + ";#" + it?.AccountName
            : UserShared + ";#" + it?.AccountID + ";#" + it?.AccountName;
        });
        dispatch(
          vbDaBanHanhChiaSeApi({
            UserShared,
            Comment: text,
            DocumentID,
            subSite
          })
        );
        setModalChiaSe(false);
      }
    },
    [filterdanhSachUsersAndGroup, DocumentID]
  );

  const onCloseModalChiaSe = useCallback(() => {
    setModalChiaSe(false);
  }, [yKienLanhDao]);

  const onOpenModalYKienLanhDao = useCallback(() => {
    setModalYKienLanhDao(true);
  }, []);

  const downloadFile = useCallback(async (dataAttach: any) => {
    dispatch(SetisLoadingDetail(true))
    const { config, fs } = RNFetchBlob;
    const date = new Date();
    const typeFile = getExtension(dataAttach?.Url)
    const mimeType = checkMimeTypeFiles(dataAttach?.Url);
    const { DownloadDir } = fs.dirs; // You can check the available directories in the wiki.
    const replaceTitle = dataAttach?.Title.replaceAll(" ", "_");
    const localPath = `${DownloadDir}/${Math.floor(date.getTime() + date.getSeconds() / 2)}_${replaceTitle}`
    const options = {
      fileCache: true,
      mime: mimeType,
      appendExt: typeFile,
      path: localPath,
    };
    const encodeUri = encodeURI(dataAttach?.Url)
    const url = `${BaseUrl}/_layouts/15/VuThao.PA.Api/ApiDownload.ashx?file=${encodeUri}`
    config(options)
      .fetch('GET', url)
      .then((res) => {
        FileViewer.open(localPath, {
          // showOpenWithDialog: true,
        }).catch(error => {
          dispatch(SetisLoadingDetail(false))
          Alert.alert('Thông báo', 'Đã có lỗi xảy ra. Vui lòng thử lại', [
            { text: 'Đóng' }
          ])
        });
        dispatch(SetisLoadingDetail(false))
      })
      .catch((error) => {
        dispatch(SetisLoadingDetail(false))
        Alert.alert('Thông báo', 'Đã có lỗi xảy ra. Vui lòng thử lại', [
          { text: 'Đóng' }
        ])
      });
  }, []);

  const gotoFileViewScreen = useCallback((item: any) => {
    if (Platform.OS !== "ios") {
      downloadFile({ ...item, Url: BaseUrl + item?.Url })
    } else {
      navigation.navigate({
        name: "FileViewScreen",
        params: { item },
      });
    }
  }, []);
  const onChangeIsFullScren = useCallback(
    (item: any) => {
      setIsFullScreen(!isFullScreen);
    },
    [isFullScreen]
  );

  const DocumentDateFormat = useMemo(() => {
    if (!DocumentDate) return "";
    return format_dd_mm_yy(DocumentDate);
  }, [DocumentDate]);

  const ReceivedDateFormat = useMemo(() => {
    if (!ReceivedDate) return "";
    return format_dd_mm_yy(ReceivedDate);
  }, [ReceivedDate]);

  const ThoiHanGQFormat = useMemo(() => {
    if (!ThoiHanGQ) return "";
    return format_dd_mm_yy(ThoiHanGQ);
  }, [ThoiHanGQ]);

  const DocumentTypeFormat = useMemo(() => {
    if (!DocumentType) return "";
    return removeSpecialCharacters(DocumentType);
  }, [DocumentType]);
  const CoQuanGuiFormat = useMemo(() => {
    if (!CoQuanGui) return "";
    return removeSpecialCharacters(CoQuanGui);
  }, [CoQuanGui]);

  useEffect(() => {
    if (route?.params?.typeModal) {
      const typeModal = route.params?.typeModal;
      onActionPress(typeModal);
    }
  }, [route.params?.typeModal, navigation, route?.params]);

  const fetchVBDaBanHanhDetailApiRequest = useCallback(
    (DocumentID: number) => {
      dispatch(
        fetchVBDaBanHanhDetailApi({
          DocumentID,
          subSite
        })
      );
    },
    [dispatch]
  );
  useEffect(() => {
    if (route.params?.DocumentID) {
      setDocumentID(route?.params?.DocumentID);
      resetNewScreen();
    }
  }, [route?.params?.DocumentID]);
  useEffect(() => {
    if (
      isGoBackWaitProcessDocxScreen ||
      isChiaSeVBDenDetailSuccess ||
      isKetThucVBDenDetailSuccess
    ) {
      navigation.goBack();
      resetNewScreen();
    }
  }, [
    isGoBackWaitProcessDocxScreen,
    isChiaSeVBDenDetailSuccess,
    isKetThucVBDenDetailSuccess,
  ]);
  const postReadVanBanRequest = useCallback(
    ({ DocumentID, subSite, ListName }: any) => {
      dispatch(
        postReadVanBan(
          {
            DocumentID,
            subSite,
            ListName
          }
        )
      );
    },
    [dispatch]
  );
  useEffect(() => {
    if (DocumentID || isGoBackWaitProcessDocxDetailScreen) {
      if (isChiaSeVBDenDetailSuccess || isGoBackWaitProcessDocxDetailScreen) {
        resetNewScreen();
      }
      fetchVBDaBanHanhDetailApiRequest(DocumentID);
      fetchVBBHAttachFileRequest(DocumentID);
      postReadVanBanRequest({ DocumentID, ListName: route.params?.ListName, subSite });
    }
  }, [
    fetchVBDaBanHanhDetailApiRequest,
    fetchVBBHAttachFileRequest,
    DocumentID,
    isChiaSeVBDenDetailSuccess,
    isGoBackWaitProcessDocxScreen,
    isGoBackWaitProcessDocxDetailScreen,
    route.params?.ListName
  ]);

  const onShowFullTrichYeu = useCallback(() => {
    Alert.alert("", TrichYeu, [{ text: "OK", onPress: () => { } }]);
  }, [TrichYeu]);

  const gotoNhiemVuDaPhanCongScreen = useCallback(
    (ID: number) => {
      // navigation.navigate({
      //   name: "NhiemVuDaPhanCongScreen",
      //   params: { DocumentID, taskID: ID },
      // });
    },
    [DocumentID]
  );

  const ItemAttach = ({ item, index }: any) => {
    const { Author, Created, Category, Size, Url, Title } = item;
    const createdFormated = Created ? format_dd_mm_yy(Created) : null;
    const sizeFormated = !isNullOrUndefined(Size) ? byteConverter(Size) : "";
    const FileIcon = () => {
      return checkTypeFiles(Url);
    };
    const isOdd = index % 2 === 0;
    return (
      <TouchableOpacity
        style={[
          styles.documentFileView,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
        onPress={() => gotoFileViewScreen(item)}
      >
        <View
          style={[styles.flexDirectionRowBetween, { alignItems: "flex-start" }]}
        >
          <FileIcon />
          <View style={styles.flexOne}>
            <Text style={styles.titleDocumentFile} numberOfLines={1}>
              {Title}
            </Text>
            <View style={styles.flexDirectionRow}>
              <Text style={styles.sizeDocumentFile} numberOfLines={1}>
                {sizeFormated}
              </Text>
              <Text style={{
                fontSize: FontSize.MEDIUM,
                color: colors.lightBlack,
                fontWeight: "400",
                fontFamily: "arial",
                marginLeft: 15,
                borderRadius: 4,
              }} numberOfLines={1}>
                {Category}
              </Text>
            </View>
          </View>
          <View>
            <Text style={styles.contenAttach} numberOfLines={1}>
              {Author}
            </Text>
            <Text style={{
              alignSelf: 'flex-end',
              fontSize: FontSize.MEDIUM,
              color: colors.lightBlack,
              fontWeight: "400",
              fontFamily: "arial",
              marginLeft: 15,
              borderRadius: 4
            }} numberOfLines={1}>
              {createdFormated}
            </Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };
  const ItemVBDenCommentJson = ({ item, index }: any) => {
    const { Title, Value, UpdateFields, Position, Created } = item;
    const createdFormated = format_dd_mm_yy(Created);
    const isOdd = index % 2 === 0;
    return (
      <View
        style={[
          styles.danhMucItemView,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
      >
        <View
          style={[styles.flexDirectionRowBetween, { alignItems: "flex-start" }]}
        >
          <View style={styles.flexOne}>
            <View style={styles.flexDirectionRowBetween}>
              <Text style={styles.titleCommentJson} numberOfLines={1}>
                {Title}
              </Text>
              <Text style={styles.positionComment} numberOfLines={1}>
                {createdFormated}
              </Text>
            </View>
            <Text style={styles.positionComment} numberOfLines={1}>
              {removeSpecialCharacters(Position)}
            </Text>
            <View style={styles.flexDirectionRow}>
              <Text style={styles.titleCommentJson} numberOfLines={1}>
                {Value}
              </Text>
            </View>
          </View>
        </View>
      </View>
    );
  };
  const ItemVBDenTaskJson = ({
    item,
    index,
    gotoNhiemVuDaPhanCongScreen,
  }: any) => {
    const {
      AssignedToType,
      TrangThai,
      DepartmentTitle,
      Position,
      Created,
      DeThucHien,
      DueDate,
      ID,
    } = item;
    const createdFormated = format_dd_mm_yy(Created);
    const isOdd = index % 2 === 0;
    const customColor = checkTrangThai(TrangThai);
    return (
      <TouchableOpacity
        onPress={gotoNhiemVuDaPhanCongScreen}
        style={[
          styles.danhMucItemView,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
      >
        <View
          style={[styles.flexDirectionRowBetween, { alignItems: "flex-start" }]}
        >
          <View style={styles.flexOne}>
            <Text style={styles.titleVbDenTheoMuc} numberOfLines={1}>
              {DepartmentTitle}
            </Text>
            <View style={styles.flexDirectionRow}>
              <Text style={styles.textTrichYeu} numberOfLines={1}>
                {removeSpecialCharacters(Position)}
              </Text>
              <TouchableOpacity
                style={[
                  styles.viewTrangThai,
                  { backgroundColor: customColor?.backgroundColor },
                ]}
              >
                <Text
                  style={[styles.textTrangThai, { color: customColor?.color }]}
                  numberOfLines={1}
                >
                  {TrangThai}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const IconView = ({ ID }: any) => {
    if (ID === ActionJsonType.ChiaSe)
      return <ShareBlueIcon color={colors.white} dimens={20} />;
    if (ID === ActionJsonType.HoSoDuThao) return <HoSoDuThaoIcon />;
    return <View />;
  };
  const ItemAction = ({ item, index, onActionPress }: any) => {
    if (index >= 2) return null;
    const { Title, ID } = item;
    return (
      <TouchableOpacity
        key={ID}
        style={styles.shareButton}
        onPress={() => onActionPress(ID)}
      >
        <View style={styles.flexDirectionRowAction}>
          <IconView ID={ID} />
          <Text style={styles.tabBarLabelActive} numberOfLines={1}>
            {Title}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  // renderView
  return (
    <View style={styles.container}>
      <View style={styles.viewHeader}>
        <View style={styles.flexDirectionRowBetween}>
          <TouchableOpacity
            style={styles.backPress}
            activeOpacity={1}
            onPress={onGoBack}
          >
            <BackIcon />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={gotoThongTinLuanChuyenVBBHScreen}
            style={styles.thongTinLuanChuyen}
          >
            <ClockWhiteIcon />
          </TouchableOpacity>
        </View>
      </View>
      <ScrollView style={styles.cardView}>
        <TouchableOpacity onPress={onShowFullTrichYeu}>
          <Text style={styles.titleHeader} numberOfLines={2}>
            {TrichYeu}
          </Text>
        </TouchableOpacity>
        <View style={styles.dashed} />
        <TouchableOpacity
          style={styles.threeDotView}
          onPress={onChangeIsFullScren}
        >
          <ThreeDotIcon />
        </TouchableOpacity>
        {isFullScreen && (
          <View>
            <Text style={styles.title}>Số văn bản</Text>
            <Text style={styles.content} numberOfLines={1}>
              {dataVBDaBanHanhDetail?.Title}
            </Text>
            <Text style={styles.title}>Loại văn bản</Text>
            <Text style={styles.content} numberOfLines={1}>
              {DocumentTypeFormat}
            </Text>
            <View>
              <View style={styles.flexDirectionRowBetween}>
                <View style={styles.flexOne}>
                  <Text style={styles.title}>Sổ văn bản</Text>
                  <Text style={styles.content} numberOfLines={1}>
                    {removeSpecialCharacters(SoVanBan)}
                  </Text>
                </View>
                <View style={styles.flexOne}>
                  <Text style={styles.title}>Ngày ban hành</Text>
                  <Text style={styles.content} numberOfLines={1}>
                    {ReceivedDateFormat}
                  </Text>
                </View>
              </View>
            </View>

            <View style={styles.flexOne}>
              <Text style={styles.title}>Người ký văn bản</Text>
              <Text style={styles.content} numberOfLines={1}>
                {removeSpecialCharacters(dataVBDaBanHanhDetail?.NguoiKyVanBan)}
              </Text>
            </View>
            <View style={styles.flexOne}>
              <Text style={styles.title}>Chức vụ</Text>
              <Text style={styles.content} numberOfLines={1}>
                {removeSpecialCharacters(dataVBDaBanHanhDetail?.ChucVu)}
              </Text>
            </View>
            <Text style={styles.title}>Người soạn thảo</Text>
            <Text style={styles.content} numberOfLines={1}>
              {dataVBDaBanHanhDetail?.NguoiSoanThaoText}
            </Text>
            <Text style={styles.title}>Đơn vị soạn thảo</Text>
            <Text style={styles.content} numberOfLines={1}>
              {removeSpecialCharacters(dataVBDaBanHanhDetail?.DonViSoanThao)}
            </Text>
            <View style={styles.flexDirectionRowBetween}>
              <View style={styles.flexOne}>
                <Text style={styles.title}>Độ mật</Text>
                <Text style={styles.content} numberOfLines={1}>
                  {DoMat}
                </Text>
              </View>
              <View style={styles.flexOne}>
                <Text style={styles.title}>Độ khẩn</Text>
                <Text style={styles.content} numberOfLines={1}>
                  {DoKhan}
                </Text>
              </View>
            </View>
            <View></View>
            <View style={[styles.dashed, { marginHorizontal: 15 }]} />
          </View>
        )}
        <Text style={styles.documentFile}>Danh sách nhận văn bản qua mạng</Text>
        <Text style={styles.title}>Cá nhân</Text>
        <Text style={styles.content} numberOfLines={1}>
          {dataVBDaBanHanhDetail?.PeopleText}
        </Text>
        <Text style={styles.title}>Đơn vị</Text>
        <Text style={styles.content} numberOfLines={3}>
          {removeNumbersAndHashes(dataVBDaBanHanhDetail?.DonVi)}
        </Text>
        <Text style={styles.documentFile}>
          Danh sách nhận văn bản ngoài hệ thống
        </Text>
        <Text style={styles.title}>Đơn vị</Text>
        <Text style={styles.content} numberOfLines={3}>
          {removeNumbersAndHashes(dataVBDaBanHanhDetail?.LTDonVi)}
        </Text>
        <View style={styles.dashed} />
        {!checkIsEmpty(dataVBBHAttachFile) && (
          <Text style={styles.documentFile}>Tài liệu đính kèm</Text>
        )}
        {!checkIsEmpty(dataVBBHAttachFile) && (
          <FlatList
            style={styles.containerAttach}
            nestedScrollEnabled
            extraData={dataVBBHAttachFile}
            disableVirtualization
            keyExtractor={(item, index) => item?.ID + index.toString()}
            data={dataVBBHAttachFile}
            renderItem={({ item, index }) => (
              <ItemAttach item={item} index={index} />
            )}
          />
        )}
        <Text style={[styles.documentFile, { marginVertical: 15 }]}>
          Ý kiến lãnh đạo
        </Text>
        <View>
          <TouchableOpacity
            onPress={onOpenModalYKienLanhDao}
            style={styles.yKienLanhDaoTouch}
          />
          <TextInputCustom
            editable={false}
            placeholder="Vui lòng nhập ý kiến"
            placeholderTextColor={colors.grey999}
            multiline
            value={yKienLanhDao}
            style={styles.commentInput}
          />
        </View>
        {!arrayIsEmpty(dataVBDaBanHanhDetail?.CommentJson) && (
          <FlatList
            nestedScrollEnabled
            style={styles.commentJsonFlatlist}
            extraData={dataVBDaBanHanhDetail?.CommentJson}
            disableVirtualization
            horizontal={false}
            keyExtractor={(item) => item?.ID}
            data={dataVBDaBanHanhDetail?.CommentJson}
            renderItem={({ item, index }) => (
              <ItemVBDenCommentJson item={item} index={index} />
            )}
          />
        )}
        <View>
          {!arrayIsEmpty(dataVBDaBanHanhDetail?.TaskJson) && (
            <Text style={[styles.documentFile, { marginTop: 15 }]}>
              Tổ chức phân công thực hiện
            </Text>
          )}
          {!arrayIsEmpty(dataVBDaBanHanhDetail?.TaskJson) && (
            <FlatList
              nestedScrollEnabled
              style={styles.danhMucFlatList}
              extraData={dataVBDaBanHanhDetail?.TaskJson}
              disableVirtualization
              horizontal={false}
              keyExtractor={(item) => item?.ID}
              data={dataVBDaBanHanhDetail?.TaskJson}
              renderItem={({ item, index }) => (
                <ItemVBDenTaskJson
                  item={item}
                  index={index}
                  gotoNhiemVuDaPhanCongScreen={() =>
                    gotoNhiemVuDaPhanCongScreen(item?.ID)
                  }
                />
              )}
            />
          )}
        </View>
        <View style={{ marginBottom: 30 }} />
      </ScrollView>

      {ActionJson && (
        <View style={[styles.actionView]}>
          {ActionJson?.map((item: any, index: any) => {
            return (
              <ItemAction
                key={index}
                item={item}
                index={index}
                onActionPress={onActionPress}
              />
            );
          })}
        </View>
      )}
      
      <ChoYKienLanhDaoModal
        modalVisible={modalYKienLanhDao}
        onCloseModalYKienLanhDao={onCloseModalYKienLanhDao}
        onConfirmModalYKienLanhDao={(text) => onConfirmModalYKienLanhDao(text)}
        yKienLanhDao={yKienLanhDao}
      />
      <ChiaSeModal
        modalVisible={modalChiaSe}
        onCloseModalChiaSe={onCloseModalChiaSe}
        onConfirmModalChiaSe={(text) => onConfirmModalChiaSe(text)}
        yKienLanhDao={yKienLanhDao}
        DocumentID={DocumentID}
        onChooseTypeChiaSe={onChooseTypeChiaSe}
        filterdanhSachUsersAndGroup={filterdanhSachUsersAndGroup}
        chiaSeStringList={chiaSeStringList}
      />
      <LoadingView isLoading={isLoadingDetail} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
  thongTinLuanChuyen: { padding: 3 },
  scrollView: {
    flex: 1,
    paddingBottom: 30,
  },
  cardView: {
    backgroundColor: "#FFFFFF",
    margin: 16,
    borderRadius: 8,
    paddingVertical: 15,
  },
  threeDotView: {
    alignSelf: "flex-end",
    marginRight: 10,
    padding: 10,
  },
  item: {},
  containerAttach: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    marginHorizontal: 15,
    overflow: "hidden",
  },
  dashed: {
    borderStyle: "dashed",
    borderTopWidth: 1,
    borderTopColor: "#E5E5E5",
    marginVertical: 15,
  },
  flexOne: {
    flex: 1,
  },
  content: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginBottom: 10,
  },
  contenAttach: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  title: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  documentFile: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginLeft: 15,
    marginBottom: 10,
  },
  documentFileView: {
    padding: 15,
  },
  viewHeader: {
    backgroundColor: colors.primary,
    height: 55,
    justifyContent: "center",
    width: "100%",
    paddingRight: 15,
    paddingLeft: 7,
  },
  titleHeader: {
    fontSize: FontSize.MEDIUM,
    color: colors.scienceBlue,
    fontWeight: "700",
    fontFamily: "arial",
    paddingHorizontal: 15,
  },
  titleDocumentFile: {
    fontSize: FontSize.MEDIUM,
    color: colors.scienceBlue,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    borderRadius: 4,
  },
  sizeDocumentFile: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    borderRadius: 4,
  },
  flexDirectionRowBetween: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  flexDirectionRowAction: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  backPress: {
    padding: 8,
  },
  tabBarLabelActive: {
    color: colors.white,
    fontWeight: "400",
    fontSize: 18,
    marginLeft: 12,
  },
  viewTabBottomBar: {
    flexDirection: "row",
    height: dimensWidth(68),
    alignItems: "center",
    backgroundColor: colors.blueMedium,
  },
  bottomTab: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
  },
  viewButton: {
    flex: 1,
    alignItems: "center",
  },
  actionMore: {
    padding: 8,
  },
  actionView: {
    height: dimensWidth(68),
    backgroundColor: colors.blueMedium,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  shareButton: {
    flex: 1,
  },
  commentInput: {
    paddingHorizontal: 10,
    borderColor: "#DDDDDD",
    borderWidth: 1,
    borderRadius: 3,
    height: 100,
    marginHorizontal: 15,
    textAlignVertical: "top",
  },
  titleVbDenTheoMuc: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    borderRadius: 4,
  },
  titleCommentJson: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    borderRadius: 4,
  },
  positionComment: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    borderRadius: 4,
  },
  viewTrangThai: {
    height: dimensWidth(22),
    width: dimensWidth(90),
    borderRadius: 3,
    backgroundColor: "#F0F0F0",
    justifyContent: "center",
    alignItems: "center",
  },
  textTrichYeu: {
    flex: 1,
    fontSize: dimensWidth(13),
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 10,
  },
  textTrangThai: {
    fontSize: dimensWidth(12),
    color: "#626262",
    fontWeight: "400",
    fontFamily: "arial",
  },
  danhMucItemView: {
    backgroundColor: colors.white,
    padding: 15,
  },
  hoanTatTextColor: {
    color: "#3ABA32",
  },
  hoanTatBackGroundColor: {
    backgroundColor: "#E6FFE4",
  },
  danhMucFlatList: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    marginHorizontal: 15,
    overflow: "hidden",
  },
  commentJsonFlatlist: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    margin: 15,
    overflow: "hidden",
  },
  yKienLanhDaoTouch: {
    zIndex: 999,
    position: "absolute",
    height: "100%",
    width: "100%",
  },
});

export default App;
