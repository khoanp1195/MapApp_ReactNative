export enum ActionJsonType {
  null,
  HoSoDuThao = 2,
  ChiaSe = 1,
}
export enum TaskVB {
  Luu = 1,
  PhanCong = 2,
  TraoDoiLai = 16,
  HoanTat = 32
}
export enum EnumPhancong {
  null,
  PhongBan = 0,
  ToChucPhanCong = 1,
  PhongBanPhanCongLai = 2,
  BoSungThuHoi = 128
}
export enum RoleVBDen {
  NguoiXem = 0,
  NguoiGiaoViec = 256 || 320,
  NguoiXuLy = 64
}
export enum EnumNguoiGiaoViecVBDen {
  Luu = 1,
  TraoDoiLai = 16,
} 