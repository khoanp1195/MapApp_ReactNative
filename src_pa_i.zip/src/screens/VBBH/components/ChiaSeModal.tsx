import React, { FC, useState, useCallback, useEffect } from "react";
import {
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  TouchableWithoutFeedback,
  Keyboard,
  FlatList,
  ScrollView,
  Dimensions,
} from "react-native";
import colors from "themes/Colors";
import { dimensWidth, dimnensHeight, FontSize } from "themes/const";
import { MemberIcon, UserPlusIcon } from "assets/SVG/index";
import {
  checkIsEmpty,
  arrayIsEmpty,
  removeSpecialCharacters,
  format_dd_mm_yy,
  format_yy_mm_mm_dd_hh,
} from "helpers/formater";
import TextInputCustom from "components/TextInputCustom";
import { useDispatch, useSelector } from "react-redux";
import { fetchVBDaBanHanhDSDaChiaSe, resetVBBhScreen } from "stores/VBBH/reducer";

interface Props {
  modalVisible: Boolean;
  onCloseModalChiaSe: () => void;
  onConfirmModalChiaSe: (text: string) => void;
  yKienLanhDao: string;
  typeChiaSe: string;
  chiaSeStringList: any;
  onChooseTypeChiaSe: () => void;
  DocumentID: any;
  filterdanhSachUsersAndGroup: any[];
}
const ChiaSeModal: FC<Props> = ({
  modalVisible,
  onCloseModalChiaSe,
  yKienLanhDao,
  onConfirmModalChiaSe,
  typeChiaSe,
  onChooseTypeChiaSe,
  chiaSeStringList,
  DocumentID,
  filterdanhSachUsersAndGroup,
  ...props
}: Props) => {
  const [text, setText] = useState("");
  const { dataVBDaBanHanhDSDaChiaSe, isChiaSeVBBHSuccess } = useSelector(
    (state: any) => state.vbBhReducer
  );
  const { subSite } = useSelector(
    (state: any) => state.login
  );
  const dispatch = useDispatch<any>();
  useEffect(() => {
    dispatch(fetchVBDaBanHanhDSDaChiaSe({ DocumentID, subSite }));
  }, [DocumentID]);
  useEffect(() => {
    if (isChiaSeVBBHSuccess) {
      dispatch(fetchVBDaBanHanhDSDaChiaSe({ DocumentID, subSite }));
      dispatch(resetVBBhScreen())

    }
  }, [isChiaSeVBBHSuccess]);

  const onChangeText = useCallback(
    (input: string) => {
      setText(input);
    },
    [text]
  );
  const onConfirm = useCallback(() => {
    onConfirmModalChiaSe(text);
    setText("");
  }, [text, filterdanhSachUsersAndGroup, chiaSeStringList]);
  
  const onCloseModal = useCallback(() => {
    setText(yKienLanhDao);
    onCloseModalChiaSe();
  }, [text]);
  useEffect(() => {
    setText(yKienLanhDao);
  }, [yKienLanhDao]);
  useEffect(() => {
    if (!checkIsEmpty(DocumentID)) {
      setText("");
    }
  }, [DocumentID]);
  const Item = ({ item, index }: any) => {
    const { FullName, Position, Created, Comment } = item;
    const createdFormated = format_yy_mm_mm_dd_hh(Created);
    const isOdd = index % 2 === 0;
    return (
      <View
        style={[
          styles.ItemView,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
      >
        <View
          style={[styles.flexDirectionRowBetween, { alignItems: "flex-start" }]}
        >
          <View style={styles.flexOne}>
            <Text style={styles.textFullName} numberOfLines={1}>
              {FullName}
            </Text>
            <View style={styles.flexDirectionRow}>
              <Text style={styles.textPosition} numberOfLines={1}>
                {Position}
              </Text>
              <Text style={[styles.textDate]} numberOfLines={1}>
                {createdFormated}
              </Text>
            </View>
            <Text style={styles.textComment} numberOfLines={1}>
              {Comment}
            </Text>
          </View>
        </View>
      </View>
    );
  };
  return (
    <Modal
      transparent={true}
      visible={modalVisible}
      {...props}
    >
      <View style={styles.centeredView}>
        <View style={styles.modalView}>
          <View style={styles.viewAssign}>
            <Text style={styles.textAssign}>Chia sẻ</Text>
          </View>
          <ScrollView>
            {/* coppy header */}
            <View>
              <Text style={styles.textType}>
                Chia sẻ <Text style={styles.warning}>(*)</Text>
              </Text>
              <View style={styles.chooseTypeView}>
                <TouchableOpacity
                  style={styles.typeChild}
                  onPress={onChooseTypeChiaSe}
                >
                  <Text style={styles.textFiltedType} numberOfLines={1}>
                    {chiaSeStringList}
                  </Text>
                </TouchableOpacity>
              </View>

              <Text style={styles.textType}>Ý kiến</Text>
              <TextInputCustom
                placeholder="Vui lòng nhập ý kiến"
                placeholderTextColor={colors.grey999}
                multiline
                onChangeText={(text) => onChangeText(text)}
                value={text}
                style={styles.yKienLanhDaoInput}
              />
            </View>
            {!arrayIsEmpty(dataVBDaBanHanhDSDaChiaSe) && (
              <Text style={[styles.titleBold, { marginTop: 15 }]}>
                Danh sách đã chia sẻ
              </Text>
            )}
            {!arrayIsEmpty(dataVBDaBanHanhDSDaChiaSe) && (
              <FlatList
                nestedScrollEnabled
                style={styles.flatlist}
                extraData={dataVBDaBanHanhDSDaChiaSe}
                disableVirtualization
                horizontal={false}
                keyExtractor={(item) => item?.ID}
                data={dataVBDaBanHanhDSDaChiaSe}
                renderItem={({ item, index }) => (
                  <Item item={item} index={index} />
                )}
              />
            )}
          </ScrollView>
          <View style={styles.viewTabBottomBar}>
            <TouchableOpacity
              style={styles.buttonExit}
              onPress={onCloseModal}
            >
              <Text style={styles.buttonExitText} numberOfLines={1}>
                Thoát
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.buttonTransfer}
              onPress={onConfirm}
            >
              <Text style={styles.tabBarLabelActive} numberOfLines={1}>
                Chia sẻ
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "flex-end",
  },
  modalView: {
    marginTop: Dimensions.get('window').height / 3,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    opacity: 1,
    backgroundColor: colors.white,
    borderTopEndRadius: 12,
    borderTopStartRadius: 12,
    overflow: "hidden",
    flex: 1
  },
  chooseTypeView: {
    marginBottom: 15,
    flexDirection: "row",
    alignItems: "center",
    height: 34,
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 3,
    marginHorizontal: 15,
  },
  flexDirection: {
    // height: 67,
    flexDirection: "row",
    paddingHorizontal: 20,
    alignItems: "center",
  },
  stroke: {
    borderWidth: 0.5,
    borderColor: "#999999",
    borderStyle: "dashed",
  },
  textType: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginVertical: 10,
  },
  warning: {
    color: colors.red,
  },
  tabBarLabelActive: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
  },
  textPhongBan: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
    marginLeft: 5,
  },
  viewTabBottomBar: {
    flexDirection: "row",
    // height: dimensWidth(66),
    borderRadius: 8,
    marginVertical: 15,
    justifyContent: "flex-end",
  },
  buttonTransfer: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.blueMedium,
    width: dimensWidth(130),
    height: dimensWidth(34),
    borderRadius: 4,
    marginEnd: 15,
  },
  buttonPhongBan: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.blueMedium,
    height: 34,
    borderRadius: 4,
    marginTop: 10,
    paddingHorizontal: 20,
  },
  buttonExit: {
    alignItems: "center",
    justifyContent: "center",
    width: dimensWidth(130),
    height: dimensWidth(34),
    borderRadius: 4,
  },
  buttonExitText: {
    color: colors.red,
    fontWeight: "400",
    fontSize: FontSize.MEDIUM,
  },
  textAssign: {
    color: colors.blueMedium,
    fontWeight: "700",
    fontSize: FontSize.LARGE,
  },
  viewAssign: {
    backgroundColor: colors.lightBlue,
    padding: 15,
  },
  titleBoss: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginHorizontal: 15,
  },
  yKienLanhDaoInput: {
    paddingHorizontal: 10,
    borderColor: colors.greyDDD,
    borderRadius: 3,
    height: dimensWidth(100),
    borderWidth: 1,
    marginHorizontal: 15,
    marginBottom: 10,
    textAlignVertical: "top",
  },
  typeChild: {
    flexDirection: "row",
    flex: 1,
    alignItems: "center",
    // height: 34,
    // borderColor: colors.greyDDD,
    // borderWidth: 1,
    // borderRadius: 3,
    paddingHorizontal: 15,
    justifyContent: "space-between",
  },
  textFiltedType: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 9,
  },
  textChooseType: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 9,
    marginHorizontal: 10,
  },
  ItemView: {
    backgroundColor: colors.white,
    padding: 15,
  },
  flexDirectionRowBetween: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  textFullName: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
  },
  textComment: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  textPosition: {
    flex: 1,
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 10,
  },
  textDate: {
    fontSize: dimensWidth(12),
    color: "#626262",
    fontWeight: "400",
    fontFamily: "arial",
  },
  flexOne: {
    flex: 1,
  },
  titleBold: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginLeft: 15,
    marginBottom: 10,
  },
  flatlist: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    marginHorizontal: 15,
    overflow: "hidden",
  },
});

export default ChiaSeModal;
