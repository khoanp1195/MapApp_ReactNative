export enum TabNameType {
    VB_Den = "Văn bản đến",
    VB_DU_THAO = "VB dự thảo",
    VB_DA_BAN_HANH = "VB đã ban hành"
  }
  export enum VbTimKiemType {
    TAT_CA = "Tất cả",
  }