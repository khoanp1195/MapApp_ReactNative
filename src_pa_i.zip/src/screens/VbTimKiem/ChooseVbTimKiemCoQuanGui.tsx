import React, { useCallback, useState, useEffect } from "react";
import {
  SafeAreaView,
  View,
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  Platform,
} from "react-native";
import {
  BackIcon,
  DoneIcon,
  FolderIcon,
  MinusIcon,
  PlusIcon,
} from "assets/SVG/index";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import { fetchVbTimKiemCoQuanGui } from "stores/VbTimKiem/reducer"
import { useDispatch, useSelector } from "react-redux";
import {
  arrayIsEmpty,
  format_yy_mm_dd,
  isNullOrUndefined,
  removeSpecialCharacters,
} from "helpers/formater";
import moment from "moment";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { splitID } from "helpers/formater";

type ItemProps = {
  item: any;
  CoQuanGui: any;
  chooseTimKiemCoQuanGui: ({ Title, ID }: any) => void;
  index: number;
  type: string;
  ID: string;
};
type Props = {
  navigation: any;
  route: any;
};

const Item = ({
  item,
  CoQuanGui,
  chooseTimKiemCoQuanGui,
  index,
  ID,
}: ItemProps) => {
  const { Title, Position } = item;
  return (
    <TouchableOpacity
      style={[styles.item, index === 0 && { borderTopWidth: 0 }]}
      onPress={() => chooseTimKiemCoQuanGui(item)}
    >
      <Text style={styles.Title} numberOfLines={1}>{Title}</Text>
      <View>
        {Title === CoQuanGui?.Title ? (
          <DoneIcon color={colors.blueMedium} />
        ) : (
          <View />
        )}
      </View>
    </TouchableOpacity>
  );
};

const App = ({ navigation, route }: Props) => {
  // const navigation = useNavigation();
  const { dataCoQuanGui } = useSelector((state: any) => state.VbTimKiemReducer);
  const { subSite } = useSelector((state: any) => state.login);
  const [listCoQuanGui, setlistCoQuanGui] = useState([]);
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const fetchCoQuanGuiRequest = useCallback(async () => {
    dispatch(fetchVbTimKiemCoQuanGui(subSite));
  }, [dispatch]);
  useEffect(() => {
    fetchCoQuanGuiRequest();
  }, [fetchCoQuanGuiRequest]);
  const chooseTimKiemCoQuanGui = useCallback(
    (item: any) => {
      navigation.navigate({
        name: "VbTimKiemScreen",
        params: { CoQuanGuiNameData: item },
      });
    },

    [navigation]
  );
  const clone = (data) => {
    return data.map((item) => {
      const newItem = { ...item, children: [], isExpanded: false, key: item.ID + item.Parent_x003a_ID };
      const items = dataCoQuanGui.filter((r) => r.Parent_x003a_ID.split(";")[0] === item.ID.toString());

      if (items.length > 0) {
        newItem.children = clone(items); // Truyền mảng data vào hàm clone
      }
      return newItem;
    });
  };
  const handleToggleExpanded = useCallback((itemId) => {
    setlistCoQuanGui((prevData) => {
      const newData = [...prevData];

      const findItemAndToggleExpanded = (items) => {
        for (let i = 0; i < items.length; i++) {
          const item = items[i];

          if (item.ID === itemId) {
            item.isExpanded = !item.isExpanded;
            return;
          }
          if (item.children && item.children.length > 0) {
            findItemAndToggleExpanded(item.children);
          }
        }
      };

      findItemAndToggleExpanded(newData);

      return newData;
    });
  }, [listCoQuanGui]);
  useEffect(() => {
    if (!arrayIsEmpty(dataCoQuanGui) && arrayIsEmpty(listCoQuanGui)) {
      const cloneData = clone(dataCoQuanGui);
      setlistCoQuanGui(cloneData);
    }
  }, [dataCoQuanGui])

  const onGoBack = useCallback(() => {
    navigation.goBack();
  }, []);
  const renderItem = ({ item, index, level = 0 }: any) => {
    const hasChildren = item.children && item.children.length > 0;
    const {
      Title,
      children,
      ID,
      isExpanded,
    } = item;

    return (
      <View style={styles.item}>
        <View
          style={[
            styles.flexDirectionRowItem,
            { paddingLeft: 20 + level * 20 },
          ]}
        >
          <TouchableOpacity onPress={() => handleToggleExpanded(item.ID)} style={{ marginRight: 10 }}>
            {isExpanded ? <MinusIcon /> : <PlusIcon />}
          </TouchableOpacity>
          <TouchableOpacity onPress={() => chooseTimKiemCoQuanGui(item)} style={styles.flexDirectionRowItem}>
            <FolderIcon />
            <Text style={styles.title} numberOfLines={2}>
              {Title}
            </Text>
            {item.key == route.params?.CoQuanGui?.key ? <DoneIcon color={colors.blueMedium} /> : <View />}
          </TouchableOpacity>
        </View>
        {isExpanded && hasChildren && (
          <FlatList
            style={{ marginTop: 10 }}
            data={item?.children}
            renderItem={({ item, index }) =>
              renderItem({ item, index, level: level + 1 })
            }
            keyExtractor={(child, index) => item.key}
          />
        )}
      </View>
    );
  };
  return (
    <View style={styles.container}>
      <View style={styles.viewHeader}>
        <View style={styles.flexDirectionRow}>
          <TouchableOpacity
            style={styles.backPress}
            activeOpacity={1}
            onPress={onGoBack}
          >
            <BackIcon />
          </TouchableOpacity>
          <Text style={styles.TitleHeader}>Cơ quan gửi</Text>
        </View>
      </View>

      <FlatList
        contentContainerStyle={styles.flatlist}
        extraData={listCoQuanGui}
        data={listCoQuanGui}
        renderItem={renderItem}
        keyExtractor={(item) => item?.ID}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
  flatlist: {
    backgroundColor: "#FFFFFF",
    margin: 16,
    borderRadius: 8,
    paddingRight: 15
  },
  item: {
    paddingVertical: 20,
    borderStyle: "dashed",
    borderTopWidth: 1,
    borderTopColor: "#E5E5E5",
  },
  Title: {
    flex: 1,
    fontSize: FontSize.LARGE,
    lineHeight: dimensWidth(20),
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 15,
  },
  position: {
    fontSize: dimensWidth(13),
    lineHeight: dimensWidth(20),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginTop: 5,
  },
  viewHeader: {
    backgroundColor: colors.primary,
    height: 55,
    justifyContent: "center",
    width: "100%",
    paddingHorizontal: 10,
  },
  TitleHeader: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  backPress: {
    padding: 8,
  },
  flexDirectionRowItem: {
    flex: 1,
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "center",
    // paddingHorizontal: 20,
  },
  title: {
    flex: 1,
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.textBlack19,
    fontWeight: "700",
    fontFamily: "arial",
    marginLeft: 10,
  },
});

export default App;
