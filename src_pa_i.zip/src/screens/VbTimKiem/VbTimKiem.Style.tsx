import { StyleSheet } from 'react-native';
import colors from 'themes/Colors';
import { dimensWidth, FontSize } from 'themes/const';

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  avatar: {
    marginRight: dimensWidth(12),
    marginLeft: dimensWidth(15),
  },
  processingDocx: {
    padding: 20,
    height: dimensWidth(220),
    width: dimensWidth(200),
    marginLeft: dimensWidth(10),
    borderRadius: dimensWidth(10),
  },
  coordinationDocx: {
    height: dimensWidth(120),
    padding: 20,
    width: dimensWidth(200),
    marginRight: dimensWidth(8),
    borderRadius: dimensWidth(10),
  },
  imgNotification: {
    padding: 20,
    position: 'absolute',
    bottom: dimensWidth(5),
    height: dimensWidth(120),
    width: dimensWidth(200),
    marginRight: dimensWidth(8),
    borderRadius: dimensWidth(10),
  },
  viewAvatar: {
    flexDirection: 'row',
    marginTop: dimensWidth(10),
    marginBottom: dimensWidth(10),
    alignItems: 'center',
  },
  titleAvatar: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(30),
    color: colors.white,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  dashboard: {
    fontSize: FontSize.LARGE_XX,
    lineHeight: dimensWidth(26),
    color: colors.white,
    fontWeight: '700',
    fontFamily: 'arial',
    marginLeft: dimensWidth(15),
    marginBottom: dimensWidth(6),
  },
  titleDashboard: {
    fontSize: 70,
    color: colors.white,
    fontWeight: '700',
    fontFamily: 'arial',
    marginBottom: dimensWidth(6),
  },
  viewHeader: {
    paddingBottom: 10,
    backgroundColor: colors.primary,
  },
  contentDashboard: {
    fontSize: FontSize.LARGE,
    color: colors.white,
    fontWeight: '700',
    fontFamily: 'arial',
  },
  viewChooseTypeDocx: {
    width: dimensWidth(384),
    height: dimensWidth(34),
    flexDirection: 'row',
    borderRadius: 3,
    borderColor: '#DDDDDD',
    borderWidth: 1,
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 15,
    alignSelf: 'center'
  },
  iconChooseTypeRight: {
    // position: 'absolute',
    // right: 15,
    // top: 15
  },
  titleVanban: {
    fontSize: 38,
    color: colors.white,
    fontWeight: '700',
    fontFamily: 'arial',
    marginBottom: dimensWidth(6),
    marginLeft: dimensWidth(15),
  },
  contentVanban: {
    fontSize: FontSize.SMALL,
    color: colors.white,
    fontWeight: '700',
    fontFamily: 'arial',
  },
  contentDescription: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  squareDescription: { height: 18, width: 18, marginRight: 5, borderRadius: 5 },
  viewDescription: {
    position: 'absolute',
    bottom: 10,
    flexDirection: 'row',
    marginHorizontal: 15,
  },
  viewTitleChart: {
    position: 'absolute',
    top: 0,
    marginTop: 30,
    width: '100%',
    alignItems: 'center',
    zIndex: 99,
  },
  titleChart: {
    fontSize: FontSize.LARGE_X,
    color: colors.black,
    fontWeight: '700',
    fontFamily: 'arial',
  },
  viewContainerChart: {
    flex: 1,
    borderTopLeftRadius: 37,
    borderTopRightRadius: 37,
    overflow: 'hidden',
    marginTop: 14,
    backgroundColor: 'white',
  },
  viewChart: {
    width: '135%',
    height: '135%',
    marginLeft: -70,
    marginTop: -15,
  },
  flexOne: {
    flex: 1,
    flexDirection: 'row',
  },
  searchIcon: {
    marginRight: 25
  },
  containerFlatList: {
    flexGrow: 1,
    marginTop: dimensWidth(15)
  },
  filterIcon: {
    marginRight: 15
  },
  item: {
    flexDirection: 'row',
    backgroundColor: colors.white,
    padding: dimensWidth(15),
    marginBottom: dimensWidth(10),
    marginHorizontal: dimensWidth(15),
    borderRadius: 8,
    justifyContent: 'center',
  },
  title: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: '400',
    fontFamily: 'arial',
    marginBottom: 6,
    marginRight: dimensWidth(5),
    flex: 1
  },
  date: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: '400',
    fontFamily: 'arial',
    marginBottom: 6,
  },
  blueText: {
    fontSize: dimensWidth(13),
    color: colors.scienceBlue,
    fontWeight: '400',
    fontFamily: 'arial',
    marginBottom: 6,
    alignSelf: 'flex-end'
  },
  dateFilter: {
    flex: 1,
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: '400',
    fontFamily: 'arial',
    marginBottom: 6,
  },
  todayDeadlife: {
    color: colors.purple
  },
  category: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: '400',
    fontFamily: 'arial',
    marginBottom: 6,
    marginRight: dimensWidth(5)
  },
  distanceDate: {
    fontSize: dimensWidth(13),
    color: colors.red,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  touchCoQuanGui: {
    backgroundColor: colors.lightBlue,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 3,
    alignSelf: 'baseline'
  },
  itemAvatar: {
    height: dimensWidth(40),
    width: dimensWidth(40),
    marginRight: dimensWidth(10),
    borderRadius: dimensWidth(20),
  },
  flexDirectionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  flexDirectionRowTab: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'baseline',
    marginLeft: 15,
    backgroundColor: colors.tab_bg_blue,
    borderColor: colors.white,
    borderWidth: 0.5,
    height: dimensWidth(37),
    borderRadius: dimensWidth(18),
  },
  onPressActiveTab: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    backgroundColor: colors.white,
    borderRadius: dimensWidth(18),
    marginHorizontal: 1
  },
  onPressInActiveTab: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: dimensWidth(18),
  },
  titleActiveTab: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.primary,
    fontWeight: '700',
    fontFamily: 'arial',
  },
  titleInActiveTab: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  flexDirectionBetween: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  titleNotifyCount: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.orange,
    fontWeight: '700',
    fontFamily: 'arial',
  },
  filterDateView: {
    flexDirection: "row",
    marginTop: dimensWidth(10),
    backgroundColor: colors.white,
  },
  flexDirection: {
    height: dimensWidth(50),
    flexDirection: "row",
    marginTop: dimensWidth(10),
  },
  modalConfirmText: {
    fontSize: FontSize.MEDIUM,
    color: colors.white,
    fontWeight: "400",
    fontFamily: "arial",
  },
  modalReFilterText: {
    fontSize: FontSize.LARGE,
    color: colors.scienceBlue,
    fontWeight: "400",
    fontFamily: "arial",
  },
  stroke: {
    borderWidth: 1,
    borderColor: "#E5E5E5",
    marginVertical: dimensWidth(7.5),
    borderStyle: "dashed",
  },
  buttonReFilter: {
    height: dimensWidth(34),
    paddingHorizontal: dimensWidth(12),
    borderRadius: dimensWidth(4),
    alignItems: "center",
    justifyContent: "center",
  },
  buttonConfirm: {
    backgroundColor: colors.scienceBlue,
    height: dimensWidth(34),
    paddingHorizontal: dimensWidth(12),
    borderRadius: dimensWidth(4),
    alignItems: "center",
    justifyContent: "center",
  },
  textDate: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginVertical: dimensWidth(14),
  },
  textTitleDate: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginTop: dimensWidth(14),
  },
  textType: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 9,
  },
  textFiltedType: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 9,
  },
  button: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  typeChild: {
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: 'center'
  },
  chooseTypeView: {
    flexDirection: "row",
    marginTop: dimensWidth(10),
    backgroundColor: colors.white,
    justifyContent: "space-between",
    width: "100%",
    paddingVertical: dimensWidth(17),
    alignItems: 'center'
  },
  titleChooseTypeDocx: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: '400',
    fontFamily: 'arial',
    marginBottom: 6,
    marginTop: 15,
    marginLeft: dimensWidth(15),
  },
  contentChooseTypeDocx: {
    fontSize: FontSize.SMALL,
    color: colors.black,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  expandView: {
    backgroundColor: colors.white,
    marginTop: 10,
    paddingBottom: 15
  },
  dropDownIcon: {
    backgroundColor: colors.Seashell,
    height: 34,
    width: 34,
    borderRadius: 17,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'flex-end',
    marginRight: 15,
    marginTop: 15
  },
  tabViewContainer: {
    flexDirection: 'row',
    paddingHorizontal: 15,
    backgroundColor: colors.white,
  },
  tabViewChild: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 20,
  },
  tabViewChildActive: {
    borderBottomColor: '#025ED8',
    borderBottomWidth: 3
  },
  tabTitle: {
    fontSize: FontSize.MEDIUM,
    color: colors.grey999,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  tabTitleActive: {
    fontSize: FontSize.MEDIUM,
    color: '#025ED8',
    fontWeight: '400',
    fontFamily: 'arial',
  },
  textCoQuanGui: {
    flex: 1,
    fontSize: dimensWidth(12),
    color: colors.primary,
    fontWeight: '400',
    fontFamily: 'arial',
  },
});
export default styles;
