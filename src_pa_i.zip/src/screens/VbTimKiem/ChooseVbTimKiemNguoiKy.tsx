import React, { useCallback, useState, useEffect } from "react";
import {
  SafeAreaView,
  View,
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  Platform,
} from "react-native";
import {
  BackIcon,
  DoneIcon,
} from "assets/SVG/index";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import { fetchVbTimKiemNguoiKyGui } from "stores/VbTimKiem/reducer"
import { useDispatch, useSelector } from "react-redux";
import {
  arrayIsEmpty,
  format_yy_mm_dd,
  removeSpecialCharacters,
} from "helpers/formater";
import moment from "moment";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { splitID } from "helpers/formater";
import { VbTimKiemType } from "./VbTimKiemType";

type ItemProps = {
  item: any;
  NguoiKyGui: any;
  chooseTimKiemNguoiKyGui: ({ Title, ID }: any) => void;
  index: number;
  type: string;
  ID: string;
};
type Props = {
  navigation: any;
  route: any;
};

const Item = ({
  item,
  NguoiKyGui,
  chooseTimKiemNguoiKyGui,
  index,
  ID,
}: ItemProps) => {
  const { Title, Position } = item;
  return (
    <TouchableOpacity
      style={[styles.item, index === 0 && { borderTopWidth: 0 }]}
      onPress={() => chooseTimKiemNguoiKyGui(item)}
    >
      <Text style={styles.Title} numberOfLines={1}>{Title}</Text>
      <View>
        {Title === NguoiKyGui?.Title ? (
          <DoneIcon color={colors.blueMedium} />
        ) : (
          <View />
        )}
      </View>
    </TouchableOpacity>
  );
};

const App = ({ navigation, route }: Props) => {
  // const navigation = useNavigation();
  const { dataNguoiKyGui } = useSelector((state: any) => state.VbTimKiemReducer);
  const { subSite } = useSelector((state: any) => state.login);
  const [listNguoiKyGui, setlistNguoiKyGui] = useState<any>([]);
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const fetchNguoiKyGuiRequest = useCallback(async () => {
    dispatch(fetchVbTimKiemNguoiKyGui(subSite));
  }, [dispatch]);
  useEffect(() => {
    fetchNguoiKyGuiRequest();
  }, [fetchNguoiKyGuiRequest]);
  const chooseTimKiemNguoiKyGui = useCallback(
    (item: any) => {
      navigation.navigate({
        name: "VbTimKiemScreen",
        params: { NguoiKyGuiNameData: item },
      });
    },

    [navigation]
  );

  const onGoBack = useCallback(() => {
    navigation.goBack();
  }, []);
  useEffect(() => {
    if (!arrayIsEmpty(dataNguoiKyGui)) {
      const clonedData = [{ ID: 99999, Title: VbTimKiemType.TAT_CA }, ...dataNguoiKyGui]
      setlistNguoiKyGui(clonedData);
    }
  }, [dataNguoiKyGui,]);

  return (
    <View style={styles.container}>
      <View style={styles.viewHeader}>
        <View style={styles.flexDirectionRow}>
          <TouchableOpacity
            style={styles.backPress}
            activeOpacity={1}
            onPress={onGoBack}
          >
            <BackIcon />
          </TouchableOpacity>
          <Text style={styles.TitleHeader}>Người ký</Text>
        </View>
      </View>

      <FlatList
        contentContainerStyle={styles.flatlist}
        extraData={listNguoiKyGui}
        data={listNguoiKyGui}
        renderItem={({ item, index }) => (
          <Item
            index={index}
            item={item}
            ID={item?.ID}
            NguoiKyGui={route.params?.NguoiKyGui}
            chooseTimKiemNguoiKyGui={chooseTimKiemNguoiKyGui}
          />
        )}
        keyExtractor={(item) => item?.ID}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
  flatlist: {
    backgroundColor: "#FFFFFF",
    margin: 16,
    borderRadius: 8,
  },
  item: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 20,
    borderStyle: "dashed",
    borderTopWidth: 1,
    borderTopColor: "#E5E5E5",
  },
  Title: {
    flex: 1,
    fontSize: FontSize.LARGE,
    lineHeight: dimensWidth(20),
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 15,
  },
  position: {
    fontSize: dimensWidth(13),
    lineHeight: dimensWidth(20),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginTop: 5,
  },
  viewHeader: {
    backgroundColor: colors.primary,
    height: 55,
    justifyContent: "center",
    width: "100%",
    paddingHorizontal: 10,
  },
  TitleHeader: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  backPress: {
    padding: 8,
  },
});

export default App;
