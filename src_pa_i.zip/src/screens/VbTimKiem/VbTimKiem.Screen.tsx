import React, { useCallback, useState, useEffect, useMemo } from "react";
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  Platform,
  ScrollView,
} from "react-native";
import { createMaterialTopTabNavigator } from "@react-navigation/material-top-tabs";
import styles from "./VbTimKiem.Style";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import SearchInput from "~/components/SearchInput";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { postVbTimKiemApi } from "~/stores/VbTimKiem/reducer";
import { useDispatch, useSelector } from "react-redux";
import { arrayIsEmpty, calculateBetweenTwoDate, checkIsEmpty, formatCreatedDate, format_dd_mm_yy, format_dd_mm_yyyy_hh_mm, removeSpecialCharacters } from "helpers/formater";
import {
  DropDownIcon,
  DropUpIcon,
  ChevronDownIcon,
  SearchIcon,
  MenuIcon,
} from "assets/SVG/index";
import CalendarPickerModal from "./components/CalendarPickerModal";
import FastImage from "react-native-fast-image";
import { BaseUrl } from "~/services/api";
import { FlatList, RefreshControl } from "react-native-gesture-handler";
import { NoDataView } from "~/components";
import { TabNameType } from "./VbTimKiemType";
import moment from "moment";
const tabData = [
  { id: 3, tabName: TabNameType.VB_Den },
  { id: 1, tabName: TabNameType.VB_DU_THAO },
  { id: 2, tabName: TabNameType.VB_DA_BAN_HANH },
];

const VbTimKiemTab = ({ navigation, route }: any) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const todayFormated = moment().format("YYYY-MM-DD");
  const prevMonth = moment(todayFormated).add(-1, "M").format("YYYY-MM-DD");
  const { subSite } = useSelector(
    (state: any) => state.login
  );
  const [filterText, setFilterText] = useState("");
  const initialObjectState = { ID: "", Title: "" }
  const [CoQuanGuiNameDataState, setCoQuanGuiNameDataState] = useState<any>(initialObjectState);
  const [NguoiKyGuiNameDataState, setNguoiKyGuiNameDataState] = useState<any>(initialObjectState);
  const [LoaiVanBanNameDataState, setLoaiVanBanNameDataState] = useState<any>(initialObjectState);
  const [startDate, setStartDate] = useState(prevMonth);
  const [endDate, setEndDate] = useState(todayFormated);
  const [isOpenCalendarPicker, setIsOpenCalendarPicker] = useState(false);
  const [typeModal, setTypeModal] = useState("startDate");
  const [isExpandDropDown, setIsExpandDropDown] = useState(false);
  const { dataVbTimKiem, isLoadingVbTimKiem } = useSelector((state: any) => state.VbTimKiemReducer);
  const [tabSelected, SetTabSelected] = useState<any>([1,2,3])

  const onChangeFilterText = useCallback(
    (text: string) => {
      setFilterText(text);
    },
    [filterText]
  );

  const TimKiemVanBanPress = useCallback(() => {
    let Type = ''
    if (!arrayIsEmpty(tabSelected)) {
      for (let index = 0; index < tabSelected.length; index++) {
        const element = tabSelected[index];
        Type += element + ","
      }

      Type = Type.substring(0, Type.length - 1)

      if (Type.split(',').length === 3) {
        Type = ''
      }
    }

    const NguoiKyVanBan = NguoiKyGuiNameDataState?.ID === 99999 ? "" : NguoiKyGuiNameDataState?.ID
    const LoaiVanBan = CoQuanGuiNameDataState?.ID === 99999 ? "" : CoQuanGuiNameDataState?.ID

    const bodyFormData = {
      Content: filterText,
      LoaiVanBan,
      CoQuanGui: CoQuanGuiNameDataState?.ID,
      NguoiKyVanBan,
      Type,
      TuNgay: startDate,
      DenNgay: endDate,
      subSite: subSite
    }
    dispatch(postVbTimKiemApi({ ...bodyFormData }));
  }, [tabSelected, filterText, LoaiVanBanNameDataState, CoQuanGuiNameDataState, NguoiKyGuiNameDataState, endDate, startDate]);

  const gotoTimKiemCoQuanGui = useCallback(() => {
    navigation.navigate({
      name: "ChooseVbTimKiemCoQuanGuiScreen",
      params: { CoQuanGui: CoQuanGuiNameDataState },
    });
  }, [CoQuanGuiNameDataState]);
  const gotoTimKiemNguoiKyGui = useCallback(() => {
    navigation.navigate({
      name: "ChooseVbTimKiemNguoiKyScreen",
      params: { NguoiKyGui: NguoiKyGuiNameDataState },
    });
  }, [NguoiKyGuiNameDataState]);
  const gotoTimKiemLoaiVanBan = useCallback(() => {
    navigation.navigate({
      name: "ChooseVbTimKiemLoaiVanBanScreen",
      params: { LoaiVanBan: LoaiVanBanNameDataState },
    });
  }, [LoaiVanBanNameDataState]);
  useEffect(() => {
    if (route.params?.CoQuanGuiNameData) {
      setCoQuanGuiNameDataState(route.params?.CoQuanGuiNameData)
    }
    if (route.params?.NguoiKyGuiNameData) {
      setNguoiKyGuiNameDataState(route.params?.NguoiKyGuiNameData)
    }
    if (route.params?.LoaiVanBanNameData) {
      setLoaiVanBanNameDataState(route.params?.LoaiVanBanNameData)
    }
  }, [route.params])

  const onPressOpenCalendarPicker = useCallback((typeModal: string) => {
    setTypeModal(typeModal);
    setIsOpenCalendarPicker(true);
  }, []);

  const onDateChangeModal = useCallback(
    (date: any) => {
      if (typeModal == "startDate") {
        setStartDate(date);
      } else {
        setEndDate(date);
      }
      setIsOpenCalendarPicker(false);
    },
    [typeModal, startDate, endDate]
  );
  const onCloseModal = useCallback(() => {
    setIsOpenCalendarPicker(false);
  }, []);

  const removeSelectedDate = useCallback(() => {
    if (typeModal == "startDate") {
      setStartDate("");
    } else {
      setEndDate("");
    }
  }, [typeModal, startDate, endDate]);

  const resetToday = useCallback(
    (today: any) => {
      setStartDate(today);
      setEndDate(today);
    },
    [typeModal, startDate, endDate]
  );
  const startDateFormat = useMemo(() => {
    if (!startDate) return "";
    const dateFormat = format_dd_mm_yy(startDate);
    return dateFormat;
  }, [startDate]);
  const endDateFormat = useMemo(() => {
    if (!endDate) return "";
    const dateFormat = format_dd_mm_yy(endDate);
    return dateFormat;
  }, [endDate]);

  const onReFilterModalPress = useCallback(() => {
    setStartDate(prevMonth);
    setEndDate(todayFormated);
    setTypeModal("startDate")
    setCoQuanGuiNameDataState(initialObjectState)
    setLoaiVanBanNameDataState(initialObjectState)
    setNguoiKyGuiNameDataState(initialObjectState)
    TimKiemVanBanPress()
  }, [tabSelected]);

  const gotoDetailPress = useCallback((ID: Number, ListName: string) => {
    let screenName = ''
    if (ListName === "Văn bản đi") {
      screenName = 'VBDiDetailScreen';
    } else if (ListName === "Văn bản ban hành") {
      screenName = 'VBDaBanHanhDetailScreen';
    } else {
      screenName = "WaitProcessDocxDetailScreen"
    }
    navigation.navigate({
      name: screenName,
      params: { DocumentID: ID, ListName },
    });

  }, []);
  const Item = ({ item, gotoDetail }: any) => {
    const {
      SoDen,
      NgayTrenVB,
      NgayDen,
      TrangThai,
      SoVanBan,
      TrichYeu,
      ID,
      ListName,
      CoQuanGui
    } = item;
    const gotoDetailPress = () => {
      gotoDetail(ID, ListName);
    };

    return (
      <TouchableOpacity style={styles.item} onPress={gotoDetailPress}>
        <View style={{ flex: 1, }}>
          <View style={styles.flexDirectionBetween}>
            <Text style={styles.title} numberOfLines={2}>
              {removeSpecialCharacters(CoQuanGui)}
            </Text>
            <Text style={styles.date} numberOfLines={1}>{ListName === 'Văn bản đi' ? "" : format_dd_mm_yy(NgayDen)}</Text>
          </View>
          <Text style={styles.blueText} numberOfLines={1}>{SoVanBan}</Text>
          <Text style={styles.title} numberOfLines={2}>{TrichYeu}</Text>
          <View style={styles.flexDirectionBetween}>
            <View style={styles.touchCoQuanGui}>
              <Text style={styles.textCoQuanGui} numberOfLines={1}>{TrangThai}</Text>
            </View>


            <Text
              style={styles.date}
              numberOfLines={1}
            >
              <Text style={{
                fontSize: dimensWidth(13),
                color: colors.scienceBlue,
                fontWeight: '400',
                fontFamily: 'arial',
                marginBottom: 6,
                alignSelf: 'center',
              }} numberOfLines={1}>{SoDen}  </Text>

              {ListName === 'Văn bản đi' ? "" : format_dd_mm_yy(NgayTrenVB)}
            </Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const openDrawer = useCallback(() => {
    navigation.openDrawer();
  }, [navigation]);

  const onChangeSelectedTab = useCallback((id: any) => {
    let tmp = [...tabSelected]
    if (tmp.includes(id)) {
      tmp = tmp.filter(r => r !== id)
    } else {
      tmp.push(id)
    }

    SetTabSelected(tmp)
  }, [tabSelected])

  return (
    <View style={styles.container}>
      <View style={styles.viewHeader}>
        <View style={styles.viewAvatar}>
          <TouchableOpacity onPress={openDrawer}>

            <View
              style={styles.avatar}
            >
              <MenuIcon color='#fff' />
            </View>
          </TouchableOpacity>
          <Text style={styles.titleAvatar}>Tra cứu văn bản</Text>
        </View>
        <SearchInput
          onChangeFilterText={onChangeFilterText}
          filterText={filterText}
        />
      </View>
      <View style={styles.tabViewContainer}>
        {tabData.map((it) => {
          return (
            <TouchableOpacity
              key={it.id}
              style={[
                styles.tabViewChild,
                tabSelected.includes(it.id) && styles.tabViewChildActive,
              ]}
              onPress={() => onChangeSelectedTab(it.id)}
            >
              <Text
                style={[
                  styles.tabTitle,
                  tabSelected.includes(it.id) && styles.tabTitleActive,
                ]}
              >
                {it.tabName}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
      <ScrollView>
        <View style={styles.filterDateView}>
          <TouchableOpacity
            style={[styles.dateFilter, { marginLeft: 16 }]}
            onPress={() => onPressOpenCalendarPicker("startDate")}
          >
            <Text style={styles.textTitleDate}>Từ ngày</Text>
            <Text style={styles.textDate}>{startDateFormat}</Text>
          </TouchableOpacity>
          <View style={styles.stroke} />
          <TouchableOpacity
            style={[styles.dateFilter, { marginRight: 16, paddingLeft: 16 }]}
            onPress={() => onPressOpenCalendarPicker("endDate")}
          >
            <Text style={styles.textTitleDate}>Đến ngày</Text>
            <Text style={styles.textDate}>{endDateFormat}</Text>
          </TouchableOpacity>
        </View>

        {isExpandDropDown && (
          <View style={styles.expandView}>
            <Text style={styles.titleChooseTypeDocx}>Loại văn bản</Text>
            <TouchableOpacity style={styles.viewChooseTypeDocx} onPress={gotoTimKiemLoaiVanBan}>
              <Text style={styles.contentChooseTypeDocx}>{!LoaiVanBanNameDataState?.Title ? "Tất cả" : LoaiVanBanNameDataState?.Title}</Text>
              <ChevronDownIcon />
            </TouchableOpacity>

            <Text style={styles.titleChooseTypeDocx}>Cơ quan gửi</Text>
            <TouchableOpacity style={styles.viewChooseTypeDocx} onPress={gotoTimKiemCoQuanGui}>
              <Text style={styles.contentChooseTypeDocx}>{!CoQuanGuiNameDataState?.Title ? "Tất cả" : CoQuanGuiNameDataState?.Title}</Text>
              <SearchIcon color={colors.tab_bg_blue} />
            </TouchableOpacity>

            <Text style={styles.titleChooseTypeDocx}>Người ký</Text>
            <TouchableOpacity style={styles.viewChooseTypeDocx} onPress={gotoTimKiemNguoiKyGui}>
              <Text style={styles.contentChooseTypeDocx}>{!NguoiKyGuiNameDataState?.Title ? "Tất cả" : NguoiKyGuiNameDataState?.Title}</Text>
              <ChevronDownIcon />
            </TouchableOpacity>
          </View>
        )}
        <TouchableOpacity
          style={styles.dropDownIcon}
          onPress={() => setIsExpandDropDown(!isExpandDropDown)}
        >
          <View>{!isExpandDropDown ? <DropDownIcon /> : <DropUpIcon />}</View>
        </TouchableOpacity>
        <View style={styles.flexDirection}>
          <View style={styles.button} />
          <View style={styles.button}>
            <TouchableOpacity
              onPress={onReFilterModalPress}
              style={styles.buttonReFilter}
            >
              <Text style={styles.modalReFilterText}>{"Thiết lập lại"}</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.button}>
            <TouchableOpacity
              onPress={TimKiemVanBanPress}
              style={styles.buttonConfirm}
            >
              <Text style={styles.modalConfirmText}>{"Tìm kiếm"}</Text>
            </TouchableOpacity>
          </View>
        </View>

        {!arrayIsEmpty(dataVbTimKiem) ? (
          <FlatList
            contentContainerStyle={styles.containerFlatList}
            data={dataVbTimKiem}
            extraData={dataVbTimKiem}
            renderItem={({ item }) => (
              <Item item={item} gotoDetail={gotoDetailPress} />
            )}
            keyExtractor={(item, index) => String(index)}
            nestedScrollEnabled
            disableVirtualization
            showsVerticalScrollIndicator={false}
          />
        ) : (
          <View />
        )}
      </ScrollView>

      <CalendarPickerModal
        modalCalendarVisible={isOpenCalendarPicker}
        onDateChangeModal={onDateChangeModal}
        onCloseModal={onCloseModal}
        startDate={startDate}
        endDate={endDate}
        typeModal={typeModal}
        removeSelectedDate={removeSelectedDate}
        resetToday={resetToday}
      />
    </View>
  );
};

export default VbTimKiemTab;
