export enum VBPhoiHopType {
    TatCa = "Tất cả",
    VB_Den = "Văn bản đến",
    VB_Di = "Văn bản đi"
}
export enum TABNAME {
    VBChoXuLy = "VB chờ xử lý",
    VBDaXuLy = "VB đã xử lý",
  }
export enum enumTypeModal {
    START_DATE = "startDate",
    END_DATE = "VB đã xử lý",
  }