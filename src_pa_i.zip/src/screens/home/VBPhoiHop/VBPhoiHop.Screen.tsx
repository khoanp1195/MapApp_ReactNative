import React, { useCallback, useState, useEffect, useMemo } from "react";
import {
  View,
  FlatList,
  Text,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  RefreshControl,
} from "react-native";
import styles from "../../VBDen/WaitProcessDocx.Style";
import {
  calculateBetweenTwoDate,
  formatCreatedDate,
  arrayIsEmpty,
  checkIsEmpty,
  format_yy_mm_mm_dd_hh,
  isNullOrEmpty
} from "helpers/formater";
import { SearchIcon, FilterIcon, MenuIcon } from "assets/SVG/index";
import FilterModal from "./components/FilterModal";
import { RootState } from "stores";
import SearchInput from "~/components/SearchInput";
import colors from "themes/Colors";
import { fetchVBPhoiHop } from "stores/home/reducer";
import { useDispatch, useSelector } from "react-redux";
import CalendarPickerModal from "./components/CalendarPickerModal";
import moment from "moment";
import { NoDataView } from "components";
import { ThunkDispatch } from "@reduxjs/toolkit";
import FastImage from "react-native-fast-image";
import { BaseUrl } from "~/services/api";
import { VBPhoiHopType, TABNAME, enumTypeModal } from "./VBPhoiHopType";
import ImageLoad from "~/components/ImageLoad";
type Props = {
  navigation: any;
  route: any;
};

const Item = ({ item, gotoDetail, token, subSite }: any) => {
  const {
    SendUnit,
    ListName,
    ImagePath,
    Title,
    SiteName,
    Category,
    Status,
    Created,
    DueDate,
    Action,
    Read,
    DocumentID,
    TaskCategory
  } = item;
  const gotoDetailPress = () => {
    gotoDetail(DocumentID, ListName);
  };
  let dueDateFormat = ""
  let isExpired = false
  let isExpiredToday = false
  const distanceDate = calculateBetweenTwoDate(DueDate);
  if (!checkIsEmpty(distanceDate)) {
    if (parseInt(distanceDate) < 0) {
      dueDateFormat = format_yy_mm_mm_dd_hh(DueDate);
    } else if (parseInt(distanceDate) >= 0 && parseInt(distanceDate) < 1) {
      dueDateFormat = "Hạn hôm nay";
      isExpiredToday = true
    }
    else {
      isExpired = true
      dueDateFormat = "Quá hạn " + distanceDate + " ngày";
    }
  }
  const formatCreated = formatCreatedDate(Created);
  return (
    <TouchableOpacity style={styles.item} onPress={gotoDetailPress}>
      <ImageLoad
        style={styles.itemAvatar}
        source={{
          uri: BaseUrl + `/${subSite}` + ImagePath,
          headers: { Authorization: `${token}` },
          priority: FastImage.priority.normal
        }}
      />
      <View style={{ flex: 1 }}>
        <View style={styles.flexDirectionBetween}>
          <Text style={styles.title} numberOfLines={2}>
            {SendUnit}
          </Text>
          <Text style={styles.date}>{formatCreated}</Text>
        </View>

        <View style={{
          flexDirection: 'row'
        }}>
          <Text style={[{ flex: 1 }, styles.category]}>{ListName}</Text>
          <Text style={styles.category} numberOfLines={1}>{TaskCategory}</Text>
        </View>
        <Text style={[styles.title, !Read && { fontWeight: '700' }]}>{Title}</Text>
        <View style={styles.flexDirectionBetween}>
          <View style={styles.touchSendUnit}>
            <Text style={styles.textSendUnit}>{Action}</Text>
          </View>
          <Text
            style={[
              styles.date,
              isExpiredToday && styles.todayDeadlife,
              isExpired && styles.distanceDate,
            ]}
          >
            {Status === 1 ? "" : dueDateFormat}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const renderFooter = (loading: boolean, refreshing: boolean, isLoadMoreVBPhoiHop: boolean, Offset: any) => {
  return (
    //Footer View with Load More button
    <View style={styles.footer}>
      {loading && !refreshing && isLoadMoreVBPhoiHop && Offset !== 0 ? (
        <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
      ) : null}
    </View>
  );
};

const WaitProcessDocxScreen = ({ route, navigation }: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const todayFormated = moment().format("YYYY-MM-DD");
  const prevMonth = moment(todayFormated).add(-1, "M").format("YYYY-MM-DD");
  const initialPayloadVB = {
    FromDate: "",
    ToDate: "",
    DocumentType: "",
  }
  const { dataNotificationUsers, dataVBPhoiHop, loading, isLoadMoreVBPhoiHop, totalRecordVBPhoiHop, isRefreshing } =
    useSelector((state: RootState) => state.home);
  const { isGoBackWaitProcessDocxScreen } = useSelector(
    (state: any) => state.vbDenReducer
  );
  const { subSite, token } = useSelector(
    (state: any) => state.login
  );
  const [visbleModalFilter, setVisbleModalFiltert] = useState(false);
  const [tabName, setTabName] = useState(TABNAME.VBChoXuLy);
  const [VBPhoiHopList, setVBPhoiHopList] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [titleSelectedState, setTitleSelectedState] = useState(
    VBPhoiHopType.TatCa
  );
  const [startDate, setStartDate] = useState(todayFormated);
  const [endDate, setEndDate] = useState(prevMonth);
  const [isOpenCalendarPicker, setIsOpenCalendarPicker] = useState(false);
  const [typeModal, setTypeModal] = useState("startDate");
  const [filterText, setFilterText] = useState("");
  const [Offset, setOffset] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const [payloadVB, setPayloadVB] = useState(initialPayloadVB)
  const [isFilter, setIsFilter] = useState(false)

  const fetchVBPhoiHopRequest = useCallback(
    async (
      payloadVB: any
    ) => {
      dispatch(
        fetchVBPhoiHop(payloadVB)
      );
    },
    [dispatch]
  );

  useEffect(() => {
    const FilterText = filterText;
    let status = 0
    if (tabName === TABNAME.VBChoXuLy) {
      status = 0;
    } else {
      status = 1
    }
    
    fetchVBPhoiHopRequest(
      { ...payloadVB, FilterText, status, Offset, subSite }
    );
  }, [
    fetchVBPhoiHopRequest,
    payloadVB,
    filterText,
    Offset,
    tabName,
    subSite
  ]);

  useEffect(() => {
    setRefreshing(isRefreshing)
  }, [refreshing, isRefreshing])

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    setOffset(0);
    onReFilterModalPress();
    setPayloadVB(initialPayloadVB);
    setFilterText("");
  }, [refreshing]);

  const onPressFilter = useCallback(() => {
    if (isSearching) setIsSearching(false);
    setVisbleModalFiltert(true);
  }, [visbleModalFilter]);
  const onPressSearch = useCallback(() => {
    if (visbleModalFilter) setVisbleModalFiltert(false);
    if (isSearching) {
      setOffset(0)
      setFilterText("")
    }
    setIsSearching(!isSearching);
  }, [isSearching, visbleModalFilter]);

  const onConfirmModalPress = useCallback(() => {
    let DocumentType = titleSelectedState;
    if (titleSelectedState == VBPhoiHopType.TatCa) DocumentType = "";
    const FromDate = startDate;
    const ToDate = endDate;
    const Offset = 0;
    const FilterText = ""
    setPayloadVB({ FromDate, ToDate, DocumentType })
    setOffset(Offset)
    setFilterText(FilterText);
    setVisbleModalFiltert(false);
    setIsFilter(true)
  }, [startDate, endDate, titleSelectedState]);
  const onReFilterModalPress = useCallback(() => {
    setStartDate(prevMonth);
    setEndDate(todayFormated);
    setTitleSelectedState(VBPhoiHopType.TatCa);
    setPayloadVB({ FromDate: "", ToDate: "", DocumentType: "" })
    setOffset(0)
    setIsFilter(false)
    setVisbleModalFiltert(false)
  }, []);

  const onPressVBPhoiHop = useCallback(() => {
    if (isFilter) {
      onReFilterModalPress()
    }

    setTabName(TABNAME.VBDaXuLy);
    setOffset(0);
  }, []);
  const onPressWaitProcesseDocx = useCallback(() => {
    if (isFilter) {
      onReFilterModalPress()
    }
    
    setTabName(TABNAME.VBChoXuLy);
    setOffset(0);
  }, []);
  useEffect(() => {
    if (dataVBPhoiHop) {
      setVBPhoiHopList(dataVBPhoiHop);
      setRefreshing(false);
    }
  }, [dataVBPhoiHop]);
  useEffect(() => {
    if (isGoBackWaitProcessDocxScreen) {
      setStartDate("");
      setEndDate("");
      setTitleSelectedState(VBPhoiHopType.TatCa);
      setFilterText("");
      setTabName(TABNAME.VBDaXuLy);
      setPayloadVB(initialPayloadVB)
    }
  }, [isGoBackWaitProcessDocxScreen]);

  useEffect(() => {
    if (route?.params?.titleSelected) {
      setVisbleModalFiltert(true);
      setTitleSelectedState(route?.params?.titleSelected);
    }
  }, [route]);

  const waitProcessCount = useMemo(() => {
    if (!dataNotificationUsers) return " 0";
    return ` (${dataNotificationUsers[0]?.VanBanPhoiHop})`;
  }, [dataNotificationUsers]);

  const onPressChooseType = useCallback(() => {
    setVisbleModalFiltert(false);
    navigation.navigate({
      name: "VBPhoiHopFilter",
      params: { titleSelected: titleSelectedState },
    });
  }, [titleSelectedState]);
  const onPressOpenCalendarPicker = useCallback(
    (typeModal: string) => {
      setVisbleModalFiltert(false);
      setTypeModal(typeModal);
      setIsOpenCalendarPicker(true);
    },
    [isOpenCalendarPicker, typeModal]
  );

  const onDateChangeModal = useCallback(
    (date: any) => {
      if (typeModal == "startDate") {
        setStartDate(date);
      } else {
        setEndDate(date);
      }
      setIsOpenCalendarPicker(false);
      setVisbleModalFiltert(true);
    },
    [typeModal, startDate, endDate]
  );
  const onCloseModal = useCallback(() => {
    setIsOpenCalendarPicker(false);
  }, []);
  const onChangeFilterText = useCallback(
    (text: string) => {
      setFilterText(text);
    },
    [filterText]
  );
  const removeSelectedDate = useCallback(() => {
    if (typeModal == "startDate") {
      setStartDate("");
    } else {
      setEndDate("");
    }
  }, [typeModal, startDate, endDate]);
  const resetToday = useCallback(
    (today: any) => {
      setStartDate(today);
      setEndDate(today);
    },
    [typeModal, startDate, endDate]
  );
  const gotoDetailPress = useCallback((DocumentID: Number, ListName: string) => {
    let screenName = ''
    if (ListName === "Văn bản đi" || ListName === 'List Văn bản đi') {
      screenName = 'VBDiDetailScreen';
    } else if (ListName === "Văn bản ban hành") {
      screenName = 'VBDaBanHanhDetailScreen';
    } else {
      screenName = "WaitProcessDocxDetailScreen"
    }
    navigation.navigate({
      name: screenName,
      params: { DocumentID, ListName },
    });
    const newData = VBPhoiHopList.map((it: any) => it.DocumentID === DocumentID ? { ...it, Read: true } : it)
    setVBPhoiHopList(newData);
  }, [VBPhoiHopList]);


  const handleLoadmore = async () => {
    if (!loading && isLoadMoreVBPhoiHop) {
      const newOffset = dataVBPhoiHop.length;
      setOffset(newOffset);
    }
  };
  const openDrawer = useCallback(() => {
    navigation.openDrawer();
  }, [navigation]);
  return (
    <View style={styles.container}>
      <View style={styles.viewAvatar}>
        <View style={styles.flexDirectionRow}>
          <View style={styles.flexDirectionRow}>
            <TouchableOpacity onPress={openDrawer}>
              <View
                style={styles.avatar}
              >
                <MenuIcon color='#fff' />
              </View>
            </TouchableOpacity>
            <Text style={styles.titleAvatar}>{`Văn bản phối hợp - ${subSite.toUpperCase()}`}</Text>
          </View>
          <View style={styles.flexDirectionRow}>
            <TouchableOpacity style={styles.searchIcon} onPress={onPressSearch}>
              <SearchIcon color={!isSearching ? colors.white : 'red'} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.filterIcon} onPress={onPressFilter}>
              <FilterIcon color={isFilter ? 'red' : '#fff'} />
            </TouchableOpacity>
          </View>
        </View>
        {!isSearching ? (
          <View style={styles.flexDirectionRowTab}>
            <TouchableOpacity
              activeOpacity={1}
              onPress={onPressWaitProcesseDocx}
              style={
                tabName === TABNAME.VBChoXuLy
                  ? styles.onPressActiveTab
                  : styles.onPressInActiveTab
              }
            >
              <Text
                style={
                  tabName === TABNAME.VBChoXuLy
                    ? styles.titleActiveTab
                    : styles.titleInActiveTab
                }
              >
                {TABNAME.VBChoXuLy}
                <Text style={styles.titleNotifyCount}>{` (${totalRecordVBPhoiHop}) `}</Text>
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              activeOpacity={1}
              onPress={onPressVBPhoiHop}
              style={
                tabName === TABNAME.VBDaXuLy
                  ? styles.onPressActiveTab
                  : styles.onPressInActiveTab
              }
            >
              <Text
                style={
                  tabName === TABNAME.VBDaXuLy
                    ? styles.titleActiveTab
                    : styles.titleInActiveTab
                }
              >
                VB đã xử lý
              </Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={{ marginTop: 10 }}>
            <SearchInput
              onChangeFilterText={onChangeFilterText}
              filterText={filterText}
            />
          </View>
        )}
      </View>
      {!arrayIsEmpty(VBPhoiHopList) ? (
        <FlatList
          contentContainerStyle={styles.containerFlatList}
          data={VBPhoiHopList}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor='#0054AE' />
          }
          renderItem={({ item }) => (
            <Item item={item} token={token} subSite={subSite} gotoDetail={gotoDetailPress} />
          )}
          keyExtractor={(item, index) => String(index)}
          showsVerticalScrollIndicator={false}
          onEndReachedThreshold={0.5}
          onEndReached={handleLoadmore}
          ListFooterComponent={renderFooter(loading, refreshing, isLoadMoreVBPhoiHop, Offset)}
        />
      ) : (
        <NoDataView />
      )}

      <FilterModal
        tabName={tabName}
        onPressVBPhoiHop={onPressVBPhoiHop}
        onPressFilter={onPressFilter}
        confirmText={"Áp dụng"}
        refilterText={"Thiết lập lại"}
        modalVisible={visbleModalFilter}
        onConfirmModal={onConfirmModalPress}
        onReFilterModal={onReFilterModalPress}
        titleSelected={titleSelectedState}
        onPressChooseType={onPressChooseType}
        onPressSearch={onPressSearch}
        onPressOpenCalendarPicker={onPressOpenCalendarPicker}
        startDate={startDate}
        endDate={endDate}
      />
      <CalendarPickerModal
        modalCalendarVisible={isOpenCalendarPicker}
        onDateChangeModal={onDateChangeModal}
        onCloseModal={onCloseModal}
        startDate={startDate}
        endDate={endDate}
        typeModal={typeModal}
        removeSelectedDate={removeSelectedDate}
        resetToday={resetToday}
      />
    </View>
  );
};

export default WaitProcessDocxScreen;
