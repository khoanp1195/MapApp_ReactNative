export enum VBThongBaoType {
    TatCa = "Tất cả",
    VB_Den = "Văn bản đến",
    VB_Di = "Văn bản đi"
}
export enum TABNAME {
    VBChuaDoc = "VB chưa đọc",
    VBDaDoc = "VB đã đọc",
}
export type Props = {
    navigation: any;
    route: any;
};
export type ItemProps = {
    title: String;
    titleSelected: String;
    chooseTypePress: (title: String) => void;
};
