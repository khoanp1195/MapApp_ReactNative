import React, { useState, useCallback, useEffect, useMemo } from "react";
import {
  Text,
  View,
  processColor,
  ImageBackground,
  TouchableOpacity,
  Platform,
  Dimensions,
  Alert,
} from "react-native";
import { fetchCurrentUsers, fetchNotificationUsers, setRefreshingStore } from "stores/home/reducer";
import { useDispatch, useSelector } from "react-redux";
import styles from "./Home.Style";
import { PieChart } from "react-native-charts-wrapper";
import { RootState } from "stores";
import LinearGradient from "react-native-linear-gradient";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { arrayIsEmpty, checkIsEmpty, isNullOrUndefined } from "~/helpers/formater";
import { MenuIcon } from "~/assets/SVG";
import { FontSize, dimensWidth, dimnensHeight } from "~/themes/const";
import {
  useSafeAreaInsets,
} from "react-native-safe-area-context";
import { setChangeSiteNotification, setCurrentUser, setRemoteMessage, setSubSite } from "~/stores/login/reducer";
import { RefreshControl, ScrollView } from "react-native-gesture-handler";
import colors from "~/themes/Colors";
import AsyncStorage from '@react-native-async-storage/async-storage';
import md5 from 'md5';
import RemotePushController from "~/services/notification/RemotePushController";
import messaging from '@react-native-firebase/messaging';
import DeviceInfo from 'react-native-device-info';
import * as RootNavigation from '~/navigation/RootNavigation';

const data = {
  dataSets: [
    {
      values: [
        { value: 0, label: "VB cần xử lý" },
        { value: 0, label: "VB phối hợp" },
        { value: 0, label: "Thông báo" },
      ],
      label: "",
      config: {
        colors: [
          processColor("#006BCF"),
          processColor("#00C94C"),
          processColor("#FF4040"),
        ],
        drawValues: true,
        valueTextSize: 15,
        valueTextColor: processColor("#000"),
        valueFormatter: "#.#'%'",
        sliceSpace: 5,
        selectionShift: 100,
        yValuePosition: "OUTSIDE_SLICE",
      },
    },
  ],
  highlights: [{ x: 2 }],
};
const HomeScreen = ({ navigation }: any) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const { isGoBackWaitProcessDocxScreen, isGoBackVBDenScreen } = useSelector(
    (state: any) => state.vbDenReducer
  );
  const { subSite, remoteMessage } = useSelector(
    (state: any) => state.login
  );
  const { isGoBackVBDiScreen } = useSelector(
    (state: any) => state.vbDiReducer
  );
  const { isGoBackVBBhScreen } = useSelector(
    (state: any) => state.vbBhReducer
  );
  const { dataCurrentUsers, dataNotificationUsers, isRefreshingDashboard } =
    useSelector((state: RootState) => state.home);

  const [dataChart, setDataChart] = useState(data);
  const [isFinish, setIsFinish] = useState(false)

  const fetchCurrentUsersRequest = useCallback(async (subSite: any) => {
    const deviceToken = await AsyncStorage.getItem('deviceToken')
    const deviceId = await AsyncStorage.getItem('deviceId')

    const deviceInfo = {
      DeviceInfo: {
        DeviceId: deviceId,
        DevicePushToken: deviceToken,
        DeviceOS: Platform.OS === "android" ? 1 : 2,
        DeviceName: await DeviceInfo.getDeviceName(),
        DeviceModel: DeviceInfo.getModel()
      }
    }

    console.log(deviceInfo)
    dispatch(fetchCurrentUsers({ subSite, deviceInfo }));
    dispatch(fetchNotificationUsers(subSite));
  }, [dispatch]);

  useEffect(() => {
    fetchCurrentUsersRequest(subSite);
  }, [fetchCurrentUsersRequest, subSite]);

  useEffect(() => {
    if (isGoBackWaitProcessDocxScreen) {
      fetchCurrentUsersRequest(subSite);
    }
  }, [isGoBackWaitProcessDocxScreen, subSite]);

  useEffect(() => {
    fetchCurrentUsersRequest(subSite)
  }, [isGoBackVBDenScreen, isGoBackVBDiScreen, isGoBackVBBhScreen])

  useEffect(() => {
    if (!arrayIsEmpty(dataCurrentUsers)) {
      dispatch(setCurrentUser(dataCurrentUsers))
      setIsFinish(true)
    }
  }, [dataCurrentUsers])

  useEffect(() => {
    if (isFinish) {
      if (Object.keys(remoteMessage).length > 0) {
        const data = remoteMessage.data

        if (subSite !== data.SiteName) {
          Alert.alert('Thông báo', 'Bạn đang xem Văn bản ở site khác. Bạn có muốn chuyển site không ?', [
            {
              text: "Hủy",
              style: "cancel"
            },
            {
              text: "Đồng ý",
              onPress: () => onChange(remoteMessage)
            }
          ])
        } else {
          let screenName = ''

          if (data.ListName === 'Văn bản đi' || data.ListName === 'List Văn bản đi') {
            screenName = 'VBDiDetailScreen';
          } else if (data.ListName === 'Văn bản đến') {
            screenName = 'WaitProcessDocxDetailScreen'
          } else {
            screenName = 'VBDaBanHanhDetailScreen'
          }

          RootNavigation.navigate(screenName, {
            DocumentID: data.ResourceId,
            ListName: data.ListName
          });

          dispatch(setRemoteMessage({}))
        }
      }
    }
  }, [dispatch, isFinish, subSite, remoteMessage])

  const onChange = useCallback((remoteMessage: any) => {
    const data = remoteMessage.data
    dispatch(setSubSite(data.SiteName))
    dispatch(setChangeSiteNotification(data.SiteName))
    let screenName = ''

    if (data.ListName === 'Văn bản đi' || data.ListName === 'List Văn bản đi') {
      screenName = 'VBDiDetailScreen';
    } else if (data.ListName === 'Văn bản đến') {
      screenName = 'WaitProcessDocxDetailScreen'
    } else {
      screenName = 'VBDaBanHanhDetailScreen';
    }

    RootNavigation.navigate(screenName, {
      DocumentID: data.ResourceId,
      ListName: data.ListName
    });

    dispatch(setRemoteMessage({}))
  }, [dispatch])

  const openDrawer = useCallback(() => {
    navigation.openDrawer();
  }, [navigation]);

  const onGoToWaitProcessDocx = useCallback(() => {
    navigation.navigate("WaitProcessDocxScreen");
  }, [navigation]);

  const onGoToPhoiHopScreen = useCallback(() => {
    navigation.navigate("VBPhoiHopScreen");
  }, [navigation]);

  const onGoToThongBaoScreen = useCallback(() => {
    navigation.navigate("VBThongBaoScreen");
  }, [navigation]);

  const ViecCanXuLy = useMemo(() => {
    if (arrayIsEmpty(dataNotificationUsers)) return 0;
    return dataNotificationUsers[0]?.ViecCanXuLy;
  }, [dataNotificationUsers]);

  const ThongBao = useMemo(() => {
    if (arrayIsEmpty(dataNotificationUsers)) return 0;
    return dataNotificationUsers[0]?.ThongBao;
  }, [dataNotificationUsers]);

  const VanBanPhoiHop = useMemo(() => {
    if (arrayIsEmpty(dataNotificationUsers)) return 0;
    return dataNotificationUsers[0]?.VanBanPhoiHop;
  }, [dataNotificationUsers]);

  useEffect(() => {
    if (dataNotificationUsers) {
      const newData = {
        dataSets: [
          {
            ...dataChart.dataSets[0],
            values: [
              {
                value: ViecCanXuLy,
                label: "VB cần xử lý",
              },
              {
                value: VanBanPhoiHop,
                label: "VB phối hợp",
              },
              {
                value: ThongBao,
                label: "Thông báo",
              },
            ],
          },
        ],
        description: {
          text: 'This is Pie chart description',
          textSize: 15,
          textColor: processColor('darkgray'),

        }
      };
      setDataChart(newData);
    }
  }, [ViecCanXuLy, VanBanPhoiHop, ThongBao]);

  const chartDimention = useMemo(() => {
    const scale = Dimensions.get('window').scale
    const dimention = dimnensHeight(scale)
    return dimention
  }, [])

  const onRefresh = useCallback(() => {
    dispatch(setRefreshingStore(true))
    dispatch(fetchNotificationUsers(subSite));
  }, [isRefreshingDashboard, subSite])

  const safeAreaParams = useSafeAreaInsets()

  return (
    <View style={styles.container}>
        <View style={styles.viewAvatar}>
          <TouchableOpacity onPress={openDrawer}>
            <View
              style={styles.avatar}
            >
              <MenuIcon color='#fff' />
            </View>
          </TouchableOpacity>
          <Text style={styles.titleAvatar}>Trang chủ - {subSite.toUpperCase()}</Text>
        </View>

        <ScrollView contentContainerStyle={{
          flexGrow: 1,
          backgroundColor: '#bdcbca'
        }}
          refreshControl={
            <RefreshControl refreshing={isRefreshingDashboard} onRefresh={onRefresh} tintColor={colors.white} />
          }>
             
          <Text style={styles.dashboard}>Dashboard</Text>


         

          <View style={{ flexDirection: 'row', }}>
            <TouchableOpacity onPress={onGoToWaitProcessDocx}>
              <ImageBackground
                style={styles.processingDocx}
                imageStyle={{ borderRadius: 8 }}
                source={require("assets/images/icon_vieccanxuly.png")}
              >
                <Text style={styles.titleDashboard}>{ViecCanXuLy}</Text>
                <Text style={styles.contentDashboard}>Văn bản chờ xử lý</Text>
              </ImageBackground>
            </TouchableOpacity>
            <View style={{ flex: 1 }}>
              <View style={{ flex: 1 }}>
                <TouchableOpacity onPress={onGoToPhoiHopScreen}>
                  <ImageBackground
                    style={styles.coordinationDocx}
                    imageStyle={{ borderRadius: 8 }}
                    source={require("assets/images/icon_phoihop.png")}
                  >
                    <Text style={styles.titleVanban}>{VanBanPhoiHop}</Text>
                    <Text style={styles.contentVanban}>Văn bản phối hợp</Text>
                  </ImageBackground>
                </TouchableOpacity>
              </View>
              <View style={{ flex: 1 }}>
                <TouchableOpacity onPress={onGoToThongBaoScreen} >
                  <ImageBackground
                    style={styles.coordinationDocx}
                    imageStyle={{ borderRadius: 8 }}
                    source={require("assets/images/icon_thongbao.png")}
                  >
                    <Text style={styles.titleVanban}>{ThongBao}</Text>
                    <Text style={styles.contentVanban}>Thông báo</Text>
                  </ImageBackground>
                </TouchableOpacity>
              </View>
            </View>
          </View>

          <View style={styles.viewContainerChart}>
            <View style={styles.viewTitleChart}>
              <Text style={styles.titleChart}>Tình hình xử lý văn bản</Text>
            </View>
            {ViecCanXuLy + ThongBao + VanBanPhoiHop > 0 && chartDimention && (
              <PieChart
                style={[styles.viewChart, {
                  height: 110 + (chartDimention) + (safeAreaParams.bottom) + '%',
                  width: 100 + (chartDimention * Dimensions.get('window').scale) + '%',
                  marginTop: -(chartDimention + safeAreaParams.bottom * Dimensions.get('window').scale),
                  alignSelf: 'center',
                }]}
                logEnabled={true}
                chartBackgroundColor={processColor("white")}
                chartDescription={{ text: "" }}
                data={dataChart}
                legend={{ enabled: false }}
                highlights={[]}
                noDataText={"No data chart !"}
                entryLabelColor={processColor("#10a8b2")}
                entryLabelTextSize={12}
                touchEnabled={false}
                drawEntryLabels={false}
                usePercentValues={true}
                rotationEnabled={true}
                centerText={""}
                onSelect={() => { }}
                centerTextRadiusPercent={0}
                holeRadius={40}
                transparentCircleRadius={0}
                maxAngle={360}
                rotationAngle={45}
              />
            )}

            <View style={styles.viewDescription}>
              <View style={styles.flexOne}>
                <LinearGradient
                  style={styles.squareDescription}
                  colors={["#4CD9ED", "#006BCF"]}
                />
                <Text style={styles.contentDescription}>VB cần xử lý</Text>
              </View>
              <View style={styles.flexOne}>
                <LinearGradient
                  style={styles.squareDescription}
                  colors={["#00C94C", "#5AFFF8"]}
                />
                <Text style={styles.contentDescription}>VB phối hợp</Text>
              </View>
              <View style={styles.flexOne}>
                <LinearGradient
                  style={styles.squareDescription}
                  colors={["#FFC386", "#FF4040"]}
                />
                <Text style={styles.contentDescription}>Thông báo</Text>
              </View>
            </View>
          </View>
        </ScrollView>
      </View>
  );
};

export default HomeScreen;
