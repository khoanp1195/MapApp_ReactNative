import {StyleSheet, Platform} from 'react-native';
import colors from 'themes/Colors';
import {dimensWidth, FontSize} from 'themes/const' 
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.whiteLilac,
  },
  containerFlatList:{
    marginTop: dimensWidth(15)
  },
  searchIcon:{
    marginRight:25
  },
  filterIcon:{
    marginRight:15
  },
  item: {
    flexDirection: 'row',
    backgroundColor: colors.white,
    padding: dimensWidth(15),
    marginBottom: dimensWidth(10),
    marginHorizontal: dimensWidth(15),
    borderRadius: 8,
    justifyContent: 'center',
  },
  title: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: '400',
    fontFamily: 'arial',
    marginBottom: 6,
    marginRight: dimensWidth(5),
    flex: 1
  },
  date: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: '400',
    fontFamily: 'arial',
    marginBottom: 6,
  },
  todayDeadlife: {
    color: colors.purple
  },
  category: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: '400',
    fontFamily: 'arial',
    marginBottom: 6,
    marginRight: dimensWidth(5)
  },
  distanceDate: {
    fontSize: dimensWidth(13),
    fontWeight: '400',
    fontFamily: 'arial',
  },
  textSendUnit:{
    fontSize: dimensWidth(12),
    color: colors.primary,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  touchSendUnit:{
    backgroundColor: colors.lightBlue,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 3,
    alignSelf: 'baseline'
  },
  viewAvatar: {
    backgroundColor: colors.primary,
    height: Platform.OS === 'ios' ? 160 : 120,
    justifyContent: 'center',
    width: '100%',
  },
  titleAvatar: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  avatar: {
    height: dimensWidth(36),
    width: dimensWidth(36),
    marginRight: dimensWidth(10),
    marginLeft: dimensWidth(15),
    borderRadius: dimensWidth(18),
  },
  itemAvatar: {
    height: dimensWidth(40),
    width: dimensWidth(40),
    marginRight: dimensWidth(10),
    borderRadius: dimensWidth(20),
  },
  flexDirectionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  flexDirectionRowTab: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'baseline',
    borderRadius: dimensWidth(18),
    marginLeft: 15,
    backgroundColor: colors.tab_bg_blue,
    borderColor: colors.white,
    borderWidth: 0.5,
    height: dimensWidth(37),
  },
  onPressActiveTab: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    backgroundColor: colors.white,
    borderRadius: dimensWidth(18),
    marginHorizontal: 1
  },
  onPressInActiveTab: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: dimensWidth(18),
  },
  titleActiveTab: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.primary,
    fontWeight: '700',
    fontFamily: 'arial',
  },
  titleInActiveTab: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  flexDirectionBetween:{
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  titleNotifyCount: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.orange,
    fontWeight: '700',
    fontFamily: 'arial',
  },
});
export default styles;
