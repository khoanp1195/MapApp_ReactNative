import React, { useCallback, useState, useEffect, useMemo } from "react";
import {
  View,
  FlatList,
  Text,
  StatusBar,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  RefreshControl,
  StyleSheet,
} from "react-native";
import styles from "../../VBDen/WaitProcessDocx.Style";
import {
  calculateBetweenTwoDate,
  formatCreatedDate,
  arrayIsEmpty,
  format_yy_mm_mm_dd_hh,
  checkIsEmpty,
  format_dd_mm_yy,
  isNullOrEmpty
} from "helpers/formater";
import { SearchIcon, FilterIcon, MenuIcon } from "assets/SVG/index";
import FilterModal from "./components/FilterModal";
import { RootState } from "stores";
import colors from "themes/Colors";
import {
  fetchWaitProcessDocx, setRefreshingStore,
} from "stores/home/reducer";
import { useDispatch, useSelector } from "react-redux";
import CalendarPickerModal from "./components/CalendarPickerModal";
import moment from "moment";
import { NoDataView } from "components";
import { ThunkDispatch } from "@reduxjs/toolkit";
import FastImage from "react-native-fast-image";
import { BaseUrl } from "~/services/api";
import { WaitProcessDocxType, TABNAME } from "./WaitProcessDocxType";
import SearchInput from "~/components/SearchInput";
import { dimensWidth } from "~/themes/const";
import CacheImage from "~/components/CacheImage";
import CachedImage from "~/components/CacheImage";
import ImageLoad from "~/components/ImageLoad";

type Props = {
  navigation: any;
  route: any;
};

const Item = ({ item, gotoDetail, tabName, token, subSite }: any) => {
  const {
    SendUnit,
    ListName,
    ImagePath,
    Title,
    Category,
    Created,
    DueDate,
    Status,
    Action,
    DocumentID,
    Read,
    TaskCategory
  } = item;
  const gotoDetailPress = () => {
    gotoDetail(DocumentID, ListName);

  };
  let dueDateFormat = ""
  let isExpired = false
  let isExpiredToday = false
  const distanceDate = calculateBetweenTwoDate(DueDate);
  if (!checkIsEmpty(distanceDate)) {
    if (parseInt(distanceDate) < 0) {
      dueDateFormat = format_dd_mm_yy(DueDate);
    } else if (parseInt(distanceDate) >= 0 && parseInt(distanceDate) < 1) {
      dueDateFormat = "Hạn hôm nay";
      isExpiredToday = true
    }
    else {
      isExpired = true
      dueDateFormat = "Quá hạn " + distanceDate + " ngày";
    }
  }

  const formatCreated = formatCreatedDate(Created);
  return (
    <TouchableOpacity style={styles.item} onPress={gotoDetailPress}>
      <ImageLoad
        style={styles.itemAvatar}
        source={{
          uri: BaseUrl + `/${subSite}` + ImagePath,
          headers: { Authorization: `${token}` },
          priority: FastImage.priority.normal
        }}
      />
      {/* {
        isNullOrEmpty(ImagePath) ? <Image
          style={styles.itemAvatar}
          source={require('../../../assets/images/avatar80.png')}
        /> :
          <View style={styles.itemAvatar}>
            <Image style={[styles.itemAvatar,StyleSheet.absoluteFill]} resizeMode="cover" source={require('../../../assets/images/avatar80.png')} />
            <FastImage
              style={styles.itemAvatar}
              source={{
                uri: BaseUrl + `/${subSite}` + ImagePath,
                headers: { Authorization: `${token}` },
                priority: FastImage.priority.normal
              }}
              resizeMode={FastImage.resizeMode.cover}
            />
          </View>

      } */}
      <View style={{ flex: 1 }}>
        <View style={styles.flexDirectionBetween}>
          <Text style={styles.title} numberOfLines={2}>
            {SendUnit}
          </Text>
          <Text style={styles.date}>{formatCreated}</Text>
        </View>

        <View style={{
          flexDirection: 'row'
        }}>
          <Text style={[{ flex: 1 }, styles.category]}>{ListName}</Text>
          <Text style={styles.category} numberOfLines={1}>{TaskCategory}</Text>
        </View>
        <Text style={[styles.title, tabName === TABNAME.VBChoXuLy && !Read && { fontWeight: '700' }]}>{Title}</Text>
        <View style={styles.flexDirectionBetween}>
          <View style={styles.touchSendUnit}>
            <Text style={[styles.textSendUnit,]}>{Action}</Text>
          </View>
          <Text
            style={[
              styles.date,
              isExpiredToday && styles.todayDeadlife,
              isExpired && styles.distanceDate,
            ]}
          >
            {Status === 1 ? "" : dueDateFormat}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const renderFooter = (loading: boolean, refreshing: boolean, isLoadMoreWaitProcessDocx: boolean, Offset: any) => {
  return (
    //Footer View with Load More button
    <View style={styles.footer}>
      {loading && !refreshing && isLoadMoreWaitProcessDocx && Offset !== 0 ? (
        <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
      ) : null}
    </View>
  );
};
const WaitProcessDocxScreen = ({ route, navigation }: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const todayFormated = moment().format("YYYY-MM-DD");
  const prevMonth = moment(todayFormated).add(-1, "M").format("YYYY-MM-DD");
  const {
    dataNotificationUsers,
    dataWaitProcessDocx,
    loading,
    isLoadMoreWaitProcessDocx,
    totalRecordWaitProcesssDocx,
    isRefreshing
  } = useSelector((state: RootState) => state.home);
  const { token, subSite } = useSelector(
    (state: any) => state.login
  );
  const { isGoBackVBDenScreen } = useSelector(
    (state: any) => state.vbDenReducer
  );
  const { isGoBackVBDiScreen } = useSelector(
    (state: any) => state.vbDiReducer
  );
  const { isGoBackVBBhScreen } = useSelector(
    (state: any) => state.vbBhReducer
  );
  const initialPayloadVB = {
    FromDate: "",
    ToDate: "",
    DocumentType: "",
  }
  const [visbleModalFilter, setVisbleModalFiltert] = useState(false);
  const [tabName, setTabName] = useState(TABNAME.VBChoXuLy);
  const [waitProcessDocList, setWaitProcessDoc] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [titleSelectedState, setTitleSelectedState] = useState(
    WaitProcessDocxType.TatCa
  );
  const [startDate, setStartDate] = useState(prevMonth);
  const [endDate, setEndDate] = useState(todayFormated);
  const [isOpenCalendarPicker, setIsOpenCalendarPicker] = useState(false);
  const [typeModal, setTypeModal] = useState("startDate");
  const [filterText, setFilterText] = useState("");
  const [Offset, setOffset] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const [payloadVB, setPayloadVB] = useState(initialPayloadVB)
  const [isFilter, setIsFilter] = useState(false)

  const fetchWaitProcessDocxRequest = useCallback(
    async (payloadVB: any) => {
      dispatch(
        fetchWaitProcessDocx(
          payloadVB,
        )
      );
    },
    [dispatch]
  );

  useEffect(() => {
    const FilterText = filterText;
    let status = 0
    if (tabName === TABNAME.VBChoXuLy) {
      status = 0;
    } else {
      status = 1
    }
    const payload = { ...payloadVB, FilterText, status, Offset, subSite };
    fetchWaitProcessDocxRequest(
      payload
    );
  }, [
    payloadVB,
    filterText,
    Offset,
    tabName,
    subSite,
    dispatch
  ]);

  const onRefresh = useCallback(() => {
    setRefreshing(true)
    setOffset(0);
    onReFilterModalPress();
    setPayloadVB(initialPayloadVB);
    setFilterText("");
  }, [refreshing]);

  useEffect(() => {
    setRefreshing(isRefreshing)
  }, [refreshing, isRefreshing])

  const onPressFilter = useCallback(() => {
    if (isSearching) setIsSearching(false);
    setVisbleModalFiltert(true);
  }, [visbleModalFilter]);

  const onPressSearch = useCallback(() => {
    if (visbleModalFilter) setVisbleModalFiltert(false);
    if (isSearching) {
      setOffset(0)
      setFilterText("")
    }
    setIsSearching(!isSearching);
  }, [isSearching, visbleModalFilter]);

  const onConfirmModalPress = useCallback(() => {
    let DocumentType = titleSelectedState;
    if (titleSelectedState == WaitProcessDocxType.TatCa) DocumentType = "";
    const FromDate = startDate;
    const ToDate = endDate;
    const Offset = 0;
    const FilterText = ""
    setPayloadVB({ FromDate, ToDate, DocumentType })
    setOffset(Offset)
    setFilterText(FilterText);
    setVisbleModalFiltert(false);
    setIsFilter(true)
  }, [startDate, endDate, titleSelectedState]);

  const onReFilterModalPress = useCallback(() => {
    setStartDate(prevMonth);
    setEndDate(todayFormated);
    setTitleSelectedState(WaitProcessDocxType.TatCa);
    setOffset(Offset)
    setVisbleModalFiltert(false);
    setIsFilter(false)
    setPayloadVB({ FromDate: "", ToDate: "", DocumentType: "" })
  }, []);

  const onPressProcessedDocx = useCallback(() => {
    if (isFilter) {
      onReFilterModalPress()
    }

    setTabName(TABNAME.VBDaXuLy);
    setOffset(0);
  }, [isFilter]);
  const onPressWaitProcesseDocx = useCallback(() => {
    if (isFilter) {
      onReFilterModalPress()
    }

    setTabName(TABNAME.VBChoXuLy);
    setOffset(0);
  }, [isFilter]);

  useEffect(() => {
    setWaitProcessDoc(dataWaitProcessDocx);
    setRefreshing(false)
  }, [dataWaitProcessDocx]);

  useEffect(() => {
    if (isGoBackVBDenScreen || isGoBackVBDiScreen || isGoBackVBBhScreen) {
      setStartDate("");
      setEndDate("");
      setTitleSelectedState(WaitProcessDocxType.TatCa);
      setFilterText("");
      setOffset(0)
      setPayloadVB(initialPayloadVB)
    }
  }, [isGoBackVBDenScreen, isGoBackVBDiScreen, isGoBackVBBhScreen]);

  useEffect(() => {
    if (route?.params?.titleSelected) {
      setVisbleModalFiltert(true);
      setTitleSelectedState(route?.params?.titleSelected);
    }
  }, [route.params]);

  const onPressChooseType = useCallback(() => {
    setVisbleModalFiltert(false);
    navigation.navigate({
      name: "WaitProcessDocxFilter",
      params: { titleSelected: titleSelectedState },
    });
  }, [titleSelectedState]);
  const onPressOpenCalendarPicker = useCallback(
    (typeModal: string) => {
      setVisbleModalFiltert(false);
      setTypeModal(typeModal);
      setIsOpenCalendarPicker(true);
    },
    [isOpenCalendarPicker, typeModal]
  );

  const onDateChangeModal = useCallback(
    (date: any) => {
      if (typeModal == "startDate") {
        setStartDate(date);
      } else {
        setEndDate(date);
      }
      setIsOpenCalendarPicker(false);
      setVisbleModalFiltert(true);
    },
    [typeModal, startDate, endDate]
  );
  const onCloseModal = useCallback(() => {
    setIsOpenCalendarPicker(false);
  }, []);
  const onChangeFilterText = useCallback(
    (text: string) => {
      if (Offset != 0) setOffset(0)
      setFilterText(text);
    },
    [filterText, Offset]
  );
  const removeSelectedDate = useCallback(() => {
    if (typeModal == "startDate") {
      setStartDate("");
    } else {
      setEndDate("");
    }
  }, [typeModal, startDate, endDate]);
  const resetToday = useCallback(
    (today: any) => {
      setStartDate(today);
      setEndDate(today);
    },
    [typeModal, startDate, endDate]
  );
  const gotoDetailPress = useCallback((DocumentID: Number, ListName: string) => {
    let screenName = ''
    if (ListName === "Văn bản đi" || ListName === "List Văn bản đi") {
      screenName = 'VBDiDetailScreen';
    } else if (ListName === "Văn bản ban hành") {
      screenName = 'VBDaBanHanhDetailScreen';
    } else {
      screenName = "WaitProcessDocxDetailScreen"
    }
    navigation.navigate({
      name: screenName,
      params: { DocumentID, ListName },
    });
    const newData = waitProcessDocList.map((it: any) => it.DocumentID === DocumentID ? { ...it, Read: true } : it)
    setWaitProcessDoc(newData);
  }, [waitProcessDocList]);

  const handleLoadmore = async () => {
    if (!loading && isLoadMoreWaitProcessDocx) {
      const newOffset = dataWaitProcessDocx.length;
      setOffset(newOffset);
    }
  };
  const openDrawer = useCallback(() => {
    navigation.openDrawer();
  }, [navigation]);
  return (
    <View style={styles.container}>
      <View style={styles.viewAvatar}>
        <View style={styles.flexDirectionRow}>
          <View style={styles.flexDirectionRow}>
            <TouchableOpacity onPress={openDrawer}>
              <View
                style={styles.avatar}
              >
                <MenuIcon color='#fff' />
              </View>
            </TouchableOpacity>
            <Text style={styles.titleAvatar}>{`Văn bản cần xử lý - ${subSite.toUpperCase()}`}</Text>
          </View>
          <View style={styles.flexDirectionRow}>
            <TouchableOpacity style={styles.searchIcon} onPress={onPressSearch}>
              <SearchIcon color={!isSearching ? colors.white : 'red'} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.filterIcon} onPress={onPressFilter}>
              <FilterIcon color={isFilter ? 'red' : '#fff'} />
            </TouchableOpacity>
          </View>
        </View>
        {!isSearching ? (
          <View style={styles.flexDirectionRowTab}>
            <TouchableOpacity
              activeOpacity={1}
              onPress={onPressWaitProcesseDocx}
              style={
                tabName === TABNAME.VBChoXuLy
                  ? styles.onPressActiveTab
                  : styles.onPressInActiveTab
              }
            >
              <Text
                style={
                  tabName === TABNAME.VBChoXuLy
                    ? styles.titleActiveTab
                    : styles.titleInActiveTab
                }
              >
                {TABNAME.VBChoXuLy}
                <Text style={styles.titleNotifyCount}>{` (${totalRecordWaitProcesssDocx})`}</Text>
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              activeOpacity={1}
              onPress={onPressProcessedDocx}
              style={
                tabName === TABNAME.VBDaXuLy
                  ? styles.onPressActiveTab
                  : styles.onPressInActiveTab
              }
            >
              <Text
                style={
                  tabName === TABNAME.VBDaXuLy
                    ? styles.titleActiveTab
                    : styles.titleInActiveTab
                }
              >
                VB đã xử lý
              </Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={{ marginTop: 10 }}>
            <SearchInput
              onChangeFilterText={onChangeFilterText}
              filterText={filterText}
            />
          </View>
        )}
      </View>
      {!arrayIsEmpty(waitProcessDocList) ? (
        <FlatList
          contentContainerStyle={styles.containerFlatList}
          data={waitProcessDocList}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor='#0054AE' />
          }
          renderItem={({ item }) => (
            <Item item={item} gotoDetail={gotoDetailPress} token={token} tabName={tabName} subSite={subSite} />
          )}
          keyExtractor={(item, index) => String(index)}
          showsVerticalScrollIndicator={false}
          onEndReachedThreshold={0.5}
          onEndReached={handleLoadmore}
          ListFooterComponent={renderFooter(loading, refreshing, isLoadMoreWaitProcessDocx, Offset)}
        />
      ) : (
        <NoDataView />
      )}

      <FilterModal
        tabName={tabName}
        onPressWaitProcesseDocx={onPressWaitProcesseDocx}
        onPressProcessedDocx={onPressProcessedDocx}
        onPressFilter={onPressFilter}
        confirmText={"Áp dụng"}
        refilterText={"Thiết lập lại"}
        modalVisible={visbleModalFilter}
        onConfirmModal={onConfirmModalPress}
        onReFilterModal={onReFilterModalPress}
        titleSelected={titleSelectedState}
        onPressChooseType={onPressChooseType}
        onPressSearch={onPressSearch}
        onPressOpenCalendarPicker={onPressOpenCalendarPicker}
        startDate={startDate}
        endDate={endDate}
      />
      <CalendarPickerModal
        modalCalendarVisible={isOpenCalendarPicker}
        onDateChangeModal={onDateChangeModal}
        onCloseModal={onCloseModal}
        startDate={startDate}
        endDate={endDate}
        typeModal={typeModal}
        removeSelectedDate={removeSelectedDate}
        resetToday={resetToday}
      />
    </View>
  );
};

export default WaitProcessDocxScreen;
