import React, { FC, useEffect, useCallback, useState } from "react";
import {
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import { RightBlueIcon, } from "assets/SVG/index";
import TextInputCustom from "components/TextInputCustom";
interface Props {
  modalVisible: Boolean;
  onCloseChuyenXuLyModal: () => void;
  onChooseNguoiDuocChuyenXuLy: () => void;
  YeuCauHieuChinhStringList: {
    UserCCString: string;
    UserCC: string;
  };
  onConfirmChuyenXuLyModal: (text: string, YeuCauHieuChinhStringList: any) => void;
  ykienlanhdao: any
}
const DongYModal: FC<Props> = ({
  modalVisible,
  onCloseChuyenXuLyModal,
  onChooseNguoiDuocChuyenXuLy,
  YeuCauHieuChinhStringList,
  onConfirmChuyenXuLyModal,
  ykienlanhdao,
  ...props
}: Props) => {

  const [text, setText] = useState("");
  const [YeuCauHieuChinhStringListState, setYeuCauHieuChinhStringListState] = useState({ UserCCString: "", UserCC: "" });
  const onChangeText = useCallback(
    (input: string) => {
      setText(input);
    },
    [text]
  );
  const onConfirm = useCallback(() => {
    onConfirmChuyenXuLyModal(text, YeuCauHieuChinhStringListState);
  }, [text, YeuCauHieuChinhStringListState]);
  const onDismiss = useCallback(() => {
    Keyboard.dismiss();
  }, []);
  useEffect(() => {
    if (YeuCauHieuChinhStringList) {
      setYeuCauHieuChinhStringListState(YeuCauHieuChinhStringList)
    }
  }, [YeuCauHieuChinhStringList])

  useEffect(() => {
    setText(ykienlanhdao)
  }, [ykienlanhdao])
  
  return (
    <Modal
      transparent={true}
      visible={modalVisible}
      {...props}
      style={styles.centeredView}
    >
      <TouchableWithoutFeedback style={styles.centeredView} onPress={onDismiss}>
        <KeyboardAvoidingView
          style={styles.centeredView}
          behavior={Platform.OS === "ios" ? "padding" : "height"}
        >
          <View style={{ flex: 1 }} />
          <View style={styles.modalView}>
            {/* coppy header */}

            <View style={styles.chooseTypeView}>
              <View style={styles.viewAssign}>
                <Text style={styles.textAssign}>Yêu cầu hiệu chỉnh</Text>
              </View>
              <View style={styles.chooseTypeView}>
                <Text style={styles.textType}>Ý kiến<Text style={styles.textTypeWarning}> (*)</Text></Text>
                <TextInputCustom
                  placeholder="Vui lòng nhập ý kiến"
                  placeholderTextColor={colors.grey999}
                  multiline
                  onChangeText={(text) => onChangeText(text)}
                  value={text}
                  style={styles.commentInput}
                />
                <Text style={styles.titleBoss}>Chọn người để biết</Text>
                <Text style={styles.textType}>CC</Text>
                <TouchableOpacity
                  style={styles.typeChild}
                  onPress={onChooseNguoiDuocChuyenXuLy}
                >
                  <Text style={styles.textFiltedType}>{YeuCauHieuChinhStringListState?.UserCCString}</Text>
                  {/* <RightBlueIcon /> */}
                </TouchableOpacity>
              </View>

            </View>

            <View style={styles.viewTabBottomBar}>
              <TouchableOpacity style={styles.buttonExit} onPress={onCloseChuyenXuLyModal}>
                <Text style={styles.buttonExitText} >
                  Thoát
                </Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.buttonTransfer} onPress={onConfirm}>
                <Text style={styles.tabBarLabelActive} numberOfLines={1}>
                  Hiệu chỉnh
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "flex-end",
  },
  modalView: {
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    opacity: 1,
    backgroundColor: colors.white,
    borderTopEndRadius: 12,
    borderTopStartRadius: 12,
    overflow: "hidden",
  },
  chooseTypeView: {
    marginBottom: 15,
    borderRadius: 8,
  },
  flexDirection: {
    height: 67,
    flexDirection: "row",
    paddingHorizontal: 20,
    alignItems: "center",
  },
  stroke: {
    borderWidth: 0.5,
    borderColor: "#999",
    borderStyle: "dashed",
  },
  textType: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginVertical: 10,
  },
  textTypeWarning: {
    color: colors.red,
  },
  tabBarLabelActive: {
    color: colors.white,
    fontWeight: "400",
    fontSize: FontSize.LARGE,
  },
  viewTabBottomBar: {
    flexDirection: "row",
    height: dimensWidth(66),
    borderRadius: 8,
    justifyContent: "flex-end",
  },
  buttonTransfer: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.blueMedium,
    width: 130,
    height: 34,
    borderRadius: 4,
  },
  buttonExit: {
    alignItems: "center",
    justifyContent: "center",
    width: 130,
    height: 34,
    borderRadius: 4,
  },
  buttonExitText: {
    color: colors.red,
    fontWeight: "400",
    fontSize: FontSize.LARGE,
  },
  textAssign: {
    color: colors.blueMedium,
    fontWeight: "700",
    fontSize: FontSize.LARGE,
  },
  viewAssign: {
    backgroundColor: colors.lightBlue,
    padding: 15,
  },
  titleBoss: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginHorizontal: 15,
  },
  commentInput: {
    paddingHorizontal: 10,
    borderColor: colors.greyDDD,
    borderRadius: 3,
    height: 100,
    borderWidth: 1,
    marginHorizontal: 15,
    marginBottom: 10,
    textAlignVertical: "top",
  },
  typeChild: {
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "center",
    minHeight: 34,
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 3,
    marginHorizontal: 15,
    justifyContent: "space-between",
    paddingVertical: 5
  },
  textFiltedType: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 9,
  },
});

export default DongYModal;
