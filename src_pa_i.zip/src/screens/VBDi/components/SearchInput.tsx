import { StyleSheet } from "react-native";
import React from "react";
import TextInputCustom from "components/TextInputCustom";
import colors from "themes/Colors";
interface Props {
  filterText: string;
  onChangeFilterText: (text: string) => void;
}
const SearchInput = ({ filterText, onChangeFilterText }: Props) => {
  return (
    <TextInputCustom
      placeholder="Tìm kiếm …"
      placeholderTextColor={colors.grey999}
      numberOfLines={1}
      onChangeText={(text) => onChangeFilterText(text)}
      value={filterText}
      style={styles.userNameInput}
    />
  );
};
const styles = StyleSheet.create({
  userNameInput: {
    marginHorizontal: 15,
    paddingStart: 15,
    paddingVertical: 8,
    backgroundColor: colors.white,
    borderRadius: 17,
    color: colors.black,
    fontSize: 16
  },
});
export default SearchInput;
