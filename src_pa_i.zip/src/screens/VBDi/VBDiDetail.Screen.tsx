import React, { useCallback, useState, useEffect, useMemo } from "react";
import {
  View,
  FlatList,
  StyleSheet,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
  Platform,
} from "react-native";
import {
  BackIcon,
  ClockWhiteIcon,
  ThreeDotIcon,
  ShareBlueIcon,
  HoSoDuThaoIcon,
  ActionMoreIcon,
  DongYIcon,
  DeNghiHieuChinhIcon,
  BoSungThongTInIcon,
  FowardProcesscon
} from "assets/SVG/index";
import colors from "themes/Colors";
import { dimensWidth, FontSize } from "themes/const";
import TextInputCustom from "components/TextInputCustom";

import {
  fetchVBDiDetailApi,
  fetchVBDiAttachFile,
  vbDiChiaSeApi,
  vbDiChuyenXuLyApi,
  vbDiDongYApi,
  resetVBDiScreen,
  vbDiYeuCauHieuChinhApi,
  vbDiBoSungThongTinApi,
  vbDiThuHoiApi,
  vbDiPheDuyetApi,
  SetisLoadingVBDi
} from "stores/VBDi/reducer";
import { useDispatch, useSelector } from "react-redux";
import ChoYKienLanhDaoModal from "./components/ChoYKienLanhDaoModal";
import ChiaSeModal from "./components/ChiaSeModal";
import ActionOptionalModal from "./components/ActionOptionalModal";
import {
  format_dd_mm_yy,
  removeSpecialCharacters,
  checkTypeFiles,
  checkTrangThai,
  checkIsEmpty,
  arrayIsEmpty,
  byteConverter,
  checkMimeTypeFiles,
  getExtension,
} from "helpers/formater";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { EnumPhancong, ActionJsonType } from "./VBDiType";
import { useFocusEffect } from "@react-navigation/native";
import ChuyenXuLyModal from "./components/ChuyenXuLyModal";
import DongYModal from "./components/DongYModal";
import YeuCauHieuChinhModal from "./components/YeuCauHieuChinhModal";
import BoSungThongTinModal from "./components/BoSungThongTinModal";
import ThuHoiModal from "./components/ThuHoiModal";
import PheDuyetModal from "./components/PheDuyetModal";
import { LoadingView } from "~/components";
import { postReadVanBan } from "~/stores/vbDen/reducer";
import { BaseUrl } from "~/services/api";
// import RNFetchBlob from 'react-native-fetch-blob';
import FileViewer from "react-native-file-viewer";
import moment from "moment";
import { cos } from "react-native-reanimated";

type Props = {
  navigation: any;
  route: any;
};

const App = ({ route, navigation }: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const { dataVBDiDetail, isChiaSeVBBHSuccess, isChiaSeVBDiSuccess, isLoadingDetail, dataVBDiAttachFile, isGoBackVBDiScreen, isLoadingVBDi } = useSelector(
    (state: any) => state.vbDiReducer
  );
  const { subSite } = useSelector(
    (state: any) => state.login
  );
  const initialState = {
    dongYStringList: {
      UserCCString: "",
      UserCC: "",
    },
    pheDuyetStringList: {
      UserCCString: "",
      UserCC: "",
    },
    YeuCauHieuChinhStringList: {
      UserCCString: "",
      UserCC: "",
    },
    chuyenXuLyStringList: {
      ChooseUserString: "",
      ChooseUser: "",
    },
    chiaSeStringList: {
      UserShared: "",
      displayString: "",
    },
  };
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [modalChiaSe, setModalChiaSe] = useState(false);
  const [modalBoSungThongTin, setModalBoSungThongTin] = useState(false);
  const [modalActionOptional, setModalActionOptional] = useState(false);
  const [modalYKienLanhDao, setModalYKienLanhDao] = useState(false);
  const [modalChuyenXuLy, setChuyenXuLyModal] = useState(false);
  const [modalDongY, setDongYModal] = useState(false);
  const [modalPheDuyet, setPheDuyetModal] = useState(false);
  const [modalThuHoi, setThuHoiModal] = useState(false);
  const [modalYeuCauHieuChinh, setYeuCauHieuChinhModal] = useState(false);
  const [chuyenXuLyStringList, setChuyenXuLyStringList] = useState<any>(
    initialState.chuyenXuLyStringList
  );
  const [YeuCauHieuChinhStringList, setYeuCauHieuChinhStringList] = useState<any>(
    initialState.YeuCauHieuChinhStringList
  );
  const [dongYStringList, setDongYStringList] = useState<any>(
    initialState.dongYStringList
  );
  const [pheDuyetStringList, setPheDuyetStringList] = useState<any>(
    initialState.pheDuyetStringList
  );
  const [nguoiDuocBoSungThongTinDataState, setNguoiDuocBoSungThongTinDataState] = useState<any>(null);
  const [yKienLanhDao, setYKienLanhDao] = useState("");
  const [danhSachUsersAndGroupState, setDanhSachUsersAndGroupState] = useState(
    []
  );
  const [chiaSeStringList, setChiaSeStringList] = useState(initialState.chiaSeStringList);
  const [typeModal, setTypeModal] = useState<ActionJsonType>(null);
  const [DocumentID, setDocumentID] = useState("");

  const resetNewScreen = useCallback(() => {
    setYKienLanhDao("");
    setIsFullScreen(false);
  }, []);

  const fetchVBDiAttachFileRequest = useCallback(
    (DocumentID: number) => {
      dispatch(
        fetchVBDiAttachFile({
          DocumentID,
          subSite
        })
      );
    },
    [dispatch]
  );
  const postReadVanBanRequest = useCallback(
    ({ DocumentID, subSite, ListName }: any) => {
      dispatch(
        postReadVanBan(
          {
            DocumentID,
            subSite,
            ListName
          }
        )
      );
    },
    [dispatch]
  );

  const onGoBack = useCallback(() => {
    navigation.goBack();
  }, []);
  const gotoThongTinLuanChuyenVBBHScreen = useCallback(() => {
    navigation.navigate({
      name: "ThongTinLuanChuyenVBDicreen",
      params: { itemId: dataVBDiDetail?.ID },
    });
  }, [dataVBDiDetail]);
  const onCloseActionOptionalModal = useCallback(() => {
    setModalActionOptional(false);
  }, [modalActionOptional]);
  const onCloseChuyenXuLyModal = useCallback(() => {
    setChuyenXuLyModal(false);
  }, [modalChuyenXuLy]);
  const onCloseDongYModal = useCallback(() => {
    setDongYModal(false);
  }, []);
  const onClosePheDuyetModal = useCallback(() => {
    setPheDuyetModal(false);
  }, []);
  const onCloseYeuCauHieuChinhModal = useCallback(() => {
    setYeuCauHieuChinhModal(false);
  }, [YeuCauHieuChinhModal]);
  const onCloseBoSungThongTinModal = useCallback(() => {
    setModalBoSungThongTin(false);
  }, []);

  const onChooseNguoiDuocChuyenXuLy = useCallback(() => {
    setChuyenXuLyModal(false);
    navigation.navigate({
      name: "ChoosNguoiDuocChuyenXuLyVBDiScreen",
      params: {
        danhSachUsersAndGroup: route?.params?.danhSachUsersAndGroup,
        typeModal: ActionJsonType.ChuyenXuLy,
        chuyenXuLyStringList,
        onlyUser: true
      },
    });
  }, [route?.params?.danhSachUsersAndGroup]);
  const onChooseCCDongY = useCallback(() => {
    setDongYModal(false);
    navigation.navigate({
      name: "ChooseNhomNguoiDungVBDiScreen",
      params: {
        danhSachUsersAndGroup: route?.params?.danhSachUsersAndGroup,
        typeModal: ActionJsonType.DongY,
        dongYStringList
      },
    });
  }, [route?.params?.danhSachUsersAndGroup, dongYStringList]);
  const onChooseCCPheDuyet = useCallback(() => {
    setPheDuyetModal(false);
    navigation.navigate({
      name: "ChooseNhomNguoiDungVBDiScreen",
      params: {
        danhSachUsersAndGroup: route?.params?.danhSachUsersAndGroup,
        typeModal: ActionJsonType.PheDuyet,
        pheDuyetStringList,
      },
    });
  }, [route?.params?.danhSachUsersAndGroup, pheDuyetStringList]);
  const onChooseCCYeuCauHieuChinh = useCallback(() => {
    setYeuCauHieuChinhModal(false);
    navigation.navigate({
      name: "ChooseNhomNguoiDungVBDiScreen",
      params: {
        danhSachUsersAndGroup: route?.params?.danhSachUsersAndGroup,
        typeModal: ActionJsonType.YeuCauHieuChinh,
        YeuCauHieuChinhStringList,
      },
    });
  }, [route?.params?.danhSachUsersAndGroup, YeuCauHieuChinhStringList]);
  useEffect(() => {
    if (route.params?.nguoiDuocBoSungThongTinData !== undefined) {
      setNguoiDuocBoSungThongTinDataState(route.params?.nguoiDuocBoSungThongTinData);
      setModalBoSungThongTin(true)
    }
  }, [route.params]);
  const onChooseNguoiDuocYeuCauBoSung = useCallback(() => {
    setModalBoSungThongTin(false);
    navigation.navigate({
      name: "ChooseDSNguoiBoSungThongTinVBDiScreen",
      params: {
        dataDSNguoiBosungThongtin: nguoiDuocBoSungThongTinDataState,
        typeModal: ActionJsonType.YeuCauBoSung,
        nguoiDuocBoSungThongTinData: nguoiDuocBoSungThongTinDataState,
        DocumentID
      },
    });
  }, [route?.params?.dataDSNguoiBosungThongtin, nguoiDuocBoSungThongTinDataState, DocumentID]);

  const onConfirmChuyenXuLyModal = useCallback(
    (text: string) => {
      if (
        checkIsEmpty(chuyenXuLyStringList?.ChooseUserString)
      ) {
        Alert.alert('Thông báo', 'Vui lòng chọn người để thực hiện chuyển xử lý', [
          {
            text: 'Đóng'
          }
        ])
      } else {
        const body = {
          Comment: text,
          ChooseUser: chuyenXuLyStringList?.ChooseUser,
          DocumentID,
          subSite
        };
        dispatch(vbDiChuyenXuLyApi(body));
        setChuyenXuLyModal(false);
      }
    },
    [chuyenXuLyStringList, DocumentID, dispatch]
  );
  const onConfirmDongYModal = useCallback(
    (text: string,) => {

      const body = {
        Comment: text,
        UserCC: checkIsEmpty(dongYStringList?.UserCC) ? "" : dongYStringList?.UserCC,
        DocumentID,
        subSite
      };

      dispatch(vbDiDongYApi(body));
      setDongYModal(false);
    },
    [dongYStringList, DocumentID, dispatch]
  );
  const onConfirmPheDuyetModal = useCallback(
    (text: string) => {

      const body = {
        Comment: text,
        UserCC: pheDuyetStringList?.UserCC,
        DocumentID,
        subSite
      };

      dispatch(vbDiPheDuyetApi(body));
      setPheDuyetModal(false);

    },
    [pheDuyetStringList, DocumentID, dispatch]
  );
  const onConfirmYeuCauHieuChinhModal = useCallback(
    (text: string, chuyenXuLyStringListParams: any) => {
      if (
        checkIsEmpty(text)) {
        Alert.alert('Thông báo', 'Vui lòng nhập ý kiến', [
          {
            text: 'Đóng'
          }
        ])
      } else {
        const body = {
          Comment: text,
          UserCC: YeuCauHieuChinhStringList?.UserCC ? YeuCauHieuChinhStringList?.UserCC : "",
          DocumentID,
          subSite
        };
        dispatch(vbDiYeuCauHieuChinhApi(body));
        setYeuCauHieuChinhModal(false);
      }
    },
    [YeuCauHieuChinhStringList, DocumentID, dispatch]
  );
  const onConfirmBoSungThongTinModal = useCallback(
    (text: string, chuyenXuLyStringListParams: any) => {
      if (
        checkIsEmpty(nguoiDuocBoSungThongTinDataState?.FullName)
      ) {
        Alert.alert('Thông báo', 'Vui lòng chọn người để thực hiện bổ sung', [
          {
            text: 'Đóng'
          }
        ])
      } else {
        const ChooseUser = nguoiDuocBoSungThongTinDataState?.AccountID + ';#' + nguoiDuocBoSungThongTinDataState?.AccountName
        const body = {
          Comment: text,
          ChooseUser,
          DocumentID,
          subSite
        };
        dispatch(vbDiBoSungThongTinApi(body));
        setModalBoSungThongTin(false);
      }
    },
    [nguoiDuocBoSungThongTinDataState, DocumentID, dispatch]
  );
  useEffect(() => {
    if (isGoBackVBDiScreen || isChiaSeVBDiSuccess) {
      navigation.goBack();
      dispatch(resetVBDiScreen());
    }
  }, [isGoBackVBDiScreen, isChiaSeVBDiSuccess, dispatch])

  const openModalActionOptional = useCallback(() => {
    setModalActionOptional(true);
  }, [modalActionOptional]);
  const onActionPress = useCallback(
    (ID: number) => {
      if (modalActionOptional) setModalActionOptional(false);
      if (ID === ActionJsonType.ChiaSe) setModalChiaSe(true);
      if (ID === ActionJsonType.ChuyenXuLy) setChuyenXuLyModal(true);
      if (ID === ActionJsonType.DongY) setDongYModal(true);
      if (ID === ActionJsonType.YeuCauHieuChinh) setYeuCauHieuChinhModal(true);
      if (ID === ActionJsonType.YeuCauBoSung) setModalBoSungThongTin(true);
      if (ID === ActionJsonType.ThuHoi) setThuHoiModal(true);
      if (ID === ActionJsonType.PheDuyet) setPheDuyetModal(true);
    },
    [modalChiaSe, modalActionOptional, route.params?.typeModal]
  );

  const onChooseTypeChiaSe = useCallback(() => {
    setModalChiaSe(false);
    setTypeModal(ActionJsonType.ChiaSe);
    navigation.navigate({
      name: "ChooseNhomNguoiDungVBDiScreen",
      params: {
        danhSachUsersAndGroup: danhSachUsersAndGroupState,
        typeModal: ActionJsonType.ChiaSe,
        chiaSeStringList
      },
    });
  }, [danhSachUsersAndGroupState, chiaSeStringList]);
  useEffect(() => {
    setDanhSachUsersAndGroupState(route?.params?.danhSachUsersAndGroup);
  }, [route?.params?.danhSachUsersAndGroup]);
  useEffect(() => {
    if (isChiaSeVBBHSuccess) {
      setDanhSachUsersAndGroupState((prevState: any) => {
        const newData = prevState?.map(
          (it: any) => (it = { ...it, isSellectedCChiaSe: false, isSellectedCCDongY: false })
        );
        return newData;
      });
      setChiaSeStringList(initialState.chiaSeStringList);
    }

  }, [isChiaSeVBBHSuccess, danhSachUsersAndGroupState]);

  const filterdanhSachUsersAndGroup = useMemo(() => {
    const data = danhSachUsersAndGroupState?.filter(
      (it: any) => it?.isSellectedCChiaSe
    );
    return data;
  }, [danhSachUsersAndGroupState]);
  useEffect(() => {
    if (route?.params?.danhSachUsersAndGroup) {
      let tmp = route?.params?.danhSachUsersAndGroup;

      if (route.params?.typeModal == ActionJsonType.ChiaSe) {
        let displayString = "";
        let UserShared = "";
        tmp = tmp.filter((it: any) => it?.isSellectedCChiaSe);
        const dataLength = tmp.length;
        tmp.forEach((it: any, index: any) => {
          displayString =
            index + 1 !== dataLength
              ? displayString + it?.FullName + "; "
              : displayString + it?.FullName;
          UserShared = checkIsEmpty(UserShared)
            ? it?.AccountID + ";#" + it?.AccountName
            : UserShared + ";#" + it?.AccountID + ";#" + it?.AccountName;
        });

        setChiaSeStringList({ UserShared, displayString });
        setModalChiaSe(true);
      }
      if (route.params?.typeModal == ActionJsonType.DongY) {
        let UserCCString = "";
        let UserCC = "";
        tmp = tmp.filter((it: any) => it?.isSellectedCCDongY);
        const dataLength = tmp.length;
        tmp.forEach((it: any, index: any) => {
          UserCCString =
            index + 1 !== dataLength
              ? UserCCString + it?.FullName + "; "
              : UserCCString + it?.FullName;
          UserCC = checkIsEmpty(UserCC)
            ? it?.AccountID + ";#" + it?.AccountName
            : UserCC + ";#" + it?.AccountID + ";#" + it?.AccountName;
        });
        setDongYStringList({ UserCC, UserCCString });
        setDongYModal(true);
      }
      if (route.params?.typeModal == ActionJsonType.PheDuyet) {
        let UserCCString = "";
        let UserCC = "";
        tmp = tmp.filter((it: any) => it?.isSellectedCCPheDuyet);
        const dataLength = tmp.length;
        tmp.forEach((it: any, index: any) => {
          UserCCString =
            index + 1 !== dataLength
              ? UserCCString + it?.FullName + "; "
              : UserCCString + it?.FullName;
          UserCC = checkIsEmpty(UserCC)
            ? it?.AccountID + ";#" + it?.AccountName
            : UserCC + ";#" + it?.AccountID + ";#" + it?.AccountName;
        });
        setPheDuyetStringList({ UserCC, UserCCString });
        setPheDuyetModal(true);
      }
      if (route.params?.typeModal == ActionJsonType.YeuCauHieuChinh) {
        let UserCCString = "";
        let UserCC = "";
        tmp = tmp.filter((it: any) => it?.isSellectedCCYeuCauHieuChinh);
        const dataLength = tmp.length;
        tmp.forEach((it: any, index: any) => {
          UserCCString =
            index + 1 !== dataLength
              ? UserCCString + it?.FullName + "; "
              : UserCCString + it?.FullName;
          UserCC = checkIsEmpty(UserCC)
            ? it?.AccountID + ";#" + it?.AccountName
            : UserCC + ";#" + it?.AccountID + ";#" + it?.AccountName;
        });
        setYeuCauHieuChinhStringList({ UserCC, UserCCString });
        setYeuCauHieuChinhModal(true);
      }
      if (route.params?.typeModal == ActionJsonType.ChuyenXuLy) {
        let ChooseUserString = "";
        let ChooseUser = "";
        tmp = tmp.filter((it: any) => it?.isSellectedChuyenXuLy);
        const dataLength = tmp.length;
        const plusString = checkIsEmpty(ChooseUser) ? "" : ";#";
        tmp.forEach((it: any, index: number) => {
          ChooseUserString =
            index + 1 !== dataLength
              ? ChooseUserString + it?.FullName + "; "
              : ChooseUserString + it?.FullName;
          ChooseUser =
            index + 1 !== dataLength
              ? ChooseUser + plusString + it?.AccountID + ";#" + it?.AccountName
              : ChooseUser + it?.AccountID + ";#" + it?.AccountName;
        });
        setChuyenXuLyStringList({ ChooseUserString, ChooseUser });
        setChuyenXuLyModal(true);
      }
    }
  }, [route.params?.danhSachUsersAndGroup, route?.params?.typeModal]);

  const onCloseModalYKienLanhDao = useCallback(() => {
    setModalYKienLanhDao(false);
  }, []);
  const onCloseModalThuHoi = useCallback(() => {
    setThuHoiModal(false);
  }, []);

  const onChangeYKienLanhDao = useCallback(
    (text: string) => {
      setModalYKienLanhDao(false);
      setYKienLanhDao(text);
    },
    [yKienLanhDao]
  );
  const onConfirmModalThuHoi = useCallback(
    (text: string, DocumentID: any) => {
      setThuHoiModal(false);
      dispatch(vbDiThuHoiApi({ Comment: text, DocumentID, subSite }))
    },
    [DocumentID]
  );

  const onConfirmModalChiaSe = useCallback(
    (text: string) => {
      if (arrayIsEmpty(filterdanhSachUsersAndGroup)) {
        Alert.alert('Thông báo', 'Vui lòng chọn người bạn muốn chia sẻ', [
          {
            text: 'Đóng',
            style: 'cancel'
          }
        ])
      } else {
        let UserShared = "";
        filterdanhSachUsersAndGroup.forEach((it: any, index: any) => {
          UserShared = checkIsEmpty(UserShared)
            ? it?.AccountID + ";#" + it?.AccountName
            : UserShared + ";#" + it?.AccountID + ";#" + it?.AccountName;
        });

        dispatch(
          vbDiChiaSeApi({
            UserShared,
            Comment: text,
            DocumentID,
            subSite
          })
        );
        setModalChiaSe(false);
      }
    },
    [filterdanhSachUsersAndGroup, DocumentID]
  );

  const onCloseModalChiaSe = useCallback(() => {
    setModalChiaSe(false);
  }, [yKienLanhDao]);

  const onOpenModalYKienLanhDao = useCallback(() => {
    setModalYKienLanhDao(true);
  }, []);

  const downloadFile = useCallback(async (dataAttach: any) => {
    dispatch(SetisLoadingVBDi(true))
    const { config, fs } = RNFetchBlob;
    const typeFile = getExtension(dataAttach?.Url)
    const mimeType = checkMimeTypeFiles(dataAttach?.Url);
    const { DownloadDir } = fs.dirs;
    const filename = dataAttach?.Url.substring(dataAttach?.Url.lastIndexOf('/') + 1, dataAttach?.Url.length)
    const milisecond = moment().valueOf()
    const localPath = `${DownloadDir}/${milisecond}_${filename}`
    const options = {
      fileCache: true,
      mime: mimeType,
      appendExt: typeFile,
      path: localPath,
    };
    const encodeUri = encodeURI(dataAttach?.Url)
    const url = `${BaseUrl}/_layouts/15/VuThao.PA.Api/ApiDownload.ashx?file=${encodeUri}`
    config(options)
      .fetch('GET', url)
      .then((res) => {
        FileViewer.open(localPath, {
        }).catch(error => {
          dispatch(SetisLoadingVBDi(false))
          Alert.alert('Thông báo', 'Đã có lỗi xảy ra. Vui lòng thử lại', [
            { text: 'Đóng' }
          ])
        });
        dispatch(SetisLoadingVBDi(false))
      })
      .catch((error) => {
        dispatch(SetisLoadingVBDi(false))
        Alert.alert('Thông báo', 'Đã có lỗi xảy ra. Vui lòng thử lại', [
          { text: 'Đóng' }
        ])
      });
  }, []);

  const gotoFileViewScreen = useCallback((item: any) => {
    if (Platform.OS !== "ios") {
      downloadFile({ ...item, Url: BaseUrl + item?.Url })
    } else {
      navigation.navigate({
        name: "FileViewVBDiScreen",
        params: { item },
      });
    }

  }, []);
  const onChangeIsFullScren = useCallback(
    (item: any) => {
      setIsFullScreen(!isFullScreen);
    },
    [isFullScreen]
  );

  const LoaiVanBanFormat = useMemo(() => {
    if (!dataVBDiDetail?.LoaiVanBan) return "";
    return removeSpecialCharacters(dataVBDiDetail?.LoaiVanBan);
  }, [dataVBDiDetail?.LoaiVanBan]);

  useEffect(() => {
    if (route?.params?.typeModal) {
      const typeModal = route.params?.typeModal;
      onActionPress(typeModal);
    }
  }, [route.params?.typeModal, navigation, route?.params]);

  const fetchVBDiDetailApiRequest = useCallback(
    (DocumentID: number) => {
      dispatch(
        fetchVBDiDetailApi({
          DocumentID,
          subSite
        })
      );
    },
    [dispatch]
  );
  useEffect(() => {
    if (route.params?.DocumentID) {
      setDocumentID(route?.params?.DocumentID);
      resetNewScreen();
    }
  }, [route?.params?.DocumentID]);

  useEffect(() => {
    if (DocumentID) {
      fetchVBDiDetailApiRequest(DocumentID);
      fetchVBDiAttachFileRequest(DocumentID);
      postReadVanBanRequest({ DocumentID, ListName: route.params?.ListName, subSite });
    }
  }, [
    fetchVBDiDetailApiRequest,
    fetchVBDiAttachFileRequest,
    subSite,
    DocumentID,
    route.params?.ListName
  ]);
  useEffect(() => {
    if (route?.params?.danhSachUsersAndGroup) {
      let tmp = route?.params?.danhSachUsersAndGroup;

      if (route.params?.typeModal == ActionJsonType.ChiaSe) {
        let displayString = "";
        let UserShared = "";
        tmp = tmp.filter((it: any) => it?.isSellectedCChiaSe);
        const dataLength = tmp.length;
        tmp.forEach((it: any, index: any) => {
          displayString =
            index + 1 !== dataLength
              ? displayString + it?.FullName + "; "
              : displayString + it?.FullName;
          UserShared = checkIsEmpty(UserShared)
            ? it?.AccountID + ";#" + it?.AccountName
            : UserShared + ";#" + it?.AccountID + ";#" + it?.AccountName;
        });

        setChiaSeStringList({ UserShared, displayString });
        setModalChiaSe(true);
      }
      if (route.params?.typeModal == ActionJsonType.ChuyenXuLy) {
        let ChooseUserString = "";
        let ChooseUser = "";
        tmp = tmp.filter((it: any) => it?.isSellectedChuyenXuLy);
        const dataLength = tmp.length;
        const plusString = checkIsEmpty(ChooseUser) ? "" : ";#";
        tmp.forEach((it: any, index: number) => {
          ChooseUserString =
            index + 1 !== dataLength
              ? ChooseUserString + it?.FullName + "; "
              : ChooseUserString + it?.FullName;
          ChooseUser =
            index + 1 !== dataLength
              ? ChooseUser + plusString + it?.AccountID + ";#" + it?.AccountName
              : ChooseUser + it?.AccountID + ";#" + it?.AccountName;
        });
        setChuyenXuLyStringList({ ChooseUserString, ChooseUser });
        setChuyenXuLyModal(true);
      }
    }
  }, [route.params?.danhSachUsersAndGroup, route?.params?.typeModal]);
  const onShowFullTrichYeu = useCallback(() => {
    Alert.alert("", dataVBDiDetail?.TrichYeu, [{ text: "OK", onPress: () => { } }]);
  }, [dataVBDiDetail?.TrichYeu]);

  const gotoNhiemVuDaPhanCongScreen = useCallback(
    (ID: number) => {
      // navigation.navigate({
      //   name: "NhiemVuDaPhanCongScreen",
      //   params: { DocumentID, taskID: ID },
      // });
    },
    [DocumentID]
  );

  const ItemAttach = ({ item, index }: any) => {
    const { Author, Created, Category, Size, Url, Title } = item;
    const createdFormated = Created ? format_dd_mm_yy(Created) : null;
    const sizeFormated = Size ? byteConverter(Size, 0) : null;
    const FileIcon = () => {
      return checkTypeFiles(Url);
    };
    const isOdd = index % 2 === 0;
    return (
      <TouchableOpacity
        style={[
          styles.documentFileView,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
        onPress={() => gotoFileViewScreen(item)}
      >
        <View
          style={[styles.flexDirectionRowBetween,]}
        >
          <View style={styles.flexDirectionRow}>
            <View style={{ marginTop: 5 }}>
              <FileIcon />
            </View>
            <Text style={styles.titleDocumentFile} numberOfLines={1}>
              {Title}
            </Text>
          </View>
          <Text style={styles.contenAttach} numberOfLines={1}>
            {removeSpecialCharacters(Author)}
          </Text>
        </View>
        <View
          style={[styles.flexDirectionRowBetween, { alignItems: "flex-start", marginLeft: 20 }]}
        >
          <Text style={styles.sizeDocumentFile} numberOfLines={1}>
            {sizeFormated}
          </Text>
          <Text style={{
            fontSize: FontSize.MEDIUM,
            color: colors.lightBlack,
            fontWeight: "400",
            fontFamily: "arial",
            marginLeft: 15,
            marginTop: 5
          }} numberOfLines={1}>
            {removeSpecialCharacters(Category)}
          </Text>
          <Text style={{
            fontSize: FontSize.MEDIUM,
            color: colors.lightBlack,
            fontWeight: "400",
            fontFamily: "arial",
            marginLeft: 15,
            marginTop: 5
          }} numberOfLines={1}>
            {createdFormated}
          </Text>

        </View>
      </TouchableOpacity>
    );
  };
  const ItemVBDenCommentJson = ({ item, index }: any) => {
    const { Title, Value, UpdateFields, Position, Created } = item;
    const createdFormated = format_dd_mm_yy(Created);
    const isOdd = index % 2 === 0;
    return (
      <View
        style={[
          styles.danhMucItemView,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
      >
        <View
          style={[styles.flexDirectionRowBetween, { alignItems: "flex-start" }]}
        >
          <View style={styles.flexOne}>
            <View style={styles.flexDirectionRowBetween}>
              <Text style={styles.titleCommentJson} numberOfLines={1}>
                {Title}
              </Text>
              <Text style={styles.positionComment} numberOfLines={1}>
                {createdFormated}
              </Text>
            </View>
            <Text style={styles.positionComment} numberOfLines={1}>
              {removeSpecialCharacters(Position)}
            </Text>
            <View style={styles.flexDirectionRow}>
              <Text style={styles.titleCommentJson} numberOfLines={1}>
                {Value}
              </Text>
            </View>
          </View>
        </View>
      </View>
    );
  };
  const ItemVBDenTaskJson = ({
    item,
    index,
    gotoNhiemVuDaPhanCongScreen,
  }: any) => {
    const {
      AssignedToType,
      TrangThai,
      DepartmentTitle,
      Position,
      Created,
      DeThucHien,
      DueDate,
      ID,
    } = item;
    const createdFormated = format_dd_mm_yy(Created);
    const isOdd = index % 2 === 0;
    const customColor = checkTrangThai(TrangThai);
    return (
      <TouchableOpacity
        onPress={gotoNhiemVuDaPhanCongScreen}
        style={[
          styles.danhMucItemView,
          isOdd && { backgroundColor: colors.alice_blue },
        ]}
      >
        <View
          style={[styles.flexDirectionRowBetween, { alignItems: "flex-start" }]}
        >
          <View style={styles.flexOne}>
            <Text style={styles.titleVbDenTheoMuc} numberOfLines={1}>
              {DepartmentTitle}
            </Text>
            <View style={styles.flexDirectionRow}>
              <Text style={styles.textTrichYeu} numberOfLines={1}>
                {removeSpecialCharacters(Position)}
              </Text>
              <TouchableOpacity
                style={[
                  styles.viewTrangThai,
                  { backgroundColor: customColor?.backgroundColor },
                ]}
              >
                <Text
                  style={[styles.textTrangThai, { color: customColor?.color }]}
                  numberOfLines={1}
                >
                  {TrangThai}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const IconView = ({ ID }: any) => {
    if (ID === ActionJsonType.ChiaSe)
      return <ShareBlueIcon color={colors.white} dimens={20} />;
    if (ID === ActionJsonType.PheDuyet) return <DongYIcon />;
    if (ID === ActionJsonType.YeuCauBoSung) return <BoSungThongTInIcon />;
    if (ID === ActionJsonType.YeuCauHieuChinh) return <DeNghiHieuChinhIcon />;
    if (ID === ActionJsonType.DongY) return <DongYIcon />;
    if (ID === ActionJsonType.ThuHoi) return <BoSungThongTInIcon />;
    if (ID === ActionJsonType.ChuyenXuLy) return <FowardProcesscon />;
    return <View />;
  };
  const ItemAction = ({ item, index, onActionPress }: any) => {
    if (index >= 2) return null;
    const { Title, ID } = item;
    return (
      <TouchableOpacity
        key={ID}
        style={styles.shareButton}
        onPress={() => onActionPress(ID)}
      >
        <View style={styles.flexDirectionRowAction}>
          <IconView ID={ID} />
          <Text style={styles.tabBarLabelActive} numberOfLines={1}>
            {Title}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  // renderView
  return (
    <View style={styles.container}>
      <View style={styles.viewHeader}>
        <View style={styles.flexDirectionRowBetween}>
          <TouchableOpacity
            style={styles.backPress}
            activeOpacity={1}
            onPress={onGoBack}
          >
            <BackIcon />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={gotoThongTinLuanChuyenVBBHScreen}
            style={styles.thongTinLuanChuyen}
          >
            <ClockWhiteIcon />
          </TouchableOpacity>
        </View>
      </View>
      <ScrollView style={styles.cardView}>
        <TouchableOpacity onPress={onShowFullTrichYeu}>
          <Text style={styles.titleHeader} numberOfLines={2}>
            {dataVBDiDetail?.TrichYeu}
          </Text>
        </TouchableOpacity>
        <View style={styles.dashed} />
        <TouchableOpacity
          style={styles.threeDotView}
          onPress={onChangeIsFullScren}
        >
          <ThreeDotIcon />
        </TouchableOpacity>
        {isFullScreen && (
          <View>
            <Text style={styles.title}>Loại văn bản</Text>
            <Text style={styles.content} numberOfLines={1}>
              {LoaiVanBanFormat}
            </Text>
            <Text style={styles.title}>Đơn vị soạn thảo</Text>
            <Text style={styles.content} numberOfLines={1}>
              {removeSpecialCharacters(dataVBDiDetail?.DonVi)}
            </Text>
          </View>
        )}

        {!checkIsEmpty(dataVBDiAttachFile) && (
          <Text style={styles.documentFile}>Tài liệu đính kèm</Text>
        )}
        {!checkIsEmpty(dataVBDiAttachFile) && (
          <FlatList
            style={styles.containerAttach}
            nestedScrollEnabled
            extraData={dataVBDiAttachFile}
            disableVirtualization
            keyExtractor={(item, index) => item?.ID + index.toString()}
            data={dataVBDiAttachFile}
            renderItem={({ item, index }) => (
              <ItemAttach item={item} index={index} />
            )}
          />
        )}
        <Text style={[styles.documentFile, { marginVertical: 15 }]}>
          Ý kiến lãnh đạo
        </Text>
        <View>
          {/* <TouchableOpacity
            onPress={onOpenModalYKienLanhDao}
            style={styles.yKienLanhDaoTouch}
          /> */}
          <TextInputCustom
            placeholder="Vui lòng nhập ý kiến"
            placeholderTextColor={colors.grey999}
            multiline
            onChangeText={onChangeYKienLanhDao}
            value={yKienLanhDao}
            style={styles.commentInput}
          />
        </View>
        {!arrayIsEmpty(dataVBDiDetail?.CommentJson) && (
          <FlatList
            nestedScrollEnabled
            style={styles.commentJsonFlatlist}
            extraData={dataVBDiDetail?.CommentJson}
            disableVirtualization
            horizontal={false}
            keyExtractor={(item, index) => item?.ID + index.toString()}
            data={dataVBDiDetail?.CommentJson}
            renderItem={({ item, index }) => (
              <ItemVBDenCommentJson item={item} index={index} />
            )}
          />
        )}
        <View>
          {!arrayIsEmpty(dataVBDiDetail?.TaskJson) && (
            <Text style={[styles.documentFile, { marginTop: 15 }]}>
              Tổ chức phân công thực hiện
            </Text>
          )}
          {!arrayIsEmpty(dataVBDiDetail?.TaskJson) && (
            <FlatList
              nestedScrollEnabled
              style={styles.danhMucFlatList}
              extraData={dataVBDiDetail?.TaskJson}
              disableVirtualization
              horizontal={false}
              keyExtractor={(item, index) => item?.ID + index.toString()}
              data={dataVBDiDetail?.TaskJson}
              renderItem={({ item, index }) => (
                <ItemVBDenTaskJson
                  item={item}
                  index={index}
                  gotoNhiemVuDaPhanCongScreen={() =>
                    gotoNhiemVuDaPhanCongScreen(item?.ID)
                  }
                />
              )}
            />
          )}
        </View>
        <View style={{ marginBottom: 30 }} />
      </ScrollView>

      {dataVBDiDetail?.ActionJson && (
        <View style={[styles.actionView]}>
          {/* test concat({ ID: 256, Title: "Kết thúc" }) */}
          {dataVBDiDetail?.ActionJson?.map((item: any, index: any) => {
            return (
              <ItemAction
                key={index}
                item={item}
                index={index}
                onActionPress={onActionPress}
              />
            );
          })}
          {dataVBDiDetail?.ActionJson?.length >= 3 && (
            <TouchableOpacity
              style={styles.actionMore}
              onPress={openModalActionOptional}
            >
              <ActionMoreIcon />
            </TouchableOpacity>
          )}
        </View>
      )}

      <LoadingView isLoading={isLoadingVBDi} />
      <ActionOptionalModal
        ActionJson={dataVBDiDetail?.ActionJson}
        modalVisible={modalActionOptional}
        onCloseModal={onCloseActionOptionalModal}
        onChooseonActionMorePress={onActionPress}
      />
      {/* <ChoYKienLanhDaoModal
        modalVisible={modalYKienLanhDao}
        onCloseModalYKienLanhDao={onCloseModalYKienLanhDao}
        onChangeYKienLanhDao={(text) => onChangeYKienLanhDao(text)}
        yKienLanhDao={yKienLanhDao}
      /> */}
      <ChiaSeModal
        modalVisible={modalChiaSe}
        onCloseModalChiaSe={onCloseModalChiaSe}
        onConfirmModalChiaSe={(text) => onConfirmModalChiaSe(text)}
        DocumentID={DocumentID}
        ykienlanhdao={yKienLanhDao}
        onChooseTypeChiaSe={onChooseTypeChiaSe}
        filterdanhSachUsersAndGroup={filterdanhSachUsersAndGroup}
        chiaSeStringList={chiaSeStringList}
      />

      <ChuyenXuLyModal
        modalVisible={modalChuyenXuLy}
        chuyenXuLyStringList={chuyenXuLyStringList}
        onCloseChuyenXuLyModal={onCloseChuyenXuLyModal}
        onChooseNguoiDuocChuyenXuLy={onChooseNguoiDuocChuyenXuLy}
        onConfirmChuyenXuLyModal={onConfirmChuyenXuLyModal}
        ykienlanhdao={yKienLanhDao}
      />
      <DongYModal
        modalVisible={modalDongY}
        dongYStringList={dongYStringList}
        onCloseChuyenXuLyModal={onCloseDongYModal}
        onChooseNguoiDuocChuyenXuLy={onChooseCCDongY}
        onConfirmChuyenXuLyModal={onConfirmDongYModal}
        ykienlanhdao={yKienLanhDao}
      />
      
      <PheDuyetModal
        modalVisible={modalPheDuyet}
        pheDuyetStringList={pheDuyetStringList}
        onCloseChuyenXuLyModal={onClosePheDuyetModal}
        onChooseNguoiDuocChuyenXuLy={onChooseCCPheDuyet}
        onConfirmChuyenXuLyModal={onConfirmPheDuyetModal}
        ykienlanhdao={yKienLanhDao}
      />

      <YeuCauHieuChinhModal
        modalVisible={modalYeuCauHieuChinh}
        YeuCauHieuChinhStringList={YeuCauHieuChinhStringList}
        onCloseChuyenXuLyModal={onCloseYeuCauHieuChinhModal}
        onChooseNguoiDuocChuyenXuLy={onChooseCCYeuCauHieuChinh}
        onConfirmChuyenXuLyModal={onConfirmYeuCauHieuChinhModal}
        ykienlanhdao={yKienLanhDao}
      />

      <BoSungThongTinModal
        modalVisible={modalBoSungThongTin}
        nguoiDuocBoSungThongTinData={nguoiDuocBoSungThongTinDataState}
        onCloseChuyenXuLyModal={onCloseBoSungThongTinModal}
        onChooseNguoiDuocChuyenXuLy={onChooseNguoiDuocYeuCauBoSung}
        onConfirmChuyenXuLyModal={onConfirmBoSungThongTinModal}
        ykienlanhdao={yKienLanhDao}
      />

      <ThuHoiModal
        modalVisible={modalThuHoi}
        onCloseModalThuHoi={onCloseModalThuHoi}
        DocumentID={DocumentID}
        onConfirmModalThuHoi={(text, DocumentID) => onConfirmModalThuHoi(text, DocumentID)}
        ykienlanhdao={yKienLanhDao}
      />

      <LoadingView isLoading={isLoadingDetail} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
  thongTinLuanChuyen: { padding: 3 },
  scrollView: {
    flex: 1,
    paddingBottom: 30,
  },
  cardView: {
    backgroundColor: "#FFFFFF",
    margin: 16,
    borderRadius: 8,
    paddingVertical: 15,
  },
  threeDotView: {
    alignSelf: "flex-end",
    marginRight: 10,
    padding: 10,
  },
  item: {},
  containerAttach: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    marginHorizontal: 15,
    overflow: "hidden",
  },
  dashed: {
    borderStyle: "dashed",
    borderTopWidth: 1,
    borderTopColor: "#E5E5E5",
    marginVertical: 15,
  },
  flexOne: {
    flex: 1,
  },
  content: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginBottom: 10,
  },
  contenAttach: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginTop: 5,
  },
  title: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  documentFile: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginLeft: 15,
    marginBottom: 10,
  },
  documentFileView: {
    padding: 15,
  },
  viewHeader: {
    backgroundColor: colors.primary,
    height: 55,
    justifyContent: "center",
    width: "100%",
    paddingRight: 15,
    paddingLeft: 7,
  },
  titleHeader: {
    fontSize: FontSize.MEDIUM,
    color: colors.scienceBlue,
    fontWeight: "700",
    fontFamily: "arial",
    paddingHorizontal: 15,
  },
  titleDocumentFile: {
    fontSize: FontSize.MEDIUM,
    color: colors.scienceBlue,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    borderRadius: 4,
  },
  sizeDocumentFile: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginTop: 5,
    borderRadius: 4,
  },
  flexDirectionRowBetween: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
    overflow: 'hidden'
  },
  flexDirectionRowAction: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  backPress: {
    padding: 8,
  },
  tabBarLabelActive: {
    color: colors.white,
    fontWeight: "400",
    fontSize: 18,
    marginLeft: 12,
  },
  viewTabBottomBar: {
    flexDirection: "row",
    height: dimensWidth(68),
    alignItems: "center",
    backgroundColor: colors.blueMedium,
  },
  bottomTab: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
  },
  viewButton: {
    flex: 1,
    alignItems: "center",
  },
  actionMore: {
    padding: 8,
  },
  actionView: {
    height: dimensWidth(68),
    backgroundColor: colors.blueMedium,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  shareButton: {
    flex: 1,
  },
  commentInput: {
    paddingHorizontal: 10,
    borderColor: "#DDDDDD",
    borderWidth: 1,
    borderRadius: 3,
    height: 100,
    marginHorizontal: 15,
    textAlignVertical: "top",
  },
  titleVbDenTheoMuc: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    borderRadius: 4,
  },
  titleCommentJson: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    borderRadius: 4,
  },
  positionComment: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    borderRadius: 4,
  },
  viewTrangThai: {
    height: dimensWidth(22),
    width: dimensWidth(90),
    borderRadius: 3,
    backgroundColor: "#F0F0F0",
    justifyContent: "center",
    alignItems: "center",
  },
  textTrichYeu: {
    flex: 1,
    fontSize: dimensWidth(13),
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    marginRight: 10,
  },
  textTrangThai: {
    fontSize: dimensWidth(12),
    color: "#626262",
    fontWeight: "400",
    fontFamily: "arial",
  },
  danhMucItemView: {
    backgroundColor: colors.white,
    padding: 15,
  },
  hoanTatTextColor: {
    color: "#3ABA32",
  },
  hoanTatBackGroundColor: {
    backgroundColor: "#E6FFE4",
  },
  danhMucFlatList: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    marginHorizontal: 15,
    overflow: "hidden",
  },
  commentJsonFlatlist: {
    borderColor: colors.greyDDD,
    borderWidth: 1,
    borderRadius: 8,
    margin: 15,
    overflow: "hidden",
  },
  yKienLanhDaoTouch: {
    zIndex: 999,
    position: "absolute",
    height: "100%",
    width: "100%",
  },
});

export default App;
