import React, { useCallback, useState, useEffect, useMemo } from "react";
import {
  View,
  FlatList,
  StyleSheet,
  Text,
  SectionList,
  TouchableOpacity,
  Alert,
  Image,
} from "react-native";
import { BackIcon, DashedLine, RetangleGreenIcon } from "assets/SVG/index";
import colors from "themes/Colors";
import { dimensWidth, dimnensHeight, FontSize } from "themes/const";
import { useDispatch, useSelector } from "react-redux";
import {
  format_yy_mm_mm_dd_hh,
  arrayIsEmpty,
  removeSpecialCharacters,
  isNullOrUndefined,
  stripHtml,
} from "helpers/formater";
import {
  fetchThongTinLuanChuyenVbDi,
} from "stores/VBDi/reducer";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { create } from "react-test-renderer";
import { NoDataView } from "components";
import FastImage from "react-native-fast-image";
import { BaseUrl } from "~/services/api";

type ItemProps = {
  index: number;
  item: any;
  subSite: any;
  token: any;
  isEnd: any
};
type Props = {
  navigation: any;
  route: any;
};

const Item = ({ item, index, subSite, token, isEnd }: ItemProps) => {
  const { SubmitAction, ImagePath, Position, FullName, Created, isLast, Action, Note } = item;
  const formatSubmitActionText = useMemo(() => {
    const formatText = stripHtml(SubmitAction)
    return formatText
  }, [SubmitAction]);

  return (
    <View style={{ flex: 1, flexDirection: 'row' }}>
      <View style={{ marginLeft: 22 }}>
        <DashedLine color={isLast ? "#fff" : "#B3B3B3"} height="100%" width={2} />
      </View>
      <View
        style={styles.item}
      >
        <View style={[styles.flexDirectionRow, { marginTop: 10 }]}>
          <FastImage
            style={styles.itemAvatar}
            source={{
              uri: `${BaseUrl}/${subSite}${ImagePath}`,
              headers: { Authorization: `${token}` },
              priority: FastImage.priority.normal,
            }}
          />
          <View style={{ flex: 1 }}>
            <View style={styles.flexDirectionRow}>
              <Text style={styles.titleContent} numberOfLines={1}>
                {FullName}
              </Text>
              <Text style={styles.date} numberOfLines={1}>
                {format_yy_mm_mm_dd_hh(Created)}
              </Text>
            </View>
            <View style={styles.flexDirectionRow}>
              <Text style={styles.titleContent} numberOfLines={1}>
                {removeSpecialCharacters(Position)}
              </Text>
              {
                SubmitAction && <View style={styles.viewSubmitAction}>
                  <Text style={styles.textSubmitAction}>
                    {formatSubmitActionText}
                  </Text>
                </View>
              }
            </View>
          </View>
        </View>
        {
          Note && <Text style={styles.textNoted} numberOfLines={1}>
            {Note}
          </Text>
        }
      </View>
    </View>

  );
};

const ThongTinLuanChuyen = ({ navigation, route }: Props) => {
  const {
    dataThongTinLuyenChuyenVbDi,
  } = useSelector((state: RootState) => state.vbDiReducer);
  const { subSite, token } = useSelector(
    (state: any) => state.login
  );
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const fetchThongTinLuanChuyenVbDiRequest = useCallback(
    ({ itemId, subSite }: any) => {
      dispatch(
        fetchThongTinLuanChuyenVbDi({
          itemId,
          subSite
        })
      );
    },
    [dispatch]
  );
  useEffect(() => {
    if (route?.params?.itemId) {
      fetchThongTinLuanChuyenVbDiRequest({ itemId: route?.params?.itemId, subSite });
    }
  }, [
    fetchThongTinLuanChuyenVbDiRequest,
    route?.params?.itemId,
    subSite
  ]);

  const onGoBack = useCallback(() => {
    navigation.goBack();
  }, [navigation]);

  return (
    <View style={styles.container}>
      <View style={styles.viewHeader}>
        <View style={styles.flexDirectionRow}>
          <TouchableOpacity style={styles.backPress} onPress={onGoBack}>
            <BackIcon />
          </TouchableOpacity>
          <Text style={styles.titleHeader}>Thông tin luân chuyển</Text>
        </View>
      </View>
      {arrayIsEmpty(dataThongTinLuyenChuyenVbDi) ? (
        <NoDataView />
      ) : (
        <SectionList
          style={{
            margin: 15,
            backgroundColor: 'white',
            borderRadius: 8,
            paddingTop: 10
          }}
          sections={dataThongTinLuyenChuyenVbDi}
          keyExtractor={(item, index) => item + index}
          renderItem={({ item, index }) => (
            <Item
              item={item}
              index={index}
              subSite={subSite}
              token={token}
            />
          )}
          renderSectionHeader={({ section: { item } }) => (
            <View style={{
              marginLeft: 15,
              marginRight: 15
            }}>
              <View style={styles.flexDirectionRow}>
                <View style={{
                  marginRight: dimensWidth(10)
                }}>
                  {
                    !isNullOrUndefined(item.SubmitAction) ? <RetangleGreenIcon /> : <RetangleGreenIcon color='#FFDA6C' />
                  }
                </View>
                <Text style={styles.title} numberOfLines={1}>
                  {item.Action}
                </Text>
              </View>
            </View>
          )}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
  viewDSNguoiXem: {
    borderRadius: 8,
    overflow: "hidden",
    backgroundColor: colors.white,
  },
  viewUserName: { marginRight: 20, marginLeft: -8 },
  viewUserImage: {
    height: 40,
    width: 40,
    borderRadius: 20,
    marginLeft: 40,
  },
  flatlist: {
    borderRadius: 8,
    backgroundColor: colors.white,
    overflow: "hidden",
  },
  containerFlatlist: {
    margin: 15,
  },
  item: {
    flex: 1,
    paddingBottom: 20,
    paddingTop: 10
  },
  title: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: "700",
    fontFamily: "arial",
  },
  titleContent: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    flex: 1,
    alignSelf: 'flex-start'
  },
  textNoted: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 30,
    alignSelf: 'flex-start',
    marginTop: 10
  },
  content: {
    flex: 1,
    fontSize: dimensWidth(12),
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    marginHorizontal: 10,
    backgroundColor: colors.lightBlue,
    paddingHorizontal: 15,
    paddingVertical: 4,
    borderRadius: 5,
    overflow: 'hidden',
  },
  viewSubmitAction: {
    backgroundColor: colors.lightBlue,
    marginHorizontal: 10,
    paddingHorizontal: 15,
    paddingVertical: 4,
    borderRadius: 5,
    overflow: 'hidden',
  },
  textSubmitAction: {
    fontSize: dimensWidth(12),
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    flex: 1,
  },
  date: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    paddingHorizontal: 6,
    paddingVertical: 4,
  },
  viewHeader: {
    backgroundColor: colors.primary,
    height: 55,
    justifyContent: "center",
    width: "100%",
    paddingHorizontal: 10,
  },
  titleHeader: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  itemAvatar: {
    height: dimensWidth(40),
    width: dimensWidth(40),
    borderRadius: dimensWidth(20),
    marginLeft: 30,
    marginTop: 5,
    alignSelf: 'flex-start'
  },
  flexDirectionRowBetween: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  backPress: {
    padding: 8,
  },
  onPressActiveTab: {
    height: 60,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.white,
    borderBottomColor: colors.primary,
    borderBottomWidth: 1,
    paddingLeft: 20,
  },
  onPressInActiveTab: {
    height: 60,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.white,
    paddingLeft: 20,
  },
  titleActiveTab: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.primary,
    fontWeight: "700",
    fontFamily: "arial",
  },
  titleInActiveTab: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.grey999,
    fontWeight: "400",
    fontFamily: "arial",
  },
  titleContentVBdenDSNguoiXem: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    marginBottom: 4
  },
  contentVBDenDSNguoiXem: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
  },
  positionVBDenDSNguoiXem: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
  },
});

export default ThongTinLuanChuyen;
