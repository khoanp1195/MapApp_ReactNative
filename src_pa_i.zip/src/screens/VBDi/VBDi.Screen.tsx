import React, { useCallback, useState, useEffect, useMemo } from "react";
import {
  SafeAreaView,
  View,
  FlatList,
  Text,
  StatusBar,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  RefreshControl,
} from "react-native";
import styles from "./VBDi.Style";
import {
  calculateBetweenTwoDate,
  formatCreatedDate,
  arrayIsEmpty,
  checkIsEmpty,
  format_yy_mm_mm_dd_hh,
  removeSpecialCharacters,
  isNullOrEmpty
} from "helpers/formater";
import { SearchIcon, FilterIcon, MenuIcon } from "assets/SVG/index";
import FilterModal from "./components/FilterModal";
import { RootState } from "stores";
import SearchInput from "~/components/SearchInput";
import colors from "themes/Colors";
import { fetchBanLanhDao } from "stores/home/reducer";
import { fetchVBDiApi } from "stores/VBDi/reducer";
import { useDispatch, useSelector } from "react-redux";
import CalendarPickerModal from "./components/CalendarPickerModal";
import moment from "moment";
import { NoDataView } from "components";
import { ThunkDispatch } from "@reduxjs/toolkit";
import FastImage from "react-native-fast-image";
import { BaseUrl } from "~/services/api";
import { TABNAME } from "./VBDiType";
import { TrinhLanhDaoType } from "../VBDen/VBDenType";
import { funtionVBDiData } from "~/themes/const";
import ImageLoad from "~/components/ImageLoad";

type Props = {
  navigation: any;
  route: any;
};


const Item = ({ item, gotoDetail, subSite, token, tabName }: any) => {
  const {
    SendUnit,
    ListName,
    ImagePath,
    Title,
    SiteName,
    Status,
    Created,
    DueDate,
    Read,
    Action,
    DocumentID,
    TaskCategory
  } = item;
  const gotoDetailPress = () => {
    gotoDetail(DocumentID, ListName);
  };
  let dueDateFormat = ""
  let isExpired = false
  let isExpiredToday = false
  const distanceDate = calculateBetweenTwoDate(DueDate);
  if (!checkIsEmpty(distanceDate)) {
    if (parseInt(distanceDate) < 0) {
      dueDateFormat = format_yy_mm_mm_dd_hh(DueDate);
    } else if (parseInt(distanceDate) >= 0 && parseInt(distanceDate) < 1) {
      dueDateFormat = "Hạn hôm nay";
      isExpiredToday = true
    }
    else {
      isExpired = true
      dueDateFormat = "Quá hạn " + distanceDate + " ngày";
    }
  }
  const formatCreated = formatCreatedDate(Created);
  return (
    <TouchableOpacity style={styles.item} onPress={gotoDetailPress}>
      {
        isNullOrEmpty(ImagePath) ? <Image
          style={styles.itemAvatar}
          source={require('../../assets/images/avatar80.png')}
        /> : <FastImage
          style={styles.itemAvatar}
          source={{
            uri: BaseUrl + `/${subSite}` + ImagePath,
            headers: { Authorization: `${token}` },
            priority: FastImage.priority.normal
          }}
        />
      }
      <View style={{ flex: 1 }}>
        <View style={styles.flexDirectionBetween}>
          <Text style={styles.title} numberOfLines={2}>
            {SendUnit}
          </Text>
          <Text style={styles.date}>{formatCreated}</Text>
        </View>

        <View style={{
          flexDirection: 'row'
        }}>
          <Text style={[{ flex: 1 }, styles.category]}>{ListName}</Text>
          <Text style={styles.category} numberOfLines={1}>{TaskCategory}</Text>
        </View>
        <Text style={[styles.title, tabName === TABNAME.VBChoXuLy && !Read && { fontWeight: '700' }]}>{Title}</Text>
        <View style={styles.flexDirectionBetween}>
          <View style={styles.touchSendUnit}>
            <Text style={styles.textSendUnit}>{Action}</Text>
          </View>
          <Text
            style={[
              styles.date,
              isExpiredToday && styles.todayDeadlife,
              isExpired && styles.distanceDate,
            ]}
          >
            {Status === 1 ? "" : dueDateFormat}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const ItemOwn = ({ item, subSite, token, gotoDetail }: any) => {
  const {
    ID,
    Title,
    ActionStatus,
    TrichYeu,
    DueDate,
    Created,
    Status,
    Author,
    ImagePath,
  } = item;
  const gotoDetailPress = () => {
    gotoDetail(ID, "Văn bản đi");
  };
  let dueDateFormat = ""
  let isExpired = false
  let isExpiredToday = false
  const distanceDate = calculateBetweenTwoDate(DueDate);
  if (!checkIsEmpty(distanceDate)) {
    if (parseInt(distanceDate) < 0) {
      dueDateFormat = format_yy_mm_mm_dd_hh(DueDate);
    } else if (parseInt(distanceDate) >= 0 && parseInt(distanceDate) < 1) {
      dueDateFormat = "Hạn hôm nay";
      isExpiredToday = true
    }
    else {
      isExpired = true
      dueDateFormat = "Quá hạn " + distanceDate + " ngày";
    }
  }
  const formatCreated = formatCreatedDate(Created);
  return (
    <TouchableOpacity style={styles.item} onPress={gotoDetailPress}>
      <ImageLoad
        style={styles.itemAvatar}
        source={{
          uri: BaseUrl + `/${subSite}` + ImagePath,
          headers: { Authorization: `${token}` },
          priority: FastImage.priority.normal
        }}
      />
      <View style={{ flex: 1 }}>
        <View style={styles.flexDirectionBetween}>
          <Text style={styles.title} numberOfLines={2}>
            {!isNullOrEmpty(Author) ? removeSpecialCharacters(Author) : ""}
          </Text>
          <Text style={styles.date}>{formatCreated}</Text>
        </View>

        <Text style={styles.category}>Văn bản đi</Text>
        <Text style={styles.title}>{Title}</Text>
        <View style={styles.flexDirectionBetween}>
          <View style={styles.touchSendUnit}>
            <Text style={styles.textSendUnit}>{Status}</Text>
          </View>
          <Text
            style={[
              styles.date,
              isExpiredToday && styles.todayDeadlife,
              isExpired && styles.distanceDate,
            ]}
          >
            {dueDateFormat}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const renderFooter = (isLoadingVBDi: boolean, refreshing: boolean, isLoadMoreVbDi: boolean, Offset: any) => {
  return (
    //Footer View with Load More button
    <View style={styles.footer}>
      {isLoadingVBDi && !refreshing && isLoadMoreVbDi && Offset !== 0 ? (
        <ActivityIndicator color="blue" style={{ marginLeft: 8 }} />
      ) : null}
    </View>
  );
};
const VBDiScreen = ({ route, navigation }: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const { dataVBDi, totalRecord, totalRecordVbDi, isLoadMoreVbDi, isLoadingVBDi, isGoBackVBDiScreen } = useSelector(
    (state: any) => state.vbDiReducer
  );
  
  const { subSite, token } = useSelector(
    (state: any) => state.login
  );
  let initialPayloadVBDi = { TinhTrang: "", FromDate: "", ToDate: "", subSite: subSite }
  const todayFormated = moment().format("YYYY-MM-DD");
  const prevMonth = moment(todayFormated).add(-1, "M").format("YYYY-MM-DD");
  const { dataBanLanhDao } = useSelector((state: RootState) => state.home);
  const [payloadVBDi, setPayloadVBDi] = useState<any>(initialPayloadVBDi);
  const [funtionVBDi, setFuntionVBDi] = useState(funtionVBDiData.VBDiTitle);
  const [tabName, setTabName] = useState(TABNAME.VBChoXuLy);
  const [visbleModalFilter, setVisbleModalFiltert] = useState(false);
  const [dataVBDiState, setDataVBDiState] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [tinhTrangState, settinhTrangState] = useState("Tất cả");
  const [lanhDaoNameSellectedState, setLanhDaoNameSellectedState] =
    useState<any>([]);
  const [startDate, setStartDate] = useState(prevMonth);
  const [endDate, setEndDate] = useState(todayFormated);
  const [isOpenCalendarPicker, setIsOpenCalendarPicker] = useState(false);
  const [typeModal, setTypeModal] = useState("startDate");
  const [filterText, setFilterText] = useState("");
  const [Offset, setOffset] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const [isFilter, setIsFilter] = useState(false)

  const resetData = useCallback(() => {
    setOffset(0);
    setFilterText("")
    setTabName(TABNAME.VBChoXuLy)
  }, []);
  const fetchVBDiRequest = useCallback((payload: any) => {
    dispatch(fetchVBDiApi(payload));
  }, [dispatch]);
  useEffect(() => {
    if (route.params?.funtionVBDi) {
      resetData()
      setFuntionVBDi(route.params?.funtionVBDi)
    }
  }, [route.params])
  useEffect(() => {
    const status = tabName === TABNAME.VBChoXuLy ? 0 : 1
    const FilterText = filterText
    fetchVBDiRequest({ ...payloadVBDi, Offset, status, FilterText, funtionVBDi, subSite });
  }, [payloadVBDi, tabName, filterText, funtionVBDi, Offset, subSite, dispatch]);

  const onConfirmModalPress = useCallback(() => {
    setOffset(0)
    setFilterText("")
    const payload = {
      TinhTrang: tinhTrangState,
      FromDate: startDate,
      ToDate: endDate,
    }
    setPayloadVBDi(payload);
    setVisbleModalFiltert(false);
    setIsFilter(true)
  }, [tabName, tinhTrangState, startDate, endDate, filterText, Offset, subSite]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    setOffset(0);
    setFilterText("");
    onReFilterModalPress();
    setPayloadVBDi(initialPayloadVBDi)
  }, [refreshing]);
  useEffect(() => {
    if (isGoBackVBDiScreen) {
      onRefresh()
    }
  }, [isGoBackVBDiScreen])

  const onPressProcessedDocx = useCallback(() => {
    if (funtionVBDi.key === 'VBDiTitle' && isFilter) {
      onReFilterModalPress()
    }

    setOffset(0);
    setTabName(TABNAME.VBDaXuLy);
  }, [isFilter, funtionVBDi]);

  const onPressWaitProcesseDocx = useCallback(() => {
    if (funtionVBDi.key === 'VBDiTitle' && isFilter) {
      onReFilterModalPress()
    }

    setOffset(0);
    setTabName(TABNAME.VBChoXuLy);
  }, [isFilter, funtionVBDi]);

  const onPressFilter = useCallback(() => {
    if (isSearching) setIsSearching(false);
    setVisbleModalFiltert(true);
  }, [visbleModalFilter]);
  const onPressSearch = useCallback(() => {
    if (funtionVBDi.key === 'VBDiTitle' && isSearching) {
      setOffset(0)
      setFilterText("")
    }
    setIsSearching(!isSearching);
  }, [isSearching, funtionVBDi]);

  const onReFilterModalPress = useCallback(() => {
    setStartDate(prevMonth);
    setEndDate(todayFormated);

    if (funtionVBDi === funtionVBDiData.VBDiTitle || funtionVBDi === funtionVBDiData.TatCa) {
      settinhTrangState("Tất cả")
    } else if (funtionVBDi === funtionVBDiData.Chopheduyet) {
      settinhTrangState("Chờ phê duyệt")
    } else if (funtionVBDi === funtionVBDiData.DaPheDuyet) {
      settinhTrangState("Đã phê duyệt")
    }

    setIsFilter(false)
    setOffset(0)
    setVisbleModalFiltert(false)
    const payload = {
      TinhTrang: "",
      FromDate: "",
      ToDate: "",
      subSite: subSite
    }
    setPayloadVBDi(payload);
  }, [subSite, funtionVBDi]);

  const onPressChooseLanhDao = useCallback(() => {
    setVisbleModalFiltert(false);
    navigation.navigate({
      name: "ChooseLanhDaoChoYKienVBDiScreen",
      params: { lanhDaoNameSellectedParam: lanhDaoNameSellectedState, screenName: 'VBDiScreen' },
    });
  }, [lanhDaoNameSellectedState]);

  useEffect(() => {
    setDataVBDiState(dataVBDi);
    if (refreshing) setRefreshing(false);
  }, [dataVBDi]);

  useEffect(() => {
    if (route?.params?.tinhTrangSellected) {
      setVisbleModalFiltert(true);
      settinhTrangState(route?.params?.tinhTrangSellected);
    }
  }, [route.params]);

  const onPressChooseType = useCallback(() => {
    if (funtionVBDi === funtionVBDiData.VBDiTitle || funtionVBDi === funtionVBDiData.TatCa) {
      setVisbleModalFiltert(false);
      navigation.navigate({
        name: "TinhTrangVBDiFilterScreen",
        params: { tinhTrangSellected: tinhTrangState, screenName: 'VBDiScreen' },
      });
    }
  }, [tinhTrangState, funtionVBDi]);
  const fetchBanLanhDaoRequest = useCallback(async () => {
    dispatch(fetchBanLanhDao(subSite));
  }, [dispatch]);
  useEffect(() => {
    fetchBanLanhDaoRequest();
  }, [fetchBanLanhDaoRequest]);

  useEffect(() => {
    if (!arrayIsEmpty(route.params?.lanhDaoNameSellectedParam)) {
      setVisbleModalFiltert(true);
      setLanhDaoNameSellectedState(route.params?.lanhDaoNameSellectedParam);
    } else {
      if (!arrayIsEmpty(dataBanLanhDao)) {
        const newData = dataBanLanhDao.map((it: any) => it = { ...it, isSellected: false })
        setLanhDaoNameSellectedState([{ ID: 999, LanhDao: TrinhLanhDaoType.TAT_CA, Orders: -1, Title: TrinhLanhDaoType.TAT_CA, isSellected: true }, ...newData]);
      }
    }

  }, [dataBanLanhDao, route.params?.lanhDaoNameSellectedParam]);

  useEffect(() => {
    if (funtionVBDi === funtionVBDiData.VBDiTitle || funtionVBDi === funtionVBDiData.TatCa) {
      settinhTrangState("Tất cả")
    } else if (funtionVBDi === funtionVBDiData.Chopheduyet) {
      settinhTrangState("Chờ phê duyệt")
    } else if (funtionVBDi === funtionVBDiData.DaPheDuyet) {
      settinhTrangState("Đã phê duyệt")
    }
  }, [funtionVBDi])

  const lanhDaoNameSellectedFilter = useMemo(
    () => {
      if (!arrayIsEmpty(lanhDaoNameSellectedState)) {
        const newData = lanhDaoNameSellectedState?.find((it: any) => it.isSellected)?.Title;
        return newData ? newData : ""
      }
      return "Tất cả"
    },
    [navigation, lanhDaoNameSellectedState]
  );

  const onPressOpenCalendarPicker = useCallback(
    (typeModal: string) => {
      setVisbleModalFiltert(false);
      setTypeModal(typeModal);
      setIsOpenCalendarPicker(true);
    },
    [isOpenCalendarPicker, typeModal]
  );

  const onDateChangeModal = useCallback(
    (date: any) => {
      if (typeModal == "startDate") {
        setStartDate(date);
      } else {
        setEndDate(date);
      }
      setIsOpenCalendarPicker(false);
      setVisbleModalFiltert(true);
    },
    [typeModal, startDate, endDate]
  );
  const onCloseModal = useCallback(() => {
    setIsOpenCalendarPicker(false);
  }, []);
  const onChangeFilterText = useCallback(
    (text: string) => {
      setFilterText(text);
    },
    [filterText]
  );
  const removeSelectedDate = useCallback(() => {
    if (typeModal == "startDate") {
      setStartDate("");
    } else {
      setEndDate("");
    }
  }, [typeModal, startDate, endDate]);
  const resetToday = useCallback(
    (today: any) => {
      setStartDate(today);
      setEndDate(today);
    },
    [typeModal, startDate, endDate]
  );
  const gotoDetailPress = useCallback((DocumentID: Number, ListName: string) => {
    navigation.navigate({
      name: "VBDiDetailScreen",
      params: { DocumentID, ListName },
    });

    if (funtionVBDi.key === 'VBDiTitle') {
      const newData = dataVBDiState.map((it: any) => it.DocumentID === DocumentID ? { ...it, Read: true } : it)
      setDataVBDiState(newData);
    }
  }, [dataVBDiState]);

  const handleLoadmore = async () => {
    if (totalRecord > dataVBDi.length) {
      const newOffset = dataVBDi.length;
      setOffset(newOffset);
      setPayloadVBDi({ ...payloadVBDi, Offset: newOffset })
    }
  };

  const openDrawer = useCallback(() => {
    navigation.openDrawer();
  }, [navigation]);

  return (
    <View style={styles.container}>
      <View style={styles.viewAvatar}>
        <View style={styles.flexDirectionRow}>
          <View style={styles.flexDirectionRow}>
            <TouchableOpacity onPress={openDrawer}>
              <View
                style={styles.avatar}
              >
                <MenuIcon color='#fff' />
              </View>
            </TouchableOpacity>
            <Text style={styles.titleAvatar}>{`${funtionVBDi.title} - ${subSite.toUpperCase()}`}</Text>
          </View>
          <View style={styles.flexDirectionRow}>
            <TouchableOpacity style={styles.searchIcon} onPress={onPressSearch}>
              <SearchIcon color={!isSearching ? colors.white : 'red'} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.filterIcon} onPress={onPressFilter}>
              <FilterIcon color={isFilter ? 'red' : '#fff'} />
            </TouchableOpacity>
          </View>
        </View>
        {!isSearching && funtionVBDi.key === 'VBDiTitle' ? (
          <View style={styles.flexDirectionRowTab}>
            <TouchableOpacity
              activeOpacity={1}
              onPress={onPressWaitProcesseDocx}
              style={
                tabName === TABNAME.VBChoXuLy
                  ? styles.onPressActiveTab
                  : styles.onPressInActiveTab
              }
            >
              <Text
                style={
                  tabName === TABNAME.VBChoXuLy
                    ? styles.titleActiveTab
                    : styles.titleInActiveTab
                }
              >
                {TABNAME.VBChoXuLy}
                <Text style={styles.titleNotifyCount}>{` (${totalRecordVbDi})`}</Text>
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              activeOpacity={1}
              onPress={onPressProcessedDocx}
              style={
                tabName === TABNAME.VBDaXuLy
                  ? styles.onPressActiveTab
                  : styles.onPressInActiveTab
              }
            >
              <Text
                style={
                  tabName === TABNAME.VBDaXuLy
                    ? styles.titleActiveTab
                    : styles.titleInActiveTab
                }
              >
                {TABNAME.VBDaXuLy}
              </Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={{ marginTop: 10 }}>
            <SearchInput
              onChangeFilterText={onChangeFilterText}
              filterText={filterText}
            />
          </View>

        )}
      </View>
      {!arrayIsEmpty(dataVBDiState) ? (
        <FlatList
          contentContainerStyle={styles.containerFlatList}
          data={dataVBDiState}
          extraData={dataVBDiState}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor='#0054AE' />
          }
          renderItem={({ item }) => (
            funtionVBDi.key === 'VBDiTitle' ? <Item item={item} gotoDetail={gotoDetailPress} subSite={subSite} tabName={tabName} token={token} /> :
              <ItemOwn item={item} gotoDetail={gotoDetailPress} subSite={subSite} token={token} />
          )}
          keyExtractor={(item, index) => String(index)}
          showsVerticalScrollIndicator={false}
          onEndReachedThreshold={0.5}
          onEndReached={handleLoadmore}
          ListFooterComponent={renderFooter(isLoadingVBDi, refreshing, isLoadMoreVbDi, Offset)}
        />
      ) : (
        <NoDataView />
      )}

      <FilterModal
        onPressWaitProcesseDocx={onPressWaitProcesseDocx}
        onPressProcessedDocx={onPressProcessedDocx}
        onPressFilter={onPressFilter}
        confirmText={"Áp dụng"}
        refilterText={"Thiết lập lại"}
        modalVisible={visbleModalFilter}
        onConfirmModal={onConfirmModalPress}
        funtionVBDi={funtionVBDi}
        onReFilterModal={onReFilterModalPress}
        tinhTrang={tinhTrangState}
        onPressChooseType={onPressChooseType}
        onPressChooseLanhDao={onPressChooseLanhDao}
        onPressSearch={onPressSearch}
        onPressOpenCalendarPicker={onPressOpenCalendarPicker}
        startDate={startDate}
        endDate={endDate}
        lanhDaoNameSellectedState={lanhDaoNameSellectedState}
      />
      <CalendarPickerModal
        modalCalendarVisible={isOpenCalendarPicker}
        onDateChangeModal={onDateChangeModal}
        onCloseModal={onCloseModal}
        startDate={startDate}
        endDate={endDate}
        typeModal={typeModal}
        removeSelectedDate={removeSelectedDate}
        resetToday={resetToday}
      />
    </View>
  );
};

export default VBDiScreen;
