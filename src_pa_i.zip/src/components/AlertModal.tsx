import React, {FC} from 'react';
import {Modal, StyleSheet, Text, View, TouchableOpacity} from 'react-native';
import colors from 'themes/Colors';
import {dimensWidth, FontSize} from 'themes/const';

interface Props {
  modalVisible: Boolean;
  onConfirmModal: () => void;
  onCancelModal: () => void;
  alertTitle: String;
  confirmText: String;
  cancelText: String;
  alertContent: String;
  props: FC<Props>;
}
const AlertModal: FC<Props> = ({
  modalVisible,
  onConfirmModal,
  onCancelModal,
  alertTitle,
  alertContent,
  confirmText,
  cancelText,
  ...props
}: Props) => {
  return (
    <Modal
      transparent={true}
      visible={modalVisible}
      {...props}
      style={styles.centeredView}>
      <View style={styles.centeredView}>
        <View style={styles.modalView}>
          <Text style={styles.modalTitle}>{alertTitle}</Text>
          <Text style={styles.modalContent}>{alertContent}</Text>
          <View style={styles.flexDirection}>
            <View style={styles.button}>
              <TouchableOpacity onPress={onConfirmModal}>
                <Text style={styles.modalConfirm}>{confirmText}</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.stroke} />
            <View style={styles.button}>
              <TouchableOpacity onPress={onCancelModal}>
                <Text style={styles.modalCancel}>{cancelText}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalView: {
    backgroundColor: 'white',
    borderRadius: 8,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    width: dimensWidth(350),
  },
  button: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: FontSize.LARGE,
    color: colors.black26,
    fontWeight: '700',
    fontFamily: 'arial',
    textAlign: 'center',
    marginTop: dimensWidth(23),
  },
  modalContent: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: '400',
    fontFamily: 'arial',
    textAlign: 'center',
    marginTop: dimensWidth(1),
  },
  flexDirection: {
    borderTopWidth: 1,
    borderTopColor: '#E5E5E5',
    height: dimensWidth(50),
    flexDirection: 'row',
    marginTop: dimensWidth(23),
  },
  modalConfirm: {
    fontSize: FontSize.LARGE,
    color: colors.pictonBlue,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  modalCancel: {
    fontSize: FontSize.LARGE,
    color: colors.primary,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  stroke: {
    width: 1,
    backgroundColor: '#E5E5E5',
    marginVertical: dimensWidth(7.5),
  },
});

export default AlertModal;
