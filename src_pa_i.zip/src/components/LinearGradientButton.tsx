import React, {FC} from 'react';
import {
  StyleProp,
  Text,
  TextStyle,
  TouchableOpacity,
  ViewStyle,
  StyleSheet,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import colors from 'themes/Colors';

interface Props {
  onPress: () => void;
  styleBtn?: StyleProp<ViewStyle>;
  styleText?: StyleProp<TextStyle>;
  title?: String;
  colorList?: Array<string>;
  disabled?: Boolean;
}

const GeneralButton: FC<Props> = ({
  onPress,
  styleBtn,
  styleText,
  title,
  colorList,
  ...props
}: Props) => {
  return (
    <TouchableOpacity
      style={[styles.container, styleBtn]}
      onPress={onPress}
      {...props}>
      <LinearGradient colors={colorList} style={styles.linearGradient}>
        <Text style={[styles.buttonText, styleText]}>{title}</Text>
      </LinearGradient>
    </TouchableOpacity>
  );
};
var styles = StyleSheet.create({
  container: {
    height: 42,
    width: 350,
    borderRadius: 6,
  },
  linearGradient: {
    flex: 1,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 14,
    lineHeight: 16,
    textAlign: 'center',
    color: colors.white,
  },
});
export default GeneralButton;
