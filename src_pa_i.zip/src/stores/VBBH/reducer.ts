import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { RESONSE_STATUS_NONE, RESONSE_STATUS_SUCCESS } from 'themes/const'
import { Alert } from 'react-native'
import { BaseUrl } from 'services/api'
import { arrayIsEmpty } from '~/helpers/formater';

export const fetchVBDaBanHanhApi = createAsyncThunk(
    'vbBh/fetchVBDaBanHanhApi',
    async (payload: any) => {
        const {
            FromDate,
            ToDate,
            FilterText,
            Offset,
            subSite
        } = payload
        const reponseVBDaBanHanh = await axios.get(
            `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=VBBanHanh&Limit=10&Offset=${Offset}&IsCount=0&params=Limit,Offset,IsCount,ToDate,FromDate,FilterText&FilterText=${FilterText}&FromDate=${FromDate}&ToDate=${ToDate}`,
        );
        return {
            data: reponseVBDaBanHanh?.data?.data?.Data,
            Offset
        }
    },
);
export const fetchVBDaBanHanhDetailApi = createAsyncThunk(
    'vbBh/fetchVBDaBanHanhDetailApi',
    async ({ DocumentID, subSite }: any) => {
        //7541
        const resVBDaBanHanhDetailApi = await axios.get(
            `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBBanHanh&rid=${DocumentID}&vbaction=ById&cmt=1&task=1&actionPer=1`,
        );
        return resVBDaBanHanhDetailApi?.data?.data
    },
);
export const fetchVBDaBanHanhDSDaChiaSe = createAsyncThunk(
    'vbDi/fetchVBDaBanHanhDSDaChiaSe',
    async ({ DocumentID, subSite }: any) => {
        //7541
        const resVBDaBanHanhDSDaChiaSe = await axios.get(
            `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBBanHanh&vbaction=UserShared&rid=${DocumentID}`,
        );
        return resVBDaBanHanhDSDaChiaSe?.data?.data
    },
);
export const vbDaBanHanhChiaSeApi = createAsyncThunk(
    'vbBh/vbDaBanHanhChiaSeApi',
    async (payload: any) => {
        const { UserShared, Comment, DocumentID, subSite } = payload;
        const formData = {
            UserShared,
            Comment
        }
        const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBBanHanh&vbaction=submit&action=1&rid=${DocumentID}`
        const form = new FormData();
        form.append("data", JSON.stringify(formData));
        try {
            const response = await axios({
                method: 'post', url: url, data: form,
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });

            let isChiaSeVBBHSuccess = false;
            if (response?.data?.status === RESONSE_STATUS_NONE) {
                Alert.alert("Thông báo", response?.data?.mess?.Value, [
                    { text: "OK", onPress: () => { } },
                ]);
            }
            if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
                isChiaSeVBBHSuccess = true;
                alert('Chia sẻ thành công!!!')
            }
            return isChiaSeVBBHSuccess;
            // return response;

        } catch (error) {
            alert("error!", error);
            console.log('error', error);
        }

    }
);
export const fetchVBBHAttachFile = createAsyncThunk(
    'vbBh/fetchVBBHAttachFile',
    async ({ DocumentID, subSite }: any) => {
        const responseWaitProcessDoc = await axios.get(
            `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBBanHanh&vbaction=AttachFile&rid=${DocumentID}`,
        );
        return responseWaitProcessDoc?.data?.data;
    },
);
export const fetchNguoiXemVbBh = createAsyncThunk(
    'vbBh/fetchNguoiXemVbBh',
    async ({ itemId, subSite }: any) => {
        const fetchNguoiXemVbBh = await axios.get(
            `${BaseUrl}/${subSite}/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=VBBanHanhNguoiXem&params=Limit,Offset,ItemId&ItemId=${itemId}`,
        );
        return fetchNguoiXemVbBh?.data?.data;
    },
);
export const fetchThongTinLuanChuyenVbBh = createAsyncThunk(
    'vbBh/fetchThongTinLuanChuyenVbBh',
    async ({ itemId, subSite }: any) => {
        const responseThongTinLuanChuyenVbBh = await axios.get(
            `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=VBBanHanhWorkflowHistory&ItemId=${itemId}&params=ItemId`,
        );
        return responseThongTinLuanChuyenVbBh?.data?.data
    },
);
export const fetchThongTinLuanChuyenVbBhDonViNhan = createAsyncThunk(
    'vbBh/fetchThongTinLuanChuyenVbBhDonViNhan',
    async ({ itemId, subSite }: any) => {
        const responseThongTinLuanChuyenVbBhDonViNhan = await axios.get(
            `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBBanHanh&vbaction=WorkflowHistoryOtherDepartment&rid=${itemId}`,
        );
        return responseThongTinLuanChuyenVbBhDonViNhan?.data?.data
    },
);

const groupThongTinLuanChuyen = (data: any) => {
    let ret = []

    if (!arrayIsEmpty(data)) {
        const sorted = data.sort((a, b) => {
            const dateA = new Date(`${a.Created}`).valueOf();
            const dateB = new Date(`${b.Created}`).valueOf();
            if (dateA > dateB) {
                return 1; // return -1 here for DESC order
            }
            return -1 // return 1 here for DESC Order
        });

        let itemSup = {
            title: sorted[0].Position,
            data: []
        }
        ret.push(itemSup)

        for (let index = 0; index < sorted.length; index++) {
            const r = sorted[index];
            if (r.Position !== itemSup.title) {
                const a = []
                const r1 = { ...r, isLast: false }

                a.push(r1)

                itemSup = {
                    title: r1.Position,
                    data: a
                }
                ret.push(itemSup)
            } else {
                const r1 = { ...r, isLast: false }
                itemSup.data.push(r1)
            }
        }

        for (let index = 0; index < ret[ret.length - 1].data.length; index++) {
            const element = ret[ret.length - 1].data[index];
            element.isLast = true
        }
    }

    return ret
}

const initialState = {
    isLoadingVBBH: false,
    isLoadmoreVBBH: false,
    isGoBackVBBhScreen: false,
    dataVBDaBanHanh: [],
    dataVBDaBanHanhDetail: [],
    dataVBDaBanHanhDSDaChiaSe: [],
    isChiaSeVBBHSuccess: false,
    dataVBBHAttachFile: [],
    dataThongTinLuyenChuyenVbBhDonViNhanVbBh: [],
    dataThongTinLuyenChuyenVbBh: [],
    dataDanhSachNguoiXemVbBh: [],
    isRefreshing: true,
    isLoadingDetail: false
}
const vbBhSlice = createSlice({
    name: 'vbBhReducer',
    initialState,
    reducers: {
        resetVBBhScreen(state, action) {
            state.isGoBackVBBhScreen = false;
            state.isChiaSeVBBHSuccess = false;
        },
        resetVBBhDaBanHanhData(state, action) {
            state.dataVBDaBanHanh = [];
        },
        SetisLoadingDetail(state, action) {
            return {
                ...state,
                isLoadingDetail: action.payload
            }
        }
    },
    extraReducers: builder => {
        // --- Xử lý trong reducer với case pending / fulfilled / rejected ---
        builder
            .addCase(fetchVBDaBanHanhApi.pending, (state: any, action: any) => {
                state.isLoadingVBBH = true;
            })
        builder.addCase(fetchVBDaBanHanhApi.fulfilled, (state: any, action: any) => {
            state.dataVBDaBanHanh = action.payload.Offset !== 0 ? state.dataVBDaBanHanh.concat(action.payload.data) : action.payload.data;
            state.isLoadingVBBH = false;
            state.isRefreshing = false;
            state.isLoadmoreVBBH = action.payload.data.length !== 0
        });
        builder.addCase(fetchVBDaBanHanhApi.rejected, (state: any, action) => {
            state.isLoadingVBBH = false;
        });
        builder.addCase(fetchVBDaBanHanhDetailApi.pending, (state: any, action) => {
            state.isLoadingDetail = true;

        });
        builder.addCase(fetchVBDaBanHanhDetailApi.fulfilled, (state: any, action) => {
            state.dataVBDaBanHanhDetail = action.payload;
            state.isLoadingDetail = false;

        });
        builder.addCase(fetchVBDaBanHanhDSDaChiaSe.fulfilled, (state: any, action) => {
            state.dataVBDaBanHanhDSDaChiaSe = action.payload;
        });
        builder.addCase(vbDaBanHanhChiaSeApi.fulfilled, (state: any, action) => {
            state.isChiaSeVBBHSuccess = action.payload;
        });
        builder.addCase(fetchVBBHAttachFile.fulfilled, (state: any, action) => {
            state.dataVBBHAttachFile = action.payload;
        });
        builder.addCase(fetchNguoiXemVbBh.fulfilled, (state: any, action) => {
            state.dataDanhSachNguoiXemVbBh = action.payload;
        });
        builder.addCase(fetchThongTinLuanChuyenVbBh.fulfilled, (state: any, action) => {
            state.dataThongTinLuyenChuyenVbBh = groupThongTinLuanChuyen(action.payload);
        });
        builder.addCase(fetchThongTinLuanChuyenVbBhDonViNhan.fulfilled, (state: any, action) => {
            state.dataThongTinLuyenChuyenVbBhDonViNhanVbBh = action.payload;
        });
    },
});
export const { resetVBBhScreen, SetisLoadingDetail, resetVBBhDaBanHanhData } = vbBhSlice.actions;
const { reducer } = vbBhSlice;
export default reducer;
