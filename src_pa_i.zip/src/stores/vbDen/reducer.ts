import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { RESONSE_STATUS_NONE, RESONSE_STATUS_SUCCESS } from 'themes/const'
import { BaseUrl } from 'services/api'
import { arrayIsEmpty, isNullOrUndefined } from '~/helpers/formater';

export const fetchVBDenApi = createAsyncThunk(
    'vbDen/fetchVBDen',
    async (payload: any) => {
        const { status, TinhTrang, BanLanhDao, FromDate, ToDate, FilterText, Offset, funtionVBDen, subSite } = payload
        const reponseVBDen = await axios.get(
            `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=${funtionVBDen.key}&status=${status}&Limit=10&Offset=${Offset}&IsCount=0&params=Limit,Offset,IsCount,Status,TinhTrang,FromDate,ToDate,BanLanhDao,FilterText&TinhTrang=${TinhTrang}&BanLanhDao=${BanLanhDao}&FromDate=${FromDate}&ToDate=${ToDate}&FilterText=${FilterText}`,
        );
        return {
            data: reponseVBDen?.data?.data?.Data,
            Offset,
            totalRecord: reponseVBDen?.data?.data?.MoreInfo[0].totalRecord,
            status
        }
    },
);
export const vbDenChiaSeApi = createAsyncThunk(
    'vbDenChiaSe',
    async (payload: any) => {
        const { UserShared, Comment, DocumentID, subSite } = payload;
        const formData = {
            UserShared,
            Comment
        }
        const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=submit&action=64&rid=${DocumentID}`
        const form = new FormData();
        form.append("data", JSON.stringify(formData));
        try {
            const response = await axios({
                method: 'post', url: url, data: form,
                headers: {
                    'Content-Type': `multipart/form-data`,
                },
            });
            let isChiaSeVBDenDetailSuccess = false;
            if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
                isChiaSeVBDenDetailSuccess = true;
            }
            return isChiaSeVBDenDetailSuccess;
        } catch (error) {
            console.log('error', error);
        }

    }
);
export const vbDenPhanCongApi = createAsyncThunk(
    'vbDenPhanCongApi',
    async (payload: any) => {
        const { BanLanhDao, Comment, UserCC, AssignmentUser, AssignmentDept, DocumentID, subSite } = payload;

        const bodyFormData = {
            BanLanhDao, Comment, UserCC, AssignmentUser, AssignmentDept,
        };
        const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=submit&action=4&rid=${DocumentID}`
        const form = new FormData();
        form.append("data", JSON.stringify(bodyFormData));
        try {
            const response = await axios({
                method: 'post', url: url, data: form,
                headers: {
                    'Content-Type': `multipart/form-data`,
                },
            });
            let isGoBackVBDenScreen = false;
            if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
                isGoBackVBDenScreen = true
            }
            return isGoBackVBDenScreen;
        } catch (error) {
            console.log('error', error);
        }
    }
);
export const vbDenPhanCongLaiApi = createAsyncThunk(
    'vbDenPhanCongLai',
    async (payload: any) => {
        const {
            Comment,
            deleteDept,
            BanLanhDao,
            AssignmentUser,
            DocumentID,
            subSite
        } = payload;
        const bodyFormData = {
            Comment,
            DeleteDept: deleteDept,
            BanLanhDao,
            AssignmentUser,
        }

        const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=submit&action=8&rid=${DocumentID}`
        const form = new FormData();
        form.append("data", JSON.stringify(bodyFormData));
        try {
            const response = await axios({
                method: 'post', url: url, data: form,
                headers: {
                    'Content-Type': `multipart/form-data`,
                },
            });
            let isGoBackVBDenScreen = false;
            if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
                isGoBackVBDenScreen = true
            }
            return isGoBackVBDenScreen;

        } catch (error) {
            console.log('error', error);
        }
    }
);
export const vbDenThuHoiBoSungApi = createAsyncThunk(
    'vbDenThuHoiBoSung',
    async (payload: any) => {
        const {
            Comment,
            DeleteDept,
            AssignmentDept,
            DocumentID,
            IsBoSung,
            subSite
        } = payload;
        let bodyFormData = {}
        if (IsBoSung) {
            bodyFormData = {
                IsBoSung,
                Comment,
                AssignmentDept,
            }
        } else {
            bodyFormData = {
                IsBoSung,
                Comment,
                DeleteDept,
            }
        }
        const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=submit&action=128&rid=${DocumentID}`
        const form = new FormData();
        form.append("data", JSON.stringify(bodyFormData));
        try {
            const response = await axios({
                method: 'post', url: url, data: form,
                headers: {
                    'Content-Type': `multipart/form-data`,
                },
            });
            let isGoBackVBDenScreen = false
            if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
                isGoBackVBDenScreen = true
            }
            return isGoBackVBDenScreen;
        } catch (error) {
            console.log('error', error);
        }
    }
);
export const vbDenKetThucApi = createAsyncThunk(
    'vbDenKetThuc',
    async ({ Comment, DocumentID, subSite }: any) => {
        const bodyFormData = {
            Comment
        }
        const form = new FormData();
        form.append("data", JSON.stringify(bodyFormData));
        const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=submit&action=256&rid=${DocumentID}`
        try {
            const response = await axios({
                method: 'post', url: url, data: form,
                headers: {
                    'Content-Type': `multipart/form-data`,
                },
            });

            let isGoBackVBDenScreen = false;
            if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
                isGoBackVBDenScreen = true
            }
            return isGoBackVBDenScreen;
        } catch (error) {
            console.log('error', error);
        }
    }
);
export const vbChuyenPhanCongApi = createAsyncThunk(
    'vbChuyenPhanCong',
    async ({ Comment, DocumentID, subSite }: any) => {
        const bodyFormData = {
            Comment,
        }
        let isGoBackVBDenScreen = false;
        const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=submit&action=1&rid=${DocumentID}`
        const form = new FormData();
        form.append("data", JSON.stringify(bodyFormData));
        try {
            const response = await axios({
                method: 'post', url: url, data: form,
                headers: {
                    'Content-Type': `multipart/form-data`,
                },
            });
            if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
                isGoBackVBDenScreen = true
            }
            return isGoBackVBDenScreen;

        } catch (error) {
            console.log('error', error);
        }
        return true
    }
);
export const vbChuyenXuLyTrinhLanhDaoApi = createAsyncThunk(
    'vbDenChuyenXuLyTrinhLanhDao',
    async (payload: any) => {
        const { DocumentID, BanLanhDao, Comment, UserCC, subSite } = payload;
        const bodyFormData = {
            BanLanhDao,
            Comment,
            UserCC
        }
        let isGoBackVBDenScreen = false;
        const fakeID = '9672';
        const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=submit&action=2&rid=${DocumentID}`
        const form = new FormData();
        form.append("data", JSON.stringify(bodyFormData));
        try {
            const response = await axios({
                method: 'post', url: url, data: form,
                headers: {
                    'Content-Type': `multipart/form-data`,
                },
            });
            if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
                isGoBackVBDenScreen = true
            }
            return isGoBackVBDenScreen;

        } catch (error) {
            console.log('error', error);
        }
    }
);
export const fetchDanhSachDaChiaSeVbDen = createAsyncThunk(
    'home/fetchDanhSachDaChiaSeVbDen',
    async ({ DocumentID, subSite }: any) => {
        const responseDanhSachDaChiaSeVbDen = await axios.get(
            `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=UserShared&rid=${DocumentID}
        `,
        );
        return responseDanhSachDaChiaSeVbDen?.data?.data
    },
);
export const fetchWaitProcessDocxDetail = createAsyncThunk(
    'home/fetchWaitProcessDocxDetail',
    async ({ DocumentID, subSite }: any) => {
        const responseWaitProcessDocDetail = await axios.get(
            `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=ById&rid=${DocumentID}&cmt=1&actionPer=1&department=1&task=1`,
        );
        return responseWaitProcessDocDetail?.data?.data;
    },
);
export const fetchWaitProcessDocxAttachFile = createAsyncThunk(
    'home/fetchWaitProcessDocxAttachFile',
    async ({ DocumentID, subSite }: any) => {
        const responseWaitProcessDoc = await axios.get(
            `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=AttachFile&rid=${DocumentID}`,
        );
        return responseWaitProcessDoc?.data?.data;
    },
);

export const checkIsEnableCollaboratorAssignment = createAsyncThunk(
    'home/IsEnableCollaboratorAssignment', async (subSite: any) => {
        const res = await axios.get(`${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=SettingByKey&params=SettingKey&SettingKey=IsEnableCollaboratorAssignment`)
        return res?.data?.data;
    }
)
export const postReadVanBan = createAsyncThunk(
    'home/postReadVanBan',
    async ({ DocumentID, ListName, subSite }: any) => {
        const postReadVanBan = await axios.get(
            `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=NotifyAsRead&rid=${DocumentID}&listname=${ListName}`,
        );
        return postReadVanBan?.data?.data;
    },
);
export const fetchDanhSachVBDenTheoMuc = createAsyncThunk(
    'home/fetchDanhSachVBDenTheoMuc',
    async (subSite: any) => {
        const fetchDanhSachVBDenTheoMuc = await axios.get(
            `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=VBDenDaXuLy&Limit=10&Offset=0&IsCount=0&params=Limit,Offset,IsCount`,
        );
        return fetchDanhSachVBDenTheoMuc?.data?.data?.Data;
    },
);
const initialState = {
    isLoadingVBDen: false,
    isGoBackVBDenScreen: false,
    isChiaSeVBDenDetailSuccess: false,
    dataVBDen: [],
    totalRecord: 0,
    IsEnableCollaboratorAssignment: false,
    isLoadMoreVbDen: false,
    dataDanhSachDaChiaSeVbDen: [],
    totalRecordVbDen: 0,
    dataWaitProcessDocxDetail: {},
    dataWaitProcessDocxAttachFile: [],
    dataDanhSachVBDenTheoMuc: []
}
const vbDenSlice = createSlice({
    name: 'vbDenReducer',
    initialState,
    reducers: {
        goBackWaitProcessDocxScreen(state, action) {
            state.isGoBackVBDenScreen = false;
            state.isChiaSeVBDenDetailSuccess = false;
        },
        SetisLoadingVBDen(state, action) {
            return {
                ...state,
                isLoadingVBDen: action.payload
            }
        }
    },
    extraReducers: builder => {
        // --- Xử lý trong reducer với case pending / fulfilled / rejected ---
        builder
            .addCase(fetchVBDenApi.pending, (state: any) => {
                state.isLoadingVBDen = true;
            })
        builder.addCase(fetchVBDenApi.fulfilled, (state: any, action) => {
            state.dataVBDen = action.payload.Offset !== 0 ? state.dataVBDen.concat(action.payload.data) : action.payload.data;
            state.isLoadMoreVbDen = action.payload.data.length !== 0
            state.totalRecordVbDen = action.payload.status == 0 ? action.payload?.totalRecord : state.totalRecordVbDen
            state.totalRecord = action.payload.totalRecord
            state.isLoadingVBDen = false;
        });
        builder.addCase(fetchVBDenApi.rejected, (state: any, action) => {
            state.isLoadingVBDen = false;
        });
        builder.addCase(fetchWaitProcessDocxDetail.pending, (state: any, action: any) => {
            state.dataWaitProcessDocxDetail = [];
            state.isLoadingVBDen = true
        });
        builder.addCase(fetchWaitProcessDocxDetail.fulfilled, (state: any, action: any) => {
            state.dataWaitProcessDocxDetail = action.payload;
            state.isLoadingVBDen = false
        });
        builder.addCase(fetchWaitProcessDocxDetail.rejected, (state: any, action: any) => {
            state.isLoadingVBDen = false
        });
        builder.addCase(fetchWaitProcessDocxAttachFile.fulfilled, (state: any, action) => {
            state.dataWaitProcessDocxAttachFile = action.payload;
        });
        builder.addCase(checkIsEnableCollaboratorAssignment.fulfilled, (state: any, action) => {
            if(!isNullOrUndefined(action.payload) && !arrayIsEmpty(action.payload)) {
                state.IsEnableCollaboratorAssignment = action.payload[0].VALUE === "1"
            } else {
                state.IsEnableCollaboratorAssignment = false
            }
        });
        builder.addCase(fetchDanhSachVBDenTheoMuc.fulfilled, (state: any, action) => {
            state.dataDanhSachVBDenTheoMuc = action.payload;
        });
        builder
            .addCase(vbDenChiaSeApi.pending, (state: any) => {
                state.isLoadingVBDen = true;
            })
        builder.addCase(vbDenChiaSeApi.fulfilled, (state: any, action) => {
            state.isLoadingVBDen = false;
            state.isChiaSeVBDenDetailSuccess = action.payload
        });
        builder.addCase(vbDenChiaSeApi.rejected, (state: any, action) => {
            state.isLoadingVBDen = false;
        });
        builder
            .addCase(vbDenKetThucApi.pending, (state: any) => {
                state.isLoadingVBDen = true;
            })
        builder.addCase(vbDenKetThucApi.fulfilled, (state: any, action) => {
            state.isLoadingVBDen = false;
            state.isGoBackVBDenScreen = action.payload;
        });
        builder.addCase(vbDenKetThucApi.rejected, (state: any, action) => {
            state.isLoadingVBDen = false;
        });
        builder
            .addCase(vbDenPhanCongApi.pending, (state: any) => {
                state.isLoadingVBDen = true;
            })
        builder.addCase(vbDenPhanCongApi.fulfilled, (state: any, action) => {
            state.isLoadingVBDen = false;
            state.isGoBackVBDenScreen = action.payload;
        });
        builder.addCase(vbDenPhanCongApi.rejected, (state: any, action) => {
            state.isLoadingVBDen = false;
        });
        builder
            .addCase(vbChuyenXuLyTrinhLanhDaoApi.pending, (state: any) => {
                state.isLoadingVBDen = true;
            })
        builder.addCase(vbChuyenXuLyTrinhLanhDaoApi.fulfilled, (state: any, action) => {
            state.isLoadingVBDen = false;
            state.isGoBackVBDenScreen = action.payload
        });
        builder.addCase(vbChuyenXuLyTrinhLanhDaoApi.rejected, (state: any, action) => {
            state.isLoadingVBDen = false;
        });
        builder
            .addCase(vbDenPhanCongLaiApi.pending, (state: any) => {
                state.isLoadingVBDen = true;
            })
        builder.addCase(vbDenPhanCongLaiApi.fulfilled, (state: any, action) => {
            state.isLoadingVBDen = false;
            state.isGoBackVBDenScreen = action.payload
        });
        builder.addCase(vbDenPhanCongLaiApi.rejected, (state: any, action) => {
            state.isLoadingVBDen = false;
        });
        builder
            .addCase(vbDenThuHoiBoSungApi.pending, (state: any) => {
                state.isLoadingVBDen = true;
            })
        builder.addCase(vbDenThuHoiBoSungApi.fulfilled, (state: any, action) => {
            state.isLoadingVBDen = false;
            state.isGoBackVBDenScreen = action.payload
        });
        builder.addCase(vbDenThuHoiBoSungApi.rejected, (state: any, action) => {
            state.isLoadingVBDen = false;
        });
        builder
            .addCase(vbChuyenPhanCongApi.pending, (state: any) => {
                state.isLoadingVBDen = true;
            })
        builder.addCase(vbChuyenPhanCongApi.fulfilled, (state: any, action) => {
            state.isLoadingVBDen = false;
            state.isGoBackVBDenScreen = action.payload
        });
        builder.addCase(vbChuyenPhanCongApi.rejected, (state: any, action) => {
            state.isLoadingVBDen = false;
        });
        builder.addCase(fetchDanhSachDaChiaSeVbDen.fulfilled, (state: any, action) => {
            state.dataDanhSachDaChiaSeVbDen = action.payload;
        });
    },
});
export const { goBackWaitProcessDocxScreen, SetisLoadingVBDen } = vbDenSlice.actions;
const { reducer } = vbDenSlice;
export default reducer;
