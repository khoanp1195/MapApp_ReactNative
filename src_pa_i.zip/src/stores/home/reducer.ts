import {
  createAsyncThunk,
  createEntityAdapter,
  createSlice,
} from '@reduxjs/toolkit';
import axios from 'axios';
import { BaseUrl } from 'services/api'
import { arrayIsEmpty, isNullOrUndefined } from '~/helpers/formater';
interface UserData {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
  avatar: string;
}

export const fetchCurrentUsers = createAsyncThunk(
  'home/fetchCurrentUsers',
  async ({ subSite, deviceInfo }: any) => {
    const form = new FormData();
    form.append("data", JSON.stringify(deviceInfo));
    const res = await axios({
      method: 'post', url: `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=CurrentUser`, data: form,
      headers: {
        'Content-Type': `multipart/form-data`,
      },
    });

    return res?.data?.data;
  },
);
export const fetchNotificationUsers = createAsyncThunk(
  'home/fetchNotificationUsers',
  async (subSite: any) => {

    const responseNotifyStatus = await axios.get(
      `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=GetCountNotify&status=0&params=Status`,
    );
    return responseNotifyStatus?.data?.data;
  },
);
interface fetchWaitProcessDocxType {
  status: string;
  FromDate: string;
  ToDate: string;
  FilterText: string;
  DocumentType: string;
  Offset: number;
}
export const fetchWaitProcessDocx = createAsyncThunk(
  'home/fetchWaitProcessDocx',
  async (payload: any) => {
    const { status, FromDate, ToDate, FilterText, DocumentType, Offset, subSite } = payload;
    const responseWaitProcessDoc = await axios.get(
      `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=HomeNotify&status=${status}&Limit=10&Offset=${Offset}&IsCount=0&params=Limit,Offset,IsCount,Status,FromDate,ToDate,FilterText,DocumentType&FromDate=${FromDate}&ToDate=${ToDate}&FilterText=${FilterText}&DocumentType=${DocumentType}`,
    );
    if (isNullOrUndefined(responseWaitProcessDoc?.data?.data)) {
      return {
        data: [],
        Offset: 0,
        totalRecord: 0,
        status: 0
      }
    }
    return {
      data: responseWaitProcessDoc?.data?.data?.Data,
      totalRecord: responseWaitProcessDoc?.data?.data.MoreInfo[0]?.totalRecord,
      Offset,
      totalRecord: responseWaitProcessDoc?.data?.data?.MoreInfo[0].totalRecord,
      status
    }
  },
);
export const fetchVBPhoiHop = createAsyncThunk(
  'home/fetchVBPhoiHop',
  async ({ status, FromDate, ToDate, FilterText, DocumentType, Offset, subSite }: any) => {
    const responseVBPhoiHop = await axios.get(
      `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=HomeCombination&status=${status}&Limit=10&Offset=${Offset}&IsCount=0&params=Limit,Offset,IsCount,Status,FromDate,ToDate,FilterText,DocumentType&FromDate=${FromDate}&ToDate=${ToDate}&FilterText=${FilterText}&DocumentType=${DocumentType}`,
    );
    if (isNullOrUndefined(responseVBPhoiHop?.data?.data)) {
      return {
        data: [],
        Offset: 0,
        totalRecord: 0,
        status: 0
      }
    }
    return {
      data: responseVBPhoiHop?.data?.data?.Data,
      Offset,
      totalRecord: responseVBPhoiHop?.data?.data?.MoreInfo[0].totalRecord,
      status
    }
  },
);
export const fetchVBThongBao = createAsyncThunk(
  'home/fetchVBThongBao',
  async ({ status, FromDate, ToDate, FilterText, DocumentType, Offset, subSite }: any) => {
    const responseVBThongBao = await axios.get(
      `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=Notification&status=${status}&Limit=10&Offset=${Offset}&IsCount=0&params=Limit,Offset,IsCount,Status,FromDate,ToDate,FilterText,DocumentType&FromDate=${FromDate}&ToDate=${ToDate}&FilterText=${FilterText}&DocumentType=${DocumentType}`,
    );
    if (isNullOrUndefined(responseVBThongBao?.data?.data)) {
      return {
        data: [],
        Offset: 0,
        totalRecord: 0,
        status: 0
      }
    }
    return {
      data: responseVBThongBao?.data?.data?.Data,
      Offset,
      totalRecord: responseVBThongBao?.data?.data?.MoreInfo[0].totalRecord,
      status
    }
  },
);

export const fetchBanLanhDao = createAsyncThunk(
  'home/fetchBanLanhDao',
  async (subSite: any) => {
    const fetchBanLanhDao = await axios.get(
      `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetSPList&listname=Ban lãnh đạo&cols=["ID","Title","LanhDao","DonVi","Orders"]`,
    );
    return fetchBanLanhDao?.data?.data;
  },
);
export const fetchToChucPhanCong = createAsyncThunk(
  'home/ToChucPhanCong',
  async (subSite: any) => {
    const res = await axios.get(
      `${BaseUrl}/${subSite}/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetSPList&listname=Đơn vị&cols=["ID","Title", "MultipleManager", "LanhDao","IsRoot","URL","Nhom","MaDonVi","DeptStatus","Status","ParentDept","Manager"]`,
    );
    return res?.data?.data;
  },
);
export const fetchUsersAndGroup = createAsyncThunk(
  'home/fetchUsersAndGroup',
  async (subSite: any) => {
    const fetchUsersAndGroup = await axios.get(post
      `${BaseUrl}/${subSite}/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=UserGroup&params=Limit,Offset,IsCount,Status,BeanName,Modified`,
    );
    return fetchUsersAndGroup?.data?.data;
  },
);
export const fetchPhongBanPhanCong = createAsyncThunk(
  'home/fetchPhongBanPhanCong',
  async (subSite: any) => {
    const fetchPhongBanPhanCong = await axios.get(
      `${BaseUrl}/${subSite}/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetSPList&listname=Đơn vị&cols=["ID","Title", "MultipleManager", "LanhDao","IsRoot","URL","Nhom","MaDonVi","DeptStatus","Status","ParentDept","Manager"]`,
    );
    return fetchPhongBanPhanCong?.data?.data;
  },
);

export const fetchCheckUserInGroup = createAsyncThunk(
  'data/fetchCheckUserInGroup', async ({ groupName, subSite }: any) => {
    const res = await axios.get(`${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GroupName&groupname=${groupName}`)
    return res.data.data
  }
)

export const fetchSettings = createAsyncThunk(
  'home/fetchSettings', async (subSite: any) => {
    const res = await axios.get(`${BaseUrl}/${subSite}/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=MasterData&params=BeanName,Modified&BeanName=beansetting`)
    return res.data.data
  }
)

export const fetchVbDenNguoiXem = createAsyncThunk(
  'home/fetchVbDenNguoiXem',
  async ({ itemId, subSite }: any) => {
    const fetchVbDenNguoiXem = await axios.get(
      `${BaseUrl}/${subSite}/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=VBDenNguoiXem&params=Limit,Offset,ItemId&ItemId=${itemId}`,
    );
    return fetchVbDenNguoiXem?.data?.data;
  },
);
export const fetchThongTinLuanChuyen = createAsyncThunk(
  'home/fetchThongTinLuanChuyen',
  async ({ itemId, subSite }: any) => {
    const responseThongTinLuanChuyen = await axios.get(
      `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=VBDenWorkflowHistory&ItemId=${itemId}&params=ItemId`,
    );
    return responseThongTinLuanChuyen?.data?.data
  },
);
export const fetchThongTinLuanChuyenDonViNhan = createAsyncThunk(
  'home/fetchThongTinLuanChuyenDonViNhan',
  async ({ itemId, subSite }: any) => {
    const responseThongTinLuanChuyenDonViNhan = await axios.get(
      `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDen&vbaction=WorkflowHistoryOtherDepartment&rid=${itemId}`,
    );
    return responseThongTinLuanChuyenDonViNhan?.data?.data
  },
);

export const fetchTaskVBDen = createAsyncThunk(
  'home/fetchTaskVBDen',
  async ({ taskID, subSite }: any) => {
    const responseDanhSachTaskVBDen = await axios.get(
      `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetTaskVBDen&taskaction=ById&rid=${taskID}
      `,
    );
    return responseDanhSachTaskVBDen?.data?.data
  },
);

const groupThongTinLuanChuyen = (data: any) => {
  let ret = []

  if (!arrayIsEmpty(data)) {
    const sorted = data.sort((a, b) => {
      const dateA = new Date(`${a.Created}`).valueOf();
      const dateB = new Date(`${b.Created}`).valueOf();
      if (dateA > dateB) {
        return 1; // return -1 here for DESC order
      }
      return -1 // return 1 here for DESC Order
    });

    let itemSup = {
      title: sorted[0].Position,
      data: []
    }
    ret.push(itemSup)

    for (let index = 0; index < sorted.length; index++) {
      const r = sorted[index];
      if (r.Position !== itemSup.title) {
        const a = []
        const r1 = { ...r, isLast: false }

        a.push(r1)

        itemSup = {
          title: r1.Position,
          data: a
        }
        ret.push(itemSup)
      } else {
        const r1 = { ...r, isLast: false }
        itemSup.data.push(r1)
      }
    }

    for (let index = 0; index < ret[ret.length - 1].data.length; index++) {
      const element = ret[ret.length - 1].data[index];
      element.isLast = true
    }
  }

  return ret
}

export const usersAdapter = createEntityAdapter<UserData>();

const usersSlice = createSlice({
  name: 'home',
  initialState: usersAdapter.getInitialState({
    loading: false,
    dataCurrentUsers: [],
    dataNotificationUsers: [],
    dataWaitProcessDocx: [],
    dataVBPhoiHop: [],
    dataVBThongBao: [],
    totalRecord: 0,
    isLoadMoreWaitProcessDocx: true,
    isLoadMoreVBPhoiHop: true,
    isLoadMoreVBThongBao: true,
    dataBanLanhDao: [],
    dataPhongBan: [],
    dataDanhSachVbDenNguoiXem: [],
    dataThongTinLuyenChuyen: [],
    dataThongTinLuyenChuyenDonViNhan: [],
    dataUsersAndGroup: [],
    dataToChucPhanCong: [],
    dataTaskVBDen: {},
    totalRecordWaitProcesssDocx: 0,
    totalRecordThongBao: 0,
    totalRecordVBPhoiHop: 0,
    isRefreshing: true,
    IsGroupAssignmentFull: false,
    dataSettings: [],
    isChangeSite: false,
    isRefreshingDashboard: false
  }),
  reducers: {
    setRefreshingStore(state, action) {
      return {
        ...state,
        isRefreshing: action.payload
      }
    },
    setRefreshingDashboard(state, action) {
      return {
        ...state,
        isRefreshingDashboard: action.payload
      }
    }
  },
  extraReducers: builder => {

    builder.addCase(fetchCurrentUsers.fulfilled, (state: any, action) => {
      state.dataCurrentUsers = action.payload;
    });
    builder.addCase(fetchNotificationUsers.fulfilled, (state: any, action) => {
      state.dataNotificationUsers = action.payload;
      state.isRefreshingDashboard = false
    });
    builder.addCase(fetchWaitProcessDocx.pending, (state, action: any) => {
      state.loading = true;
    })
    builder.addCase(fetchWaitProcessDocx.fulfilled, (state: any, action: any) => {
      state.dataWaitProcessDocx = action.payload.Offset !== 0 ? state.dataWaitProcessDocx.concat(action.payload.data) : action.payload.data;
      state.isLoadMoreWaitProcessDocx = action.payload.data.length !== 0
      state.loading = false;
      state.isRefreshing = false;
      state.totalRecordWaitProcesssDocx = action.payload.status == 0 ? action.payload?.totalRecord : state.totalRecordWaitProcesssDocx
    });
    builder.addCase(fetchWaitProcessDocx.rejected, (state: any, action) => {
      state.loading = false;
    });

    builder.addCase(fetchVBPhoiHop.pending, (state: any, action: any) => {
      state.loading = true
    });
    builder.addCase(fetchVBPhoiHop.fulfilled, (state: any, action) => {
      state.dataVBPhoiHop = action.payload.Offset !== 0 ? state.dataVBPhoiHop.concat(action.payload.data) : action.payload.data;
      state.isLoadMoreVBPhoiHop = action.payload.data.length !== 0
      state.loading = false;
      state.isRefreshing = false;
      state.totalRecordVBPhoiHop = action.payload.status == 0 ? action.payload?.totalRecord : state.totalRecordVBPhoiHop
    });
    builder.addCase(fetchVBPhoiHop.rejected, (state: any, action) => {
      state.loading = false;
    });
    
    builder.addCase(fetchVBThongBao.pending, (state: any, action: any) => {
      state.loading = true
    });
    builder.addCase(fetchVBThongBao.fulfilled, (state: any, action: any) => {
      state.dataVBThongBao = action.payload.Offset !== 0 ? state.dataVBThongBao.concat(action.payload.data) : action.payload.data;
      state.isLoadMoreVBThongBao = action.payload.data.length !== 0
      state.loading = false;
      state.isRefreshing = false;
      state.totalRecordThongBao = action.payload.status == 0 ? action.payload?.totalRecord : state.totalRecordThongBao
    });
    builder.addCase(fetchVBThongBao.rejected, (state: any, action) => {
      state.loading = false;
    });
    builder.addCase(fetchBanLanhDao.fulfilled, (state: any, action) => {
      state.dataBanLanhDao = action.payload;
    });
    builder.addCase(fetchSettings.fulfilled, (state: any, action) => {
      state.dataSettings = action.payload;
    });
    builder.addCase(fetchCheckUserInGroup.fulfilled, (state: any, action) => {
      state.IsGroupAssignmentFull = action.payload;
    });
    builder.addCase(fetchToChucPhanCong.fulfilled, (state: any, action) => {
      state.dataToChucPhanCong = action.payload;
    });
    builder.addCase(fetchUsersAndGroup.fulfilled, (state: any, action) => {
      state.dataUsersAndGroup = action.payload;
    });
    builder.addCase(fetchPhongBanPhanCong.fulfilled, (state: any, action) => {
      state.dataPhongBan = action.payload;
    });
    builder.addCase(fetchVbDenNguoiXem.fulfilled, (state: any, action) => {
      state.dataDanhSachVbDenNguoiXem = action.payload;
    });
    builder.addCase(fetchThongTinLuanChuyen.fulfilled, (state: any, action) => {
      state.dataThongTinLuyenChuyen = groupThongTinLuanChuyen(action.payload);
    });
    builder.addCase(fetchThongTinLuanChuyenDonViNhan.fulfilled, (state: any, action) => {
      state.dataThongTinLuyenChuyenDonViNhan = action.payload;
    });
    builder.addCase(fetchTaskVBDen.fulfilled, (state: any, action) => {
      state.dataTaskVBDen = action.payload;
    });
  },
});

export const { setRefreshingStore } = usersSlice.actions;
export default usersSlice.reducer;
