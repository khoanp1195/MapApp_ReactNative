import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { Alert } from 'react-native'
import { RESONSE_STATUS_NONE, RESONSE_STATUS_SUCCESS } from 'themes/const'
import { BaseUrl } from 'services/api'
import { EnumNguoiGiaoViecVBDen } from '~/screens/VBDen/VBDenType';
export const NguoiGiaoViecTaskVBDenApi = createAsyncThunk(
    'taskVBDen/NguoiGiaoViecTaskVBDenApi',
    async (payload: any) => {
        const { taskID, TrangThai, YKienChiDao, ThoiHanGiaiQuyet, NguoiXuLy, isTraoDoiLai, subSite } = payload;
        const bodyFormData = {
            TrangThai, YKienChiDao, ThoiHanGiaiQuyet, NguoiXuLy
        }
        const taskVbDenAction = isTraoDoiLai ? EnumNguoiGiaoViecVBDen.TraoDoiLai : EnumNguoiGiaoViecVBDen.Luu
        const alertMessage = isTraoDoiLai ? 'Trao đổi lại thành công!!!' : 'Lưu thành công!!!'
        let isGoBackWaitProcessDocxDetailScreen = false;
        const fakeID = '9672';
        const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetTaskVBDen&taskaction=submit&rid=${taskID}&action=${taskVbDenAction}`
        const form = new FormData();
        form.append("data", JSON.stringify(bodyFormData));
        try {
            const response = await axios({
                method: 'post', url: url, data: form,
                headers: {
                    'Content-Type': `multipart/form-data`,
                },
            });
            if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
                isGoBackWaitProcessDocxDetailScreen = true
            }
            return isGoBackWaitProcessDocxDetailScreen;

        } catch (error) {
            console.log('error', error);
        }
    }
);
export const NguoiXuLyTaskVBDenApi = createAsyncThunk(
    'taskVBDen/NguoiXuLyTaskVBDenApi',
    async (payload: any) => {
        const { taskID, TrangThai, YKienCuaNguoiGiaiQuyet, TienDo, isTraoDoiLai, subSite } = payload;
        const bodyFormData = {
            TrangThai, YKienCuaNguoiGiaiQuyet, TienDo
        }
        const taskVbDenAction = isTraoDoiLai ? EnumNguoiGiaoViecVBDen.TraoDoiLai : EnumNguoiGiaoViecVBDen.Luu
        const alertMessage = isTraoDoiLai ? 'Trao đổi lại thành công!!!' : 'Lưu thành công!!!'

        let isGoBackWaitProcessDocxDetailScreen = false;
        const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetTaskVBDen&taskaction=submit&rid=${taskID}&action=${taskVbDenAction}`
        const form = new FormData();
        form.append("data", JSON.stringify(bodyFormData));
        try {
            const response = await axios({
                method: 'post', url: url, data: form,
                headers: {
                    'Content-Type': `multipart/form-data`,
                },
            });
            if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
                isGoBackWaitProcessDocxDetailScreen = true
            }
            return isGoBackWaitProcessDocxDetailScreen;

        } catch (error) {
            console.log('error', error);
        }
    }
);
export const fetchIsGroupAssignmentDept = createAsyncThunk(
    'taskVBDen/fetchIsGroupAssignmentDept',
    async ({taskID, subSite}: any) => {
        const responseIsGroupAssignmentDept = await axios.get(
            `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetTaskVBDen&taskaction=IsGroupAssignmentDept&rid=${taskID}`,
        );

        return responseIsGroupAssignmentDept?.data?.data;
    },
);
export const taskVbDenNguoiXuLyKetThucApi = createAsyncThunk(
    'taskVbDenNguoiXuLyKetThucApi',
    async ({ YKienCuaNguoiGiaiQuyet, taskID, subSite }: any) => {
        const bodyFormData = {
            YKienCuaNguoiGiaiQuyet,
        }
        const form = new FormData();
        form.append("data", JSON.stringify(bodyFormData));
        const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetTaskVBDen&taskaction=submit&rid=${taskID}&action=32`
        try {
            const response = await axios({
                method: 'post', url: url, data: form,
                headers: {
                    'Content-Type': `multipart/form-data`,
                },
            });
            let isGoBackWaitProcessDocxDetailScreen = false;
            if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
                isGoBackWaitProcessDocxDetailScreen = true
            }
            return isGoBackWaitProcessDocxDetailScreen;
        } catch (error) {
            console.log('error', error);
        }
    }
);
export const taskVbDenPhanCongApi = createAsyncThunk(
    'taskVbDenPhanCongApi',
    async (payload: any) => {
        const { BanLanhDao, Comment, UserCC, AssignmentUser, AssignmentDept, taskID, subSite } = payload;

        const bodyFormData = {
            BanLanhDao, Comment, UserCC, AssignmentUser, AssignmentDept,
        };
        const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetTaskVBDen&taskaction=submit&rid=${taskID}&action=2`
        const form = new FormData();
        form.append("data", JSON.stringify(bodyFormData));
        try {
            const response = await axios({
                method: 'post', url: url, data: form,
                headers: {
                    'Content-Type': `multipart/form-data`,
                },
            });
            let isGoBackWaitProcessDocxDetailScreen = false;
            if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
                isGoBackWaitProcessDocxDetailScreen = true
            }
            return isGoBackWaitProcessDocxDetailScreen;
        } catch (error) {
            console.log('error', error);
        }
    }
);
const taskVBDenSlice = createSlice({
    name: 'taskVBDenRequest',
    initialState: {
        isLoading: false,
        isGoBackWaitProcessDocxDetailScreen: false,
        IsGroupAssignmentDept: false,
    },
    reducers: {
        goBackWaitProcessDocxDetailScreen(state, action) {
            state.isGoBackWaitProcessDocxDetailScreen = false;
            state.IsGroupAssignmentDept = false
        },
    },
    extraReducers: builder => {
        builder
            .addCase(NguoiGiaoViecTaskVBDenApi.pending, (state: any) => {
                state.isLoading = true;
            })
            .addCase(NguoiGiaoViecTaskVBDenApi.fulfilled, (state: any, action) => {
                state.isLoading = false;
                state.isGoBackWaitProcessDocxDetailScreen = action.payload
            })
            .addCase(NguoiGiaoViecTaskVBDenApi.rejected, (state: any, action) => {
                state.isLoading = false;
            });
        builder
            .addCase(NguoiXuLyTaskVBDenApi.pending, (state: any) => {
                state.isLoading = true;
            })
            .addCase(NguoiXuLyTaskVBDenApi.fulfilled, (state: any, action) => {
                state.isLoading = false;
                state.isGoBackWaitProcessDocxDetailScreen = action.payload
            })
            .addCase(NguoiXuLyTaskVBDenApi.rejected, (state: any, action) => {
                state.isLoading = false;
            });
        builder
            .addCase(fetchIsGroupAssignmentDept.fulfilled, (state: any, action) => {
                state.isLoading = false;
                state.IsGroupAssignmentDept = action.payload
            })
            .addCase(fetchIsGroupAssignmentDept.rejected, (state: any, action) => {
                state.isLoading = false;
            });
        builder
            .addCase(taskVbDenNguoiXuLyKetThucApi.fulfilled, (state: any, action) => {
                state.isGoBackWaitProcessDocxDetailScreen = action.payload
            })
        builder
            .addCase(taskVbDenPhanCongApi.fulfilled, (state: any, action) => {
                state.isGoBackWaitProcessDocxDetailScreen = action.payload
            })
    }
});
export const { goBackWaitProcessDocxDetailScreen } = taskVBDenSlice.actions;
const { reducer } = taskVBDenSlice;
export default reducer;
