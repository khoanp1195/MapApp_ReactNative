import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { RESONSE_STATUS_NONE, RESONSE_STATUS_SUCCESS, funtionVBDiData } from 'themes/const'
import { Alert } from 'react-native'
import { BaseUrl } from 'services/api'
import { arrayIsEmpty, isNullOrUndefined } from '~/helpers/formater';

export const fetchVBDiApi = createAsyncThunk(
    'vbDi/fetchVBDi',
    async (payload: any) => {
        const {
            status,
            TinhTrang,
            FromDate,
            ToDate,
            FilterText,
            Offset,
            funtionVBDi,
            subSite
        } = payload
        
        
        let reponseVBDi;
        if (funtionVBDi === funtionVBDiData.VBDiTitle) {
            reponseVBDi = await axios.get(
                `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=${funtionVBDi.key}&Limit=10&Offset=${Offset}&IsCount=0&params=Limit,Offset,IsCount,Status,TinhTrang,FromDate,ToDate,FilterText&Status=${status}&TinhTrang=${TinhTrang}&FromDate=${FromDate}&ToDate=${ToDate}&FilterText=${FilterText}`,
            );
        } else {
            reponseVBDi = await axios.get(
                `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&viewname=${funtionVBDi.key}&Limit=10&Offset=${Offset}&TinhTrang=${TinhTrang}&FromDate=${FromDate}&ToDate=${ToDate}&FilterText=${FilterText}`,
            );
        }

        if (isNullOrUndefined(reponseVBDi?.data?.data)) {
            return {
                data: [],
                Offset: 0,
                totalRecord: 0,
                status: 0
            }
        }

        return {
            data: reponseVBDi?.data?.data?.Data,
            Offset: Offset,
            totalRecord: funtionVBDi.key === 'VBDiTitle' ? reponseVBDi?.data?.data?.MoreInfo[0].totalRecord : reponseVBDi?.data?.data?.totalRecord,
            status
        }
    },
);

export const fetchVBDiDetailApi = createAsyncThunk(
    'vbDi/fetchVBDiDetailApi',
    async ({ DocumentID, subSite }: any) => {
        const resVBDiDetailApi = await axios.get(
            `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&rid=${DocumentID}&vbaction=ById&cmt=1&actionPer=1`,
        );

        return resVBDiDetailApi?.data?.data
    },
);
export const fetchVBDiDSDaChiaSe = createAsyncThunk(
    'vbDi/fetchVBDiDSDaChiaSe',
    async ({DocumentID, subSite}: any) => {
        //7541
        const resVBDiDSDaChiaSe = await axios.get(
            `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&vbaction=UserShared&rid=${DocumentID}`,
        );
        return resVBDiDSDaChiaSe?.data?.data
    },
);
export const fetchVBDiDSNguoiBoSungThongTin = createAsyncThunk(
    'vbDi/fetchVBDiDSNguoiBoSungThongTin',
    async ({DocumentID, subSite}: any) => {
        const resVBDiDSNguoiBoSungThongTin = await axios.get(
            `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&vbaction=UserRequestInformation&rid=${DocumentID}`,
        );
        return resVBDiDSNguoiBoSungThongTin?.data?.data
    },
);
export const vbDiChiaSeApi = createAsyncThunk(
    'vbDi/vbDiChiaSeApi',
    async (payload: any) => {
        const { UserShared, Comment, DocumentID, subSite } = payload;
        const formData = {
            UserShared,
            Comment
        }
        const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&vbaction=submit&action=256&rid=${DocumentID}`
        const form = new FormData();
        form.append("data", JSON.stringify(formData));
        try {
            const response = await axios({
                method: 'post', url: url, data: form,
                headers: {
                    'Content-Type': `multipart/form-data`,
                    'Accept': 'application/json'
                },
            });
            let isChiaSeVBDiSuccess = false;
            if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
                isChiaSeVBDiSuccess = true;
            }
            return isChiaSeVBDiSuccess;
        } catch (error) {
            console.log('error', error, subSite);
        }

    }
);
export const fetchVBDiAttachFile = createAsyncThunk(
    'vbDi/fetchVBDiAttachFile',
    async ({ DocumentID, subSite }: any) => {
        const responseVBDiAttachFile = await axios.get(
            `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&rid=${DocumentID}&vbaction=AttachFile`,
        );
        return responseVBDiAttachFile?.data?.data;
    },
);
export const vbDiBoSungThongTinApi = createAsyncThunk(
    'vbDi/vbDiBoSungThongTinApi',
    async (payload: any) => {
        const { ChooseUser, Comment, DocumentID, subSite } = payload;
        const formData = {
            ChooseUser,
            Comment
        }
        const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&vbaction=submit&action=64&rid=${DocumentID}`
        const form = new FormData();
        form.append("data", JSON.stringify(formData));
        try {
            const response = await axios({
                method: 'post', url: url, data: form,
                headers: {
                    'Content-Type': `multipart/form-data`,
                },
            });
            let isGoBackVBDiScreen = false;
            if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
                isGoBackVBDiScreen = true;
            }
            return isGoBackVBDiScreen;
        } catch (error) {
            console.log('error', error);
        }

    }
);
export const vbDiYeuCauHieuChinhApi = createAsyncThunk(
    'vbDi/vbDiYeuCauHieuChinhApi',
    async (payload: any) => {
        const { UserCC, Comment, DocumentID, subSite } = payload;
        const formData = {
            UserCC,
            Comment
        }
        const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&vbaction=submit&action=8&rid=${DocumentID}`
        const form = new FormData();
        form.append("data", JSON.stringify(formData));
        try {
            const response = await axios({
                method: 'post', url: url, data: form,
                headers: {
                    'Content-Type': `multipart/form-data`,
                },
            });
            let isGoBackVBDiScreen = false;
            if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
                isGoBackVBDiScreen = true;
            }
            return isGoBackVBDiScreen;
            // return response;

        } catch (error) {
            console.log('error', error);
        }

    }
);
export const vbDiChuyenXuLyApi = createAsyncThunk(
    'vbDi/vbDiChuyenXuLyApi',
    async (payload: any) => {
        const { ChooseUser, Comment, DocumentID, subSite } = payload;
        const formData = {
            ChooseUser,
            Comment
        }
        const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&vbaction=submit&action=4&rid=${DocumentID}`
        const form = new FormData();
        form.append("data", JSON.stringify(formData));
        try {
            const response = await axios({
                method: 'post', url: url, data: form,
                headers: {
                    'Content-Type': `multipart/form-data`,
                },
            });
            let isGoBackVBDiScreen = false;
            if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
                isGoBackVBDiScreen = true;
            }
            return isGoBackVBDiScreen;
        } catch (error) {
            console.log('error', error);
        }
    }
);
export const vbDiDongYApi = createAsyncThunk(
    'vbDi/vbDiDongYApi',
    async (payload: any) => {
        const { UserCC, Comment, DocumentID, subSite } = payload;
        const formData = {
            UserCC,
            Comment
        }

        const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&vbaction=submit&action=1&rid=${DocumentID}`
        const form = new FormData();
        form.append("data", JSON.stringify(formData));
        try {
            const response = await axios({
                method: 'post', url: url, data: form,
                headers: {
                    'Content-Type': `multipart/form-data`,
                },
            });
            let isGoBackVBDiScreen = false;
            if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
                isGoBackVBDiScreen = true;
            }
            return isGoBackVBDiScreen;
        } catch (error) {
            console.log('error', error);
        }

    }
);
export const vbDiPheDuyetApi = createAsyncThunk(
    'vbDi/vbDiPheDuyetApi',
    async (payload: any) => {
        const { UserCC, Comment, DocumentID, subSite } = payload;
        const formData = {
            UserCC,
            Comment
        }
        const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&vbaction=submit&action=2&rid=${DocumentID}`
        const form = new FormData();
        form.append("data", JSON.stringify(formData));
        try {
            const response = await axios({
                method: 'post', url: url, data: form,
                headers: {
                    'Content-Type': `multipart/form-data`,
                },
            });
            let isGoBackVBDiScreen = false;
            if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
                isGoBackVBDiScreen = true;
            }
            return isGoBackVBDiScreen;
        } catch (error) {
            console.log('error', error);
        }

    }
);
export const vbDiThuHoiApi = createAsyncThunk(
    'vbDi/vbDiThuHoiApi',
    async (payload: any) => {
        const { Comment, DocumentID, subSite } = payload;

        const formData = {
            Comment
        }
        const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&vbaction=submit&action=32&rid=${DocumentID}`
        const form = new FormData();
        form.append("data", JSON.stringify(formData));
        try {
            const response = await axios({
                method: 'post', url: url, data: form,
                headers: {
                    'Content-Type': `multipart/form-data`,
                },
            });
            let isGoBackVBDiScreen = false;
            if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
                isGoBackVBDiScreen = true;
            }
            return isGoBackVBDiScreen;
        } catch (error) {
            console.log('error', error);
        }

    }
);
export const fetchThongTinLuanChuyenVbDi = createAsyncThunk(
    'vbDi/fetchThongTinLuanChuyenVbDi',
    async ({ itemId, subSite }: any) => {
        const responseThongTinLuanChuyenVbDi = await axios.get(
            `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetVBDi&rid=${itemId}&vbaction=WorkflowHistory`,
        );
        return responseThongTinLuanChuyenVbDi?.data?.data
    },
);

const groupThongTinLuanChuyenVbDi = (data: any) => {

    let ret = []

    if (arrayIsEmpty(data)) return ret
    
    let itemSup = {
        item: data[0],
        data: []
    }

    ret.push(itemSup)

    for (let index = 0; index < data.length; index++) {
        const r = data[index];

        if (r.Action !== itemSup.item.Action) {
            const a = []
            const r1 = {...r, isLast: false}
            a.push(r1)

            itemSup = {
                item: r1,
                data: a
            }
            ret.push(itemSup)
        } else {
            const r1 = {...r, isLast: false}
            itemSup.data.push(r1)
        }
    }

    for (let index = 0; index < ret[ret.length - 1].data.length; index++) {
        const element = ret[ret.length - 1].data[index];
        element.isLast = true
    }
    return ret
}

const initialState = {
    isLoadingVBDi: false,
    isGoBackVBDiScreen: false,
    isLoadMoreVbDi: true,
    dataVBDi: [],
    dataVBDiDetail: [],
    dataVBDiDSDaChiaSe: [],
    isChiaSeVBDiSuccess: false,
    dataVBDiAttachFile: [],
    dataDSNguoiBosungThongtin: [],
    dataThongTinLuyenChuyenVbDi: [],
    totalRecordVbDi: 0,
    totalRecord: 0,
    isLoadingDetail: false
}
const vbDiSlice = createSlice({
    name: 'vbDiReducer',
    initialState,
    reducers: {
        resetVBDiScreen(state, action) {
            state.isGoBackVBDiScreen = false;
            state.isChiaSeVBDiSuccess = false;
        },
        SetisLoadingVBDi(state, action) {
            return {
                ...state,
                isLoadingVBDi: action.payload
            }
        }
    },
    extraReducers: builder => {
        // --- Xử lý trong reducer với case pending / fulfilled / rejected ---
        builder
            .addCase(fetchVBDiApi.pending, (state: any) => {
                state.isLoadingVBDi = true;
            })
        builder.addCase(fetchVBDiApi.fulfilled, (state: any, action) => {
            state.dataVBDi = action.payload.Offset !== 0 ? state.dataVBDi.concat(action.payload.data) : action.payload.data;
            state.totalRecordVbDi = action.payload.status == 0 ? action.payload?.totalRecord : state.totalRecordVbDi
            state.isLoadMoreVbDi = action.payload.data.length !== 0
            state.totalRecord = action.payload.totalRecord
            state.isLoadingVBDi = false;
        });
        builder.addCase(fetchVBDiApi.rejected, (state: any, action) => {
            state.isLoadingVBDi = false;
        });
        
        builder.addCase(fetchVBDiDetailApi.pending, (state: any, action) => {
            state.isLoadingDetail = true;

        });
        builder.addCase(fetchVBDiDetailApi.fulfilled, (state: any, action) => {
            state.dataVBDiDetail = action.payload;
            state.isLoadingDetail = false;

        });
        builder.addCase(fetchVBDiDSDaChiaSe.fulfilled, (state: any, action) => {
            state.dataVBDiDSDaChiaSe = action.payload;
        });
        builder.addCase(fetchVBDiDSNguoiBoSungThongTin.fulfilled, (state: any, action) => {
            state.dataDSNguoiBosungThongtin = action.payload;
        });

        builder.addCase(vbDiChiaSeApi.pending, (state: any, action) => {
            state.isLoadingVBDi = true;
        });
        builder.addCase(vbDiChiaSeApi.fulfilled, (state: any, action) => {
            state.isChiaSeVBDiSuccess = action.payload;
            state.isLoadingVBDi = false
        });
        builder.addCase(vbDiChiaSeApi.rejected, (state: any, action) => {
            state.isLoadingVBDi = false;
        });

        builder.addCase(fetchVBDiAttachFile.fulfilled, (state: any, action) => {
            state.dataVBDiAttachFile = action.payload;
        });

        builder.addCase(vbDiChuyenXuLyApi.pending, (state: any, action) => {
            state.isLoadingVBDi = true;
        });

        builder.addCase(vbDiChuyenXuLyApi.fulfilled, (state: any, action) => {
            state.isGoBackVBDiScreen = action.payload;
            state.isLoadingVBDi = false;
        });

        builder.addCase(vbDiChuyenXuLyApi.rejected, (state: any, action) => {
            state.isLoadingVBDi = false;
        });

        builder.addCase(vbDiDongYApi.pending, (state: any, action) => {
            state.isLoadingVBDi = true;
        });
        builder.addCase(vbDiDongYApi.fulfilled, (state: any, action) => {
            state.isGoBackVBDiScreen = action.payload;
            state.isLoadingVBDi = false;
        });
        builder.addCase(vbDiDongYApi.rejected, (state: any, action) => {
            state.isLoadingVBDi = false;
        });

        builder.addCase(vbDiYeuCauHieuChinhApi.pending, (state: any, action) => {
            state.isLoadingVBDi = true;
        });
        builder.addCase(vbDiYeuCauHieuChinhApi.fulfilled, (state: any, action) => {
            state.isGoBackVBDiScreen = action.payload;
            state.isLoadingVBDi = false;
        });
        builder.addCase(vbDiYeuCauHieuChinhApi.rejected, (state: any, action) => {
            state.isLoadingVBDi = false;
        });

        builder.addCase(vbDiBoSungThongTinApi.pending, (state: any, action) => {
            state.isLoadingVBDi = true;
        });
        builder.addCase(vbDiBoSungThongTinApi.fulfilled, (state: any, action) => {
            state.isGoBackVBDiScreen = action.payload;
            state.isLoadingVBDi = false;
        });
        builder.addCase(vbDiBoSungThongTinApi.rejected, (state: any, action) => {
            state.isLoadingVBDi = false;
        });

        builder.addCase(vbDiThuHoiApi.pending, (state: any, action) => {
            state.isLoadingVBDi = true;
        });
        builder.addCase(vbDiThuHoiApi.fulfilled, (state: any, action) => {
            state.isGoBackVBDiScreen = action.payload;
            state.isLoadingVBDi = false;
        });
        builder.addCase(vbDiThuHoiApi.rejected, (state: any, action) => {
            state.isLoadingVBDi = false;
        });

        builder.addCase(fetchThongTinLuanChuyenVbDi.fulfilled, (state: any, action) => {
            state.dataThongTinLuyenChuyenVbDi = groupThongTinLuanChuyenVbDi(action.payload)
        });
        builder.addCase(vbDiPheDuyetApi.pending, (state: any, action) => {
            state.isLoadingVBDi = true;
        });
        builder.addCase(vbDiPheDuyetApi.fulfilled, (state: any, action) => {
            state.isGoBackVBDiScreen = action.payload;
            state.isLoadingVBDi = false
        });
        builder.addCase(vbDiPheDuyetApi.rejected, (state: any, action) => {
            state.isLoadingVBDi = false;
        });
    },
});
export const { resetVBDiScreen, SetisLoadingVBDi } = vbDiSlice.actions;
const { reducer } = vbDiSlice;
export default reducer;
