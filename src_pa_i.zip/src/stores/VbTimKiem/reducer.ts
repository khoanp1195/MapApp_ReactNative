import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { RESONSE_STATUS_NONE, RESONSE_STATUS_SUCCESS } from 'themes/const'
import { Alert } from 'react-native'
import { BaseUrl } from 'services/api'

export const postVbTimKiemApi = createAsyncThunk(
  'VbTimKiem/postVbTimKiemApi',
  async (payload: any) => {
    const { Content, LoaiVanBan, CoQuanGui, NguoiKyVanBan, Type, TuNgay, DenNgay, subSite } = payload;
    const bodyFormData = {
      Content, LoaiVanBan, CoQuanGui, NguoiKyVanBan, Type, TuNgay, DenNgay
    }
    
    const url = `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=SearchVB&limit=100&offset=0`
    const form = new FormData();
    form.append("data", JSON.stringify(bodyFormData));
    try {
      const response = await axios({
        method: 'post', url: url, data: form,
        headers: {
          'Content-Type': `multipart/form-data`,
        },
      });

      return response?.data?.data;

    } catch (error) {
      console.log('error', error);
    }
  }
);
export const fetchVbTimKiemCoQuanGui = createAsyncThunk(
  'VbTimKiem/fetchVbTimKiemCoQuanGui',
  async (subSite: any) => {
    const VbTimKiem = await axios.get(
      `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetSPList&listname=Cơ quan gửi&cols=["ID","Title","Parent_x003a_ID"]`,
    );
    return VbTimKiem?.data?.data
  },
);
export const fetchVbTimKiemNguoiKyGui = createAsyncThunk(
  'VbTimKiem/fetchVbTimKiemNguoiKyGui',
  async (subSite: any) => {
    const VbTimKiem = await axios.get(
      `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetSPList&listname=Người Ký Văn bản&cols=["ID","Title"]`,
    );
    return VbTimKiem?.data?.data
  },
);
export const fetchVbTimKiemLoaiVanBan = createAsyncThunk(
  'VbTimKiem/fetchVbTimKiemLoaiVanBan',
  async (subSite: any) => {
    const VbTimKiem = await axios.get(
      `${BaseUrl}/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetSPList&listname=Loại văn bản&cols=["ID","Title"]`,
    );
    return VbTimKiem?.data?.data
  },
);
const initialState = {
  isLoadingVbTimKiem: false,
  dataVbTimKiem: [],
  dataLoaiVanBan: [],
  dataCoQuanGui: [],
  dataNguoiKyGui: []
}
const VbTimKiemSlice = createSlice({
  name: 'VbTimKiemReducer',
  initialState,
  reducers: {
  },
  extraReducers: builder => {
    // --- Xử lý trong reducer với case pending / fulfilled / rejected ---
    builder
      .addCase(postVbTimKiemApi.pending, (state: any) => {
        state.isLoadingVbTimKiem = true;
      })
    builder.addCase(postVbTimKiemApi.fulfilled, (state: any, action) => {
      state.dataVbTimKiem = action.payload
      state.isLoadingVbTimKiem = false;
    });
    builder.addCase(postVbTimKiemApi.rejected, (state: any, action) => {
      state.isLoadingVbTimKiem = false;
    });
    builder.addCase(fetchVbTimKiemCoQuanGui.fulfilled, (state: any, action) => {
      state.dataCoQuanGui = action.payload
    });
    builder.addCase(fetchVbTimKiemNguoiKyGui.fulfilled, (state: any, action) => {
      state.dataNguoiKyGui = action.payload
    });
    builder.addCase(fetchVbTimKiemLoaiVanBan.fulfilled, (state: any, action) => {
      state.dataLoaiVanBan = action.payload
    });
  },
});
export const { } = VbTimKiemSlice.actions;
const { reducer } = VbTimKiemSlice;
export default reducer;
