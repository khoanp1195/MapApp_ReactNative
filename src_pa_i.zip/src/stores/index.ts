import loginReducer from './login/reducer';
import homeReducer from './home/reducer';
import vbDenReducer from './vbDen/reducer';
import vbDiReducer from './VBDi/reducer';
import vbBhReducer from './VBBH/reducer';
import taskVBDenReducer from './taskVBDen/reducer';
import VbTimKiemReducer from './VbTimKiem/reducer';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  combineReducers,
  configureStore,
  getDefaultMiddleware,
} from '@reduxjs/toolkit';
import {createSelectorHook, useDispatch} from 'react-redux';
import {
  FLUSH,
  PAUSE,
  PERSIST,
  persistReducer,
  persistStore,
  PURGE,
  REGISTER,
  REHYDRATE,
} from 'redux-persist';
import {PersistedState} from 'redux-persist/es/types';
import 'react-native-gesture-handler';
const PersistVersion = 1;
// @see httpss://github.com/reduxjs/redux-toolkit/issues/121#issuecomment-480621931 // Create a Persist-Config
const persistConfig = {
  key: 'PetrolimexAvitation',
  storage: AsyncStorage,
  whitelist: ['auth'],
  blacklist: [],
  version: PersistVersion,
  migrate: (state: PersistedState) => {
    if (PersistVersion !== state?._persist.version) {
      return Promise.resolve(null as unknown as PersistedState);
    }
    return Promise.resolve(state);
  },
};
const rootReducer = combineReducers({
  login: loginReducer,
  home: homeReducer,
  vbDenReducer: vbDenReducer,
  taskVBDenReducer,
  vbDiReducer,
  vbBhReducer,
  VbTimKiemReducer
});

const persistedReducer = persistReducer(persistConfig, rootReducer);

const store = configureStore({
  devTools: process.env.NODE_ENV === 'development',
  reducer: persistedReducer,
  // @see httpss://redux-toolkit.js.org/usage/usage-guide#use-with-redux-persist
  middleware: getDefaultMiddleware({
    serializableCheck: false,
  }),
});
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
export const useAppSelector = createSelectorHook<RootState>();
export const useAppDispatch = () => useDispatch<AppDispatch>();
export const persistor = persistStore(store);
export default store;
