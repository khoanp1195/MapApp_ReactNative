// export const BaseUrl = 'https://papetrolimex.vuthao.com';                 // DEV
export const BaseUrl = 'https://papetrolimexuat.vuthao.com';              // UAT
//export const BaseUrl = 'https://eofficeuat.petrolimexaviation.com.vn';    // MIG
//export const BaseUrl = 'https://eoffice.petrolimexaviation.com.vn';         // LIVE