import React, { useState, useEffect } from "react";
import styles from "./RootContainer.Style";
import { View, StatusBar } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { createNavigationContainerRef } from '@react-navigation/native';
import LoginScreen from "screens/auth/Login/Login.Screen";
import { RootState } from "stores";
import { useSelector } from "react-redux";
import DrawerNavigatorStack from "./DrawerNavigatorStack";
import colors from "~/themes/Colors";
export type StackParamList = {
  LoginScreen: undefined;
  DrawerNavigatorStack: undefined;
};
import {
  SafeAreaProvider,
  SafeAreaView
} from "react-native-safe-area-context";

const Stack = createStackNavigator<StackParamList>();

const RootContainerScreen = () => {
  const { isLogin } = useSelector((state: RootState) => state.login);

  return (
    <SafeAreaProvider>
      {
        isLogin ? <SafeAreaView style={styles.mainContainer}>
          <StatusBar barStyle='light-content' backgroundColor='#bdcbca'/>
          <DrawerNavigatorStack />
        </SafeAreaView> :
          <>
            <StatusBar barStyle='light-content' backgroundColor='transparent' translucent={true} />
            <Stack.Navigator
              initialRouteName="LoginScreen"
              screenOptions={{
                headerShown: false,
              }}
            >
              <Stack.Screen
                name="LoginScreen"
                component={LoginScreen}
                options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
              />
            </Stack.Navigator>
          </>
      }
    </SafeAreaProvider>
  );
};

export default RootContainerScreen;
