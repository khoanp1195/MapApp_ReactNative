import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  const { color = "#fff" } = props;
  return (
    <Svg
      width={21}
      height={20}
      viewBox="0 0 21 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M15.712 1.333h3.957c.184 0 .333.15.333.334v18c0 .184-.15.333-.333.333h-12a.333.333 0 01-.334-.333v-1h-3a.333.333 0 01-.333-.334v-1.25a5.667 5.667 0 010-10.833V.333c0-.184.15-.333.333-.333h10a.33.33 0 01.244.107l1.133 1.226zm1.863 3L14.67 1.187v3.146h2.906zM.67 11.667a5 5 0 1110 0 5 5 0 01-10 0zm4 5.573V18h13.333V5h-3.667a.333.333 0 01-.333-.333v-4H4.67v5.426c.33-.06.664-.09 1-.093a5.667 5.667 0 010 11.333 5.813 5.813 0 01-1-.093zm14.666 2.093H8.002v-.666h10.333c.184 0 .334-.15.334-.334V4.667a.326.326 0 00-.09-.227L16.329 2h3.006v17.333zM8.002 1.667h-2v.666h2v-.666zm1 0h4v.666h-4v-.666zm4 1.666h-7V4h7v-.667z"
        fill={color}
      />
    </Svg>
  );
}

export default SvgComponent;
