import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
    const { color = "#FC0D0D" } = props
    return (
        <Svg
            width={14}
            height={18}
            viewBox="0 0 14 18"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            {...props}
        >
            <Path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M13.083 9.45L9.7 6.28l3.384-3.15a.299.299 0 00.068-.39c-.07-.138-.237-.218-.409-.197H1.817V2.27c.52-.184.866-.613.886-1.096C2.703.526 2.093 0 1.34 0 .6 0 0 .517 0 1.154v.02c.03.486.384.914.909 1.096v15.339c0 .216.203.391.454.391.25 0 .454-.175.454-.391v-7.435h10.925a.494.494 0 00.41-.274.367.367 0 00-.069-.45zM1.34 1.565c-.25 0-.454-.175-.454-.391 0-.216.203-.391.454-.391s.455.175.455.39c0 .217-.204.392-.455.392zm.477 1.761v6.065h9.903L8.768 6.593a.37.37 0 010-.547l2.952-2.72H1.817z"
                fill={color}
            />
        </Svg>
    )
}

export default SvgComponent
