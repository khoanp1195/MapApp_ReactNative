import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
  return (
    <Svg
      width={16}
      height={16}
      viewBox="0 0 19 12"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        d="M9.744 11.028l8.302-8.992A.797.797 0 0018.045.97a.662.662 0 00-.987.002L9.25 9.429 1.442.971A.662.662 0 00.455.97a.784.784 0 00-.205.534c0 .192.068.385.204.532l8.302 8.992c.13.142.309.222.494.222s.363-.08.494-.222z"
        fill="#00419E"
      />
    </Svg>
  )
}

export default SvgComponent
