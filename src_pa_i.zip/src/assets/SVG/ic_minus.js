import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
  return (
    <Svg
      width={18}
      height={18}
      viewBox="0 0 18 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M9 18a9 9 0 10-9-9 9.01 9.01 0 009 9zM9 .58A8.42 8.42 0 11.58 9 8.429 8.429 0 019 .58zm-.29 8.71H3.484a.29.29 0 010-.58h11.032a.29.29 0 110 .58H8.71z"
        fill="#005FD4"
      />
    </Svg>
  )
}

export default SvgComponent
