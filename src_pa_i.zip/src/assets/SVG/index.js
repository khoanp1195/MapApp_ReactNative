import UserIcon from "./user.js";
import PasswordIcon from "./password.js";
import ChevronDownIcon from "./chevronDown.js";
import ProcessingDocxIcon from "./processingDocx.js";
import CoordinationDocxIcon from "./coordinationDocx.js";
import NotificationIcon from "./notification.js";
import WaitingCommentIcon from "./waitingComment.js";
import VBDenIcon from "./ic_vb_den.js";
import VBDiIcon from "./ic_vb_di.js";
import ProcessedIcon from "./processed.js";
import WaitingActionIcon from "./waitingAction.js";
import AllActionIcon from "./allAction.js";
import PublishedIcon from "./published.js";
import WaitForApprovedIcon from "./waitForApproved.js";
import LogOutPrimaryIcon from "./logOutPrimary.js";
import TabHomeIcon from "./ic_tabHome.js";
import TabSearchIcon from "./ic_tab_search.js";
import TabInComingDocxIcon from "./ic_tab_incomingDocx.js";
import TabOutGoingDocxIcon from "./ic_tab_outgoing.js";
import SearchIcon from "./ic_search.js";
import FilterIcon from "./ic_filter.js";
import RightBlueIcon from "./ic_right_blue.js";
import TypeIcon from "./ic_type.js";
import BackIcon from "./ic_back.js";
import SelectedEnalbleIcon from "./ic_selected_enable.js";
import SelectedDisableIcon from "./ic_selected_disable.js";
import CalendarLeftIcon from "./ic_calendar_left.js";
import CalendarRightIcon from "./ic_calendar_right.js";
import CalendarIcon from "./icon_calendar.js";
import RemoveIcon from "./icon_delete.js";
import DeleteIcon from "./icon_remove.js";
import DropDownIcon from "./ic_drop_down.js";
import DropUpIcon from "./ic_dop_up.js";
import ClockWhiteIcon from "./ic_clock_white.js";
import FowardProcesscon from "./ic_foward_process.js";
import TransferProcessIcon from "./ic_transfer_process.js";
import ActionMoreIcon from "./ic_action_more.js";
import FinishGreenIcon from "./ic_finish_green.js";
import AssignGreenIcon from "./ic_assign_green.js";
import ShareBlueIcon from "./ic_share_blue.js";
import WordBlueIcon from "./ic_word_blue.js";
import UserGreyIcon from "./ic_user_grey.js";
import DownloadIcon from "./download.js";
import UserPlusIcon from "./ic_user_plus.js";
import MemberIcon from "./ic_member.js";
import DoneIcon from "./ic_done.js";
import SellectedBoxIcon from "./sellected_box.js";
import UnSellectedBoxIcon from "./unsellected_box.js";
import MinusIcon from "./ic_minus.js";
import PlusIcon from "./ic_plus.js";
import ThreeDotIcon from "./ic_three_dot.js";
import AddRemoveIcon from "./ic_add_remove.js";
import ReAssignIcon from "./ic_re_assign.js";
import KetThucIcon from "./ic_ket_thuc.js";
import SaveIcon from "./ic_save.js";
import TraoDoiLaiIcon from "./ic_trao_doi_lai.js";
import RetangleGreenIcon from "./retangle_green.js";
import DueDateBlueIcon from "./ic_deadline_blue.js";
import DeleteRedIcon from "./ic_delete_red.js";
import CommentIcon from "./ic_comment.js";
import ChoYKienLanhDaoIcon from "./ic_ChoYKienLanhDao.js";
import TinhTrangIcon from "./ic_tinh_trang.js";
import HoSoDuThaoIcon from "./ic_ho_so_du_thao.js";
import DongYIcon from "./ic_dong_y.js";
import BoSungThongTInIcon from "./ic_bo_sung_thong_tin.js";
import DeNghiHieuChinhIcon from "./ic_de_nghi_dieu_chinh.js";
import FolderIcon from "./ic_folder.js";
import LaCoIcon from "./ic_la_co.js";
import ExelIcon from "./ic_excel.js";
import MenuIcon from "./ic_menu.js";
import DashedLine from "./dashline.js"

export {
  DashedLine,
  MenuIcon,
  UserIcon,
  PasswordIcon,
  ChevronDownIcon,
  ProcessingDocxIcon,
  CoordinationDocxIcon,
  NotificationIcon,
  WaitingCommentIcon,
  VBDenIcon,
  VBDiIcon,
  ProcessedIcon,
  WaitingActionIcon,
  AllActionIcon,
  PublishedIcon,
  WaitForApprovedIcon,
  LogOutPrimaryIcon,
  TabHomeIcon,
  TabSearchIcon,
  TabInComingDocxIcon,
  TabOutGoingDocxIcon,
  SearchIcon,
  FilterIcon,
  RightBlueIcon,
  TypeIcon,
  BackIcon,
  SelectedEnalbleIcon,
  SelectedDisableIcon,
  CalendarLeftIcon,
  CalendarRightIcon,
  CalendarIcon,
  RemoveIcon,
  DeleteIcon,
  DropDownIcon,
  DropUpIcon,
  ClockWhiteIcon,
  FowardProcesscon,
  TransferProcessIcon,
  ActionMoreIcon,
  FinishGreenIcon,
  AssignGreenIcon,
  ShareBlueIcon,
  WordBlueIcon,
  UserGreyIcon,
  DownloadIcon,
  UserPlusIcon,
  MemberIcon,
  DoneIcon,
  SellectedBoxIcon,
  UnSellectedBoxIcon,
  MinusIcon,
  PlusIcon,
  ThreeDotIcon,
  AddRemoveIcon,
  ReAssignIcon,
  KetThucIcon,
  TraoDoiLaiIcon,
  SaveIcon,
  RetangleGreenIcon,
  DueDateBlueIcon,
  DeleteRedIcon,
  CommentIcon,
  ChoYKienLanhDaoIcon,
  TinhTrangIcon,
  HoSoDuThaoIcon,
  DongYIcon,
  DeNghiHieuChinhIcon,
  BoSungThongTInIcon,
  FolderIcon,
  LaCoIcon,
  ExelIcon
};
