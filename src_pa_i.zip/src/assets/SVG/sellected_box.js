import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
  return (
    <Svg
      width={18}
      height={18}
      viewBox="0 0 18 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M18 2.5A2.5 2.5 0 0015.5 0h-13A2.495 2.495 0 000 2.5v13C0 16.912 1.156 18 2.5 18h13a2.5 2.5 0 002.5-2.5v-13zm-4.16 2.37a.68.68 0 11.96.962L7.113 13.52a.666.666 0 01-.978-.018L3.183 10.34a.68.68 0 01.033-.96.67.67 0 01.96.033l2.472 2.65L13.84 4.87z"
        fill="#005FD4"
      />
    </Svg>
  )
}

export default SvgComponent
