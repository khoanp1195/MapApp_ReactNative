import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
  return (
    <Svg
      width={16}
      height={16}
      viewBox="0 0 19 12"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        d="M9.256.972L.954 9.964a.797.797 0 00.001 1.066.662.662 0 00.987-.002L9.75 2.571l7.808 8.458a.662.662 0 00.987.001.784.784 0 00.205-.534.783.783 0 00-.204-.532L10.244.972A.672.672 0 009.75.75a.673.673 0 00-.494.222z"
        fill="#00419E"
      />
    </Svg>
  )
}

export default SvgComponent
