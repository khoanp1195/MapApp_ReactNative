import * as React from 'react';
import Svg, {Path} from 'react-native-svg';

function SvgComponent(props) {
  return (
    <Svg
      width={17}
      height={18}
      viewBox="0 0 17 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}>
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M9 .5a.5.5 0 00-1 0v7a.5.5 0 001 0v-7zm2.986 3.087a.535.535 0 01-.188-.72.507.507 0 01.702-.193c2.399 1.424 4 4.084 4 7.113 0 4.54-3.578 8.213-8 8.213-4.422 0-8-3.674-8-8.213 0-3.027 1.6-5.688 4-7.113a.507.507 0 01.701.192.535.535 0 01-.187.72C2.929 4.826 1.527 7.14 1.527 9.788c0 3.947 3.128 7.158 6.973 7.158 3.845 0 6.973-3.21 6.973-7.158 0-2.646-1.4-4.961-3.487-6.2z"
        fill="#015DD1"
      />
    </Svg>
  );
}

export default SvgComponent;
