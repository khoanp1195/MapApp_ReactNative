import * as React from 'react';
import Svg, {Path} from 'react-native-svg';

function SvgComponent(props) {
  return (
    <Svg
      width={24}
      height={24}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}>
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M12 0C5.375 0 0 5.372 0 12s5.373 12 12 12c6.629 0 12.001-5.372 12.001-12s-5.372-12-12-12zm0 3.588a3.97 3.97 0 11.001 7.94 3.97 3.97 0 010-7.94zm-5.737 15.16a8.807 8.807 0 005.735 2.115 8.804 8.804 0 005.736-2.116c.376-.32.593-.79.593-1.285a3.997 3.997 0 00-4.017-4.002H9.692a4.003 4.003 0 00-4.023 4.002c0 .494.217.965.594 1.286z"
        fill="#E5E5E5"
      />
    </Svg>
  );
}

export default SvgComponent;
