import * as React from 'react';
import Svg, {Path} from 'react-native-svg';

function SvgComponent(props) {
  const {color = '#025ED8'} = props;
  return (
    <Svg
      width={22}
      height={22}
      viewBox="0 0 22 22"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}>
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M19.52 2.475A8.421 8.421 0 007.307 14.063l-.643.643a1.33 1.33 0 00-1.882 0L.39 19.096a1.33 1.33 0 000 1.883l.627.627c.52.52 1.362.52 1.881 0l4.391-4.391a1.33 1.33 0 000-1.882l.643-.643A8.421 8.421 0 0019.521 2.475zM6.664 16.587l-4.391 4.391a.443.443 0 01-.627 0l-.628-.627a.443.443 0 010-.627l4.391-4.39a.454.454 0 01.627 0l.628.627a.444.444 0 010 .626zm1.568-2.822a7.54 7.54 0 0010.663 0 7.549 7.549 0 000-10.663A7.54 7.54 0 008.231 13.765z"
        fill={color}
      />
    </Svg>
  );
}

export default SvgComponent;
