import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  const { color = "#fff" } = props;
  return (
    <Svg
      width={20}
      height={20}
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M9.167.833H.833V17.5H8.75v.833H.417A.418.418 0 010 17.917V.417C0 .187.188 0 .417 0h9.166a.43.43 0 01.296.12l4.159 4.163a.407.407 0 01.1.159c0 .005.002.01.004.016a.443.443 0 01.025.125v3.334h-.834V5h-3.75a.418.418 0 01-.416-.417V.833zm3.575 3.334L10 1.425v2.742h2.742zM9.167 14.583a5.417 5.417 0 1110.833 0 5.417 5.417 0 01-10.833 0zm.833 0a4.58 4.58 0 004.583 4.584 4.591 4.591 0 004.584-4.584A4.58 4.58 0 0014.583 10 4.58 4.58 0 0010 14.583zm4.117 1.521l2.887-3.162a.43.43 0 01.596-.034.42.42 0 01.025.588l-3.183 3.487a.422.422 0 01-.3.138h-.009a.412.412 0 01-.295-.121l-2.271-2.27a.42.42 0 010-.58.419.419 0 01.587-.008l1.963 1.962z"
        fill={color}
      />
    </Svg>
  );
}

export default SvgComponent;
