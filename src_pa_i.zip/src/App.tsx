import React, { useCallback, useEffect, useState } from 'react';
import { Provider } from 'react-redux';
import RootContainer from './navigation/RootContainer.Screen';
import 'react-native-gesture-handler';
import store from './stores';
import { requestUserPermission } from './helpers/formater';
// import Configure, { getDeviceId, getFcmToken } from './services/notification/RemotePushController';
import { NavigationContainer } from "@react-navigation/native";
import { navigationRef } from './navigation/RootNavigation';

const App = () => {
  useEffect(() => {
    // requestUserPermission()
    // getFcmToken()
    // getDeviceId()
  }, [])

  return (
    <Provider store={store}>
      <NavigationContainer ref={navigationRef}>
        <RootContainer />
        {/* <Configure /> */}
      </NavigationContainer>
    </Provider>
  );
};

export default App
