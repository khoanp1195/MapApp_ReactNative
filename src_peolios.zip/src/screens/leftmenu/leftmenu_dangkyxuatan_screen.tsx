import { useDispatch } from "react-redux";
import { DrawerActions, useNavigation } from "@react-navigation/native";
import React, { useState } from "react";
import {
  redirectLichChoDuyet,
  redirectLichChoXepPhong,
  redirectLichDuKien, redirectLichTatCa,
  redirectParentView
} from "../../stores/base_screen/actions.ts";
import { Image, StyleSheet, Text, TouchableOpacity, View } from "react-native";

export const LeftMenuDangKyXuatAnScreen = () => {
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const [id, setID] = useState(2);

  const data = [
    {
      ID: 0,
      Title: "Đăng ký xuất ăn",
      Icon: require("../../assets/images/icon_xuatan.png"),
      IsParent: true,
      EnableClick: false
    },
    {
      ID: 1,
      Title: "Đăng ký",
      Icon: require("../../assets/images/icon_xuatan_dangky.png"),
      IsParent: false,
      EnableClick: false
    },
    {
      ID: 2,
      Title: "Quản lý ăn ca",
      Icon: require("../../assets/images/icon_xuatan_caan.png"),
      IsParent: false,
      EnableClick: true
    }
  ];


  return (
    <View style={styles.container}>
      {data.map((item) => (
        <TouchableOpacity key={item.ID} onPress={() => {
          if (item.EnableClick) {
            // @ts-ignore
            setID(item.ID);
          } else if (item.ID == 1) {
            // @ts-ignore
            navigation.navigate("DetailXuatAnScreen");
          }

        }}>
          <View style={styles.rowContainer}>
            <View style={[styles.indicator, { backgroundColor: id === item.ID ? "#0072C6" : "white" },
              (id !== item.ID && item.IsParent) && { backgroundColor: "#F5F5F5CC" }]} />
            <View style={[styles.itemContainer, { backgroundColor: id === item.ID ? "#E6F5FF80" : "white" },
              (id !== item.ID && item.IsParent) && { backgroundColor: "#F5F5F5CC" }]}>
              <Image source={item.Icon} style={styles.icon} />
              <Text style={[styles.title, item.IsParent && { fontWeight: "bold" }]}>{item.Title}</Text>
            </View>
          </View>
        </TouchableOpacity>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginVertical: 10
  },
  rowContainer: {
    flexDirection: "row"
  },
  indicator: {
    width: 10,
    height: 50
  },
  itemContainer: {
    flexDirection: "row",
    width: "96%",
    padding: 10,
    alignItems: "center"
  },
  icon: {
    height: 20,
    width: 20,
    marginRight: 10
  },
  title: {
    color: "#000000"
  }
});
