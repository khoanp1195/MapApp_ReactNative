import { View, Text, StyleSheet, TouchableOpacity, Pressable, Keyboard, Image, TextInput, ActivityIndicator } from 'react-native'
import React, { useState } from 'react'
import { useNavigation, useRoute } from '@react-navigation/native'
import { FlatList } from 'react-native-gesture-handler';
import { ModalTopBar } from '../../components/modalTopBar';


export const Calendar_unit = () => {
  const navigation = useNavigation();
  const route = useRoute();
  // @ts-ignore
  const item = route.params["item"];
  // @ts-ignore
  const onSelected = route.params["onSelected"];
  // @ts-ignore
  const selectedItem = route.params["title"]
    // @ts-ignore
  const flag = route.params["flag"]
  const [searchKey, setSearchKey] = useState("")
  const closeScreen = () => {
    // @ts-ignore
    if (navigation.canGoBack())
      navigation.goBack();
  }
  //@ts-ignore
  const onClickUnit = (item) => {
    if (__DEV__) console.log(item.Title, item.KeyConnection, item.SiteConnection)
    onSelected(item.Title, item.KeyConnection, item.SiteConnection,flag)
    closeScreen()
  }

  const Item = ({ item, index }: any) => {
    return (
      <TouchableOpacity style={{
        backgroundColor: 'white',
        flex: 1,
        flexDirection: 'row',
        padding: 10,
      }} onPress={() => {
        onClickUnit(item)
      }
      }>
        <Text style={item.Title == selectedItem ? styles.focusedText : styles.normalText}>{item.Title}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <Pressable
      style={{ flex: 1, backgroundColor: 'white' }}
      onPress={Keyboard.dismiss}
    >
      <ModalTopBar
        title={"Đơn vị"}
        onPress={() => {
          closeScreen()
        }} />
      <View style={{
        height: 60,
        justifyContent: 'center',
        alignItems: 'center',
        borderTopWidth: 1,
        borderBottomWidth: 1,
        borderColor: 'lightgrey'
      }}>
        <View style={styles.searchBar}>
          <Image
            style={{
              height: '50%',
              aspectRatio: 1,
              marginLeft: 10,
              justifyContent: 'center',
            }}
            source={require('../../assets/images/icon_search26.png')}
            resizeMode="stretch"
          />
          < TextInput
            style={styles.input}
            placeholder="Tìm kiếm"
            autoCapitalize="none"
            value={searchKey}
            onChangeText={(text) => setSearchKey(text)} />
        </View>

      </View>

      {
        item != null && item.length > 0 ?
          <View style={{
            flex: 1,
          }}>
            <FlatList
              scrollEnabled={true}
              // @ts-ignore
              keyExtractor={(item, index) => item + index}
              data={item}
              numColumns={1}
              // @ts-ignore
              renderItem={({ item, index }) => {
                return <Item item={item} index={index} />;
              }}
            />
          </View>
          : null
      }
      {/* </View> */}
    </Pressable>
  )
}

const styles = StyleSheet.create({
  flatList: {
    backgroundColor: 'white', 
    paddingHorizontal: 20, 
    paddingVertical: 10,
  },
  rootContainer: {
    height: "100%",
    backgroundColor: "white"
  },
  searchBar: {
    height: 40,
    backgroundColor: "#f5f5f5",
    marginHorizontal: 5,
    flexDirection: 'row',
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 6,
  },
  input: {
    // height: 30,
    fontSize: 14,
    marginHorizontal: 5,
    paddingHorizontal: 5,
    flex: 1,
    borderRadius: 6,
  },
  focusedText: { color: 'red', fontWeight: 'bold' },
  normalText: { color: 'black', fontWeight: 'normal' }
})

export default Calendar_unit