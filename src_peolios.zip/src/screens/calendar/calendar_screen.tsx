import { FlatList, Image, Text, TouchableOpacity, View, StyleSheet, Alert, Pressable, LogBox, Linking } from "react-native";
import ReactNativeCalendarStrip from "react-native-calendar-strip";
import CustomSafeAreaView from "../../components/custom_safe_area_view.tsx";
import { showLeftMenuCalendar, showLeftMenuHome } from "../../stores/leftmenu/actions.ts";
import { PetroAppBarCustom } from "../../components/petro_appbar_custom.tsx";
import { useDispatch, useSelector } from "react-redux";
import { useNavigation } from "@react-navigation/native";
import { Tab } from "react-native-elements";
import React, { memo, useCallback, useEffect, useMemo, useState } from "react";
import BaseScreen from "../../components/basescreen.tsx";
import { Calendar, LocaleConfig, WeekCalendar, CalendarProvider } from 'react-native-calendars';
import { formatDate, formatDateNum, formatDateToVietnamese, getDisplayTxtFromDateString, getDisplayTxtFromHourString, getStartOfWeek, getWeekOfYear, isNullOrEmpty, startOfWeek } from "../../utils/functions.ts";
import moment, { isDate } from "moment";
import { appMainBlueColor } from "../../utils/color.ts";
import { getListDonVi, getMeetingCalendars } from "../../services/api/api_calendar.ts";
import Empty_view from "../../components/empty_view.tsx";
import { RefreshControl, ScrollView } from "react-native-gesture-handler";
import { formatParticipantsDetail } from '../../utils/functions'
import { subsiteStore } from "../../config/constants.ts";
import * as Animatable from 'react-native-animatable'
export const CalendarScreen = () => {
  moment.locale("en");
  const dispatch = useDispatch();
  const onLoading = useSelector((state: any) => state.loading.onLoading);
  const navigation = useNavigation();
  const [selectedDate, setSelectedDate] = useState(moment(new Date()).format("YYYY-MM-DD"));
  const [donvi, setDonVi] = useState();
  const [lichhHop, setlichhHop] = useState([])
  const [lichtuan, setLichTuan] = useState([])
  const [firstDayofWeek, setfirstDayofWeek] = useState(new Date());
  const [lastDayOfWeek, setlastDayOfWeek] = useState(new Date())
  const [uniTitle, setUnitTitle] = useState("Tập đoàn Xăng dầu Việt Nam")
  const [siteConnection, setSiteConnection] = useState("")
  const [keyConnection, setKeyConnection] = useState("")
  const [isFirst, setIsFirst] = useState(true)
  const [flag, setFlag] = useState(1)
  const [isShowMonthCalendar, setIsShowMonthCalendar] = useState(false);
  const [dictLichhop, setdictLichhop] = useState({})
  const [isWeekView, setisWeekView] = useState(false)
  const [weeknum, setweeknum] = useState("")
  const [week, setweek] = useState(Number)
  const [dotCalendar, setdotCalendar] = useState([])
  const [isPreDate, setisPreDate] = useState(false)
  const [dateWeekLoad, setdateWeekLoad] = useState(new Date())
  const [isChangeUnit, setisChangeUnit] = useState(false)
  const [refreshing, setRefreshing] = useState(false)
  const isReload = useSelector((state: any) => state.lichHop.isReload);

  const datesBlacklistFunc = (date: { isoWeekday: () => number; }) => {
    return date.isoWeekday() === 6 || date.isoWeekday() === 7; // disable Saturdays
  };
  const tabs = [
    { title: "Lịch lãnh đạo" },
    { title: "Lịch ban" },
    { title: "Lịch của tôi" }
  ];

  const [indexTab, setIndexTab] = useState(0);
  const [isFullWeek, setIsFullWeek] = useState(false);

  // @ts-ignore
  const RenderItem = ({ item, index }) => {
    const getColorByAppStatus = (AppStatus: any) => {
      switch (AppStatus) {
        case 1:
          return "#FFF2EA"
        case 4:
          return '#A7FFA5'
        case 2:
          return '#ACB0EE';
        case 5:
          return '#FFF0F0';
        case 3:
          return '#FFFAEC';
        default:
          return '#E7F8FF';
      }
    }
    const getColorBorderByAppStatus = (AppStatus: any) => {
      switch (AppStatus) {
        case 1:
          return "#FF9E5E"
        case 4:
          return '#A7FFA5'
        case 2:
          return '#ACB0EE';
        case 5:
          return '#FF8685';
        case 3:
          return '#FFD770';
        default:
          return '#8ECFFF';
      }
    }

    const getStatusItem = (StatusItem: any) => {
      switch (StatusItem) {
        case 1:
          return "Bổ sung"
        case 2:
          return "Điều chỉnh";
        case 3:
          return "Hoãn";
        case 4:
          return "Dự kiến";
        case 5:
          return "Hủy";
        default:
          return '';
      }
    }

    const getParticipant = () => {
      var dataTxt = item.ParticipantsDetail
      var tPKhacTxt = item.AdditionIngredients ? item.AdditionIngredients : "";
      var tPCTXDTxt = item.OtherParticipants ? item.OtherParticipants : "";
      tPKhacTxt = tPKhacTxt.replace(/\n/g, ";$");
      var decodedDataTxt = decodeURIComponent(dataTxt);
      var dataToShow = decodedDataTxt + (tPKhacTxt || tPCTXDTxt ? "#Thành phần tại đơn vị;$" + tPCTXDTxt + ";$" + tPKhacTxt : "");
      return dataToShow
    }

    const ParticipantTxt = () => {
      let dataTxt = item.ParticipantsDetail || "";
      if (item.OtherParticipants || item.AdditionIngredients) {
        dataTxt += (dataTxt ? "#" : "") + "Thành phần tại đơn vị";
      }
      let data = decodeURIComponent(dataTxt);
      return formatParticipantsDetail(data)
    }

    const OpenMeetingLink = (item: any) => {
      if (item.IsView === 1) {
        Linking.canOpenURL(item.MeetingLink).then(supported => {
          if (!supported) {
            Alert.alert(
              'Thông báo',
              'Bạn chưa có phần mềm họp, vui lòng tải để sử dụng.',
            );
            return;
          } else {
            Linking.openURL(item.MeetingLink);
          }
        });
      } else {
        Alert.alert(
          'Thông báo',
          'Bạn không có quyền vào link này',
          [
            {
              text: 'Đóng',
              onPress: () => {
              },
            },
          ],
        );
      }
    }

    return <Pressable onPress={() => {
      // @ts-ignore
      navigation.navigate("DetailCalendarScreen", {
        item: item
      });
    }}
      style={{
        borderWidth: 1.5,
        borderRadius: 10,
        flexDirection: "row",
        alignItems: "center",
        alignContent: "center",
        justifyContent: "center",
        marginTop: 10,
        borderColor: getColorBorderByAppStatus(item.StatusItem)
      }}>
      <View style={{
        padding: 10,
        borderTopLeftRadius: 10,
        borderBottomLeftRadius: 10,
        flexDirection: "column",
        flex: 3,
        height: "100%",
        backgroundColor: getColorByAppStatus(item.StatusItem),
        alignItems: "center"
      }}>

        <View style={{ flexDirection: 'row' }}>
          <Text style={{ color: '#19191E', fontWeight: '700', fontSize: 12 }}>{getDisplayTxtFromHourString(item.StartTime)}</Text>
          <Text> - </Text>
          <Text style={{ color: '#19191E', fontWeight: '700', fontSize: 12 }}>{getDisplayTxtFromHourString(item.EndTime)}</Text>
        </View>
        <View style={{
          width: "100%",
          alignItems: "center"
        }}>
          <View style={{ justifyContent: 'center', display: item.StatusItem ? 'flex' : 'none', backgroundColor: getColorBorderByAppStatus(item.StatusItem), height: 20, width: 60, borderRadius: 7, marginTop: '6%' }}>
            <Text style={{ alignSelf: 'center' }}>{getStatusItem(item.StatusItem)}</Text>
          </View>
        </View>
        <TouchableOpacity style={{ marginTop: '15%' }} onPress={() => {
          Alert.alert('Địa điểm phòng họp', item.LocationTitle, [
            { text: 'OK', onPress: () => console.log('OK Pressed') },
          ]);
        }}>
          <Text numberOfLines={2} style={{ marginTop: '15%', textAlign: 'center' }}>{item.LocationTitle}</Text>
        </TouchableOpacity>
        {
          item.MeetingLink != "" ? (
            <View style={{ flexDirection: "row", marginTop: '45%' }}>
              <Image resizeMode={"contain"} style={{ height: 20, width: 20 }}
                source={require("../../assets/images/icon_meeting_call.png")} />
              <TouchableOpacity onPress={() => {
                OpenMeetingLink(item)
              }}>
                <Text style={{ marginLeft: '5%' }}>Vào link họp</Text>
              </TouchableOpacity>
            </View>) : <View></View>
        }
      </View>
      <View style={styles.view_item_right}>
        <Text numberOfLines={2}>{item?.Title}</Text>
        <View style={styles.dashed_line} />
        <View style={{ flexDirection: "column", marginTop: 20 }}>
          <View style={{ flexDirection: "row", marginBottom: 10 }}>
            <Image resizeMode={"contain"} style={{ height: 20, width: 20, }}
              source={require("../../assets/images/icon_user_calendar.png")} />
            <Text style={{ marginLeft: '4%', width: '90%' }}>{item.HostTitle}</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <Image resizeMode={"contain"} style={{ height: 20, width: 20, marginTop: '3%' }}
              source={require("../../assets/images/icon_group.png")} />
            <TouchableOpacity onPress={() => {
              OnClickParticipant(getParticipant())
            }} style={{ width: '80%', marginLeft: '4%' }}>
              <Text>{(ParticipantTxt())}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Pressable>;
  };


  useEffect(() => {
    if (isFirst) {
      loadMyCalendar()
      loadDonVi()
      loadListCalendarByWeek(formatDate(firstDayofWeek), formatDate(lastDayOfWeek), 2, siteConnection).then(dataFirstLich => {
        if (dataFirstLich != null) {
          setlichhHop(dataFirstLich)
        }
        setRefreshing(false)
      })
    }
    else {
      try {
        if (!isWeekView) {
          setUnitTitle(uniTitle)
          loadListCalendarByWeek(selectedDate, selectedDate, flag, siteConnection).then(dataLichHop => {
            if (dataLichHop != null) {
              setlichhHop(dataLichHop)
            }
            setRefreshing(false)
          })
        }
      }
      catch (error) {
        console.log("Error fetching data: " + error)
      }
    }
    LogBox.ignoreLogs(['VirtualizedLists should never be nested']);
  }, [uniTitle, selectedDate, indexTab, dateWeekLoad, refreshing])


  useEffect(() => {
    if (isWeekView) {
      LoadListCalendarByWeek(dateWeekLoad)
    }
  }, [isWeekView, keyConnection, siteConnection, indexTab, refreshing]);


  useEffect(() => {
    if (isChangeUnit)
      loadMyCalendar()
  }, [isChangeUnit])


  const loadDonVi = async () => {
    try {
      const data = await getListDonVi();
      setIsFirst(false)
      if (data && data.length > 0) {
        const matchDepartment = data.find((d: { SiteConnection: string, KeyConnection: string; }) => subsiteStore.getSubsite() === (d.SiteConnection === 'Protal' ? "" : d.SiteConnection || d.KeyConnection));
        const unitTitle = matchDepartment ? matchDepartment.Title : data[0].Title;
        const siteConnection = matchDepartment ? matchDepartment.SiteConnection : subsiteStore.getSubsite();

        setDonVi(data);
        setUnitTitle(unitTitle);
        setSiteConnection(siteConnection);
        calculateWeekBounds();

        const dataFirstLich = await loadListCalendarByWeek(formatDate(firstDayofWeek), formatDate(lastDayOfWeek), 2, siteConnection);
        if (dataFirstLich) {
          setlichhHop(dataFirstLich);
        }
      } else {
        setUnitTitle("Tập đoàn xăng dầu Việt Nam");
        setSiteConnection("portal");
        setKeyConnection("portal");
      }
    } catch (error) {
      console.log("loadDonVi - error: " + error)
    }
  }

  const loadListCalendarByWeek = async (fromDate: any, toDate: any, flag: number, SiteConnection: any) => {
    const data = await getMeetingCalendars(fromDate, toDate, flag, SiteConnection);
    if (data != null) {
      return data;
    } else {
      return [];
    }
  };

  const LoadListCalendarByWeek = async (date: any) => {
    const dateObject = new Date(date)
    const firstDay = startOfWeek(dateObject);
    const lastDay = new Date(firstDay);
    firstDay.setDate(firstDay.getDate())
    lastDay.setDate(firstDay.getDate() + 6);
    let flagWeek = getFlag(indexTab) || 0
    setdateWeekLoad(date)
    
    setweek(getWeekOfYear(date));
    setweeknum(`(${formatDateNum(firstDay)} - ${formatDateNum(lastDay)})`);

    const dataFirstLich = await loadListCalendarByWeek(formatDate(firstDay), formatDate(lastDay), flagWeek, siteConnection)
    if (dataFirstLich != null) {
      setLichTuan(dataFirstLich);
      const tempDict: Record<string, any[]> = {}
      dataFirstLich.forEach((item: { StartTime: string | number | Date; }) => {
        if (item.StartTime) {
          const key = formatDateToVietnamese(new Date(item.StartTime));
          tempDict[key] = tempDict[key] ? [...tempDict[key], item] : [item];
        }
        setdateWeekLoad(new Date())
      });
      setdictLichhop(tempDict);
    }
    setRefreshing(false)
  }

  const loadMyCalendar = () => {
    const dateObject = new Date(selectedDate);
    const firstDay = startOfWeek(dateObject);
    const lastDay = new Date(firstDay);
    firstDay.setDate(firstDay.getDate() - 20);
    lastDay.setDate(firstDay.getDate() + 10);

    loadListCalendarByWeek(formatDate(firstDay), formatDate(lastDay), 3, siteConnection)
      .then(dataMyCalendar => {
        if (dataMyCalendar) {
          const markedDates = dataMyCalendar.reduce((acc, item) => {
            if (item.StartTime) {
              const key = moment(item.StartTime).format("YYYY-MM-DD");
              acc[key] = {
                textColor: 'green',
                color: 'green',
                dotColor: 'red',
                marked: true
              };
            }
            return acc;
          }, {});

          setdotCalendar(markedDates);
          setisChangeUnit(false);
          setRefreshing(false)
        } else {
          console.error('No calendar data available');
        }
      })
      .catch(error => {
        console.error('Error loading calendar:', error);
      });
  };

  const calculateWeekBounds = () => {
    const firstDay = getStartOfWeek();
    const lastDay = new Date(firstDay);
    lastDay.setDate(firstDay.getDate() + 6);
    setfirstDayofWeek(firstDay);
    setlastDayOfWeek(lastDay);
  };

  const getFlag = (index: number) => {
    switch (index) {
      case 0:
        return 2
      case 1:
        return 1;
      case 2:
        return 3;
    }
  }

  const OnClickUnit = (item: any) => {
    // @ts-ignore
    navigation.navigate("Calendar_unit", {
      item: donvi, title: uniTitle, flag: getFlag(indexTab),
      onSelected: (title: string, KeyConnection: string, SiteConnection: string, flag: number) => {
        setUnitTitle(title)
        setisChangeUnit(true)
        setSiteConnection(SiteConnection)
        setKeyConnection(KeyConnection)
        setFlag(flag)
        console.log("KeyConnection - here " + KeyConnection)
      }
    })
  };

  const OnClickParticipant = (item: any) => {
    // @ts-ignore
    navigation.navigate("Participant_Screen", { item: item })
  };

  const onDateChanged = (date: any) => {
    setFlag(getFlag(indexTab) || 0)
    setIndexTab(0)
    setSelectedDate(date)
    setdateWeekLoad(date)
  };

  const changeTab = (index: any) => {
    setFlag(getFlag(index) || 0)
  }

  const loadWeekCalendar = useCallback(() => {
    setIsFullWeek(!isFullWeek);
    setisWeekView(!isWeekView)
  }, [isWeekView, isFullWeek])


  const Btn_prevWeek_Click = () => {
    try {
      dateWeekLoad.setDate(dateWeekLoad.getDate() - 7)
      LoadListCalendarByWeek(dateWeekLoad)
    } catch (error) {
      console.log('Btn_prevWeek_Click - error: ' + error)
    }
  }

  const Btn_nextWeek_Click = () => {
    try {
      dateWeekLoad.setDate(dateWeekLoad.getDate() + 7)
      LoadListCalendarByWeek(dateWeekLoad)
    } catch (error) {
      console.log('Btn_nextWeek_Click - error: ' + error)
    }
  }

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
  }, [refreshing]);


  LocaleConfig.locales["vn"] = {
    monthNames: [
      "Tháng 1",
      "Tháng 2",
      "Tháng 3",
      "Tháng 4",
      "Tháng 5",
      "Tháng 6",
      "Tháng 7",
      "Tháng 8",
      "Tháng 9",
      "Tháng 10",
      "Tháng 11",
      "Tháng 12"
    ],
    monthNamesShort: [
      "Th 1",
      "Th 2",
      "Th 3",
      "Th 4",
      "Th 5",
      "Th 6",
      "Th 7",
      "Th 8",
      "Th 9",
      "Th 10",
      "Th 11",
      "Th 12"
    ],
    dayNames: ["Chủ nhật", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"],
    dayNamesShort: ["CN", "T2", "T3", "T4", "T5", "T6", "T7"]
  };
  LocaleConfig.defaultLocale = "vn";

  return (
    <BaseScreen key={isReload}>
      {
        <View style={{ height: "100%", backgroundColor: "white" }}>
          <PetroAppBarCustom
            title={"Lịch tuần"}
            rightAction={
              <View style={{ flexDirection: 'row' }}>
                <TouchableOpacity onPress={() => {
                  setIsShowMonthCalendar(!isShowMonthCalendar)
                }}>
                  <Text style={styles.displayDate}>{getDisplayTxtFromDateString(selectedDate)}</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={() => {
                  loadWeekCalendar()
                }}>
                  <Image style={{ height: 25, width: 25 }} source={
                    !isFullWeek ?
                      require("../../assets/images/icon_change_type_date.png") :
                      require("../../assets/images/icon_change_type_week.png")
                  } />
                </TouchableOpacity>
              </View>
            }
            onPress={() => {
              dispatch(showLeftMenuCalendar());
              // @ts-ignore
              navigation.openDrawer();
            }} />

          <View style={styles.lineGray} />

          <TouchableOpacity
            style={styles.btn_donvi}
            onPress={(item) => {
              OnClickUnit(item);
            }}>
            <Image style={{ height: 20, width: 20, marginRight: 10 }} resizeMode={"contain"}
              source={require("../../assets/images/icon_focus_contact.png")} />
            <Text style={styles.lbl_donvi}>{uniTitle}</Text>
          </TouchableOpacity>

          <View style={styles.lineGray} />

          <View style={{ height: 80, backgroundColor: "cyan" }}>
            {
              isWeekView ? (
                <View>
                  <View style={{ width: '100%', height: 80, backgroundColor: '#FAFAFA', flexDirection: 'row' }}>
                    <TouchableOpacity style={{ width: '15%', alignItems: 'center', justifyContent: "center" }}
                      onPress={() => {
                        Btn_prevWeek_Click()
                        setisPreDate(
                          !isPreDate)
                      }}
                    >
                      <Image style={{ height: 20, width: 20, marginRight: 10 }} resizeMode={"contain"}
                        source={require("../../assets/images/icon_preWeek.png")} />
                    </TouchableOpacity>
                    <View style={{ width: '70%', justifyContent: 'center', flexDirection: 'row' }}>
                      <Text style={{ marginRight: '2%', alignSelf: 'center', fontSize: 16, fontWeight: '600' }}>Tuần {week}</Text>
                      <Text numberOfLines={1} style={{ alignSelf: 'center', fontSize: 16 }}>
                        {weeknum}
                      </Text>
                    </View>
                    <TouchableOpacity style={{ width: '15%', alignItems: 'center', justifyContent: "center" }}
                      onPress={() => {
                        Btn_nextWeek_Click()
                      }}
                    >
                      <Image style={{ height: 20, width: 20, marginRight: 10 }} resizeMode={"contain"}
                        source={require("../../assets/images/icon_nextWeek.png")} />
                    </TouchableOpacity>
                  </View>
                </View>
              ) :
                (
                  null
                )
            }
            <CalendarProvider
              date={selectedDate} // date={"2024-01-01"}
              //@ts-ignore
              onDateChanged={(date) => { onDateChanged(date) }}
              disabledOpacity={1}
              showTodayButton={false}
            >
              <WeekCalendar testID={'weekCalendar'}
                firstDay={1}
                theme={{
                  backgroundColor: '#F3F9FF',
                  calendarBackground: '#F3F9FF',//#ffffff
                  textSectionTitleColor: 'black',
                  selectedDayBackgroundColor: appMainBlueColor,//'#00adf5'
                  selectedDayTextColor: '#ffffff',
                  todayTextColor: appMainBlueColor,// '#00adf5'
                  dayTextColor: 'black',
                }}
                disableOnPageChange={true}
                markedDates={dotCalendar}
              />
            </CalendarProvider>
          </View>
          <View style={styles.lineGray} />
          <Tab
            value={indexTab}
            onChange={(index) => {
              setIndexTab(index);
              // setFlag(index)
              console.log("Index here " + index)
              changeTab(index)
            }}
            indicatorStyle={styles.indiCatorStyles}
          >
            {tabs.map((tab, index) => (
              <Tab.Item key={index} title={tab.title} containerStyle={{ backgroundColor: "white" }} titleStyle={styles.tabItemStyle} />
            ))}
          </Tab>
          {/* <View style={{ width: "100%", height: 5, backgroundColor: "#EAEAEA", marginTop: 5 }} /> */}
          {
            isShowMonthCalendar ? (
              <Animatable.View
                animation={"fadeInDown"}
                duration={500}
                delay={0.2 * 300}
                style={styles.animateCalendar}
              >
                <View >
                  <Calendar
                    date={selectedDate}
                    onDayPress={day => {
                      setSelectedDate(day.dateString);
                      setIsShowMonthCalendar(false)
                      onDateChanged(day.dateString)
                      setisWeekView(false)
                    }}
                    markedDates={dotCalendar}
                    theme={{
                      backgroundColor: '#F3F9FF',
                      calendarBackground: '#F3F9FF',
                      textSectionTitleColor: '#b6c1cd',
                      selectedDayBackgroundColor: '#00adf5',
                      selectedDayTextColor: '#ffffff',
                      todayTextColor: appMainBlueColor,
                      dayTextColor: '#2d4150',
                      textDayHeaderFontWeight: '600',
                    }}
                    style={styles.calendar}
                  />
                </View>
              </Animatable.View>
            ) : null
          }

          <ScrollView style={{ alignContent: 'center' }}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={'#0A78C8'} />
            }>
            {
              isWeekView && dictLichhop != undefined && Object.keys(dictLichhop).length > 0 ? (
                <FlatList
                  style={{ padding: 10 }}
                  data={Object.keys(dictLichhop)}
                  renderItem={({ item }) => (
                    <View>
                      <View style={styles.headerWeekCalendar}>
                        <Image style={{ height: 20, width: 20, marginRight: 10 }}
                          source={require("../../assets/images/icon_week_header.png")} />

                        <Text style={{ alignSelf: 'center', fontWeight: '600', color: '#0072C6' }}>{item}</Text></View>
                      <FlatList
                        style={{ marginTop: '2%' }}
                        data={dictLichhop[item]}
                        renderItem={({ item, index }) => <RenderItem item={item} index={index} />}
                        keyExtractor={(item, index) => index.toString()}
                      />
                    </View>
                  )}
                  keyExtractor={(item, index) => index.toString()}
                />
              ) : isWeekView ? (<View style={styles.viewNoData}>
                <Text style={styles.textNoData}>Không có dữ liệu</Text>
              </View>) : null
            }
            {lichhHop != undefined && lichhHop.length > 0 && !isWeekView ? (
              <FlatList
                data={lichhHop}
                renderItem={({ item, index }) => <RenderItem item={item} index={index} />}
                keyExtractor={item => item.id}
                scrollEnabled={false}
                style={{ padding: 10 }}
              />
            ) : !isWeekView ? (
              <View style={styles.viewNoData}>
                <Text style={styles.textNoData}>Không có dữ liệu</Text>
              </View>) : null}
          </ScrollView>
        </View>
      }
    </BaseScreen>
  );
};
const styles = StyleSheet.create({
  viewNoData: {
    flex: 1,
    justifyContent: 'center',
    marginTop: '50%',
    alignItems: 'center',
  },
  textNoData: {
    fontSize: 15,
    color: '#5E5E5E',
    fontStyle: 'italic'
  },
  headerWeekCalendar: {
    backgroundColor: '#E7F5FF',
    height: 40,
    width: '60%',
    justifyContent: "center",
    flexDirection: 'row',
    borderRadius: 14,
    alignItems: 'center',
    marginTop: '2%'
  },
  absolute: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
  },
  calendar: {
    borderColor: 'gray',
    height: '100%',
    marginTop: '6%',
    shadowColor: 'lughtgray',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  animateCalendar: {
    height: "55%",
    marginTop: '-55%',
    zIndex: 99,
    width: '100%',
    alignSelf: 'center',
    backgroundColor: 'transparent',
  },
  displayDate: {
    marginRight: 15, marginTop: '7%', color: '#0072C6', fontWeight: '600'
  },
  tabItemStyle: {
    fontSize: 12,
    color: "#000000",
    height: 30,
    width: '100%'
  },
  lineGray: {
    width: "100%", height: 5, backgroundColor: "#EAEAEA"
  },
  indiCatorStyles: {
    backgroundColor: "#0072C6", height: 3, borderRadius: 100, marginHorizontal: 4
  },
  btn_donvi: {
    paddingVertical: 15,
    paddingHorizontal: 15,
    flexDirection: "row",
    backgroundColor: "white"
  },
  lbl_donvi: {
    color: "black", fontWeight: "bold", fontSize: 15, width: '95%', backgroundColor: "white"
  },
  dashed_line: {
    width: "100%",
    height: 1,
    borderWidth: 0.5,
    marginTop: '3%',
    borderColor: "#474747",
    borderStyle: "dashed"
  },
  view_item_right: {
    flexDirection: "column",
    flex: 7,
    height: "100%",
    padding: 10,
    backgroundColor: "white",
    borderTopRightRadius: 9,
    borderBottomRightRadius: 9
  }
});
