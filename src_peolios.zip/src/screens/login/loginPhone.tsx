import { FC } from "react";
import { styles } from "./login.style";
import { useSelector } from "react-redux";
import { Button, ImageBackground, Keyboard, Pressable ,Text,TextInput, View} from "react-native";
import { Image } from "react-native-elements";
interface Props {
    onChangeTextUserName(username: string): void,
    onChangeTextPassword(password: string): void
    handleLogin(): void
  }
export const LoginPhoneScreen: FC<Props> = ({ onChangeTextUserName, onChangeTextPassword, handleLogin }) => {
    const { loading } = useSelector((state: any) => state.login);

    return <Pressable style={{ flex: 1 }} onPress={Keyboard.dismiss}>
      <ImageBackground
        source={require("../../assets/images/icon_splashscreen.png")}
        style={[styles.container, { justifyContent: loading ? "flex-end" : "center" }]}>
        {!loading ? (
          <View style={styles.loginContainer}>
            <View style={styles.inputContainer}>
              <Image style={styles.iconInput} source={require("../../assets/images/icon_login_username.png")} />
              <TextInput
                style={styles.input}
                placeholder="Tên đăng nhập"
                autoCapitalize='none'
                onChangeText={(text) => onChangeTextUserName(text)}
              />
            </View>
            <View style={styles.inputContainer}>
              <Image style={styles.iconInput} source={require("../../assets/images/icon_login_password.png")} />
              <TextInput
                style={styles.input}
                placeholder="Mật khẩu"
                secureTextEntry
                onChangeText={text => onChangeTextPassword(text)}
              />
            </View>
            <View style={styles.containerButtonLogin}>
              <Button title="Đăng nhập" onPress={handleLogin} />
            </View>
          </View>
        ) :

          <View style={styles.loadingContainer}>
            <Text style={styles.loadingText}>Loading...</Text>
          </View>}
      </ImageBackground>
    </Pressable>;
}