import { Image, ImageBackground, TextInput, View } from "react-native"
import { styles } from "./login.style"
import { useSelector } from "react-redux";
import { Button, Text } from "react-native-elements";
import { FC } from "react";
interface Props {
  onChangeTextUserName(username: string): void,
  onChangeTextPassword(password: string): void
  handleLogin(): void
}
export const LoginTabletScreen: FC<Props> = ({ onChangeTextUserName, onChangeTextPassword, handleLogin }) => {
  const { loading } = useSelector((state: any) => state.login);

  return <ImageBackground
    resizeMode="stretch"
    source={require("../../assets/images/tab/icon_splashscreen.jpg")}
    style={[styles.container]}
  >
    <View style={{ justifyContent: 'center', alignContent: 'center', flex: 1 }}>
      {!loading && (
        <View style={styles.loginTabContainer}>
          <View style={{ backgroundColor: 'white', padding: 30 }}>
            <View style={[styles.inputContainer, styles.inputExTabContainer]}>
              <Image style={styles.iconInput} source={require("../../assets/images/icon_login_username.png")} />
              <TextInput
                style={styles.input}
                placeholder="Tên đăng nhập"
                autoCapitalize='none'
                onChangeText={(text) => onChangeTextUserName(text)}
              />
            </View>
            <View style={[styles.inputContainer, styles.inputExTabContainer]}>
              <Image style={styles.iconInput} source={require("../../assets/images/icon_login_password.png")} />
              <TextInput
                style={styles.input}
                placeholder="Mật khẩu"
                secureTextEntry
                onChangeText={text => onChangeTextPassword(text)}
              />
            </View>
            <View style={styles.containerButtonLogin}>
              <Button title="Đăng nhập" onPress={handleLogin} />
            </View>
          </View>
        </View>
      )}
    </View>
    {loading &&
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    }
  </ImageBackground>
}