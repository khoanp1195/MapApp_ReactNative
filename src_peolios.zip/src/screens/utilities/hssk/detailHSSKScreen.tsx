import { StyleSheet, View } from "react-native"
import WebView from "react-native-webview"
import { currentUserStore, getFullLink } from "../../../config/constants"
import { useNavigation, useRoute } from "@react-navigation/native";
import { ModalTopBar } from "../../../components/modalTopBar";
import { CustomFastImage } from "../../../components/custom_fast_image";
import { Text } from "react-native-elements";
import { convertStringToMoment } from "../../../utils/functions";
import { useDispatch } from "react-redux";
import { endLoading, startLoading } from "../../../stores/loading/actions";

export const DetailHSSKScreen = () => {
  const route = useRoute();
  const dispatch= useDispatch();
  const navigation = useNavigation();
  // @ts-ignore
  const url = route.params["url"];
  // @ts-ignore
  const title = route.params["title"];

  return <View style={{ flex: 1, backgroundColor: 'white' }}>

    <ModalTopBar
      title={title}
      onPress={() => {
        navigation.goBack();
      }}
    />
    {
      url.includes("Statistics") && <View style={styles.profileContainer}>
        <CustomFastImage
          defaultImage={require('../../../assets/images/avatar80.jpg')}
          urlOnline={getFullLink() + '/' + currentUserStore.getCurrentUser().ImagePath}
          styleImg={styles.profileImage}
        />
        <Text style={styles.profileName}>{currentUserStore.getCurrentUser().Title}</Text>
        <View style={styles.rowContainer}>
          <Text style={styles.label}>Ngày sinh:</Text>
          <Text style={styles.value}>{
            currentUserStore.getCurrentUser().Birthday != null ?
              convertStringToMoment(currentUserStore.getCurrentUser().Birthday).format("DD/MM/yyyy") :
              ""
          }</Text>
        </View>
      </View>
    }

    <WebView
      style={{ flex: 1 }}
      originWhitelist={["*"]}
      source={{ uri: getFullLink() + url }}
      mixedContentMode="compatibility"
      javaScriptEnabled
      domStorageEnabled
      sharedCookiesEnabled
      thirdPartyCookiesEnabled
      setSupportMultipleWindows={false}
      onShouldStartLoadWithRequest={request => {
        console.log("request.url",request.url);
        if(request.url.includes("Records_Grid")) {
          dispatch(startLoading());
          navigation.goBack();
          dispatch(endLoading());
          return false;
        }
        return true;
      }}
      />
  </View>
}
const styles = StyleSheet.create({
  profileContainer: {
    alignItems: 'center',
    padding: 15,
  },
  profileImage: {
    height: 125,
    width: 125,
    borderRadius: 100,
  },
  profileName: {
    textAlign: 'center',
    fontSize: 20,
    fontWeight: 'bold',
    color: 'black',
    marginTop: 10,
  },
  rowContainer: {
    flexDirection: 'row',
  },
  label: {
    textAlign: 'center',
    fontSize: 14,
    color: 'black',
    marginTop: 10,
  },
  value: {
    textAlign: 'center',
    fontSize: 14,
    color: 'black',
    marginTop: 10,
  },
})