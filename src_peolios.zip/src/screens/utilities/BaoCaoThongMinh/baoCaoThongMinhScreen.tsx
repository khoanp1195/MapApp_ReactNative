import { Text, View } from "react-native";
import { PetroAppBarCustom } from "components/petro_appbar_custom.tsx";
import { showLeftMenuDangKyXuatAn } from "stores/leftmenu/actions.ts";
import { WebView } from "react-native-webview";
import { BASE_URL, getFullLink, subsiteStore } from "../../../config/constants.ts";
import React, { useRef, useState } from "react";
import { ModalTopBar } from "../../../components/modalTopBar.tsx";
import { useDispatch } from "react-redux";
import { redirectParentView } from "../../../stores/base_screen/actions.ts";

export const BaoCaoThongMinhScreen = () => {
  const dispatch = useDispatch();
  const [currentUrl, setCurrentUrl] = useState("");
  const webViewRef = useRef(null);
  return <View style={{ flex: 1, marginBottom: 10 }}>
    <ModalTopBar
      title={"Báo cáo thông minh BI"}
      onPress={() => {
        if (currentUrl.includes("View-Report")) {
          // @ts-ignore
          webViewRef.current.injectJavaScript(`window.location.href = '${getFullLink() + "/Pages/mobile/List-Reports.aspx?ismobile=1"}'`);
        } else dispatch(redirectParentView());
      }} />
    <WebView
      ref={webViewRef}
      style={{ flex: 1 }}
      originWhitelist={["*"]}
      source={{ uri: getFullLink() + "/Pages/mobile/List-Reports.aspx?ismobile=1" }}
      mixedContentMode="compatibility"
      javaScriptEnabled
      domStorageEnabled
      sharedCookiesEnabled
      thirdPartyCookiesEnabled
      setSupportMultipleWindows={false}
      onShouldStartLoadWithRequest={request => {
        setCurrentUrl(request.url);
        return true;
      }}
    />
  </View>;
};
