import { Text, View } from "react-native";
import { FC } from "react";
import { getFullLink } from "../../../../config/constants.ts";
import { CustomFastImage } from "../../../../components/custom_fast_image.tsx";
import { convertStringToMoment, isNullOrEmpty } from "../../../../utils/functions.ts";

interface Props {
  item: any,
}

export const ItemTinNoiBoHorizontal: FC<Props> = ({ item }) => {
  const imgUrl = !isNullOrEmpty(item.ImageThumb) ? JSON.parse(item.ImageThumb).Path : "";
  return <View>
    <CustomFastImage resizeMode={"stretch"} styleImg={{ height: 94, width: 150, borderRadius: 6 }}
                     defaultImage={require("../../../../assets/images/temp_tinnoibo.png")}
                     urlOnline={getFullLink() + imgUrl} />
    <Text style={{ width: 150, height: 55, color: "#000000", fontWeight: "bold", fontSize: 14, marginTop:10 }}
          numberOfLines={3}>{item.Title}</Text>
    <Text style={{ width: 150, color: "#999999", fontSize: 10 }}
          numberOfLines={3}>{isNullOrEmpty(item.Modified) ? "" : convertStringToMoment(item.Modified).format("DD/MM/yyyy")}</Text>
  </View>;
};
