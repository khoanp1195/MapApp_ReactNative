import { Text, View } from "react-native";
import { useDispatch } from "react-redux";
import { useNavigation } from "@react-navigation/native";
import { showLeftMenuDangKyXuatAn } from "../../../stores/leftmenu/actions.ts";
import { WebView } from "react-native-webview";
import { BASE_URL, getFullLink, subsiteStore } from "../../../config/constants.ts";
import React from "react";
import { ModalTopBar } from "../../../components/modalTopBar.tsx";

export const DetailXuatAnScreen=()=>{
  const dispatch= useDispatch();
  const navigation=useNavigation();
  return <View style={{flex:1}}>
    <ModalTopBar
      title={"Đăng ký"}
      onPress={() => {
        // @ts-ignore
        navigation.goBack();
      }} />
    <WebView
      style={{ flex: 1, }}
      originWhitelist={['*']}
      source={{ uri: getFullLink()+"/QLSuatAn/SitePages/MealRegistration.aspx?IsMobile=1"}}
      mixedContentMode="compatibility"
      javaScriptEnabled
      domStorageEnabled
      sharedCookiesEnabled
      thirdPartyCookiesEnabled
      onShouldStartLoadWithRequest={request => {
        console.log("request.url",request.url);
        if(request.url.includes("MealRegistration_ListByDate.aspx?IsMobile=1")) {
          navigation.goBack();
          return false;
        }
        return true;
      }}
    />
  </View>
}
