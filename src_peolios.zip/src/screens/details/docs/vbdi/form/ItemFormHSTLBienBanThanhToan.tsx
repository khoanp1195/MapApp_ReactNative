import { FC } from "react"
import { BeanVBDi } from "../../../../../services/database/models/beanVBDi"
import { View } from "react-native"
import { HeaderValueTextView } from "../../../../../components/headerValueTextView"
import { convertStringToMoment, isNullOrEmpty } from "../../../../../utils/functions"

interface Props {
    dataForm: BeanVBDi
}
export const ItemFormHSTLBienBanThanhToan: FC<Props> = ({ dataForm }) => {
    console.log("ItemFormHSTLBienBanThanhToan");

    return <View>
        <HeaderValueTextView headerText={"Số hợp đồng"}
            valueText={isNullOrEmpty(dataForm.DocumentName) ?
                "" :
                dataForm.DocumentName}
        />
        <HeaderValueTextView headerText={"Đơn vị soạn thảo"} valueText={isNullOrEmpty(dataForm.DepartmentTitle) ? "" : dataForm.DepartmentTitle} />
        <HeaderValueTextView headerText={"Nội dung"} valueText={isNullOrEmpty(dataForm.Subject) ? "" : dataForm.Subject} />
        <HeaderValueTextView headerText={"Ngày ký"}
            valueText={dataForm.ReceivedDate != null ?
                convertStringToMoment(dataForm.ReceivedDate).format("DD/MM/YY") :
                ""} />
        <HeaderValueTextView headerText={"Nơi lưu"} valueText={isNullOrEmpty(dataForm.NoiLuu) ? "" : dataForm.NoiLuu} />
        <HeaderValueTextView headerText={"Lĩnh vực"} valueText={isNullOrEmpty(dataForm.CodeFieldTitle) ? "" : dataForm.CodeFieldTitle} />
        <HeaderValueTextView headerText={"Hồ sơ"} valueText={isNullOrEmpty(dataForm.HoSoTitle) ? "" : dataForm.HoSoTitle} />
    </View>
}