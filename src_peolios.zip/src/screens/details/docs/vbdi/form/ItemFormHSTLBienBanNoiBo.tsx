import { Text, View } from "react-native";
import { BeanVBDi } from "../../../../../services/database/models/beanVBDi";
import { FC } from "react";
import { HeaderValueTextView } from "../../../../../components/headerValueTextView";
import { convertStringToMoment, isNullOrEmpty } from "../../../../../utils/functions";
interface Props {
    dataForm: BeanVBDi
}
export const ItemFormHSTLBienBanNoiBo:FC<Props>=({dataForm})=>{
    console.log("ItemFormHSTLBienBanNoiBo");

    return <View>
        <HeaderValueTextView headerText={"Số văn bản"} valueText={isNullOrEmpty(dataForm.DocumentName)?"":dataForm.DocumentName}/>
        <HeaderValueTextView headerText={"Nội dung"} valueText={isNullOrEmpty(dataForm.Subject)?"":dataForm.Subject}/>
        <HeaderValueTextView headerText={"Ngày trình duyệt"} valueText={dataForm.EffectiveDate!=null?convertStringToMoment(dataForm.EffectiveDate).format("DD/MM/YY"):""}/>
        <HeaderValueTextView headerText={"Lĩnh vực"} valueText={isNullOrEmpty(dataForm.CodeFieldTitle)?"":dataForm.CodeFieldTitle}/>
    </View>
}