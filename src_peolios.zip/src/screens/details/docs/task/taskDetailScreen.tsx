import { Button, Image, Keyboard, Text, TouchableOpacity, View, KeyboardAvoidingView } from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { ModalTopBar } from "../../../../components/modalTopBar.tsx";
import { FC, useEffect, useState } from "react";
import {
    getAttFileVBDenByID,
    getDetailVBDenByID,
    getTaskById,
    getVBDenListTask,
    getVBDenWorkflowHistory, getViewerVBDen, getWorkflowHistoryOtherDepartment
} from "../../../../services/api/apiDetailVBDen.ts";
import EmptyView from "../../../../components/empty_view.tsx";
import { ScrollView } from "react-native-gesture-handler";
import { DetailVBDen } from "../../docDetail/detailVBDen.jsx";
import { ListAttachment } from "../../docDetail/listAttachment.jsx";
import { CustomImageButton } from "../../../../components/customImageButton.tsx";
import { appMainBlueColor } from "../../../../utils/color.ts";
import { ListIdea } from "../../../../screens/details/docDetail/listIdea.jsx";
import { ListDepartmentTask } from "../../../../screens/details/docDetail/listDepartmentTask.tsx";
import { ListUnitTask } from "../../../../screens/details/docDetail/listUnitTask.tsx";
import { getDisplayTxtFromDateString, isNullOrEmpty, mapActionTaskVBDen } from "../../../../utils/functions.ts";
import { BottomAction } from "../../../../components/bottomAction.tsx";
import { MoreAction } from "../../../../screens/details/popup/moreAction.tsx";
import { downloadFile } from "../../../../services/api/api_client.ts";
import { useDispatch, useSelector } from "react-redux";
import { LoadingScreen } from "../../../../components/loadingScreen.tsx";
import { EnumTaskAction } from "../../../../config/enum.ts";
import { DetailTask } from "../../docDetail/detailTask.jsx";
import { Any } from "typeorm";
import { showAlert } from "../../../../screens/commonAlertView.jsx";
import { endLoading, startLoading } from "../../../../stores/loading/actions.ts";
import { sendActionTaskVBBH, sendActionTaskVBDen } from "../../../../services/api/apiTaskVB.ts";
import { TaskPopUpContainer } from "../../../../screens/details/popup/taskPopUpContainer.tsx";
import { ClassActionTasks } from "../../../../services/database/models/classActionTasks.ts";
import { openFile } from "../../../../utils/fileUtil.ts";
import { getFullLink } from "../../../../config/constants.ts";
import { getVBBHWorkflowHistory, getViewerVBBH, getWorkflowHistoryOtherDepartmentVBBH } from "../../../../services/api/apiDetailVBBH.ts";

interface Props {
    item: any;
    itemVB: any;
    isVBDen: boolean;
    lstBODIdea: any;
    lstAttachment: any;
}
export const TaskDetailScreen: FC<Props> = ({ item, itemVB, isVBDen, lstBODIdea, lstAttachment }) => {
    const route = useRoute();
    const navigation = useNavigation();
    const dispatch = useDispatch();
    const onLoading = useSelector((state: any) => state.loading.onLoading);


    const [lstAction, setListAction] = useState<ClassActionTasks[] | null>(null);
    const [isShowMoreAction, setShowMoreAction] = useState(false);
    const [isShowPopup, setShowPopup] = useState(false);
    const [indexAction, setIndexAction] = useState(0);
    // const [isPhoiHopChiXem, setIsPhoiHopChiXem] = useState(false);
    const [hasAction, setHasAction] = useState(false);

    const [percentage, setPercentage] = useState(item.Percent);
    const lst_taskState = percentage > 0 ? ["Đang thực hiện", "Tạm hoãn"] : ["Chưa bắt đầu", "Đang thực hiện", "Tạm hoãn"];

    const [taskState, setTaskState] = useState(item.TrangThai);


    useEffect(() => {
        if (item != undefined) {
            if (__DEV__) console.log("action task nè", item.ActionJson)
            //@ts-ignore
            if (!isNullOrEmpty(item.ActionJson)) {
                if (__DEV__) console.log("task nè", JSON.stringify(item))
                const actionMap = mapActionTaskVBDen(getListFromTxt(item.ActionJson));
                setListAction(actionMap as ClassActionTasks[]);
                // setListAction(getListFromTxt(taskVB.ActionJson));
                if (__DEV__) console.log("lstAction nè", JSON.stringify(lstAction))
            }
        }
    }, []);

    useEffect(() => {
        //@ts-ignore
        setHasAction(lstAction != undefined && lstAction.length > 0)
    }, [lstAction]);

    //@ts-ignore
    const getListFromTxt = (txt) => {
        return !isNullOrEmpty(txt) ? JSON.parse(txt) : null;
    };

    //@ts-ignore
    const onClickAttachment = (item) => {
        if (__DEV__)
            console.log(getFullLink() + item.Path);
        //@ts-ignore
        if (Platform.OS == "ios") {
            //@ts-ignore
            navigation.navigate('AttachmentDetailView', { item })
        }
        else {
            downloadFile(item.Path).then(filePath => {
                openFile(filePath);
            })
        }
    };

    const handleTaskAction = (index: number) => {
        onEndEditing();
        console.log(index);
        if (index != 0)
            setIndexAction(index);

        switch (index) {
            case 0:
                setShowMoreAction(true);
                break;
            case EnumTaskAction.Save:
                dispatch(startLoading());
                item.Percent = percentage;
                item.TrangThai = taskState;
                if (__DEV__) console.log("item gửi nè:", JSON.stringify(item))

                if (isVBDen) {
                    sendActionTaskVBDen(EnumTaskAction.Save, item).then(value => {
                        dispatch(endLoading());
                        if (value) {
                            //ToDO reload list
                            navigation.goBack();
                        } else {
                            showAlert("Thao tác không thực hiện được!");
                        }
                    }
                    );
                }
                else {
                    sendActionTaskVBBH(EnumTaskAction.Save, item).then(value => {
                        dispatch(endLoading());
                        if (value) {
                            //ToDO reload list
                            navigation.goBack();
                        } else {
                            showAlert("Thao tác không thực hiện được!");
                        }
                    });
                }
                return;
            case EnumTaskAction.Completed:
            case EnumTaskAction.Feedback:
                setShowPopup(true);
                break;
            case EnumTaskAction.Assignment:
                // @ts-ignore
                navigation.navigate("AssignTaskScreen",
                    {
                        taskVB: item,//detailVanBanDen,
                        // btnAction: index,
                        VB: itemVB,
                        isVBDen: isVBDen
                    }
                );
                break;
            default:
                if (__DEV__) console.log("ID action tào lao gòi nhen")
                break;
        }
    };

    const onClickTaskState = () => {
        console.log("TaskState nè: " + item.TrangThai, "Danh sách tình trạng nè: ", JSON.stringify(lst_taskState));

        //@ts-ignore
        navigation.navigate("TypeSelectScreen",
            {
                data: lst_taskState,
                title: "Tình trạng",
                selectedTitle: taskState != undefined ? taskState : "",
                onSelected: (item: any) => {
                    setTaskState(item);
                    console.log('itemitem', item);
                },
                isSimpleSelectView: true,
            });
    };

    const didFinishedEditting = (percent: string) => {
        setPercentage(percent);
    };

    const onEndEditing = () => {
        Keyboard.dismiss()
    }

    return <View style={{ flex: 1 }}>
        <View style={{ flex: 1 }}>

            <ModalTopBar
                title={""}
                rightAction={
                    item != null && item != undefined
                        ? <TouchableOpacity onPress={() => {
                            // @ts-ignore
                            navigation.navigate("RootWorkflowHistory", {
                                // @ts-ignore
                                getWorkflowHistory: () => isVBDen ? getVBDenWorkflowHistory(itemVB.DocumentID ?? itemVB.ID) : getVBBHWorkflowHistory(itemVB.DocumentID ?? itemVB.ID),
                                // @ts-ignore
                                getViewer: () => isVBDen ? getViewerVBDen(itemVB.DocumentID ?? itemVB.ID) : getViewerVBBH(itemVB.DocumentID ?? itemVB.ID),
                                // @ts-ignore
                                getOtherDepartment: () => isVBDen ? getWorkflowHistoryOtherDepartment(itemVB.DocumentID ?? itemVB.ID) : getWorkflowHistoryOtherDepartmentVBBH(itemVB.DocumentID ?? itemVB.ID),
                                isVBDen: isVBDen,
                                itemVB: itemVB
                            });
                        }}>
                            <Image style={{ height: 25, width: 25 }} resizeMode={"stretch"}
                                source={require("../../../../assets/images/icon_proce.png")} />
                        </TouchableOpacity>
                        :
                        <View />
                }
                onPress={() => {
                    navigation.goBack();
                }} />

            {
                item != null && item != undefined
                    ? <View style={{ flex: 1 }}>

                        <View style={{ width: "100%", alignSelf: "baseline", flexDirection: "row" }}>
                            <Text style={{ flex: 1, fontWeight: "bold", margin: 10 }}>{item.Title}</Text>
                        </View>

                        <KeyboardAvoidingView style={{
                            flex: 1,
                            backgroundColor: "white"
                        }}>
                            <ScrollView style={{ flex: 1, backgroundColor: "white" }}
                                onScroll={() => {
                                    //onEndEditing() 
                                }}
                            >
                                <View style={{ flex: 1, backgroundColor: "white", marginHorizontal: 10 }}>
                                    {
                                        //@ts-ignore
                                        lstAttachment != null && lstAttachment.length > 0 ?
                                            <ListAttachment data={lstAttachment} onClick={(item: any) => onClickAttachment(item)} />
                                            : null
                                    }
                                    {
                                        //@ts-ignore
                                        lstBODIdea != null && lstBODIdea.length > 0 ? <ListIdea data={lstBODIdea} />
                                            : null
                                    }
                                    <DetailTask task={item}
                                        onClickStateEditting={() => { onClickTaskState() }}
                                        didFinishedEditting={(text: string) => { didFinishedEditting(text) }}
                                        // onEndEditing={() => { onEndEditing() }}
                                        defaultPercentage={percentage}
                                        hasAction={hasAction}
                                        state={taskState}
                                    />
                                </View>
                            </ScrollView>
                        </KeyboardAvoidingView>
                        {
                            //@ts-ignore
                            hasAction &&
                            < View style={{ width: "100%", height: 60 }}>
                                <BottomAction data={lstAction} onPressAction={handleTaskAction} />
                            </View>
                        }
                    </View>
                    :
                    <EmptyView />
            }
        </View>

        {
            isShowMoreAction && <MoreAction actionJson={lstAction} onPressAcion={handleTaskAction}
                onPressCancel={() => setShowMoreAction(false)} />
        }

        {
            isShowPopup && <TaskPopUpContainer
                //@ts-ignore
                action={lstAction.find(item => item.ID == indexAction)}
                cancelPress={() => setShowPopup(false)}
                itemVB={item}
                isVBDen={isVBDen}
            />
        }
        {onLoading && <LoadingScreen />}
    </View >;
};
