import { Image, Platform, TouchableOpacity, View, ActivityIndicator, Dimensions } from "react-native"
// import { Share } from "react-native"
import Share from 'react-native-share';
import { WebView } from 'react-native-webview';
import { BASE_URL } from "../../../config/constants.ts";
import { useNavigation, useRoute } from "@react-navigation/native";
import { ModalTopBar } from "../../../components/modalTopBar.tsx";
import ReactNativeBlobUtil from "react-native-blob-util";
import { isNullOrEmpty } from "../../../utils/functions.ts";
import { appMainBlueColor } from "../../../utils/color.ts";
import { downloadFile, downloadFile2 } from "../../../services/api/api_client.ts";
import { showAlert } from "../../../screens/commonAlertView.jsx";
import { useState } from "react";

export const AttachmentDetailView = () => {
    const route = useRoute()
    const navigation = useNavigation()

    const [isLoading, setIsLoading] = useState(true)
    // @ts-ignore
    const item = route.params["item"]
    let fileName = item.Path.split('/').pop()
    let encodeFilePath = item.Path.replace(fileName, encodeURI(fileName))
    const link = BASE_URL + encodeFilePath
    if (__DEV__)
        console.log("Link attachment nè: " + link)

    const onClickDownload = () => {
        if (!isNullOrEmpty(encodeFilePath)) {
            downloadFile(encodeFilePath)
                .then((path) => {

                    if (__DEV__)
                        console.log("FilePath nè: ", path)
                    // path = "data/Containers/Data/Application/5BD5E688-5C90-44FF-B962-C2A4C3790B3A/Documents/File%20Excel%20Ky%20So221220231025045361.xlsx";
                    //@ts-ignore
                    if (!isNullOrEmpty(path)) {
                        let options = {
                            url: `file://${path}`,
                            title: item.Title,
                            // saveToFiles: true,
                        };
                        Share.open(options)
                            .then(r => {
                                if (r.success) {

                                }
                                else
                                    if (__DEV__)
                                        console.log(r);
                            })
                            .catch(e => {
                                e && __DEV__ && console.log("Lỗi shareFile nè: " + JSON.stringify(e));
                            });

                        // Share.share({
                        //     url: path,
                        //     title: item.Title,
                        // }).catch(e => {
                        //     e && __DEV__ && console.log("Lỗi shareFile nè: " + JSON.stringify(e));
                        // });
                    }
                    else {
                        if (__DEV__)
                            console.log("FilePath rỗng nè")
                    }
                });
        }
        else {
            if (__DEV__)
                console.log("user null gòi")
        }
    }

    const hideLoading = () => {
        setIsLoading(false)
    }

    return (
        <View style={{ flex: 1 }}>
            <ModalTopBar
                title={item.Title}
                isTitleCenter={true}
                rightAction={<TouchableOpacity onPress={() => {
                    onClickDownload()
                }}>
                    <Image style={{ height: 25, width: 25, tintColor: appMainBlueColor }}
                        resizeMode={"stretch"}
                        source={require("../../../assets/images/icon_Save.png")}
                    />
                </TouchableOpacity>}
                onPress={() => {
                    navigation.goBack();
                }} />

            <WebView
                style={{ flex: 1, }}
                originWhitelist={['*']}
                source={{ uri: link }}
                mixedContentMode="compatibility"
                javaScriptEnabled
                domStorageEnabled
                sharedCookiesEnabled
                thirdPartyCookiesEnabled
                onLoadEnd={() => hideLoading()}
            />

            {isLoading && <ActivityIndicator
                size="small"
                style={{
                    position: "absolute",
                    width: Dimensions.get('window').width,
                    height: Dimensions.get('window').height / 2,
                }}
            />}
        </View>
    )
}