import { Image, Text, TouchableOpacity, View } from "react-native";
import { WorkflowHistoryScreen } from "./workflowHistoryScreen.tsx";
import { useEffect, useState } from "react";
import { mapLstDataIntoListSection } from "../../../../utils/functions.ts";
import {
  getVBDenWorkflowHistory,
  getVBDenWorkflowHistoryOtherDepartment, getViewerVBDen,
  getWorkflowHistoryOtherDepartment
} from "../../../../services/api/apiDetailVBDen.ts";
import { useNavigation, useRoute } from "@react-navigation/native";
import EmptyView from "../../../../components/empty_view.tsx";
import { ModalTopBar } from "../../../../components/modalTopBar.tsx";
import { getVBDenWorkflowHistoryOtherDepartmentVBBH } from "../../../../services/api/apiDetailVBBH.ts";

export const WorkflowOtherDepartment = () => {
  const route = useRoute();
  // @ts-ignore
  const isVBDen = route.params["isVBDen"];
  // @ts-ignore
  const itemVB = route.params["itemVB"];
  // @ts-ignore
  const itemDepartment = route.params["itemDepartment"];

  const [workflowHistory, setWorkflowHistory] = useState();
  const [isLoading, setIsLoading] = useState(true);
  const navigation = useNavigation();
  useEffect(() => {
    if (isVBDen)
      getVBDenWorkflowHistoryOtherDepartment(itemVB.ID, itemDepartment.DepartmentId).then((value: any) => {
        const dataMap = mapLstDataIntoListSection(value, "Position");
        // @ts-ignore
        setWorkflowHistory(dataMap);
        setIsLoading(false);
      });
    else
    {
      getVBDenWorkflowHistoryOtherDepartmentVBBH(itemVB.ID, itemDepartment.ID).then((value: any) => {
        const dataMap = mapLstDataIntoListSection(value, "Position");
        // @ts-ignore
        setWorkflowHistory(dataMap);
        setIsLoading(false);
      });
    }
  }, []);
  return <View style={{ flex: 1 }}>
    <ModalTopBar
      title={""}
      onPress={() => {
        navigation.goBack();
      }} />
    {
      // @ts-ignore
      workflowHistory != undefined && workflowHistory.length > 0 ?
        <WorkflowHistoryScreen data={workflowHistory} /> : isLoading ? <View /> : <EmptyView />
    }
  </View>;

};
