import { Image, Text, TouchableOpacity, View } from "react-native";
import { WorkflowHistoryScreen } from "./workflowHistoryScreen.tsx";
import { useEffect, useState } from "react";
import { mapLstDataIntoListSection } from "../../../../utils/functions.ts";

import { useNavigation, useRoute } from "@react-navigation/native";
import EmptyView from "../../../../components/empty_view.tsx";
import { ModalTopBar } from "../../../../components/modalTopBar.tsx";
import { getVBDenWorkflowHistoryOtherDepartmentVBBH } from "../../../../services/api/apiDetailVBBH.ts";
import { getWorkflowHistoryVBDi } from "../../../../services/api/apiDetailVBDi.ts";

export const WorkflowHistoryVBDi = () => {
  const route= useRoute();
  // @ts-ignore
  const itemVB = route.params["itemVB"];

  const [workflowHistory, setWorkflowHistory] = useState();
  const [isLoading, setIsLoading] = useState(true);
  const navigation = useNavigation();
  useEffect(() => {
    getWorkflowHistoryVBDi(itemVB.ID, itemVB.SPListId).then((value: any) => {
      const dataMap = mapLstDataIntoListSection(value, "GroupText");
      // @ts-ignore
      setWorkflowHistory(dataMap);
      setIsLoading(false);
    });
  }, []);
  return <View style={{ flex: 1 }}>
    <ModalTopBar
      title={""}
      onPress={() => {
        navigation.goBack();
      }} />
    {
      // @ts-ignore
      workflowHistory != undefined && workflowHistory.length > 0 ?
        <WorkflowHistoryScreen data={workflowHistory} isVBDi={true} /> : isLoading ? <View /> : <EmptyView />
    }
  </View>;

};
