import { Text, View } from "react-native"
import TextRequire from "../../../components/textRequire"
import { TouchableOpacity } from "react-native-gesture-handler"
import { BeanUser } from "../../../services/database/models/bean_user"
import { useNavigation } from "@react-navigation/native"
import { TypeSelectUser } from "../../../config/enum"
import { FC } from "react"
import { FormOnlyComment } from "./formOnlyComment"
import { PlaceholderText } from "../../../components/placeholderText"
interface PropsChuyenXuLyVBDi {
    onChangeText(text: string): void,
    selectedUser: BeanUser,
    setSelectedUser(user: BeanUser): void,
    isBSTT:boolean,
    UserBSST:string
}
export const PopupActionSelectUserAndComment: FC<PropsChuyenXuLyVBDi> = ({ onChangeText, selectedUser, setSelectedUser,isBSTT,UserBSST }) => {
    return <View>
        <FormNguoiDuocChuyenXuXy selectedUser={selectedUser} setSelectedUser={setSelectedUser} isBSTT={isBSTT} UserBSST={UserBSST} />
        <FormOnlyComment isRequire={false} onChangeText={onChangeText} isForce={false}  />
    </View>
}
interface PropsFormNguoiDuocChuyenXuXy {
    selectedUser: BeanUser,
    setSelectedUser(user: BeanUser): void,
    isBSTT:boolean,
    UserBSST:string

}
export const FormNguoiDuocChuyenXuXy: FC<PropsFormNguoiDuocChuyenXuXy> = ({ selectedUser, setSelectedUser, isBSTT,UserBSST}) => {
    const navigation = useNavigation();
    const onClickCC = () => {
        //@ts-ignore
        navigation.navigate("SelectUserScreen",
            {   
                typeSelect: TypeSelectUser.Single,
                usersSelected: selectedUser,
                onSelectApply: (users: any) => {
                    setSelectedUser(users);
                },
                beanTask: null,
                result: UserBSST
            });
    }
    return <View style={{ marginBottom: 10 }}>
        <View style={{ flexDirection: 'row', marginBottom: 10 }}>
            <Text>Người được {isBSTT?"yêu cầu bổ sung":"chuyển xử lý"}</Text>
            <TextRequire />
        </View>
        <TouchableOpacity onPress={onClickCC}>
            <PlaceholderText
                placeholder="Vui lòng chọn người được chuyển xử lý" 
                containerStyle={{ borderRadius: 10, borderColor: "#E5E5E5", borderWidth: 1, padding: 10 }}
                text={selectedUser != undefined ? selectedUser.Title : ""}
                textStyle={{ color: 'black' }} />
        </TouchableOpacity>
    </View>
}