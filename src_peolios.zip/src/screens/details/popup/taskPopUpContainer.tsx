import { Image, Pressable, Text, TextInput, View } from "react-native";
import { getRequireImageAction, isNullOrEmpty } from "../../../utils/functions.ts";
import { EnumTaskAction, EnumTaskRole } from "../../../config/enum.ts";
import { useState } from "react";
import { useNavigation, useRoute } from "@react-navigation/native";
import { DbServices } from "../../../services/database/db_service.ts";
import { subsiteStore } from "../../../config/constants.ts";
import { sendActionVanBanDen } from "../../../services/api/apiDetailVBDen.ts";
import { showAlert } from "../../../screens/commonAlertView.jsx";
import { useDispatch, useSelector } from "react-redux";
import { endLoading, startLoading } from "../../../stores/loading/actions.ts";
import { redirectScreen } from "../../../stores/base_screen/actions.ts";
import { sendActionTaskVBBH, sendActionTaskVBDen } from "../../../services/api/apiTaskVB.ts";
import { FormOnlyComment } from "./formOnlyComment.tsx";

///Chỉ dùng cho ViewNhiemVuDaPhanCong dueDate, selectedUser
// @ts-ignore
export const TaskPopUpContainer = ({ action, cancelPress, itemVB, dueDate = undefined, selectedUser = undefined, isVBDen = false }) => {
    // const route = useRoute();
    const dispatch = useDispatch();
    const navigation = useNavigation();
    let yKien = "";
    //@ts-ignore
    const onLoading = useSelector((state) => state.loading.onLoading);

    const ContentOnlyEditText = () => {
        switch (action.ID) {
            case EnumTaskAction.Completed:
            case EnumTaskAction.Feedback:
            case EnumTaskAction.Assignment:
                return <FormOnlyComment isRequire={false} onChangeText={(text: string) => { yKien = text; }} isForce={action.ID == EnumTaskAction.Completed} />;
            default:
                if (__DEV__) console.log("ID action tào lao gòi nhen")
                return <View />;
        }
    };

    const submitAction = () => {

        itemVB.YKienChiDao = yKien;
        itemVB.YKienCuaNguoiGiaiQuyet = yKien;
        if (dueDate != undefined) { itemVB.DueDate = dueDate; }
        if (selectedUser != undefined) {
            //@ts-ignore
            itemVB.AssignedToUserValue = selectedUser.AccountID + ";#" + selectedUser.Name;
        }
        dispatch(startLoading());
        cancelPress();

        if ((itemVB.Role == EnumTaskRole.Assignor || itemVB.Role == EnumTaskRole.AssignorPBan) && action.ID == EnumTaskAction.Assignment)
            action.ID = EnumTaskAction.Save

        if (isVBDen) {
            sendActionTaskVBDen(action.ID, itemVB).then(
                value => {
                    dispatch(endLoading());
                    if (value) {
                        //ToDO reload list
                        navigation.goBack();
                    } else {
                        showAlert("Thao tác không thực hiện được!");
                    }
                }
            );
        }
        else {
            sendActionTaskVBBH(action.ID, itemVB).then(
                value => {
                    dispatch(endLoading());
                    if (value) {
                        //ToDO reload list
                        navigation.goBack();
                    } else {
                        showAlert("Thao tác không thực hiện được!");
                    }
                }
            );
        }

    };

    return <Pressable
        onPress={() => {
            cancelPress();
        }}
        style={{
            position: "absolute",
            height: "100%",
            width: "100%",
            backgroundColor: "#19191EB2",
            alignItems: "center",
            justifyContent: "center"
        }}>
        <Pressable style={{ backgroundColor: "white", width: "90%", borderRadius: 10 }}>
            <View style={{ flexDirection: "row", borderBottomWidth: 0.7, borderBottomColor: "#f4f4f4", padding: 10 }}>
                <Image
                    style={{ height: 25, width: 25, marginRight: 10 }}
                    resizeMode={"contain"}
                    source={getRequireImageAction(action.ID, action.Class)}
                />
                <Text style={{ color: "#0072c6", fontSize: 15 }}>{action.Title}</Text>
            </View>
            <View style={{ padding: 10 }}>
                <ContentOnlyEditText />
            </View>
            <View style={{ flexDirection: "row", padding: 10 }}>
                <View style={{ flex: 1 }} />
                <View style={{ flex: 1, flexDirection: "row" }}>
                    <Pressable onPress={() => {
                        cancelPress();
                    }} style={{ flex: 1 }}><Text
                        style={{ flex: 1, textAlign: "center", color: "#f65a5b", padding: 10 }}>Thoát</Text></Pressable>
                    <Pressable
                        onPress={() => {
                            submitAction();
                        }}
                        style={{
                            flex: 1,
                            backgroundColor: "#0072C6",
                            padding: 10,
                            borderRadius: 6
                        }}>
                        <Text style={{
                            textAlign: "center",
                            backgroundColor: "#0072C6",
                            color: "white",
                            borderRadius: 6
                        }}>Đồng ý</Text>
                    </Pressable>
                </View>
            </View>
        </Pressable>
    </Pressable>;
};
