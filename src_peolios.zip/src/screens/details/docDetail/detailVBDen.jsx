import { StyleSheet, View } from "react-native"
import { Text } from "react-native-elements"
import { isNullOrEmpty } from "../../../utils/functions"
import moment from "moment";
import { getDisplayTxtFromDateString } from '../../../utils/functions.ts'

export const DetailVBDen = ({ vBDen }) => {
    moment.locale('en');
    return (
        <View style={styles.basicStyle}>
            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Loại văn bản</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>
                {!isNullOrEmpty(vBDen.DocumentType) && vBDen.DocumentType.split(';#').length > 0 ? vBDen.DocumentType.split(';#')[vBDen.DocumentType.split(';#').length - 1] : ""}
            </Text>
            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Nơi gửi</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{vBDen.CoQuanGuiText}</Text>

            <View style={styles.basicStyle}>
                <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                    <Text style={styles.titleTextStyle}>Ngày trên văn bản</Text>
                    <Text style={styles.titleTextStyle}>Ngày đến</Text>
                </View>
                <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                    <Text style={styles.valueTextStyle}>{getDisplayTxtFromDateString(vBDen.DocumentDate)}</Text>
                    <Text style={styles.valueTextStyle}>{getDisplayTxtFromDateString(vBDen.ReceivedDate)}</Text>
                </View>
                <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                    <Text style={styles.titleTextStyle}>Số đến</Text>
                    <Text style={styles.titleTextStyle}>Độ khẩn</Text>
                </View>
                <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                    <Text style={styles.valueTextStyle}>{vBDen.SoDen}</Text>
                    <Text style={styles.valueTextStyle}>{vBDen.DoKhan}</Text>
                </View>
                <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                    <Text style={styles.titleTextStyle}>Độ mật</Text>
                    <Text style={styles.titleTextStyle}>Thời hạn giải quyết</Text>
                </View>
                <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                    <Text style={styles.valueTextStyle}>{vBDen.DoMat}</Text>
                    <Text style={styles.valueTextStyle}>{getDisplayTxtFromDateString(vBDen.DueDate)}</Text>
                </View>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    basicStyle: {
        flex: 1,
        margin: 5,
    },
    titleTextStyle: {
        flex: 1,
        fontSize: 13,
        color: 'darkgray',
    },
    valueTextStyle: {
        flex: 1,
        fontSize: 15,
        color: 'black',
    },
})