import { StyleSheet, View } from "react-native"
import { Text } from "react-native-elements"
import { isNullOrEmpty } from "../../../utils/functions.ts"
import moment from "moment";
import { getDisplayTxtFromDateString, getTextFromFormatText } from '../../../utils/functions.ts'
import { BeanVBBH } from "../../../services/database/models/beanVBBH.ts";
import { FC } from "react";
interface Props{
    vBBH:BeanVBBH
}
export const DetailVBBH:FC<Props> = ({vBBH}) => {
    moment.locale('en');

    const getStringTxt = (text:string) => {
        let resTxt = ""
        if (!isNullOrEmpty(text)) {
            const txt = text.split(';#')
            if (txt.length > 0) {
                for (let index = 1; index < txt.length; index += 2) {
                    resTxt += txt[index] + "; ";
                }
                resTxt = resTxt.substring(0, resTxt.length - 2)
            }
        }
        return resTxt
    }

    return (
        <View style={styles.basicStyle}>
            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Số văn bản</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{vBBH.Title}</Text>

            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Loại văn bản</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{getTextFromFormatText(vBBH.DocumentType)}</Text>

            <View style={styles.basicStyle}>
                <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                    <Text style={styles.titleTextStyle}>Sổ văn bản</Text>
                    <Text style={styles.titleTextStyle}>Ngày ban hành</Text>
                </View>
                <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                    <Text style={styles.valueTextStyle}>{getTextFromFormatText(vBBH.SoVanBan)} </Text>
                    <Text style={styles.valueTextStyle}>{getDisplayTxtFromDateString(vBBH.ReceivedDate)}</Text>
                </View>
            </View>

            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Người ký văn bản</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{getTextFromFormatText(vBBH.NguoiKyVanBanText)}</Text>

            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Chức vụ</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{getTextFromFormatText(vBBH.ChucVu)}</Text>

            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Người soạn thảo</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{vBBH.NguoiSoanThaoText}</Text>

            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Đơn vị soạn thảo</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{getTextFromFormatText(vBBH.DonViSoanThao)}</Text>

            <View style={styles.basicStyle}>
                <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                    <Text style={styles.titleTextStyle}>Độ mật</Text>
                    <Text style={styles.titleTextStyle}>Độ khẩn</Text>
                </View>
                <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                    <Text style={styles.valueTextStyle}>{vBBH.DoMat}</Text>
                    <Text style={styles.valueTextStyle}>{vBBH.DoKhan}</Text>
                </View>
            </View>

            <Text style={[styles.valueTextStyle, styles.basicStyle, { fontWeight: 'bold' }]}>Danh sách nhận văn bản qua mạng</Text>
            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Cá nhân</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{!isNullOrEmpty(vBBH.PeopleText)
                ? vBBH.PeopleText.substring(0, vBBH.PeopleText.length - 2)
                : ""}
            </Text>
            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Đơn vị</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{getStringTxt(vBBH.DonVi)}</Text>

            <Text style={[styles.valueTextStyle, styles.basicStyle, { fontWeight: 'bold' }]}>Danh sách nhận văn bản ngoài hệ thống</Text>
            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Đơn vị</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{getStringTxt(vBBH.LTDonVi)}</Text>

        </View>
    )
}

const styles = StyleSheet.create({
    basicStyle: {
        flex: 1,
        margin: 5,
    },
    titleTextStyle: {
        flex: 1,
        fontSize: 13,
        color: 'darkgray',
    },
    valueTextStyle: {
        flex: 1,
        fontSize: 15,
        color: 'black',
    },
})