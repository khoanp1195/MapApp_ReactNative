import { StyleSheet, TextInput, View, Image, TouchableOpacity, Keyboard } from "react-native"
import { Text } from "react-native-elements"
import { isNullOrEmpty } from "../../../utils/functions.ts"
import moment from "moment";
import { getDisplayTxtFromDateString, getTextFromFormatText } from '../../../utils/functions.ts'
import { TextEditorWithBorder } from "../../../components/customTextEditor.tsx";
import { useEffect, useState } from "react";
import { showAlert } from "../../../screens/commonAlertView.jsx";

export const DetailTask = ({ task, didFinishedEditting, onClickStateEditting, defaultPercentage, hasAction, state }) => {
    const [hoSoDuThaoTitle, setHoSoDuThaoTitle] = useState("");
    const [percentage, setPercentage] = useState(defaultPercentage);
    useEffect(() => {
        if (task.HoSoDuThaoUrl != undefined && task.HoSoDuThaoUrl != null) {
            try {
                setHoSoDuThaoTitle(task.HoSoDuThaoUrl["Title"]);
            } catch (error) {
                console.log("Lấy thông tin hồ sơ lưu trữ lỗi nè: " + JSON.stringify(error));
                setHoSoDuThaoTitle("");
            }
        }
        // setTaskStateIndex(lst_taskState.findIndex(state => state.toLowerCase() === task.TrangThai));
    }, []);

    // console.log("Task lấy nội dung nè:" + JSON.stringify(task))
    // moment.locale('en');

    const didChangeText = (text) => {
        // Allow only numbers 
        const numericValue = text.replace(/[^0-9]/g, "");
        if (__DEV__)
            console.log("Percentage text nè: " + (numericValue));

        setPercentage(numericValue)
    }

    const didEndEditing = () => {
        if (__DEV__)
            console.log("Percentage nè: " + (percentage));
        const value = Number.parseInt(percentage)
        if (__DEV__)
            console.log("Percentage value nè: " + value);
        if (value < 0 || value > 100) {
            showAlert("Vui lòng chỉ nhập số từ 0 đến 100");
        }
        else {
            didFinishedEditting(percentage);
        }
    }

    return (
        <View style={styles.basicStyle}>
            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Người chuyển</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>
                {
                    task.NguoiChuyenJson != null && !isNullOrEmpty(task.NguoiChuyenJson["Title"])
                        ? task.NguoiChuyenJson["Title"]
                        : task.AssignorText
                }
            </Text>

            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Ý kiến người chuyển</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{getTextFromFormatText(task.YKienChiDao)}</Text>

            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Người nhận</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>
                {
                    task.NguoiNhanJson != null && !isNullOrEmpty(task.NguoiNhanJson["Title"])
                        ? task.NguoiNhanJson["Title"]
                        : !isNullOrEmpty(task.DepartmentTitle) ? task.DepartmentTitle : ""
                }
            </Text>

            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Ý kiến chỉ đạo</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{getTextFromFormatText(task.YKienCuaNguoiGiaiQuyet)}</Text>

            <View style={styles.basicStyle}>
                <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                    <Text style={styles.titleTextStyle}>Ngày bắt đầu</Text>
                    <Text style={styles.titleTextStyle}>Hạn hoàn tất</Text>
                </View>
                <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                    <Text style={styles.valueTextStyle}>
                        {getDisplayTxtFromDateString(task.StartDate)}
                    </Text>
                    <Text style={styles.valueTextStyle}>
                        {
                            // getDisplayTxtFromDateString(task.DueDate)
                            task.DueDate != undefined && task.DueDate != null ? getDisplayTxtFromDateString(task.DueDate)
                                : task.ThoiHanGiaiQuyet != undefined && task.ThoiHanGiaiQuyet != null ? getDisplayTxtFromDateString(task.ThoiHanGiaiQuyet)
                                    : ""
                        }
                    </Text>
                </View>
            </View>

            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Hồ sơ dự thảo</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{hoSoDuThaoTitle}</Text>

            <View style={styles.basicStyle}>
                <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                    <Text style={styles.titleTextStyle}>Tình trạng</Text>
                    <Text style={styles.titleTextStyle}>Tiến độ</Text>
                </View>
                {
                    hasAction ?
                        <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                            <TouchableOpacity
                                style={[styles.basicStyle, styles.customBorderStyle, { flexDirection: 'row', alignItems: 'center' }]}
                                onPress={() => { onClickStateEditting() }}
                            >
                                <Text style={[styles.valueTextStyle, { flex: 1 }]}>{state}</Text>
                                <Image
                                    source={require("../../../assets/images/icon_expand_contact.png")}
                                    style={[styles.customIconInBoxStyle]}
                                    resizeMode='contain'
                                    tintColor='lightgray'
                                />
                            </TouchableOpacity>
                            <View style={[styles.basicStyle, styles.customBorderStyle, { flexDirection: 'row' }]}>
                                <TextInput
                                    // defaultValue={'' + percentage}
                                    value={'' + percentage}
                                    style={[styles.customValueTextStyle, { flex: 1 }]}
                                    onEndEditing={() => {
                                        didEndEditing()
                                    }}
                                    onChangeText={newText => didChangeText(newText)}
                                    //onPressOut={() => { onEndEditing() }}
                                    keyboardType="numeric"
                                />
                                <Text style={[styles.customValueTextStyle, styles.customIconInBoxStyle]}>%</Text>
                            </View>
                        </View> :
                        <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                            <Text style={[styles.valueTextStyle, { flex: 1 }]}>{task.TrangThai}</Text>
                            <Text style={[styles.valueTextStyle, { flex: 1 }]}>{defaultPercentage + " %"}</Text>
                        </View>
                }
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    basicStyle: {
        flex: 1,
        margin: 5,
    },
    titleTextStyle: {
        flex: 1,
        fontSize: 13,
        color: 'darkgray',
    },
    valueTextStyle: {
        flex: 1,
        fontSize: 15,
        color: 'black',
    },
    customBorderStyle: {
        borderWidth: 1,
        borderColor: 'lightgray',
        borderRadius: 5,
        padding: 5,
    },
    customValueTextStyle: {
        fontSize: 14,
        color: 'black',
    },
    customIconInBoxStyle: {
        height: "100%",
        width: 15,
    }
})