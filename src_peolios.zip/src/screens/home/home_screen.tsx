import {
  Dimensions,
  Image,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View
} from "react-native";
import { TestChart } from "./test_chart.tsx";
import { useEffect, useState } from "react";
import { getCount } from "../../services/api/api_home_page.ts";
import { CircleButton } from "../../components/circleButton.tsx";
import { DashBoardButton } from "../../components/dashBoardButton.tsx";
import { PetroAppBarCustom } from "../../components/petro_appbar_custom.tsx";
import { DrawerActions, useNavigation } from "@react-navigation/native";
import { useDispatch, useSelector } from "react-redux";
import { showLeftMenuHome } from "../../stores/leftmenu/actions.ts";
import BaseScreen from "../../components/basescreen.tsx";
import { TinNoiBoComponent } from "../../screens/utilities/tinnoibo/tinNoiBoComponent.tsx";
import { getDashboard } from "../../services/api/apiTinNoiBo.ts";
import { TinNoiBoType, ViewModeTinNoiBo } from "../../config/enum.ts";
import {
  redirectHSLTCuaToi,
  redirectTBScreen,
  redirectTinNoiBo,
  redirectVBDenTitle,
  redirectVBDiTitle,
  redirectVBPHScreen,
  redirectVCXLHighScreen,
  redirectVCXLScreen
} from "../../stores/base_screen/actions.ts";
import { changePageTypeTinNoiBo } from "../../stores/tinnoibo/actions.ts";
import { isTabletMode } from "../../config/constants.ts";
import { CountComponent } from "./countComponent.tsx";

export const HomeScreen = () => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const [dataTinNoiBo, setDataTinNoiBo] = useState();
  const onLoading = useSelector((state: any) => state.loading.onLoading);

  useEffect(() => {
    if (!onLoading ) {    
      getDashboard().then(value => {
        setDataTinNoiBo(value);
      });
    }
  }, [onLoading]);

  const onClickVBDen = () => {
    dispatch(redirectVBDenTitle());
    navigation.dispatch(DrawerActions.closeDrawer());
  }

  const onClickVBPH = () => {
    dispatch(redirectVBDenTitle());
    navigation.dispatch(DrawerActions.closeDrawer());
  }

  return <View style={styles.root}>
    <BaseScreen>
      <View style={{
        backgroundColor: "white",
        height: "100%"
      }}>
        <PetroAppBarCustom
          title={"Trang chủ"}
          rightAction={
            <TouchableOpacity onPress={() => {
              // @ts-ignore
              navigation.navigate("QRScreen");

            }}>
              <Image style={{ height: 30, width: 30 }} source={require("../../assets/images/icon_qr.png")} />
            </TouchableOpacity>
          }
          onPress={() => {
            try {
              dispatch(showLeftMenuHome());
              // @ts-ignore 
              navigation.openDrawer();
              // navigation.dispatch(DrawerActions.openDrawer())
            } catch (e) {
              if (__DEV__)
                console.log("Lỗi gòi: " + e);
            }
          }} />
        <ScrollView style={styles.scrollView}>
          <View
            style={[
              styles.container,
              {
                flexDirection: "row",

              }
            ]}>
            <View style={styles.topButtonContainer}>
              <CircleButton path={require("../../assets/images/icon_vbden_db.png")} title={"VB đến"} onClick={() => {
                dispatch(redirectVBDenTitle());
              }} />
            </View>
            <View style={styles.topButtonContainer}>
              <CircleButton path={require("../../assets/images/icon_vbdi_db.png")} title={"VB đi/Nội bộ"}
                onClick={() => {
                  dispatch(redirectVBDiTitle());
                }} />
            </View>
            <View style={styles.topButtonContainer}>
              <CircleButton path={require("../../assets/images/icon_hslt_db.png")} title={"Hồ sơ lưu trữ"}
                onClick={() => {
                  dispatch(redirectHSLTCuaToi());
                }} />
            </View>
          </View>
          {/*<TestChart countData={data} />*/}
          <View style={{
            flexDirection: isTabletMode ? 'row' : 'column',
            flex: 1
          }}>
            <View style={{ flex: 1 }}>
              <TinNoiBoComponent
                sizeTitle={20}
                title={"Tin nội bộ"}
                data={dataTinNoiBo}
                typeView={TinNoiBoType.DashBoard}
                viewMode={ViewModeTinNoiBo.Horizontal}
                showDot={true}
                showAll={true}
                autoScroll={true}
                onPressAll={() => {
                  dispatch(changePageTypeTinNoiBo(undefined));
                  // @ts-ignore
                  navigation.navigate("TienIch");

                  dispatch(redirectTinNoiBo());
                }}
                showLine={false}
              />
            </View>
            <CountComponent/>
          </View>
        </ScrollView >
      </View >
    </BaseScreen >
  </View >;
};

const styles = StyleSheet.create({
  root: {
    height: "100%"
  },
  scrollView: {
    backgroundColor: "white",
    height: "100%",
    paddingBottom: 20
  },
  container: {
    flex: 1,
    padding: 15
  },
  innerContainer: {
    flex: 1,
    padding: 0
  },
  topButtonContainer: {
    flex: 1,
    height: 70
  },
  viecXLContainer: {
    flex: 1,
    borderRadius: 12,
    margin: 5
  }
});
