import { StyleSheet, Text, View } from "react-native";
import { DashBoardButton } from "../../components/dashBoardButton";
import { useNavigation } from "@react-navigation/native";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { getCount } from "../../services/api/api_home_page";
import { redirectTBScreen, redirectVBPHScreen, redirectVCXLHighScreen, redirectVCXLScreen } from "../../stores/base_screen/actions";

export const CountComponent = () => {
    const dispatch = useDispatch();
    const [data, setData] = useState({ "ThongBao": 0, "VBCanXuLy": 0, "VBCanXuLyHigh": 0, "VBPhoiHop": 0 });
    const refreshHome = useSelector((state: any) => state.refreshHome.refreshHome);

    useEffect(() => {
        if (!refreshHome) {
            getCount().then(value => {
                setData(value);
            });
        }
    }, [refreshHome]);
    return <View style={{ flex: 1 }}>
        <Text style={{ color: "#004374", fontSize: 20, fontWeight: "bold", marginHorizontal: 20, marginTop: 5 }}>Xử lý
            văn bản</Text>
        <View style={{ height: 340 }}>
            <View style={[
                styles.container,
                {
                    flexDirection: "column"
                }
            ]}>
                <View
                    style={[
                        styles.innerContainer,
                        {
                            flexDirection: "row"
                        }
                    ]}>
                    <View style={[styles.viecXLContainer, { backgroundColor: "#DFF1FF" }]}>
                        <DashBoardButton title={"Thông báo (để biết)"}
                            path={require("../../assets/images/icon_db_tb.png")}
                            countNum={data !== undefined ? data.ThongBao : 0}
                            countNumColor={"#004EE1"}
                            handleClick={() => {
                                dispatch(redirectTBScreen());
                            }} />
                    </View>
                    <View style={[styles.viecXLContainer, { backgroundColor: "#D6FFE0" }]}>
                        <DashBoardButton
                            title={"VB phối hợp"}
                            path={require("../../assets/images/icon_db_vbph.png")}
                            countNum={data !== undefined ? data.VBPhoiHop : 0} countNumColor={"#00CF6C"}
                            handleClick={() => {
                                dispatch(redirectVBPHScreen());
                            }} />
                    </View>
                </View>
                <View
                    style={[
                        styles.innerContainer,
                        {
                            flexDirection: "row"
                        }
                    ]}>
                    <View style={[styles.viecXLContainer, { backgroundColor: "#FFF3C4" }]}>
                        <DashBoardButton
                            title={"VB cần xử lý"}
                            path={require("../../assets/images/icon_db_vcxl.png")}
                            countNum={data !== undefined ? (data?.VBCanXuLy ?? 0) - (data?.VBCanXuLyHigh ?? 0) : 0}
                            countNumColor={"#FFCF2C"}
                            handleClick={() => {
                                dispatch(redirectVCXLScreen());
                            }}
                        />
                    </View>
                    <View style={[styles.viecXLContainer, { flex: 1, backgroundColor: "#FFE2CE" }]}>
                        <DashBoardButton
                            title={"VB ưu tiên xử lý sớm"}
                            path={require("../../assets/images/icon_db_vcxl_hight.png")}
                            countNum={data !== undefined ? data.VBCanXuLyHigh : 0}
                            countNumColor={"#FA6400"}
                            handleClick={() => {
                                dispatch(redirectVCXLHighScreen());
                            }}
                        />
                    </View>
                </View>
            </View>
        </View>
    </View>
}
const styles = StyleSheet.create({
    root: {
        height: "100%"
    },
    scrollView: {
        backgroundColor: "white",
        height: "100%",
        paddingBottom: 20
    },
    container: {
        flex: 1,
        padding: 15
    },
    innerContainer: {
        flex: 1,
        padding: 0
    },
    topButtonContainer: {
        flex: 1,
        height: 70
    },
    viecXLContainer: {
        flex: 1,
        borderRadius: 12,
        margin: 5
    }
});