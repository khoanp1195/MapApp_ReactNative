import { View, TextInput } from "react-native";
import { isNullOrEmpty } from "../utils/functions";

//@ts-ignore
export const TextEditorWithBorder = ({ didFinishedEditting, placeHolder = "Vui lòng nhập ý kiến" }) => {
    return (
        <View
            style={{
                flex: 1,
                height: 120,
                backgroundColor: "white",
                borderRadius: 8,
                borderWidth: 1,
                borderColor: "gray",
            }}>
            <TextInput
                multiline
                numberOfLines={4}
                style={{
                    flex: 1,
                    textAlignVertical: 'top',
                }}
                onEndEditing={(text) => { didFinishedEditting(text) }}
                placeholder={!isNullOrEmpty(placeHolder) ? placeHolder : "Vui lòng nhập..."} />
        </View >
    );
};
