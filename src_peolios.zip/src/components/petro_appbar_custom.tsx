import { Image, Text, TouchableOpacity, View } from "react-native";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { isNullOrEmpty } from "../utils/functions.ts";
import { isTabletMode, subsiteStore } from "../config/constants.ts";
import { isTablet } from "../utils/deviceHelper.ts";

// @ts-ignore
export const PetroAppBarCustom = ({ title, onPress, rightAction = <View /> }) => {
  const [site, setSite] = useState("");
  const onLoading=useSelector((state: any) => state.loading.onLoading);

  useEffect(() => {
    if(!onLoading)
    {
      if(isNullOrEmpty(subsiteStore.getSubsite()))
      {
        setSite(!isTabletMode?`- Tập đoàn`:"Tập đoàn");
      }
      else
      {
        setSite(!isTabletMode?`- ${subsiteStore.getSubsite()}`:` ${subsiteStore.getSubsite()}`);
      }
    }
  }, [onLoading]);
  return <View style={{ backgroundColor: "white" }}>
    <View style={{ flexDirection: "row", height: isTabletMode?40: 60, alignItems: "center" }}>
      <View style={{ flexDirection: "row", alignItems: "center", flex: 1 }}>
        <TouchableOpacity onPress={() => {
          onPress();
        }}>
          <Image source={require("../assets/images/icon_menu.png")} tintColor={"#0072C6"}
                 style={{ height: 25, width: 25, marginLeft: 15 }} />
        </TouchableOpacity>
        {
          isTabletMode?
          <View style={{marginLeft:15}}>
            <Text style={{fontSize:15,color:'black'}}>{site}</Text>
            <Text style={{color:'#5E5E5E',fontSize:13}}>{title}</Text>
          </View>:
          <Text style={{ color: "#000000", marginLeft: 15, fontSize: 18 }}>{`${title}  ${site}`}</Text>
        }
      </View>
      <View style={{ marginRight: 15 }}>
        {rightAction}
      </View>
    </View>
    {!isTabletMode&&<View style={{ height: 1, width: "100%", backgroundColor: "#E9E9E9" }} />}
  </View>;
};
