import React from "react";
import { View, Text } from "react-native";
import { useSelector } from "react-redux";
import {
  BaoCaoThongMinhUtil,
  DangKyXuatAn, DatVeMayBay,
  DatVeXe,
  HSLTCuaToi,
  HSLTTatCa,
  LichChoDuyet,
  LichChoXepPhong,
  LichDuKien,
  LichTatCa,
  TBScreen, TinNoiBo,
  VBDenChoChoYKien,
  VBDenChoThucHien,
  VBDenDaGiaiQuyet,
  VBDenTatCa,
  VBDenThongBao,
  VBDenTitle, VBDiChoPheDuyet, VBDiDaPhatHanh, VBDiDaPheDuyet, VBDiTatCa, VBDiThongBao, VBDiTitle,
  VBPHScreenState,
  VCXLHighScreen,
  VCXLScreen
} from "../stores/base_screen/action_types.ts";
import { isNullOrEmpty } from "../utils/functions.ts";
import { VBChoXuLyScreen } from "../screens/docs/menu_no_child/vb_cho_xu_ly/vb_cho_xu_ly_screen.tsx";
import { ThongBaoScreen } from "../screens/docs/menu_no_child/thongbao/thong_bao_screen.tsx";
import { ListCalendarScreen } from "../screens/calendar/listCalendarScreen.tsx";
import { VBPHScreen } from "../screens/docs/menu_no_child/vbph/vbph_screen.tsx";
import { VBDenScreen } from "../screens/docs/vbden/vbden_screen.tsx";
import { VBDiScreen } from "../screens/docs/vbdi/vbdi_screen.tsx";
import { HSTLScreen } from "../screens/docs/hstl/hstl_screen.tsx";
import { AnCaScreen } from "../screens/utilities/SuatAn/anCaScreen.tsx";
import { BaoCaoThongMinhScreen } from "../screens/utilities/BaoCaoThongMinh/baoCaoThongMinhScreen.tsx";
import { DashboardTinNoiBoScreen } from "../screens/utilities/tinnoibo/dashboardTinNoiBoScreen.tsx";
import {  DashboardDatVeMayBayScreen } from "../screens/utilities/datvemaybay/dashboardDatVeMayBayScreen.tsx";
import { DashboardDatVeXeScreen } from "../screens/utilities/datxe/dashboardDatVeXeScreen.tsx";

// @ts-ignore
const BaseScreen = ({ children }) => {
  const screen = useSelector((state: any) => state.baseScreen.screen.toString());
  const ChildScreen = () => {
    switch (screen) {
      case VCXLScreen:
        return <VBChoXuLyScreen isHigh={false} />;
      case VCXLHighScreen:
        return <VBChoXuLyScreen isHigh={true} />;
      case VBPHScreenState:
        return <VBPHScreen />;
      case TBScreen:
        return <ThongBaoScreen />;
      case VBDenTitle:
      case VBDenChoChoYKien:
      case VBDenChoThucHien:
      case VBDenDaGiaiQuyet:
      case VBDenThongBao:
      case VBDenTatCa:
        return <VBDenScreen action={screen} />;
      case VBDiTitle:
      case VBDiChoPheDuyet:
      case VBDiDaPheDuyet:
      case VBDiThongBao:
      case VBDiDaPhatHanh:
      case VBDiTatCa:
        return <VBDiScreen action={screen} />;
      case HSLTTatCa:
        return <HSTLScreen menuId={0} />;
      case HSLTCuaToi:
        return <HSTLScreen menuId={1} />;
      case LichDuKien:
        return <ListCalendarScreen type={4} />;
      case LichChoDuyet:
        return <ListCalendarScreen type={3} />;
      case LichChoXepPhong:
        return <ListCalendarScreen type={2} />;
      case LichTatCa:
        return <ListCalendarScreen type={1} />;
      case DangKyXuatAn:
        return <AnCaScreen />;
      case BaoCaoThongMinhUtil:
        return <BaoCaoThongMinhScreen />;
      case TinNoiBo:
        return <DashboardTinNoiBoScreen />;
      case DatVeMayBay:
        return <DashboardDatVeMayBayScreen />;
        case DatVeXe:
          return <DashboardDatVeXeScreen />;
      default:
        return <View />;
    }
  };

  return (
    <View key={screen} style={{ flex: 1, paddingBottom: 50 }}>
      {isNullOrEmpty(screen) ? children : <ChildScreen />}
    </View>
  );
};

export default BaseScreen;
