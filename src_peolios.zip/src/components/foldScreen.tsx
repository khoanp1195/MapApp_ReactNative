import { FC, useCallback } from "react";
import { View } from "react-native";
import { TopAction } from "./topAction";
import { useSelector } from "react-redux";
import { VBDenDetailScreen } from "../screens/details/docs/vbden/vbden_detail_screen";
import { VBDiDetailScreen } from "../screens/details/docs/vbdi/vbdi_detail_screen";
import { VBBHDetailScreen } from "../screens/details/docs/vbbh/vbbh_detail_screen";
import { DetailHSTLScreen } from "../screens/details/docs/hstl/detail_hstl_screen";
import { Divider } from "react-native-elements";
interface Props {
    TopLeft: React.JSX.Element,
    BottomLeft: React.JSX.Element,

}
export const FoldScreen: FC<Props> = ({ TopLeft, BottomLeft }) => {
    const typeDetail = useSelector((state: any) => state.detailActionTab.type);
    const DetailTab =useCallback( () => {
        console.log("typeDetail",typeDetail);
        if (typeDetail == 'VBDen')
            return <VBDenDetailScreen />
        else if (typeDetail == 'VBDi')
            return <VBDiDetailScreen />
        else if (typeDetail == 'VBBH')
            return <VBBHDetailScreen />;
        else if (typeDetail == 'HSLT')
            return <DetailHSTLScreen />;
        return <View />
    },[typeDetail]);
    return <View style={{ flex: 1, flexDirection: 'row', backgroundColor: '#D1E9FF' }}>
        <View style={{ flex: 1.4 }}>
            <View style={{ height: 50, backgroundColor: 'white' }}>
                {TopLeft}
            </View>
            <View style={{ flex: 1, backgroundColor: 'white', marginTop: 10, marginRight: 10, marginBottom: 20, marginLeft: 10, borderRadius: 5 }}>
                {BottomLeft}
            </View>
        </View>
        <View style={{ flex: 3 }}>
            <TopAction />
            <View style={{ flex: 1, backgroundColor: 'white', marginTop: 10, marginBottom: 20, marginRight: 10, borderRadius: 5, padding: 5 }}>
                <DetailTab />
            </View>
        </View>
    </View>
}