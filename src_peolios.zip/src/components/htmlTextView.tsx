import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { isNullOrEmpty } from '../utils/functions';

//@ts-ignore
const HTMLTextView = ({ html,style }) => {
    const renderHTML = () => {
        const htmlRegex = /<[^>]+>/g;
        const textParts = html.split(htmlRegex);
        const tags = html.match(htmlRegex) || [];
        //@ts-ignore
        return textParts.map((part, index) => {
            if (part.trim() === '') return null;
            return (
                <Text key={index} style={[getStyle(tags[index]),{color:'black', textAlign:'center'}]} >
                    {part}
                    {tags[index] && <HTMLTag tag={tags[index]} />}
                </Text>
            );
        });
    };
    const getTagName = (tag: string) => {
        if (isNullOrEmpty(tag))
            return '';
        else {
            const math = tag.match(/<\/?([a-zA-Z]+)[^>]*>/);
            if (math != null)
                return math[1];
            return tag;
        }
    };
    const getStyle = (tag: string) => {
        switch (getTagName(tag)) {
            case 'b':
            case 'strong':
                return styles.bold;
            case 'i':
            case 'em':
                return styles.italic;
            case 'u':
                return styles.underline;
            // Add more supported tags here
            default:
                return {}; // Default empty style object
        }
    };

    //@ts-ignore
    const HTMLTag = ({ tag }) => {
        const tagName = getTagName(tag);
        const tagContentRegex = /<[^>]+>([^<]+)<\/[^>]+>/;
        const match = tag.match(tagContentRegex);
        const tagContent = match ? match[1] : '';
        switch (tagName) {
            case 'b':
            case 'strong':
                return <Text style={{ fontWeight: 'bold' }}>{tagContent}</Text>;
            case 'i':
            case 'em':
                return <Text style={{ fontStyle: 'italic' }}>{tagContent}</Text>;
            case 'u':
                return <Text style={{ textDecorationLine: 'underline' }}>{tagContent}</Text>;
            case 'a':
                const url = tag.match(/href=['"](.*?)['"]/);
                return (
                    <Text
                        style={{ color: 'blue', textDecorationLine: 'underline' }}
                        onPress={() => handleLinkPress(url[1])}>
                        {tagContent}
                    </Text>
                );
            // Add more supported tags here
            default:
                // If tag not supported, just return the content inside the tag
                return <Text>{tagContent}</Text>;
        }
    };

    const handleLinkPress = (url: string) => {
        // Handle link press here, for example, open the URL in a browser
        // You can use Linking from react-native
        // Example: Linking.openURL(url);
    };

    return <View style={style}>{renderHTML()}</View>;
};
const styles = StyleSheet.create({
    bold: {
        fontWeight: 'bold',
    },
    italic: {
        fontStyle: 'italic',
    },
    underline: {
        textDecorationLine: 'underline',
    },
    // Define more styles here for other tags if needed
});
export default HTMLTextView;
