import { Pressable, Text, View } from "react-native";
import { isTabletMode } from "../config/constants";
import { PhoneModeScreen } from "./phoneModeScreen";

// @ts-ignore
export const FilterComponent = ({ onPressOutSite, children = <View /> }) => {
  return <PhoneModeScreen PhoneMode={
    <View style={{ width: "100%", height: '100%', marginTop: 60, position: 'absolute' }}>
        {children}
        <Pressable onPress={() => {
          onPressOutSite();
        }}>
          <View style={{ width: "100%", height: '100%', backgroundColor: '#00000066' }} />
        </Pressable>
      </View>
  }
  TabletMode={
    <View style={{ width: "100%", height: '100%', position: 'absolute' }}>
        <Pressable onPress={() => {
          onPressOutSite();
        }} style={{ backgroundColor: '#00000066', flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          {children}
        </Pressable>
      </View>
  }/>
}
