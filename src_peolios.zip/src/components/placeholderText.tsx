import { FC } from "react";
import { StyleSheet, Text, TextStyle } from "react-native";
import { View, ViewStyle } from "react-native";

interface Props{
    text:string;
    placeholder:string;
    textStyle:TextStyle;
    containerStyle:ViewStyle;

}
export const PlaceholderText:FC<Props> = ({ text, placeholder,textStyle,containerStyle }) => {
    return (
      <View style={containerStyle}>
        {text ? (
          <Text style={textStyle}>{text}</Text>
        ) : (
          <Text style={styles.placeholder}>{placeholder}</Text>
        )}
      </View>
    );
  };
  const styles = StyleSheet.create({
    placeholder: {
      color: 'gray',
    },
  });