import { FC, useState } from "react"
import { Image, View } from "react-native"
import { downloadFile } from "../services/api/api_client"
import { getFullLink } from "../config/constants"
import { isNullOrEmpty } from "../utils/functions"

interface Props {
    url: string,
    styleImg?: any;

}
export const ErrorTypeImage: FC<Props> = ({ url, styleImg }) => {
    const [imagePath, setImagePath] = useState("");
    downloadFile(url.replace(getFullLink(), ""), false).then((path) => {
        setImagePath(path);
    })
    return isNullOrEmpty(imagePath) ?
        <View>
            <Image style={styleImg} resizeMode="stretch" source={require("../assets/images/avatar80.jpg")} />
        </View>
        :
        <Image style={styleImg} resizeMode="stretch" source={{ uri: `file://${imagePath}` }} />;

}