import { Modal, View } from "react-native"
import { isTabletMode } from "../config/constants"
//@ts-ignore
export const ModalPopup = ({ visible, onClose, children }) => {
    return isTabletMode?
    <Modal
        animationType={isTabletMode?"slide":"none"}
        transparent={true}
        visible={visible}
        onRequestClose={onClose}
    >
        {children}

    </Modal>:
    children
}