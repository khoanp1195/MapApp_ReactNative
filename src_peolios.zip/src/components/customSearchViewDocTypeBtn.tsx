import { Pressable, StyleSheet, Text, View, TouchableOpacity } from "react-native"

// @ts-ignore
export const BtnDocType = ({ title, onClickHandle, textStyle, buttonStyle }) => {
    return (
        <TouchableOpacity
            style={[styles.rootContainer]}
            onPress={() => {
                // console.log("btn is pressed.")
                onClickHandle()
            }}>
            <View style={[styles.button, buttonStyle]}>
                <Text style={[styles.text, textStyle]}>{title}</Text>
            </View>
        </TouchableOpacity >
    );
};

const styles = StyleSheet.create({
    rootContainer: {
        flex: 1,
        alignContent: 'center',
        justifyContent: 'center',
        padding: 5,
    },
    button: {
        flex: 1,
        borderRadius: 5,
        borderWidth: 0,
        borderColor: 'clear',
        justifyContent: 'center',
        flexDirection: 'row',
        alignItems: 'center',
    },
    text: {
        flex: 1,
        textAlign: 'center',
        padding: 5,
    },
});