import { Pressable, TouchableOpacity } from "react-native";
import { Calendar } from "react-native-calendars";
import React from "react";
import moment from "moment";
import { isNullOrEmpty } from "../utils/functions";

// @ts-ignore
export const CustomCalendarView = ({dateFocus, onTouchOutSite, onPressDate }) => {
  console.log("dateFocus",dateFocus)
  return (
    <TouchableOpacity onPress={() => {
      onTouchOutSite();
    }} style={{
      position: "absolute",
      backgroundColor: "#00000066",
      height: "100%",
      width: "100%",
      alignItems: "center",
      justifyContent: "center"
    }}>
      <Pressable style={{ backgroundColor: "white", borderRadius: 10, padding: 10 }}>
        <Calendar
          locale={'vi'}
          onDayPress={date => {
            onPressDate(date);
          }}
          markedDates={{
            [!isNullOrEmpty(dateFocus)?moment(dateFocus).format('YYYY-MM-DD'):moment(new Date()).format('YYYY-MM-DD')]: { selected: true, marked: true }
          }}
          current={!isNullOrEmpty(dateFocus)?moment(dateFocus).format('YYYY-MM-DD'):moment(new Date()).format('YYYY-MM-DD')}
          theme={{
            backgroundColor: "#ffffff",
            calendarBackground: "#ffffff",
            textSectionTitleColor: "#b6c1cd",
            selectedDayBackgroundColor: "#00adf5",
            selectedDayTextColor: "#ffffff",
            todayTextColor: "black",
            dayTextColor: "#2d4150",
            textDisabledColor: "#d9e1e8",
            dotColor: "#00adf5",
            selectedDotColor: "#ffffff",
            arrowColor: "#00adf5",
            monthTextColor: "#00adf5",
            indicatorColor: "blue",
            textDayFontFamily: "monospace",
            textMonthFontFamily: "monospace",
            textDayHeaderFontFamily: "monospace",
            textDayFontSize: 16,
            textMonthFontSize: 16,
            textDayHeaderFontSize: 16
          }}
        />
      </Pressable>
    </TouchableOpacity>
  );
}
