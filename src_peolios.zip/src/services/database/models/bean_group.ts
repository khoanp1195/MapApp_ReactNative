import { Entity } from "typeorm/browser";
import { Column, PrimaryColumn } from "typeorm";

// @ts-ignore
@Entity({name:'BeanGroup'})
export class BeanGroup{
  // @ts-ignore
  @PrimaryColumn({type: 'int'})
  public ID:number=0;
  // @ts-ignore
  @Column({type:'text'})
  public Title:string='';
  // @ts-ignore
  @Column({type:'text'})
  public Name:string='';
  // @ts-ignore
  @Column({type:'text'})
  public Image:string='';
  // @ts-ignore
  @Column({type:'text'})
  public Modified:string='';
  // @ts-ignore
  @Column({type:'text'})
  public Created:string='';
  constructor(data: any) {
    if (data) {
      this.ID = data.ID || 0;
      this.Title = data.Title || '';
      this.Name = data.Name || '';
      this.Image = data.Image || '';
      this.Modified = data.Modified || '';
      this.Created = data.Created || '';
    }
  }
  static fromJson(json: any): BeanGroup {
    return new BeanGroup(json);
  }

  static listFromJson(jsonArray: any[]): BeanGroup[] {
    return jsonArray.map((item) => new BeanGroup(item));
  }
}
