import { BeanYKien } from "./beanYKien";

export class BeanComment extends BeanYKien {
    public ImagePath: string;
    public Position: string;

    constructor() {
        super(); // Call the constructor of the base class BeanYKien
        this.ImagePath = '';
        this.Position = '';
    }
}
