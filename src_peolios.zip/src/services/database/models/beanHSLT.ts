export class BeanHSLT {
    public ID: number;
    public MaDinhDanh: string;
    public MaHoSo: string;
    public TenHoSo: string;
    public NoiDung: string;
    public FromDate: string | null;
    public ToDate: string | null;
    public CodeFieldId: any;
    public Follower: string;
    public Viewer: string;
    public Created: string;
    public Modified: string;
    public CreatedByText: string;
    public ModifiedBy: string;
    public Status: number;
    public StatusText: string;
    public NoiLuu: string;
    public LinhVuc: string;
    public ModifiedByText: string;
    public DepartmentTitle: string;
    public FollowerText: string;
    public ViewerText: string;

    constructor(
        ID: number,
        MaDinhDanh: string,
        MaHoSo: string,
        TenHoSo: string,
        NoiDung: string,
        FromDate: string | null,
        ToDate: string | null,
        CodeFieldId: any,
        Follower: string,
        Viewer: string,
        Created: string,
        Modified: string,
        CreatedByText: string,
        ModifiedBy: string,
        Status: number,
        StatusText: string,
        NoiLuu: string,
        LinhVuc: string,
        ModifiedByText: string,
        DepartmentTitle: string,
        FollowerText: string,
        ViewerText: string
    ) {
        this.ID = ID;
        this.MaDinhDanh = MaDinhDanh;
        this.MaHoSo = MaHoSo;
        this.TenHoSo = TenHoSo;
        this.NoiDung = NoiDung;
        this.FromDate = FromDate;
        this.ToDate = ToDate;
        this.CodeFieldId = CodeFieldId;
        this.Follower = Follower;
        this.Viewer = Viewer;
        this.Created = Created;
        this.Modified = Modified;
        this.CreatedByText = CreatedByText;
        this.ModifiedBy = ModifiedBy;
        this.Status = Status;
        this.StatusText = StatusText;
        this.NoiLuu = NoiLuu;
        this.LinhVuc = LinhVuc;
        this.ModifiedByText = ModifiedByText;
        this.DepartmentTitle = DepartmentTitle;
        this.FollowerText = FollowerText;
        this.ViewerText = ViewerText;
    }
}
