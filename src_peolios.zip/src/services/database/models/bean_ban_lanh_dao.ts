import { Column, Entity, PrimaryColumn } from "typeorm/browser";

// @ts-ignore
@Entity({name:'BeanBanLanhDao'})
export class BeanBanLanhDao {
  // @ts-ignore
  @PrimaryColumn({type: 'int'})
  public ID: number = 0;
  // @ts-ignore
  @Column({type:'text'})
  public Title:string='';
  // @ts-ignore
  @Column({type:'text'})
  public DonVi:string='';
  // @ts-ignore
  @Column({type:'text'})
  public Modified:string='';
  // @ts-ignore
  @Column({type:'text'})
  public Created:string='';
  // @ts-ignore
  @Column({type:'text'})
  public LanhDao:string='';
  // @ts-ignore
  @Column({type:'int'})
  public Orders:number=0;
  // @ts-ignore
  @Column({type:'text'})
  public Group:string='';
  // @ts-ignore
  @Column({type:'boolean'})
  public OneAssign:boolean=false;
  // @ts-ignore
  @Column({type:'text'})
  public ThayThe:string='';
  public isSelected:boolean=false;
  public isLoadImage:boolean=false;
  constructor(data: any) {
    if (data) {
      this.ID = data.ID || 0;
      this.Title = data.Title || '';
      this.DonVi = data.DonVi || '';
      this.Modified = data.Modified || '';
      this.Created = data.Created || '';
      this.LanhDao = data.LanhDao || '';
      this.Orders = data.Orders || 0;
      this.Group = data.Group || '';
      this.OneAssign = data.OneAssign || false;
      this.ThayThe = data.ThayThe || '';
    }
  }
  static fromJson(json: any): BeanBanLanhDao {
    return new BeanBanLanhDao(json);
  }

  // Method to create an array of instances from an array of JSON objects
  static listFromJson(jsonArray: any[]): BeanBanLanhDao[] {
    return jsonArray.map((item) => new BeanBanLanhDao(item));
  }
}
