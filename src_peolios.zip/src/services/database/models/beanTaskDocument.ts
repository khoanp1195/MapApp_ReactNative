import { BeanUser } from "./bean_user";

export class BeanTaskDocument {
    public ID: number;
    public DepartmentId: number;
    public VBId: number;
    public ParentId: number | null;
    public DeThucHien: boolean;
    public Role: number;
    public AssignedToType: boolean;
    public StartDate: string | null;
    public DueDate: string | null;
    public ThoiHanGQ: string | null;
    public HoSoDuThaoUrl: string;
    public Percent: number;
    public TrangThai: string;
    public ImagePath: string;
    public Position: string;
    public ModuleId: number;
    public YKienCuaNguoiGiaiQuyet: string;
    public YKienChiDao: string;
    public Modified: string; // Changed to string
    public Created: string; // Changed to string
    public CreatedBy: string;
    public NguoiChuyenJson: BeanUser|null;
    public NguoiNhanJson: BeanUser|null;
    public AssignedToText: string;
    public AssignedToTextJson: BeanUser|null;
    public DepartmentTitle: string;
    public DepartmentName: string;
    public DepartmentUrl: string;
    public IsSelected: boolean;
    public TrichYeu: string;
    public AssignedToUserValue: string;
    public NguoiChuyen: string;
    public ListAssignmentUsers: string;
    public ListParentTask: BeanTaskDocument[];
    public ListUserTask: BeanTaskDocument[];
    public IsDonVi: boolean;
    public ActionJson: string;

    constructor() {
        this.ID = 0;
        this.DepartmentId = 0;
        this.VBId = 0;
        this.ParentId = null;
        this.DeThucHien = false;
        this.Role = 0;
        this.AssignedToType = false;
        this.StartDate = null;
        this.DueDate = null;
        this.ThoiHanGQ = null;
        this.HoSoDuThaoUrl = '';
        this.Percent = 0;
        this.TrangThai = '';
        this.ImagePath = '';
        this.Position = '';
        this.ModuleId = 0;
        this.YKienCuaNguoiGiaiQuyet = '';
        this.YKienChiDao = '';
        this.Modified = '';
        this.Created = '';
        this.CreatedBy = '';
        this.NguoiChuyenJson =null;
        this.NguoiNhanJson = null;
        this.AssignedToText = '';
        this.AssignedToTextJson =null;
        this.DepartmentTitle = '';
        this.DepartmentName = '';
        this.DepartmentUrl = '';
        this.IsSelected = false;
        this.TrichYeu = '';
        this.AssignedToUserValue = '';
        this.NguoiChuyen = '';
        this.ListAssignmentUsers = '';
        this.ListParentTask = [];
        this.ListUserTask = [];
        this.IsDonVi = false;
        this.ActionJson = '';
    }
}

