import {EntityRepository, Repository} from 'typeorm';
import { BeanBanLanhDao } from "../models/bean_ban_lanh_dao.ts";
import { BeanCoQuanGui } from "../models/bean_co_quan_gui.ts";

// @ts-ignore
@EntityRepository(BeanCoQuanGui)
export class BeanCoQuanGuiRepository extends Repository<BeanCoQuanGui> {
  async insertAll(datas: BeanCoQuanGui[]): Promise<void> {
    datas.forEach(element => {
      this.manager.save(element);
   });
  }
  async findByTitle(title: string): Promise<BeanCoQuanGui[]> {
    const queryString = `SELECT * FROM BeanCoQuanGui WHERE Title LIKE '%${title}%'`;
    return this.query(queryString);
  }
  async findAll(): Promise<BeanCoQuanGui[]> {
    const queryString = `SELECT * FROM BeanCoQuanGui`;
    return this.query(queryString);
  }
  async deleteAll():Promise<void>{
    const queryString = `Delete FROM BeanCoQuanGui`;
    return this.query(queryString);
  }
}
