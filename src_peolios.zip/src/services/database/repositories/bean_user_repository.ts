import {EntityRepository, Repository} from 'typeorm';
import { BeanUser } from "../models/bean_user.ts";

// @ts-ignore
@EntityRepository(BeanUser)
export class BeanUserRepository extends Repository<BeanUser> {
  async insertAll(datas: BeanUser[]): Promise<void> {
    datas.forEach(element => {
      this.manager.save(element);
   });
  }
  async findAll(): Promise<BeanUser[]> {
    const queryString = `SELECT * FROM BeanUser`;
    return this.query(queryString);
  }
  async findByTitle(title:string): Promise<BeanUser[]> {
    const queryString = `SELECT * FROM BeanUser where Title like '${title}'`;
    return this.query(queryString);
  }
  async executeQuery(str:string): Promise<BeanUser[]> {
    return this.query(str);
  }
  async deleteAll():Promise<void>{
    const queryString = `Delete FROM BeanUser`;
    return this.query(queryString);
  }
}
