import {EntityRepository, Repository} from 'typeorm';
import { BeanGroup } from "../models/bean_group.ts";

// @ts-ignore
@EntityRepository(BeanGroup)
export class BeanGroupRepository extends Repository<BeanGroup> {
  async insertAll(datas: BeanGroup[]): Promise<void> {
    datas.forEach(element => {
      this.manager.save(element);
   });
  }
  async findAll(): Promise<BeanGroup[]> {
    const queryString = `SELECT * FROM BeanGroup`;
    return this.query(queryString);
  }
  async executeQuery(str:string): Promise<BeanGroup[]> {
    return this.query(str);
  }
  async deleteAll():Promise<void>{
    const queryString = `Delete FROM BeanGroup`;
    return this.query(queryString);
  }
}
