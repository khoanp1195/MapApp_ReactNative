import Cheerio from "cheerio";

export const getImagePathTagImageCheerio = (value: string) => {
    if (value!=undefined && value.includes("img")) {
        const $ = Cheerio.load(value);
        let url=  $('img').attr('src');
        if(url?.includes("?"))
        {
            url=url.split("?")[0];
        }
        return url;
    }
    return value;
}