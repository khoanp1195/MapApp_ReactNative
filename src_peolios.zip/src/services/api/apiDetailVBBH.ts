import { EnumTaskRole } from "../../config/enum.ts";
import { get, post } from "../../services/api/api_client.ts";
import { getCurrentTimeFormatted, isNullOrEmpty } from "../../utils/functions.ts";
import { BeanComment } from "../database/models/beanComment.ts";
import { BeanTaskDocument } from "../database/models/beanTaskDocument.ts";
import { BeanVBBH } from "../database/models/beanVBBH.ts";

export const getDetailVBBHByID = async (id: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiVanBanBanHanhMobile.ashx', {
    func: 'get',
    rid: id,
    taskv2: 1,
    cmtv2: 1
  });
  if (res.data["status"] != "ERR") {
    return res.data["data"] as BeanVBBH;
  }
  else {
    return null;
  }
}

export const getAttFileVBBHByID = async (id: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiVanBanBanHanhMobile.ashx',
    {
      func: 'getAttachFiles',
      rid: id
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}

export const getWorkflowHistoryOtherDepartmentVBBH = async (id: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiVanBanBanHanhMobile.ashx',
    {
      func: 'getWorkflowHistoryOtherDepartment',
      rid: id
    });
  if (res.data["status"] != "ERR" && !isNullOrEmpty(JSON.stringify(res))) {
    return res.data["data"];
  }
  else {
    return null;
  }
}

export const getVBBHWorkflowHistory = async (id: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx',
    {
      func: 'Get',
      Action: 'VBBHGetWorkflowHistory',
      Params: 'ItemId',
      ItemId: id
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}

export const getViewerVBBH = async (id: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx',
    {
      func: 'Get',
      Action: 'VBGetViewer',
      Params: 'ItemId,ModuleId',
      ItemId: id,
      ModuleId: 8,
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}

export const getVBDenWorkflowHistoryOtherDepartmentVBBH = async (vbId: number, departmentId: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiVanBanBanHanhMobile.ashx',
    {
      func: 'ExpandThongTinLuanChuyen',
      data: `{VBId:${vbId},LookupId:${departmentId}}`
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}

export const getListShareVBBH = async (item: BeanVBBH) => {
  const res = await get("/vanban/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx",
    {
      func: 'Get',
      Action: 'VBBHUserShare',
      Params: "ModuleId,ItemId",
      ItemId: item.ID,
      ModuleId: item.ModuleId
    }
  );
  if (res.data["status"] != "ERR") {
    return res.data["data"] as BeanComment[];
  }
  else {
    if (__DEV__)
      console.log('getListShareVBBH thất bại gòi');
    return null;
  }

}
export const submitShareVBBH = async (item: BeanVBBH) => {
  let dataPost = new FormData();
  const obj = {
    ID: item.ID,
    YKien: item.YKien,
    PeopleText: item.PeopleText
  };
  dataPost.append("data", JSON.stringify(obj));
  const res = await post("/vanban/_layouts/15/VuThao.Petrolimex.API/ApiVanBanBanHanhMobile.ashx",
    {
      func: 'submit',
      action: '128'
    },
    dataPost
  );
  if (res.data["status"] != "ERR") {
    return true;
  }
  else {
    if (__DEV__)
      console.log('submitShareVBBH thất bại gòi');
    return false;
  }

}
export const getDetailTaskVanBanBanHanh = async (id: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiVanBanBanHanhMobile.ashx',
    {
      func: 'getTaskByIdv2',
      rid: id,
      modified: getCurrentTimeFormatted(),
      actionPer: 1
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"] as BeanTaskDocument;
  }
  else {
    return null;
  }
}
export const actionTaskVanBanBanHanh = async (action: any, task: BeanTaskDocument) => {
  let dataPost = new FormData();
  let obj: any = {
    ID: task.ID
  };
  switch (task.Role) {
    case EnumTaskRole.Assignor:
    case EnumTaskRole.AssignorPBan:
     
      break;

  }
  // const res = await post("/vanban/_layouts/15/VuThao.Petrolimex.API/ApiVanBanBanHanhMobile.ashx",
  //   {
  //     func: "taskSubmit",
  //     action: action,

  //   },
  //   dataPost
  // );
  return false;
}

