import { get,post } from "./api_client.ts";
import { TinNoiBoType, ViewModeTinNoiBo } from "../../config/enum.ts";

export const getDashboard=async()=>{
  const res= await get('/_layouts/15/VuThao.Petrolimex.News/API/ApiHandler.ashx',
    {
      tbl:'News_Sort',
      func:'GetHotNewsHomePage',
      IsMobile:1
    });
  if (res.data["status"] != "ERR") {
    return res.data.data.data;
  }
  else {
    return null;
  }
}

export const getLeftMenu=async ()=>{
  const res=await get('/_layouts/15/VuThao.Petrolimex.News/API/ApiHandler.ashx',
    {
      tbl:"News_Category",
      func:"GetHorizontalCategories",
      IsMobile:1
    });
  if (res.data["status"] != "ERR") {
    let lstMenu=[{
      ID: 0,
      Title: 'Tin nội bộ',
      Icon: getIconLeftMenu(),
      IsParent: true,
      EnableClick: true,
    }];
    //return res.data.data.data;
    const dataRes= res.data.data.Parents;
    const dataMap=dataRes.map((item: { ID: any; Title: any; IconMobile: number | undefined; })=>{
      return {
        ID: item.ID,
        Title: item.Title,
        Icon: getIconLeftMenu(item.IconMobile),
        IsParent: false,
        EnableClick: true,
      }
    });
    lstMenu=lstMenu.concat(dataMap);
    return lstMenu;
  }
  else {
    return null;
  }
}
const getIconLeftMenu=(index:number=0)=>{
  switch (index)
  {
    case 0:
    default:
      return require('../../assets/images/icon_tinnoibo_parent.png');
    case 1:
      return require('../../assets/images/icon_tinnoibo_1.png');
    case 2:
      return require('../../assets/images/icon_tinnoibo_2.png');
    case 3:
      return require('../../assets/images/icon_tinnoibo_3.png');
    case 4:
      return require('../../assets/images/icon_tinnoibo_4.png');
    case 5:
      return require('../../assets/images/icon_tinnoibo_5.png');
  }
}
export const getSliceDashBoardTinNoiBo=async()=>{
  const res=await get('/_layouts/15/VuThao.Petrolimex.News/API/ApiHandler.ashx',
    {
      tbl:"News_Content",
      func:"LastestNewsHomePage",
      IsMobile:1
    });
  if (res.data["status"] != "ERR") {
    const dataRes= res.data.data.data;
    const dataMap={
      ID : 0,
      Rank : 0,
      title : "Tin mới",
      typeView : TinNoiBoType.DashBoard,
      showAll : false,
      viewMode : ViewModeTinNoiBo.Horizontal,
      data : dataRes,
      autoScroll : true,
      showDot : true

    }
    return dataMap;
  }
  else {
    return null;
  }
}
export const getDataAllCategory=async ()=>{
  const res=await get('/_layouts/15/VuThao.Petrolimex.News/API/ApiHandler.ashx',
    {
      tbl:"News_Category",
      func:"GetCategoryHomePage",
      IsMobile:1
    });
  if (res.data["status"] != "ERR") {
    let categories=res.data.data.Categories;
    let collection=res.data.data.Collection;
    categories=categories.map((item: { ID: any; Title: any; ViewMode: number; Rank: any; })=>{
      return {
        ID:item.ID,
        title:item.Title,
        viewMode:item.ViewMode==1?ViewModeTinNoiBo.Horizontal:ViewModeTinNoiBo.Vertical,
        Rank:item.Rank,
        autoScroll:false,
        data:collection.filter((r: { CategoryId: any;CategoryText:string }) => {
          r.CategoryText=item.Title;
          return r.CategoryId ==item.ID;
        }),
        typeView:item.ViewMode==1? TinNoiBoType.Horizontal : TinNoiBoType.Vertical,
        showAll:true,
        showDot:false
      };
    });
    return categories;
  }
  else {
    return null;
  }
}
export const getDataByCategoryID=async (CategoryId:number,Offset:number, takeHotNews:boolean)=>{
  let dataPost = new FormData();
  dataPost.append('data', `{CategoryId : ${CategoryId},Offset: ${Offset}}`);
  const res=await post('/_layouts/15/VuThao.Petrolimex.News/API/ApiHandler.ashx',
    {
      tbl:"News_Sort",
      func:"GetByCategoryId",
      IsMobile:1
    },
    dataPost
    );
  if (res.data["status"] != "ERR") {
    let categoryText="";
    res.data.data.HotNews.forEach((element:any) => {
      element.CategoryText=element.CategoryTitle;
      categoryText=element.CategoryTitle;
    });
    res.data.data.Categories.forEach((element:any) => {
      element.CategoryText=categoryText;
    });
    let hotNews= {
      ID:0,
      title:"",
      viewMode:ViewModeTinNoiBo.Horizontal,
      Rank:0,
      autoScroll:true,
      data:res.data.data.HotNews,
      typeView:TinNoiBoType.DashBoard,
      showAll:false,
      showDot:(res.data.data.HotNews!=undefined && res.data.data.HotNews.length>1)
    };

    let Categories= {
      ID:1,
      title:"",
      viewMode:ViewModeTinNoiBo.Vertical,
      Rank:1,
      autoScroll:false,
      data:res.data.data.Categories,
      typeView:TinNoiBoType.ListLoadMore,
      showAll:false,
      showDot:false
    };
    if(takeHotNews)
      return {
        hotNews:hotNews,
        Categories:Categories
      }
    else
    return {
      Categories:Categories
    }
  }
  else {
    return null;
  }
}
