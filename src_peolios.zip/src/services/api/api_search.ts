import { post } from "../api/api_client.ts";

export const getSearchData = async (limit: number, ofset: number, dataPost: FormData) => {
  const res = await post(
    '/vanban/_layouts/15/VuThao.Petrolimex.API/ApiVanBanBanHanhMobile.ashx',
    {
      func: 'searchVB',
      Limit: limit,
      Offset: ofset
    },
    dataPost
  );
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
}
