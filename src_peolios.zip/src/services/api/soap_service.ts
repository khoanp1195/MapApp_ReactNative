import axios from 'axios';
import { BASE_URL, cookieStore } from "../../config/constants.ts";
import { saveCookie, saveCredentials } from '../../utils/async_storage.ts';

export const soapAuth = async (username: string, password: string) => {
  let data =
    '<?xml version="1.0" encoding="utf-8"?>' +
    '<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ' +
    'xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">' +
    '<soap:Body><Login xmlns="http://schemas.microsoft.com/sharepoint/soap/">' +
    `<username>${username}</username>` +
    `<password>${password}</password>` +
    '</Login>' +
    '</soap:Body></soap:Envelope>';
  const res = await axios({
    method: 'post',
    url: BASE_URL + '/_vti_bin/authentication.asmx',
    headers: {
      'content-type': 'text/xml',
      SOAPAction: 'http://schemas.microsoft.com/sharepoint/soap/Login',
    },
    withCredentials: false,
    data: data,
  });

  // @ts-ignore
  if (res.headers.get('Set-Cookie') !== undefined) {
    ///Check FedAuth
    // console.log(res.headers.get('Set-Cookie'));
    await saveCredentials(username, password);
    // @ts-ignore
    await saveCookie(res.headers.get('Set-Cookie')[0]);
    // @ts-ignore
    cookieStore.setCookie(res.headers.get('Set-Cookie')[0]);
    return true;
  } else {
    return false;
  }
};
