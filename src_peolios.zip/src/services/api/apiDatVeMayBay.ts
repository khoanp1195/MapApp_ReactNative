import { post } from "./api_client.ts";
import { TypeDatVeMayBay } from "../../config/enum.ts";

export const getDataListVeMatBayByType = async (type: any, limit: number, offset: number) => {
  let obj;
  let dataPost = new FormData();
  switch (type) {
    case TypeDatVeMayBay.PhieuToiTao:
      obj = {
        MySelf: 1,
        limit: limit,
        offset: offset
      };
      break;
    case TypeDatVeMayBay.ChoPheDuyet:
      obj = {
        Step: "2,3",
        limit: limit,
        offset: offset
      };
      break;
    case TypeDatVeMayBay.ChoMuaVe:
      obj = {
        Step: "4,5",
        limit: limit,
        offset: offset
      };
      break;
    case TypeDatVeMayBay.DaMuaVe:
      obj = {
        Step: "6",
        limit: limit,
        offset: offset
      };
      break;
    case TypeDatVeMayBay.TatCa:
      obj = {
        limit: limit,
        offset: offset
      };
      break;
  }
  dataPost.append("data", JSON.stringify(obj));
  const res = await post("/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx",
    {
      func: "Get",
      Action: "DangKyCongTac"
    },
    dataPost
  );
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }
};

