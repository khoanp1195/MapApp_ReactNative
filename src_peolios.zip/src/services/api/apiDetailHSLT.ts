import { get } from "../../services/api/api_client.ts";

export const getDetailHoSoluuTru = async (_IDHoSo: number, isPermission: boolean) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx',
    {
      func: 'Get',
      Action: 'HSLTDetail',
      Params: 'ID',
      ID: _IDHoSo
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"]["Data"];
  }
  else {
    return null;
  }
}

export const getDetailVanBanHoSoluuTru = async (_IDHoSo: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx',
    {
      func: 'Get',
      Action: 'HSLTDetailDoc',
      Params: 'ID',
      ID: _IDHoSo
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"];
  }
  else {
    return null;
  }

}

export const getAttachmentHoSoluuTru = async (_IDHoSo: number) => {
  const res = await get('/vanban/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx',
    {
      func: 'Get',
      Action: 'HSLTDetailAttach',
      Params: 'ID',
      ID: _IDHoSo
    });
  if (res.data["status"] != "ERR") {
    return res.data["data"]
  }
  else {
    return null;
  }
}