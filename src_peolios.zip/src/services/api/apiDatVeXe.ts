import { TypeDatVeXe } from "../../config/enum.ts";
import { post } from "./api_client.ts";

export const getDataVeXeByType = async (type: any, limit: number, offset: number) => {
    let obj;
    let dataPost = new FormData();
    switch (type) {
        case TypeDatVeXe.DangLuu:
            obj = {
                MySelf: 1,
                Step: 1,
                limit: limit,
                offset: offset,
                IsMobile: 1
            };
            break;
        case TypeDatVeXe.ChoPheDuyet:
            obj = {
                Step: 2,
                limit: limit,
                offset: offset,
                CarStatus: "Soạn thảo",
                IsMobile: 1
            };
            break;
        case TypeDatVeXe.ChoDieuXe:
            obj = {
                Step: 3,
                limit: limit,
                offset: offset,
                CarStatus: "Soạn thảo",
                IsMobile: 1
            };
            break;
        case TypeDatVeXe.DaDieuXe:
            obj = {
                Step: 3,
                limit: limit,
                offset: offset,
                CarStatus: "Đã điều xe",
                IsMobile: 1
            };
            break;
        case TypeDatVeXe.ChuyenHoanThanh:
            obj = {
                Step: 3,
                limit: limit,
                offset: offset,
                CarStatus: "Hoàn tất",
                IsMobile: 1
            };
            break;
        case TypeDatVeXe.All:
            obj = {
                limit: limit,
                offset: offset,
                IsMobile: 1
            };
            break;
    }
    dataPost.append("data", JSON.stringify(obj));
    const res = await post("/_layouts/15/VuThao.Petrolimex.API/ApiMobile.ashx",
        {
            func: "Get",
            Action: "DangKyXeCongTac"
        },
        dataPost
    );
    if (res.data["status"] != "ERR") {
        return res.data["data"];
    }
    else {
        return null;
    }
};

