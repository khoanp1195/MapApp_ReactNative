// import RNFetchBlob from "rn-fetch-blob";

// export const openFile=(filePath:string)=>{
//     RNFetchBlob.android.actionViewIntent(filePath, '*/*');
// }