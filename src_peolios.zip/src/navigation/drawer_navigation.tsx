import { createDrawerNavigator, DrawerContent } from "@react-navigation/drawer";
import { Image, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { TestScreen1 } from "../screens/test_screen.tsx";
import { AppNavigation } from "../navigation/app_navigation.tsx";
import { useDispatch, useSelector } from "react-redux";
import { useCallback, useState } from "react";
import { CustomFastImage } from "../components/custom_fast_image.tsx";
import { BASE_URL, currentUserStore, modifiedStore, subsiteStore } from "../config/constants.ts";
import { getAllData, isNullOrEmpty, promiseApiMasterData } from "../utils/functions.ts";
import { Dropdown } from "react-native-element-dropdown";
import { LeftMenuHomeScreen } from "../screens/leftmenu/leftmenu_home_screen.tsx";
import { LeftMenuCalendarScreen } from "../screens/leftmenu/leftmenu_calendar_screen.tsx";
import { LeftMenuInTimeUpgradeScreen } from "../screens/leftmenu/leftmenu_in_time_upgrade_screen.tsx";
import { DbServices } from "../services/database/db_service.ts";
import { saveModified, saveSubSite } from "../utils/async_storage.ts";
import { endChangeSite, startChangeSite } from "../stores/loading/actions.ts";
import { DrawerActions, useNavigation } from "@react-navigation/native";
import { redirectParentView } from "../stores/base_screen/actions.ts";
import { getCurrentUser } from "../services/api/api_data.ts";
import { LeftMenuDangKyXuatAnScreen } from "../screens/leftmenu/leftmenu_dangkyxuatan_screen.tsx";
import { LeftMenuTinNoiBoScreen } from "../screens/leftmenu/leftMenuTinNoiBoScreen.tsx";
import { LeftMenuDatVeMayBay } from "../screens/leftmenu/leftMenuDatVeMayBay.tsx";
import { LeftMenuDatVeXe } from "../screens/leftmenu/leftMenuDatVeXe.tsx";

export const DrawerNavigation = () => {
  const Drawer = createDrawerNavigator();
  const index = useSelector((state: any) => state.leftMenu.index);
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const [currentUser, setCurrentUser] = useState(currentUserStore.getCurrentUser())

  const DrawerHeader = () => {
    return (
      <View style={headerStyles.container}>
        <View style={headerStyles.imageContainer}>
          <CustomFastImage
            defaultImage={require("../assets/images/avatar80.jpg")}
            urlOnline={BASE_URL + "/" + subsiteStore.getSubsite() + "/" + currentUser.ImagePath}
            styleImg={headerStyles.image}
          />
        </View>
        <View style={headerStyles.textContainer}>
          <Text style={headerStyles.name}>{currentUser.Title}</Text>
          <Text style={headerStyles.position}>{currentUser.Position}</Text>
        </View>
      </View>
    );
  };

  const DropDownSite = () => {
    const [value, setValue] = useState(null);
    const [isFocus, setIsFocus] = useState(false);

    const data = !currentUserStore.getCurrentUser().SiteName.includes(";")
      ? [{ label: isNullOrEmpty(currentUserStore.getCurrentUser().SiteName) ? "Tập đoàn" : currentUserStore.getCurrentUser().SiteName, value: '1' }]
      : currentUserStore.getCurrentUser().SiteName.split(";").map((value, index) => ({
        label: isNullOrEmpty(value) ? "Tập đoàn" : value,
        value: isNullOrEmpty(value) ? "" : value,
      }));

    return (
      <View>
        <Dropdown
          renderItem={(item, selected) => (
            <View>
              <View style={dropdownStyles.itemContainer}>
                <Image
                  source={
                    subsiteStore.getSubsite() === item.value
                      ? require('../assets/images/icon_Circle_CheckEvalution.png')
                      : require('../assets/images/icon_Circle_unCheckEvalution.png')
                  }
                  style={dropdownStyles.icon}
                />
                <Text style={dropdownStyles.label}>{item.label}</Text>
              </View>
              <View style={dropdownStyles.separator} />
            </View>
          )}
          style={[dropdownStyles.dropdown, isFocus && { borderColor: 'blue' }]}
          placeholderStyle={dropdownStyles.placeholderStyle}
          selectedTextStyle={dropdownStyles.selectedTextStyle}
          inputSearchStyle={dropdownStyles.inputSearchStyle}
          iconStyle={dropdownStyles.iconStyle}
          data={data}
          maxHeight={300}
          labelField="label"
          valueField="value"
          placeholder={isNullOrEmpty(subsiteStore.getSubsite()) ? "Tập đoàn" : subsiteStore.getSubsite()}
          searchPlaceholder="Tìm kiếm..."
          value={value}
          onFocus={() => setIsFocus(true)}
          onBlur={() => setIsFocus(false)}
          onChange={(item) => {
            navigation.dispatch(DrawerActions.closeDrawer());
            dispatch(startChangeSite());
            // @ts-ignore
            setValue(item.value);
            setIsFocus(false);
            subsiteStore.setSubsite(item.value);
            saveModified("");
            modifiedStore.setModified("");
            dispatch(redirectParentView());
            saveSubSite(item.value);
            DbServices.getInstance().deleteAll().then(_ => {
              getCurrentUser().then(_ => {
                setCurrentUser(currentUserStore.getCurrentUser());
              });
              promiseApiMasterData().then(() => {
                // @ts-ignore
                navigation.navigate("Home");
                dispatch(endChangeSite());
              });
            });
          }}
        />
      </View>
    );
  };

  const DrawerBody = () => {
    switch (index) {
      case 0:
        return <LeftMenuHomeScreen />;
      case 1:
        return <LeftMenuCalendarScreen />;
      case 3:
        return <LeftMenuDangKyXuatAnScreen />;
      case 4:
        return <LeftMenuTinNoiBoScreen />;
      case 5:
        return <LeftMenuDatVeMayBay />;
        case 6:
          return <LeftMenuDatVeXe />;
      default:
        return <LeftMenuHomeScreen />;
    }
  };

  const DrawerContent = () => {
    return (
      <ScrollView>
        <DrawerHeader />
        <DropDownSite />
        <DrawerBody />
      </ScrollView>
    );
  };

  return (
    <Drawer.Navigator
      screenOptions={{ headerShown: false }}
      drawerContent={(props) => <DrawerContent />}>
      <Drawer.Screen
        options={{
          swipeEnabled: false,
        }} name="AppNavigation" component={AppNavigation} />
    </Drawer.Navigator>
  );
};

const headerStyles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
  },
  imageContainer: {
    padding: 10,
  },
  image: {
    height: 50,
    width: 50,
    borderRadius: 40
  },
  textContainer: {
    marginLeft: 10,
  },
  name: {
    fontSize: 15,
    color: "#000000",
  },
  position: {
    fontSize: 13,
    color: "#5E5E5E",
  },
});

const dropdownStyles = StyleSheet.create({
  itemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  dropdown: {
    height: 50,
    borderColor: '#0072C6',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 8,
    marginLeft: 10,
    marginRight: 10,
    backgroundColor: '#F2FAFF',
  },
  icon: {
    height: 20,
    width: 20,
    marginLeft: 10,
  },
  label: {
    padding: 10,
    color: '#000000',
    fontSize: 15,
    fontWeight: '400',
  },
  separator: {
    width: '100%',
    height: 1,
    backgroundColor: '#E5E5E5',
  },
  placeholderStyle: {
    fontSize: 16,
    backgroundColor: '#F2FAFF',
    color: '#0072C6',
    fontWeight: 'bold',
  },
  selectedTextStyle: {
    fontSize: 16,
    color: '#0072C6',
    fontWeight: 'bold',
  },
  iconStyle: {
    width: 20,
    height: 20,
  },
  inputSearchStyle: {
    height: 40,
    fontSize: 16,
  },
});
