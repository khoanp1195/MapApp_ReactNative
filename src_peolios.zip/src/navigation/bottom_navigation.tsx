import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { BackHandler, Image, Platform, Text, View } from "react-native";
import { useEffect } from "react";
import { TestScreen1 } from "../screens/test_screen.tsx";
import { HomeScreen } from "../screens/home/home_screen.tsx";
import { CalendarScreen } from "../screens/calendar/calendar_screen.tsx";
import { UtilitiesScreen } from "../screens/utilities/utilities_screen.tsx";
import { SearchScreen } from "../screens/search/search_screen.tsx";
import { createDrawerNavigator } from '@react-navigation/drawer';
import { useDispatch, useSelector } from "react-redux";
import { redirectParentView } from "../stores/base_screen/actions.ts";
import { LoadingScreen } from "../components/loadingScreen.tsx";
import { changePageTypeVeMayBay } from "../stores/vemaybay/actions.ts";
import { TypeDatVeMayBay } from "../config/enum.ts";

const Tab = createBottomTabNavigator();
const Drawer = createDrawerNavigator();

const ImageBottom = (size: number, color: string, path: any) => {
  return (
    <Image
      style={{ width: size - 2, height: size - 2, tintColor: color }}
      source={path}
      resizeMode="contain"
    />
  );
};
export const BottomNavigation = () => {
  /*useEffect(() => {
    const backHandler = BackHandler.addEventListener("hardwareBackPress", handleBackPress);
    return () => {
      backHandler.remove();
    };
  }, []);*/
  const onLoading = useSelector((state: any) => state.loading.onLoading);

  const dispatch = useDispatch();
  const handleBackPress = () => {
    return true;
  };
  return (
    <View style={{ flex: 1 }}>
      <Tab.Navigator
        initialRouteName={"Home"}
        screenOptions={({ route }) => ({
          headerShown: false,
          unmountOnBlur: true,
          tabBarInactiveBackgroundColor: "#FFFFFF",
          tabBarActiveBackgroundColor: "#FFFFFF",
          tabBarActiveTintColor: "#0072C6",
          tabBarInactiveTintColor: "#77869E",
          tabBarLabelStyle: {
            fontSize: 12
          },
          tabBarStyle: {
            backgroundColor: "#FFFFFF",
            position: "absolute",
            borderTopWidth: 0,
            paddingTop: 10,
            paddingBottom: 5,//Platform.OS === "ios" ? 20 : 5,
            height: 60,// Platform.OS === "ios" ? 77 : 50
          }

        })}
      >
        <Tab.Screen name="Home" component={HomeScreen} options={{
          headerShown: false,
          title: 'Trang chủ',
          tabBarIcon: ({ size, color }) => {
            return ImageBottom(size, color, require("../assets/images/icon_home.png"));
          }
        }}
          listeners={({ navigation, route }) => ({
            tabPress: (e) => {
              dispatch(redirectParentView());
            }
          })}

        />
        <Tab.Screen name="Calendar" component={CalendarScreen} options={{
          headerShown: false,
          title: 'Lịch tuần',
          tabBarIcon: ({ size, color }) => {
            return ImageBottom(size, color, require("../assets/images/icon_lichtuan.png"));
          }
        }}
          listeners={({ navigation, route }) => ({
            tabPress: (e) => {
              dispatch(redirectParentView());

            }
          })}

        />
        <Tab.Screen name="TienIch" component={UtilitiesScreen} options={{
          title: 'Tiện ích',
          headerShown: false,
          tabBarIcon: ({ size, color }) => {
            return ImageBottom(size, color, require("../assets/images/icon_tienich.png"));
          }
        }}
          listeners={({ navigation, route }) => ({
            tabPress: (e) => {
              dispatch(redirectParentView());
              dispatch(changePageTypeVeMayBay(TypeDatVeMayBay.PhieuToiTao));
            }
          })}

        />
        <Tab.Screen name="Search" component={SearchScreen} options={{
          headerShown: false,
          title: 'Tìm kiếm',
          tabBarIcon: ({ size, color }) => {
            return ImageBottom(size, color, require("../assets/images/icon_search26.png"));
          }
        }}
          listeners={({ navigation, route }) => ({
            tabPress: (e) => {
              dispatch(redirectParentView());

            }
          })}

        />
      </Tab.Navigator>
      {
        onLoading && <LoadingScreen />
      }
    </View>
  );
};
