import * as types from './action_types.ts';

export const changePageTypeVeMayBay = (item:any) => ({
  type: types.CHANGEPAGE_VEMAYBAY,
  payload: item
});
export const startReloadVeMayBay = () => ({
  type: types.START_RELOAD_VEMAYBAY
});
export const endReloadVeMayBay = () => ({
  type: types.END_RELOAD_VEMAYBAY
})

