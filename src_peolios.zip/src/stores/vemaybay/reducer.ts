import { CHANGEPAGE_VEMAYBAY, END_RELOAD_VEMAYBAY, START_RELOAD_VEMAYBAY } from "./action_types.ts";
import { TypeDatVeMayBay } from "../../config/enum.ts";

const initialState = {
  item: TypeDatVeMayBay.PhieuToiTao,
  isReload:false
};

const typeVeMayBayReducer = (state = initialState, action: { type: any; payload: { id: any; }; }) => {
  switch (action.type) {
    case CHANGEPAGE_VEMAYBAY:
      return {
        ...state,
        item: action.payload,
        isReload:false
      };
      case START_RELOAD_VEMAYBAY:
      return {
        ...state,
        isReload:true
      };
      case END_RELOAD_VEMAYBAY:
      return {
        ...state,
        isReload:false
      };
    default:
      return state;
  }
};

export default typeVeMayBayReducer;
