import { UPDATE_ITEM, UPDATE_ITEM_AND_TYPE, UPDATE_LSTACTION, UPDATE_TYPE } from "./action_types";

export const updateLstAction = (lstaction:any) => ({
    type: UPDATE_LSTACTION,
    payload: lstaction,
  });
  
  export const updateItem = (item:any) => ({
    type: UPDATE_ITEM,
    payload: item,
  });
  
  export const updateType = (type:any) => ({
    type: UPDATE_TYPE,
    payload: type,
  });

  export const updateItemAndType = (item:any,type:any) => ({
    type: UPDATE_ITEM_AND_TYPE,
    payload: {
      item:item,
      type:type
    },
  });