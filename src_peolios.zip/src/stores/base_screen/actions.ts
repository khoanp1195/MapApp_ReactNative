import * as types from './action_types.ts';
import { BaoCaoThongMinhUtil, DatVeMayBay } from "./action_types.ts";

export const redirectVCXLScreen = () => ({
  type: types.VCXLScreen,
});
export const redirectVBPHScreen = () => ({
  type: types.VBPHScreenState,
});

export const redirectVCXLHighScreen = () => ({
  type: types.VCXLHighScreen,
});

export const redirectTBScreen = () => ({
  type: types.TBScreen,
});
export const redirectVBDenTitle = () => ({
  type: types.VBDenTitle,
});
export const redirectVBDenChoChoYKien = () => ({
  type: types.VBDenChoChoYKien,
});
export const redirectVBDenChoThucHien = () => ({
  type: types.VBDenChoThucHien,
});
export const redirectVBDenThongBao = () => ({
  type: types.VBDenThongBao,
});
export const redirectVBDenTatCa = () => ({
  type: types.VBDenTatCa,
});
export const redirectVBDenDaGiaiQuyet = () => ({
  type: types.VBDenDaGiaiQuyet,
});


export const redirectVBDiTitle = () => ({
  type: types.VBDiTitle,
});
export const redirectVBDiChoPheDuyet = () => ({
  type: types.VBDiChoPheDuyet,
});
export const redirectVBDiDaPheDuyet = () => ({
  type: types.VBDiDaPheDuyet,
});
export const redirectVBDiDaPhatHanh = () => ({
  type: types.VBDiDaPhatHanh,
});
export const redirectVBDiThongBao = () => ({
  type: types.VBDiThongBao,
});
export const redirectVBDiTatCa = () => ({
  type: types.VBDiTatCa,
});
export const redirectHSLTTatCa = () => ({
  type: types.HSLTTatCa,
});
export const redirectHSLTCuaToi = () => ({
  type: types.HSLTCuaToi,
});
export const redirectParentView = () => ({
  type: "",
});


//Lich
export const redirectLichDuKien = () => ({
  type: types.LichDuKien,
});
export const redirectLichChoDuyet = () => ({
  type: types.LichChoDuyet,
});
export const redirectLichChoXepPhong = () => ({
  type: types.LichChoXepPhong,
});
export const redirectLichTatCa = () => ({
  type: types.LichTatCa,
});
export const redirectDangKyXuatAn = () => ({
  type: types.DangKyXuatAn,
});
export const redirectBaoCaoThongMinh = () => ({
  type: types.BaoCaoThongMinhUtil,
});
export const redirectTinNoiBo = () => ({
  type: types.TinNoiBo,
});
export const redirectDatVeMayBay = () => ({
  type: types.DatVeMayBay,
});
export const redirectDatVeXe = () => ({
  type: types.DatVeXe,
});
export const redirectScreen = (screen:string) => ({
  type: screen,
});
