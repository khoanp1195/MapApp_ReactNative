import * as types from './action_types.ts';

export const changePageTypeVeXe = (item:any) => ({
  type: types.CHANGEPAGE_VEXE,
  payload: item
});
export const startReloadVeXe = () => ({
  type: types.START_RELOAD_VEXE
});
export const endReloadVeXe = () => ({
  type: types.END_RELOAD_VEXE
})

