import * as types from './action_types.ts';

export const startReloadLichHop = () => ({
  type: types.START_RELOAD_LICHHOP
});
export const endReloadLichHop = () => ({
  type: types.END_RELOAD_LICHHOP
})

