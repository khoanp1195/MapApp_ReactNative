import { END_RELOAD_LICHHOP, START_RELOAD_LICHHOP } from "./action_types.ts";

const initialState = {
  isReload:false
};

const lichHopReducer = (state = initialState, action: { type: any; payload: { id: any; }; }) => {
  switch (action.type) {
   
      case START_RELOAD_LICHHOP:
      return {
        ...state,
        isReload:true
      };
      case END_RELOAD_LICHHOP:
      return {
        ...state,
        isReload:false
      };
    default:
      return state;
  }
};

export default lichHopReducer;
