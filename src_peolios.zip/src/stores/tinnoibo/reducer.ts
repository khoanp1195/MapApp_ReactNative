import { CHANGEPAGE_TINNOIBO } from "./action_types.ts";

const initialState = {
  item: undefined,
};

const typeTinnoBoReducer = (state = initialState, action: { type: any; payload: { id: any; }; }) => {
  switch (action.type) {
    case CHANGEPAGE_TINNOIBO:
      return {
        ...state,
        item: action.payload,
      };
    default:
      return state;
  }
};

export default typeTinnoBoReducer;
