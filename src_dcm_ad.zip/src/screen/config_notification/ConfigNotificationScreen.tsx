import { FlatList, StyleSheet, Switch, Text, TouchableOpacity, View } from "react-native";
import { useDispatch, useSelector } from "react-redux";
import { AppBarCustom } from "components/AppBarCustom";
import { useCallback, useEffect, useState } from "react";
import {
    getConfigNotification,
    updateConfigureNotification
} from "services/api/apiProvider";
import { ConfigNotification } from "services/database/models/ConfigNotification";
import NetInfo from "@react-native-community/netinfo";
import { SafeAreaView } from "react-native-safe-area-context";
import FastImage from "react-native-fast-image";
import { dimensWidth } from "../../../src/config/font";
import {showBottomSheet} from "../../redux/bottom_sheet/reducer";
import {hideBottomSheet} from "../../redux/bottom_sheet/reducer";
// @ts-ignore
export const ConfigNotificationScreen = ({ navigation }) => {
    // @ts-ignore
    const currentLanguage = useSelector((state) => state.languages.currentLanguage);
    // @ts-ignore
    const translations = useSelector((state) => state.languages.translations);
    const currentTranslations = translations[currentLanguage];
    const [data, setData] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    // @ts-ignore
    const { isConnected } = useSelector((state) => state.netInfo);
    const {isVisible} = useSelector((state: any) => state.bottomSheet);
    const dispatch = useDispatch();
    useEffect(() => {
        if (isConnected) {
            getConfigNotification().then(data => {
                setData(data?.data);
                setIsLoading(false);
                ConfigNotification.insertOrUpdateAll(data?.data);
            })
        }
        else {
            ConfigNotification.getAll().then(values => {
                // @ts-ignore
                setData(values);
                setIsLoading(false);
            })
        }

    }, [isConnected]);

    const onGoBack = useCallback(() => {
        navigation.goBack();
        dispatch(isVisible ? hideBottomSheet() : showBottomSheet());
    }, [])
    // @ts-ignore
    const CustomItemConfig = ({ Item1, Item2, Item3, styleContainer }) => {
        return <View style={[styles.container, styleContainer]}>
            <View style={styles.child1}>
                {Item1}
            </View>
            <View style={styles.child2}>
                {Item2}
            </View>
            <View style={styles.child3}>
                {Item3}
            </View>
        </View>;
    }
    // @ts-ignore
    const ItemRender = ({ item, index }) => {
        const enableCheckNotify = (item.IsConfig & 1) > 0;
        const enableCheckGmail = (item.IsConfig & 2) > 0;
        const [checkNotify, setCheckNotify] = useState(item.NotifyChecked);
        const [checkEmail, setCheckEmail] = useState(item.EmailChecked);
        return <CustomItemConfig
            Item1={(<Text style={styles.textTitle}>{item.Title}</Text>)}
            Item2={(<Switch value={checkNotify} disabled={!enableCheckNotify}
                trackColor={{ false: "#767577", true: "#2190FF" }}
                thumbColor={checkNotify == 'en' ? "#f4f3f4" : "#f4f3f4"}
                onValueChange={(value) => {
                    setCheckNotify(value);
                    // @ts-ignore
                    data[data.indexOf(item)].NotifyChecked = value;
                    ConfigNotification.insertOrUpdateAll([item]);
                    updateConfigureNotification(data);

                }} />)}
            Item3={(<Switch value={checkEmail} disabled={!enableCheckGmail}
                trackColor={{ false: "#767577", true: "#2190FF" }}
                thumbColor={checkEmail ? "#f4f3f4" : "#f4f3f4"}
                onValueChange={(value) => {
                    setCheckEmail(value);
                    // @ts-ignore
                    data[data.indexOf(item)].EmailChecked = value;
                    ConfigNotification.insertOrUpdateAll([item]);
                    updateConfigureNotification(data);
                }} />)}
            styleContainer={{ backgroundColor: index % 2 == 0 ? '#F1FAFF' : 'white' }} />
    }
    return <View style={{ backgroundColor: '#F8FBFC' }}>
        <View>
            {/* <AppBarCustom onPress={null} title={currentTranslations.configure_notification} navigation={navigation} RightControl={null}/> */}

            <View style={{ alignItems: 'center', backgroundColor: 'white', height: '15%' }}>
                <Text style={{ fontSize: 24, fontWeight: '600', marginTop: '3%' }}>Cài đặt</Text>
                <TouchableOpacity
                    activeOpacity={1}
                    style={{ backgroundColor: 'blue' }}
                    onPress={onGoBack}
                >
                    <FastImage
                        style={styles.icon_back}
                        resizeMode='contain'
                        source={require('../../../src/assets/images/icon_closeForm.png')}
                    />
                </TouchableOpacity>
            </View>

            <CustomItemConfig
                Item1={(<View />)}
                Item2={(<Text style={styles.textHeader}>Thông báo</Text>)}
                Item3={(<Text style={styles.textHeader}>Email</Text>)}
                styleContainer={{ backgroundColor: '#F0F0F0' }} />
            {
                data != null && data.length > 0 && <FlatList
                    data={data}
                    // @ts-ignore
                    keyExtractor={(item) => item.Rank.toString()} // Thay id bằng thuộc tính định danh của bạn
                    renderItem={({ item, index }) => (
                        <ItemRender item={item} index={index} />
                    )}
                />
            }
        </View>
    </View>
}

const styles = StyleSheet.create({
    textHeader: {
        fontSize: 15,
        fontWeight: '400',
        fontFamily: 'heritage_regular',
        lineHeight: 15,
    },
    icon_back: {
        height: dimensWidth(10),
        width: dimensWidth(10),
        position: 'absolute',
        right: '-47%',
        bottom: '5%'
    },
    textTitle: {
        color: 'black',
        fontSize: 15,
        fontWeight: '400',
        fontFamily: 'heritage_regular',
        lineHeight: 24,
        marginTop: 5
    },
    container: {
        flexDirection: 'row',
        width: '95%',
        height: 70,
        marginLeft: '2%',

    },
    child1: {
        flex: 6,
        justifyContent: 'center',
        marginLeft: 10,
    },
    child2: {
        flex: 2,
        justifyContent: 'center',
        alignItems: 'center',
    },
    child3: {
        flex: 2,
        justifyContent: 'center',
        alignItems: 'center',
    }
});
