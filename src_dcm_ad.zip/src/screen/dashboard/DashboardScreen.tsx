import { ActivityIndicator, SectionList, StyleSheet, Text, View, ImageBackground, Platform, processColor, Dimensions } from 'react-native';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../../redux/stores';
import TextCusTom from 'components/TextCusTom';
import { ThunkDispatch } from 'redux-thunk';
import NoDataView from 'components/NoDataView';
import { FlatList, RefreshControl, ScrollView } from 'react-native-gesture-handler';
import { arrayIsEmpty, getCurrentTimeFormatted, getParameterUrlDoc } from "../../utils/function";
import DocumentItem from "./components/DocumentItem";
import colors from "../../config/colors";
import { FontSize, dimnensHeight, windowHeight, windowWidth } from "../../config/font";
import AppBarDCM from "components/AppBarDCM";
import DocumentRecently from "services/database/models/DocumentRecently";
import { Document } from "services/database/models/Document";
import { BottomSheetMenu } from "../bottom_sheet_menu/BottomSheetMenu";
import BottomSheet from "@gorhom/bottom-sheet";
import { hideBottomSheet, showBottomSheet } from "../../redux/bottom_sheet/reducer";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getUnReadNotify } from "../../redux/dashboard/unreadReducer";
import { Calendar, LocaleConfig, WeekCalendar, CalendarProvider } from 'react-native-calendars';
import {
    getStandardDocNew,
    setStandardDocNew,
    setLoadingStandardDocNew, setLoadOneTimeStandardDocNew
} from "../../redux/dashboard/standardDocNewReducer";
import {
    getViewDocumentNew,
    setDocumentNewList,
    setLoadingDocumentNewList, setLoadOneTimeDocumentNewList
} from "../../redux/dashboard/documentNewReducer";
import {
    getDocumentFavorite,
    setDocumentFavoriteList, setLoadingDocumentFavoriteList,
    setLoadOneTimeDocumentFavoriteList
} from "../../redux/dashboard/favoriteReducer";
import {
    getDocumentMostView,
    setDocumentMostViewList, setLoadingDocumentMostViewList,
    setLoadOneTimeDocumentMostViewList
} from "../../redux/dashboard/mostViewReducer";
import {
    addItemToRecentlyViewedDocumentData,
    getRecentlyDoc,
    setLoadingRecentlyViewedDocument, setLoadOneTimeRecentlyViewedDocument, setRecentlyViewedDocument
} from "../../redux/dashboard/recentlyReducer";
import ShimmerList from "components/ShimmerList";
import { goToDocumentDetail } from "navigation/goToDetailNavigation";
import FastImage from 'react-native-fast-image';
import DeviceInfo from 'react-native-device-info';
import { fetchCurrentUsers } from 'services/api/apiProvider';
import Carousel from 'react-native-snap-carousel'
import { subsiteStore } from '../../../src/config/constants';
import { PieChart } from "react-native-charts-wrapper";

const dataPieChart = {
    dataSets: [
        {
            values: [
                { value: 0, label: "VB mới nhất" },
                { value: 0, label: "VB yêu thích" },
                { value: 0, label: "VB xem nhiều" },
                { value: 0, label: "Bộ tiêu chuẩn" },
            ],
            label: "",
            config: {
                colors: [
                    processColor("#f87080"),
                    processColor("#fdc065"),
                    processColor("#ab89f7"),
                    processColor("#dbedea")
                ],
                drawValues: true,
                valueTextSize: 15,
                valueTextColor: processColor("#000"),
                valueFormatter: "#.#'%'",
                sliceSpace: 5,
                selectionShift: 100,
                yValuePosition: "OUTSIDE_SLICE",
            },
        },
    ],
    highlights: [{ x: 2 }],
};

// @ts-ignore
const DashboardScreen = ({ navigation }) => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    // @ts-ignore
    const currentLanguage = useSelector((state) => state.languages.currentLanguage);
    // @ts-ignore
    const translations = useSelector((state) => state.languages.translations);
    const currentTranslations = translations[currentLanguage];
    const langId = currentLanguage === 'en' ? 1033 : 1066;
    const [dataChart, setdataChart] = useState(dataPieChart)
    const [dataHome, setDataHome] = useState<any>([
        {
            data: subsiteStore.getSubsite().includes("sqd") ? [
                {
                    title: currentTranslations.document, viewDocumentNewData: []
                },
                {
                    title: currentTranslations.newest_docs, viewDocumentNewData: []
                },
                { title: currentTranslations.recently_viewed_docs, recentlyViewedDocumentData: [] },
                { title: currentTranslations.most_favourite_docs, documentMostViewData: [] },
                { title: currentTranslations.most_view_docs, documentFavoriteData: [] },
            ] :
                [
                    {
                        title: currentTranslations.newest_docs, viewDocumentNewData: []
                    },
                    { title: currentTranslations.recently_viewed_docs, recentlyViewedDocumentData: [] },
                    { title: currentTranslations.most_favourite_docs, documentMostViewData: [] },
                    { title: currentTranslations.most_view_docs, documentFavoriteData: [] },
                ]
        }
    ]);
    const [refreshing, setRefreshing] = useState(false);
    const {
        documentStandard,
        isLoadStandardNewList,
        countDocumentStandard,
        isLoadOneTimeStandardNewList
    } = useSelector((state: RootState) => state.viewStandardDocNew);
    // @ts-ignore
    const { documentNewList, countdataNewList, isLoadDocumentNewList, isLoadOneTimeDocumentNewList } = useSelector((state: RootState) => state.viewDocumentNew);
    // @ts-ignore
    const { documentMostViewList, countMostViewList, isLoadingDocumentMostViewList, isLoadOneTimeDocumentMostViewList } = useSelector((state: RootState) => state.documentMostView);
    // @ts-ignore
    const { recentlyViewedDocumentData, isLoadingRecentlyViewed, isLoadOneTimeRecentlyViewed } = useSelector((state: RootState) => state.recentlyViewedDocument);
    // @ts-ignore
    const { documentFavoriteList, isLoadingDocumentFavoriteList, countFavoriteViewList, isLoadOneTimeDocumentFavoriteList } = useSelector((state: RootState) => state.documentFavorite);
    // @ts-ignore
    const { isConnected } = useSelector((state) => state.netInfo);
    // @ts-ignore
    const { currentSite } = useSelector((state) => state.sub_site);

    useEffect(() => {
        getData()
    }, [currentLanguage, currentSite])
    useEffect(() => {
        setDataHome([
            subsiteStore.getSubsite().includes("sqd") && currentLanguage === 'en' ?
                {
                    data: [
                        {
                            title: currentTranslations.document,
                            data: documentStandard,
                            isLoading: isLoadStandardNewList,
                            isLoadOneTime: isLoadOneTimeStandardNewList,
                        },
                        {
                            title: currentTranslations.newest_docs,
                            data: documentNewList,
                            isLoading: isLoadDocumentNewList,
                            isLoadOneTime: isLoadOneTimeDocumentNewList,
                        },
                        {
                            title: currentTranslations.recently_viewed_docs,
                            data: recentlyViewedDocumentData,
                            isLoading: isLoadingRecentlyViewed,
                            isLoadOneTime: isLoadOneTimeRecentlyViewed,
                        },
                        {
                            title: currentTranslations.most_favourite_docs,
                            data: documentFavoriteList,
                            isLoading: isLoadingDocumentFavoriteList,
                            isLoadOneTime: isLoadOneTimeDocumentFavoriteList,
                        },
                        {
                            title: currentTranslations.most_view_docs,
                            data: documentMostViewList,
                            isLoading: isLoadingDocumentMostViewList,
                            isLoadOneTime: isLoadOneTimeDocumentMostViewList,
                        },
                    ]
                } :
                {
                    data: [
                        {
                            title: currentTranslations.newest_docs,
                            data: documentNewList,
                            isLoading: isLoadDocumentNewList,
                            isLoadOneTime: isLoadOneTimeDocumentNewList,

                        },
                        {
                            title: currentTranslations.recently_viewed_docs,
                            data: recentlyViewedDocumentData,
                            isLoading: isLoadingRecentlyViewed,
                            isLoadOneTime: isLoadOneTimeRecentlyViewed,
                        },
                        {
                            title: currentTranslations.most_favourite_docs,
                            data: documentFavoriteList,
                            isLoading: isLoadingDocumentFavoriteList,
                            isLoadOneTime: isLoadOneTimeDocumentFavoriteList,
                        },
                        {
                            title: currentTranslations.most_view_docs,
                            data: documentMostViewList,
                            isLoading: isLoadingDocumentMostViewList,
                            isLoadOneTime: isLoadOneTimeDocumentMostViewList,
                        },
                    ]
                }
        ])
    }, [

        documentNewList,
        documentMostViewList,
        documentFavoriteList,
        recentlyViewedDocumentData,
        currentSite
    ])
    console.log("documentStandard - here : =>>> " + documentStandard)
    useEffect(() => {

    }, [recentlyViewedDocumentData]);
    const onRefresh = useCallback(() => {
        getData();
    }, []);

    const getDataNew = () => {
        Document.getNewDocument(false, false).then(values => {
            dispatch(setLoadOneTimeDocumentNewList(true));
            if (values != null && values.length > 0) {
                dispatch(setDocumentNewList(values));
            } else {
                dispatch(setLoadingDocumentNewList(true))
            }
            dispatch(getViewDocumentNew({ LangId: langId, Limit: 5, Offset: 0, Params: 'LangId,Offset,Limit', isConnected: isConnected }));
        })
    }
    const getDataFavorite = () => {
        Document.getNewDocument(false, true).then(values => {
            dispatch(setLoadOneTimeDocumentFavoriteList(true));
            if (values != null && values.length > 0) {
                dispatch(setDocumentFavoriteList(values));
            } else {
                dispatch(setLoadingDocumentFavoriteList(true))
            }
            dispatch(getDocumentFavorite({ LangId: langId, Params: 'Offset,Limit', Offset: 0, Limit: 5, isConnected: isConnected }))
        })
    }
    const getMostView = () => {
        Document.getNewDocument(true, false).then(values => {
            dispatch(setLoadOneTimeDocumentMostViewList(true));
            if (values != null && values.length > 0) {
                dispatch(setDocumentMostViewList(values));
            } else {
                dispatch(setLoadingDocumentMostViewList(true))
            }
            dispatch(getDocumentMostView({
                LangId: langId,
                Params: 'LangId,CategoryId,Offset,Limit',
                CategoryId: 5,
                Offset: 0,
                Limit: 5,
                isConnected: isConnected
            }))
        })

    }
    const getRecently = () => {
        Document.getDucmentRecently().then(values => {
            dispatch(setLoadOneTimeRecentlyViewedDocument(true))
            if (values != null && values.length > 0) {
                dispatch(setRecentlyViewedDocument(values));
            } else {
                dispatch(setLoadingRecentlyViewedDocument(false));
            }
            dispatch(getRecentlyDoc())
        })

    }

    const getStandard = () => {
        console.log("subsiteStore.getSubsite().includes", subsiteStore.getSubsite().includes("sqd"))
        if (subsiteStore.getSubsite().includes("sqd")) {
            Document.getStandardDocDashBoard().then(values => {
                dispatch(setLoadOneTimeStandardDocNew(true))
                if (values != null && values.length > 0) {
                    dispatch(setStandardDocNew(values));
                } else {
                    dispatch(setLoadingStandardDocNew(false));
                }
                dispatch(getStandardDocNew({ LangId: langId, Params: "Top,LangId", Top: 5, isConnected: isConnected }))
            })
        }

    }

    const getData = async () => {
        getRecently();
        getDataNew();
        getDataFavorite();
        getMostView();
        dispatch(getUnReadNotify());

    }
    const gotoDetailPress = (item: Document) => {
        goToDocumentDetail(navigation, item.Url, isConnected, false);
        setTimeout(() => saveItemClick(item), 1000);
    };
    const saveItemClick = async (item: Document) => {
        DocumentRecently.insertOrUpdateAll([
            {
                documentID: item.DocumentId,
                modified: getCurrentTimeFormatted()
            }
        ]);
        Document.insertOrUpdateAll([item])
        // @ts-ignore
        getRecently();
    }
    const chartDimention = useMemo(() => {
        const scale = Dimensions.get('window').scale
        const dimention = dimnensHeight(scale)
        return dimention
    }, [])

    useEffect(() => {
        const newData = {
            dataSets: [
                {
                    ...dataChart?.dataSets[0],
                    values: [
                        {
                            value: 10,
                            label: "VB mới nhất",
                        },
                        {
                            value: 20,
                            label: "VB yêu thích",

                        },
                        {
                            value: 30,
                            label: "VB xem nhiều",

                        },
                        {
                            value: 40,
                            label: "Bộ tiêu chuẩn",

                        },
                    ],
                },
            ],
            description: {
                text: 'This is Pie chart description',
                textSize: 15,
                textColor: processColor('darkgray'),

            }
        };
        // @ts-ignore
        setdataChart(newData);
    }, [documentNewList])

    const checkItemInChart = () => {
        if (countFavoriteViewList > 0 && countMostViewList > 0 && countdataNewList > 0)
            return 3
        else
            return 2
    }


  LocaleConfig.locales["vn"] = {
    monthNames: [
      "Tháng 1",
      "Tháng 2",
      "Tháng 3",
      "Tháng 4",
      "Tháng 5",
      "Tháng 6",
      "Tháng 7",
      "Tháng 8",
      "Tháng 9",
      "Tháng 10",
      "Tháng 11",
      "Tháng 12"
    ],
    monthNamesShort: [
      "Th 1",
      "Th 2",
      "Th 3",
      "Th 4",
      "Th 5",
      "Th 6",
      "Th 7",
      "Th 8",
      "Th 9",
      "Th 10",
      "Th 11",
      "Th 12"
    ],
    dayNames: ["Chủ nhật", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"],
    dayNamesShort: ["CN", "T2", "T3", "T4", "T5", "T6", "T7"]
  };
  LocaleConfig.defaultLocale = "vn";
    return (
        <View style={styles.root}>
            <ScrollView style={styles.container}>
            <ImageBackground
                source={require('assets/images/background.png')}
                resizeMode="cover"
                style={styles.container}>

                <View style={{flexDirection:'row'}}>
                    <View style={{flexDirection:'column', width:'100%'}}>
                    <Text style={styles.title_dashboard}>  Have a nice day  </Text>
                    <View style={styles.view_chart} >
                        <Text style={styles.title_dsc_chart}>Document statistic</Text>
                        {
                            dataChart != undefined ? (
                                <PieChart
                                    style={[styles.viewChart, {
                                        height: 120 + (chartDimention) + '%',
                                        width: 90 + (chartDimention * Dimensions.get('window').scale) + '%',
                                        marginTop: -80,
                                        alignSelf: 'center',
                                        marginRight: 200
                                    }]}
                                    logEnabled={true}
                                    chartBackgroundColor={processColor("transparent")}
                                    chartDescription={{ text: "" }}
                                    data={dataChart}
                                    legend={{
                                        enabled: false, // Disable legend
                                        horizontalAlignment: 'CENTER', // Set legend position to the left
                                        verticalAlignment: 'BOTTOM',// Adjust vertical alignment if necessary
                                    }}
                                    highlights={[]}
                                    noDataText={"No data chart !"}
                                    entryLabelColor={processColor("black")}
                                    entryLabelTextSize={12}
                                    touchEnabled={false}
                                    drawEntryLabels={false}
                                    usePercentValues={true}
                                    rotationEnabled={true}
                                    centerText={""}
                                    onSelect={() => { }}
                                    centerTextRadiusPercent={0}
                                    holeRadius={30}
                                    transparentCircleRadius={0}
                                    maxAngle={360}
                                    rotationAngle={45}
                                />
                            ) : null
                        }
                        <View
                            style={
                                {
                                    marginTop: checkItemInChart() == 3 ? '-50%' : '-40%',
                                    marginLeft: '60%',
                                    width: '40%',
                                    backgroundColor: 'white',
                                    height: '66%',
                                    flexDirection: 'column'
                                }
                            }>
                            <View style={{ flexDirection: 'row', height: 50 }}>
                                <View style={{ marginLeft: '10%', backgroundColor: '#f87080', width: 20, height: 20 }}>
                                </View>
                                <View >
                                    <Text
                                        style={{
                                            marginLeft: '8%', fontWeight: '600'
                                        }}
                                    >
                                        Vb mới nhất
                                    </Text>
                                    <Text
                                        style={{
                                            marginLeft: '8%',
                                            color: 'gray'
                                        }}
                                    >
                                        {countdataNewList} vb mới nhất
                                    </Text>
                                </View>
                            </View>


                            <View style={{ flexDirection: 'row', height: 50 }}>
                                <View style={{ marginLeft: '10%', backgroundColor: '#fdc065', width: 20, height: 20 }}>
                                </View>
                                <View >
                                    <Text
                                        style={{
                                            marginLeft: '8%', fontWeight: '600'
                                        }}
                                    >
                                        Vb yêu thích
                                    </Text>
                                    <Text
                                        style={{
                                            marginLeft: '8%',
                                            color: 'gray'
                                        }}
                                    >
                                        {countFavoriteViewList} Vb yêu thích
                                    </Text>
                                </View>
                            </View>


                            {
                                (countMostViewList != undefined && countMostViewList > 0) ?
                                    (<View style={{ flexDirection: 'row', height: 50 }}>
                                        <View style={{ marginLeft: '10%', backgroundColor: '#ab89f7', width: 20, height: 20 }}>
                                        </View>
                                        <View >
                                            <Text
                                                style={{
                                                    marginLeft: '8%', fontWeight: '600'
                                                }}
                                            >
                                                Vb xem nhiều nhất
                                            </Text>
                                            <Text
                                                style={{
                                                    marginLeft: '8%',
                                                    color: 'gray'
                                                }}
                                            >
                                                {countMostViewList} Vb xem nhiều nhất
                                            </Text>
                                        </View>
                                    </View>
                                    ) : null
                            }

                            {
                                (countDocumentStandard != undefined && countDocumentStandard > 0) ?
                                    (<View style={{ flexDirection: 'row', height: 50 }}>
                                        <View style={{ marginLeft: '10%', backgroundColor: '#dbedea', width: 20, height: 20 }}>
                                        </View>
                                        <View >
                                            <Text
                                                style={{
                                                    marginLeft: '8%', fontWeight: '600'
                                                }}
                                            >
                                                Bộ tiêu chuẩn
                                            </Text>
                                            <Text
                                                style={{
                                                    marginLeft: '8%',
                                                    color: 'gray'
                                                }}
                                            >
                                                {countDocumentStandard} Bộ tiêu chuẩn
                                            </Text>
                                        </View>
                                    </View>
                                    ) : null
                            }


                        </View>



                    </View>
                    </View>
               
                    <View>
                    <Calendar
                
                    onDayPress={day => {
                    }}
                  //  markedDates={dotCalendar}
                    theme={{
                      backgroundColor: '#F3F9FF',
                      calendarBackground: '#F3F9FF',
                      textSectionTitleColor: '#b6c1cd',
                      selectedDayBackgroundColor: '#00adf5',
                      selectedDayTextColor: '#ffffff',
                      todayTextColor: '#0072C6',
                      dayTextColor: '#2d4150',
                      textDayHeaderFontWeight: '600',
                    }}
                    style={styles.calendar}
                  />
                    </View>


                </View>


                <SectionList sections={dataHome}
                    refreshControl={
                        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor='#0054AE' />
                    }
                    renderItem={({ item }) => (
                        <View>

                            <TextCusTom i18nKey={item.title} style={styles.textTitle} />
                            {!arrayIsEmpty(item.data) && !item.isLoading ? (
                                <FlatList
                                    contentContainerStyle={styles.containerFlatList}
                                    data={item.data}
                                    horizontal={true}
                                    renderItem={({ item, index }) => (
                                        <DocumentItem item={item} index={index}
                                            gotoDetail={() => gotoDetailPress(item)} />
                                    )}
                                    showsHorizontalScrollIndicator={false}
                                />

                            ) : (
                                (!item.isLoading && arrayIsEmpty(item.data) && item.isLoadOneTime) ? (
                                    <NoDataView isHomeView={true} />
                                ) : (
                                    <ShimmerList /> // Show a loading indicator when isLoading is true
                                )
                            )}
                            <View style={styles.line} />
                        </View>
                    )}
                    keyExtractor={(item, index) => item.title}>
                </SectionList>
            </ImageBackground>
            </ScrollView>
        </View>
    );
};
const styles = StyleSheet.create({
    root: { flex: 1, marginBottom: 0, height: '100%' },
    container: { flex: 1, backgroundColor: 'transparent' },
    containerFlatList: {
        marginLeft: '4%',
        width: '105%',
        marginBottom: '2%'

    },
    viewChart: {
        backgroundColor: 'transparent',
        borderRadius: 15,
    },
    title_dsc_chart: {
        marginLeft: '5%', marginTop: '2%', fontSize: 25, fontWeight: '600'
    },
    view_chart: {
        width: '50%',
        height: 300,
        marginLeft:'5%',
        backgroundColor: 'white',
        flexDirection: 'column',
        borderRadius: 25,
        shadowOffset: {
            width: 5,   // Horizontal shadow offset
            height: 5,  // Vertical shadow offset
        },
        shadowOpacity: 0.1,
        shadowRadius: 20,
        elevation: 5, // Android only, controls the depth of the shadow
        marginTop: '2%',
    },
    title_dashboard: {
        marginLeft: '6%',
        marginTop: '2%',
        fontWeight: '600',
        fontSize: 20,
        color: '#006885'
    },
    textTitle: {
        color: '#DBA410',
        fontSize: 18,
        fontWeight: '600',
        margin: 20
    },
    line: {
        height: 0.5,
        backgroundColor: colors.grey_co,
        marginTop: 20
    },
    vnaBackgroundImage: {
        height: '100%',
        width: '100%',
        position: 'absolute',
        zIndex: 0,
        aspectRatio: 1,
    },
    calendar: {
        borderColor: 'gray',
        height: '20%',
        width:'20%',
        shadowColor: 'lightgray',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2,
        shadowRadius: 4,
      },
});
export default React.memo(DashboardScreen);
