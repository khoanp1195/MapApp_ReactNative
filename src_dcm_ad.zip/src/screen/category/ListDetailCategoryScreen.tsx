import {StyleSheet, Text, TouchableOpacity, View} from "react-native";
import {goToDocumentDetail} from "navigation/goToDetailNavigation";
import {FastImageCustom} from "components/FastImageCustom";
import {dimensWidth, windowWidth} from "../../config/font";
import FastImage from "react-native-fast-image";
import {format_dd_mm_yy, isNullOrEmpty} from "../../utils/function";
import {getListDocumentCategory} from "services/api/apiProvider";
import React, {useCallback, useEffect, useState} from "react";
import {useNavigation} from "@react-navigation/native";
import {useDispatch, useSelector} from "react-redux";
import {ListLoadMore} from "components/ListLoadMore";
import {DocumentCategory} from "services/database/models/DocumentCategory";
import { Col, Row } from 'react-native-flex-grid';
export const ListDetailCategoryScreen = () => {
    const navigation = useNavigation();
    const currentLanguage = useSelector((state: any) => state.languages.currentLanguage);
    const langId = currentLanguage === 'en' ? 1033 : 1066;
    const [change, setChange] = useState(false);
    // @ts-ignore
    const {positionStayCategory} = useSelector((state: RootState) => state.category);
    // @ts-ignore
    const {isConnected} = useSelector((state) => state.netInfo);
    // @ts-ignore
    const itemRender = ({item, index}) => {
        // @ts-ignore
        return   <View style={{ flexDirection: 'row',
        width: '100%',
        padding : -20,
        marginVertical: -25,
        paddingTop: 15,
        height:  130, backgroundColor: index % 2 == 0 ? '#F1FAFF' : 'white'}} >
        <View key={index}  >
          <TouchableOpacity  onPress={() => goToDocumentDetail(navigation, item.StorageCode,isConnected,false)}>
            <Row style={styles.cellContent}>
              <Col style={{ padding: 10, width: 210, flexDirection: 'row' }}>
                <FastImage   style={{
                height: 35,
                width: 35,
                position: 'absolute',
                left: 25, 
                top:15
              }}
                source={{ uri: item.Thumbnail }}
                defaultSource={require('assets/images/icon_document_default.png')}
                />
                <Text numberOfLines={1}  style={{ marginLeft:'22%', marginTop: 17, color: '#2376E0', width: '100%' }}>{item.Code}</Text>
              </Col>
              <Col style={{ padding: 10, width: 210, flexDirection: 'row'   }}>
                <Text numberOfLines={1} style={{marginLeft:'30%', marginTop: 17,width: 170  }}>{item.Title}</Text>
              </Col>
              <Col style={{ padding: 10, width: 210, flexDirection: 'row'   }}>
                <Text numberOfLines={1} style={{marginLeft:'22%', width: 80,marginTop: 17 }}>{format_dd_mm_yy(item.IssueDate)}</Text>
              </Col>
              <Col  style={{ padding: 10, width: 210, flexDirection: 'row' }}>
                <Text numberOfLines={1} style={{marginLeft:'10%', width: 80,marginTop: 17 }}>{format_dd_mm_yy(item.IssueDate)}</Text>
              </Col>
            </Row>
          </TouchableOpacity>

        </View>
      </View>
    }
    const List = useCallback(() => {
        return <ListLoadMore numColumn={1} callData={getData} ItemRenderFlatlist={itemRender} enableMoreData={true}
                             limit={15}/>;
    }, [positionStayCategory])
    const getData = async (limit: number, offet: number, isOnline: any) => {
        if (isOnline) {
            const data = await getListDocumentCategory(langId, offet, limit, {
                "Parameters": {
                    "AreaCategoryId": positionStayCategory[positionStayCategory.length - 1].PrimaryKey,
                    "DocumentGroupId": "1",
                    "Title": "",
                    "Code": "",
                    "StorageCode": "",
                    "Int2": ""
                }
            });
            if (data != null) {
                DocumentCategory.insertOrUpdateAll(data);
            }
            return data;
        } else {
            return DocumentCategory.getAll(positionStayCategory[positionStayCategory.length - 1].PrimaryKey, limit, offet);
        }
    }
    return <View style={{
        flex: 1,
        borderRadius:15
    }}>
        <List/>
    </View>
}

const styles = StyleSheet.create({
    cellContent: {
        width: windowWidth,
        height: 70,
        borderRadius:15
      },

    itemRender:{
      
    }
  
  })