import React, { useState, useRef, useEffect } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
    Image,
    TouchableWithoutFeedback,
    Animated,
    ImageBackground
} from 'react-native';
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../redux/stores";
import { addPositionStayCategory } from "../../redux/category/reducer";
import { DocumentAreaCategory } from "services/database/models/DocumentAreaCategory";
import { FastImageCustom, NoDataView, TextCusTom } from "components/index";
import { useNavigation } from "@react-navigation/native";
import loadMoreListReducer, { changeColumnFlatList } from "../../redux/list_load_more/reducer";
import { ListDetailCategoryScreen } from "./ListDetailCategoryScreen";
import { ThumpDetailCategoryScreen } from "./ThumpDetailCategoryScreen";
import * as Animatable from 'react-native-animatable';
import { FontFamily, dimensWidth, windowWidth } from '../../../src/config/font';


// @ts-ignore
const LeftMenu = ({ isOpen, onClose, onMenuItemClick, menuItems }) => {
    const slideAnimation = useRef(new Animated.Value(0)).current;
    const currentLanguage = useSelector((state: any) => state.languages.currentLanguage);
    const scaleValue = React.useRef(new Animated.Value(0)).current;
    const [showModal, setShowModal] = React.useState(isOpen);
    const translateXValue = React.useRef(new Animated.Value(0)).current;
    React.useEffect(() => {
        toggleModal();
    }, [isOpen]);
    const toggleModal = () => {
        if (isOpen) {
            // setShowModal(true);
            Animated.parallel([
                Animated.timing(scaleValue, {
                    toValue: 1,
                    duration: 200,
                    useNativeDriver: true,
                }),
                Animated.timing(translateXValue, {
                    toValue: 0, // Start from 0 to slide in from left to right
                    duration: 200,
                    useNativeDriver: true,
                }),
            ]).start();
        } else {
            Animated.parallel([
                Animated.timing(scaleValue, {
                    toValue: 0,
                    duration: 200,
                    useNativeDriver: true,
                }),
                Animated.timing(translateXValue, {
                    toValue: -200, // Slide out to the left
                    duration: 200,
                    useNativeDriver: true,
                }),
            ]).start(() => onClose());
        }
    };

    const closeMenu = () => {
        Animated.parallel([
            Animated.timing(scaleValue, {
                toValue: 0,
                duration: 100,
                useNativeDriver: true,
            }),
            Animated.timing(translateXValue, {
                toValue: -200, // Slide out to the left
                duration: 50,
                useNativeDriver: true,
            }),
        ]).start(() => onClose());
    };

    if (isOpen) {
        slideAnimation.setValue(0);
    }




    return (
        <Animated.View
            style={[
                styles.menuContainer,
                isOpen ? styles.openMenu : styles.closedMenu,
                {
                    transform: [
                        {
                            translateX: scaleValue.interpolate({
                                inputRange: [0, 1],
                                outputRange: [-200, 4], // Adjust the distance for your desired slide length
                            }),
                        },
                    ],
                },
            ]}
        >
            {
                menuItems.length != 0 ? menuItems.map((item: any) => (
                    <View
                        style={{
                            marginTop: '5%',


                        }}
                        key={item.PrimaryKey}
                    >
                        <TouchableOpacity
                            style={{
                                flexDirection: 'row',
                                height: '10%',
                                marginLeft: 45,

                            }}
                            onPress={() => {
                                onMenuItemClick(item);
                                closeMenu(); // Close the menu when an item is clicked
                            }}>
                            <Image
                                style={styles.icon_arrow}
                                resizeMode='contain'
                                source={require('../../assets/images/icon_categoryDefault.png')}

                            />
                            <Text
                                numberOfLines={1}
                                style={styles.menuItem}>
                                {currentLanguage !== 'en' ? item["Title"] : item["TitleEN"]}
                            </Text>

                        </TouchableOpacity>


                        <Image
                            style={styles.icon_arrow1}
                            resizeMode='contain'
                            source={require('../../assets/images/icon_arrow.png')}

                        />

                    </View>

                )) :
                    <NoDataView isHomeView={false} />
            }
        </Animated.View>
    );
};

export const DetailCategoryScreen = () => {
    const navigation = useNavigation();
    const dispatch = useDispatch();
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [menus, setMenus] = useState();
    const currentLanguage = useSelector((state: any) => state.languages.currentLanguage);
    const { columnFlatlist } = useSelector((state: any) => state.loadMoreList);
    const langId = currentLanguage === 'en' ? 1033 : 1066;

    // @ts-ignore
    const { positionStayCategory } = useSelector((state: RootState) => state.category);
    useEffect(() => {
        DocumentAreaCategory.getChildByParentId(positionStayCategory[positionStayCategory.length - 1].PrimaryKey).then(values => {
            setMenus(values);
        })
    }, [positionStayCategory]);
    const openMenu = () => {
        setIsMenuOpen(true);
    };

    const closeMenu = () => {
        setIsMenuOpen(false);
    };

    const handleMenuItemClick = (item: any) => {
        dispatch(addPositionStayCategory(item))
    };

    const overlayRef = useRef(null);

    const handleOverlayClick = () => {
        if (isMenuOpen) {
            closeMenu();
        }
    };
    return (
        <View style={styles.container}>
            <TouchableWithoutFeedback onPress={handleOverlayClick}>
                <View ref={overlayRef} style={isMenuOpen ? styles.overlay : null} />
            </TouchableWithoutFeedback>

            <ImageBackground source={require('assets/images/background.png')} style={{
                height: '100%',
                width: "100%",
            
            }}>

           <View style={ columnFlatlist == 1  ? styles.columnFlatlistView : styles.columnThumbView
                }>
           <View style={styles.headerContainer}>
                    <View style={{ flexDirection: 'row' }}>
                        <View style={{ padding: 10 }}>
                            <TouchableOpacity onPress={openMenu}>
                                <Image
                                    style={{ height: 30, width: 30 }}
                                    source={require('assets/images/icon_menu.png')}
                                />
                            </TouchableOpacity>
                        </View>
                        <View style={styles.titleContainer}>
                            <Text style={styles.title}>{currentLanguage === 'en' ?
                                positionStayCategory[positionStayCategory.length - 1].TitleEN :
                                positionStayCategory[positionStayCategory.length - 1].Title}
                            </Text>
                        </View>
                        <View style={{ padding: 10 }}>
                            <TouchableOpacity onPress={() => {
                                dispatch(changeColumnFlatList(columnFlatlist == 1 ? 2 : 1))
                            }}>
                                <Image
                                    style={styles.image}
                                    source={columnFlatlist == 1 ? require('assets/images/icon_show_thumb.png') : require('assets/images/icon_show_list.png')}
                                    resizeMode={"stretch"}
                                />
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>

                <View style={{
                    marginTop: 15,
                    height: 1,
                    width: '107%',
                    backgroundColor: '#C0C0C0',
                    marginLeft: '1.5%',
                    borderRadius:15,
                    zIndex:99             
                }} />
                <View style={ columnFlatlist == 1  ? styles.columnFlatlist : styles.columnThumb
                }>
                    {
                        columnFlatlist == 1 ?
                            (<View style={styles.headerContainerGrid}>
                                <Text  style={styles.gridItem}>
                                    Mã văn bản
                                </Text>
                                <TextCusTom i18nKey={'Tên văn bản'} style={styles.gridItem}/>
                                <TextCusTom i18nKey={'Ngày ban hành'} style={styles.gridItem}/>
                                <TextCusTom i18nKey={'Ngày hiệu lực'} style={styles.gridItem}  />
                            </View>) : null
                    }
                    {
                        columnFlatlist == 1 ?

                            <ListDetailCategoryScreen /> :
                            <ThumpDetailCategoryScreen />
                    }
                </View>
           </View>

            </ImageBackground>

            {isMenuOpen && (

                <LeftMenu isOpen={isMenuOpen} onClose={closeMenu} onMenuItemClick={handleMenuItemClick}
                    menuItems={menus} />
            )}
        </View>
    );
};

const styles = StyleSheet.create({
    image: {
        height: 30,
        width: 30
    },
    titleContainer: {
        flex: 1,
        justifyContent: 'center',
    },
    textHeader_category_first: {
        color: 'black',
        fontWeight: '400',
        fontFamily: FontFamily.HERITAGE_REGULAR,
        width: 100,
        marginBottom: 15,
        fontSize: 16,
        height: 30,
        marginLeft:'7%'
    },
    textHeaderRight2: {
        color: 'black',
        fontSize: 16,
        fontWeight: '400',
        fontFamily: FontFamily.HERITAGE_REGULAR,  
        marginBottom: 15,
        marginLeft: '20%',
        height: 30
    },
    textHeaderRight: {
        color: 'black',
        fontSize: 16,
        fontWeight: '400',
        fontFamily: FontFamily.HERITAGE_REGULAR,
        marginBottom: 15,
        marginLeft: '18%',
        height: 30
    },
    textHeader_category: {
        color: 'black',
        fontSize: 16,
        fontWeight: '400',
        fontFamily: FontFamily.HERITAGE_REGULAR,
        width: 110,
        marginBottom: 15,
        marginLeft: '12%',
        height: 30
    },
    icon_arrow: {
        height: dimensWidth(20),
        width: dimensWidth(20),
        marginLeft: '-12%',
        marginTop: '-5%'
    },
    icon_arrow1: {
        height: dimensWidth(5),
        width: dimensWidth(5),
        marginLeft: '90%',
        marginBottom: '-12%',

    },
    headerContainer: {
        flexDirection: 'column',
        backgroundColor: 'transparent',
        paddingHorizontal: 15,
        height: 40,
        marginTop: 5
    },
    title: {
        fontSize: 20,
        color: '#000000',
        fontFamily: 'heritage_regular',
        lineHeight: 24,
        fontWeight: '400',
        marginLeft: '2%'
    },
    headerContainerGrid: {
        paddingTop: 25,
        flexDirection: 'row',
        backgroundColor: '#F0F0F0',
        height: 58,
        width: '100%',
        borderColor: 'lightgray',
        borderRadius: 15,
    },
    gridItem: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 8,
        marginLeft:'10%',
        lineHeight:15.6,
        fontWeight:'400',
        fontSize:13
      },
    columnFlatlist: {
        flexDirection: 'column',
        flex: 1,
        borderWidth: 0.5,
        borderColor: 'lightgray',
        borderRadius: 15,
        width: '90%',
        alignSelf: 'center',
        marginTop: 20,
        backgroundColor:'#F0F0F0',
        zIndex:99
    },

    columnFlatlistView:{
        height: '85%',borderRadius: 15,
        width: "100%",
    },
    columnThumbView:{
        height: '100%',borderRadius: 15,
        width: "100%",
    },

    columnThumb: {
        flexDirection: 'column',
        flex: 1,
        marginTop: 20,
        marginLeft:'3%'
    },


    container: {
        flex: 1,
        backgroundColor: 'white',
    },
    menuContainer: {
        position: 'absolute',
        top: 60,
        left: -200, // Adjust the left position to control menu visibility
        width: 350, // Set the width of the menu
        height: '92%',
        backgroundColor: '#fff',
        borderRightWidth: 1,
        borderColor: '#ccc',
        zIndex: 999, // Ensure the menu is above other components
    },
    openMenu: {
        left: 0,
    },
    closedMenu: {
        left: -200,
    },
    menuItem: {
        padding: '10%',
        borderBottomWidth: 1,
        borderBottomColor: '#ccc',
        fontSize: 12,
        height: '40%',
        marginTop: '-8%'
    },
    icon_next: {
        height: dimensWidth(15),
        width: dimensWidth(15),
        marginTop: '-60%',


    },
    overlay: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'transparent', // Use transparent background to capture taps
        zIndex: 998, // Ensure the overlay is above other components, but below the menu
    },
});
