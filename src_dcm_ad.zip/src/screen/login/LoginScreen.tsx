import React, { useCallback, useEffect, useState } from 'react';
import {
    View,
    Text,
    TextInput,
    ImageBackground,
    StyleSheet,
    TouchableOpacity, Image, Platform, Alert, PermissionsAndroid,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../../redux/stores'
import { login } from '../../redux/login/loginReducer'
import { auth } from "../../redux/auth/reducer";
import {
    getModified,
    getPassword,
    getUsername,
    saveCredentials,
    saveCurrentUser,
    saveModified, saveSiteChangeType
} from "../../utils/asyncStrorage";
import { getCurrentTimeFormatted, isNullOrEmpty } from "../../utils/function";
import {
    callLogin,
    getAllMasterData,
    getCategoryDefine,
    getCurrentUser,
    getListSites,
    GetSettingsByKey
} from "services/api/apiProvider";
import { BaseSubSite, currentUserStore, subsiteStore } from "../../config/constants";
import NetInfo from "@react-native-community/netinfo";
import { DocumentAreaCategory } from "services/database/models/DocumentAreaCategory";
import { FavoriteFolder } from "services/database/models/FavoriteFolder";
import { DocumentType } from "services/database/models/DocumentType";
import { values } from "@nozbe/watermelondb/utils/fp";
import { SubSite } from "services/database/models/SubSite";
import { setSubSite } from "../../redux/subsite/reducer";
import { StandardDoc } from "services/database/models/StandardDoc";
import { dimensWidth, windowHeight, windowWidth } from '../../../src/config/font';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import FastImage from 'react-native-fast-image';
import { UserGreyIcon } from 'assets/svg';
import LoadingViewLogin from 'components/LoadingViewLogin';

function LoginScreen() {

    const dispatch = useDispatch();
    // @ts-ignore
    const { isAuth, isLoading, error } = useSelector((state: RootState) => state.login);
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [isShowPass, setShowPass] = useState(false);
    const [isShowWaitingView, setShowWaitingView] = useState(false);

    // @ts-ignore
    const currentSite = useSelector((state) => state.sub_site.currentSite);
    useEffect(() => {
        const showErr = async () => {
            const user = await getUsername();
            const pass = await getPassword();
            if (error != null && !isNullOrEmpty(user) && !isNullOrEmpty(pass)) {
                Alert.alert("Alert", "Unable to log in, please try again later");
            }

        }
        showErr();
    }, [error]);
    console.log("Error - login: " + error)
    useEffect(() => {
        subsiteStore.setSubsite(currentSite);
        const reLogin = async () => {
            const connect = await NetInfo.fetch()
            if (connect.isConnected) {
                // @ts-ignore
                setUsername(await getUsername());
                // @ts-ignore
                setPassword(await getPassword());
                // @ts-ignore
                dispatch(login({ username: await getUsername(), password: await getPassword() }));
            } else {
                getCurrentUser().then(user => {
                    currentUserStore.setCurrentUser(user);
                })
                dispatch(auth());
            }
        }
        reLogin();
    }, []);
    useEffect(() => {
        const checkAuth = async () => {
            const modified = await getModified();
            const getData = () => {
                if (subsiteStore.getSubsite().includes("sqd")) {
                    getCategoryDefine().then(value => {
                        StandardDoc.insertOrUpdateAll(value)
                    })
                }
                GetSettingsByKey("SiteChangeType").then(value => {
                    if (value != undefined && value != null && value.length > 0 && value[0].VALUE != null)
                        saveSiteChangeType(value[0].VALUE)
                })
                getAllMasterData("DocumentAreaCategory,FavoriteFolder,DocumentType", modified).then(values => {
                    DocumentAreaCategory.insertOrUpdateAll(values.DocumentAreaCategory);
                    FavoriteFolder.insertOrUpdateAll(values.FavoriteFolder);
                    DocumentType.insertOrUpdateAll(values.DocumentType);
                    saveModified(getCurrentTimeFormatted());
                });
            }
            if (isAuth) {
                saveCredentials(username, password);
                getListSites(modified).then(value => {
                    SubSite.insertOrUpdateAll(value)
                })
                getCurrentUser().then(r => {
                    console.log("Default site", r.DefaultSite)
                    if (r.DefaultSite.includes(BaseSubSite)) {
                        currentUserStore.setCurrentUser(r);
                        saveCurrentUser(r);
                        dispatch(auth());
                        setTimeout(
                            async () => {
                                getData();
                            },
                            350
                        )
                    } else {
                        const lstSpitSite = r.DefaultSite.split('/');
                        dispatch(setSubSite(lstSpitSite[lstSpitSite.length - 1]))
                        callLogin(username, password).then(_ => {
                            getCurrentUser().then(r => {
                                console.log("Default site", r.DefaultSite)
                                currentUserStore.setCurrentUser(r);
                                saveCurrentUser(r);
                                dispatch(auth());
                                setTimeout(
                                    async () => {
                                        getData();
                                    },
                                    350
                                )
                            })
                        })
                    }
                });

            }
        }
        checkAuth();
    }, [isAuth, dispatch]);
    return (
        <KeyboardAwareScrollView>
            <View style={styles.bg_login}>
                {(isAuth || isLoading || isShowWaitingView) ? (
                    <View style={styles.bg_login}>
                        <FastImage
                            style={styles.vnaBackgroundImage}
                            source={require('../../assets/images/img_vnaPlane.png')}
                        />
                        <FastImage
                            style={styles.vnaImage}

                            source={require('../../assets/images/vietname_airline.png')}
                        />
                        <View style={{ backgroundColor: 'blue', width: '100%' }}></View>

                    </View>
                ) : (
                    <>
                        <View style={styles.bg_login}>

                            <FastImage
                                style={styles.vnaBackgroundImage}
                                source={require('../../assets/images/img_vnaPlane.png')}
                            />
                            <FastImage
                                style={styles.vnaImage}

                                source={require('../../assets/images/vietname_airline.png')}
                            />
                            <View style={{
                                flexDirection: 'column', height: 300, position: 'absolute',
                                zIndex: 1, marginTop: '20%', alignContent: 'center', alignItems: 'center', backgroundColor: 'transparent'
                            }}>

                                <Text style={{ textAlign: 'center', fontSize: 18, marginTop: 20, color: 'white', fontWeight: '700', zIndex: 1 }}>Enter your business Email</Text>
                                <View style={styles.containerTextInput}>
                                    <UserGreyIcon />
                                    {/* <Image style={styles.iconLeft} source={require('assets/images/icon_username.png')} /> */}
                                    <TextInput
                                        style={styles.input}
                                        placeholder="User name"
                                        value={username}
                                        onChangeText={text => setUsername(text)}
                                        autoCapitalize='none'
                                    />
                                    {username !== '' && (
                                        <TouchableOpacity onPress={() => setUsername('')}>
                                            <Image
                                                style={styles.iconRight}
                                                source={require('assets/images/icon_delete_text.png')}
                                            />
                                        </TouchableOpacity>
                                    )}


                                    <View style={styles.containerTextInputPassword}>
                                        <Image style={styles.iconLeft} source={require('assets/images/icon_password.png')} />
                                        <TextInput
                                            style={styles.input}
                                            placeholder="Password"
                                            value={password}
                                            onChangeText={text => setPassword(text)}
                                            secureTextEntry={!isShowPass}
                                            autoCapitalize='none'
                                        />
                                        {password !== '' && (
                                            <TouchableOpacity onPress={() => setShowPass(!isShowPass)}>
                                                <Image
                                                    style={styles.iconRight}
                                                    source={!isShowPass ? require('assets/images/icon_show_password.png') : require('assets/images/icon_unshow_password.png')}
                                                />

                                            </TouchableOpacity>
                                        )}

                                    </View>
                                </View>

                                {
                                    //    isShowWarning && <TextCusTom i18nKey={languages.incorrect_login} style={styles.textWarning} />
                                }

                            </View>
                            <TouchableOpacity
                            style={styles.button}
                            onPress={async () => {

                                if (isNullOrEmpty(username) || isNullOrEmpty(password)) {
                                    Alert.alert("Alert", "Username or password is blank. Please check again");
                                }

                                else {
                                    // @ts-ignore
                                    dispatch(login({ username, password }));
                                    setShowWaitingView(true);
                                }
                            }}>
                            <Text style={styles.textLoginButton}>Login</Text>
                        </TouchableOpacity>
                        </View>
                  
    
                    </>
                )}
                
           
            </View>

            <LoadingViewLogin isLoading={isLoading} />

        </KeyboardAwareScrollView>

    );
}

export default React.memo(LoginScreen);
const styles = StyleSheet.create({
    loadingContainer: {
        flex: 1,
        justifyContent: 'flex-end', // Để căn giữa theo chiều dọc dưới cùng
        alignItems: 'center', // Để căn giữa theo chiều ngang
        marginBottom: 50, // Điều chỉnh khoảng cách dưới cùng
        width: '100%',
        backgroundcolor: 'blue'
    },
    loadingText: {
        fontSize: 16,
        fontFamily: 'heritage_regular',
        lineHeight: 20,
    },
    backgroundImage: {
        flex: 1,
        resizeMode: 'cover',
    },
    container: {
        // flex: 1,
        // justifyContent: 'center',
        // alignItems: 'center',

        flexDirection: 'column',
        alignItems: 'center',
        width: windowWidth,
        height: windowHeight,
        backgroundColor: 'transparent',
    },

    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'white',
        borderRadius: 5, // Set the border radius to round the corners
        borderWidth: 1, // Add a border
        borderColor: '#E5E5E5', // Set the border color
        width: '80%',
        height: 40,
        marginBottom: 10

    },
    iconLeft: {
        marginLeft: 10,
        height: 15,
        width: 15,
        resizeMode: 'contain'
    },
    iconRight: {
        marginRight: 10,
        height: 15,
        width: 15,
        resizeMode: 'contain'
    },
    input: {
        paddingHorizontal: 10,
        flex: 1,
    },
    containerTextInput: {
        flexDirection: 'row',
        alignItems: 'center',
        height: dimensWidth(20),
        width: dimensWidth(150),
        backgroundColor: '#fff',
        borderColor: '#E5E5E5',
        paddingLeft: 18,
        borderRadius: 10,
        borderWidth: 1,
        marginTop: 40,
        paddingRight: 10,
        zIndex: 1, // Set the zIndex of this view

    },
    button: {
        borderRadius: 5,
        padding: 10,
        width: '36%',
        alignItems: 'center',
        backgroundColor: '#E6B441',
        marginTop:-220,
        zIndex:99
    

    },
    loading: {
        height: '100%',
        width: '100%',
        alignItems: 'center',
        justifyContent: 'flex-end',
    },
    textLoginButton: {
        color: '#FFFFFF'
    },
    bg_login: {
        flexDirection: 'column',
        alignItems: 'center',
        width: windowWidth,
        height: windowHeight,
        backgroundColor: 'transparent',
        flex:1  ,
     

    },
    containerTextInputPassword: {
        flexDirection: 'row',
        alignItems: 'center',
        height: dimensWidth(20),
        width: dimensWidth(150),
        backgroundColor: '#fff',
        borderColor: '#E5E5E5',
        paddingLeft: 18,
        borderRadius: 10,
        borderWidth: 1,
        marginTop: 40,
        paddingRight: 10,
        zIndex: 1, // Set the zIndex of this view
        position: 'absolute', // Position this view
        top: 50

    },
    vnaBackgroundImage: {
        height: '100%',
        width: '100%',

    },
    vnaImage: {
        height: 35,
        width: 310,
        position: 'absolute',
        right: 50,
        bottom: 60,
        zIndex: 1,
    },
});
