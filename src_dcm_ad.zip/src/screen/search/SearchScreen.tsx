import React, {useCallback, useEffect, useState} from "react";
import {useDispatch, useSelector} from "react-redux";
import {
    Image,
    ImageBackground,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    View,
    TouchableWithoutFeedback,
    Keyboard,
    Text,
    FlatList,
} from "react-native";
import {currentUserStore} from "../../config/constants";
import {setSearchTerm} from "../../redux/search_result/reducer";
import {useNavigation} from "@react-navigation/native";
import {SearchHistory} from "services/database/models/SearchHistory";
import {getCurrentTimeFormatted, isNullOrEmpty} from "../../utils/function";
import * as Animatable from 'react-native-animatable';
import { fonts } from "@rneui/base";

export const SearchScreen = () => {
    const currentLanguage = useSelector((state: any) => state.languages.currentLanguage);
    const translations = useSelector((state: any) => state.languages.translations);
    const currentTranslations = translations[currentLanguage];
    const [keySearch, setKeySearch] = useState("");
    const data = currentUserStore.getCurrentUser().TopUsedKey.split(",");
    const searchTerm = useSelector((state: any) => state.search_result.searchTerm);
    const [isSelectSearch, setisSelectSearch] = useState(false)
    const navigation = useNavigation();
    const dispatch = useDispatch();
    useEffect(() => {
        setKeySearch(searchTerm)
    }, [searchTerm]);




    // @ts-ignore
    const renderItem = ({item,index}) => (

        <TouchableOpacity onPress={() => {
            // @ts-ignore
            navigation.navigate('search_result')
            dispatch(setSearchTerm(item))
        }}>
    <View style={styles.listItemContainer}>
                <Image
                    source={require("assets/images/icon_search_1.png")}
                    style={styles.searchBarIcon}
                />
                <Text style={styles.listItemText}>{item}</Text>
            </View>
      
        </TouchableOpacity>
    );

    return (
        <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
            <ImageBackground
                source={require("assets/images/background.png")}
                style={styles.imgBackground}
            >
                <View style={styles.container} >
                    <View style={{padding: 20 ,marginLeft:'8%'}}>
                    <Text style={{fontSize:30,fontWeight:400}}>Tìm kiếm</Text>
                    </View>
                    <TouchableOpacity style={styles.searchBarContainer} onPress={() => {
                              navigation.navigate('search_result')
                              dispatch(setSearchTerm(keySearch))
                            }}>
                        <Image
                            source={require("assets/images/icon_search_1.png")}
                            style={styles.searchBarIcon}
                        />
                        <TouchableOpacity>
                        <TextInput
                            onSubmitEditing={() => {
                                // @ts-ignore
                                navigation.navigate('search_result')
                                dispatch(setSearchTerm(keySearch))
                            }}
                            style={styles.searchInput}
                            onChangeText={(text) => {
                                setKeySearch(text)
                            }}
                            placeholder={currentTranslations.search_hint}
                            value={keySearch}
                        />
                        </TouchableOpacity>
            
                        {keySearch.length > 0 && (
                            <TouchableOpacity onPress={() => setKeySearch("")}>
                                <Image
                                    source={require("assets/images/icon_delete_search.png")}
                                    style={styles.clearSearchIcon}
                                />
                            </TouchableOpacity>
                        )}
                    </TouchableOpacity>
                </View>
                {data !== undefined && data.length > 0 && (
                    <View style={styles.listContainer}>
                        <Text style={styles.listTitle}>{currentTranslations.trend}</Text>
                        <FlatList 
                         data={data} 
                         numColumns={2}
                         renderItem={renderItem}/>
                    </View>
                )}
            </ImageBackground>
        </TouchableWithoutFeedback>
    );
};

const styles = StyleSheet.create({
    imgBackground: {
        height: "100%",
        width: "100%",
    },
    container: {
        padding: 10,
    },
    searchBarContainer: {
        height: 40,
        flexDirection: "row",
        alignItems: "center",
        borderColor: "#DBA410",
        borderWidth: 1,
        borderRadius: 30,
        backgroundColor: "#FFFAEE",
        width:'90%',
        marginLeft:'8%'
    },
    searchBarIcon: {
        width: 20,
        height: 20,
        marginHorizontal: 10,
    },
    searchInput: {
        flex: 1,
        height: 40,
        fontFamily: 'heritage_italic'
    },
    clearSearchIcon: {
        width: 20,
        height: 20,
        marginHorizontal: 10,
    },
    listContainer: {
        paddingHorizontal: 15,
        paddingVertical: 15,
    },
    listTitle: {
        color: '#262626',
        lineHeight: 20,
        fontSize: 16,
        fontFamily: "heritage_regular",
        fontWeight:'400',
        marginLeft: '8%'
    },
    listItemContainer: {
        padding: 10,
        flexDirection: "row",
        marginHorizontal: 100,
    },
    listItemText: {
        fontSize: 16,
        fontFamily: "heritage_regular",
        lineHeight: 20,
        color:'#4F4F4F',
        fontWeight:'400',
        flexDirection: 'row',
        width: 200,
    },
});
