import { FlatList, ImageBackground, RefreshControl, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useDispatch, useSelector } from "react-redux";
import React, { useEffect, useState } from "react";
import { getCategoryDefine } from "services/api/apiProvider";
import { setChildStandardDoc } from "../../redux/app_bar_dasboard/reducer";
import { FastImageCustom } from "components/FastImageCustom";
import { windowWidth } from "../../config/font";
import { StandardDoc } from "services/database/models/StandardDoc";
import { addPositionStayStandardDoc } from "../../redux/standard_doc/reducer";
import * as Animatable from 'react-native-animatable';
import { Animations, getCurrentTimeFormatted } from "../../utils/function";
import FastImage from "react-native-fast-image";
export const StandardDocScreen = () => {
    const dispatch = useDispatch();
    const [data, setData] = useState([]);
    const [refreshing, setRefreshing] = useState(false);
    const currentLanguage = useSelector((state: any) => state.languages.currentLanguage);
    const { currentSite } = useSelector((state: any) => state.sub_site);
    const fetchData = () => {
        StandardDoc.getAll().then((values) => {
            // @ts-ignore
            setData(values);
            setRefreshing(false);
        });
    };
    const animation = Animations[Math.floor(Math.random() * Animations.length)]
    useEffect(() => {
        fetchData();
    }, [currentLanguage, currentSite]);

    const onRefresh = async () => {
        setRefreshing(true); // Start the refreshing indicator
        getCategoryDefine().then(value => {
            StandardDoc.insertOrUpdateAll(value).then(_ => fetchData())
        })

    };

    return (
        <ImageBackground source={require('assets/images/background.png')} style={styles.imgBackground}>
            <FlatList
                contentContainerStyle={{ marginLeft: '6%' }}
                data={data}
                numColumns={5}
                renderItem={({ item, index }) => (
                    <TouchableOpacity onPress={() => {
                        dispatch(setChildStandardDoc(true))
                        dispatch(addPositionStayStandardDoc(item))
                    }} style={{marginLeft: '-6.5%',marginBottom:'3%' }}>
                                <TouchableOpacity style={[styles.item, { backgroundColor: '#E2F9FF' }]}
                        >
                            <View style={styles.text}>
                                <FastImage
                                    defaultSource={require('assets/images/icon_thumbnail_category_default.png')}
                                    style={styles.image}
                                    source={{ uri: (item["Image"] && JSON.parse(item["Image"]).Path) ? JSON.parse(item["Image"]).Path : 'null' }}
                                />
                            </View>
                        </TouchableOpacity>
                        <View >
                            <View style={{ marginTop: 122, marginLeft: '8%' }}>
                                <Text style={[{
                                    top: '50%', width: 140,
                                    color: item.color, position: 'absolute', marginLeft: '9%',
                                    textAlign: 'center'
                                }]} numberOfLines={1}>
                                    {currentLanguage !== 'en' ? item["Title"] : item["TitleEN"]}
                                </Text>
                                <Text style={[{ height: 50, marginTop: 89, color: 'gray', width: 200, textAlign: 'center' }]}
                                    numberOfLines={2}>{item["Description"]}</Text>
                            </View>
                        </View>



                    </TouchableOpacity>
                )}
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh}
                    />
                }
            />
        </ImageBackground>
    );
};

const styles = StyleSheet.create({
    imageContainer: {
        padding: 10,
        backgroundColor: '#E2F9FF',
        alignItems: 'center',
        justifyContent: 'center',
        height: 150,
        width: 150,
        borderRadius: 12
    },
    imgBackground: {
        height: '100%',
        width: "100%"
    },
    image: {
        marginLeft: 10,
        height: 120,
        width: 120,
    },
    title: {
        color: 'black',
        fontFamily: 'heritage_regular',
        lineHeight: 15,
        marginTop: 10,
        textAlign: 'center'
    },
    description: {
        fontFamily: 'heritage_regular',
        lineHeight: 15,
        marginTop: 10,
        textAlign: 'center',
        height: 50
    },
    container: {
        flex: 1,
        height: '100%',
        width: '100%',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
    },
    gridItem: {
        width: windowWidth / 2,
        height: 220,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 10,
    },
    centeredItem: {
        alignSelf: 'center',
    },
    text: {
        justifyContent: 'center',
        alignContent: 'center',
        alignItems: 'center',   
    },
    item: {
        borderRadius: 10,
        shadowColor: "#000",
        flexDirection: 'column',
        shadowOffset: {
          width: 5,
          height: 5,
        },
        shadowOpacity: 0.5,
        shadowRadius: 3.84,
        elevation: 5,
        backgroundColor: 'white',
        position: 'absolute',
        width: 150,
        height: 160,
        top: 0,
        left: '17%',
        right: 0,
        bottom: 0,
        marginTop: 20,
        justifyContent: 'center',
        alignItems: 'center',
 
      },
});

