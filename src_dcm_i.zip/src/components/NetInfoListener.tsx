import React, {useEffect} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {setConnectionStatus} from '../redux/net_info/reducer';
import NetInfo from "@react-native-community/netinfo";
import ToastA from 'react-native-simple-toast';
import {AlertNotificationRoot} from 'react-native-alert-notification';
import {
    View,
    Text,
    TouchableOpacity,
    TextInput,
    ScrollView,
    FlatList,
    RefreshControl,
    Keyboard,
    SafeAreaView,
    Platform
} from 'react-native';
import {ALERT_TYPE, Dialog, Toast} from 'react-native-alert-notification';

const NetInfoListener = () => {
    const dispatch = useDispatch();
    const isAuth = useSelector((state: any) => state.auth.isAuth);

    // @ts-ignore
    useEffect(() => {
        const unsubscribe = NetInfo.addEventListener((state) => {

            if ((Platform.OS === "ios")) {
                Toast.show({
                    type: !state.isConnected ? ALERT_TYPE.WARNING : ALERT_TYPE.SUCCESS,
                    title: !state.isConnected ? "VNA LIB HD" : "VNA LIB HD",
                    textBody: !state.isConnected ? "No internet connection!" : "Internet connection!",
                    autoClose: 2000,
                })
            }

            // @ts-ignore
            if (__DEV__)
                console.log("isAuth", isAuth);
            if (isAuth) {
                if ((Platform.OS === "android")) {
                    ToastA.show(!state.isConnected ? "No internet connection!" : "Internet connection!", 3);
                }
            }
            dispatch(setConnectionStatus(state.isConnected));
        });

        return () => {
            unsubscribe();
        };
    }, [dispatch]);

    return null
};

export default NetInfoListener;
