import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import TextCusTom from 'components/TextCusTom'
import { TouchableOpacity } from 'react-native-gesture-handler'
import {format_dd_mm_yy} from "../../../utils/function";
import {FontSize} from "../../../config/font";
import colors from "../../../config/colors";
import ThumbnailImage from "./ThumbnailImage";
import * as Animatable from 'react-native-animatable';

const DocumentItem = ({gotoDetail, item, index}: any) => {
    const formatDate = format_dd_mm_yy(item?.IssueDate)
    return (
        //fadeInLeftBig zoomInLeft
        <View style={styles.itemContainer}>
        <TouchableOpacity onPress={gotoDetail}>
            <ThumbnailImage urlOnline={item?.Thumbnail} styleImg={styles.imgThumbnail}/>
    </TouchableOpacity>
    <TextCusTom i18nKey={item?.Title} style={styles.cap1} numberOfLines={1}/>
    <TextCusTom i18nKey={formatDate} style={styles.cap2}/>
    </View>
     
)
}

export default DocumentItem

const styles = StyleSheet.create({
    itemContainer:{
        width: 120,
        height: 270,
        marginLeft: 20,
        marginTop:'-25%'
    },
    imgThumbnail:{
        height: 220,
        width: 120
    },
    cap1:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey26,
        fontWeight: '400',
        marginTop: '-10%',
        textAlign: 'center'
    },
    cap2:{
        fontSize: FontSize.SMALL,
        color: '#7B7B7B',
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'center'
    }
})
