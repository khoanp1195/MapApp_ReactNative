import { View, Text, TouchableOpacity, StyleSheet, Image, TextInput } from 'react-native'
import React, { useEffect, useState } from 'react'
import { AppBarCustom } from '../../components/AppBarCustom'
import { useNavigation } from '@react-navigation/native';
import { ListLoadMore } from '../../components/ListLoadMore';
import { FastImageCustom } from '../../components/FastImageCustom';
import { dimensWidth } from '../../config/font';
import FastImage from 'react-native-fast-image';
import { format_dd_mm_yy, isNullOrEmpty } from '../../utils/function';
import { getDocumentFavorite } from '../../redux/dashboard/favoriteReducer';
import { useDispatch, useSelector } from 'react-redux';
import { callDocumentFavorite } from '../../services/api/apiProvider';
import { color } from '@rneui/base';

export const FavoriteDoc = () => {
    const navigation = useNavigation();
    // @ts-ignore
    const { isConnected } = useSelector((state) => state.netInfo);
    // @ts-ignore
    const currentLanguage = useSelector((state) => state.languages.currentLanguage);
    const langId = currentLanguage === 'en' ? 1033 : 1066;
    const [keySearh, setKeySearh] = useState("")
    const [data, setData] = useState([])
    const getData = async (limit: number, offet: number, isOnline: any) => {
        if (isOnline) {
            const data = await callDocumentFavorite(langId, "Offset,Limit", offet, limit);
            // const data = await getDocumentFavorite({
            //     LangId: langId,
            //     Params: 'Offset,Limit',
            //     Offset: 0,
            //     Limit: 1000,
            //     isConnected: isConnected
            // })
            console.log(" data here : " + data)
            setData(data)
            return data;
        }
    }
    const filterData = (searchTerm) => {
        // Filter your data array based on the search term
        const filteredData = data.filter(item =>
            item.title.toLowerCase().includes(searchTerm.toLowerCase())
        );
        return filteredData;
    };

    // useEffect(() => {
    //     getData(0, 15, isConnected)
    // })

    // @ts-ignore
    const itemRender = ({ item, index }) => {
        // @ts-ignore
        return <TouchableOpacity onPress={() => goToDocumentDetail(navigation, item.ResourceUrl, isConnected, false)}>
            <View
                style={{
                    backgroundColor: index % 2 == 0 ? '#F1FAFF' : 'white', flexDirection: 'row', width: '100%', paddingHorizontal: 20,
                    paddingVertical: 10
                }}>
                <FastImageCustom urlOnline={item.Thumbnail}
                    defaultImage={require('assets/images/icon_document_default.png')}
                    styleImg={{ height: 45, width: 30, borderRadius: dimensWidth(0) }}
                    resizeMode={FastImage.resizeMode.stretch} />
                <View style={{ flex: 1 }}>
                    <Text numberOfLines={1} style={{ width: '100%', fontSize: 14 }} >{item.Title}</Text>
                    <Text style={{ color: '#7B7B7B', marginTop: 15 }}>{item.Code}</Text>
                </View>
                {
                    !isNullOrEmpty(item.Created) && (<View>
                        <Text style={{ color: '#7B7B7B', marginTop: 36, fontSize: 12 }}>{format_dd_mm_yy(item.Created)}</Text>
                    </View>)
                }
            </View>
        </TouchableOpacity>
    }

    return (
        <View style={{ backgroundColor: 'white' }}>
            <AppBarCustom
                onPress={null}
                navigation={navigation}
                title={"Tài liệu được yêu thích"}
                RightControl={null} isOffline={undefined} localPath={undefined} url={undefined} documentOffline={undefined} />
            <TouchableOpacity style={styles.searchBarContainer} onPress={() => {

            }}>
                <Image
                    source={require("assets/images/icon_search_1.png")}
                    style={styles.searchBarIcon}
                />
                <TextInput
                    onSubmitEditing={() => {
                        // @ts-ignore
                        // navigation.navigate('search_result')
                        // dispatch(setSearchTerm(keySearch))

                        // Filter data based on search term
                        const filteredData = filterData(keySearch);
                        // Update the data source for FlatList
                        setData(filteredData);
                    }}
                    style={styles.searchInput}
                    onChangeText={(text) => {
                        // setKeySearch(text)
                    }}
                    // placeholder={currentTranslations.search_hint}
                    placeholder={'Nhập tài liều cần tìm'}
                    placeholderTextColor={'gray'}
                    // value={keySearch}

                    value={keySearh}
                />

                {/* 
                {keySearch.length > 0 && (
                    <TouchableOpacity onPress={() => setKeySearch("")}>
                        <Image
                            source={require("assets/images/icon_delete_search.png")}
                            style={styles.clearSearchIcon}
                        />
                    </TouchableOpacity>
                )} */}
            </TouchableOpacity>

            <View style={{ marginTop: 5, height: '92%' }}>
                <ListLoadMore numColumn={1} callData={getData} ItemRenderFlatlist={itemRender} limit={15} enableMoreData={true} />

            </View>

        </View>
    )
}
const styles = StyleSheet.create({
    imgBackground: {
        height: "100%",
        width: "100%",
    },
    container: {
        padding: 10,
    },
    searchBarContainer: {
        height: 50,
        flexDirection: "row",
        alignItems: "center",
        borderColor: "#DBA410",
        borderWidth: 1,
        borderRadius: 30,
        backgroundColor: "#FFFAEE",
        width: '95%',
        alignSelf: 'center'
    },
    searchBarIcon: {
        width: 20,
        height: 20,
        marginHorizontal: 10,
    },
    searchInput: {
        flex: 1,
        height: 40,
    },
    clearSearchIcon: {
        width: 20,
        height: 20,
        marginHorizontal: 10,
    },
    listContainer: {
        paddingHorizontal: 15,
        marginTop: 15
    },
    listTitle: {
        color: "black",
        fontSize: 18,
        fontFamily: "heritage_bold",
        lineHeight: 20,
        fontWeight: '600'
    },
    listItemContainer: {
        padding: 10,
        borderBottomWidth: 0.5,
        borderBottomColor: "#ccc",
        flexDirection: "row",
    },
    listItemText: {
        fontSize: 14,
        fontFamily: "heritage_regular",
        lineHeight: 19.2,
        color: '#4F4F4F',
        fontWeight: '400'
    },
});
