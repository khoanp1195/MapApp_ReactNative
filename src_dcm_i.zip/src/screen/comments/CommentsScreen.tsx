import {Image, Platform, StyleSheet, Text, TouchableOpacity, useWindowDimensions, View} from "react-native";
import {ListLoadMore} from "components/ListLoadMore";
import {getComments, getDocumentInteractive} from "services/api/apiProvider";
import {useDispatch, useSelector} from "react-redux";
import {currentUserStore} from "../../config/constants";
import React from "react";
import {FastImageCustom} from "components/FastImageCustom";
import FastImage from "react-native-fast-image";
import {dimensWidth} from "../../config/font";
import {format_dd_mm_yy, getParameterUrlDoc, isNullOrEmpty} from "../../utils/function";
import {AppBarCustom} from "components/AppBarCustom";
import HTML from 'react-native-render-html';
import {Comment} from "services/database/models/Comment";
import {goToDocumentDetail} from "navigation/goToDetailNavigation";
import { SafeAreaView } from "react-native-safe-area-context";
import {decode} from "html-entities";
import { hideBottomSheet, showBottomSheet } from "../../../src/redux/bottom_sheet/reducer";

// @ts-ignore
export const CommentsScreen = ({navigation}) => {
    // @ts-ignore
    const currentLanguage = useSelector((state) => state.languages.currentLanguage);
    const { isVisible } = useSelector((state: any) => state.bottomSheet);
    // @ts-ignore
    const translations = useSelector((state) => state.languages.translations);
    const currentTranslations = translations[currentLanguage];
    // @ts-ignore
    const {isConnected} = useSelector((state) => state.netInfo);
    const dispatch = useDispatch();
    // @ts-ignore
    const itemRender = ({item, index}) => {

        const parseHTML = (htmlString:string) => {
            // Simple parsing logic, doesn't cover all HTML elements
            const elements = htmlString.split(/(<[^>]+>)/).filter(Boolean);

            return elements.map((element, index) => {
                if (element.startsWith('<')) {
                    // Handle HTML tags
                    const tag = element.replace(/<\/?([a-z]+)[^>]*>/g, '$1').toLowerCase();
                    const key = `element-${index}`;

                    if (tag === 'p') {
                        return <Text key={key}>{element.replace(/<\/?p[^>]*>/g, '')}</Text>;
                    } else if (tag === 'b') {
                        return <Text key={key} style={{ fontWeight: 'bold' }}>{element.replace(/<\/?b[^>]*>/g, '')}</Text>;
                    }
                } else {
                    return <Text key={`text-${index}`}>{element}</Text>;
                }
            });
        };
        // @ts-ignore
        return <TouchableOpacity onPress={() =>  goToDocumentDetail(navigation,item.ResourceUrl,isConnected,false)}>
            <View
                style={[{backgroundColor: index % 2 == 0 ? '#F1FAFF' : 'white'}, styles.root]}>
                <FastImageCustom urlOnline={item.Thumbnail}
                                 defaultImage={require('assets/images/icon_document_default.png')}
                                 styleImg={styles.img}
                                 resizeMode={FastImage.resizeMode.stretch}/>
                <View style={{flex: 1}}>
                    <Text ellipsizeMode="tail" numberOfLines={1}  style={styles.textTilte}>{item.Title}</Text>
                    <Text ellipsizeMode="tail" numberOfLines={1}  style={styles.textContent} >{parseHTML(decode(item.Content))}</Text>
                </View>
                <View>
                    {
                        !isNullOrEmpty(item.Created) && (<View>
                            <Text style={styles.textCreated}>{format_dd_mm_yy(item.Created)}</Text>
                        </View>)
                    }
                    {
                        !isNullOrEmpty(item.Status) && (<View style={{marginTop: 10}}>
                            <TextStatus item={item}/>
                        </View>)
                    }
                </View>
            </View>
        </TouchableOpacity>
    }
    // @ts-ignore
    const TextStatus = ({item}) => {
        const statusMap = {
            '-1': {backgroundColor: '#FFCDCD', text: currentTranslations.status_delete},
            '0': {backgroundColor: '#D1E9FF', text: currentTranslations.status_approving},
            '1': {backgroundColor: '#D1FDCE', text: currentTranslations.status_approved},
            default: {backgroundColor: '#FFCDCD', text: currentTranslations.status_refuse},
        };

        const FormatTextStatusToString = (itemp: any) => {
            if (item.Status == -1) {
                return currentTranslations.status_delete
            }
            if (item.IsApproved === null || item.IsApproved === 0) {
                return currentTranslations.status_approving;
            }
            if (item.IsApproved === 1) {
                return currentTranslations.status_approved;
            }

            if ((item.IsApproved === 0)) {
                return currentTranslations.status_refuse;
            }
            else
                return "Nodata"
        }

        const ColorStatusToString = (itemp: any) => {
            if (item.Status == -1) {
                return '#FFCDCD'
            }
            if (item.IsApproved === null || item.IsApproved === 0) {
                return "#D1E9FF";
            }
            if (item.IsApproved === 1) {
                return "#D1FECE";
            }

            if ((item.IsApproved === 0)) {
                return "#FFCDCD";
            }
            else
                return "white"
        }

        // @ts-ignore
        const statusInfo = statusMap[item.Status] || statusMap.default;

        return ( <View style={{borderRadius:5, marginLeft:30,backgroundColor: ColorStatusToString(item.IsApproved),height: 25,width:'90%', alignItems: 'center', alignContent: 'center', justifyContent: 'center',marginTop:5 }}>
        <Text numberOfLines={1} style={{
                  marginTop: 5,
                  paddingHorizontal: 10,
                  color: 'black',
                
                  alignSelf:'center',
                  fontFamily: 'heritage_regular',
                  lineHeight: 15,backgroundColor: ColorStatusToString(item.IsApproved)
        }}>{FormatTextStatusToString(item.IsApproved)}</Text>
    </View>
            // <View style={{backgroundColor: statusInfo.backgroundColor, alignItems: 'center'}}>
            //     <Text style={styles.textStatus}>{statusInfo.text}</Text>
            // </View>
        );
    };
    const isShowModal = async () => {
        dispatch(isVisible ? hideBottomSheet() : showBottomSheet());
    }
    const getData = async (limit: number, offet: number, isOnline: any) => {
        if (isOnline) {
            const data = await getComments(offet, limit, {
                "Parameters": {
                    "CommentTitle": null,
                    "CommentStorageCode": null,
                    "CommentVersion": null,
                    "CommentDate": null,
                    "CommentIsApproved": null,
                    "CommentStatus": null
                }
            });
            if (data != null) {
                Comment.insertOrUpdateAll(data);
            }
            return data;
        } else {
            return Comment.getAll(limit, offet);
        }
    }
    return <SafeAreaView style={{height:'100%',width:'100%',backgroundColor:'white'}}>
        <View style={{flex: 1, flexDirection: 'column'}}>
        <AppBarCustom onPress={Platform.OS === 'ios' ? isShowModal : null} navigation={navigation} title={currentTranslations.list_comment} RightControl={null}/>
        
        <ListLoadMore numColumn={1} callData={getData} ItemRenderFlatlist={itemRender} enableMoreData={true} limit={15}/>
    </View>
    </SafeAreaView>
}
const styles = StyleSheet.create({
    root: {
        flexDirection: 'row',
        paddingHorizontal: 20,
        paddingVertical: 10
    },
    img: {
        height: 45,
        width: 30,
        borderRadius: dimensWidth(0)
    },
    textStatus: {
        marginTop: 5,
        paddingHorizontal: 10,
        color: 'black',
        fontFamily: 'heritage_regular',
        lineHeight: 15,
    },
    textTilte: {
        color: 'black',
        fontSize: 14,
        fontFamily: 'heritage_regular',
        lineHeight: 15,
        width:'150%'
    },
    textContent: {
        color: '#7B7B7B',
        fontSize: 14,
        fontFamily: 'heritage_regular',
        lineHeight: 15,
        marginTop:15
    },
    textCreated: {
        fontFamily: 'heritage_regular',
        lineHeight: 15,
        fontSize:12,
        color:'#7B7B7B',
        marginLeft:100,
 
    }
})

