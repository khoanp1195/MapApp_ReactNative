import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { Platform } from 'react-native';

// @ts-ignore
const ItemMenuBottom = ({ onPress, pathImageLeft, rightView, text, showLine, textColor }) => {
    return (
        onPress ? (
            <TouchableOpacity onPress={onPress}>
                <MenuItem
                    pathImageLeft={pathImageLeft}
                    rightView={rightView}
                    text={text}
                    showLine={showLine}
                    textColor={textColor}
                />
            </TouchableOpacity>
        ) : (
            <MenuItem
                pathImageLeft={pathImageLeft}
                rightView={rightView}
                text={text}
                showLine={showLine}
                textColor={textColor}
            />
        )
    );
};
const { width } = Dimensions.get('window');
// @ts-ignore
const MenuItem = ({ pathImageLeft, rightView, text, showLine, textColor }) => {
    return (
        Platform.OS === 'ios' ? 
        (
            <View style={styles.container}>
            <View style={styles.leftContainer}>
                <Image source={pathImageLeft} style={styles.leftImage} />
            </View>
            <View style={styles.centerContainer}>
                <Text style={[styles.centerText, { color: textColor }]}>{text}</Text>
                {rightView && (
                    <View style={styles.rightViewContainer}>
                        {rightView}
                    </View>
                )}
            </View>
            {showLine ? <View style={styles.line} /> : <View style={styles.lineHidden} />}
        </View>
        )
        :
        (
            <View style={android_styles.container_main}>

            <View style={android_styles.container}>
            <View style={android_styles.leftContainer}>
                <Image source={pathImageLeft} style={android_styles.leftImage} />
            </View>
            <View style={android_styles.centerContainer}>
                <Text style={[android_styles.centerText, { color: textColor }]}>{text}</Text>
                {rightView && (
                    <View style={android_styles.rightViewContainer}>
                        {rightView}
                    </View>
                )}      
            </View>
            </View> 
            {showLine && <View style={android_styles.line} />}
        </View>
        
        )
    );
};
const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        padding:8,
        flex:1
    },
    leftContainer: {
        marginRight: 16,
    },
    leftImage: {
        width: 20,
        height: 20,
        resizeMode: 'contain',
        marginTop:12

    },
    centerContainer: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    centerText: {
        fontSize: 16,
        fontFamily: 'heritage_regular',
        lineHeight: 20,
        width: '92%',
        alignSelf:'center',
        marginTop:6,
    },
    
    rightViewContainer: {
       
    },
    line: {
        marginTop: '14%',
        height: 0.7,
        width: '97%',
        backgroundColor: '#C0C0C0',
        marginLeft:'-98%',
    },
    lineHidden:{
        marginTop: 35,
        height: 1,
        width: '100%',
        backgroundColor: 'white',
    }
});


const android_styles = StyleSheet.create({
    container_main: {
        flexDirection: 'column',
    },
    container: {
        flexDirection: 'row',
        alignItems: 'center',
        padding:12
    },

    leftContainer: {
        marginRight: 16,
    },
    leftImage: {
        width: 20,
        height: 20,
        resizeMode: 'contain'
    },
    centerContainer: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    centerText: {
        fontSize: 14,
        fontFamily: 'heritage_regular',
        lineHeight: 15,
    },
    rightViewContainer: {
        marginLeft: 16,
    },
    line: {
        height: 1,
        width: '93%',
        marginLeft:'10%',
        backgroundColor: 'lightgray',
        marginTop:2
    },
});


export default ItemMenuBottom;
