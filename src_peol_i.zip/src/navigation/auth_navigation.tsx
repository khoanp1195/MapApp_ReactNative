import { useSelector } from 'react-redux';
import { Platform, SafeAreaView, View } from 'react-native';
import LoginScreen from '../screens/login/login_screen.tsx';
import { AppNavigation } from "./app_navigation.tsx";
import { DrawerNavigation } from "../navigation/drawer_navigation.tsx";
import React from 'react';
export const AuthNavigation = () => {
  const isAuth = useSelector((state: any) => state.login.isAuth);

  const NavigateToView = () => {
    return (
      <View style={{ flex: 1}}>
        {!isAuth ? <LoginScreen /> : <DrawerNavigation />}
      </View>
    )
  }

  return <SafeAreaView
    style={{
      flex: 1,
    }}>
    <NavigateToView />
  </SafeAreaView >
};
