import { isNullOrEmpty } from "./functions";

export const getTextSplit=(text:string,splitReg:string, positionTake:number)=>{
    if(!isNullOrEmpty(text)&& text.includes(splitReg))
    {
        return text.split(splitReg)[positionTake];
    }
    else
    {
        return text;
    }
}
export const formatCount=(count:number)=>{
    let newCount;
    if(count!=null && count!=undefined)
    {
        if(count<10)
        {
            newCount=  `0${count}`;
        }
        else if(count<100)
        {   
            newCount= count;
        }
        else
            newCount= '99+';
    }
    else
        return '';
    return `(${newCount})`;
}