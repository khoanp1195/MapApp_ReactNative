import moment from "moment";
import { Animated, Dimensions } from "react-native";
import {
  getBanLanhDao,
  getCoQuanGui,
  getCurrentUser,
  getDepartment,
  getGroups,
  getLoaiVanBan,
  getNguoiKyVanBan,
  getSetting,
  getUsers
} from "../services/api/api_data.ts";
import { currentUserStore, modifiedStore, subsiteStore } from "../config/constants.ts";
import { saveModified, saveSubSite } from "../utils/async_storage.ts";
import { EnumTaskAction, EnumVanBanDenAction } from "../config/enum.ts";
import strings from "../assets/strings.ts";

export const isNumber = (value: any) => {
  return typeof value === 'number' && !isNaN(value);
};
export const isNullOrEmpty = (data: string | null) => {
  return data == undefined || data == null || (data != undefined && data != null && data === '');
};

export const getCurrentTimeFormatted = () => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0'); // Add 1 to month since it's 0-based
  const day = String(now.getDate()).padStart(2, '0');
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');

  return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
}

export const convertStringToMoment = (strDate: string) => {
  return moment(strDate);
}

export const fadeInPressableAnimation = () => {
  //@ts-ignore
  Animated.timing(animated, {
    toValue: 0.4,
    duration: 100,
    useNativeDriver: true,
  }).start();
};

export const fadeOutPressableAnimation = () => {
  //@ts-ignore
  Animated.timing(animated, {
    toValue: 1,
    duration: 200,
    useNativeDriver: true,
  }).start();
};

export const getListItemBackground = (isOdd: boolean) => {
  return isOdd ? 'white' : '#F3F9FF'//appMainBlueColor
}

export const getDisplayTxtFromDateString = (dateTime: string, format: string = strings.WorkDateFormatDayVN) => {
  moment.locale('en');
  return !isNullOrEmpty(dateTime) ? moment(dateTime).format(format) : ''
}

export const getDisplayTxtFromDate = (dateTime: Date, format: string = strings.WorkDateFormatDayVN) => {
  moment.locale('en');
  return dateTime !== null ? moment(dateTime).format(format) : ''
}

export const compareDateFromTxt = (firstDate: string, secondDate: string) => {
  moment.locale('en');

  var date1 = moment(firstDate);
  var date2 = moment(secondDate);
  console.log("date1", date1, "date2", date2)

  return date1.isBefore(date2, 'day') ? -1 : date1.isSame(date2, 'day') ? 0 : 1;
}

export const getFileSize = (bytes: number) => {
  if (bytes < 1024) return (bytes + " Bytes");
  else if (bytes < 1048576) return ((bytes / 1024).toFixed(1) + " KB");
  else if (bytes < 1073741824) return ((bytes / 1048576).toFixed(1) + " MB");
  else return ((bytes / 1073741824).toFixed(1) + " GB");
}

export const getFileIcon = (fileExt: string) => {
  switch (fileExt) {
    case "doc":
    case "docx":
      return require('../assets/images/icon_attachFile_word.png');
    case "pdf":
      return require("../assets/images/icon_attachFile_pdf.png");
    case "pptx":
      return require("../assets/images/icon_attachFile_ppt.png");
    case "ppt":
      return require("../assets/images/icon_attachFile_ppt.png");
    case "xls":
    case "xlsx":
      return require("../assets/images/icon_attachFile_excel.png");
    case "jpg":
    case "png":
    case "jpeg":
      return require("../assets/images/icon_attachFile_photo.png");
    default:
      return require("../assets/images/icon_attachFile_other.png");
  }
}
//@ts-ignore
export const sortTask = (tasks) => {
  if (tasks != undefined && tasks != null && tasks.length > 0 && !isNullOrEmpty(JSON.stringify(tasks))) {
    console.log(" tasks.filter", tasks);
    let resLst = tasks.filter((data: any) => data.ParentId == null || data.ParentId == 0)
    let childLst = tasks.filter((data: any) => data.ParentId != null && data.ParentId != 0)

    for (let index = 0; index < resLst.length; index++) {
      var lstChild = getLstChildTask(childLst, resLst[index])
      if (lstChild != null && lstChild.length > 0) {
        for (let index1 = 0; index1 < lstChild.length; index1++) {
          const element = lstChild[index1];
          resLst = addAfter(resLst, index + 1 + index1, element)
        }
      }
    }
    console.log('lstAll end: ' + JSON.stringify(resLst))

    return resLst
  }
  else return tasks;
}

//@ts-ignore
const getLstChildTask = (lstTask, parentTask) => {
  let retLst = []

  if (lstTask !== null && lstTask.length > 0)
    for (let task of lstTask) {
      if (task.ParentId == parentTask.ID) {
        retLst.push(task)
        getLstChildTask(lstTask, task)
      }
    }
  // console.log('ParentID: ' + parentTask.ID + '- childLst: ' + JSON.stringify(retLst))
  return retLst
}

//@ts-ignore
const addAfter = (array, index, newItem) => {
  return [
    ...array.slice(0, index),
    newItem,
    ...array.slice(index)
  ];
}
export const removeSignVietnamese = (str: string) => {
  try {
    if (str != null)
      return str.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    else
      return "";
  }
  catch {
    return isNullOrEmpty(str) ? "" : str;
  }
};

export const getAllData = async (reLogin = false) => {
  await getCurrentUser();
  if (currentUserStore.getCurrentUser() !== undefined) {
    if (!reLogin) {
      if (currentUserStore.getCurrentUser().DefaultSite != "" && isNullOrEmpty(subsiteStore.getSubsite())) {
        saveSubSite(currentUserStore.getCurrentUser().DefaultSite);
        subsiteStore.setSubsite(currentUserStore.getCurrentUser().DefaultSite);
        getCurrentUser();
      }
    }
    await promiseApiMasterData();
    return true;
  }
  else {
    return false;
  }
};

export const promiseApiMasterData = async () => {

  const promiseBanLanhDao = () => new Promise(async resolve => {
    await getBanLanhDao(modifiedStore.getModified(), !isNullOrEmpty(modifiedStore.getModified()) ? "0" : "1").then(value => resolve(value));
  });
  const promiseSetting = () => new Promise(async resolve => {
    await getSetting(modifiedStore.getModified(), !isNullOrEmpty(modifiedStore.getModified()) ? "0" : "1").then(value => resolve(value));
  });
  const promiseDepartment = () => new Promise(async resolve => {
    await getDepartment(modifiedStore.getModified(), !isNullOrEmpty(modifiedStore.getModified()) ? "0" : "1").then(value => resolve(value));
  });
  const promiseCoQuanGui = () => new Promise(async resolve => {
    await getCoQuanGui(modifiedStore.getModified(), !isNullOrEmpty(modifiedStore.getModified()) ? "0" : "1").then(value => resolve(value));
  });
  const promiseLoaiVanBan = () => new Promise(async resolve => {
    await getLoaiVanBan(modifiedStore.getModified(), !isNullOrEmpty(modifiedStore.getModified()) ? "0" : "1").then(value => resolve(value));
  });
  const promiseNguoiKyVanBan = () => new Promise(async resolve => {
    await getNguoiKyVanBan(modifiedStore.getModified(), !isNullOrEmpty(modifiedStore.getModified()) ? "0" : "1").then(value => resolve(value));
  });
  const promiseUsers = () => new Promise(async resolve => {
    await getUsers(modifiedStore.getModified(), !isNullOrEmpty(modifiedStore.getModified()) ? "0" : "1").then(value => resolve(value));
  });
  const promiseGroups = () => new Promise(async resolve => {
    await getGroups(modifiedStore.getModified(), !isNullOrEmpty(modifiedStore.getModified()) ? "0" : "1").then(value => resolve(value));
  });
  if (isNullOrEmpty(modifiedStore.getModified()))
    await Promise.all([
      promiseBanLanhDao(),
      promiseSetting(),
      promiseDepartment(),
      promiseCoQuanGui(),
      promiseLoaiVanBan(),
      promiseNguoiKyVanBan(),
      promiseUsers(),
      promiseGroups(),
    ]).then(_ => {
      modifiedStore.setModified(getCurrentTimeFormatted());
      saveModified(getCurrentTimeFormatted());
    });
  else {
    await Promise.all([
      promiseSetting(),
      promiseDepartment(),
      promiseUsers(),
      promiseGroups(),
    ]).then(_ => {
      modifiedStore.setModified(getCurrentTimeFormatted());
      saveModified(getCurrentTimeFormatted());
    });
  }
}

interface MapSectionVB{
  title:string,
  data:any[]
}
export const mapLstDataIntoListSection = (lst:any[], key:string)=>{
  try {
    let _res = [];
    
    let _lstQTLC = lst.slice(); // Create a shallow copy of lst
    if (_lstQTLC && _lstQTLC.length > 0) {
      //@ts-ignore
      _lstQTLC=_lstQTLC.sort((a, b) => new Date(a.Created)-new Date(b.Created));
      // Default buoc dau
      let itemSupQTLC:MapSectionVB = {
        title: _lstQTLC[0][key],
        data: []
      };

      _res.push(itemSupQTLC);
      
      _lstQTLC.forEach((item:any) => {
        if (item[key] !== itemSupQTLC.title) { // Qua buoc moi
          itemSupQTLC = {
            title: item[key],
            data: [item]
          };
          _res.push(itemSupQTLC);
        } else {
          itemSupQTLC.data.push(item); // Buoc cu thi add vo them
        }
      });
      
      return _res;
    }
  } catch (error) {
    console.error(error); // Log error
  }
  return null;
}
export const getRequireImageAction = (id: number, type: string) => {
  if (type == "VBBH") {
    switch (id) {
      case 1024:
        return require("../assets/images/icon_hosoduthao.png");
      default:
      case 2048:
        return require("../assets/images/icon_Btn_action_2048.png");
    }
  }
  else if (type == "VBDen") {
    switch (id) {
      case 1:
        return require("../assets/images/icon_Btn_action_vanbanden_1.png");
      case 2:
        return require("../assets/images/icon_Btn_action_vanbanden_2.png");
      case 4:
        return require("../assets/images/icon_Btn_action_vanbanden_4.png");
      case 8:
        return require("../assets/images/icon_Btn_action_vanbanden_8.png");
      case 16:
        return require("../assets/images/icon_Btn_action_vanbanden_16.png");
      case 32:
        return require("../assets/images/icon_Btn_action_vanbanden_32.png");
      case 64:
        return require("../assets/images/icon_Btn_action_vanbanden_64.png");
      case 128:
        return require("../assets/images/icon_Btn_action_vanbanden_128.png");
      case 256:
        return require("../assets/images/icon_Btn_action_vanbanden_256.png");
      case 512:
        return require("../assets/images/icon_Btn_action_vanbanden_512.png");
      case 1024:
        return require("../assets/images/icon_Btn_action_vanbanden_1024.png");
      case 2048:
        return require("../assets/images/icon_Btn_action_vanbanden_2048.png");
      case 32768:
        return require("../assets/images/icon_Btn_action_vanbanden_32768.png");
    }
  }
  else if (type == "TaskVBDen") {
    switch (id) {
      case 1:
        return require("../assets/images/icon_Btn_action_taskvanbanden_1.png");
      case 2:
        return require("../assets/images/icon_Btn_action_taskvanbanden_2.png");
      case 16:
        return require("../assets/images/icon_Btn_action_taskvanbanden_16.png");
      case 32:
        return require("../assets/images/icon_Btn_action_taskvanbanden_32.png");
    }
  }
  else if (type == "VBDi") {
    switch (id) {
      case 1:
        return require("../assets/images/icon_Btn_action_1.png");
      case 2:
        return require("../assets/images/icon_Btn_action_2.png");
      case 4:
        return require("../assets/images/icon_Btn_action_4.png");
      case 8:
        return require("../assets/images/icon_Btn_action_8.png");
      case 16:
        return require("../assets/images/icon_Btn_action_16.png");
      case 32:
        return require("../assets/images/icon_Btn_action_32.png");
      case 64:
        return require("../assets/images/icon_Btn_action_64.png");
      case 2048:
        return require("../assets/images/icon_Btn_action_2048.png");

    }
  }
  else return require("../assets/images/icon_Btn_action_vanbanden_1.png");
};


export const mapActionVBDi = (actionJson: any) => {
  const data = actionJson.map((item: {
    ID: any;
    Title: any;
    Type: any;
    Visible: any;
    Index: any;
    Url: any;
    Class: any;
  }) => (
    {
      ID: item.ID,
      Title: item.Title,
      Type: item.Type,
      Visible: item.Visible,
      Index: item.Index,
      Url: item.Url,
      Class: "VBDi"
    }
  ));
  return data.slice().sort((a: { Index: number; }, b: { Index: number; }) => a.Index - b.Index);
};


export const mapActionVBDen = (actionJson: any) => {
  const data = actionJson.map((item: {
    ID: any;
    Title: any;
    Type: any;
    Visible: any;
    Index: any;
    Url: any;
    Class: any;
  }) => (
    {
      ID: item.ID,
      Title: item.Title,
      Type: item.Type,
      Visible: item.Visible,
      Index: setIndexActionVBDen(item.ID),
      Url: item.Url,
      Class: "VBDen"
    }
  ));
  return data.filter((r: any) => r.ID != 8412 &&r.ID != 8192)
    .slice()
    .sort((a: { Index: number; }, b: { Index: number; }) =>
      a.Index - b.Index
    );
};

const setIndexActionVBDen = (id: number) => {
  switch (id) {
    case EnumVanBanDenAction.Priority:
      return 7;
    case EnumVanBanDenAction.Recall:
      return 11;
    case EnumVanBanDenAction.Forward:
      return 2;
    case EnumVanBanDenAction.ReAssignment:
      return 5;
    case EnumVanBanDenAction.Assignment:
      return 4;
    case EnumVanBanDenAction.SubmitBOD:
      return 0;
    case EnumVanBanDenAction.RecallOrForward:
      return 6;
    case EnumVanBanDenAction.Completed:
      return 8;
    case EnumVanBanDenAction.CommentBOD:
      return 1;
    case EnumVanBanDenAction.RecallBOD:
      return 2;
    default:
      return id;
  }
}

export const mapActionTaskVBDen = (actionJson: any) => {
  const data = actionJson.map((item: {
    ID: any;
    Title: any;
    Type: any;
    Visible: any;
    Index: any;
    Url: any;
    Class: any;
  }) => (
    {
      ID: item.ID,
      Title: item.Title,
      Type: item.Type,
      Visible: item.Visible,
      Index: setIndexActionTaskVBDen(item.ID),
      Url: item.Url,
      Class: "TaskVBDen"
    }
  ));
  return data.slice().sort((a: { Index: number; }, b: { Index: number; }) => a.Index - b.Index);
};

const setIndexActionTaskVBDen = (id: number) => {
  switch (id) {
    case EnumTaskAction.Assignment:
      return 1;
    case EnumTaskAction.Completed:
      return 2;
    case EnumTaskAction.Save:
      return 3;
    case EnumTaskAction.Feedback:
      return 4;
  }
};

export const mapActionVBBH = (actionJson: any) => {
  const data = actionJson.map((item: {
    ID: any;
    Title: any;
    Type: any;
    Visible: any;
    Index: any;
    Url: any;
    Class: any;
  }) => (
    {
      ID: item.ID,
      Title: item.Title,
      Type: item.Type,
      Visible: item.Visible,
      Index: setIndexActionVBDen(item.ID),
      Url: item.Url,
      Class: "VBDen"
    }
  ));
  return data.slice().sort((a: { Index: number; }, b: { Index: number; }) => a.Index - b.Index);
};

export const setindexActionVBBH = (id: number) => {

};

export const getInitials = (inputString: string) => {
  const words = inputString.split(' ');

  // Lấy chữ cái đầu tiên của từ đầu tiên
  const firstInitial = words.length > 0 ? words[0][0].toUpperCase() : '';

  // Lấy chữ cái đầu tiên của từ cuối cùng
  const lastInitial = words.length > 1 ? words[words.length - 1][0].toUpperCase() : '';

  // Kết hợp chữ cái để tạo chuỗi kết quả
  const result = firstInitial + lastInitial;

  return result;
};

export const getRandomColor = () => {
  // Generate random values for red, green, and blue components
  const randomRed = Math.floor(Math.random() * 256);
  const randomGreen = Math.floor(Math.random() * 256);
  const randomBlue = Math.floor(Math.random() * 256);

  // Construct the color string in the format '#RRGGBB'
  const randomColor = `rgb(${randomRed},${randomGreen},${randomBlue})`;

  return randomColor;
};

export const getTextFromFormatText = (text: string) => {
  return !isNullOrEmpty(text) && text.split(';#').length > 0 ? text.split(';#').pop() : ""
};

export const getScreenWidth = () => {
  const { width } = Dimensions.get('window');
  return width;
};

export const removeHTMLTag = (txt: string) => {
  const regex = /(<([^>]+)>)/ig;
  return txt.replace(regex, '');
};

export const removePrintFile = (lstItem: any) => {
  // if (lstItem != null && lstItem.length > 0 && !CmmVariable.sysConfig.ViewPrint) {
  //   lstItem.RemoveAll(o => o.Path.Contains("_Print"));
  // }
  // return lstItem;
};

export const getDisplayTxtFromHourString = (dateTime: string, format: string = strings.WorkHourFormatDayVN) => {
  moment.locale('en');
  return !isNullOrEmpty(dateTime) ? moment(dateTime).format(format) : ''
}

export const getStartOfWeek = () => {
  let toDay = new Date()
  let dayOfWeek = toDay.getDate()
  let diff = toDay.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1); // Adjust when today is Sunday
  return new Date(toDay.setDate(diff));
}

export const formatDate = (date: any) => {
  const day = date.getDate().toString().padStart(2, '0');
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const year = date.getFullYear();
  // return `${day}/${month}/${year}`;
  return `${year}/${month}/${day}`;
};

export const formatDateNum = (date: any) => {
  const day = date.getDate().toString().padStart(2, '0');
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const year = date.getFullYear();
  return `${day}/${month}/${year}`;
};

export const getWeekOfYear = (time: moment.MomentInput) => {
  let day = moment(time).day();
  if (day >= 1 && day <= 3) {
    time = moment(time).add(3, 'days');
  } else {
    time = moment(time).add(1, 'days');
  }
  return moment(time).isoWeek();

}

export const convertListUser = (data: string) => {
  let users: { Title: string; DepartmentTitle: string | undefined; }[] = [];
  if (data && data !== '') {
    try {
      let groups = data.split('#');
      groups.forEach(group => {
        let members = group.split(";$");
        if (members && members.length > 0) {
          let title = members.shift(); // Lấy và loại bỏ phần tử đầu tiên
          members.forEach(member => {
            if (member && member !== '') {
              users.push({ Title: member, DepartmentTitle: title });
            }
          });
        }
      });
    } catch (error: any) {
      console.log("ConvertListUser - Err:" + error.toString());
    }
  }
  return users;
}

export const formatParticipantsDetail = (data: string) => {
  if (data && data !== '') {
    try {
      let groups = data.split('#');
      let retStr: string[] = [];
      groups.forEach(group => {
        let members = group.split(";$");
        if (members.length > 1) {
          let groupName = members[0].trim();
          retStr.push(groupName);
        } else {
          retStr.push(members[0]);
        }
      });
      data = retStr.join("; ");
    } catch (error: any) {
      console.log("Error: " + error.toString());
    }
  } else {
    return "";
  }
  return data;
}

export const formatDateToVietnamese = (date: Date) => {
  const daysOfWeek = ['Chủ Nhật', 'Thứ Hai', 'Thứ Ba', 'Thứ Tư', 'Thứ Năm', 'Thứ Sáu', 'Thứ Bảy'];
  const months = ['Tháng 1', 'Tháng 2', 'Tháng 3', 'Tháng 4', 'Tháng 5', 'Tháng 6', 'Tháng 7', 'Tháng 8', 'Tháng 9', 'Tháng 10', 'Tháng 11', 'Tháng 12'];
  const dayOfWeek = daysOfWeek[date.getDay()];
  const dayOfMonth = date.getDate();
  const month = months[date.getMonth()];
  const year = date.getFullYear();

  return `${dayOfWeek}, ${dayOfMonth} ${month} ${year}`;
}


export function startOfWeek(dt: string | number | Date, startOfWeek = 1) {
  let inputDate: Date;
  if (typeof dt === 'string' || typeof dt === 'number') {
    inputDate = new Date(dt);
  } else {
    inputDate = dt as Date;
  }
  const diff = (7 + (inputDate.getDay() - startOfWeek)) % 7;
  const newDate = new Date(inputDate);
  newDate.setDate(inputDate.getDate() - diff);
  newDate.setHours(0, 0, 0, 0);
  return newDate;
}
export const dimnensHeight = (height: any) => (height * windowHeight) / 736;
export const windowHeight = Dimensions.get('window').height;