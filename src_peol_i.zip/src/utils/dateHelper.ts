export const compareIsGreaterDates=(date1: Date, date2: Date): boolean =>{
    return date1.getTime() > date2.getTime();
}
export const compareIsLessDate=(date1: Date, date2: Date)=>{
    return date1.getTime() < date2.getTime();
}
