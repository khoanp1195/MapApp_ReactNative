import { Dimensions, Platform } from "react-native";

export const isTablet = () => {
    const { height, width } = Dimensions.get('window');
    if (Platform.OS === 'ios') {
        return Platform.isPad;
    } else {
      return (
        (Platform.isTV && (height >= 480 && width >= 720)) ||
        (height >= 600 && width >= 600) 
      );
    }
  };