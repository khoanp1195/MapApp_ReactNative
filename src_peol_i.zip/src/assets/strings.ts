export default {
  AlertTitle: 'Thông báo',//'DOffice',
  AlertMesSignin: 'Đăng nhập không thành công. Vui lòng kiểm tra lại!!',

  WorkDateFormatDayVN: "DD/MM/YY",
  SubmitFormatDate: "YYYY/MM/DD",

  SplitSignal: ";#phongBan;#",

  WorkHourFormatDayVN: "hh:mm"
};
