import * as types from './action_types.ts';

export const startRefreshHome = () => ({
  type: types.START_REFRESH_HOME,
});

export const endRefreshHome= () => ({
  type: types.END_REFRESH_HOME,
});
