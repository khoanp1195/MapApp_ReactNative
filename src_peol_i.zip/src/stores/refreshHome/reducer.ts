import * as types from './action_types.ts';
const initialState = {
  refreshHome: false
};

const refreshHomeReducer = (
  state = initialState,
  action: { type: any; payload: any },
) => {
  switch (action.type) {
    case types.START_REFRESH_HOME:
      return { ...state, refreshHome: true };
    case types.END_REFRESH_HOME:
      return { ...state, refreshHome: false };
    default:
      return state;
  }
};

export default refreshHomeReducer;
