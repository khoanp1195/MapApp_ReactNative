import {combineReducers} from 'redux';
import loginReducer from './login/reducer';
import leftMenuReducer from "./leftmenu/reducer.ts";
import baseScreenReducer from "./base_screen/reducer.ts";
import loadingReducer from "./loading/reducer.ts";
import typeTinnoBoReducer from "./tinnoibo/reducer.ts";
import typeVeMayBayReducer from "./vemaybay/reducer.ts";
import typeVeXeReducer from './vexe/reducer.ts';
import detailActionTabReducer from './detailActionTab/reducer.ts';
import refreshHomeReducer from './refreshHome/reducer.ts';
import lichHopReducer from './calendar/reducer.ts';
const rootReducer = combineReducers({
  login: loginReducer,
  leftMenu:leftMenuReducer,
  baseScreen:baseScreenReducer,
  loading:loadingReducer,
  tinNoiBo:typeTinnoBoReducer,
  veMayBay:typeVeMayBayReducer,
  veXe:typeVeXeReducer,
  detailActionTab:detailActionTabReducer,
  refreshHome:refreshHomeReducer,
  lichHop:lichHopReducer
});

export default rootReducer;
