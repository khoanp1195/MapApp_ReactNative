import * as types from './action_types.ts';

export const changePageTypeTinNoiBo = (item:any) => ({
  type: types.CHANGEPAGE_TINNOIBO,
  payload: item
});

