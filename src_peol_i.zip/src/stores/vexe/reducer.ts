import { CHANGEPAGE_VEXE, END_RELOAD_VEXE, START_RELOAD_VEXE } from "./action_types.ts";
import { TypeDatVeXe } from "../../config/enum.ts";

const initialState = {
  item: TypeDatVeXe.DangLuu,
  isReload:false
};

const typeVeXeReducer = (state = initialState, action: { type: any; payload: { id: any; }; }) => {
  switch (action.type) {
    case CHANGEPAGE_VEXE:
      return {
        ...state,
        item: action.payload,
        isReload:false
      };
      case START_RELOAD_VEXE:
      return {
        ...state,
        isReload:true
      };
      case END_RELOAD_VEXE:
      return {
        ...state,
        isReload:false
      };
    default:
      return state;
  }
};

export default typeVeXeReducer;
