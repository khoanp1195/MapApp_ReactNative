import { UPDATE_LSTACTION, UPDATE_ITEM, UPDATE_TYPE, UPDATE_ITEM_AND_TYPE } from './action_types';

const initialState = {
  lstaction: [],
  item: null,
  type: null,
};

const detailActionTabReducer = (state = initialState, action:{ type: any; payload: any }) => {
  switch (action.type) {
    case UPDATE_LSTACTION:
      return {
        ...state,
        lstaction: action.payload,
      };
    case UPDATE_ITEM:
      console.log("action.payload UPDATE_ITEM",action.payload)
      return {
        ...state,
        item: action.payload,
      };
    case UPDATE_TYPE:
      return {
        ...state,
        type: action.payload,
      };
      case UPDATE_ITEM_AND_TYPE:
        console.log("payload type item",action.payload)
        return {
          ...state,
          type: action.payload.type,
          item: action.payload.item,
        };
    default:
      return state;
  }
};

export default detailActionTabReducer;