import {
  BaoCaoThongMinhUtil,
  DangKyXuatAn, DatVeMayBay,
  DatVeXe,
  HSLTCuaToi,
  HSLTTatCa,
  LichChoDuyet,
  LichChoXepPhong,
  LichDuKien,
  LichTatCa,
  TBScreen, TinNoiBo,
  VBDenChoChoYKien,
  VBDenChoThucHien,
  VBDenDaGiaiQuyet,
  VBDenTatCa,
  VBDenThongBao,
  VBDenTitle,
  VBDiChoPheDuyet, VBDiDaPhatHanh, VBDiDaPheDuyet, VBDiTatCa, VBDiThongBao,
  VBDiTitle,
  VBPHScreenState,
  VCXLHighScreen,
  VCXLScreen
} from "./action_types.ts";

const initialState = {
  screen: ""
};

const baseScreenReducer = (
  state = initialState,
  action: { type: any; payload: any }
) => {
  switch (action.type) {
    case VCXLScreen:
    case VCXLHighScreen:
    case VBPHScreenState:
    case TBScreen:
    case VBDenTitle:
    case VBDenChoChoYKien:
    case VBDenDaGiaiQuyet:
    case VBDenChoThucHien:
    case VBDenThongBao:
    case VBDenTatCa:
    case VBDiTitle:
    case VBDiChoPheDuyet:
    case VBDiDaPheDuyet:
    case VBDiDaPhatHanh:
    case VBDiThongBao:
    case VBDiTatCa:
    case HSLTTatCa:
    case HSLTCuaToi:
      return { ...state, screen: action.type.toString() };
    //lich
    case LichDuKien:
    case LichChoDuyet:
    case LichChoXepPhong:
    case LichTatCa:
      return { ...state, screen: action.type.toString() };
    case DangKyXuatAn:
    case BaoCaoThongMinhUtil:
      return { ...state, screen: action.type.toString() };
    case TinNoiBo:
      return { ...state, screen: action.type.toString() };
    case DatVeMayBay:
    case DatVeXe:
      return { ...state, screen: action.type.toString() };
    case "":
      return { ...state, screen: "" };
    default:
      return state;
  }
};

export default baseScreenReducer;
