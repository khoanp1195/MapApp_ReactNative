import * as types from './action_types.ts';
import {saveCredentials} from '../../utils/async_storage.ts';
import { LOGIN_FAIL } from "./action_types.ts";
const initialState = {
  isAuth: false,
  loading: true,
  error: null,
};

const loginReducer = (
  state = initialState,
  action: {type: any; payload: any},
) => {
  switch (action.type) {
    case types.LOGIN_REQUEST:
      return {...state, loading: true, error: null};
    case types.LOGIN_SUCCESS:
      return {
        ...state,
        loading: false,
        isAuth: true,
        error: null,
      };
      case types.LOGIN_FAIL:
      return {
        ...state,
        loading: false,
        isAuth: false,
        error: 'Err',
      };
    case types.LOGOUT:
      saveCredentials('', '');
      return {...state, isAuth: false, loading: false, error: null};
    default:
      return state;
  }
};

export default loginReducer;
