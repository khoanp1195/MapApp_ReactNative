import * as types from "./action_types.ts";

const initialState = {
  index: 0
};

const leftMenuReducer = (
  state = initialState,
  action: { type: any; payload: any }
) => {
  console.log(action.type);
  switch (action.type) {
    case types.HOME:
      return { ...state, index: 0 };
    case types.CALENDAR:
      return { ...state, index: 1 };
    case types.UTILITIES:
      return { ...state, index: 2 };
    case types.LeftMenuDangKyXuatAn:
      return { ...state, index: 3 };
    case types.LeftMenuTinNoiBo:
      return { ...state, index: 4 };
    case types.LeftMenuVeMayBay:
      return { ...state, index: 5 };
    case types.LeftMenuVeXe:
      return { ...state, index: 6 };
    default:
      return state;
  }
};

export default leftMenuReducer;
