import { get } from "./api_client";

export const getInfoHSSk=async()=>{
    const res=await get('/HealthRecords/_layouts/15/VuThao.Petrolimex.HealthRecords/API/ApiHandler.ashx',
    {
        tbl:'HR_Records',
        func:'GetDataItemByUser'
    })
    if (res.data["status"] != "ERR") {
        return res.data['data'] as Health;
      } else {
        return null;
      }

}