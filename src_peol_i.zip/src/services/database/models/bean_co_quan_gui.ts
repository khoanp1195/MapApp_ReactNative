import { Column, Entity } from "typeorm/browser";
import { PrimaryColumn } from "typeorm";

// @ts-ignore
@Entity({name:'BeanCoQuanGui'})
export class BeanCoQuanGui{
  // @ts-ignore
  @PrimaryColumn({type: 'int'})
  public ID:number=0;
  // @ts-ignore
  @Column({type:'text'})
  public Title:string='';
  // @ts-ignore
  @Column({type:'text'})
  public Parent:string='';
  // @ts-ignore
  @Column({type:'int'})
  public Order:number=0;
  constructor(data: any) {
    if (data) {
      this.ID = data.ID || 0;
      this.Title = data.Title || '';
      this.Parent = data.Parent || '';
      this.Order = data.Order || 0;
    }
  }
  static fromJson(json: any): BeanCoQuanGui {
    return new BeanCoQuanGui(json);
  }
  static listFromJson(jsonArray: any[]): BeanCoQuanGui[] {
    return jsonArray.map((item) => new BeanCoQuanGui(item));
  }
}
