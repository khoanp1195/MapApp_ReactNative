import { Entity } from "typeorm/browser";
import { Column, PrimaryColumn } from "typeorm";

// @ts-ignore
@Entity({name:'BeanUser'})
export class BeanUser{
  // @ts-ignore
  @PrimaryColumn({type: 'text'})
  public ID_SQL:string='';
  // @ts-ignore
  @Column({type:'text'})
  public AccountID:number=0;
  // @ts-ignore
  @Column({type:'text'})
  public Title:string='';
  // @ts-ignore
  @Column({type:'text'})
  public Name:string='';
  // @ts-ignore
  @Column({type:'text',nullable:true})
  public AccountName:string='';
  // @ts-ignore
  @Column({type:'text'})
  public ImagePath:string='';
  // @ts-ignore
  @Column({type:'text'})
  public Position:string='';
  // @ts-ignore
  @Column({type:'text'})
  public Email:string='';
  // @ts-ignore
  @Column({type:'text'})
  public Created:string='';
  // @ts-ignore
  @Column({type:'int',nullable:true})
  public UserType: number=0;
  constructor(data: any) {
    if (data) {
      this.ID_SQL = data.ID_SQL ?? '';
      this.AccountID = data.AccountID ?? 0;
      this.Title = data.Title ?? '';
      this.Name = data.Name ?? '';
      this.AccountName = data.AccountName ?? '';
      this.ImagePath = data.ImagePath ?? '';
      this.Position = data.Position ?? '';
      this.Email = data.Email ?? '';
      this.Created = data.Created ?? '';
      this.UserType=data.UserType;
    }
  }
  static fromJson(json: any): BeanUser {
    return new BeanUser(json);
  }

  static listFromJson(jsonArray: any[]): BeanUser[] {
    return jsonArray.map((item) => new BeanUser(item));
  }
}
