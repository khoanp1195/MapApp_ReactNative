import { ClassActionTasks } from "./classActionTasks";
import { MoreInfo } from "./moreInfo";

export class BeanVBDi {
    public ID: number;
    public CodeCategoryId: number;
    public CodeCategoryTitle: string;
    public IsDelegate?: boolean | null;
    public DocumentName: string;
    public DocSignType: number;
    public DocumentTitle: string;
    public Subject: string;
    public SignDate?: string | null;
    public ReceivedDate?: string | null;
    public SPItemId: number;
    public SPListId: string;
    public IsArchived?: boolean | null;
    public CCForm: string;
    public ChooseUserValue: string;
    public CommentValue: string;
    public HoSoKT: string;
    public Data: BeanVBDi[];
    public MoreInfo: MoreInfo[];
    public StatusText: string;
    public UserSigned: string;
    public NoiLuu: string;
    public ModuleId?: number | null;
    public UserShared: string;
    public EffectiveDate?: string | null;
    public Created?: string | null;
    public ActionJson: string;
    public Modified?: string | null;
    public YKienTrinh: string;
    public DepartmentTitle: string;
    public CreatedByText: string;
    public CodeFieldTitle: string;
    public CodeDocumentTypeTitle: string;
    public HoSoTitle: string;
    public IsSelected: boolean;
    public ImagePath: string;

    constructor(
        ID: number,
        CodeCategoryId: number,
        CodeCategoryTitle: string,
        DocumentName: string,
        DocSignType: number,
        DocumentTitle: string,
        Subject: string,
        SPItemId: number,
        SPListId: string,
        CCForm: string,
        ChooseUserValue: string,
        CommentValue: string,
        HoSoKT: string,
        Data: BeanVBDi[],
        MoreInfo: MoreInfo[],
        StatusText: string,
        UserSigned: string,
        NoiLuu: string,
        UserShared: string,
        ActionJson: string,
        YKienTrinh: string,
        DepartmentTitle: string,
        CreatedByText: string,
        CodeFieldTitle: string,
        CodeDocumentTypeTitle: string,
        HoSoTitle: string,
        IsSelected: boolean,
        ImagePath: string,
        IsDelegate?: boolean | null,
        SignDate?: string | null,
        ReceivedDate?: string | null,
        IsArchived?: boolean | null,
        ModuleId?: number | null,
        EffectiveDate?: string | null,
        Created?: string | null,
        Modified?: string | null
    ) {
        this.ID = ID;
        this.CodeCategoryId = CodeCategoryId;
        this.CodeCategoryTitle = CodeCategoryTitle;
        this.IsDelegate = IsDelegate;
        this.DocumentName = DocumentName;
        this.DocSignType = DocSignType;
        this.DocumentTitle = DocumentTitle;
        this.Subject = Subject;
        this.SignDate = SignDate;
        this.ReceivedDate = ReceivedDate;
        this.SPItemId = SPItemId;
        this.SPListId = SPListId;
        this.IsArchived = IsArchived;
        this.CCForm = CCForm;
        this.ChooseUserValue = ChooseUserValue;
        this.CommentValue = CommentValue;
        this.HoSoKT = HoSoKT;
        this.Data = Data;
        this.MoreInfo = MoreInfo;
        this.StatusText = StatusText;
        this.UserSigned = UserSigned;
        this.NoiLuu = NoiLuu;
        this.ModuleId = ModuleId;
        this.UserShared = UserShared;
        this.EffectiveDate = EffectiveDate;
        this.Created = Created;
        this.ActionJson = ActionJson;
        this.Modified = Modified;
        this.YKienTrinh = YKienTrinh;
        this.DepartmentTitle = DepartmentTitle;
        this.CreatedByText = CreatedByText;
        this.CodeFieldTitle = CodeFieldTitle;
        this.CodeDocumentTypeTitle = CodeDocumentTypeTitle;
        this.HoSoTitle = HoSoTitle;
        this.IsSelected = IsSelected;
        this.ImagePath = ImagePath;
    }
}
