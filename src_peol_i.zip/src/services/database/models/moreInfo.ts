export class MoreInfo {
    public totalRecord: number;
    public IsPermission: number;

    constructor() {
        this.totalRecord = 0;
        this.IsPermission = 0;
    }
}
