export class ClassActionTasks {
    ID: number;
    Title: string;
    Type: number;
    Value: string;
    Visible: boolean;
    Index: number;
    Class:string;
    constructor(ID: number, Title: string, Type: number, Value: string, Visible: boolean, Index: number,Class:string) {
        this.ID = ID;
        this.Title = Title;
        this.Type = Type;
        this.Value = Value;
        this.Visible = Visible;
        this.Index = Index;
        this.Class=Class;
    }
}
