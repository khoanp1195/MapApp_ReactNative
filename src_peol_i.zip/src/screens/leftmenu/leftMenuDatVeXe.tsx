import { useDispatch, useSelector } from "react-redux";
import { DrawerActions, useNavigation } from "@react-navigation/native";
import React, {  useState } from "react";
import { Image, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { TypeDatVeXe } from "../../config/enum";
import { changePageTypeVeXe } from "../../stores/vexe/actions";

export const LeftMenuDatVeXe = () => {
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const type = useSelector((state: any) => state.veMayBay.item);
  const [id, setID] = useState(2);
  const data = [

    {
      ID: 0,
      Title: "Đăng ký vé xe",
      Icon: require("../../assets/images/icon_dkvx.png"),
      IsParent: true,
      EnableClick: false
    },
    {
      ID: 1,
      Title: TypeDatVeXe.DangKy,
      Icon: require("../../assets/images/icon_dkvx_dangky.png"),
      IsParent: false,
      EnableClick: true
    },
    {
      ID: 2,
      Title: TypeDatVeXe.DangLuu,
      Icon: require("../../assets/images/icon_dkvx_dangluu.png"),
      IsParent: false,
      EnableClick: true
    },
    {
      ID: 3,
      Title: TypeDatVeXe.ChoPheDuyet,
      Icon: require("../../assets/images/icon_dkvx_chopheduyet.png"),
      IsParent: false,
      EnableClick: true
    },
    {
      ID: 4,
      Title: TypeDatVeXe.ChoDieuXe,
      Icon: require("../../assets/images/icon_dkvx_chodieuxe.png"),
      IsParent: false,
      EnableClick: true
    },
    {
      ID: 5,
      Title: TypeDatVeXe.DaDieuXe,
      Icon: require("../../assets/images/icon_dkvx_dadieuxe.png"),
      IsParent: false,
      EnableClick: true
    },
    {
      ID: 6,
      Title: TypeDatVeXe.ChuyenHoanThanh,
      Icon: require("../../assets/images/icon_dkvx_chuyenhoanthanh.png"),
      IsParent: false,
      EnableClick: true
    },
    {
      ID: 7,
      Title: TypeDatVeXe.All,
      Icon: require("../../assets/images/icon_dkvmb_tatca.png"),
      IsParent: false,
      EnableClick: true
    }
  ];
  return (
    <View style={styles.container}>
      {
        // @ts-ignore
        data.map((item) => (
          <TouchableOpacity key={item.ID} onPress={() => {
            if (item.EnableClick) {
              if (item.Title != TypeDatVeXe.DangKy) {
                // @ts-ignore
                setID(item.ID);
                dispatch(changePageTypeVeXe(item.Title));
              }
              else {
                // @ts-ignore
                navigation.navigate("DetailDatVeMayBayScreen",{
                  item:null
                });
              }
              navigation.dispatch(DrawerActions.closeDrawer());
            }
          }}>
            <View style={styles.rowContainer}>
              <View style={[styles.indicator, { backgroundColor: id === item.ID ? "#0072C6" : "white" },
                (id !== item.ID && item.IsParent) && { backgroundColor: "#F5F5F5CC" }]} />
              <View style={[styles.itemContainer, { backgroundColor: id === item.ID ? "#E6F5FF80" : "white" },
                (id !== item.ID && item.IsParent) && { backgroundColor: "#F5F5F5CC" }]}>
                <Image source={item.Icon} style={styles.icon} />
                <Text style={[styles.title, item.IsParent && { fontWeight: "bold" }]}>{item.Title}</Text>
              </View>
            </View>
          </TouchableOpacity>
        ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginVertical: 10
  },
  rowContainer: {
    flexDirection: "row"
  },
  indicator: {
    width: 10,
    height: 50
  },
  itemContainer: {
    flexDirection: "row",
    width: "96%",
    padding: 10,
    alignItems: "center"
  },
  icon: {
    height: 20,
    width: 20,
    marginRight: 10
  },
  title: {
    color: "#000000"
  }
});
