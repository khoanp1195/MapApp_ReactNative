import { useDispatch, useSelector } from "react-redux";
import { DrawerActions, useNavigation } from "@react-navigation/native";
import React, { useEffect, useState } from "react";
import { getLeftMenu } from "../../services/api/apiTinNoiBo.ts";
import { Image, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { changePageTypeTinNoiBo } from "../../stores/tinnoibo/actions.ts";
import { TypeDatVeMayBay } from "../../config/enum.ts";
import { changePageTypeVeMayBay } from "../../stores/vemaybay/actions.ts";

export const LeftMenuDatVeMayBay = () => {
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const type = useSelector((state: any) => state.veMayBay.item);
  const [id, setID] = useState(2);

  const data = [

    {
      ID: 0,
      Title: "Đăng ký vé máy bay",
      Icon: require("../../assets/images/icon_dkvmb.png"),
      IsParent: true,
      EnableClick: false
    },
    {
      ID: 1,
      Title: TypeDatVeMayBay.DangKy,
      Icon: require("../../assets/images/icon_dkvmb_dky.png"),
      IsParent: false,
      EnableClick: true
    },
    {
      ID: 2,
      Title: TypeDatVeMayBay.PhieuToiTao,
      Icon: require("../../assets/images/icon_dkvmb_phieutoitao.png"),
      IsParent: false,
      EnableClick: true
    },
    {
      ID: 3,
      Title: TypeDatVeMayBay.ChoPheDuyet,
      Icon: require("../../assets/images/icon_dkvmb_chopheduyet.png"),
      IsParent: false,
      EnableClick: true
    },
    {
      ID: 4,
      Title: TypeDatVeMayBay.ChoMuaVe,
      Icon: require("../../assets/images/icon_dkvmb_chomuave.png"),
      IsParent: false,
      EnableClick: true
    },
    {
      ID: 5,
      Title: TypeDatVeMayBay.DaMuaVe,
      Icon: require("../../assets/images/icon_dkvmb_damuave.png"),
      IsParent: false,
      EnableClick: true
    },
    {
      ID: 6,
      Title: TypeDatVeMayBay.TatCa,
      Icon: require("../../assets/images/icon_dkvmb_tatca.png"),
      IsParent: false,
      EnableClick: true
    }
  ];
  return (
    <View style={styles.container}>
      {
        // @ts-ignore
        data.map((item) => (
          <TouchableOpacity key={item.ID} onPress={() => {
            if (item.EnableClick) {
              if (item.Title != TypeDatVeMayBay.DangKy) {
                // @ts-ignore
                setID(item.ID);
                dispatch(changePageTypeVeMayBay(item.Title));
              }
              else {
                // @ts-ignore
                navigation.navigate("DetailDatVeMayBayScreen",{
                  item:null
                });
              }
              navigation.dispatch(DrawerActions.closeDrawer());
            }
          }}>
            <View style={styles.rowContainer}>
              <View style={[styles.indicator, { backgroundColor: id === item.ID ? "#0072C6" : "white" },
                (id !== item.ID && item.IsParent) && { backgroundColor: "#F5F5F5CC" }]} />
              <View style={[styles.itemContainer, { backgroundColor: id === item.ID ? "#E6F5FF80" : "white" },
                (id !== item.ID && item.IsParent) && { backgroundColor: "#F5F5F5CC" }]}>
                <Image source={item.Icon} style={styles.icon} />
                <Text style={[styles.title, item.IsParent && { fontWeight: "bold" }]}>{item.Title}</Text>
              </View>
            </View>
          </TouchableOpacity>
        ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginVertical: 10
  },
  rowContainer: {
    flexDirection: "row"
  },
  indicator: {
    width: 10,
    height: 50
  },
  itemContainer: {
    flexDirection: "row",
    width: "96%",
    padding: 10,
    alignItems: "center"
  },
  icon: {
    height: 20,
    width: 20,
    marginRight: 10
  },
  title: {
    color: "#000000"
  }
});
