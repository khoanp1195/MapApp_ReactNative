import { Dimensions, Text, TouchableOpacity, View } from "react-native";
import React, { useEffect, useState } from "react";
import { getDataListCalendar } from "../../services/api/api_calendar.ts";
import { CustomFlatListRefreshLoadMore } from "../../components/custom_flat_list_refresh_loadmore.tsx";
import { CustomFastImage } from "../../components/custom_fast_image.tsx";
import { BASE_URL, subsiteStore } from "../../config/constants.ts";
import { getDisplayTxtFromHourString, isNullOrEmpty } from "../../utils/functions.ts";
import { PetroAppBarCustom } from "../../components/petro_appbar_custom.tsx";
import { DrawerActions, useNavigation } from "@react-navigation/native";
import { useSelector } from "react-redux";
// @ts-ignore
export const ListCalendarScreen = ({ type }) => {
  const isReload = useSelector((state: any) => state.lichHop.isReload);
  const navigation = useNavigation();
  const [title, setTitle] = useState("");
  useEffect(() => {
    switch (type) {
      case 1:
        setTitle("Tất cả");
        break;
      case 2:
        setTitle("Lịch chờ xếp phòng");
        break;
      case 3:
        setTitle("Lịch chờ duyệt");
        break;
      case 4:
        setTitle('Lịch dự kiến');
        break;
    }
  }, []);
  // @ts-ignore
  const RenderItem = ({ item, index }) => {
    const width = Dimensions.get("window").width;
    return <TouchableOpacity style={{
      backgroundColor: index % 2 == 0 ? "white" : "#F3F9FF",
      flexDirection: "row"
    }}
      onPress={() => {
        // @ts-ignore
        navigation.navigate("DetailCalendarScreen", { item: item });
      }}
    >
      <View style={{ padding: 10 }}>
        <CustomFastImage
          styleImg={{ height: 50, width: 50, borderRadius: 50 }}
          resizeMode={"contain"}
          urlOnline={BASE_URL + `${isNullOrEmpty(subsiteStore.getSubsite()) && "/" + subsiteStore.getSubsite()}` + item.ImagePath}
          defaultImage={require("../../assets/images/avatar80.jpg")} />
      </View>
      <View style={{ padding: 10 }}>
        <View style={{ flexDirection: "row", alignItems: 'center' }}>
          <Text style={{ color: "black", fontSize: 15, fontWeight: "bold", width: '78%' }}>{item.Handler}</Text>
          <Text style={{ textAlign: "right" }}> {getDisplayTxtFromHourString(item.Modi)}</Text>


        </View>
        <View style={{ flexDirection: 'row' }}>
          <Text style={{ fontSize: 12, color: "#5E5E5E", marginTop: 5 }}>{item.WorkflowCate}</Text>

          <View style={{ flexDirection: 'row', marginLeft: '38%', marginTop: 5 }}>
            <Text style={{ textAlign: "right" }}>{getDisplayTxtFromHourString(item.StartTime)} - </Text>
            <Text style={{ textAlign: "right" }}> {getDisplayTxtFromHourString(item.EndTime)}</Text>
          </View>
        </View>
        <Text numberOfLines={2} style={{ fontSize: 15, color: "black", width: width - 95, marginTop: 5 }}>{item.Title}</Text>
        {
          type == 1 && <View style={{ alignSelf: 'baseline', marginTop: 5 }}>
            <Text style={{ padding: 5, backgroundColor: '#A5DEFF', color: 'black', fontSize: 12 }}>{item.Status}</Text>
          </View>
        }

      </View>
    </TouchableOpacity>;
  };

  const getData = async (limit: number, offset: number) => {
    const data = await getDataListCalendar(limit, offset, type);
    if (data != null) {
      return data;
    } else {
      return [];
    }
  };

  return <View style={{ flex: 1 }}>
    <PetroAppBarCustom title={title} onPress={() => {
      navigation.dispatch(DrawerActions.openDrawer());
    }} />
    <View style={{ flex: 1 }}>
      <CustomFlatListRefreshLoadMore
        key={type+isReload}
        enableMoreData={true}
        callData={getData}
        limit={10}
        numColumn={1}
        ItemRenderFlatlist={RenderItem} />
    </View>
  </View>;
};
