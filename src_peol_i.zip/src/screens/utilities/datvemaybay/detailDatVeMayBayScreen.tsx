import { View } from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { ModalTopBar } from "../../../components/modalTopBar.tsx";
import React, { useEffect, useRef, useState } from "react";
import { getFullLink } from "../../../config/constants.ts";
import { WebView } from "react-native-webview";
import { useDispatch } from "react-redux";
import { endReloadVeMayBay, startReloadVeMayBay } from "../../../stores/vemaybay/actions.ts";

export const DetailDatVeMayBayScreen = () => {
  const dispatch = useDispatch();
  const route = useRoute();
  const navigation = useNavigation();
  const [title, setTitle] = useState("");

  const webViewRef = useRef(null);
  // @ts-ignore
  const item = route.params["item"];
  // @ts-ignore
  const [canGoBack, setCanGoBack] = useState(false);
  const [url, setUrl] = useState(item.ItemUrlMobile);
  const handleNavigationStateChange = (navState: any) => {
    setCanGoBack(navState.canGoBack);
  };
  const navigationGoBack = async () => {
    if (webViewRef.current && canGoBack) {
      //@ts-ignore
      webViewRef.current.goBack();
    }
    else {
      navigation.goBack();
    }
  };
  useEffect(() => {
    if (url.includes("Title")) {
      setTitle(getTitleFromUrl(url));
    }
  }, []);
  const getTitleFromUrl = (url: string) => {
    if (url != undefined) {
      if (url.includes(getFullLink())) {
        url = url.replace(getFullLink(), "");
      }
      const params = url.split('&');
      for (const param of params) {
        const [key, value] = param.split('=');
        if (key === 'Title') {
          return decodeURIComponent(value);
        }
      }
    }
    return '';
  };

  return <View style={{ flex: 1 }}>
    <ModalTopBar onPress={navigationGoBack} title={title} />
    <WebView
      ref={webViewRef}
      style={{ flex: 1 }}
      originWhitelist={["*"]}
      source={{ uri: getFullLink() + url }}
      mixedContentMode="compatibility"
      javaScriptEnabled
      domStorageEnabled
      sharedCookiesEnabled
      thirdPartyCookiesEnabled
      setSupportMultipleWindows={false}
      bounces={false}
      onLoadStart={(request: any) => {
        const { url } = request.nativeEvent;
        setTitle(getTitleFromUrl(url));
        dispatch(startReloadVeMayBay());
      }}
      onLoadEnd={(_: any) => {
        dispatch(endReloadVeMayBay());
      }}
      onNavigationStateChange={handleNavigationStateChange}
      onShouldStartLoadWithRequest={request => {
        dispatch(startReloadVeMayBay());
        console.log("request.url", request.url);
        setTitle(getTitleFromUrl(request.url));
        if (request.url.includes("bussinessdoc-byme")) {
          dispatch(endReloadVeMayBay());
          navigation.goBack();
        }
        return true;
      }}
    />
  </View>;
};
