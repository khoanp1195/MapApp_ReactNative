import React, { FC } from "react";
import { Dimensions, Image, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import CustomSafeAreaView from "../../components/custom_safe_area_view.tsx";
import { CustomFlatListRefreshLoadMore } from "../../components/custom_flat_list_refresh_loadmore.tsx";
import { useNavigation } from "@react-navigation/native";
import { showLeftMenuHome, showLeftMenuUtilities } from "../../stores/leftmenu/actions.ts";
import { PetroAppBarCustom } from "../../components/petro_appbar_custom.tsx";
import { useDispatch } from "react-redux";
import {
  redirectBaoCaoThongMinh,
  redirectDangKyXuatAn,
  redirectDatVeMayBay,
  redirectDatVeXe,
  redirectTinNoiBo
} from "../../stores/base_screen/actions.ts";
import BaseScreen from "../../components/basescreen.tsx";
import { changePageTypeTinNoiBo } from "../../stores/tinnoibo/actions.ts";
import { BeanUtilities } from "../../services/database/models/beanUtilities.ts";

export const UtilitiesScreen = () => {
  const navigation = useNavigation();
  const dispatch = useDispatch();

  const ItemMenu: FC<{ item: BeanUtilities }> = ({ item }) => {
    return (
      <View style={[styles.card,
      {
        width: Dimensions.get("window").width / 3.5,
        height: 100,
      }]}>
        <TouchableOpacity onPress={() => {
          gotoUtil(item.title);
        }}>
          <View style={{ alignItems: 'center' }}>
            <Image source={item.imageSource} style={styles.cardImage} resizeMode={'contain'} />
          </View>
          <View style={styles.cardContent}>
            <Text style={styles.cardTitle}>{item.title}</Text>
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  const gotoUtil = (utilName: string) => {
    switch (utilName) {
      case "Danh bạ":
        {
          // @ts-ignore
          navigation.navigate("ContactsScreen");
          break;
        }
      case "Đăng ký suất ăn":
        {
          // @ts-ignore
          //navigation.navigate("AnCaScreen");
          dispatch(redirectDangKyXuatAn());
          break;
        }
      case "Báo cáo thông minh BI":
        {
          // @ts-ignore
          //navigation.navigate("AnCaScreen");
          dispatch(redirectBaoCaoThongMinh());
          break;
        }
      case "Tin nội bộ":
        {
          // @ts-ignore
          //navigation.navigate("AnCaScreen");
          dispatch(changePageTypeTinNoiBo(undefined));
          dispatch(redirectTinNoiBo());
          break;
        }
      case "Đặt vé máy bay":
        {
          // @ts-ignore
          //navigation.navigate("AnCaScreen");
          dispatch(redirectDatVeMayBay());
          break;
        }
      case "Hồ sơ sức khỏe":
        {
          // @ts-ignore
          navigation.navigate("DashboardHSSKScreen");
          break;
        }
      case "Đặt xe công tác":
        {
          // @ts-ignore
          dispatch(redirectDatVeXe());
          break;
        }
    }
  };

  const getData = () => [
    new BeanUtilities("Danh bạ", require("../../assets/images/icon_utilities_danhba.png")),
    new BeanUtilities("Đăng ký suất ăn", require("../../assets/images/icon_dangkyxuatan.png")),
    new BeanUtilities("Tin nội bộ", require("../../assets/images/icon_tinNoiBo.png")),
    new BeanUtilities("Báo cáo thông minh BI", require("../../assets/images/icon_BI.png")),
    new BeanUtilities("Đặt vé máy bay", require("../../assets/images/icon_vemaybay.png")),
    new BeanUtilities("Đặt xe công tác", require("../../assets/images/icon_datxecontac.png")),
    new BeanUtilities("Hồ sơ sức khỏe", require("../../assets/images/icon_hssk.png")),
    new BeanUtilities("Biểu quyết bằng văn bản", require("../../assets/images/icon_bieuquyet_disable.png")),
    new BeanUtilities("Quy định, quy chế", require("../../assets/images/icon_quydinh_quyche_disable.png")),
    new BeanUtilities("Kế hoạch công việc", require("../../assets/images/icon_kehoachcongviec_disable.png")),
    new BeanUtilities("Hợp đồng lao động", require("../../assets/images/icon_hopdonglaodong_disable.png")),
    new BeanUtilities("Chấm công", require("../../assets/images/icon_chamcong_disable.png")),
    new BeanUtilities("Nghỉ lễ, phép", require("../../assets/images/icon_nghile_disable.png")),
    new BeanUtilities("Hồ sơ nhân sự", require("../../assets/images/icon_hosonhansu_disable.png")),
    new BeanUtilities("Thanh toán", require("../../assets/images/icon_thanhtoan_disable.png")),
    new BeanUtilities("Quản lý thu nhập", require("../../assets/images/icon_quanlythunhap_disable.png")),
    new BeanUtilities("Cẩm nang", require("../../assets/images/icon_camNang_disable.png"))
  ];
  return (
    <BaseScreen>
      <View style={{ backgroundColor: "white", width: "100%" }}>
        <PetroAppBarCustom
          title={"Tiện ích"}
          onPress={() => {
            dispatch(showLeftMenuUtilities());
            // @ts-ignore
            navigation.openDrawer();
          }} />
        <View style={{
          justifyContent: "center",
          alignItems: "center"
        }}>
          <CustomFlatListRefreshLoadMore
            enableMoreData={false}
            numColumn={3}
            limit={0}
            callData={getData}
            ItemRenderFlatlist={ItemMenu} />
        </View>
      </View>
    </BaseScreen>
  );
};

const styles = StyleSheet.create({
  card: {
    padding: 10,
    borderRadius: 8,
    elevation: 3,
    backgroundColor: "#fff",
    shadowOffset: { width: 1, height: 1 },
    shadowColor: "#333",
    shadowOpacity: 0.3,
    shadowRadius: 2,
    marginHorizontal: 5,
    marginVertical: 5,
    alignItems: 'center'
  },
  cardImage: {
    width: 30,
    height: 30,
    borderTopLeftRadius: 8,
    borderTopRightRadius: 8
  },
  cardContent: {
    marginTop: 10
  },
  cardTitle: {
    fontSize: 14,
    fontWeight: "normal",
    color: "#3B4664",
    textAlign: 'center'
  }
});
