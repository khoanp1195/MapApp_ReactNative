import { FlatList, Image, RefreshControl, ScrollView, Text, TouchableOpacity, View } from "react-native";
import { PetroAppBarCustom } from "../../../components/petro_appbar_custom.tsx";
import { showLeftMenuHome, showLeftMenuTinNoiBo } from "../../../stores/leftmenu/actions.ts";
import { useDispatch, useSelector } from "react-redux";
import { useNavigation } from "@react-navigation/native";
import { useCallback, useEffect, useState } from "react";
import {
  getDataAllCategory,
  getDataByCategoryID,
  getSliceDashBoardTinNoiBo
} from "../../../services/api/apiTinNoiBo.ts";
import { TinNoiBoType, ViewModeTinNoiBo } from "../../../config/enum.ts";
import { redirectTinNoiBo } from "../../../stores/base_screen/actions.ts";
import { TinNoiBoComponent } from "../../../screens/utilities/tinnoibo/tinNoiBoComponent.tsx";
import { changePageTypeTinNoiBo } from "../../../stores/tinnoibo/actions.ts";

export const DashboardTinNoiBoScreen = () => {
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const item = useSelector((state: any) => state.tinNoiBo.item);
  const [itemNews, setItemNews] = useState();
  const [itemDiffNews, setItemDiffNews] = useState();
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (!refreshing) {
      if (item != undefined) {
        setItemNews(undefined);
        setItemDiffNews(undefined);
      }
      getData();
    } else {
      setRefreshing(false);
    }
  }, [item, refreshing]);
  const getData = async () => {
    // @ts-ignore
    if (item == undefined || (item != undefined && item.ID == 0)) {
      getSliceDashBoardTinNoiBo().then(value => {
        // @ts-ignore
        setItemNews(value);
      });
      getDataAllCategory().then(value => {
        // @ts-ignore
        setItemDiffNews(value);
      });
    } else {
      getDataByCategoryID(item.ID, 0, true).then(value => {
        // @ts-ignore
        setItemNews(value.hotNews);
        // @ts-ignore
        setItemDiffNews([value.Categories]);
      });
    }
  };
  const loadMore = () => {
    // @ts-ignore
    if (itemDiffNews != undefined && itemDiffNews[0].data != undefined) {
      // @ts-ignore
      getDataByCategoryID(item.ID, itemDiffNews[0].data != undefined ? itemDiffNews[0].data.length : 0, true).then(value => {
        // @ts-ignore
        if (value.Categories != undefined && value.Categories.data != undefined && value.Categories.data.length > 0) {
          // @ts-ignore
          setItemDiffNews(preData => {
            // @ts-ignore
            const updatedData = [...preData];
            // @ts-ignore
            updatedData[0] = {
              ...updatedData[0],
              data: [...updatedData[0].data, ...value?.Categories.data]
            };
            return updatedData;
          });
        }
      });
    }
  };
  return <View style={{
    backgroundColor: "white",
    height: "100%"
  }}>
    <PetroAppBarCustom
      title={item ? item["Title"] : "Tin nội bộ"}
      onPress={() => {
        dispatch(showLeftMenuTinNoiBo());
        // @ts-ignore
        navigation.openDrawer();
      }} />
    <ScrollView
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => setRefreshing(true)} />}
      style={{ marginBottom: 20 }}>

      {
        // @ts-ignore
        <View>
          {
            // @ts-ignore
            (itemNews != undefined) && <TinNoiBoComponent
              sizeTitle={16}
              title={itemNews["title"]}
              data={itemNews["data"]}
              typeView={itemNews["typeView"]}
              viewMode={itemNews["viewMode"]}
              showDot={itemNews["showDot"]}
              showAll={itemNews["showAll"]}
              showLine
              autoScroll={itemNews["autoScroll"]}
              onPressAll={() => {
              }}
            />
          }
          {
            // @ts-ignore
            (itemDiffNews != undefined) && <FlatList
              scrollEnabled={false}
              onEndReached={_ => {
                // @ts-ignore
                if(itemDiffNews[0].typeView==TinNoiBoType.ListLoadMore)
                {
                  loadMore();
                }
              }}
              data={itemDiffNews} renderItem={info => {
              return <TinNoiBoComponent
                sizeTitle={16}
                // @ts-ignore
                showLine={itemDiffNews.length - 1 != info.index}
                key={info.item}
                title={info.item["title"]}
                data={info.item["data"]}
                typeView={info.item["typeView"]}
                viewMode={info.item["viewMode"]}
                showDot={info.item["showDot"]}
                showAll={info.item["showAll"]}
                autoScroll={info.item["autoScroll"]}
                onPressAll={() => {
                  dispatch(changePageTypeTinNoiBo({
                    ID: info.item.ID,
                    Title: info.item.title
                  }));
                }}
              />;
            }} />
          }
        </View>
      }
    </ScrollView>
  </View>;
};
