import { FlatList, Image, Pressable, Text, View } from "react-native";
import { FC, Key, useEffect, useRef, useState } from "react";
import { TinNoiBoType, ViewModeTinNoiBo } from "../../../config/enum.ts";
import PagerView from "react-native-pager-view";
import { ItemTinNoiBoDashBoard } from "./components/itemTinNoiBoDashBoard.tsx";
import { DotBellowComponent } from "./components/dotBellowComponent.tsx";
import { ItemTinNoiBoHorizontal } from "./components/itemTinNoiBoHorizontal.tsx";
import { ItemTinNoiBoVertical } from "./components/itemTinNoiBoVertical.tsx";
import { ItemTinNoiBoListLoadMore } from "./components/itemTinNoiBoListLoadMore.tsx";
import { isNullOrEmpty } from "../../../utils/functions.ts";
import { useNavigation } from "@react-navigation/native";
import { useDispatch, useSelector } from "react-redux";
import { changePageTypeTinNoiBo } from "../../../stores/tinnoibo/actions.ts";
import { isTabletMode } from "../../../config/constants.ts";
import React from "react";

interface Props {
  data: any,
  title: string,//=> Title
  typeView: any, //=>Kiểu hiển thị
  viewMode: number,//=>==1 là Horizontal
  showAll: boolean, //=> showTextAll
  showDot: boolean,
  autoScroll: boolean,
  onPressAll: any,
  showLine: boolean,
  sizeTitle: number
}

export const TinNoiBoComponent: FC<Props> = ({
                                               data = undefined,
                                               title = "",//=> Title
                                               typeView = TinNoiBoType.DashBoard, //=>Kiểu hiển thị
                                               viewMode = 0,//=>==1 là Horizontal
                                               showAll = false, //=> showTextAll
                                               showDot = false,
                                               autoScroll = false,
                                               showLine = false,
                                               sizeTitle = 20,
                                               onPressAll = () => {
                                               } // sự kiện khi click Show All
                                             }) => {
  const flatListRef = useRef(null);
  const pagerRef = useRef(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [enableAutoScroll, setEnableAutoScroll] = useState(autoScroll);
  const navigation=useNavigation();

  useEffect(() => {
    // @ts-ignore
    if (data != undefined && data.length > 0 && enableAutoScroll) {
      const intervalId = setInterval(() => {
        // @ts-ignore
        setCurrentIndex((prevIndex) => (prevIndex + 1) % data.length);
      }, 7000);

      return () => clearInterval(intervalId);
    }
  }, [data, autoScroll]);

  useEffect(() => {
    if (autoScroll) {
      // Check if flatListRef.current is available before scrolling
      if (flatListRef.current && typeView != TinNoiBoType.DashBoard) {
        // @ts-ignore
        flatListRef.current.scrollToIndex({
          index: currentIndex,
          animated: true
        });
      } else if (pagerRef.current) {
        // @ts-ignore
        pagerRef.current.setPage(currentIndex);
      }
    }

  }, [currentIndex]);

  // @ts-ignore
  const Item = ({ item, index }) => {
    if (typeView == TinNoiBoType.Horizontal) {
      return <ItemTinNoiBoHorizontal item={item} />;
    } else if (typeView == TinNoiBoType.Vertical) {
      return <ItemTinNoiBoVertical item={item} showLine={data.length - 1 != index} />;
    } else
      return <ItemTinNoiBoListLoadMore item={item} showLine={data.length - 1 != index}/>;

  };


  const onPageSelected = (event: {
    nativeEvent: {
      position: any;
    };
  }) => {
    const { position } = event.nativeEvent;
    setEnableAutoScroll(false);
    setCurrentIndex(position);
    setTimeout(()=>setEnableAutoScroll(true),7000);

  };
  const goToDetail=(item:any)=>{
    // if(parent==undefined)
    // {
    //   dispatch(changePageTypeTinNoiBo({
    //     ID:item.CategoryId,
    //     Title:item.CategoryText
    //   }))
    // }

    console.log("item.CategoryText",item.CategoryText)
    // @ts-ignore
    navigation.navigate("DetailTinNoiBoScreen",{
      item:item,
      Title:isNullOrEmpty(item.CategoryText)?"":item.CategoryText
    });
  }
  return <View >
    {
      (!isNullOrEmpty(title)) ?
        <View style={{marginBottom:10}}>
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            <Text style={{
              color: "#004374",
              fontSize: sizeTitle,
              fontWeight: "bold",
              marginHorizontal: 20,
              marginTop: 5, flex: 1
            }}>{title}</Text>
            {
              showAll && <Pressable onPress={onPressAll}>
                <Text style={{
                  color: "#0072C6",
                  fontSize: 14,
                  fontWeight: "bold",
                  marginHorizontal: 20,
                  marginTop: 5
                }}>
                  Tất cả
                </Text>
              </Pressable>
            }

          </View>
        </View> :
        <View style={{ padding: 5 }} />
    }
    {
      data != undefined &&
      (
        typeView != TinNoiBoType.DashBoard ?
          <FlatList
            style={{ marginHorizontal: 20 }}
            showsHorizontalScrollIndicator={false}
            scrollEnabled={true}
            horizontal={viewMode == ViewModeTinNoiBo.Horizontal}
            data={data}
            renderItem={info => <Pressable
              onPress={()=>{
                goToDetail(info.item);
              }}
            >
              <Item item={info.item} index={info.index}/>
            </Pressable>}
            // @ts-ignore
            ItemSeparatorComponent={<View style={{ padding: 5 }} />}
            keyExtractor={(item) => item.id}
            ref={flatListRef}
            onScrollBeginDrag={event => {
              setEnableAutoScroll(false);
            }}
            onScrollEndDrag={event => {
              setEnableAutoScroll(true);
            }}
          /> :
          <PagerView
            ref={pagerRef}
            style={{ height: isTabletMode?320:220 }}
            initialPage={0}
            onPageSelected={onPageSelected}
          >
            {
              // @ts-ignore
              data.map((item: {
                id: Key | null | undefined;
              }) =>
                <Pressable
                  onPress={()=>{
                    goToDetail(item);
                  }}
                >
                  <ItemTinNoiBoDashBoard item={item} />
                </Pressable>
                )
            }
          </PagerView>
      )
    }
    {
      (data != undefined && showDot) && <View style={{ alignItems: "center" }}>
        <DotBellowComponent currentIndex={currentIndex} numDot={
          // @ts-ignore
          data.length
        } />
      </View>
    }
    {
      showLine && <View style={{ height: 1, backgroundColor: "#E9E9E9", marginHorizontal: 20, marginTop: 10 }} />
    }
  </View>;
};
