import { FC } from "react";
import { Text, View } from "react-native";
import { convertStringToMoment, isNullOrEmpty } from "../../../../utils/functions.ts";

interface Props{
  item:any,
  showLine:boolean
}
export const ItemTinNoiBoVertical:FC<Props>=({item,showLine})=>{
  return <View>
    <Text style={{height:50,color:'black',fontWeight:'bold',fontSize:14}} numberOfLines={3}>{item.Title}</Text>
    <Text style={{ color: "#999999", fontSize: 10 }}>
      {isNullOrEmpty(item.Modified)?"":convertStringToMoment(item.Modified).format("DD/MM/yyyy")}</Text>
    {
      showLine&&<View style={{ height: 1, backgroundColor: "#E9E9E9",  marginTop: 10 }} />
    }
  </View>
}
