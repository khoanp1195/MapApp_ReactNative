import { Image, Text, View } from "react-native";
import { convertStringToMoment, getScreenWidth, isNullOrEmpty } from "../../../../utils/functions.ts";
import { CustomFastImage } from "../../../../components/custom_fast_image.tsx";
import { BASE_URL, getFullLink, isTabletMode, subsiteStore } from "../../../../config/constants.ts";
import React from "react";

// @ts-ignore
export const ItemTinNoiBoDashBoard = ({ item }) => {
  const imgUrl = !isNullOrEmpty(item.ImageStand) ? JSON.parse(item.ImageStand).Path : "";
  return <View
    style={[{ height: isTabletMode?300: 200, marginHorizontal: 20, marginVertical: 10, borderRadius: 10 ,flex:1},isTabletMode&& { width: getScreenWidth() - 40}]}>
    <View>
      <CustomFastImage resizeMode={"stretch"} styleImg={[{ height: isTabletMode?300: 200,  borderRadius: 16 }, isTabletMode && {width: "60%",}]}
                       defaultImage={require("../../../../assets/images/temp_tinnoibo.png")}
                       urlOnline={getFullLink() + imgUrl} />
      <Image resizeMode={"stretch"} style={[{ height: isTabletMode?300: 200, position: "absolute", width:isTabletMode?"60%":'100%'}]}
             source={require("../../../../assets/images/img_blur.png")} />
      <View style={[{ position: "absolute", height: isTabletMode?300: 200,  justifyContent: "flex-end", padding: 10 },isTabletMode&& {width: "60%",}]}>
        <Text numberOfLines={3} style={{ color: "white", fontSize: 14, fontWeight: "bold" }}>{item.Title}</Text>
        <View style={{ flexDirection: "row" }}>
          {
            !isNullOrEmpty(item.CategoryText) &&
            <View style={{ flexDirection: "row" }}>
              <Text style={{ color: "white", fontSize: 10 }}>{item.CategoryText}</Text>
              <Text style={{ color: "white", fontSize: 10 }}> | </Text>
            </View>
          }
          <Text style={{
            color: "white",
            fontSize: 10
          }}>{convertStringToMoment(item.Modified).format("DD/MM/yyyy")}</Text>
        </View>
      </View>
    </View>
  </View>;
};
