import { Button, Image, Linking, Platform, Text, TouchableOpacity, View } from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { ModalTopBar } from "../../../../components/modalTopBar.tsx";
import { useEffect, useState } from "react";
import {
  getAttFileVBDenByID,
  getDetailVBDenByID,
  getTaskById,
  getVBDenListTask,
  getVBDenWorkflowHistory, getViewerVBDen, getWorkflowHistoryOtherDepartment
} from "../../../../services/api/apiDetailVBDen.ts";
import EmptyView from "../../../../components/empty_view.tsx";
import { ScrollView } from "react-native-gesture-handler";
import { DetailVBDen } from "../../docDetail/detailVBDen.jsx";
import { ListAttachment } from "../../docDetail/listAttachment.jsx";
import { CustomImageButton } from "../../../../components/customImageButton.tsx";
import { appMainBlueColor } from "../../../../utils/color.ts";
import { ListIdea } from "../../../../screens/details/docDetail/listIdea.jsx";
import { ListDepartmentTask } from "../../../../screens/details/docDetail/listDepartmentTask.tsx";
import { ListUnitTask } from "../../../../screens/details/docDetail/listUnitTask.tsx";
import { getDisplayTxtFromDateString, isNullOrEmpty, mapActionVBDen, sortTask } from "../../../../utils/functions.ts";
import { BottomAction } from "../../../../components/bottomAction.tsx";
import { MoreAction } from "../../../../screens/details/popup/moreAction.tsx";
import { RootPopUpContainer } from "../../../../screens/details/popup/rootPopUpContainer.tsx";
import { downloadFile } from "../../../../services/api/api_client.ts";
import { useDispatch, useSelector } from "react-redux";
import { LoadingScreen } from "../../../../components/loadingScreen.tsx";
import { EnumVanBanDenAction } from "../../../../config/enum.ts";
import { EnumTaskRole } from "../../../../config/enum.ts";
import { openFile } from "../../../../utils/fileUtil.ts";
import { ClassActionTasks } from "../../../../services/database/models/classActionTasks.ts";
import { BeanVanBanDen } from "../../../../services/database/models/beanVanBanDen.ts";
import { isTabletMode } from "../../../../config/constants.ts";
import { updateLstAction } from "../../../../stores/detailActionTab/action.ts";
// @ts-ignore
export const VBDenDetailScreen = () => {
  const dispatch= useDispatch();
  const route = useRoute();
  const navigation = useNavigation();
  const onLoading = useSelector((state: any) => state.loading.onLoading);
  let item: { DocumentID: any; ID: any; } | null = null;
  if (!isTabletMode) {
    // @ts-ignore
    item = route.params["item"];
  }
  else {
    item = useSelector((state: any) => state.detailActionTab.item);

  }
  const [detailVanBanDen, setDetailVanBanDen] = useState<BeanVanBanDen>();
  const [lstAttachment, setListAttachment] = useState();
  const [lstBODIdea, setLstBODIdea] = useState([]);
  const [lstTCTH, setListTCTH] = useState<any[]>();
  const [lstDVTH, setListDVTH] = useState([]);
  const [isViewDetail, setIsViewDetail] = useState(true);
  const [lstAction, setListAction] = useState<ClassActionTasks[] | null>([new ClassActionTasks(32768, "Chia sẻ", 32768, "", true, 32768, "VBDen")]);
  const [isShowMoreAction, setShowMoreAction] = useState(false);
  const [isShowPopup, setShowPopup] = useState(false);
  const [indexAction, setIndexAction] = useState(0);

  const [isLoading, setLoading] = useState(true);

  useEffect(() => {
    if (item != undefined) {
      getAttFileVBDenByID(item!.DocumentID ?? item!.ID).then(attachments => {
        setListAttachment(attachments);
      });
      getDetailVBDenByID(item!.DocumentID ?? item!.ID).then(detail => {
        if (detail != null) {
          setDetailVanBanDen(detail);
          setLstBODIdea(getListFromTxt(detail.CommentJson));
          const lstActionTemp = getListFromTxt(detail.ActionJson);
          if (lstAction && lstAction.length == 1) {
            const actionMap = mapActionVBDen([...lstAction, ...lstActionTemp]);
            if(isTabletMode)
            {
              dispatch(updateLstAction(actionMap));
            }
            else{
              setListAction(actionMap);
            }
          }
          //setListAction(mapActionVBDen([{ ID: 128, Title: "Bổ sung thu hồi", Index: 7 }]));
          getVBDenListTask(detail.ID, detail.ModuleId).then(value => {

            if (__DEV__)
              console.log("Task TC nè: " + JSON.stringify(value.TaskJson));
            var lstres = sortTask(value.TaskJson);
            if (__DEV__)
              console.log("Task TC convert nè nè: " + JSON.stringify(lstres));
            // setListTCTH(value.TaskJson)
            setListTCTH(lstres);
            if(lstres!=undefined&& lstres!=null&&lstres.length>0&& isLoading)
            {
              onClickDepartmentTask(lstres[0]);
            }
            if (__DEV__)
              console.log("Task DV nè: " + JSON.stringify(value.NhiemVuXuLyJson));
            setListDVTH(value.NhiemVuXuLyJson);
          });
        }
        setLoading(detail == null);
      });
    }
  }, [onLoading, item]);

  //@ts-ignore
  const getListFromTxt = (txt) => {
    return !isNullOrEmpty(txt) ? JSON.parse(txt) : null;
  };

  //@ts-ignore
  const onClickAttachment = (item) => {
    if (__DEV__)
      console.log("onClickAttachment", item);
    if (Platform.OS == "ios") {
      //@ts-ignore
      navigation.navigate('AttachmentDetailView', { item })
    }
    else {
      downloadFile(item.Path).then(filePath => {
        openFile(filePath);
      })
    }
  };

  //@ts-ignore
  const onClickDepartmentTask = (task) => {
    if (__DEV__) console.log("Task nè " + task.DepartmentTitle, "item nè:", JSON.stringify(item));
    console.log("Role nè:" + task.Role)
    //@ts-ignore
    navigation.navigate("RooTaskScreen",
      {
        checkType: () => getTaskById(task.ID),
        itemVB: item,
        isVBDen: true,
        lstBODIdea: lstBODIdea,
        lstAttachment: lstAttachment
      });
  };

  const handlePressShowAction = (index: number) => {
    switch (index) {
      case 0:
        setShowMoreAction(true);
        break;
      case 32768:
        //@ts-ignore
        navigation.navigate("ShareScreen",
          {
            item: detailVanBanDen,
            type: "VBDen"
          });
        return;
    }
    if (index != 0
      && index != EnumVanBanDenAction.RecallOrForward
      && index != EnumVanBanDenAction.Assignment
      && index != EnumVanBanDenAction.ReAssignment
    ) {
      setIndexAction(index);
      setShowPopup(true);
    } else {
      if (index == EnumVanBanDenAction.RecallOrForward) {
        // @ts-ignore
        navigation.navigate("RecallOrForwardScreen",
          {
            beanVanBanDen: detailVanBanDen,
            btnAction: index
          }
        );
      }
      else if (index == EnumVanBanDenAction.ReAssignment) {
        // @ts-ignore
        navigation.navigate("ReassignScreen",
          {
            beanVanBanDen: detailVanBanDen,
            btnAction: index,
            lstTCTH: lstTCTH
          }
        );
      } else if (index == EnumVanBanDenAction.Assignment) {
        // @ts-ignore
        navigation.navigate("AssignScreen",
          {
            beanVanBanDen: detailVanBanDen,
            btnAction: index,
          }
        );
      }
    }
  };

  return <View style={{ flex: 1 }}>
    <View style={{ flex: 1 }}>

      {
        !isTabletMode && <ModalTopBar
          title={""}
          rightAction={
            detailVanBanDen != undefined ? <TouchableOpacity onPress={() => {
              // @ts-ignore
              navigation.navigate("RootWorkflowHistory", {
                // @ts-ignore
                getWorkflowHistory: () => getVBDenWorkflowHistory(detailVanBanDen.ID),
                // @ts-ignore
                getViewer: () => getViewerVBDen(detailVanBanDen.ID),
                // @ts-ignore
                getOtherDepartment: () => getWorkflowHistoryOtherDepartment(detailVanBanDen.ID),
                isVBDen: true,
                itemVB: detailVanBanDen
              });
            }}>
              <Image style={{ height: 25, width: 25 }} resizeMode={"stretch"}
                source={require("../../../../assets/images/icon_proce.png")} />
            </TouchableOpacity> :
              <View />
          }
          onPress={() => {
            navigation.goBack();
          }} />
      }

      {
        detailVanBanDen != undefined
          ? <View style={{ flex: 1 }}>

            <View style={{ width: "100%", alignSelf: "baseline", flexDirection: "row" }}>
              <Text style={{ flex: 1, fontWeight: "bold", margin: 10 }}>{detailVanBanDen.TrichYeu}</Text>
            </View>

            <View style={{
              flex: 1,
              backgroundColor: "white"
            }}>

              <ScrollView style={{ flex: 1, backgroundColor: "white" }}>
                <View style={{ flex: 1, backgroundColor: "white", marginHorizontal: 10 }}>
                  {isViewDetail && <DetailVBDen vBDen={detailVanBanDen} />}
                  {
                    //@ts-ignore
                    lstAttachment != null && lstAttachment.length > 0 ?
                      <ListAttachment data={lstAttachment} onClick={(item: any) => onClickAttachment(item)} />
                      : null
                  }
                  {
                    //@ts-ignore
                    lstBODIdea != null && lstBODIdea.length > 0 ? <ListIdea data={lstBODIdea} />
                      : null
                  }
                  {
                    //@ts-ignore
                    lstTCTH != null && lstTCTH.length > 0 ? <ListDepartmentTask data={lstTCTH} OnPress={(item) => {
                      onClickDepartmentTask(item);
                    }} />
                      : null
                  }
                  {
                    //@ts-ignore
                    lstDVTH != null && lstDVTH.length > 0 ? <ListUnitTask data={lstDVTH} />
                      : null
                  }

                </View>
              </ScrollView>

              <View style={{
                width: 50,
                height: 40,
                position: "absolute",
                top: 0,
                right: 0
                // justifyContent: 'flex-end',
              }}>
                <CustomImageButton imgPath={require("../../../../assets/images/icon_more_detail.png")}
                  //@ts-ignore
                  imgColor={isViewDetail ? appMainBlueColor : "black"} onClickHandle={() => {
                    setIsViewDetail(!isViewDetail);
                  }} />
              </View>

            </View>
            {
              //@ts-ignore
              !isTabletMode && lstAction != undefined && lstAction.length > 0 &&
              <View style={{ width: "100%", height: 60 }}>
                <BottomAction data={lstAction} onPressAction={handlePressShowAction} />
              </View>
            }
          </View>
          : !isLoading && <EmptyView />
      }
    </View>
    {
      isShowMoreAction && <MoreAction actionJson={lstAction} onPressAcion={handlePressShowAction}
        onPressCancel={() => setShowMoreAction(false)} />
    }
    {
      isShowPopup && <RootPopUpContainer
        type={"VBDen"}
        //@ts-ignore
        action={lstAction.find(item => item.ID == indexAction)}
        cancelPress={() => setShowPopup(false)}
        //@ts-ignore
        itemVB={detailVanBanDen}
      />
    }
    {onLoading && <LoadingScreen />}
  </View>;
};
