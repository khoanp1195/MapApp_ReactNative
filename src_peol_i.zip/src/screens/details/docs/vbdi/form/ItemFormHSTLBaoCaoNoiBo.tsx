import { FC } from "react"
import { BeanVBDi } from "../../../../../services/database/models/beanVBDi"
import { HeaderValueTextView } from "../../../../../components/headerValueTextView"
import { convertStringToMoment, isNullOrEmpty } from "../../../../../utils/functions"
import { View } from "react-native"

interface Props {
    dataForm: BeanVBDi
}
export const ItemFormHSTLBaoCaoNoiBo: FC<Props> = ({ dataForm }) => {
    console.log("ItemFormHSTLBaoCaoNoiBo");
    return <View>
        <HeaderValueTextView headerText={"Số văn bản"}
            valueText={isNullOrEmpty(dataForm.DocumentName) ?
                "" :
                dataForm.DocumentName}
        />
        <HeaderValueTextView headerText={"Loại văn bản"}
            valueText={isNullOrEmpty(dataForm.CodeDocumentTypeTitle) ? ""
                : dataForm.CodeDocumentTypeTitle} />
        <HeaderValueTextView headerText={"Trích yếu"}
            valueText={isNullOrEmpty(dataForm.Subject) ? ""
                : dataForm.Subject} />
        <HeaderValueTextView headerText={"Ngày ký"}
            valueText={dataForm.EffectiveDate != null ?
                convertStringToMoment(dataForm.EffectiveDate).format("DD/MM/YY") :
                ""} />
        <HeaderValueTextView headerText={"Đơn vị soạn thảo"} valueText={isNullOrEmpty(dataForm.DepartmentTitle) ? "" : dataForm.DepartmentTitle} />
        <HeaderValueTextView headerText={"Nơi lưu"} valueText={isNullOrEmpty(dataForm.NoiLuu) ? "" : dataForm.NoiLuu} />
        <HeaderValueTextView headerText={"Hồ sơ"} valueText={isNullOrEmpty(dataForm.HoSoTitle) ? "" : dataForm.HoSoTitle} />
    </View>
}