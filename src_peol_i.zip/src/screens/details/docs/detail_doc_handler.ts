import { useDispatch } from "react-redux";
import { isTabletMode } from "../../../config/constants";
import { showAlert } from "../../commonAlertView";
import { updateItem, updateType } from "../../../stores/detailActionTab/action";

// @ts-ignore
export const gotoDetailDocs = (dispatch,navigation, item) => {
  if(isTabletMode)
  {
    switch (item.ModuleId) {
      case 9:
      case 7:
        dispatch(updateType("VBDi"));
        break;
      case 8:
        dispatch(updateType("VBBH"));
        break;
      case 10:
      case 11:
      case 12:
        dispatch(updateType("None"));
        break;
        //showAlert("Tính năng đang phát triển");
        break;
      default:
        dispatch(updateType("VBDen"));
        break;
    }
    dispatch(updateItem(item));
  }
  else
  {
    switch (item.ModuleId) {
      case 9:
      case 7:
        navigation.navigate('VBDiDetailScreen', { item });
        break;
      case 8:
        navigation.navigate('VBBHDetailScreen', { item });
        break;
      case 10:
      case 11:
      case 12:
        showAlert("Tính năng đang phát triển");
        break;
      default:
        navigation.navigate('VBDenDetailScreen', { item });
        break;
    }
  }
}
