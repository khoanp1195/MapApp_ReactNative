import React from "react";
import { FlatList, StyleSheet, Text, View } from "react-native";
import { useState } from "react";
import { BASE_URL, subsiteStore } from "../../../../config/constants.ts";
import { CustomFastImage } from "../../../../components/custom_fast_image.tsx";
import {
  convertStringToMoment,
  getListItemBackground,
  isNullOrEmpty,
} from "../../../../utils/functions.ts";

// @ts-ignore
export const ViewerScreen = ({ data }) => {

  // @ts-ignore
  const renderItem = ({ item, index }) => (
    <View style={[styles.itemContainer, { backgroundColor: getListItemBackground(index % 2 !== 0) }]}>
      <View style={styles.imageContainer}>
        <CustomFastImage
          styleImg={styles.customFastImage}
          urlOnline={BASE_URL + "/" + subsiteStore.getSubsite() + item.ImagePath}
          defaultImage={require("../../../../assets/images/avatar80.jpg")}
        />
      </View>
      <View style={styles.contentContainer}>
        <View style={styles.textRowContainer}>
          <Text style={styles.titleText}>{item.Title}</Text>
          <Text style={styles.dateTimeText}>{convertStringToMoment(item.Created).format("DD/MM/YY HH:mm")}</Text>
        </View>
        <Text style={styles.positionText}>
          {!isNullOrEmpty(item.Position) && item.Position.includes(";#") ? item.Position.split(";#")[1] : item.Position}
        </Text>
      </View>
    </View>
  );

  return (
    <View style={{ backgroundColor: "white", flex: 1 }}>
      <FlatList data={data} renderItem={renderItem} />
    </View>
  );
};
const styles = StyleSheet.create({
  itemContainer: {
    padding: 10,
    flexDirection: "row",
  },
  imageContainer: {
    flexDirection: "row",
  },
  customFastImage: {
    height: 45,
    width: 45,
    borderRadius: 100,
    marginLeft: 10,
    marginRight: 10,
  },
  contentContainer: {
    justifyContent: "center",
    flex: 1,
  },
  textRowContainer: {
    flexDirection: "row",
  },
  titleText: {
    flex: 1,
    color: "black",
    fontSize: 15,
  },
  dateTimeText: {
    flex: 1,
    textAlign: "right",
    fontSize: 12,
    color: "#5e5e5e",
  },
  positionText: {
    flex: 1,
    fontSize: 12,
    color: "#5e5e5e",
  },
});
