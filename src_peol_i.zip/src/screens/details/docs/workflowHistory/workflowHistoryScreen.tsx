// @ts-ignore
import { Image, SectionList, StyleSheet, Text, View } from "react-native";
import { convertStringToMoment, isNullOrEmpty } from "../../../../utils/functions.ts";
import { CustomFastImage } from "../../../../components/custom_fast_image.tsx";
import { BASE_URL, subsiteStore } from "../../../../config/constants.ts";
import HTMLTextView from "../../../../components/htmlTextView.tsx";

// @ts-ignore
export const WorkflowHistoryScreen = ({ data, isVBDi = false }) => {

  // Render each section header
  // @ts-ignore
  const renderSectionHeader = ({ section: { title } }) => (
    <View style={styles.sectionHeader}>
      <Image style={styles.sectionImage} resizeMode={"stretch"} source={getImageProcess(title)} />
      <Text style={styles.sectionHeaderText}>{!isNullOrEmpty(title) && title.includes(";#") ? title.split(";#")[1] : title}</Text>
    </View>
  );

  const getImageProcess = (title: string) => {
    if (isVBDi) {
      if (isNullOrEmpty(data.find((item: { title: string; }) => item.title == title).data[0].SubmitAction))
        return require("../../../../assets/images/icon_inprogress30.png");
      else
        return require("../../../../assets/images/icon_history_done.png");
    } else {
      const currentItem = data.find((item: { title: string; }) => item.title == title);
      const index = data.indexOf(currentItem);
      if (index != data.length - 1) {
        return require("../../../../assets/images/icon_history_done.png");
      } else {
        return require("../../../../assets/images/icon_inprogress30.png");
      }
    }
  };
  const removeHTMLTags = (str:any) => {
    if (!str || typeof str !== 'string') {
      return '';
    }
    return str.replace(/<[^>]*>/g, '');
  };
  // Render each item in the section
  // @ts-ignore
  const renderItem = ({ item }) => (
    <View style={styles.itemContainer}>
      <View style={styles.itemSeparator} />
      <View style={styles.itemInnerContainer}>
        <CustomFastImage
          styleImg={styles.avatar}
          urlOnline={BASE_URL + "/" + subsiteStore.getSubsite() + item.ImagePath}
          defaultImage={require("../../../../assets/images/avatar80.jpg")} />
        <View style={[styles.item, { flex: 1 }]}>
          <View style={styles.itemRow}>
            <Text style={[styles.itemText, { color: "black", fontSize: 15 }]} numberOfLines={1}>{!isVBDi ? item.UserName : item.AssignedTo}</Text>
            {!(isNullOrEmpty(item.Action)&&isNullOrEmpty(item.SubmitAction))}
            <Text style={[styles.itemText, styles.itemDate]}>{isNullOrEmpty(item.Created) ?
              "" :
              convertStringToMoment(item.Created).format("DD/MM/YY hh:mm")}</Text>
          </View>
          <View style={styles.itemRow}>
            <View style={{ flex: 1 }}>
              <Text style={[styles.itemText, styles.itemPosition]}>{!isNullOrEmpty(item.Position) && item.Position.includes(";#") ? item.Position.split(";#")[1] : item.Position}</Text>
              {isVBDi && <Text style={styles.itemNote}>{item.Note}</Text>}
            </View>

            {
                !(isNullOrEmpty(item.Action)&&isNullOrEmpty(item.SubmitAction))&&<Text style={styles.itemAction}>{removeHTMLTags(!isVBDi ? item.Action : item.SubmitAction)}</Text>
            }

          </View>
        </View>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <SectionList
        sections={data}
        keyExtractor={(item, index) => item + index}
        renderItem={renderItem}
        renderSectionHeader={renderSectionHeader}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white",
    paddingTop: 10
  },
  sectionHeader: {
    paddingHorizontal: 10,
    flexDirection: "row",
    alignItems: "center"
  },
  sectionImage: {
    height: 20,
    width: 20,
    marginRight: 10
  },
  sectionHeaderText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "black"
  },
  itemContainer: {
    flexDirection: "row",
    width: "100%"
  },
  itemSeparator: {
    height: "100%",
    width: 1,
    backgroundColor: "#eeeeee",
    marginLeft: 19
  },
  itemInnerContainer: {
    flex: 1,
    flexDirection: 'row'
  },
  avatar: {
    height: 40,
    width: 40,
    borderRadius: 100,
    marginTop: 20,
    marginLeft: 10
  },
  item: {
    padding: 15
  },
  itemRow: {
    flexDirection: "row"
  },
  itemText: {
    flex: 1
  },
  itemDate: {
    textAlign: "right",
    color: "#5e5e5e",
    fontSize: 12
  },
  itemPosition: {
    color: "#5e5e5e",
    fontSize: 12
  },
  itemAction: {
    color: "black",
    padding: 10,
    backgroundColor: "#C5DDF9",
    borderRadius: 5,
    textAlign: "center",
    flex: 1
  },
  itemNote: {
    fontSize: 15,
    color: 'black'
  }
});
