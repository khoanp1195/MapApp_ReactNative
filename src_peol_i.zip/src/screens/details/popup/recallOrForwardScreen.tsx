import {
  FlatList,
  Image,
  Keyboard,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from "react-native";
import { ModalTopBar } from "../../../components/modalTopBar.tsx";
import { useNavigation, useRoute } from "@react-navigation/native";
import { Tab } from "react-native-elements";
import React, { useEffect, useState } from "react";
import { SwipeableRight } from "../../../components/swipeableRight.tsx";
import { convertStringToMoment, getListItemBackground, isNullOrEmpty } from "../../../utils/functions.ts";
import { showAlert } from "../../../screens/commonAlertView.jsx";
import { CustomCalendarView } from "../../../components/customCalendarView.tsx";
import { ListIdea } from "../../../screens/details/docDetail/listIdea.jsx";
import { sendActionVanBanDen } from "../../../services/api/apiDetailVBDen.ts";
import { useDispatch, useSelector } from "react-redux";
import { endLoading, startLoading } from "../../../stores/loading/actions.ts";
import { LoadingScreen } from "../../../components/loadingScreen.tsx";
import { redirectScreen } from "../../../stores/base_screen/actions.ts";
import { AssignmentHeaderView } from "../../../components/assignmentHeaderView.tsx";
import { AssignItem } from "../../../components/assignItem.tsx";
import moment from "moment";
import { BeanDepartment } from "../../../services/database/models/bean_department.ts";

export const RecallOrForwardScreen = () => {
  const dispatch = useDispatch();
  const route = useRoute();
  const navigation = useNavigation();
  const [index, setIndex] = useState(0);
  const [departments, setDepartments] = useState<BeanDepartment[]>();
  // @ts-ignore
  const beanVanBanDen = route.params["beanVanBanDen"];
  // @ts-ignore
  const lstYKienLanhDao = JSON.parse(beanVanBanDen.CommentJson);
  // @ts-ignore
  let beanTasks_Donvi = beanVanBanDen.NhiemVuXuLyJson;
  // @ts-ignore
  const btnAction = route.params["btnAction"];
  const [isVisibleCalendar, setIsVisibleCalendar] = useState(false);
  const [indexItemSetDueDate, setIndexItemSetDueDate] = useState(-1);
  let removeDepartment:any[]|null|undefined= null;
  const onLoading = useSelector((state: any) => state.loading.onLoading);
  const screen = useSelector((state: any) => state.baseScreen.screen.toString());

  const tabs = [
    { title: "Bổ sung" },
    { title: "Thu hồi" }
  ];
  const BoSung = () => {
    // @ts-ignore
    const renderItem = ({ item, index }) => <AssignItem
      item={item}
      index={index}
      onDelete={() => {
        // @ts-ignore
        setDepartments((prevData) => prevData.filter((_, _index) => _index !== _index));
      }}
      onShowCalendar={() => {
        setIndexItemSetDueDate(index);
        setIsVisibleCalendar(true);
      }}
    />;

    return <View style={{ flex: 1, backgroundColor: "white", padding: 10 }}>
      <AssignmentHeaderView titleHeader={"Chuyển đến Tập đoàn, các đơn vị thành viên"}
        titleButton={"Công ty thành viên"}
        onPress={() => {
          // @ts-ignore
          navigation.navigate("SelectDepartmentScreen",
            {
              beanTasks_Donvi: beanTasks_Donvi,
              selectedTemp: departments,
              onSelectApply: (departments: any) => {
                setDepartments(departments);
              }
            });
        }}
        placeHolder={"Vui lòng bấm vào nút để chọn công ty thành viên"}
        imageButton={require("../../../assets/images/icon_tick_thanh_vien.png")} />
      <View style={{ marginTop: 10 }}>
        {
          // @ts-ignore
          departments != undefined &&
          <FlatList
            data={departments}
            renderItem={renderItem}
            scrollEnabled={false}
          />
        }
      </View>
    </View>;
  };

  const ThuHoi = () => {
    const [removeDepartmentTemp, setRemoveDepartmentTemp] = useState<any[]|null|undefined>();
    useEffect(()=>{
      removeDepartment=removeDepartmentTemp;
    },[removeDepartmentTemp]);
    // @ts-ignore
    const renderItem = ({ item, index }) => {
      const checkUnSelect = () => {
        if (removeDepartmentTemp != undefined) {
          // @ts-ignore
          return (removeDepartmentTemp.find((itemDatta: { Title: any; }) => itemDatta.ID == item.ID) == undefined);
        } else
          return true;
      };
      console.log("item", item);
      return <Pressable
        onPress={() => {
          if (removeDepartmentTemp != undefined) {
            // @ts-ignore
            if (removeDepartmentTemp.find((itemDatta: { Title: any; }) => itemDatta.ID == item.ID) == undefined) {
              // @ts-ignore
              setRemoveDepartmentTemp((prevData) => [...prevData, item]);
            } else {
              // @ts-ignore
              const difItem = removeDepartmentTemp.filter(itemDatta => itemDatta.ID != item.ID);
              setRemoveDepartmentTemp(difItem);
            }
          } else {
            // @ts-ignore
            setRemoveDepartmentTemp([item]);
          }
        }}
        style={{ padding: 10, flexDirection: "row", backgroundColor: getListItemBackground(index % 2 != 0) }}>
        <Text style={{ flex: 9 }}>{item.DepartmentName}</Text>
        <View style={{ flex: 1 }}>
          <Image style={{ height: 20, width: 20, marginRight: 10 }}
            source={checkUnSelect() ? require("../../../assets/images/icon_unCheckEvaluntion_Tint.png") : require("../../../assets/images/icon_CheckEvalution.png")} />
        </View>
      </Pressable>;
    };

    return <View style={{ flex: 1, backgroundColor: "white", padding: 10 }}>
      <Text style={{ color: "black", fontSize: 15, fontWeight: "bold", marginBottom: 10 }}>Tập đoàn các đơn vị thành
        viên</Text>
      {
        beanTasks_Donvi != undefined &&
        <FlatList
          data={JSON.parse(beanTasks_Donvi)}
          renderItem={renderItem}
          scrollEnabled={false}
        />
      }
    </View>;
  };
  const submitAction = () => {
    if (index == 0)//bo sung
    {
      beanVanBanDen.actionType = "forward";
      beanVanBanDen.ListIDDelete = null;
      if (departments != undefined && departments != null && departments.length > 0) {
        // @ts-ignore
        let ListAssignmentDept = "";
        departments.forEach((department: any) => {
          ListAssignmentDept += department.ID + ";#" + department.Title + "&&" + department.Url + "&&" + (isNullOrEmpty(department.HanXuLy) ? "" : moment(department.HanXuLy).format("yyyy/MM/DD")) + "&&@@";
        });
        beanVanBanDen.ListAssignmentDept = ListAssignmentDept.replace(/@+$/, "");
      } else {
        showAlert("Vui lòng chọn Đơn vị");
        return;
      }
    } else {
      beanVanBanDen.ListAssignmentDept = null;
      beanVanBanDen.actionType = "recall";
      if (removeDepartment != undefined && removeDepartment != null && removeDepartment.length > 0) {

        let IDs = "";
        removeDepartment.forEach(item => {
          IDs += item.ID.toString() + ";#" + item.DepartmentId.toString() + ";#" + item.DepartmentName + ";#" + item.DepartmentUrl + "|";
        });

        beanVanBanDen.ListIDDelete = IDs.endsWith('|') ? IDs.slice(0, -1) : IDs;
      } else {
        showAlert("Vui lòng chọn Đơn vị");
        return;
      }
    }
    dispatch(startLoading());
    sendActionVanBanDen(btnAction, beanVanBanDen).then(value => {
      dispatch(endLoading());
      if (value) {
        //ToDO reload list
        navigation.goBack();
        navigation.goBack();
      } else {
        showAlert("Thao tác không thực hiện được");
      }
    });
  };
  return <Pressable
    onPress={() => {
      Keyboard.dismiss();
    }}
    style={{
      flex: 1
    }}>
    <ModalTopBar
      title={""}
      onPress={() => {
        navigation.goBack();
      }} />
    <Tab
      value={index}
      onChange={(index) => {
        setIndex(index);
      }}
      indicatorStyle={styles.tabIndicatorStyle}
    >
      {tabs.map((tab, index) => (
        <Tab.Item
          key={index}
          title={tab.title}
          containerStyle={{ backgroundColor: "white" }}
          titleStyle={{
            fontSize: 12,
            color: "#000000"
          }}
        />
      ))}
    </Tab>
    <ScrollView style={{ backgroundColor: "white" }} onScroll={() => Keyboard.dismiss()}>
      <View style={{ backgroundColor: "white", padding: 10 }}>
        <Text>Ý kiến lãnh đạo</Text>
        <TextInput
        multiline
          placeholder={"Vui lòng nhập..."} 
          numberOfLines={5}
          style={{ 
            backgroundColor: "#F1F1F1",
             borderRadius: 5,
              marginTop: 10 ,
              textAlignVertical:'top',
               padding:5,
               height:100
              }} />
        {
          lstYKienLanhDao != undefined && <ListIdea data={lstYKienLanhDao} />
        }
      </View>
      {
        index == 0 ? <BoSung /> : <ThuHoi />
      }
    </ScrollView>
    <View style={{ justifyContent: "flex-end", flexDirection: "row", padding: 10, backgroundColor: "white" }}>
      <View style={{ flex: 2 }} />
      <Pressable
        onPress={() => {
          navigation.goBack();
        }}
        style={{ padding: 10, flex: 1 }}>
        <Text style={{ color: "#f65a5b" }}>Thoát</Text>
      </Pressable>
      <Pressable
        onPress={() => {
          submitAction();
        }}
        style={{
          padding: 10,
          flex: 1,
          backgroundColor: "#0072C6",
          borderRadius: 2
        }}>
        <Text style={{
          textAlign: "center",
          color: "white"
        }}>{index == 0 ? "Bổ sung" : "Thu hồi"}</Text>
      </Pressable>
    </View>
    {isVisibleCalendar &&
      <CustomCalendarView
        //@ts-ignore
        dateFocus={departments[indexItemSetDueDate].HanXuLy}
        onTouchOutSite={() => {
          setIndexItemSetDueDate(-1);
          setIsVisibleCalendar(!isVisibleCalendar);
        }}
        onPressDate={(date: any) => {
          // @ts-ignore
          departments[indexItemSetDueDate].HanXuLy = date.dateString;
          setIsVisibleCalendar(false);
        }}
      />}
    {onLoading && <LoadingScreen />}
  </Pressable>;
};
const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  tabContainer: {
    height: 50
  },
  tabIndicatorStyle: {
    backgroundColor: "#0072C6",
    height: 3,
    borderRadius: 100,
    marginHorizontal: 4
  }
});
