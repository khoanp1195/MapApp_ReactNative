import {
  Image,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { getRequireImageAction } from "../../../utils/functions.ts";

// @ts-ignore
export const MoreAction = ({ actionJson, onPressCancel, onPressAcion }) => {
  const data = actionJson.slice(2);
  return (
    <Pressable onPress={() => onPressCancel()} style={styles.container}>
      <View style={styles.actionContainer}>
        {data.map((item: any) => (
          <Pressable
            onPress={() => {
              onPressCancel();
              onPressAcion(item.ID);
            }}
            style={styles.actionItem}
            key={item.ID}
          >
            <Image
              style={{ height: 25, width: 20, marginRight: 10 }}
              resizeMode={"contain"}
              source={getRequireImageAction(item.ID, item.Class)}
            />
            <Text>{item.Title}</Text>
          </Pressable>
        ))}
      </View>

      <Pressable onPress={() => onPressCancel()} style={styles.exitButton}>
        <Text style={styles.exitButtonText}>Thoát</Text>
      </Pressable>
    </Pressable>
  );
};
const styles = StyleSheet.create({
  container: {
    position: "absolute",
    backgroundColor: "rgba(0, 0, 0, 0.4)",//"#19191EB2",
    height: "100%",
    width: "100%",
    alignItems: "center",
    justifyContent: "flex-end",
    flex: 1,
  },
  actionContainer: {
    marginBottom: 10,
    backgroundColor: "white",
    width: "90%",
    borderRadius: 6,
  },
  actionItem: {
    flexDirection: "row",
    padding: 10,
    borderBottomWidth: 0.5,
    borderBottomColor: "#19191EB2",
    alignItems: "center",
  },
  exitButton: {
    backgroundColor: "#EBEBE8",
    width: "90%",
    alignItems: "center",
    borderRadius: 6,
    padding: 10,
    marginBottom: 10,
  },
  exitButtonText: {
    color: "#0072C6",
    fontSize: 20,
  },
});

