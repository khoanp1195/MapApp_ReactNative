import { useNavigation, useRoute } from "@react-navigation/native";
import { Image, Keyboard, Pressable, StyleSheet, Text, View } from "react-native";
import { ModalTopBar } from ".././../../components/modalTopBar";
import { FlatList, ScrollView } from "react-native-gesture-handler";
import { TextEditorWithBorder } from ".././../../components/customTextEditor";
import React, { useEffect, useState } from "react";
import { getDisplayTxtFromDate, getListItemBackground, isNullOrEmpty } from "../../../utils/functions";
import { AssignmentHeaderView } from "../../../components/assignmentHeaderView.tsx";
import { BtnChooseEle } from "../../../components/buttonChooseSearchElement.tsx";
import { AssignItem } from "../../../components/assignItem.tsx";
import { CustomCalendarView } from "../../../components/customCalendarView.tsx";
import { useDispatch, useSelector } from "react-redux";
import { currentUserStore, subsiteStore } from "../../../config/constants.ts";
import { DbServices } from "../../../services/database/db_service.ts";
import { TypeSelectUser } from "../../../config/enum.ts";
import { LoadingScreen } from "../../../components/loadingScreen.tsx";
import { showAlert } from "../../../screens/commonAlertView.jsx";
import { endLoading, startLoading } from "../../../stores/loading/actions.ts";
import { sendActionVanBanDen } from "../../../services/api/apiDetailVBDen.ts";
import { getDataAssignTree } from "./assignHelper.tsx";
import strings from "../../../assets/strings.ts";
import moment from "moment";
import { BeanDepartment } from "../../../services/database/models/bean_department.ts";

export const AssignScreen = () => {
  const dispatch = useDispatch();
  const onLoading = useSelector((state: any) => state.loading.onLoading);
  const route = useRoute();
  const navigation = useNavigation()
  const [selectedCVPOrTPTH, setSelectedCVPOrTPTH] = useState();
  const [selectedCC, setSelectedCC] = useState();
  const [departments, setDepartments] = useState<BeanDepartment[]>();
  const [isVisibleCalendar, setIsVisibleCalendar] = useState(false);
  const [indexItemSetDueDate, setIndexItemSetDueDate] = useState(-1);
  const [_dropdownDefaultBLD, setDropdownDefaultBLD] = useState();
  const [dataTreeView, setDataTreeView] = useState();
  const [dataPhanCong, setDataPhanCong] = useState<BeanDepartment[]>();
  let [isCalendarDonViPhongBan, setIsCalendarDonViPhongBan] = useState(false);
  // let lstId: any;
  let ykien = "";
  // @ts-ignore
  const _beanVanBanDen = route.params["beanVanBanDen"];
  // @ts-ignore
  const btnAction = route.params["btnAction"];
  // let lv_1_departments: any;

  const submitAction = () => {
    dispatch(startLoading());
    if (selectedCVPOrTPTH == undefined && selectedCC == undefined && dataPhanCong == undefined && departments == undefined) {
      dispatch(endLoading());
      showAlert("Vui lòng chọn thông tin phân công");
    } else {
      //dispatch(startLoading());
      _beanVanBanDen.NguoiChuyen = currentUserStore.getCurrentUser().AccountID + ";#" + currentUserStore.getCurrentUser().Title;
      _beanVanBanDen.YKien = ykien;
      //CVP.TPTH
      if (selectedCVPOrTPTH != undefined) {
        _beanVanBanDen.chkPhanCong = "true";
        _beanVanBanDen.chkCVP_TPTH = "false";
        _beanVanBanDen.chkLanhDao = "false";
        // @ts-ignore
        _beanVanBanDen.NguoiNhan = selectedCVPOrTPTH.ID + ";#" + selectedCVPOrTPTH.Title;
      } else {
        _beanVanBanDen.chkPhanCong = "false";
        _beanVanBanDen.chkCVP_TPTH = "false";
        _beanVanBanDen.chkLanhDao = "false";
        _beanVanBanDen.NguoiNhan = "";
      }
      //CC
      // @ts-ignore
      if (selectedCC != undefined && selectedCC.length > 0) {
        // @ts-ignore
        _beanVanBanDen.UserCC = selectedCC.map((item: { AccountID: string; Title: string; }) => {
          return item.AccountID + ";#" + item.Title;
        }).join(";#");
      }

      //Phòng ban
      // @ts-ignore
      if (dataPhanCong != undefined && dataPhanCong.length > 0) {

        let character = "";
        for (const department of dataPhanCong) {
          if (department !== undefined) {
            if (!department.IsUser) { // Phòng
              department.DepartmentTitle = department.ID + ";#" + department.Title;
              console.log("department.DepartmentTitle", department.DepartmentTitle)

              if (department.IsThucHien)
                character += department.GroupManager + "&&1&&0&&0&&" + (isNullOrEmpty(department.HanXuLy) ? "" : moment(department.HanXuLy).format('yyyy/MM/DD')) + "&&" + department.DepartmentTitle + "&&" + department.Comment + "&&@@";
              else
                character += department.GroupManager + "&&0&&0&&1&&" + (isNullOrEmpty(department.HanXuLy) ? "" : moment(department.HanXuLy).format('yyyy/MM/DD')) + "&&" + department.DepartmentTitle + "&&" + department.Comment + "&&@@";
            } else { // Người
              if (department.IsThucHien)
                character += department.ID + ";#" + department.Title + "&&1&&0&&0&&" + (isNullOrEmpty(department.HanXuLy) ? "" : moment(department.HanXuLy).format('yyyy/MM/DD')) + "&&" + department.DepartmentTitle + "&&" + department.Comment + "&&@@";
              else
                character += department.ID + ";#" + department.Title + "&&0&&0&&1&&" + (isNullOrEmpty(department.HanXuLy) ? "" : moment(department.HanXuLy).format('yyyy/MM/DD')) + "&&" + department.DepartmentTitle + "&&" + department.Comment + "&&@@";
            }
          }
        }

        _beanVanBanDen.ListAssignmentUsers = character.replace(/@+$/, "");
      }

      
      if (departments != null && departments.length > 0) {
        let ListAssignmentDept = "";
        departments.forEach((lv2: any) => {
          ListAssignmentDept += lv2.ID + ";#" + lv2.Title + "&&" + lv2.Url + "&&" + (isNullOrEmpty(lv2.HanXuLy) ? "" : moment(lv2.HanXuLy).format('yyyy/MM/DD')) + "&&@@";
        });
        _beanVanBanDen.ListAssignmentDept = ListAssignmentDept.replace(/@+$/, "");
      }

      sendActionVanBanDen(btnAction, _beanVanBanDen).then(value => {
        dispatch(endLoading());
        if (value) {
          navigation.goBack();
          navigation.goBack();
        }
        else {
          showAlert("Thao tác không thực hiện được");
        }
      });

    }
  };

  useEffect(() => {
    getListBanLanhDao();
    //@ts-ignore
    getDataAssignTree(_beanVanBanDen)
      .then(value => {
        console.log("cây nè:", JSON.stringify(value))
        setDataTreeView(value)
      });
  }, []);

  const getListBanLanhDao = async () => {
    let _banLanhDao = _beanVanBanDen.BanLanhDao;
    if (_banLanhDao.includes(";#"))
      _banLanhDao = _banLanhDao.split(";#")[0];
    let data;
    if (!isNullOrEmpty(subsiteStore.getSubsite())) {
      data = await DbServices.getInstance().getBanLanhDaoRepository().findDiffId("*", _banLanhDao);
    } else {
      ///2: BOD1 trình lên BOD2, 3: BOD2 chuyển ngang, 4: BOD2 đã chuyển về BOD1 và BOD1 trình lên
      if (_beanVanBanDen.Step == 3) {
        data = await DbServices.getInstance().getBanLanhDaoRepository().findById("LanhDao", _banLanhDao);

        // @ts-ignore
        if (_dropdownDefault != undefined && (_dropdownDefault[0].LanhDao == "Chánh văn phòng" || _dropdownDefault[0].LanhDao == "Ban TGĐ")) {
          data = await DbServices.getInstance().getBanLanhDaoRepository().findByLanhDao("*", "'Ban TGĐ'");
        } else {
          data = await DbServices.getInstance().getBanLanhDaoRepository().findByLanhDao("*", "'HĐQT'");
        }
      } else {
        data = await DbServices.getInstance().getBanLanhDaoRepository().findInLanhDao("*", "'Chánh văn phòng','Trưởng phòng Tổng hợp - HĐQT'");
      }
    }
    // @ts-ignore
    setDropdownDefaultBLD(data);
  };

  const didFinishedEditting = (text: any) => {
    ykien = text;
  }
  const onClickCVPOrTPTH = () => {
    // @ts-ignore
    navigation.navigate("TypeSelectScreen",
      {
        data: _dropdownDefaultBLD,
        enableAvatar: true,
        title: "Lãnh đạo tập đoàn",
        selectedTitle: selectedCVPOrTPTH == undefined ? "" : selectedCVPOrTPTH["Title"],
        onSelected: (item: any) => {
          setSelectedCVPOrTPTH(item);
        }
      });
  };

  const onClickCC = () => {
    // @ts-ignore
    navigation.navigate("SelectUserScreen",
      {
        typeSelect: TypeSelectUser.Multiple,
        usersSelected: selectedCC,
        onSelectApply: (users: any) => {
          setSelectedCC(users);
        },
        beanTask: null,
        result: null
      });
  };

  const onChooseDepartment = () => {
    // @ts-ignore
    navigation.navigate("AssignTreeView",
      {
        // @ts-ignore
        dataSelected: dataPhanCong != undefined ? new Set(dataPhanCong.map(item => {
          var text = [item.ID, item.Title, item.IsThucHien, item.IsPhoiHop, item.IsUser, item.DepartmentTitle, item.GroupManager, item.GroupManager, item.HanXuLy].join(strings.SplitSignal);
          if (__DEV__)
            console.log("Chọn nè: ", text)
          return text;
        })) : new Set(),
        data: dataTreeView,
        onSubmit: (departments: any) => {
          setDataPhanCong(departments.map((item: string) => ({
            ID: item.split(strings.SplitSignal)[0],
            Title: item.split(strings.SplitSignal)[1],
            IsThucHien: JSON.parse(item.split(strings.SplitSignal)[2]),
            IsPhoiHop: JSON.parse(item.split(strings.SplitSignal)[3]),
            IsUser: JSON.parse(item.split(strings.SplitSignal)[4]),
            DepartmentTitle: item.split(strings.SplitSignal)[5],
            GroupManager: item.split(strings.SplitSignal)[6],
            HanXuLy: "",
            Comment: ""
          })));
        }
      });
  };

  const onChooseUnit = () => {
    // @ts-ignore
    navigation.navigate("SelectDepartmentScreen",
      {
        beanTasks_Donvi: [],
        selectedTemp: departments,
        onSelectApply: (departments: any) => {
          console.log("departments", departments);
          setDepartments(departments);
        }
      });
  };

  // @ts-ignore
  const renderItem = ({ item, index }) => <AssignItem
    item={item}
    index={index}
    onDelete={() => {
      // @ts-ignore
      setDepartments((prevData) => prevData.filter((_, _index) => _index !== _index));
    }}
    onShowCalendar={() => {
      setIsCalendarDonViPhongBan(false);
      setIndexItemSetDueDate(index);
      setIsVisibleCalendar(true);
    }}
  />;

  // @ts-ignore
  const renderItemPhongBan = ({ item, index }) => <AssignItem
    item={item}
    index={index}

    onDelete={() => {
      // @ts-ignore
      setDataPhanCong((prevData) => prevData.filter((_, _index) => _index !== index));
    }}

    onShowCalendar={() => {
      setIsCalendarDonViPhongBan(true);
      setIndexItemSetDueDate(index);
      setIsVisibleCalendar(true);
    }}
    textLabelBellowTitle={item.IsThucHien ? "Thực hiện" : "Phối hợp"}
  />;

  return (
    <Pressable style={{ flex: 1, backgroundColor: "white" }} onPress={() => {
      Keyboard.dismiss();
    }}>
      <ModalTopBar
        title={"Phân công"}
        isTitleCenter={true}

        onPress={() => {
          navigation.goBack();
        }} />

      <ScrollView style={{ flex: 1, paddingHorizontal: 10 }}>
        <View style={{ flex: 1, height: 20 }}><Text style={styles.titleStyle}>Ý kiến lãnh đạo</Text></View>
        <View style={{ flex: 1, height: 100 }}>
          <TextEditorWithBorder
            didFinishedEditting={(text: any) => {
              didFinishedEditting(text);
            }} />
        </View>

        <View style={{ flex: 1 }}>
          <View style={{ flex: 1, height: 20 }}>
            <Text style={styles.mainTitleStyle}>Chuyển đến CVP/TPTH</Text>
          </View>
          <BtnChooseEle
            title={"CVP/TPTH"}
            onClickHandle={() => {
              onClickCVPOrTPTH();
            }}
            //@ts-ignore
            valueText={(selectedCVPOrTPTH != null ? selectedCVPOrTPTH.Title : "")}
            imgPath={require("../../../assets/images/icon_expand_contact.png")}
          />

          <BtnChooseEle
            title={"CC"}
            onClickHandle={() => {
              onClickCC();
            }}
            //@ts-ignore
            valueText={selectedCC == undefined ? "" : selectedCC.map(item => item.Title).join(";")}
            imgPath={null}
          />

        </View>

        <View style={{ flex: 1 }}>
          <AssignmentHeaderView titleHeader={"Các phòng/ban nghiệp vụ Tập đoàn"}
            titleButton={"Phòng/ban"}
            onPress={() => {
              onChooseDepartment();
            }}
            placeHolder={"Vui lòng bấm vào nút để chọn phòng/ban"}
            imageButton={require("../../../assets/images/icon_tick_phong_ban.png")} />

          <View style={{ marginTop: 10 }}>
            {
              // @ts-ignore
              dataPhanCong != undefined &&
              <FlatList
                style={{ marginTop: 10 }}
                data={dataPhanCong}
                renderItem={renderItemPhongBan}
                scrollEnabled={false}
              />
            }
          </View>
        </View>

        <View style={{ flex: 1 }}>
          <AssignmentHeaderView titleHeader={"Chuyển đến Tập đoàn, các đơn vị thành viên"}
            titleButton={"Công ty thành viên"}
            onPress={() => {
              // @ts-ignore
              onChooseUnit();
            }}
            placeHolder={"Vui lòng bấm vào nút để chọn công ty thành viên"}
            imageButton={require("../../../assets/images/icon_tick_thanh_vien.png")} />
          <View>
            {
              // @ts-ignore
              departments != undefined &&
              <FlatList
                style={{ marginTop: 10 }}
                data={departments}
                renderItem={renderItem}
                scrollEnabled={false}
              />
            }
          </View>
        </View>
      </ScrollView>
      <View style={{ flexDirection: "row", padding: 10 }}>
        <View style={{ flex: 1 }} />
        <View style={{ flex: 1, flexDirection: "row" }}>
          <Pressable onPress={() => {
            navigation.goBack();
          }} style={{ flex: 1 }}><Text
            style={{ flex: 1, textAlign: "center", color: "#f65a5b", padding: 10 }}>Thoát</Text></Pressable>
          <Pressable
            onPress={() => {
              submitAction();
            }}
            style={{
              flex: 1,
              backgroundColor: "#0072C6",
              padding: 10,
              borderRadius: 6
            }}>
            <Text style={{
              textAlign: "center",
              backgroundColor: "#0072C6",
              color: "white",
              borderRadius: 6
            }}>Đồng ý</Text>
          </Pressable>
        </View>
      </View>

      {isVisibleCalendar &&
        <CustomCalendarView
          dateFocus={!isCalendarDonViPhongBan?departments![indexItemSetDueDate].HanXuLy:dataPhanCong![indexItemSetDueDate].HanXuLy}
          onTouchOutSite={() => {
            setIndexItemSetDueDate(-1);
            setIsVisibleCalendar(!isVisibleCalendar);
          }}
          onPressDate={(date: any) => {
            if (!isCalendarDonViPhongBan) {
              // @ts-ignore
              departments[indexItemSetDueDate].HanXuLy = date.dateString;
            } else {
              if (dataPhanCong != undefined) { // @ts-ignore
                dataPhanCong[indexItemSetDueDate].HanXuLy = date.dateString;
              }
            }
            setIsVisibleCalendar(false);
          }}
        />}
      {onLoading && <LoadingScreen />}
    </Pressable>
  );
};

const styles = StyleSheet.create({
  root: {
    height: "100%"
  },
  mainTitleStyle: {
    flex: 1,
    fontWeight: "bold"
  },
  titleStyle: {
    flex: 1
  }
});
