import { FlatList, Pressable, StyleSheet, Text, View } from "react-native"
import { getDisplayTxtFromDateString } from "../../../utils/functions.ts";
import React from 'react'

export const List_noidung_hslt = ({ hslt }) => {
    return (
        <View style={styles.basicStyle}>
            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Mã hồ sơ</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{hslt.MaHoSo}</Text>

            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Tên hồ sơ</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{(hslt.TenHoSo)}</Text>

            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Nội dung</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{hslt.NoiDung}</Text>

            <View>
                <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                    <Text style={styles.titleTextStyle}>Từ ngày</Text>
                    <Text style={styles.titleTextStyle}>Đến ngày</Text>
                </View>
                <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                    <Text style={styles.valueTextStyle}>{getDisplayTxtFromDateString(hslt.FromDate)} </Text>
                    <Text style={styles.valueTextStyle}>{getDisplayTxtFromDateString(hslt.ToDate)}</Text>
                </View>
            </View>
            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Nơi lưu</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{hslt.NoiLuu}</Text>

            <View>
                <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                    <Text style={styles.titleTextStyle}>Lĩnh vực</Text>
                    <Text style={styles.titleTextStyle}>Tình trạng</Text>
                </View>
                <View style={[styles.basicStyle, { flexDirection: 'row' }]}>
                    <Text style={[styles.valueTextStyle, styles.basicStyle]}>{hslt.LinhVuc}</Text>
                    <Text style={[styles.valueTextStyle, styles.basicStyle]}>{hslt.StatusText}</Text>
                </View>
            </View>


            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Người cập nhật</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{hslt.FollowerText}</Text>

            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Quyền xem</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{hslt.ViewerText}</Text>

            <Text style={[styles.titleTextStyle, styles.basicStyle]}>Người tạo hồ sơ</Text>
            <Text style={[styles.valueTextStyle, styles.basicStyle]}>{(hslt.CreatedByText)}</Text>
        </View>
    )
}

const styles = StyleSheet.create({
    basicStyle: {
        flex: 1,
        margin: 5,
    },
    titleTextStyle: {
        flex: 1,
        fontSize: 13,
        color: 'darkgray',
    },
    valueTextStyle: {
        flex: 1,
        fontSize: 15,
        color: 'black',
    },
})

