import {
  Dimensions,
  Image,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  processColor
} from "react-native";
import { TestChart } from "./test_chart.tsx";
import { useEffect, useMemo, useState } from "react";
import { getCount } from "../../services/api/api_home_page.ts";
import { CircleButton } from "../../components/circleButton.tsx";
import { DashBoardButton } from "../../components/dashBoardButton.tsx";
import { PetroAppBarCustom } from "../../components/petro_appbar_custom.tsx";
import { DrawerActions, useNavigation } from "@react-navigation/native";
import { useDispatch, useSelector } from "react-redux";
import { showLeftMenuHome } from "../../stores/leftmenu/actions.ts";
import BaseScreen from "../../components/basescreen.tsx";
import { TinNoiBoComponent } from "../../screens/utilities/tinnoibo/tinNoiBoComponent.tsx";
import { getDashboard } from "../../services/api/apiTinNoiBo.ts";
import { TinNoiBoType, ViewModeTinNoiBo } from "../../config/enum.ts";
import {
  redirectHSLTCuaToi,
  redirectTBScreen,
  redirectTinNoiBo,
  redirectVBDenTitle,
  redirectVBDiTitle,
  redirectVBPHScreen,
  redirectVCXLHighScreen,
  redirectVCXLScreen
} from "../../stores/base_screen/actions.ts";
import { changePageTypeTinNoiBo } from "../../stores/tinnoibo/actions.ts";
import { BASE_URL, currentUserStore, isTabletMode, subsiteStore } from "../../config/constants.ts";
import { CountComponent } from "./countComponent.tsx";
import { CustomFastImage } from "../../components/custom_fast_image.tsx";
import { PieChart } from "react-native-charts-wrapper";
import { Calendar, LocaleConfig, WeekCalendar, CalendarProvider } from 'react-native-calendars';
import React from "react";
import { dimnensHeight, formatDate, startOfWeek } from "../../utils/functions.ts";
import moment from "moment";
import { getMeetingCalendars } from "../../services/api/api_calendar.ts";
export const HomeScreen = () => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const [dataTinNoiBo, setDataTinNoiBo] = useState();
  const onLoading = useSelector((state: any) => state.loading.onLoading);
  const [currentUser, setCurrentUser] = useState(currentUserStore.getCurrentUser())
  const [data, setData] = useState({ "ThongBao": 0, "VBCanXuLy": 0, "VBCanXuLyHigh": 0, "VBPhoiHop": 0 });
  const [dataChart, setdataChart] = useState({})
  const [selectDate, setselectDate] = useState(moment(new Date()).format("YYYY-MM-DD"))
  const [siteConnection, setsiteConnection] = useState("portal")
  const [isChangeUnit, setisChangeUnit] = useState(false)
  const [refreshing, setRefreshing] = useState(false)
  const [dotCalendar, setdotCalendar] = useState([])
  
  const getCountChart = useMemo(() =>{
      return async () =>{
        const value = await getCount()
        setData(value)
        const newDataChart = {
          dataSets: [
            {
              values: [
                { value: value.ThongBao, label: "Thông báo" },
                { value: value.VBCanXuLy, label: "VB cần xử lý" },
                { value: value.VBCanXuLyHigh, label: "VB cần xử lý khẩn" },
                { value: value.VBPhoiHop, label: "VB phối hợp" },
              ],
              label: "",
              config: {
                colors: [
                  processColor("#f87080"),
                  processColor("#ab89f7"),
                  processColor("#dbedea"),
                  processColor("#fdc065")
                ],
                drawValues: true,
                valueTextSize: 15,
                valueTextColor: processColor("#000"),
                valueFormatter: "#.#'%'",
                sliceSpace: 5,
                selectionShift: 100,
                yValuePosition: "OUTSIDE_SLICE",
              },
            },
          ],
          description: {
            text: 'This is Pie chart description',
            textSize: 15,
            textColor: processColor('darkgray'),
          }
        };
        setdataChart(newDataChart );
      }
  },[])


  useEffect(() =>{
    getCountChart()
  },[onLoading])

  useEffect(() => {
    if (!onLoading) {
      getDashboard().then(value => {
        setDataTinNoiBo(value);
      });
    }
  }, [onLoading]);

  useEffect(() =>{
    loadMyCalendar()
  },[])



  const loadListCalendarByWeek = async (fromDate: any, toDate: any, flag:number, SiteConnection: any) =>{
   try{
    const data = await getMeetingCalendars(fromDate,toDate,flag,SiteConnection)
    if(data != null){
      return data
    }else{
      return []
    }
   }catch(error)
   {
    console.log("LoadCalendar - error: " + error)
   }
  }

  const loadMyCalendar = () => {
    const dateObject = new Date(selectDate);
    const firstDay = startOfWeek(dateObject);
    const lastDay = new Date(firstDay);
    firstDay.setDate(firstDay.getDate() - 20);
    lastDay.setDate(firstDay.getDate() + 10);

    loadListCalendarByWeek(formatDate(firstDay), formatDate(lastDay), 3, siteConnection)
      .then(dataMyCalendar => {
        if (dataMyCalendar) {
          const markedDates = dataMyCalendar.reduce((acc, item) => {
            if (item.StartTime) {
              const key = moment(item.StartTime).format("YYYY-MM-DD");
              acc[key] = {
                textColor: 'green',
                color: 'green',
                dotColor: 'red',
                marked: true
              };
            }
            return acc;
          }, {});

          setdotCalendar(markedDates);
          setisChangeUnit(false);
          setRefreshing(false)
        } else {
          console.error('No calendar data available');
        }
      })
      .catch(error => {
        console.error('Error loading calendar:', error);
      });
  };



  const onClickVBDen = () => {
    dispatch(redirectVBDenTitle());
    navigation.dispatch(DrawerActions.closeDrawer());
  }

  const onClickVBPH = () => {
    dispatch(redirectVBDenTitle());
    navigation.dispatch(DrawerActions.closeDrawer());
  }
  const chartDimention = useMemo(() => {
    const scale = Dimensions.get('window').scale
    const dimention = dimnensHeight(scale)
    return dimention
  }, [])


  return <View style={styles.root}>
    <BaseScreen>
      <View style={{
        backgroundColor: '#718b81',
        height: "100%",
      }}>
        <PetroAppBarCustom
          title={"Trang chủ"}
          rightAction={
            <TouchableOpacity onPress={() => {
              // @ts-ignore
              navigation.navigate("QRScreen");

            }}>
              <Image style={{ height: 30, width: 30 }} source={require("../../assets/images/icon_qr.png")} />
            </TouchableOpacity>
          }
          onPress={() => {
            try {
              dispatch(showLeftMenuHome());
              // @ts-ignore 
              navigation.openDrawer();
              // navigation.dispatch(DrawerActions.openDrawer())
            } catch (e) {
              if (__DEV__)
                console.log("Lỗi gòi: " + e);
            }
          }} />
        <View style={{
          backgroundColor: '#e1f0fe',
          height: "100%",
          flexDirection: 'row'
        }}>
          <View style={{ backgroundColor: '#e1f0fe', height: '100%', width: '6%', alignContent: 'center', alignItems: 'center' }}>

            <TouchableOpacity style={{ marginTop: '100%' }} onPress={() => {
              // @ts-ignore
              navigation.navigate("QRScreen");

            }}>
              <Image style={{ height: 60, width: 60 }} source={require("../../assets/images/icon_qr.png")} />
            </TouchableOpacity>


            {/*View vb_den, vbdi,hstl*/}
            <View style={styles.topButtonContainer}>
              <CircleButton path={require("../../assets/images/icon_vbden_db.png")} title={"VB đến"} onClick={() => {
                dispatch(redirectVBDenTitle());
              }} />
            </View>
            <View style={styles.topButtonContainer}>
              <CircleButton path={require("../../assets/images/icon_vbdi_db.png")} title={"VB đi/Nội bộ"}
                onClick={() => {
                  dispatch(redirectVBDiTitle());
                }} />
            </View>
            <View style={styles.topButtonContainer}>
              <CircleButton path={require("../../assets/images/icon_hslt_db.png")} title={"Hồ sơ lưu trữ"}
                onClick={() => {
                  dispatch(redirectHSLTCuaToi());
                }} />
            </View>




          </View >
          <View style={styles.scrollView}>

            <View style={{ flexDirection: 'row', flex: 2 }}>
              {/*View Left*/}
              <ScrollView style={{ width: '66%', height: '100%' }}>



                <View style={{
                  flexDirection: isTabletMode ? 'row' : 'column',
                  width: '100%',
                  height: '20%',
                }}>
                  <View style={{ flex: 1 }}>
                    <TinNoiBoComponent
                      sizeTitle={20}
                      title={"Tin nội bộ"}
                      data={dataTinNoiBo}
                      typeView={TinNoiBoType.DashBoard}
                      viewMode={ViewModeTinNoiBo.Horizontal}
                      showDot={true}
                      showAll={true}
                      autoScroll={true}
                      onPressAll={() => {
                        dispatch(changePageTypeTinNoiBo(undefined));
                        // @ts-ignore
                        navigation.navigate("TienIch");

                        dispatch(redirectTinNoiBo());
                      }}
                      showLine={false}
                    />
                  </View>


                </View>


                <View style={{ width: '100%', height: '50%', marginTop: 20 }}>
                  <CountComponent />
                </View>

                <View style={{ width: '100%', height: '20%', flexDirection: 'column' }}>
                  <Text style={{ fontWeight: '600', fontSize: 30, margin: 10 }}>Biểu đồ </Text>
                </View>



              </ScrollView>

              {/*View Right*/}
              <ScrollView
                style={{ width: '34%', height: '102%', backgroundColor: '#f7f7ff', borderRadius: 30 }}>

                {/*View header*/}
                <View style={{ flexDirection: 'row', height: 100 }}>


                  <View style={{ width: '30%', height: 100, flexDirection: 'row', marginTop: '5%', justifyContent: 'center', alignItems: 'flex-start' }}>
                    <TouchableOpacity style={{ marginTop: '15%', marginLeft: '15%' }} onPress={() => {
                      // @ts-ignore
                      navigation.navigate("QRScreen");

                    }}>

                      <Image style={{ height: 30, width: 30 }} source={require("../../assets/images/notification_icon.png")} />
                    </TouchableOpacity>

                    <TouchableOpacity style={{ marginTop: '15%', marginLeft: '15%' }} onPress={() => {
                      // @ts-ignore
                      navigation.navigate("QRScreen");

                    }}>

                      <Image style={{ height: 30, width: 30 }} source={require("../../assets/images/icon_qr.png")} />
                    </TouchableOpacity>
                  </View>

                  <View style={{ flexDirection: 'column', marginRight: '10%', width: '70%' }}>
                    <View style={styles.imageContainer}>
                      <CustomFastImage
                        defaultImage={require("../../assets/images/avatar80.jpg")}
                        urlOnline={BASE_URL + "/" + subsiteStore.getSubsite() + "/" + currentUser.ImagePath}
                        styleImg={styles.image}
                      />
                    </View>

                    <View style={styles.textContainer}>
                      <Text numberOfLines={1} style={styles.name}>{currentUser.Title}</Text>
                    </View>
                    <View style={styles.txt_positionContainer}>
                      <Text numberOfLines={1} style={styles.position}>{currentUser.Position}</Text>
                    </View>
                  </View>

                </View>
                {/*View header*/}


                {/*View calendar*/}
                <View style={{ width: '100%', height: 500, marginTop: '4%' }}>
                  <View
                    style={{ width: '90%', height: '10%', alignSelf: 'center', flexDirection: 'row', justifyContent: 'center' }}
                  >
                    <Text style={{ marginTop: '4%', marginLeft: '2%', width: '60%', fontSize: 16, fontWeight: '500' }}>Schedule Calendar</Text>

                    <View style={{
                      flexDirection: 'row',
                      backgroundColor: '#e1f0fe',
                      borderColor: 'gray',
                      shadowColor: 'lightgray',
                      shadowOffset: { width: 0, height: 2 },
                      shadowOpacity: 1,
                      shadowRadius: 4,
                      borderRadius: 10,
                      width: '40%'

                    }}>
                      <Text style={{ marginTop: '4%', width: '70%', marginLeft: '5%', fontSize: 14, fontWeight: '500', alignSelf: 'center' }}>2.4.2024</Text>
                      <Image style={{ height: 30, width: 30, alignSelf: 'center' }} source={require("../../assets/images/icon_calendar_home.png")} />
                    </View>

                  </View>
                  <Calendar
                    theme={{
                      backgroundColor: '#F3F9FF',
                      calendarBackground: '#F3F9FF',
                      textSectionTitleColor: '#b6c1cd',
                      selectedDayBackgroundColor: '#00adf5',
                      selectedDayTextColor: '#ffffff',
                      todayTextColor: '##f7f7ff',
                      dayTextColor: '#2d4150',
                      textDayHeaderFontWeight: '600',
                    }}
                    markedDates={dotCalendar}
                    style={styles.calendar}
                  />
                </View>
                {/*View calendar*/}



                {/*View piechart*/}
                <Text style={{ marginLeft: '4%', width: '60%', fontSize: 16, fontWeight: '500' }}>Number of Patients</Text>

                <View style={{
                  width: '90%',
                  height: 400,
                  borderRadius: 30,
                  alignSelf: 'center',
                  backgroundColor: '#fafafe',
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.2,
                  shadowRadius: 4,
                  marginTop: '5%'
                }}>
                  <PieChart
                    style={[styles.viewChart, {
                      height: 150 + (chartDimention) + '%',
                      width: 100 + (chartDimention * Dimensions.get('window').scale) + '%',
                      marginTop: '-50%',
                      alignSelf: 'center',
                    }]}
                    logEnabled={true}
                    chartBackgroundColor={processColor("transparent")}
                    chartDescription={{ text: "" }}
                    data={dataChart }
                    legend={{
                      enabled: false, // Disable legend
                      horizontalAlignment: 'CENTER', // Set legend position to the left
                      verticalAlignment: 'BOTTOM',// Adjust vertical alignment if necessary
                    }}
                    highlights={[]}
                    noDataText={"No data chart !"}
                    entryLabelColor={processColor("black")}
                    entryLabelTextSize={12}
                    touchEnabled={false}
                    drawEntryLabels={false}
                    usePercentValues={true}
                    rotationEnabled={true}
                    centerText={""}
                    onSelect={() => { }}
                    centerTextRadiusPercent={0}
                    holeRadius={30}
                    transparentCircleRadius={0}
                    maxAngle={360}
                    rotationAngle={45}
                  />

                  {/*View description piechart*/}
                  <View style={{
                    marginTop: '-45%',
                    width: '100%',
                    height: 100,
                    flexDirection: 'column',
                    backgroundColor: '#fafafe',
                    borderRadius: 30,
                    justifyContent:'center'
                  }}>

                    <View style={{ width: '100%', height: '20%', flexDirection: 'row' }}>

                      <View style={{ flexDirection: 'row', height: '100%', width: '50%', alignItems: 'center' }}>
                        <View style={{ marginLeft: '10%', backgroundColor: '#f87080', width: 20, height: 20 }}>

                        </View>

                        <View >
                          <Text
                            style={{
                              marginLeft: '8%', fontWeight: '600'
                            }}
                          >
                            Thông báo
                          </Text>
                          <Text
                            style={{
                              marginLeft: '8%',
                              color: 'gray'
                            }}
                          >
                            {data.ThongBao}
                          </Text>
                        </View>


                      </View>

                      <View style={{ flexDirection: 'row', height: '100%', width: '50%', alignItems: 'center' }}>
                        <View style={{ marginLeft: '10%', backgroundColor: '#fdc065'  , width: 20, height: 20 }}>
                        </View>
                        <View >
                          <Text
                            style={{
                              marginLeft: '8%', fontWeight: '600'
                            }}
                          >
                            Vb phối hợp
                          </Text>
                          <Text
                            style={{
                              marginLeft: '8%',
                              color: 'gray'
                            }}
                          >
                            {data.VBPhoiHop}
                          </Text>
                        </View>
                      </View>

                    </View>


                    <View style={{ width: '100%', height: '20%', flexDirection: 'row', marginTop:'10%' }}>

                      <View style={{ flexDirection: 'row', height: '100%', width: '50%', alignItems: 'center' }}>
                        <View style={{ marginLeft: '10%', backgroundColor: '#ab89f7', width: 20, height: 20 }}>

                        </View>

                        <View >
                          <Text
                            style={{
                              marginLeft: '8%', fontWeight: '600'
                            }}
                          >
                            Vb cần xử lý
                          </Text>
                          <Text
                            style={{
                              marginLeft: '8%',
                              color: 'gray'
                            }}
                          >
                            {data.VBCanXuLy}
                          </Text>
                        </View>


                      </View>

                      <View style={{ flexDirection: 'row', height: '100%', width: '50%', alignItems: 'center' }}>
                        <View style={{ marginLeft: '10%', backgroundColor: '#dbedea', width: 20, height: 20 }}>
                        </View>
                        <View >
                          <Text
                          numberOfLines={2}
                            style={{
                              marginLeft: '8%', fontWeight: '600'
                            }}
                          >
                            Vb ưu tiên xử lý sớm
                          </Text>
                          <Text
                            style={{
                              marginLeft: '8%',
                              color: 'gray'
                            }}
                          >
                             {data.VBCanXuLyHigh}
                          </Text>
                        </View>
                      </View>

                    </View>












                  </View>

                </View>
                {/*View piechart*/}


              </ScrollView>



            </View>


          </View >
        </View>
      </View >
    </BaseScreen >
  </View >;
};

const styles = StyleSheet.create({
  root: {
    height: "100%",
  },
  viewChart: {
    backgroundColor: 'transparent',
    borderRadius: 15,
  },
  scrollView: {
    backgroundColor: "#f1f1ff",
    height: "90%",
    width: '90%',
    marginRight: '1%',
    paddingBottom: 20,
    marginTop: '2%',
    borderRadius: 40,
    flexDirection: 'row'
  },
  container: {
    width: '50%',
    marginTop: 100,
    padding: 15,
    height: '90%'
  },
  innerContainer: {
    flex: 1,
    padding: 0
  },
  topButtonContainer: {
    marginTop: 50
  },
  viecXLContainer: {
    flex: 1,
    borderRadius: 12,
    margin: 5
  },
  imageContainer: {
    padding: 35,
    alignItems: 'flex-end',
    width: '40%',
    marginLeft: '60%',
  },
  image: {
    height: 50,
    width: 50,
    borderRadius: 40,

  },
  textContainer: {
    marginLeft: '15%',
    marginTop: '-27%',
    width: '50%'
  },
  txt_positionContainer: {
    marginLeft: '15%',
    marginTop: '5%',
    width: '50%'
  },
  name: {
    fontSize: 15,
    color: "#000000",
    textAlign: 'right'
  },
  position: {
    fontSize: 13,
    color: "#5E5E5E",
    alignContent: 'flex-end',
    textAlign: 'right'
  },
  calendar: {
    height: '86%',
    borderColor: 'gray',
    shadowColor: 'lightgray',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 4,
    borderRadius: 20,
    alignSelf: 'center',
    width: '90%',
    marginTop: '5%',
  },
});


{/* <View
style={[
  styles.container,
  {
    flexDirection: "row",
  }
]}>
<View style={styles.topButtonContainer}>
  <CircleButton path={require("../../assets/images/icon_vbden_db.png")} title={"VB đến"} onClick={() => {
    dispatch(redirectVBDenTitle());
  }} />
</View>
<View style={styles.topButtonContainer}>
  <CircleButton path={require("../../assets/images/icon_vbdi_db.png")} title={"VB đi/Nội bộ"}
    onClick={() => {
      dispatch(redirectVBDiTitle());
    }} />
</View>
<View style={styles.topButtonContainer}>
  <CircleButton path={require("../../assets/images/icon_hslt_db.png")} title={"Hồ sơ lưu trữ"}
    onClick={() => {
      dispatch(redirectHSLTCuaToi());
    }} />
</View>
</View> */}