import { StyleSheet, Text, View } from "react-native";
import { DashBoardButton } from "../../components/dashBoardButton";
import { useNavigation } from "@react-navigation/native";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { getCount } from "../../services/api/api_home_page";
import { redirectTBScreen, redirectVBPHScreen, redirectVCXLHighScreen, redirectVCXLScreen } from "../../stores/base_screen/actions";
import React from "react";

export const CountComponent = () => {
    const dispatch = useDispatch();
    const refreshHome = useSelector((state: any) => state.refreshHome.refreshHome);
    const [data, setData] = useState({ "ThongBao": 0, "VBCanXuLy": 0, "VBCanXuLyHigh": 0, "VBPhoiHop": 0 });
    useEffect(() => {
        if (!refreshHome) {
            getCount().then(value => {
                setData(value);
            });
        }
    }, [refreshHome]);
    return <View style={{ flex: 1,marginTop:170 }}>
        <Text style={{ color: "#004374", fontSize: 20, fontWeight: "bold", marginHorizontal: 20, marginTop: 5 }}>Xử lý
            văn bản</Text>
        <View style={{ height: 340}}>
            <View style={[
                styles.container,
                {
                    flexDirection: "row"
                }
            ]}>
                <View
                    style={[
                        styles.innerContainer,
                        {
                            flexDirection: "row"
                        }
                    ]}>
                    
                    <View style={[styles.viecXLContainer]}>
                        <DashBoardButton title={"Thông báo (để biết)"}
                            path={require("../../assets/images/icon_db_tb.png")}
                            countNum={data !== undefined ? data.ThongBao : 0}
                            countNumColor={"#004EE1"}
                            handleClick={() => {
                                dispatch(redirectTBScreen());
                            }} />
                    </View>
                    
                    <View style={[styles.viecXLContainer]}>
                        <DashBoardButton
                            title={"VB phối hợp"}
                            path={require("../../assets/images/icon_db_vbph.png")}
                            countNum={data !== undefined ? data.VBPhoiHop : 0} countNumColor={"#00CF6C"}
                            handleClick={() => {
                                dispatch(redirectVBPHScreen());
                            }} />
                    </View>
                    
                    <View style={[styles.viecXLContainer]}>
                        <DashBoardButton
                            title={"VB cần xử lý"}
                            path={require("../../assets/images/icon_db_vcxl.png")}
                            countNum={data !== undefined ? (data?.VBCanXuLy ?? 0) - (data?.VBCanXuLyHigh ?? 0) : 0}
                            countNumColor={"#FFCF2C"}
                            handleClick={() => {
                                dispatch(redirectVCXLScreen());
                            }}
                        />
                    </View>
                    
                    <View style={[styles.viecXLContainer]}>
                        <DashBoardButton
                            title={"VB ưu tiên xử lý sớm"}
                            path={require("../../assets/images/icon_db_vcxl_hight.png")}
                            countNum={data !== undefined ? data.VBCanXuLyHigh : 0}
                            countNumColor={"#FA6400"}
                            handleClick={() => {
                                dispatch(redirectVCXLHighScreen());
                            }}
                        />
                    </View>

                </View>

            </View>
        </View>
    </View>
}
const styles = StyleSheet.create({
    root: {
        height: "100%"
    },
    scrollView: {
        backgroundColor: "white",
        height: "100%",
        paddingBottom: 20
    },
    container: {
        height:'80%',
        padding: 15,
    },
    innerContainer: {
        width:'100%',
    },
    topButtonContainer: {
        flex: 1,
        height: 70
    },
    viecXLContainer: {
        borderRadius: 12,
        margin:15,
        width:'20%',
        alignSelf:'center',
        backgroundColor:'#fafafe',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2, 
        shadowRadius: 4,
    }
});