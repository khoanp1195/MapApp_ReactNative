import { Defs, LinearGradient, Stop } from "react-native-svg";
// @ts-ignore
export const GradientChartComponent=  ({ id, stopColor1, stopColor2 }) => (
  <Defs key={id}>
    <LinearGradient id={id} x1={'0%'} y1={'0%'} x2={'0%'} y2={'100%'}>
      <Stop offset={'0%'} stopColor={stopColor1} />
      <Stop offset={'100%'} stopColor={stopColor2} />
    </LinearGradient>
  </Defs>
);
