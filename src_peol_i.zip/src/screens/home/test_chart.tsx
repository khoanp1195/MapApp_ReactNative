import { Image, StyleSheet, Text, View } from "react-native";
// @ts-ignore
import { PieChart as SVGPieChart } from "react-native-svg-charts";
import { GradientChartComponent } from "./chart/gradient_chart_component.tsx";
// @ts-ignore
import EmptyView from "../../components/empty_view.tsx";
import React from "react";

// @ts-ignore
export const TestChart = ({ countData }) => {
  const GradientTB = () => <GradientChartComponent id={"thongbao"} stopColor1={"#4CD9ED"} stopColor2={"#006BCF"} />;
  const GradientVBPH = () => <GradientChartComponent id={"vbph"} stopColor1={"#36FF8C"} stopColor2={"#00A245"} />;
  const GradientVCXL = () => <GradientChartComponent id={"vcxl"} stopColor1={"#FFEFAE"} stopColor2={"#FFCC00"} />;
  const GradientVCXL_HIGHT = () => <GradientChartComponent id={"vcxlhight"} stopColor1={"#FFC386"}
                                                           stopColor2={"#FF4040"} />;

  const data = [
    {
      value: countData?.ThongBao ?? 0,
      svg: { fill: "url(#thongbao)" },
      key: "thongbao"
    },
    {
      value: countData?.VBPhoiHop ?? 0,
      svg: { fill: "url(#vbph)" },
      key: "vbph"
    },
    {
      value: (countData?.VBCanXuLy ?? 0) - (countData?.VBCanXuLyHigh ?? 0),
      svg: { fill: "url(#vcxl)" },
      key: "vcxl"
    },
    {
      value: countData?.VBCanXuLyHigh ?? 0,
      svg: { fill: "url(#vcxlhight)" },
      key: "vcxlhight"
    }
  ];

  // @ts-ignore
  const LegendItem = ({ title, path }) => {
    return <View style={{ padding: 5, flexDirection: "row", alignItems: "center" }}>
      <Image style={{ width: 15, height: 15 }} source={path} />
      <Text style={{ marginLeft: 10, color: "#4C4C4C" }}>{title}</Text>
    </View>;
  };
  return <View style={{ flex: 1, margin: 10 }}>
    <Text style={{ color: "#004374", fontSize: 20, fontWeight: "bold", marginHorizontal: 10, marginBottom: 10 }}>Tình
      hình xử lý văn bản</Text>
    <View style={styles.container_chart}>
      {
        countData !== undefined && (!(countData.ThongBao == 0 && countData.VBPhoiHop == 0 && countData.VBCanXuLy == 0 && countData.VBCanXuLyHigh == 0)) ?
          <View style={{ flexDirection: "row" }}>
            <SVGPieChart
              style={{ height: 160, flex: 1 }}
              data={data}
              spacing={0}
              outerRadius={"95%"}>
              <GradientTB />
              <GradientVBPH />
              <GradientVCXL />
              <GradientVCXL_HIGHT />
            </SVGPieChart>
            <View style={{ flex: 1, flexDirection: "column", justifyContent: "center" }}>
              {(countData !== undefined && countData?.ThongBao > 0) &&
                <LegendItem title={`Thông báo (để biết)`}
                            path={require("../../assets/images/icon_chart_tb.png")} />}
              {(countData !== undefined && countData?.VBPhoiHop > 0) &&
                <LegendItem title={`Văn bản phối hợp`}
                            path={require("../../assets/images/icon_chart_ph.png")} />}
              {(countData !== undefined && countData?.VBCanXuLy > 0) &&
                <LegendItem title={`Việc cần xử lý`}
                            path={require("../../assets/images/icon_chart_vcxl.png")} />}
              {(countData !== undefined && countData?.VBCanXuLyHigh > 0) &&
                <LegendItem title={`Việc cần xử lý sớm`}
                            path={require("../../assets/images/icon_chart_vcxl_hight.png")} />}
            </View>
          </View> :
          <EmptyView />
      }
    </View>
  </View>;
};

const styles = StyleSheet.create({
  container_chart: {
    flex: 1,
    borderRadius: 12,
    backgroundColor: "#DCF5FF",
    padding: 15,
    borderColor: "#000000",
    marginHorizontal: 10
  }
});
