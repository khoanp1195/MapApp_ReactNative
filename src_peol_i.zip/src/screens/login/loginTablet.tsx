import { Dimensions, Image, ImageBackground, TextInput, View,TouchableOpacity } from "react-native"
import { styles } from "./login.style"
import { useSelector } from "react-redux";
import { Button, Text } from "react-native-elements";
import { FC } from "react";
import React from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import LottieView from 'lottie-react-native';

interface Props {
  onChangeTextUserName(username: string): void,
  onChangeTextPassword(password: string): void
  handleLogin(): void
}
export const LoginTabletScreen: FC<Props> = ({ onChangeTextUserName, onChangeTextPassword, handleLogin }) => {
  const { loading } = useSelector((state: any) => state.login);
  const windowWidth = Dimensions.get('window').width;
  const windowHeight = Dimensions.get('window').height;
  return <SafeAreaView style={styles.container}>
  <View
    style={{ width: windowWidth, height: windowHeight, marginTop:'-1.8%',flexDirection:'row',backgroundColor:'#e1f0fe' }}
  >

    
      <View style={{backgroundColor:'#e1f0fe',width:'50%',height:'100%', }}>
     <LottieView
        source={require('../../assets/lotties/Animation_Login.json')} // Replace with your animation file path
        autoPlay={true} // Set to true for automatic playback
        loop={true} // Set to true for continuous looping
        style={styles.lottie} // Optional styles for the Lottie animation
      />
</View>


<View style={{ justifyContent: 'center', alignContent: 'center', flex: 1 }}>
{!loading && (
<View style={styles.loginTabContainer}>
  <View style={{ backgroundColor: 'white', height:'90%',width:'100%',borderRadius:30}}>
   <View style={{width:'100%', height:'15%', 
borderRadius:30,
justifyContent:'center',
 alignItems:'center',flexDirection:'row'}} >
     <LottieView
        source={require('../../assets/lotties/Animation_Sybol_Login.json')} // Replace with your animation file path
        autoPlay={false} // Set to true for automatic playback
        loop={false} // Set to true for continuous looping
        style={{width:90,height:90}} // Optional styles for the Lottie animation
      />
        <Text style={{ fontSize: 30,fontWeight:'500',width:'20%',textAlign:'center'}}>KOffice</Text>

 </View>
   <View style={{width:'100%', height:'20%', 
   justifyContent:'center',
    alignItems:'center'}}>
      <Text style={{ fontSize: 40,fontWeight:'500',width:'70%',textAlign:'center'}}>To start an efficient working day</Text>
   </View>
   
    <View style={[styles.inputContainer, styles.inputExTabContainer]}>
      <Image style={styles.iconInput} source={require("../../assets/images/icon_login_username.png")} />
      <TextInput
        style={styles.input}
        placeholder="Tên đăng nhập"
        autoCapitalize='none'
        onChangeText={(text) => onChangeTextUserName(text)}
      />
    </View>

    <View style={[styles.inputContainerPassWord, styles.inputExTabContainer]}>
      <Image style={styles.iconInput} source={require("../../assets/images/icon_login_password.png")} />
      <TextInput
        style={styles.input}
        placeholder="Mật khẩu"
        secureTextEntry
        onChangeText={text => onChangeTextPassword(text)}
      />
    </View>
    <View style={styles.containerButtonLogin}>
      <TouchableOpacity style={{backgroundColor:'#a3d95d',justifyContent:'center',alignContent:'center', marginTop:'12%',height:'25%'
    , borderRadius:30}} onPress={handleLogin}>
        <Text style={{alignSelf:'center'}}>Đăng nhập</Text>
      </TouchableOpacity>



    </View>

  </View>
</View>
)}

</View>

  

    {loading &&
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    }
  </View>
  </SafeAreaView>

}