import React, { useCallback, useEffect, useState } from "react";
import { View, StyleSheet, Alert, ImageBackground, TextInput, Image, Text, Pressable, Keyboard } from "react-native";
import { Input, Button } from "react-native-elements";
import { soapAuth } from "../../services/api/soap_service.ts";
import strings from "../../assets/strings.ts";
import { useDispatch, useSelector } from "react-redux";
import {
  loginRequest,
  loginSuccess,
  logout
} from "../../stores/login/actions.ts";
import { getPassword, getUsername, saveModified } from "../../utils/async_storage.ts";
import { getAllData, isNullOrEmpty } from "../../utils/functions.ts";
import { getCurrentUser } from "../../services/api/api_data.ts";
import { isTabletMode } from "../../config/constants.ts";
import { styles } from "./login.style.ts";
import { LoginTabletScreen } from "./loginTablet.tsx";
import { LoginPhoneScreen } from "./loginPhone.tsx";
import { useNavigation } from "@react-navigation/native";



const LoginScreen = () => {
  const dispatch = useDispatch();
  const navigation=useNavigation();
  let [username, setUsername] = useState("");
  let [password, setPassword] = useState("");
  const { loading } = useSelector((state: any) => state.login);

  const relogin = useCallback(async () => {
    if (loading) {
      const user = await getUsername();
      const pass = await getPassword();
      if (!isNullOrEmpty(user) && !isNullOrEmpty(pass)) {
        soapAuth(user!, pass!).then(async isAuth => {
          if (isAuth) {
            const result = await getAllData(true);
            if (result) {
              dispatch(loginSuccess());
              //@ts-ignore
              navigation.navigate("Home");
            }
            else {
              dispatch(logout());
              Alert.alert(strings.AlertTitle, strings.AlertMesSignin);
            }
          } else {
            dispatch(logout());
            Alert.alert(strings.AlertTitle, strings.AlertMesSignin);
          }
        });
      } else {
        dispatch(logout());
      }
    }
  }, [dispatch]);
  useEffect(() => {
    relogin();
  }, [relogin]);
  const handleLogin = () => {
    if (username !== "" && password !== "") {
      dispatch(loginRequest());
      soapAuth(username, password).then(async isAuth => {
        if (isAuth) {
          const result = await getAllData();
          if (result) {
            dispatch(loginSuccess());
            //@ts-ignore
            navigation.navigate("Home");
          }
          else {
            dispatch(logout());
            Alert.alert(strings.AlertTitle, strings.AlertMesSignin);
          }
        } else {
          dispatch(logout());
          Alert.alert(strings.AlertTitle, strings.AlertMesSignin);
        }
      });
    } else {
      dispatch(logout());
      Alert.alert(strings.AlertTitle, strings.AlertMesSignin);
    }
  };
  return (
      <LoginTabletScreen onChangeTextUserName={(text)=>{setUsername(text)}} onChangeTextPassword={(text)=>{setPassword(text)}} handleLogin={handleLogin}/> 
  );
};



export default LoginScreen;
