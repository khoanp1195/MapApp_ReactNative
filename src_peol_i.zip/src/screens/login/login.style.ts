import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
    loginContainer: {
      paddingHorizontal: "3%"
    },
    loginTabContainer: {
      paddingHorizontal: "4%",
    },
    loadingText: {
      color: "#000000",
      fontStyle: "italic"
    },
    loadingContainer: {
      width: "100%",
      backgroundColor: "rgba(255, 255, 255, 0.45)",
      padding: 5,
      alignItems: "center",
      marginBottom: 10
    },
    containerButtonLogin: {
      paddingHorizontal: 10,
      alignSelf:'center',
      width:'60%',
    },
    container: {
      flex: 1
    },
    inputContainer: {
      flexDirection: "row",
      alignItems: "center",
      backgroundColor: "white",
      borderRadius: 20,
      paddingHorizontal: 5,
      margin: 10,
      width:'60%',
      height:'7%',
      marginTop:'8%',
      alignSelf:'center'
    },
    inputContainerPassWord: {
      flexDirection: "row",
      alignItems: "center",
      backgroundColor: "white",
      borderRadius: 20,
      paddingHorizontal: 5,
      margin: 10,
      width:'60%',
      height:'7%',
      marginTop:'2%',
      alignSelf:'center'
    },
    inputExTabContainer:
    {
      borderWidth: 1,
      borderColor: '#E5E5E5'
    },
    input: {
      flex: 1,
      paddingVertical: 10
    },
    iconInput: {
      height: 20,
      width: 20,
      marginRight: 5,
    },
    lottie: {
        flex:1,
        marginLeft:'5%'
    },
  });