import React, { FC } from "react";
import { isTabletMode } from "../config/constants";

interface Props{
    PhoneMode:React.JSX.Element,
    TabletMode:React.JSX.Element,

}


export const PhoneModeScreen:FC<Props>=({PhoneMode,TabletMode})=>
{
    return isTabletMode? TabletMode:PhoneMode
}