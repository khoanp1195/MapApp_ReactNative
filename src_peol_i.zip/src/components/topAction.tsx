import { View } from "react-native"
import { BottomAction } from "./bottomAction"
import { useSelector } from "react-redux";

export const TopAction = () => {
    const lstaction: [] = useSelector((state: any) => state.detailActionTab.lstaction);

    return <View style={{ height: 50, backgroundColor: 'white' }}>
        {
            (lstaction != undefined && lstaction != null && lstaction.length > 0) &&
            <BottomAction data={lstaction} onPressAction={() => { }} />
        }
    </View>
}