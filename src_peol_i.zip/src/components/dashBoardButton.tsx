import { Image, PixelRatio, Pressable, StyleSheet, Text, View } from "react-native";
import { Button } from "react-native-elements";
import { ImageBackground } from "react-native";
import React from "react";

// @ts-ignore
export const DashBoardButton = ({ path, title, countNum, countNumColor, handleClick }) => {

  return (
    <Pressable
      style={styles.container}
      onPress={() => {
        // handle
        if (__DEV__)
          console.log("btn is pressed.");
        handleClick();
      }}>
      <View
        style={{
          flexDirection: "column",
          flex: 1,
          width: "100%"

        }}>

        {/* <View
          style={{
            flexDirection: "row",
            flex: 4,
            alignItems: "center",
            backgroundColor:'yellow'
          }}>

        </View> */}

        <View style={{
          alignSelf: "center",
          flexDirection: 'column'
        }}>
          <Image
            source={path}
            style={styles.square}
            resizeMode='stretch'
          />

          <Text
            style={{
              textAlign: "center",
              fontSize: 15,
              marginTop: 20,
              width:'100%'
            }}>
            {title}
          </Text>

          <Text
            numberOfLines={1}
            style={{
              textAlign: "center",
              fontSize: 35,
              fontWeight: "bold",
              color: countNumColor,
              marginTop:15
            }}>
            {countNum}
          </Text>

        </View>





      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 12,
    margin: 80
  },

  square: {
    width: 50,
    height: 50,
    marginTop: -50,
    alignSelf: 'center',
  }
});
