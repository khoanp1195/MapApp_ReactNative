import React from "react";
import { Image, PixelRatio, Pressable, StyleSheet, Text, View } from "react-native";
import { ImageBackground } from 'react-native';

// @ts-ignore
export const CircleButton = ({ path, title, onClick }) => {

    return (
        <Pressable
            style={styles.container}
            onPress={() => {
                // handle
                // console.log("btn is pressed.")
                onClick()
            }}>
            <Image
                source={path}
                style={[styles.circle]}
                resizeMode="contain"
            />
            {title.trim().length > 0 && <Text style={styles.textStyle}>{title}</Text>}

        </Pressable >
    );
};

const styles = StyleSheet.create({
    container: {
        width:80,
        height:80,
        alignItems: 'center',
        justifyContent: 'center',
        alignSelf: 'center',
    },

    circle: {
        height: '75%',
        aspectRatio: 1,
        alignItems: 'center',
        justifyContent: 'center',
        // marginBottom: 10,
    },

    textStyle: {
        textAlign: 'center',
        fontSize: 15,
        color: '#000000'
    }
});
