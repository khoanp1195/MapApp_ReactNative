import { Pressable, StyleSheet, Text, View } from "react-native"
import moment from 'moment';

// @ts-ignore
export const BtnChooseDate = ({ id, title, onClickHandle, dateText }) => {
    moment.locale('en');

    return (
        <Pressable
            style={[styles.rootContainer]}
            onPress={() => {
                // handle
                // console.log("btn is pressed.")
                onClickHandle()
            }}>
            <View style={[styles.button, { borderRightWidth: (id === 0 ? 1 : 0), borderColor: 'lightgrey' }]}>
                <Text style={[styles.text]} lineBreakMode={'tail'}>{title}</Text>
                <Text style={[styles.date]} lineBreakMode={'tail'}>{moment(dateText).format('DD/MM/YY')}</Text>
            </View>
        </Pressable >
    );
};

const styles = StyleSheet.create({
    rootContainer: {
        flex: 1,
        alignContent: 'center',
        justifyContent: 'center',
    },
    button: {
        flex: 1,
        flexDirection: "column",
        paddingHorizontal: 5,
    },
    text: {
        flex: 1,
        fontSize: 12,
        paddingVertical: 5,
        color: 'grey',
    },
    date: {
        flex: 1,
        fontSize: 15,
        paddingVertical: 5,
    }
});