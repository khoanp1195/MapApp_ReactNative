import React, { FC, useState } from 'react';
import { ActivityIndicator, StyleProp, StyleSheet, View, ViewStyle } from 'react-native';
import FastImage from 'react-native-fast-image';
import { isNullOrEmpty } from "../utils/functions.ts";
import { cookieStore } from "../config/constants.ts";
import { Text } from 'react-native';
import { ErrorTypeImage } from './errorTypeImage.tsx';
import { appMainBlueColor } from '../utils/color.ts';

interface Props {
  onRetryPress?: () => any;
  urlOnline: string;
  priority?: any;
  resizeMode?: any;
  styleImg?: ViewStyle;
  defaultImage: any;
}

export const CustomFastImage: FC<Props> = (props: Props) => {
  const { urlOnline = '', resizeMode, priority, defaultImage, styleImg = {} } = props;
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [imageSource, setImageSource] = useState(
    !isNullOrEmpty(urlOnline)
      ? {
        uri: props.urlOnline,
        priority: priority ? priority : FastImage.priority.normal,
        headers: {
          Cookie: cookieStore.getCookie()
        }
      }
      : defaultImage
  );
  const [inErroCase, setIsInErroCase] = useState<boolean>(false);
  const getURLCorrect = () => {
    if (urlOnline.includes("?")) {
      return urlOnline.split("?")[0];
    }
    else {
      return urlOnline;
    }
  }
  const onError = () => {
    setImageSource(defaultImage);
    setIsInErroCase(true);
  };
  return (!inErroCase ?
    <FastImage
      onError={onError}
      //@ts-ignore
      style={styleImg}//styles.container,
      source={imageSource}
      defaultSource={defaultImage}
      resizeMode={resizeMode ? resizeMode : FastImage.resizeMode.contain}
    />
    :
    <ErrorTypeImage url={getURLCorrect()} styleImg={styleImg} />
  );
};

const styles = StyleSheet.create({
  container: {
    height: 40,
    width: 40,
    marginRight: 10,
    borderRadius: 20,
    
  },
});

