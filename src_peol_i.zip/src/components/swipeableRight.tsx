// @ts-ignore
import { Pressable, Text, View } from "react-native";
import { Swipeable } from "react-native-gesture-handler";
import React from "react";

// @ts-ignore
export const SwipeableRight=({children, rightActions=<View/>,onPressRightAction=()=>{}})=>{
  const renderLeftActions = () => {
    // You can customize the left content here
    return (
      <Pressable  onPress={()=>onPressRightAction()}>
        {rightActions}
      </Pressable>
    );
  };
  return <Swipeable renderRightActions={renderLeftActions}>
    {children}
  </Swipeable>
}
