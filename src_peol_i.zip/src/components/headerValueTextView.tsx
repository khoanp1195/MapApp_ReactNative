import { FC } from "react";
import { Text } from "react-native";
import { View } from "react-native";

interface Props{
    headerText:string;
    valueText:string;
}
export const HeaderValueTextView:FC<Props>=({headerText,valueText})=>{
    return <View style={{marginBottom:10}}>
        <Text style={{fontSize:15,color:'#5e5e5e'}}>{headerText}</Text>
        <Text style={{fontSize:15,color:'black'}}>{valueText}</Text>
    </View>
}