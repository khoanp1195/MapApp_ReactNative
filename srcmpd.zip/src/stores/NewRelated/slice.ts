import { createSlice, PayloadAction } from '@reduxjs/toolkit';

import * as TYPE from './type';

export interface InitialState {
	procedure: TYPE.IProcedureType[];
	isGettingProcedure: boolean;
	listSheet: TYPE.IListSheetType[];
}
const initialState: InitialState = {
	procedure: [],
	isGettingProcedure: false,
	listSheet: [],
};

export const newRelatedSlice = createSlice({
	name: 'newRelated',
	initialState,
	reducers: {
		setIsGettingProcedure: (state, action) => {
			state.isGettingProcedure = action.payload;
		},
		setProcedure: (state, action) => {
			state.procedure = action.payload;
		},
		setListSheet: (state, action) => {
			state.listSheet = action.payload;
		},
		getProcedure: (state, action: PayloadAction<TYPE.IGetProcedurePayloadType>) => {},
		getListSheet: (state, action: PayloadAction<TYPE.ISheetListPayloadType>) => {},
	},
});

export default newRelatedSlice.reducer;
export const newRelatedReducerKey = newRelatedSlice.name;
export const newRelatedReducerActions = newRelatedSlice.actions;

export const { getProcedure, getListSheet } = newRelatedSlice.actions;
