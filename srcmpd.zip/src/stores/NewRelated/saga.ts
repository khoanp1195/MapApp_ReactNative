import { GET, ENDPOINT } from 'http/modules';

import { PayloadAction } from '@reduxjs/toolkit';
import { ShowLoading } from 'components/Atoms/Loading/LoadingGlobal';
import { call, takeLatest, put } from 'redux-saga/effects';

import { getProcedure, newRelatedReducerActions, getListSheet } from './slice';
import * as TYPE from './type';

export function* getProcedureData(action: PayloadAction<TYPE.IGetProcedurePayloadType>) {
	try {
		const res = yield call(GET, ENDPOINT.WORKFLOW, action.payload);

		const keyword = JSON.parse(action.payload.data);

		if (res) {
			const { data } = res.data;

			if (keyword.Keyword.length === 0) {
				const all = {
					ID: 0,
					WorkflowID: 0,
					Title: 'Tất cả',
					TitleEN: 'All',
					Description: null,
					ImageURL: '',
					IsFavor: 0,
					WorkflowCategory: '',
					WorkflowCategoryID: 41,
				};
				const arr = data.unshift(all);
				console.log(arr);
				yield put(newRelatedReducerActions.setProcedure(data));
			} else {
				yield put(newRelatedReducerActions.setProcedure(data));
			}
		}
	} catch (error) {
		console.log('error', error);
	}
}

export function* getSheetList(action: PayloadAction<TYPE.IGetProcedurePayloadType>) {
	try {
		ShowLoading(true);

		const res = yield call(GET, ENDPOINT.WORKFLOW, action.payload);

		if (res) {
			const { data } = res.data;

			yield put(newRelatedReducerActions.setListSheet(data));

			ShowLoading(false);
		}
	} catch (error) {
		console.log('error', error);
	}
}

// the 'watcher' - on every 'API_BUTTON_CLICK' action, run our side effect
export function* NewRelatedSaga() {
	yield takeLatest(getProcedure.type, getProcedureData);
	yield takeLatest(getListSheet.type, getSheetList);
}
