export interface IProcedureType {
	ID: number;
	WorkflowID: number;
	Title: string;
	TitleEN: string;
	Description: null;
	ImageURL: string;
	IsFavor: number;
	WorkflowCategory: string;
	WorkflowCategoryID: number;
}
export interface IGetProcedurePayloadType {
	func: string;
	data: string;
	flag: number;
	limit: number;
	offset: number;
	lid: number;
}

export interface ISheetListPayloadType {
	func: string;
	resourcetype: string;
	data: string;
	flag: number;
	limit: number;
	offset: number;
	lid: number;
	totalrecord: number;
}
export interface IListSheetType {
	ID: number;
	ListID: string;
	SPItemId: number;
	Content: string;
	WorkflowId: number;
	AssignedTo: string;
	AssignedToInfo: string;
	Created: string;
	StatusGroup: number;
	ApprovalStatus: number;
	Flag: number;
	TotalRecord: number;
}
