export interface ITask {
	data: {
		ListChildren: [];
		FormConfig: {
			IsAssignedTo: true;
			IsAuthor: true;
			IsCompleted: false;
			IsHold: false;
			NumChildrenCount: 0;
		};
		ItemInfo: {
			ID: 10588;
			SPItemId: 10475;
			Title: 'createTask bằng API update thông tin từ API';
			ListAssignedTo: '24A8ECDF-A20E-4C15-AE9F-DFA1429D3E04';
			AssignedTo: '24A8ECDF-A20E-4C15-AE9F-DFA1429D3E04;#qc.admin4@vuthao.vn';
			Content: 'Nội dung công việc được tạo từ API update thông tin từ API';
			StatusGroup: 2;
			DueDate: '2023-06-06T16:22:00';
			AssignedBy: '24a8ecdf-a20e-4c15-ae9f-dfa1429d3e04';
			AssignedByName: 'qc.admin4@vuthao.vn';
		};
		ListAttchment: [];
		ListComment: [];
	};
}

export interface IGetTaskPayloadType {
	func: string;
	lid: number;
	rid: number;
	spitemid: number;
}

export interface IUpdateTaskPayloadType {
	params: { lid: number; func: string };
	formData: FormData;
}
