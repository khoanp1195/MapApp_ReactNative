/* eslint-disable @typescript-eslint/no-unused-vars */
import { createSlice, PayloadAction } from '@reduxjs/toolkit';

import * as TYPE from './type';

export interface InitialState {
	isGettingTask: boolean;
	taskData: any;
	isUpdatingTask: boolean;
}
const initialState: InitialState = {
	isGettingTask: false,
	taskData: null,
	isUpdatingTask: false,
};

interface ICBPayLoad {
	params?: any;
	success?: () => void;
	failed?: () => void;
}

export const taskSlice = createSlice({
	name: 'task',
	initialState,
	reducers: {
		setIsGettingTask: (state, action) => {
			state.isGettingTask = action.payload;
		},
		setTaskData: (state, action) => {
			state.taskData = action.payload;
		},
		getTask: (state, action: PayloadAction<TYPE.IGetTaskPayloadType>) => {},
		updateTask: (state, action: PayloadAction<TYPE.IUpdateTaskPayloadType>) => {},
		createTask: (state, action: PayloadAction<ICBPayLoad>) => {},
		completeTask: (state, action: PayloadAction<TYPE.IGetTaskPayloadType>) => {},
	},
});

export default taskSlice.reducer;
export const taskReducerKey = taskSlice.name;
export const taskReducerActions = taskSlice.actions;

export const { getTask, updateTask, createTask, completeTask } = taskSlice.actions;
