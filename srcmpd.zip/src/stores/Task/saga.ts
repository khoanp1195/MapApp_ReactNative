import { GET, ENDPOINT, POST } from 'http/modules';

import { PayloadAction } from '@reduxjs/toolkit';
import { ShowLoading } from 'components/Atoms/Loading/LoadingGlobal';
import { call, put, takeEvery, takeLatest } from 'redux-saga/effects';
import { updateAtatchmentTasks } from 'stores/TaskDetails';
import { ActionType, ConvertResponse } from 'stores/TaskDetails/saga';

import { completeTask, createTask, getTask, taskReducerActions, updateTask } from './slice';
import * as TYPE from './type';

export function* getTaskData(action: PayloadAction<TYPE.IGetTaskPayloadType>) {
	try {
		ShowLoading(true);
		const res = yield call(GET, ENDPOINT.TASK, action.payload);
		if (res) {
			const { data } = res.data;
			yield put(taskReducerActions.setTaskData(data));
			yield put(updateAtatchmentTasks(res.data?.data?.ListAttchment));
			ShowLoading(false);
		}
	} catch (error) {
		console.log('error', error);
	}
}

export function* updateDataTask(action: PayloadAction<TYPE.IUpdateTaskPayloadType>) {
	try {
		const res = yield call(POST, ENDPOINT.TASK, action.payload.params, action.payload.formData);

		console.log(action.payload.formData);

		if (res) {
			const { data } = res.data;
			yield action.payload?.success();
		}
	} catch (error) {
		console.log('error', error);
	}
}
interface ICreateTask {
	attachments: string;
	itemInfo: string;
	lid: number;
	rid: number;
}

function* funcCreateTask(action: ActionType<ICreateTask>): Generator {
	try {
		const formData = new FormData();
		formData.append('attachment', action.payload.params.attachments);
		formData.append('itemInfo', action.payload.params.itemInfo);

		const body = {
			func: 'createTask',
			lid: action.payload.params.lid,
		};

		const response = yield call(POST, ENDPOINT.TASK, body, formData);

		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
			yield action.payload.success(responseData);
		}
	} catch (error) {
		// TODO
	}
}

function* funcCompleteTask(action: ActionType<ICreateTask>): Generator {
	try {
		const body = {
			func: 'completeTask',
			lid: action.payload.params.lid,
			rid: action.payload.params.rid,
		};

		const response = yield call(POST, ENDPOINT.TASK, body);

		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
			yield action.payload.success(responseData);
		}
	} catch (error) {
		// TODO
	}
}

// the 'watcher' - on every 'API_BUTTON_CLICK' action, run our side effect
export function* TaskTestSaga() {
	yield takeLatest(getTask.type, getTaskData);
	yield takeLatest(updateTask.type, updateDataTask);
	yield takeLatest(createTask.type, funcCreateTask);
	yield takeLatest(completeTask.type, funcCompleteTask);
}
