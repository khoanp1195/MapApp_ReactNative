import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export interface State {
	isTurnOnFilterMyTaskInProcess?: boolean;
	isTurnOnFilterMyTaskCompleted?: boolean;
}

const initialState: State = {
	isTurnOnFilterMyTaskInProcess: false,
	isTurnOnFilterMyTaskCompleted: false,
};

export const myTaskSlice = createSlice({
	name: 'myTask',
	initialState,
	reducers: {
		updateTurnOnFilterMyTaskInProcess: (state, action: PayloadAction<boolean>) => {
			state.isTurnOnFilterMyTaskInProcess = action.payload;
		},
		updateTurnOnFilterMyTaskCompleted: (state, action: PayloadAction<boolean>) => {
			state.isTurnOnFilterMyTaskCompleted = action.payload;
		},
	},
	extraReducers: () => {},
});

export const { updateTurnOnFilterMyTaskInProcess, updateTurnOnFilterMyTaskCompleted } = myTaskSlice.actions;
