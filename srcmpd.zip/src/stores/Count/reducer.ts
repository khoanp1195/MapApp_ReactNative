import { createSlice } from '@reduxjs/toolkit';
import { ICount } from 'services/Counts/types';

import { fetchCount } from './thunks';

interface CountState {
	loading: boolean;
	count?: ICount;
}

const initialState: CountState = {
	loading: false,
	count: undefined,
};

export const countSlice = createSlice({
	name: 'count',
	initialState,
	reducers: {},
	extraReducers: builder => {
		builder.addCase(fetchCount.pending, state => {
			state.loading = true;
		});
		builder.addCase(fetchCount.fulfilled, (state, action) => {
			state.loading = false;
			state.count = { ...(state.count || {}), ...(action.payload?.[0] || {}) };
		});
		builder.addCase(fetchCount.rejected, state => {
			state.loading = false;
		});
	},
});
