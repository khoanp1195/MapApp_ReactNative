import { createAsyncThunk } from '@reduxjs/toolkit';
import { apiCount } from 'services/Counts';

export const fetchCount = createAsyncThunk(
	'count/fetchCount',
	async (params: { countType?: number; WorkflowId?: number } | undefined) => {
		const { countType = 2044, WorkflowId = 0 } = params || {};
		const res = await apiCount({ countType, WorkflowId });
		if (!res) throw new Error('Error!!!');
		return res.data.data;
	},
);

// Home: 4 8 16 32 512 64 128 256 1024 = 2044
// Den toi:   8 16 32 512 = 568
// Toi bat dau: 64 128 256 1024 = 1472
