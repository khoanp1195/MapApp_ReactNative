import { fork, all } from 'redux-saga/effects';

import { watcherAppsSaga } from './Apps/sagaApps';
import { watcherHomeSaga } from './Home/saga';
import { NewRelatedSaga } from './NewRelated/saga';
import { watcherSystemSaga } from './System/saga';
import { TaskTestSaga } from './Task/saga';
import { TaskSaga } from './TaskDetails/saga';
import { watcherWorkflowSaga } from './Workflows/sagaWorkflow';

export default function* rootSaga() {
	yield all([
		fork(TaskSaga),
		fork(TaskTestSaga),
		fork(NewRelatedSaga),
		fork(watcherSystemSaga),
		fork(watcherHomeSaga),
		fork(watcherWorkflowSaga),
		fork(watcherAppsSaga),
	]);
}
