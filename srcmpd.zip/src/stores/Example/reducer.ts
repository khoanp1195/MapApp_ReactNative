import { createSlice } from '@reduxjs/toolkit';

interface ExampleState {
	example: boolean;
}

const initialState: ExampleState = {
	example: false,
};

export const exampleSlice = createSlice({
	name: 'example',
	initialState,
	reducers: {},
	extraReducers: () => {},
});

// export const {  } = authSlice.actions;
