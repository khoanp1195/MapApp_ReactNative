/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { ENDPOINT, GET, POST } from 'http/modules';

import { call, put, takeEvery, takeLatest } from 'redux-saga/effects';
import { ConvertResponse } from 'stores';
import { deleteAttachment } from 'stores/TaskDetails';
import { ActionType } from 'stores/types';

import {
	getAttachmentWorkflow,
	getAttachmentWorkflowSuccess,
	getDetailsWorkflow,
	getDetailsWorkflowSuccess,
	getFormWorkFlowSuccess,
	getFormWorkFlow,
	postActionWorkflow,
	editAttachment,
	updateAttachments,
	postShareWorkflow,
	getHistoryShare,
	postFollowWorkflow,
	getWokflowHistory,
	getListLookup,
	getListLookupSQL,
	setInit,
	postComment,
	getComment,
	updateComment,
	postLikeComment,
	postDeleteWorkflowRelated,
	getDetailsNewWorkflow,
	getFormGirdDetails,
	getLineManagerUserSQL,
} from './sliceWorkflow';
import { IParamsActionWorkflow, IParamsDetailsWorkFlow, IParamsFormWorkFlow } from './types';

function* funcGetFormWorkFlow(action: ActionType<IParamsFormWorkFlow>): Generator {
	try {
		const { params } = action.payload;
		const body = {
			func: 'getFormTemplate',
			mode: 2,
			// rid: params.rid,
			listid: params.listid,
			wid: params.wid,
			lid: params?.lid,
			flag: params?.flag || 0,
			modified: params?.modified,
		};

		const response = yield call(GET, `${ENDPOINT.WORKFLOWREQUEST}`, body);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
			yield put(getFormWorkFlowSuccess({ ...responseData.data, rid: action.payload.params.rid }));
			yield action.payload?.success(responseData);
		} else {
			yield action.payload?.failed(responseData);
			// TODO: error handling
		}
	} catch (error) {
		yield action.payload?.failed(error);
		//
	}
}

function* funcGetDetailsWorkflow(action: ActionType<IParamsDetailsWorkFlow>): Generator {
	try {
		const body = {
			func: 'getFormData',
			rid: action.payload.params?.rid,
			lid: action.payload.params?.lid,
		};

		const response = yield call(GET, `${ENDPOINT.WORKFLOWREQUEST}`, body);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
			yield put(getDetailsWorkflowSuccess(responseData.data));
			yield put(setInit(true));
			yield action.payload?.success(responseData);
		} else {
			// Handle unexpected response structure
			yield action.payload?.failed(responseData);
		}
	} catch (error) {
		yield action.payload?.failed(error);
	}
}

function* funcGetAttachmentWorkflow(action: ActionType<IParamsDetailsWorkFlow>): Generator {
	try {
		const body = {
			func: 'getAttachments',
			rid: action.payload.params?.rid,
		};

		const response = yield call(GET, `${ENDPOINT.WORKFLOWREQUEST}`, body);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
			yield put(getAttachmentWorkflowSuccess(responseData.data?.data?.fileInfoCollections));
		} else {
			// Handle unexpected response structure
		}
		yield action.payload?.success(responseData);
	} catch (error) {
		// Handle error
	}
}

function* funcPostActionWorkflow(action: ActionType<IParamsActionWorkflow>): Generator {
	try {
		const { params } = action.payload;

		const formdata = new FormData();
		formdata.append('itemInfo', params?.itemInfo ? JSON.stringify(params?.itemInfo || '') : '');
		formdata.append('idea', params?.idea || '');
		formdata.append('attachment', JSON.stringify(params?.attachment) || '');
		formdata.append('workflowrelated', JSON.stringify(params?.workflowrelated));

		const body = {
			func: params?.func,
			rid: params.rid,
			lid: params?.lid,
			usergroupvalues: params?.usergroupvalues || null,
			SSN: 'workflow',
			listid: params?.ListId,
			relatedListID: params?.relatedListID || '',
			itemRLID: params?.itemRLID || '',
		};

		const response = yield call(POST, `${ENDPOINT.WORKFLOWREQUEST}`, body, formdata);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
			yield action.payload?.success(responseData);
			// yield put(getDetailsWorkflowSuccess(responseData.data));
		} else {
			yield action.payload?.success(responseData);
			// Handle unexpected response structure
		}
	} catch (error) {
		yield action.payload?.failed(error);

		// Handle error
	}
}

function* funcDeleteAttachment(action: ActionType<IParamsActionWorkflow>): Generator {
	try {
		const { params } = action.payload;

		const body = {
			func: 'deleteAttachments',
			rid: params.rid,
			data: JSON.stringify(params.data),
		};

		const response = yield call(POST, `${ENDPOINT.WORKFLOWREQUEST}`, body);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
			// yield put(getDetailsWorkflowSuccess(responseData.data));
		} else {
			// Handle unexpected response structure
		}
		yield action.payload?.success(responseData);
	} catch (error) {
		// Handle error
	}
}

function* funcEditAttachment(action: ActionType<IParamsActionWorkflow>): Generator {
	try {
		const { params } = action.payload;

		const body = {
			func: 'updateAttachments',
			rid: params.rid,
			data: JSON.stringify(params.data),
		};

		const response = yield call(POST, `${ENDPOINT.WORKFLOWREQUEST}`, body);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
			// yield put(getDetailsWorkflowSuccess(responseData.data));
			yield put(
				updateAttachments({
					func: 'edit',
					item: params.data,
				}),
			);
		} else {
			// Handle unexpected response structure
		}
		yield action.payload?.success(responseData);
	} catch (error) {
		// Handle error
	}
}

function* funcPostShareWorkflow(action: ActionType<IParamsActionWorkflow>): Generator {
	try {
		const { params } = action.payload;

		const body = {
			func: 'SHARE',
			rid: params.rid,
			lid: params?.lid,
			usergroupvalues: params?.usergroupvalues || null,
			SSN: 'workflow',
			idea: params.idea || '',
		};

		const response = yield call(POST, `${ENDPOINT.WORKFLOWREQUEST}`, body);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
			// yield put(getDetailsWorkflowSuccess(responseData.data));
		} else {
			// Handle unexpected response structure
		}
		yield action.payload?.success(responseData);
	} catch (error) {
		// Handle error
	}
}

function* funcGetHistoryShare(action: ActionType<IParamsActionWorkflow>): Generator {
	try {
		const { params } = action.payload;

		const body = {
			func: 'getShareHistory',
			rid: params.rid,
			lid: params?.lid,
			SSN: 'workflow',
		};

		const response = yield call(GET, `${ENDPOINT.WORKFLOWREQUEST}`, body);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
			// yield put(getDetailsWorkflowSuccess(responseData.data));
		} else {
			// Handle unexpected response structure
		}
		yield action.payload?.success(responseData);
	} catch (error) {
		// Handle error
	}
}

function* funcPostFollowWorkflow(action: ActionType<IParamsActionWorkflow>): Generator {
	try {
		const { params } = action.payload;

		const body = {
			func: 'FOLLOW',
			rid: params.rid,
			lid: params?.lid,
			SSN: 'workflow',
			flag: params.flag,
		};

		const response = yield call(POST, `${ENDPOINT.WORKFLOWREQUEST}`, body);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
			// yield put(getDetailsWorkflowSuccess(responseData.data));
		} else {
			// Handle unexpected response structure
		}
		yield action.payload?.success(responseData);
	} catch (error) {
		// Handle error
	}
}

function* funcGetWokflowHistory(action: ActionType<IParamsActionWorkflow>): Generator {
	try {
		const { params } = action.payload;

		const body = {
			func: 'getHistory',
			rid: params.rid,
			lid: params.lid,
		};

		const response = yield call(GET, `${ENDPOINT.WORKFLOWREQUEST}`, body);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
			// yield put(getDetailsWorkflowSuccess(responseData.data));
		} else {
			// Handle unexpected response structure
		}
		yield action.payload?.success(responseData);
	} catch (error) {
		// Handle error
	}
}

function* funcGetListLookup(action: ActionType<IParamsActionWorkflow>): Generator {
	try {
		const { params } = action.payload;

		const body = {
			func: 'getLookupDataSource',
			keyword: params.keyword,
			FormFieldOption: params.options,
			PagingInfo: params.PagingInfo,
			limit: 10,
		};

		const response = yield call(GET, `${ENDPOINT.WORKFLOWREQUEST}`, body);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
			// yield put(getListLookupSuccess(responseData));
		} else {
			// Handle unexpected response structure
		}
		yield action.payload?.success(responseData);
	} catch (error) {
		// Handle error
	}
}

function* funcGetListLookupSQL(action: ActionType<IParamsActionWorkflow>): Generator {
	try {
		const { params } = action.payload;

		const form = new FormData();
		form.append('FormFieldOption', params.options);

		const body = {
			func: 'getLookupDataSourceSQL',
			keyword: params.keyword,
			limit: 10,
			offset: params?.offset || 0,
		};

		const response = yield call(POST, `${ENDPOINT.WORKFLOWREQUEST}`, body, form);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
			// yield put(getListLookupSuccess(responseData));
		} else {
			// Handle unexpected response structure
		}
		yield action.payload?.success(responseData);
	} catch (error) {
		// Handle error
	}
}

function* funcPostComment(action: ActionType<IParamsActionWorkflow>): Generator {
	try {
		const { params } = action.payload;

		const data = {
			OtherResourceId: params.OtherResourceId || '',
			ParentCommentId: params.ParentCommentId || '',
			Resourcecategoryid: !params?.isWorkflow ? 16 : 8, // cv : 16
			Resourcesubcategoryid: !params?.isWorkflow ? 0 : 9, // cv : 0
			Content: params.Content,
		};

		const formdata = new FormData();
		formdata.append('data', JSON.stringify(data));
		formdata.append('Files', params?.Files?.length ? JSON.stringify(params?.Files) : '');

		const body = {
			func: 'ADDCOMMENT',
			rid: params.rid,
		};

		const response = yield call(POST, `${ENDPOINT.SOCIAL}`, body, formdata);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
			// yield put(getListLookupSuccess(responseData));
		} else {
			// Handle unexpected response structure
		}
		yield action.payload?.success(responseData);
	} catch (error) {
		// Handle error
	}
}

function* funcGetComment(action: ActionType<IParamsActionWorkflow>): Generator {
	try {
		const { params } = action.payload;

		const body = {
			func: 'getCommentByOtherResourceId',
			rid: params.rid,
			lid: params?.lid,
			otherresourceid: params.OtherResourceId,
			resourcecategoryid: !params?.isWorkflow ? 16 : 8, // cv : 16
			resourcesubcategoryid: !params?.isWorkflow ? 0 : 9, // cv : 0
		};

		const response = yield call(GET, `${ENDPOINT.SOCIAL}`, body);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
			yield put(updateComment({ func: 'recall', comment: responseData.data }));
		} else {
			// Handle unexpected response structure
		}
		yield action.payload?.success(responseData);
	} catch (error) {
		// Handle error
	}
}

function* funcPostLikeComment(action: ActionType<IParamsActionWorkflow>): Generator {
	try {
		const { params } = action.payload;

		const body = {
			func: params.action,
			rid: params.rid,
			lid: params?.lid,
			commentid: params.commentid,
			resourcecategoryid: !params?.isWorkflow ? 16 : 8, // cv : 16
			resourcesubcategoryid: !params?.isWorkflow ? 0 : 9, // cv : 0
		};

		const response = yield call(POST, `${ENDPOINT.SOCIAL}`, body);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
		} else {
			// Handle unexpected response structure
		}
		yield action.payload?.success(responseData);
	} catch (error) {
		// Handle error
	}
}

function* funcPostDeleteWorkflowRelated(action: ActionType<IParamsActionWorkflow>): Generator {
	try {
		const { params } = action.payload;

		const body = {
			func: 'deleteWorkflowRelatedByID',
			lid: params?.lid,
			workflowrelatedid: params.workflowrelatedid,
		};

		const response = yield call(POST, `${ENDPOINT.WORKFLOWREQUEST}`, body);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
		} else {
			// Handle unexpected response structure
		}
		yield action.payload?.success(responseData);
	} catch (error) {
		// Handle error
	}
}

function* funcGetDetailsNewWorkflow(action: ActionType<IParamsDetailsWorkFlow>): Generator {
	try {
		const body = {
			func: 'getNewFormData',
			// rid: action.payload.params?.rid,
			listid: action.payload.params?.listId,
			relatedListID: action.payload.params?.relatedListID || '',
			itemRLID: action.payload.params?.itemRLID || '',
			lid: action.payload.params?.lid,
		};

		const response = yield call(GET, `${ENDPOINT.WORKFLOWREQUEST}`, body);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
			yield put(getDetailsWorkflowSuccess(responseData.data));
			yield put(setInit(true));
		} else {
			// Handle unexpected response structure
		}
		yield action.payload?.success(responseData);
	} catch (error) {
		// Handle error
	}
}

function* funcGetFormGirdDetails(action: ActionType<IParamsDetailsWorkFlow>): Generator {
	try {
		const body = {
			func: 'getFormTemplate',
			listid: action.payload.params?.listid,
			lid: action.payload.params?.lid,
			mode: 2,
			flag: action.payload.params?.flag || 0,
			modified: action.payload.params?.modified,
			wid: action.payload.params?.wid || 0,
			rid: action.payload.params?.rid,
		};

		const form = new FormData();
		form.append('detailsListInfo', JSON.stringify(action.payload.params?.detailsListInfo));
		form.append('detailsFieldInfoCollection', JSON.stringify(action.payload.params?.detailsFieldInfoCollection));

		const response = yield call(POST, `${ENDPOINT.WORKFLOWREQUEST}`, body, form);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
		} else {
			// Handle unexpected response structure
		}
		yield action.payload?.success(responseData);
	} catch (error) {
		// Handle error
	}
}

function* funcGetLineManagerUserSQL(action: ActionType<IParamsDetailsWorkFlow>): Generator {
	try {
		const body = {
			func: 'GetLineManagerUserSQL',
			getInGroup: true,
			Delimiter: ',',
			data: action.payload.params?.Delimiter || '',
		};

		const response = yield call(GET, '/qc/_layouts/15/VuThao.BPMOP.API/ApiUser.ashx', body);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
		} else {
			// Handle unexpected response structure
		}
		yield action.payload?.success(responseData);
	} catch (error) {
		// Handle error
	}
}

export function* watcherWorkflowSaga() {
	yield takeLatest(getFormWorkFlow.type, funcGetFormWorkFlow);
	yield takeLatest(getDetailsWorkflow.type, funcGetDetailsWorkflow);
	yield takeLatest(getAttachmentWorkflow.type, funcGetAttachmentWorkflow);
	yield takeLatest(postActionWorkflow.type, funcPostActionWorkflow);
	yield takeLatest(deleteAttachment.type, funcDeleteAttachment);
	yield takeLatest(editAttachment.type, funcEditAttachment);
	yield takeLatest(postShareWorkflow.type, funcPostShareWorkflow);
	yield takeLatest(getHistoryShare.type, funcGetHistoryShare);
	yield takeLatest(postFollowWorkflow.type, funcPostFollowWorkflow);
	yield takeLatest(getWokflowHistory.type, funcGetWokflowHistory);
	yield takeLatest(getListLookup.type, funcGetListLookup);
	yield takeLatest(getListLookupSQL.type, funcGetListLookupSQL);
	yield takeLatest(postComment.type, funcPostComment);
	yield takeLatest(getComment.type, funcGetComment);
	yield takeLatest(postLikeComment.type, funcPostLikeComment);
	yield takeLatest(postDeleteWorkflowRelated.type, funcPostDeleteWorkflowRelated);
	yield takeLatest(postDeleteWorkflowRelated.type, funcPostDeleteWorkflowRelated);
	yield takeLatest(getDetailsNewWorkflow.type, funcGetDetailsNewWorkflow);
	yield takeEvery(getFormGirdDetails.type, funcGetFormGirdDetails);
	yield takeLatest(getLineManagerUserSQL.type, funcGetLineManagerUserSQL);
}
