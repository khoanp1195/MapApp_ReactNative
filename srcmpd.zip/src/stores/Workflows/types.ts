export interface IWorkflowState {
	attachmets: IAttachments[];
	itemInfo: IItemInfo;
	isFollow: number;
	related: IRelated[];
	details: IDetails;
	forms: any;
	assignTask: any[];
	listFieldNameHides: any[];
	init: boolean;
	comments: IComment[];
	Content: string;
	dateMonth: any;
}

export interface ParamsUpdateAttachments {
	func: string;
	idLocal: string;
	item: { ID: number };
}
export interface ParamsDetailsWorkflow {
	ItemInfo: any;
	Attachments: any[];
	WorkflowRelated: any[];
	ListTask: any[];
	ListComment: IComment[];
}

export interface IParamsFormWorkFlow {
	rid: number;
	listid: number;
	wid: number;
	flag: number;
	modified: string;
	lid: number;
}

export interface IParamsDetailsWorkFlow {
	rid: number;
	lid: number;
}

export interface IParamsActionWorkflow {
	itemInfo: any;
	attachment: any;
	workflowrelated: any;
	func: string;
	usergroupvalues: string;
	idea: string;
	rid: number;
	data?: any;
	flag?: number;
	lid?: number;
	relatedListID?: string;
	itemRLID?: number;
	ListId?: string;
}

export interface IRelated {
	ID: number;
	Title: string;
	Content: string;
	Created: string;
	CreatedBy: string;
	StatusGroup: number;
	ImagePath: string;
	DefaultImagePath: string;
	Workflow: string;
	WorkflowId: number;
	ListID: string;
	WorkflowRelatedId: number;
	AssignedToInfo?: string;
}

export interface IDetails {
	FormConfig?: FormConfig;
	ItemInfo?: IItemInfo;
	Attachments?: any[];
	WorkflowRelated?: WorkflowRelated[];
	ListTask?: any[];
	ListComment?: IComment[];
}

export interface FormConfig {
	ID: number;
	IsCompleted: boolean;
	WorkflowID: number;
	SPItemId: number;
	ResourceVersionId: number;
	Step: number;
	ListId: string;
	Roles: number;
	Permission: number;
	IsAdmin: boolean;
	IsCreatedByMe: boolean;
	IsFollowed: boolean;
	HubPackageId: any;
	AllowRelatedEdit: boolean;
	DocStatus: number;
	StatusGroup: number;
	StatusDetailName: string;
	IsAllowRecall: boolean;
	IsAddinfoUser: number;
	IsIdeaByUser: number;
	IsShowApproveAction: boolean;
	MaxStepOffWorkflow: number;
	DocStep: number;
	AssignmentRule: any;
	AllMemApproved: string;
	CountMemApproveNotYet: number;
	CountNotify: number;
	CountUserApproveNotYetAfterCurrentCompleted: number;
	ListDocumentCategory: string;
	DefindJsonObj: string;
	JQFormFieldUse: string;
	ListButtonAction: string;
	Flag: number;
	OtherResourceId: string;
	NotifiedUsersInfo: any;
	NotifiedUsers: string;
	IsWaitSignature: boolean;
	AssignedToInfo: string;
	Content: string;
	WorkflowTitle?: string;
}

export interface IItemInfo {
	[key: string]: string | any[] | null | number;
	_ID_?: number;
}

export interface WorkflowRelated {
	ID: number;
	Title: string;
	Content: string;
	Created: string;
	CreatedBy: string;
	StatusGroup: number;
	ImagePath: string;
	DefaultImagePath: string;
	Workflow: string;
	WorkflowId: number;
	ListID: string;
	WorkflowRelatedId: number;
}

export interface IAttachments {
	ID: string;
	Title: string;
	Name: string;
	AttachTypeId: number;
	Extension: string;
	Size: number;
	Path: string;
	CreatedName: string;
	PositionName: string;
	AttachTypeName: string;
	IsAuthor: number;
	Base64?: string;
	isAdd?: boolean;
	Created?: Date;
	idLocal?: string;
	uri?: string;
	size?: number | undefined;
	fileSize?: number | undefined;
}

export interface IComment {
	ID: string;
	CID: number;
	Content: string;
	Image: string;
	ResourceId: string;
	ResourceCategoryId: number;
	ResourceSubCategoryId: number;
	LikeCount: number;
	CommentCount: number;
	ParentCommentId: any;
	Created: string;
	IsLiked: number;
	Name: string;
	ImagePath: string;
	DefaultImagePath: string;
	PositionName: string;
	children?: any[];
}
