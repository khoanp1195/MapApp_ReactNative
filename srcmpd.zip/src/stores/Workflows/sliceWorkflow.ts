/* eslint-disable @typescript-eslint/no-unused-vars */
import { PayloadAction, createSlice } from '@reduxjs/toolkit';

import { IWorkflowState, ParamsUpdateAttachments, ParamsDetailsWorkflow } from './types';

const initialState: IWorkflowState = {
	forms: {},
	details: {},
	itemInfo: {},
	itemInfoField: {},
	attachmets: [],
	assignTask: [],
	related: [],
	comments: [],
	lookup: [],
	pageLookup: '0',
	Guid: '',
	listFieldNameHides: [],
	userGroup: [],
	IsFollowed: false,
	init: false,
	dateMonth: {
		name: '',
		value: '',
	},
};

export const workflowsSlice = createSlice({
	name: 'workflows',
	initialState,
	reducers: {
		// Form
		getFormWorkFlow(_state, _action) {},
		getFormWorkFlowSuccess(state, action) {
			state.forms = action.payload;
		},
		// Details
		getDetailsWorkflow(_state, _action) {},
		getDetailsWorkflowSuccess(state, action: PayloadAction<ParamsDetailsWorkflow>) {
			state.details = action.payload;
			state.itemInfo = action.payload.ItemInfo || {};
			state.attachmets = action.payload?.Attachments || [];
			state.related = action.payload?.WorkflowRelated || [];
			state.assignTask = action.payload?.ListTask || [];
			state.comments = action.payload?.ListComment || [];
		},
		// Details Add New
		getDetailsNewWorkflow(_state, _action) {},
		// Related
		updateRelated(state, action) {
			if (action.payload?.func === 'add') {
				state.related = [...state.related, ...action.payload?.item];
			}
			if (action.payload?.func === 'delete') {
				state.related = state.related.filter(item => item.ID !== action.payload?.item?.ID);
			}
		},
		postDeleteWorkflowRelated(_state, _action) {},
		// Attachment
		getAttachmentWorkflow(_state, _action) {},
		getAttachmentWorkflowSuccess(state, action) {
			state.attachmets = action.payload;
		},
		editAttachment(_state, _action) {},
		deteleAttachment(_state, _action) {},
		updateAttachments(state, action: PayloadAction<ParamsUpdateAttachments>) {
			if (action.payload?.func === 'delete') {
				state.attachmets = state.attachmets.filter(item => item.ID !== action.payload?.item?.ID);
			}
			if (action.payload?.func === 'add') {
				state.attachmets = [...state.attachmets, ...action.payload?.item];
			}
			if (action.payload?.func === 'deleteLocal') {
				state.attachmets = state.attachmets.filter((item, index) => item?.idLocal !== action.payload?.idLocal);
			}
			if (action.payload?.func === 'editLocal') {
				const clone = [...state.attachmets];
				const find = state.attachmets.findIndex(item => item.idLocal === action.payload?.idLocal);
				if (find !== -1) {
					clone[find] = { ...clone[find], ...action.payload?.item };
					state.attachmets = clone;
				}
			}
			if (action.payload?.func === 'edit') {
				const clone = [...state.attachmets];
				const find = state.attachmets.findIndex(item => item.ID === action.payload?.item?.ID);
				if (find !== -1) {
					clone[find] = { ...clone[find], ...action.payload?.item };
					state.attachmets = clone;
				}
			}
		},
		// Action
		postActionWorkflow(_state, _action) {},
		// Handle InfoFeild
		updateValueInternalName(state, action) {
			state.itemInfo = { ...state.itemInfo, ...action.payload };
		},
		changeItemInfo(state, action) {
			state.itemInfo = { ...action.payload };
		},
		// Share
		postShareWorkflow(_state, _action) {},
		getHistoryShare(_state, _action) {},
		// Follow
		postFollowWorkflow(_state, _action) {},
		// History
		getWokflowHistory(_state, _action) {},
		// Lookup
		getListLookup(_state, _action) {},
		getListLookupSuccess(state, action) {},
		getFormGirdDetails(_state, _action) {},
		// LookupSQL
		getListLookupSQL(_state, _action) {},
		updateFieldHide(state, action) {
			let arrClone = [...state.listFieldNameHides];
			if (action.payload?.isShow) {
				action.payload?.arrFieldName.map(item => {
					if (arrClone?.includes(item)) {
						arrClone = arrClone.filter(e => e !== item);
					}
				});
			} else {
				action.payload.arrFieldName.map(item => {
					if (!arrClone?.includes(item)) {
						arrClone = [...arrClone, item];
					}
				});
			}
			state.listFieldNameHides = arrClone;
		},
		resetFieldHide(state) {
			state.listFieldNameHides = [];
		},
		//
		setInit(state, action) {
			state.init = action.payload;
		},
		// Comments
		postComment(_state, _action) {},
		getComment(_state, _action) {},
		postLikeComment(_state, _action) {},
		updateComment(state, action) {
			if (action.payload?.func === 'add') {
				state.comments = [action.payload?.comment, ...state.comments];
			}
			if (action.payload?.func === 'recall') {
				state.comments = action.payload.comment;
			}
		},
		//
		updateDateMonth(state, action) {
			console.log('action', action);
			state.dateMonth = action.payload;
		},
		getLineManagerUserSQL(state, action) {},
		clearDetails(state) {
			state.details = {};
		},
	},
});

export const {
	getFormWorkFlow,
	getFormWorkFlowSuccess,
	getDetailsWorkflow,
	getDetailsWorkflowSuccess,
	getAttachmentWorkflow,
	getAttachmentWorkflowSuccess,
	postActionWorkflow,
	updateValueInternalName,
	deteleAttachment,
	updateAttachments,
	editAttachment,
	postShareWorkflow,
	getHistoryShare,
	postFollowWorkflow,
	getWokflowHistory,
	getListLookup,
	getListLookupSuccess,
	getListLookupSQL,
	updateFieldHide,
	setInit,
	postComment,
	updateComment,
	getComment,
	postLikeComment,
	updateRelated,
	postDeleteWorkflowRelated,
	resetFieldHide,
	changeItemInfo,
	getDetailsNewWorkflow,
	updateDateMonth,
	getFormGirdDetails,
	getLineManagerUserSQL,
	clearDetails,
} = workflowsSlice.actions;
