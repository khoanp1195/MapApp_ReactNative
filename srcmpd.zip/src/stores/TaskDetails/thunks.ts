/* eslint-disable @typescript-eslint/no-explicit-any */
import { createAsyncThunk } from '@reduxjs/toolkit';
import {
	apiDeleteAttachment,
	apiEditAttachment,
	apiGetAttachments,
	apiGetFormTaskDetails,
	apiGetLookup,
	apiGetTaskDetails,
	apiGridDetails,
	apiGetWorkflowRelated,
	apiGetTaskFlow,
	apiPostActionTaskDetails,
	apiGetUserGroup,
	apiPostFollowTask,
	apiGetHistoryShare,
	apiPostShareTask,
	apiGetHistoryTask,
	apiDeleteWorkflowRelated,
	apiDeleteTaskFlow,
	apiGetComments,
	apiLikeComments,
	apiAddComments,
} from 'services/TaskDetails';

interface Prams {
	rid?: string | number;
	listid?: string | undefined;
	wid?: string | undefined;
	lid?: number;
	success?: (res: any) => void;
	isMore?: boolean;
	Guid?: string;
	data?: { ID: string };
	func?: string;
	itemInfo?: any;
	attachment?: any;
	options?: any;
	keyword?: string;
	PagingInfo?: any;
	flag?: number;
	usergroupvalues?: any;
	idea?: string;
	workflowrelated?: any;
	workflowrelatedid?: number;
	Path?: string;
	spitemid?: string | number;
	detailsFieldInfoCollection?: any[];
	detailsListInfo?: any;
}

export const fetchFormTaskDetails = createAsyncThunk('apps/fetchFormTaskDetails', async (params: Prams) => {
	const res = await apiGetFormTaskDetails(params);
	if (!res) throw new Error('Session Expired!!!');
	return res.data.data;
});

export const fetchTaskDetails = createAsyncThunk('apps/fetchTaskDetails', async (params: Prams) => {
	const res = await apiGetTaskDetails(params);
	if (!res) throw new Error('Session Expired!!!');
	return res.data.data;
});

export const fetchUserGroup = createAsyncThunk('apps/fetchUserGroup', async params => {
	const res = await apiGetUserGroup(params);
	if (!res) throw new Error('Session Expired!!!');
	return res.data.data;
});

export const fetchAtatchments = createAsyncThunk('apps/fetchAtatchments', async params => {
	const res = await apiGetAttachments(params);
	if (!res) throw new Error('Session Expired!!!');
	return res.data.data;
});

export const fetchLookup = createAsyncThunk('apps/fetchLookup', async (params: Prams) => {
	const res = await apiGetLookup(params);
	if (!res) throw new Error('Session Expired!!!');
	return {
		data: res.data.data,
		isMore: params.isMore,
		Guid: params.Guid,
	};
});

export const fetchDeleteAttachment = createAsyncThunk('apps/fetchDeleteAttachment', async (params: Prams) => {
	const res = await apiDeleteAttachment(params);
	if (!res) throw new Error('Session Expired!!!');
	return {
		status: res.data.status,
		ID: params.data?.ID,
	};
});

export const fetchEditAttachment = createAsyncThunk('apps/fetchEditAttachment', async params => {
	const res = await apiEditAttachment(params);
	if (!res) throw new Error('Session Expired!!!');
	return {
		status: res.data.status,
		params,
	};
});

export const fetchGirdDetails = createAsyncThunk('apps/fetchGirdDetails', async (params: Prams) => {
	const res = await apiGridDetails(params);
	if (!res) throw new Error('Session Expired!!!');
	return params.success(res);
});

export const fetchFormGirdDetails = createAsyncThunk('apps/fetchFormGirdDetails', async (params: Prams) => {
	const res = await apiGetFormTaskDetails(params);
	if (!res) throw new Error('Session Expired!!!');
	return params?.success(res);
});

export const fetchWorkflowRelated = createAsyncThunk('apps/fetchWorkflowRelated', async params => {
	const res = await apiGetWorkflowRelated(params);
	if (!res) throw new Error('Session Expired!!!');
	return res.data.data;
});

export const fetchTaskFlow = createAsyncThunk('apps/fetchTaskFlow', async (params: Prams) => {
	const res = await apiGetTaskFlow(params);
	if (!res) throw new Error('Session Expired!!!');
	return res.data.data;
});

export const fetchActionTaskDetails = createAsyncThunk('apps/fetchActionTaskDetails', async (params: Prams) => {
	const res = await apiPostActionTaskDetails(params);
	if (!res) throw new Error('Session Expired!!!');
	return params.success(res);
});

export const fetchFollowTask = createAsyncThunk('apps/fetchFollowTask', async (params: Prams) => {
	const res = await apiPostFollowTask(params);
	if (!res) throw new Error('Session Expired!!!');
	return params.success(res);
});

export const fetchHistoryShare = createAsyncThunk('apps/fetchHistoryShare', async (params: Prams) => {
	const res = await apiGetHistoryShare(params);
	if (!res) throw new Error('Session Expired!!!');
	return params.success(res);
});

export const fetchShareTask = createAsyncThunk('apps/fetchShareTask', async (params: Prams) => {
	const res = await apiPostShareTask(params);
	if (!res) throw new Error('Session Expired!!!');
	return params.success(res);
});

export const fetchHistoryTask = createAsyncThunk('apps/fetchHistoryTask', async (params: Prams) => {
	const res = await apiGetHistoryTask(params);
	if (!res) throw new Error('Session Expired!!!');
	return params.success(res);
});

export const fetchDeleteWorkflowRelated = createAsyncThunk('apps/fetchDeleteWorkflowRelated', async (params: Prams) => {
	const res = await apiDeleteWorkflowRelated(params);
	if (!res) throw new Error('Session Expired!!!');
	return params.success(res);
});

export const fetchDeleteTaskFlow = createAsyncThunk('apps/fetchDeleteTaskFlow', async (params: Prams) => {
	const res = await apiDeleteTaskFlow(params);
	if (!res) throw new Error('Session Expired!!!');
	return res.data.data;
});

export const fetchComment = createAsyncThunk('apps/fetchComment', async (params: Prams) => {
	const res = await apiGetComments(params);
	if (!res) throw new Error('Session Expired!!!');
	return params.success(res);
});

export const fetchLikeComment = createAsyncThunk('apps/fetchLikeComment', async (params: Prams) => {
	const res = await apiLikeComments(params);
	if (!res) throw new Error('Session Expired!!!');
	return params.success(res);
});

export const fetchAddComment = createAsyncThunk('apps/fetchAddComment', async (params: Prams) => {
	const res = await apiAddComments(params);
	if (!res) throw new Error('Session Expired!!!');
	return params.success(res);
});
