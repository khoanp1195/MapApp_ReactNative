import { GET, ENDPOINT, POST } from 'http/modules';

import { call, put, takeLatest } from 'redux-saga/effects';
import { apiGetAttachments } from 'services/TaskDetails';

import {
	getAttachment,
	getAttachmentSuccess,
	getFormTaskDetails,
	getFormTaskDetailsSuccess,
	getTaskDetails,
	getTaskDetailsSuccess,
	postActionTaskDetails,
} from './reduce';

export const ConvertResponse = (response: unknown) => {
	if (typeof response === 'object' && response !== null && 'data' in response) {
		const responseData: BaseAPIResponse<any> = (response as { data: BaseAPIResponse }).data;
		return responseData;
	}

	const responseError: BaseAPIResponse = {
		status: 'NONE',
		mess: {
			Key: '0',
			Value: 'Error',
		},
		data: null,
		dateNow: new Date().toString(),
	};
	return responseError;
};

interface Params {
	rid?: number;
	lid?: number;
	wid?: number;
	listid?: number;
	flag?: number;
	modified?: string;
}

interface IActionTasks {
	itemInfo: any;
	attachment: any;
	workflowrelated: any;
	func: string;
	usergroupvalues: string;
	idea: string;
	rid: number;
}

export interface ActionType<R = Params> {
	type: string;
	payload: {
		params: R;
		success: (res: unknown) => void;
		failed: (err: unknown) => void;
	};
}

export function* funcGetAttachment(action: ActionType): Generator {
	const res = yield call(apiGetAttachments, action.payload);
	if (res.data?.data?.fileInfoCollections) {
		yield put(getAttachmentSuccess(res.data?.data.fileInfoCollections));
	}
}

export function* funcGetFormTaskDetails(action: ActionType): Generator {
	const { params } = action.payload;
	// const response = yield call(apiGetFormTaskDetails, action.payload.params);
	const response = yield call(GET, ENDPOINT.WORKFLOWREQUEST, {
		func: 'getFormTemplate',
		mode: 2,
		// rid: params.rid,
		listid: params.listid,
		wid: params.wid,
		lid: 1066,
		flag: params?.flag || 0,
		modified: params?.modified,
	});

	const responseData = ConvertResponse(response);
	if (responseData.status === 'SUCCESS') {
		yield put(getFormTaskDetailsSuccess({ ...responseData.data, rid: action.payload.params.rid }));
		yield action.payload?.success(responseData);
	} else {
		// TODO: error handling
	}
}

function* funcGetTaskDetails(action: ActionType): Generator {
	try {
		const response = yield call(GET, ENDPOINT.WORKFLOWREQUEST, {
			func: 'getFormData',
			rid: action.payload.params?.rid,
			lid: action.payload.params?.lid,
		});

		const responseData = ConvertResponse(response);
		if (responseData.status === 'SUCCESS') {
			yield put(getTaskDetailsSuccess(responseData.data));
		} else {
			// Handle unexpected response structure
		}
		yield action.payload?.success(response);
	} catch (error) {
		// Handle error
	}
}

function* funcActionTaskDetails(action: ActionType<IActionTasks>): Generator {
	try {
		const { params } = action.payload;

		const formdata = new FormData();
		formdata.append('itemInfo', params?.itemInfo ? JSON.stringify(params?.itemInfo) : '');
		formdata.append('idea', params?.idea || '');
		formdata.append('attachment', JSON.stringify(params?.attachment) || '');
		formdata.append('workflowrelated', JSON.stringify(params?.workflowrelated));

		const body = {
			func: params?.func,
			rid: params.rid,
			lid: 1066,
			usergroupvalues: params?.usergroupvalues || null,
			SSN: 'workflow',
		};

		const response = yield call(POST, ENDPOINT.WORKFLOWREQUEST, body, formdata);

		const responseData = ConvertResponse(response);
		if (responseData.status === 'SUCCESS') {
			yield put(getTaskDetailsSuccess(responseData.data));
		} else {
			// Handle unexpected response structure
		}
		yield action.payload?.success(response);
	} catch (error) {
		// Handle error
	}
}

// the 'watcher' - on every 'API_BUTTON_CLICK' action, run our side effect
export function* TaskSaga() {
	yield takeLatest(getAttachment.type, funcGetAttachment);
	yield takeLatest(getFormTaskDetails.type, funcGetFormTaskDetails);
	yield takeLatest(getTaskDetails.type, funcGetTaskDetails);
	yield takeLatest(postActionTaskDetails.type, funcActionTaskDetails);
}
