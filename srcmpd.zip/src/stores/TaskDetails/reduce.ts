/* eslint-disable array-callback-return */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { createSlice } from '@reduxjs/toolkit';

import {
	fetchAtatchments,
	fetchDeleteAttachment,
	fetchDeleteTaskFlow,
	fetchEditAttachment,
	fetchFormTaskDetails,
	fetchLookup,
	fetchTaskDetails,
	fetchTaskFlow,
	fetchWorkflowRelated,
} from './thunks';

interface DetailsParams {
	FormConfig: {
		DocStatus: number;
		ListButtonAction: string;
		DefindJsonObj: string;
		NotifiedUsersInfo: string;
		Permission: number;
		Roles: number;
		IsAddinfoUser: number;
		DocStep: number;
		IsCompleted: boolean;
		IsCreatedByMe: boolean;
		AllowRelatedEdit: boolean;
		IsAdmin: boolean;
		Step: number;
	};
	ItemInfo: {
		Workflow: string;
	};
}

interface Attachments {
	ID: string;
	Title: string;
	Name: string;
	AttachTypeId: number;
	Extension: string;
	Size: number;
	Path: string;
	CreatedName: string;
	PositionName: string;
	AttachTypeName: string;
	IsAuthor: number;
	Base64: string;
}

interface IItemWorkflow {
	ID: number;
	Title: string;
	Content: string;
	Created: string;
	CreatedBy: string;
	StatusGroup: number;
	ImagePath: string;
	DefaultImagePath: string;
	Workflow: string;
	WorkflowId: number;
	ListID: string;
	WorkflowRelatedId?: number;
	SPItemId: number;
	AssignedTo?: string;
	AssignedToInfo?: string;
	ApprovalStatus?: number;
	Flag?: number;
	TotalRecord?: number;
}

interface Children {
	ID: number;
	Parent: number;
	DueDate: string;
	StatusGroup: number;
	Title: string;
	AssignedTo: string;
	AssignedToInfo: string;
	IsAllowDelete: number;
	children?: Children[];
	level?: number;
}

export interface ITaskFlow {
	ID: number;
	Parent: number;
	DueDate: string;
	StatusGroup: number;
	Title: string;
	AssignedTo: string;
	AssignedToInfo: string;
	IsAllowDelete: number;
	children?: Children[];
	level?: number;
}

export interface TaskState {
	forms: Array<unknown>;
	details: DetailsParams;
	userGroup: Array<unknown>;
	attachmets: Array<Attachments>;
	lookup: Array<unknown>;
	pageLookup: string;
	Guid: string;
	workflowRelated: Array<IItemWorkflow>;
	TaskFlow: Array<ITaskFlow>;
	listFieldNameHides: string[];
	ItemInfo: any;
}

const initialState: TaskState = {
	forms: {},
	details: [],
	userGroup: [],
	attachmets: [],
	lookup: [],
	pageLookup: '0',
	Guid: '',
	workflowRelated: [],
	TaskFlow: [],
	listFieldNameHides: [],
	ItemInfo: {},
};

export const taskDetailsSlice = createSlice({
	name: 'taskDetails',
	initialState,
	reducers: {
		// editDetails
		updateDetails(state, action) {
			let data: Details = state.details;
			data = {
				...data,
				...{
					ItemInfo: {
						...data.ItemInfo,
						...action.payload,
					},
				},
			};

			state.details = data;
		},

		updateFieldHide(state, action) {
			let arrClone = [...state.listFieldNameHides];
			if (action.payload?.isShow) {
				action.payload.arrFieldName.map(item => {
					if (arrClone?.includes(item)) {
						arrClone = arrClone.filter(e => e !== item);
					}
				});
			} else {
				action.payload.arrFieldName.map(item => {
					if (!arrClone?.includes(item)) {
						arrClone = [...arrClone, item];
					}
				});
			}
			state.listFieldNameHides = arrClone;
		},

		editDetails(state, action) {
			let data: Details = state.details;
			data = {
				...data,
				...{
					ItemInfo: {
						...data.ItemInfo,
						[action.payload.name]: action.payload.text,
					},
				},
			};

			state.details = data;
		},
		editDetailsLockupSQL(state, action) {
			let data: Details = state.details;
			data = {
				...data,
				...{
					ItemInfo: {
						...data.ItemInfo,
						...action.payload,
					},
				},
			};

			state.details = data;
		},
		addAttachment(state, action) {
			state.attachmets = [...state.attachmets, action.payload];
		},
		editAttachment(state, action) {
			const data = state.attachmets;
			const index = data.findIndex(attachment => attachment.Name === action.payload.Name);
			if (index !== -1) {
				data[index] = { ...data[index], ...action.payload };
			}
			state.attachmets = data;
		},
		deleteAttachment(state, action) {
			state.attachmets = state.attachmets.filter(attachment => attachment.Name !== action.payload.Name);
		},
		getAttachment(state, action) {},
		getAttachmentSuccess(state, action) {
			state.attachmets = action.payload;
		},
		updateWorkflowRelated(state, action) {
			state.workflowRelated = state.workflowRelated.filter(item => item.ID !== action.payload.ID);
		},

		getFormTaskDetails(state, action) {},
		getFormTaskDetailsSuccess(state, action) {
			state.forms = action.payload;
		},
		getTaskDetails(state, action) {},
		getTaskDetailsSuccess(state, action) {
			try {
				state.details = action.payload;
				state.attachmets = action.payload?.Attachments || [];
				state.workflowRelated = action.payload?.WorkflowRelated;
				state.TaskFlow = action.payload?.ListTask;
				state.ItemInfo = action.payload.ItemInfo;
			} catch (error) {
				console.log('getTaskDetailsSuccess', error);
			}
		},
		updateOtherResourceId(state, action) {
			state.details = {
				...state.details,
				FormConfig: {
					...state.details.FormConfig,
					OtherResourceId: action.payload,
				},
			};
		},
		updateAtatchmentTasks(state, action) {
			try {
				state.attachmets = action.payload || [];
			} catch (error) {}
		},
		postActionTaskDetails(state, action) {},
		updateItemInfo(state, action) {
			state.ItemInfo = { ...state.ItemInfo, ...action.payload };
		},
	},
	extraReducers: builder => {
		builder.addCase(fetchFormTaskDetails.pending, state => {});
		builder.addCase(fetchFormTaskDetails.fulfilled, (state, action) => {
			state.forms = action.payload;
		});
		builder.addCase(fetchFormTaskDetails.rejected, state => {});

		builder.addCase(fetchTaskDetails.pending, state => {});
		builder.addCase(fetchTaskDetails.fulfilled, (state, action) => {
			state.details = action.payload;
		});
		builder.addCase(fetchTaskDetails.rejected, state => {});

		builder.addCase(fetchAtatchments.pending, state => {});
		builder.addCase(fetchAtatchments.fulfilled, (state, action) => {
			state.attachmets = action.payload?.fileInfoCollections;
		});
		builder.addCase(fetchAtatchments.rejected, state => {});

		builder.addCase(fetchLookup.pending, state => {});
		builder.addCase(fetchLookup.fulfilled, (state, action) => {
			if (action.payload.isMore) {
				state.Guid = action.payload?.Guid;
				state.lookup = [...state.lookup, ...action.payload.data?.Data];
				state.pageLookup = action.payload.data?.PagingInfo;
			} else {
				state.Guid = action.payload?.Guid;
				state.lookup = action.payload.data?.Data;
				state.pageLookup = action.payload.data?.PagingInfo;
			}
		});
		builder.addCase(fetchLookup.rejected, state => {});

		builder.addCase(fetchDeleteAttachment.pending, state => {});
		builder.addCase(fetchDeleteAttachment.fulfilled, (state, action) => {
			if (action.payload.status === 'SUCCESS') {
				state.attachmets = state.attachmets.filter(item => item.ID !== action.payload.ID);
			}
		});
		builder.addCase(fetchDeleteAttachment.rejected, state => {});

		builder.addCase(fetchEditAttachment.pending, state => {});
		builder.addCase(fetchEditAttachment.fulfilled, (state, action) => {
			if (action.payload.status === 'SUCCESS') {
				const data = state.attachmets;
				const index = state.attachmets.findIndex(e => e.ID === action.payload.params?.data?.ID);
				data[index] = {
					...data[index],
					AttachTypeId: action.payload.params?.data?.AttachTypeId,
					AttachTypeName: action.payload.params?.data?.AttachTypeName,
					Title: action.payload.params?.data?.Title,
				};
				state.attachmets = data;
			}
		});
		builder.addCase(fetchWorkflowRelated.rejected, state => {});

		builder.addCase(fetchWorkflowRelated.pending, state => {});
		builder.addCase(fetchWorkflowRelated.fulfilled, (state, action) => {
			state.workflowRelated = action.payload;
		});

		builder.addCase(fetchTaskFlow.pending, state => {});
		builder.addCase(fetchTaskFlow.fulfilled, (state, action) => {
			state.TaskFlow = action.payload;
		});
		builder.addCase(fetchTaskFlow.rejected, state => {});

		builder.addCase(fetchDeleteTaskFlow.pending, state => {});
		builder.addCase(fetchDeleteTaskFlow.fulfilled, (state, action) => {
			state.TaskFlow = action.payload;
		});
		builder.addCase(fetchDeleteTaskFlow.rejected, state => {});
	},
});

export const {
	editDetails,
	editDetailsLockupSQL,
	addAttachment,
	deleteAttachment,
	editAttachment,
	getAttachment,
	getAttachmentSuccess,
	updateWorkflowRelated,
	getFormTaskDetails,
	getFormTaskDetailsSuccess,
	getTaskDetails,
	getTaskDetailsSuccess,
	updateOtherResourceId,
	updateAtatchmentTasks,
	postActionTaskDetails,
	updateDetails,
	updateFieldHide,
	updateItemInfo,
} = taskDetailsSlice.actions;
