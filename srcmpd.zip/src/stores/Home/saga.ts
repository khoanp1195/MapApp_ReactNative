import { GET, ENDPOINT, POST } from 'http/modules';

import { call, put, takeLatest } from 'redux-saga/effects';
import { ConvertResponse } from 'stores';

import {
	getChartHome,
	getChartHomeSuccess,
	getCountUnReadNotify,
	getFavoriteHome,
	getFavoriteHomeSuccess,
	updateAllReadNotify,
	updateCountUnRead,
} from './reducer';

function* funcGetChartHome(action): Generator {
	try {
		const response = yield call(GET, `${ENDPOINT.BOARD}`, {
			func: 'getChartFirstActionOnRequest',
			lid: 1066,
		});

		const responseData = ConvertResponse(response);
		if (responseData.status === 'SUCCESS') {
			yield put(getChartHomeSuccess(responseData.data));
			yield action?.payload?.success();
		} else {
			yield action?.payload?.failed();
			// Handle unexpected response structure
		}
	} catch (error) {
		yield action?.payload?.failed();
		// Handle error
	}
}

function* funcGetFavoriteHome(action): Generator {
	try {
		const response = yield call(GET, `${ENDPOINT.WORKFLOW}`, {
			func: 'getOrSearchListWorkflow',
			lid: 1066,
			flag: 1,
			data: `{"PerType": -1,"WorkflowCategoryId":0}`,
		});

		const responseData = ConvertResponse(response);
		if (responseData.status === 'SUCCESS') {
			yield put(getFavoriteHomeSuccess(responseData.data));
			yield action?.payload?.success();
		} else {
			yield action?.payload?.failed();
			// Handle unexpected response structure
		}
	} catch (error) {
		yield action?.payload?.failed();
		// Handle error
	}
}

function* funcGetCountUnReadNotify(): Generator {
	try {
		const response = yield call(GET, `${ENDPOINT.WORKFLOW}`, {
			func: 'getList',
			lid: 1066,
			flag: 1,
			data: `{"Flag":0}`,
			resourcetype: 'MySocialNotify',
			totalrecord: 0,
		});

		const responseData = ConvertResponse(response);
		if (responseData.status === 'SUCCESS') {
			yield put(updateCountUnRead(responseData.data.TotalRecord || 0));
		} else {
			// Handle unexpected response structure
		}
	} catch (error) {
		// Handle error
	}
}

function* funcUpdateAllReadNotify(action): Generator {
	try {
		const response = yield call(GET, '/qc/workflow/_layouts/15/VuThao.BPMOP.Social/Notify.ashx?func=readAll');

		const responseData = ConvertResponse(response);
		if (responseData.status === 'SUCCESS') {
			yield put(updateCountUnRead(0));
			yield action?.payload?.success(responseData);
		} else {
			// Handle unexpected response structure
		}
	} catch (error) {
		// Handle error
	}
}

export function* watcherHomeSaga() {
	yield takeLatest(getChartHome.type, funcGetChartHome);
	yield takeLatest(getFavoriteHome.type, funcGetFavoriteHome);
	yield takeLatest(getCountUnReadNotify.type, funcGetCountUnReadNotify);
	yield takeLatest(updateAllReadNotify.type, funcUpdateAllReadNotify);
}
