import { createAsyncThunk } from '@reduxjs/toolkit';
import { getAppVersion } from 'utils/system';

export const setAppVersion = createAsyncThunk('system/appVersion', getAppVersion);
