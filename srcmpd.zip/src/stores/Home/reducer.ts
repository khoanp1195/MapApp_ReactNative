import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export interface HomeState {
	isTurnOnFilterMyTask?: boolean;
	isTurnOnFilterMyRequest?: boolean;
	chartHome?: IChart;
	favorite?: IFavorite;
	countUnRead: number;
}

export interface IChart {
	FirstChartData: FirstChartDaum[];
	SecondChartData: SecondChartDaum[];
	MoreData: any;
}

export interface FirstChartDaum {
	Index: number;
	StartOfDate: string;
	DoW: number;
	Total: number;
	MaxTotal: number;
}

export interface SecondChartDaum {
	TotalYear: number;
	TotalMonth: number;
	TotalWeek: number;
	TotalPreYear: number;
	TotalPreMonth: number;
	TotalPreWeek: number;
}

export type IFavorite = IItemFavorite[];

export interface IItemFavorite {
	ID: number;
	WorkflowID: number;
	Title: string;
	TitleEN: string;
	Description: any;
	ImageURL: string;
	IsFavor: number;
	WorkflowCategory?: string;
	WorkflowCategoryID: number;
}

const initialState: HomeState = {
	isTurnOnFilterMyTask: false,
	isTurnOnFilterMyRequest: false,
	chartHome: undefined,
	favorite: [],
	countUnRead: 0,
};

export const homeSlice = createSlice({
	name: 'home',
	initialState,
	reducers: {
		updateTurnOnFilterMyTask: (state, action: PayloadAction<boolean>) => {
			state.isTurnOnFilterMyTask = action.payload;
		},
		updateTurnOnFilterMyRequest: (state, action: PayloadAction<boolean>) => {
			state.isTurnOnFilterMyRequest = action.payload;
		},
		getChartHome(state, action) {},
		getChartHomeSuccess(state, action) {
			state.chartHome = action.payload;
		},
		getFavoriteHome(state, action) {},
		getFavoriteHomeSuccess(state, action) {
			state.favorite = action.payload;
		},
		updateFavoriteHome(state, action) {
			if (action.payload?.isDelete) {
				state.favorite = state.favorite.filter(e => e.WorkflowID !== action.payload.WorkflowID);
			} else {
				state.favorite = [...state.favorite, action.payload];
			}
		},
		getCountUnReadNotify(state, action) {},
		updateCountUnRead(state, action) {
			state.countUnRead = action.payload;
		},
		updateAllReadNotify(state, action) {},
	},
	extraReducers: () => {},
});

export const {
	updateTurnOnFilterMyTask,
	updateTurnOnFilterMyRequest,
	getChartHome,
	getChartHomeSuccess,
	getFavoriteHome,
	getFavoriteHomeSuccess,
	updateFavoriteHome,
	getCountUnReadNotify,
	updateCountUnRead,
	updateAllReadNotify,
} = homeSlice.actions;
