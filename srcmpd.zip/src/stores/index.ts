import AsyncStorage from '@react-native-async-storage/async-storage';
import { combineReducers, configureStore } from '@reduxjs/toolkit';
import { createSelectorHook, useDispatch } from 'react-redux';
import { FLUSH, PAUSE, PERSIST, persistReducer, persistStore, PURGE, REGISTER, REHYDRATE } from 'redux-persist';
import { PersistedState } from 'redux-persist/es/types';
import createSagaMiddleware from 'redux-saga';

import { appsSlice } from './Apps';
import { authSlice } from './Auth';
import { countSlice } from './Count';
import { dataNotRemoveSlice } from './DataNotRemove';
import { homeSlice } from './Home';
import { myTaskSlice } from './Mytasks';
import { newRelatedSlice } from './NewRelated/slice';
import rootSaga from './rootSaga';
import { systemSlice } from './System';
import { taskSlice } from './Task/slice';
import { taskDetailsSlice } from './TaskDetails';
import { workflowsSlice } from './Workflows/sliceWorkflow';

const sagaMiddleware = createSagaMiddleware();

const PersistVersion = 1;

// @see https://github.com/reduxjs/redux-toolkit/issues/121#issuecomment-480621931
// Create a Persist-Config
const persistConfig = {
	key: 'DPM_VUTHAO',
	storage: AsyncStorage,
	whitelist: ['dataNotRemove'],
	blacklist: [],
	version: PersistVersion,
	migrate: (state: PersistedState) => {
		// eslint-disable-next-line no-underscore-dangle
		if (PersistVersion !== state?._persist.version) {
			return Promise.resolve(null as unknown as PersistedState);
		}
		return Promise.resolve(state);
	},
};

const rootReducer = combineReducers({
	auth: authSlice.reducer,
	home: homeSlice.reducer,
	mytask: myTaskSlice.reducer,
	system: systemSlice.reducer,
	count: countSlice.reducer,
	dataNotRemove: dataNotRemoveSlice.reducer,
	apps: appsSlice.reducer,
	taskDetails: taskDetailsSlice.reducer,
	task: taskSlice.reducer,
	newRelated: newRelatedSlice.reducer,
	workflow: workflowsSlice.reducer,
});

const persistedReducer = persistReducer(persistConfig, rootReducer);

const store = configureStore({
	devTools: process.env.NODE_ENV === 'development',
	reducer: persistedReducer,
	middleware: getDefaultMiddleware =>
		getDefaultMiddleware({
			serializableCheck: false,
		}).concat(sagaMiddleware),
});

sagaMiddleware.run(rootSaga);

export type RootState = ReturnType<typeof store.getState>;

export type AppDispatch = typeof store.dispatch;

export const useAppSelector = createSelectorHook<RootState>();

export const useAppDispatch = () => useDispatch<AppDispatch>();

export const persistor = persistStore(store);

export const ConvertResponse = (response: unknown) => {
	if (typeof response === 'object' && response !== null && 'data' in response) {
		const responseData: BaseAPIResponse<any> = (response as { data: BaseAPIResponse }).data;
		return responseData;
	}

	const responseError: BaseAPIResponse = {
		status: 'NONE',
		mess: {
			Key: '0',
			Value: 'Error',
		},
		data: null,
		dateNow: new Date().toString(),
	};
	return responseError;
};

export default store;
