import { createAsyncThunk } from '@reduxjs/toolkit';
import { apiGetMe } from 'services/Auth';

export const fetchCustomerInformation = createAsyncThunk('auth/fetchCustomerInformation', async () => {
	const res = await apiGetMe();
	if (!res) throw new Error('Session Expired!!!');
	return res.data.data;
});
