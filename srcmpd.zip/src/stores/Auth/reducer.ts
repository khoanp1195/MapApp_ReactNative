import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { ICustomerProfile } from 'services/Auth/types';
import { clearToken } from 'utils/keychain';

import { fetchCustomerInformation } from './thunks';

interface LoginState {
	status: 'AUTH' | 'UNAUTH';
	loading: boolean;
	customerInfo?: ICustomerProfile;
	isLogin: boolean;
	isSplash: boolean;
	isAfterSplash: boolean;
}

const initialState: LoginState = {
	status: 'UNAUTH',
	loading: false,
	customerInfo: undefined,
	isLogin: false,
	isSplash: true,
	isAfterSplash: false,
};

export const authSlice = createSlice({
	name: 'auth',
	initialState,
	reducers: {
		updateStatus: (state, action: PayloadAction<LoginState['status']>) => {
			state.status = action.payload;
		},
		clearUser: state => {
			state.loading = false;
			state.customerInfo = undefined;
			clearToken();
		},
		updateProfile: (state, action: PayloadAction<ICustomerProfile>) => {
			state.customerInfo = action.payload;
		},
		updateLogin: (state, action) => {
			state.isLogin = action.payload;
		},
		updateSplash: (state, action) => {
			state.isSplash = action.payload;
		},
		updateAfterSplash: (state, action) => {
			state.isAfterSplash = action.payload;
		},
	},
	// extraReducers: builder => {
	// 	builder.addCase(fetchCustomerInformation.pending, state => {
	// 		// state.loading = true;
	// 	});
	// 	builder.addCase(fetchCustomerInformation.fulfilled, (state, action) => {
	// 		// state.loading = false;
	// 		// state.customerInfo = action.payload;
	// 		state.status = 'AUTH';
	// 	});
	// 	builder.addCase(fetchCustomerInformation.rejected, state => {
	// 		// state.loading = false;
	// 	});
	// },
});

export const { updateStatus, clearUser, updateProfile, updateLogin, updateSplash, updateAfterSplash } =
	authSlice.actions;
