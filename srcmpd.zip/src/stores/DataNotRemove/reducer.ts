import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { ICustomerProfile } from 'services/Auth/types';
import { fetchCustomerInformation } from 'stores/Auth/thunks';
import { ILanguage, updateLoadingUser } from 'stores/System/reducer';

import i18n from '../../utils/I18n';

export interface DataNotRemoveState {
	username?: string;
	isTurnOnBiometric: boolean;
	language: string;
	customer?: ICustomerProfile;
	bioType?: string | boolean;
	side: string;
	isLogin: boolean;
}

const initialState: DataNotRemoveState = {
	username: '',
	isTurnOnBiometric: false,
	language: 'en',
	customer: undefined,
	bioType: false,
	side: '',
	isLogin: false,
};

export const dataNotRemoveSlice = createSlice({
	name: 'dataNotRemove',
	initialState,
	reducers: {
		clearUsername: state => {
			state.username = '';
		},
		saveUsername: (state, action: PayloadAction<string>) => {
			state.username = action.payload;
		},
		updateStatusBiometric: (state, action: PayloadAction<boolean>) => {
			state.isTurnOnBiometric = action.payload;
		},
		updateBioType: (state, action: PayloadAction<string | boolean>) => {
			state.bioType = action.payload;
		},
		updateLanguage: (state, action: PayloadAction<ILanguage>) => {
			state.language = action.payload;
			i18n.locale = action.payload;
		},
		updateCustomer: state => {
			state.customer = undefined;
		},
		clearCustomer: state => {
			state.customer = undefined;
		},
		updateSide: (state, action: PayloadAction<string>) => {
			state.side = action.payload;
		},
		updateLogin: (state, action) => {
			state.isLogin = action.payload;
		},
	},
	extraReducers: builder => {
		builder.addCase(fetchCustomerInformation.pending, state => {});
		builder.addCase(fetchCustomerInformation.fulfilled, (state, action) => {
			state.customer = action.payload;
			// state.status = 'AUTH';
		});
		builder.addCase(fetchCustomerInformation.rejected, state => {});
	},
});

export const {
	clearUsername,
	saveUsername,
	updateStatusBiometric,
	updateLanguage,
	updateCustomer,
	clearCustomer,
	updateBioType,
	updateSide,
	updateLogin,
} = dataNotRemoveSlice.actions;
