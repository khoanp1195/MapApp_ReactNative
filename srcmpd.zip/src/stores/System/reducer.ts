import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import VersionCheck from 'react-native-version-check';
import { IBeanWorkflowStatus } from 'services/BeanWorkflowStatus/types';

import { fetchBeanAppStatus, fetchBeanWorkflowStatus, fetchSettingSystem } from './thunks';
import i18n from '../../utils/I18n';

export type ILanguage = 'vi' | 'en';

export interface SystemState {
	isSupportedBiometric?: boolean;
	isTurnOnDrawer?: boolean;
	isExpiredUserSession: boolean;
	appVersion: string;
	language?: ILanguage;
	loading?: boolean;
	beanAppStatus?: IBeanWorkflowStatus[];
	beanWorkflowStatus?: IBeanWorkflowStatus[];
	settingSystem: string;
	toTabScreenTask: string;
	isReload: boolean;
	loadingUser: boolean;
}

const initialState: SystemState = {
	isSupportedBiometric: false,
	isTurnOnDrawer: false,
	isExpiredUserSession: false,
	language: 'en',
	loading: false,
	beanAppStatus: [],
	appVersion: VersionCheck.getCurrentVersion(),
	beanWorkflowStatus: [],
	settingSystem: '1,4,8,16,64',
	toTabScreenTask: '',
	isReload: false,
	loadingUser: true,
};

export const systemSlice = createSlice({
	name: 'system',
	initialState,
	reducers: {
		clearSystem: state => {
			state.isSupportedBiometric = false;
			state.isTurnOnDrawer = false;
		},
		updateStatusSupportingBiometric: (state, action: PayloadAction<boolean>) => {
			state.isSupportedBiometric = action.payload;
		},
		updateStatusDrawer: (state, action: PayloadAction<boolean>) => {
			state.isTurnOnDrawer = action.payload;
		},
		updateLanguage: (state, action: PayloadAction<ILanguage>) => {
			state.language = action.payload;
			i18n.locale = action.payload;
		},
		updateStatusExpiredUserSession: (state, action: PayloadAction<boolean>) => {
			state.isExpiredUserSession = action.payload;
		},
		trackingUser(state, action) {},
		updateTabScreenTask: (state, action) => {
			state.toTabScreenTask = action.payload;
		},
		reloadWorkflow: (state, action) => {
			state.isReload = action.payload;
		},
		updateLoadingUser: (state, action) => {
			state.loadingUser = action.payload;
		},
	},
	extraReducers: builder => {
		builder.addCase(fetchBeanAppStatus.pending, state => {
			state.loading = true;
		});
		builder.addCase(fetchBeanAppStatus.fulfilled, (state, action) => {
			state.loading = false;
			const filterData = action.payload.filter(v => v.IsShow);
			state.beanAppStatus = filterData;
		});
		builder.addCase(fetchBeanAppStatus.rejected, state => {
			state.loading = false;
		});

		builder.addCase(fetchBeanWorkflowStatus.pending, state => {
			state.loading = true;
		});
		builder.addCase(fetchBeanWorkflowStatus.fulfilled, (state, action) => {
			state.loading = false;
			// const filterData = action.payload.filter(v => v.IsShow);
			state.beanWorkflowStatus = action.payload;
		});
		builder.addCase(fetchBeanWorkflowStatus.rejected, state => {
			state.loading = false;
		});

		builder.addCase(fetchSettingSystem.pending, state => {
			state.loading = true;
		});
		builder.addCase(fetchSettingSystem.fulfilled, (state, action) => {
			state.loading = false;
			state.settingSystem = action.payload;
		});
		builder.addCase(fetchSettingSystem.rejected, state => {
			state.loading = false;
		});
	},
});

export const {
	clearSystem,
	updateLanguage,
	updateStatusDrawer,
	updateStatusExpiredUserSession,
	updateStatusSupportingBiometric,
	trackingUser,
	updateTabScreenTask,
	reloadWorkflow,
	updateLoadingUser,
} = systemSlice.actions;
