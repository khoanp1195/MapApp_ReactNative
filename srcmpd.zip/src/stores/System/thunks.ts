import { createAsyncThunk } from '@reduxjs/toolkit';
import { apiBeanAppStatus, apiBeanWorkflowStatus, apiSettingSystem } from 'services/BeanWorkflowStatus';
import { getAppVersion } from 'utils/system';

export const setAppVersion = createAsyncThunk('system/appVersion', getAppVersion);

export const fetchBeanAppStatus = createAsyncThunk('auth/apiBeanAppStatus', async () => {
	const res = await apiBeanAppStatus();
	if (!res) throw new Error('Error');
	return res.data.data;
});

export const fetchBeanWorkflowStatus = createAsyncThunk('auth/apiBeanWorkflowStatus', async () => {
	const res = await apiBeanWorkflowStatus();
	if (!res) throw new Error('Error');
	return res.data.data;
});

export const fetchSettingSystem = createAsyncThunk('auth/apiSettingSystem', async () => {
	const res = await apiSettingSystem();
	if (!res) throw new Error('Error');
	return res.data.data;
});
