import { GET, ENDPOINT, POST } from 'http/modules';

import { call, put, takeEvery, takeLatest } from 'redux-saga/effects';
import { ConvertResponse } from 'stores';
import { ActionType } from 'stores/types';

import { trackingUser } from './reducer';

function* funcTrackingUser(action: ActionType): Generator {
	try {
		const params = {
			func: 'logActionHistory',
		};
		const defaultData = {
			ResourceId: '',
			MoreData: '',
			ExtendId: 0,
			ExtendId2: 0,
			ResourceGuid: null,
			IsNegative: false,
			IsSuccess: true,
			ReportStatus: 0,
		};
		const listData = { ...defaultData, ...(action.payload.params || {}) };

		const formData = new FormData();
		formData.append('data', JSON.stringify(listData));
		const response = yield call(POST, ENDPOINT.TRACKING, params, formData);
	} catch (error) {
		//
	}
}

export function* watcherSystemSaga() {
	yield takeLatest(trackingUser.type, funcTrackingUser);
}
