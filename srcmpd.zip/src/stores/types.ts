export interface ActionType<R = unknown> {
	type: string;
	payload: {
		params: R;
		success: (res: unknown) => void;
		failed: (err: unknown) => void;
	};
}

export interface Response<R = unknown> {
	data: {
		status: string;
		mess: {
			Key: string;
			Value: string;
		};
		data: R;
		dateNow: string;
	};
}
