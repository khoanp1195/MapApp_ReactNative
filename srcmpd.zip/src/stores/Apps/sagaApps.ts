/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { ENDPOINT, GET, POST } from 'http/modules';

import { call, put, takeEvery, takeLatest } from 'redux-saga/effects';
import { ConvertResponse } from 'stores';
import { deleteAttachment } from 'stores/TaskDetails';
import { ActionType } from 'stores/types';

import { setFavoriteApps } from './reducer';

function* funcSetFavoriteApps(action: ActionType): Generator {
	try {
		const body = {
			func: 'setFavorite',
			flag: action.payload.params?.flag,
			data: `{"WorkflowId":${action.payload.params?.id}}`,
		};

		const response = yield call(POST, ENDPOINT.BOARD, body);
		const responseData = ConvertResponse(response);

		if (responseData.status === 'SUCCESS') {
			yield action.payload?.success(responseData);
		} else {
			// Handle unexpected response structure
			yield action.payload?.failed(responseData);
		}
	} catch (error) {
		// Handle error
		yield action.payload?.failed(error);
	}
}

export function* watcherAppsSaga() {
	yield takeEvery(setFavoriteApps.type, funcSetFavoriteApps);
}
