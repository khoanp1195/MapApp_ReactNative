import { createAsyncThunk } from '@reduxjs/toolkit';
import { Alert } from 'react-native';
import { ParamsProps } from 'screens/Apps/Containers';
import { apiGetAllWorkFlow, apiGetWorkFlow, apiSetFavorite, apiGetListFormTemplateModified } from 'services/Apps';

export const fetchListWorkFlow = createAsyncThunk('apps/fetchListWorkFlow', async () => {
	const res = await apiGetAllWorkFlow();
	if (!res) throw new Error('Session Expired!!!');
	return res.data.data;
});

export const fetchWorkFlow = createAsyncThunk('apps/fetchWorkFlow', async () => {
	const res = await apiGetWorkFlow();
	if (!res) throw new Error('Session Expired!!!');
	return res.data.data;
});

export const fetchFavorite = createAsyncThunk('apps/fetchFavorite', async (data: ParamsProps) => {
	const res = await apiSetFavorite(data);
	if (!res) throw new Error('Session Expired!!!');
	return data?.success(res);
});

export const getListFormTemplateModified = createAsyncThunk(
	'apps/getListFormTemplateModified',
	async (data: ParamsProps) => {
		const res = await apiGetListFormTemplateModified(data);
		if (!res) throw new Error('Session Expired!!!');
		return data?.success(res);
	},
);
