import { createSlice } from '@reduxjs/toolkit';

import { fetchFavorite, fetchListWorkFlow, fetchWorkFlow } from './thunks';

export interface WorkflowProps {
	Created: string;
	ID: number;
	Modified: string;
	Order: null;
	Title: string;
	TotalRecord: number;
}
export interface AppsState {
	bookMark: Array<unknown>;
	loading: boolean;
	workflow: Array<WorkflowProps>;
	workflowsApps:
		| {
				ID: number;
				WorkflowID: number;
				ListID: string;
				Title: string;
				TitleEN: string;
				Description: any;
				ImageURL: string;
				IsFavor: number;
				WorkflowCategory: any;
				WorkflowCategoryID: number;
		  }
		| undefined;
}

const initialState: AppsState = {
	bookMark: [],
	loading: false,
	workflow: [],
	workflowsApps: undefined,
};

export const appsSlice = createSlice({
	name: 'apps',
	initialState,
	reducers: {
		addBookmark: (state, action) => {
			state.bookMark.push(action.payload);
		},
		removeBookmark: state => {
			state.bookMark = [];
		},
		updateWorkflowsApps: (state, action) => {
			state.workflowsApps = action.payload;
		},
		setFavoriteApps: (state, action) => {},
	},
	extraReducers: builder => {
		builder.addCase(fetchListWorkFlow.pending, state => {
			state.loading = true;
		});
		builder.addCase(fetchListWorkFlow.fulfilled, state => {
			state.loading = false;
		});
		builder.addCase(fetchListWorkFlow.rejected, state => {
			state.loading = false;
		});
		builder.addCase(fetchWorkFlow.pending, state => {
			state.loading = true;
		});
		builder.addCase(fetchWorkFlow.fulfilled, (state, action) => {
			state.workflow = action.payload;
			state.loading = false;
		});
		builder.addCase(fetchWorkFlow.rejected, state => {
			state.loading = false;
		});
		builder.addCase(fetchFavorite.pending, state => {
			state.loading = true;
		});
		builder.addCase(fetchFavorite.fulfilled, state => {
			state.loading = false;
		});
		builder.addCase(fetchFavorite.rejected, state => {
			state.loading = false;
		});
	},
});

export const { addBookmark, removeBookmark, updateWorkflowsApps, setFavoriteApps } = appsSlice.actions;
