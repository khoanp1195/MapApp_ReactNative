import { baseURL } from 'http';

export const defaultImgUri = (text = 'No Image') => `https://via.placeholder.com/500x500.png?text=${text}`;

export const imgDummy = `${baseURL}/qc/_layouts/15/images/VuThao.BPMOP.eOffice/avarta-default.png`;

export const PhoneNumberRegExp = /^\d{10}$/;
