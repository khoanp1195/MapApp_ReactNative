export const FONTS = {
	'Roboto-Black': 'Roboto-Black',
	'Roboto-BlackItalic': 'Roboto-BlackItalic',
	'Roboto-Bold': 'Roboto-Bold',
	'Roboto-BoldItalic': 'Roboto-BoldItalic',
	'Roboto-Regular': 'Roboto-Regular',
	'Roboto-Italic': 'Roboto-Italic',
	'Roboto-Light': 'Roboto-Light',
	'Roboto-LightItalic': 'Roboto-LightItalic',
	'Roboto-Medium': 'Roboto-Medium',
	'Roboto-MediumItalic': 'Roboto-MediumItalic',
	'Roboto-Thin': 'Roboto-Thin',
	'Roboto-ThinItalic': 'Roboto-ThinItalic',
};
