import Config from 'react-native-config';

interface EnvProperties {
	envName?: string;
	apiBaseUrl?: string;
	apiAuthBaseUrl?: string;
	domainLegacyUrlPrefix?: string;
	domainLegacyUrl?: string;
	domainNvpStage?: string;
	domainMedia?: string;
	baseUrlWebview?: string;
	surveyApiBaseUrl?: string;
	citigymWebToLeadApiBaseUrl?: string;
	ticketBaseUrl?: string;
}

const EnvSingleton = (() => {
	let isSetup = false;
	let instance: EnvProperties = {};

	function createInstance() {
		isSetup = true;
		const object = Object.defineProperties(instance, {
			envName: {
				value: Config.ENV_NAME,
				writable: false,
				enumerable: false,
				configurable: false,
			},
			apiBaseUrl: {
				value: Config.API_BASE_URL,
				writable: false,
				enumerable: false,
				configurable: false,
			},
		});
		return object;
	}

	return {
		getInstance() {
			if (!isSetup) {
				instance = createInstance();
			}
			return instance;
		},
	};
})();

const envInstance = EnvSingleton.getInstance();
export const ENVName = envInstance.envName;
export const ApiBaseUrl = envInstance.apiBaseUrl;
