import en from 'assets/i18n/en';

import I18n from './I18n';

export const translate = (key: keyof typeof en) => I18n.t(key);
