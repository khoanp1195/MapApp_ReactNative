import VersionCheck from 'react-native-version-check';

export const getAppVersion = () => {
	return VersionCheck.getCurrentVersion();
};
