/* eslint-disable import/no-extraneous-dependencies */
import * as dayjsModule from 'dayjs';
import 'dayjs/locale/vi';
import isSameOrAfter from 'dayjs/plugin/isSameOrAfter';
import timezone from 'dayjs/plugin/timezone';
import toObject from 'dayjs/plugin/toObject';
import utc from 'dayjs/plugin/utc';

const dayjs = dayjsModule.default;
dayjs.locale('vi');
dayjs.extend(toObject);
dayjs.extend(isSameOrAfter);
dayjs.extend(timezone);
dayjs.extend(utc);

export const isDifferenceDateTimes = (one: Date, two: Date) => !!dayjs(one).diff(two);

export const createDateWithoutTime = (date: Date) => new Date(date).setHours(0, 0, 0, 0);

export const ishasNewTag = (date: string): number => {
	const time = new Date().getTime() - new Date(date).getTime();
	return time / (24 * 60 * 60 * 1000);
};

export default dayjs;
