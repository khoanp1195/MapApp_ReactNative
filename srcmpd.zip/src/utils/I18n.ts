/* eslint-disable import/no-extraneous-dependencies */
import en from 'assets/i18n/en';
import vi from 'assets/i18n/vi';
import I18n from 'react-native-i18n';

I18n.fallbacks = true;

I18n.translations = {
	en,
	vi,
};

export default I18n;
