// @ref https://www.freecodecamp.org/news/how-to-implement-secure-biometric-authentication-on-mobile-devices-4dc518558c5c/
import { Alert } from 'react-native';
import { getBundleId } from 'react-native-device-info';
import SInfo, { RNSensitiveInfoOptions } from 'react-native-sensitive-info';

const SHARE_PREF_KEY = 'RN_KEYCHAIN';

interface UserSession {
	username: string;
	password: string;
}

const bioMetricsOptions: RNSensitiveInfoOptions = {
	sharedPreferencesName: SHARE_PREF_KEY,
	keychainService: getBundleId(),
	touchID: true,
	showModal: true,
	strings: {
		header: 'Xác thực để lấy thông tin',
	},
	kSecUseOperationPrompt: 'Xác thực để lấy thông tin',
	kSecAccessControl: 'kSecAccessControlBiometryAny',
	// kLocalizedFallbackTitle: 'Nhập mã pin để mở lại biometric',
	kSecAttrSynchronizable: true,
};

const bioMetricsOptionsSet: RNSensitiveInfoOptions = {
	sharedPreferencesName: SHARE_PREF_KEY,
	keychainService: getBundleId(),
};

export const BIOMETRICS_ERROR = {
	KEY_INVALIDATED: 'Key permanently invalidated',
	KEY_EUNSPECIFIED_RETRY_LIMIT: 'Application retry limit exceeded.',
	KEY_EUNSPECIFIED_LOCKEDOUT: 'Biometry is locked out.',
	KEY_ATTEMPT_ANDROID: 'Too many attempts. Try again later.',
	KEY_SENSOR_DISABLED_ANDROID: 'Too many attempts. Fingerprint sensor disabled.',
	KEY_ATTEMPT_IOS: 'The user name or passphrase you entered is not correct.',
};

export const getSupportedBiometryType = async () => {
	try {
		const biometricType = await SInfo.isSensorAvailable();
		return !!biometricType;
	} catch {
		return false;
	}
};

export const resetUserSession = async () => {
	try {
		const result = await SInfo.deleteItem('userInfo', {
			sharedPreferencesName: SHARE_PREF_KEY,
			keychainService: getBundleId(),
		});
		return result;
	} catch {
		return false;
	}
};

export const getUserSession = async () => {
	try {
		const result = await SInfo.getItem('userInfo', bioMetricsOptions);
		if (!result) {
			resetUserSession();
			throw new Error(BIOMETRICS_ERROR.KEY_INVALIDATED);
		}
		return JSON.parse(result) as UserSession;
	} catch (err) {
		const errorMessage = (err as Error).message;
		if (!errorMessage) {
			resetUserSession();
			throw new Error(BIOMETRICS_ERROR.KEY_INVALIDATED);
		}
		throw err as Error;
	}
};

export const setUserInfoToKeyChain = async (params: { username: string; password: string }) => {
	try {
		const result = await SInfo.setItem('userInfo', JSON.stringify(params), bioMetricsOptionsSet);
		if (!result) {
			resetUserSession();
			throw new Error(BIOMETRICS_ERROR.KEY_INVALIDATED);
		}
		return result;
	} catch (err) {
		throw err as Error;
	}
};
