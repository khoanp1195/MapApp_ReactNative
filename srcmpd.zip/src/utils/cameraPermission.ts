import { PermissionsAndroid, Platform } from 'react-native';

export const androidRequestCameraPermission = async () => {
	try {
		if (Platform.OS === 'android') {
			const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.CAMERA, {
				title: 'App Camera Permission',
				message: 'App needs access to your camera ',
				buttonNeutral: 'Ask Me Later',
				buttonNegative: 'Cancel',
				buttonPositive: 'OK',
			});
			return granted === PermissionsAndroid.RESULTS.GRANTED;
		}
	} catch {
		return false;
	}
};

export const androidRequestWriteExternalStoragePermission = async () => {
	try {
		if (Platform.OS === 'android') {
			const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE, {
				title: 'App Write External Storage Permission',
				message: 'App needs access to save images to your device',
				buttonNegative: 'Cancel',
				buttonPositive: 'OK',
			});
			return granted === PermissionsAndroid.RESULTS.GRANTED;
		}
	} catch {
		return false;
	}
};

export const androidRequestReadContactsPermission = async () => {
	try {
		if (Platform.OS === 'android') {
			const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.READ_CONTACTS, {
				title: 'App Read Contacts Permission',
				message: 'App needs access to recharge mobile phone',
				buttonNegative: 'Cancel',
				buttonPositive: 'OK',
			});
			return granted === PermissionsAndroid.RESULTS.GRANTED;
		}
	} catch {
		return false;
	}
};
