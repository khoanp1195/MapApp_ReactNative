import AsyncStorage from '@react-native-async-storage/async-storage';
import messaging, { firebase } from '@react-native-firebase/messaging';
import { Alert, PermissionsAndroid, Platform } from 'react-native';

export async function requestUserPermission() {
	try {
		const tokenAsync = await AsyncStorage.getItem('FCM_TOKEN');
		if (tokenAsync) return;
		const authStatus = await messaging().requestPermission({
			provisional: false,
			sound: true,
			badge: true,
			alert: true,
		});

		if (
			authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
			authStatus === messaging.AuthorizationStatus.PROVISIONAL
		) {
			const token = await messaging().getToken();
			AsyncStorage.setItem('FCM_TOKEN', token);
		}
	} catch (error) {
		// Alert.alert('The operation couldn’t be completed');
	}
}
