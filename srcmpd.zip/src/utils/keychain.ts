import { getBundleId } from 'react-native-device-info';
import SInfo, { RNSensitiveInfoOptions } from 'react-native-sensitive-info';

const keychainOptions: RNSensitiveInfoOptions = {
	sharedPreferencesName: 'tokenRefs',
	keychainService: getBundleId(),
};

export interface ITokens {
	refreshToken: string;
	accessToken: string;
}

export const saveTokenToKeyChain = async (tokens: ITokens) => {
	return SInfo.setItem('authenToken', JSON.stringify(tokens), keychainOptions);
};

export const getTokenFromKeyChain = async () => {
	try {
		const result = await SInfo.getItem('authenToken', keychainOptions);
		return JSON.parse(result) as ITokens;
	} catch (err) {
		return {} as ITokens;
	}
};

export const clearToken = async () => {
	return SInfo.deleteItem('authenToken', keychainOptions);
};

export const setTimeSyncForm = async (date: string) => {
	return SInfo.setItem('timeSyncForm', JSON.stringify(date), keychainOptions);
};

export const getTimeSyncForm = async () => {
	try {
		const result = await SInfo.getItem('timeSyncForm', keychainOptions);
		return JSON.parse(result) as string;
	} catch (err) {
		return null;
	}
};
