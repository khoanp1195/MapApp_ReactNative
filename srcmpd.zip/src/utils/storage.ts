import AsyncStorage from '@react-native-async-storage/async-storage';

const config = {
	prefix: 'DPM_APP',
	accessToken: 'ACCESS_TOKEN',
	phoneNumber: 'USER_PHONE_NUMBER',
} as const;

/**
 * Package: https://react-native-async-storage.github.io/async-storage/
 * Saving data to Storage.
 */
export const saveToStorage = async (name: string, values: unknown) => {
	try {
		return await AsyncStorage.setItem(`${config.prefix}-${name}`, JSON.stringify(values));
	} catch (error) {
		return error;
	}
};

/**
 * Package: https://react-native-async-storage.github.io/async-storage/
 * Load data from Storage
 */
export const loadFromStorage = async (name: string) => {
	try {
		const value = await AsyncStorage.getItem(`${config.prefix}-${name}`);
		if (value) return JSON.parse(value) as unknown;
		return null;
	} catch (error) {
		return error;
	}
};

/**
 * Package: https://react-native-async-storage.github.io/async-storage/
 * Remove data from Storage
 */
export const removeFromStorage = async (name: string) => {
	try {
		return await AsyncStorage.removeItem(`${config.prefix}-${name}`);
	} catch (error) {
		return error;
	}
};

export const getSideName = async () => {
	try {
		const side: string = (await AsyncStorage.getItem('SIDE')) || '';
		return side;
	} catch (error) {
		return '';
	}
};

// export const setCustomerAccessToken = (accessToken: string) => {
// 	saveToStorage(config.accessToken, accessToken);
// };

// export const getCustomerAccessToken = async (): Promise<string | false> => {
// 	const accessToken = await loadFromStorage(config.accessToken);
// 	if (!accessToken) return;
// 	return accessToken;
// };

// export const clearCustomerAccessToken = () => {
// 	removeFromStorage(config.accessToken);
// };

// export const saveUserPhoneNumber = (phone: string) => saveToStorage(config.phoneNumber, phone);
// export const loadUserPhoneNumber = () => loadFromStorage(config.phoneNumber) as Promise<string>;
// export const clearUserPhoneNumber = () => removeFromStorage(config.phoneNumber);

// export const saveEventsTrackingClientID = (cid: string) => saveToStorage(config.eventsTrackingClientID, cid);
// export const loadEventsTrackingClientID = () => loadFromStorage(config.eventsTrackingClientID) as Promise<string>;
// export const clearEventsTrackingClientID = () => removeFromStorage(config.eventsTrackingClientID);

// export const saveUserId = (userId: string) => saveToStorage(config.userId, userId);
// export const loadUserId = () => loadFromStorage(config.userId) as Promise<string>;
// export const clearUserId = () => removeFromStorage(config.userId);
