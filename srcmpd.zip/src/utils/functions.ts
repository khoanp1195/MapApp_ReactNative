import { ICONS } from 'config/images';

/* eslint-disable no-plusplus */
export const getRandomColor = () => {
	const letters = '0123456789ABCDEF';
	let color = '#';
	for (let i = 0; i < 6; i++) {
		color += letters[Math.floor(Math.random() * 16)];
	}
	return color;
};

export const currency = (price: number) => {
	return `${price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')} đ`;
};

export const formatNumberToMoney = (number: string | number | undefined, currencyUnit = '') => {
	if (number === '') {
		return '';
	}

	if (Number(number) === 0) {
		return `0${currencyUnit}`;
	}

	if (!number || Number.isNaN(number)) {
		return `${currencyUnit}`;
	}

	const array = [];
	let result = '';
	let isNegative = false;

	if (Number(number) < 0) {
		isNegative = true;
	}

	const numberString = Math.abs(Number(number)).toString();
	if (numberString.length < 3) {
		return numberString + currencyUnit;
	}

	let count = 0;
	for (let i = numberString.length - 1; i >= 0; i -= 1) {
		count += 1;
		if (numberString[i] === '.' || numberString[i] === ',') {
			array.push(',');
			count = 0;
		} else {
			array.push(numberString[i]);
		}
		if (count === 3 && i >= 1) {
			array.push('.');
			count = 0;
		}
	}

	for (let i = array.length - 1; i >= 0; i -= 1) {
		result += array[i];
	}

	if (isNegative) {
		result = `-${result}`;
	}

	return result + currencyUnit;
};
export const formatMoneyToNumber = (money: string, currencyUnit = '') => {
	if (money && money.length > 0) {
		const moneyString = money
			.replace(currencyUnit, '')
			.replace(/,/g, '')
			.replace(/đ/g, '')
			.replace(/\./g, '')
			.replace(/ /g, '');
		const number = Number(moneyString);
		if (Number.isNaN(number)) {
			return 0;
		}
		return number;
	}

	return money;
};
export const currencyWithoutVND = (price: number) => {
	return price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
};

export function bytesToMB(bytes: number) {
	if (typeof bytes !== 'number') {
		throw new Error('Input must be a number');
	}
	return bytes / (1024 * 1024);
}

export function generateRandomId(length: number) {
	const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	let randomId = '';

	for (let i = 0; i < length; i++) {
		const randomIndex = Math.floor(Math.random() * characters.length);
		randomId += characters.charAt(randomIndex);
	}

	return randomId;
}

export function formatBytes(bytes: number, decimals = 2) {
	if (!+bytes) return '0 Bytes';

	const k = 1024;
	const dm = decimals < 0 ? 0 : decimals;
	const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

	const i = Math.floor(Math.log(bytes) / Math.log(k));

	return `${parseFloat((bytes / k ** i).toFixed(dm))} ${sizes[i]}`;
}

export const getIconFile = (Extension: string) => {
	if (!Extension) return ICONS.icFileOther;
	if (Extension.includes('do')) return ICONS.icFileDoc;
	if (Extension.includes('xl')) return ICONS.icFileExel;
	if (Extension.includes('pp')) return ICONS.icFilePpt;
	if (Extension.includes('po')) return ICONS.icFilePpt;
	if (Extension.includes('pd')) return ICONS.icFilePdf;
	return ICONS.icFileOther;
};

export const breakExecuteJS = (ExecuteJS: string) => {
	const arrExecuteJS = ExecuteJS.replace('vtUtility.', '').replace(');', '').replace(')', '').split('(');
	const funcName = arrExecuteJS[0] as 'IFunction';
	return {
		arrExecuteJS,
		funcName,
	};
};

export const exportFieldTypeIdWithFTypeId = (FTypeId: number) => {
	switch (FTypeId) {
		case 2:
			return 1;
		case 3:
			return 2;
		case 4:
			return 5;
		case 6:
			return 3;
		case 1:
			return 4;
		case 7:
			return 13;
		case 8:
			return 10;
		case 9:
			return 4;
		case 10:
			return 8;
		case 15:
			return 3;
		case 17:
			return 9;
		case 20:
			return 7;

		default:
			return 0;
	}
};

function compareTypes(a, b) {
	// Đặt ưu tiên cho ký tự đặc biệt, nếu một trong hai là ký tự đặc biệt
	const specialChars = /[^a-zA-Z0-9]/;
	const isSpecialCharA = specialChars.test(a?.name);
	const isSpecialCharB = specialChars.test(b?.name);

	if (isSpecialCharA && !isSpecialCharB) {
		return -1;
	}
	if (!isSpecialCharA && isSpecialCharB) {
		return 1;
	}

	// Sắp xếp theo thứ tự bình thường nếu cả hai không phải ký tự đặc biệt
	return a?.name?.localeCompare(b?.name);
}

export function quickSort(arr) {
	if (arr.length <= 1) {
		return arr;
	}

	const pivot = arr[0];
	const left = [];
	const right = [];

	for (let i = 1; i < arr.length; i++) {
		if (compareTypes(arr[i], pivot) < 0) {
			left.push(arr[i]);
		} else {
			right.push(arr[i]);
		}
	}

	return [...quickSort(left), pivot, ...quickSort(right)];
}

export function containsAllAlphabets(inputString: string) {
	let isAz = false;
	const arrayInputString = Array.from(inputString);

	arrayInputString.forEach((elm, index) => {
		const isRegex = Number.isNaN(Number(elm));
		const isL = index === 0 && arrayInputString[index] === '-';
		if (isRegex && !isL && elm !== ',' && elm !== '.') {
			isAz = true;
		}
	});

	return isAz;
}

export function filterAndRemoveNonAlphabets(inputString: string) {
	let valueInputString = Array.from(inputString);
	const arrayInputString = Array.from(inputString);
	arrayInputString.forEach((elm, index) => {
		const isRegex = Number.isNaN(Number(elm));
		const isL = index === 0 && arrayInputString[index] === '-';
		if (isRegex && !isL && elm !== ',' && elm !== '.') {
			valueInputString = valueInputString.filter(e => e !== elm);
		}
	});
	return valueInputString?.toString()?.replaceAll(',', '');
}
