/* eslint-disable @typescript-eslint/require-await */
/* eslint-disable react-hooks/exhaustive-deps */
import { useEffect, useRef } from 'react';

import PushNotificationIOS from '@react-native-community/push-notification-ios';
import messaging from '@react-native-firebase/messaging';
import { navigate, navigationRef } from 'navigation/RootNavigation';
import { RoutesNames } from 'navigation/RoutesNames';
import PushNotification from 'react-native-push-notification';
import { useAppDispatch, useAppSelector } from 'stores';
import { fetchCount } from 'stores/Count/thunks';

interface INotify {
	data: {
		NotifyTitle: string;
		NotifyContent: string;
		ResourceId: string;
		ListId: string;
		ResourceCategoryId: string;
		WorkflowID: string;
	};
}

const NotifyService = () => {
	const dispatch = useAppDispatch();
	const { isLogin } = useAppSelector(store => store.dataNotRemove);

	const refQuereStack = useRef<INotify | null>(null);

	const handleNavigation = (remoteMessage: INotify) => {
		const { data } = remoteMessage;

		const { ResourceCategoryId, ListId, ResourceId, WorkflowID } = data || {};
		const isWorkflow = ResourceCategoryId === '8';

		if (isWorkflow && navigationRef.isReady() && isLogin) {
			refQuereStack.current = null;
			navigate(RoutesNames.WorkflowDetails, {
				item: {
					ListID: ListId,
					ID: ResourceId,
					WorkflowId: WorkflowID,
				},
			});
		}
	};

	const handleTouchNotify = async (remoteMessage: INotify) => {
		if (!isLogin) {
			refQuereStack.current = remoteMessage;
			return;
		}

		handleNavigation(remoteMessage);
	};

	useEffect(() => {
		messaging().onMessage((remoteMessage: INotify) => {
			// dispatch(fetchCount());
			PushNotification.localNotification({
				title: remoteMessage.data.NotifyTitle,
				message: remoteMessage.data.NotifyContent,
				userInfo: remoteMessage.data,
			});
		});
	}, []);

	useEffect(() => {
		if (isLogin && refQuereStack.current) {
			handleNavigation(refQuereStack.current);
		}
	}, [isLogin]);

	useEffect(() => {
		PushNotification.configure({
			onNotification: (onNotify: {
				foreground: boolean;
				userInteraction: boolean;
				message: string;
				data: object;
				finish: (res: any) => void;
			}) => {
				if (onNotify.userInteraction && onNotify.foreground) {
					handleTouchNotify(onNotify);
				}
				onNotify.finish(PushNotificationIOS.FetchResult.NoData);
			},
		});

		messaging().onNotificationOpenedApp(remoteMessage => {
			// dispatch(fetchCount());
			handleTouchNotify(remoteMessage);
		});

		messaging()
			.getInitialNotification()
			.then(remoteMessage => {
				if (remoteMessage) {
					// dispatch(fetchCount());
					handleTouchNotify(remoteMessage);
				}
			});
	}, [isLogin]);

	return null;
};

export default NotifyService;
