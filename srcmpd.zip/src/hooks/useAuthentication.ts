import { resetStackNavigation } from 'navigation/RootNavigation';
import { useAppDispatch } from 'stores';
import { clearUser } from 'stores/Auth';
import { clearCustomer, updateBioType, updateStatusBiometric, updateLogin } from 'stores/DataNotRemove';
import { clearSystem } from 'stores/System';
import { resetUserSession } from 'utils/biometricAuthentication';
import { clearToken } from 'utils/keychain';

function useAuthentication() {
	const dispatch = useAppDispatch();

	const logout = async () => {
		try {
			dispatch(clearUser());
			dispatch(clearCustomer());
			// dispatch(clearSetting());
			// resetUserSession();
			// dispatch(clearSystem());
			dispatch(updateLogin(false));
			// dispatch(updateStatusBiometric(false));
			// dispatch(updateBioType())
			await Promise.allSettled([clearToken()]);
			// resetStackNavigation();
		} catch {
			// Error handler
		}
	};

	return { logout };
}

export default useAuthentication;
