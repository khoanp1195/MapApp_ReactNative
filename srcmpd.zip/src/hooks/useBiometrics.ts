/* eslint-disable @typescript-eslint/no-misused-promises */
/* eslint-disable @typescript-eslint/require-await */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { Alert, Linking } from 'react-native';
import store, { useAppSelector, useAppDispatch } from 'stores';
import { updateStatusBiometric } from 'stores/DataNotRemove';
import { updateStatusSupportingBiometric } from 'stores/System';
import {
	setUserInfoToKeyChain,
	BIOMETRICS_ERROR,
	getUserSession,
	getSupportedBiometryType,
	resetUserSession,
} from 'utils/biometricAuthentication';
import { translate } from 'utils/translate';

const useBiometrics = () => {
	const { isSupportedBiometric } = useAppSelector(state => state.system);
	const dispatch = useAppDispatch();

	const handleAuthError = (error: Error) => {
		const show3TimesLimitError = () => {
			Alert.alert(
				translate('title_alert_warning'),
				// 'Bạn đã xác thực sai nhiều lần. Vui lòng kiểm tra lại thông tin',
				BIOMETRICS_ERROR.KEY_EUNSPECIFIED_RETRY_LIMIT,
				[{ text: 'OK', style: 'cancel' }],
			);
		};

		const show5TimesLimitError = () => {
			Alert.alert(
				'Xác thực sinh trắc học đã bị khoá',
				// 'Bạn phải đăng nhập thông qua số điện thoại và mật khẩu hoặc tiến hành khoá thiết bị và mở khoá để tái kích hoạt sinh trắc học',
				BIOMETRICS_ERROR.KEY_EUNSPECIFIED_LOCKEDOUT,
				[{ text: 'OK', style: 'cancel' }],
			);
		};

		const show3TimesLimitAndroid = () => {
			Alert.alert(
				translate('title_alert_warning'),
				// 'Bạn đã xác thực sai nhiều lần. Vui lòng kiểm tra lại thông tin và chờ trong giây lát',
				BIOMETRICS_ERROR.KEY_ATTEMPT_ANDROID,
				[{ text: 'OK', style: 'cancel' }],
			);
		};

		const handleInvalidatedError = () => {
			Alert.alert(
				translate('title_alert_warning'),
				// 'Vì lý do bảo mật, khi thay đổi vân tay/Face ID trên thiết bị, vui lòng đăng nhập bằng mật khẩu và kích hoạt lại đăng nhập bằng sinh trắc học.',
				BIOMETRICS_ERROR.KEY_INVALIDATED,
				[{ text: 'OK' }],
			);
		};

		const errorMessage = error?.message;
		switch (errorMessage) {
			case BIOMETRICS_ERROR.KEY_INVALIDATED:
				handleInvalidatedError();
				break;
			case BIOMETRICS_ERROR.KEY_EUNSPECIFIED_RETRY_LIMIT:
				show3TimesLimitError();
				break;
			case BIOMETRICS_ERROR.KEY_EUNSPECIFIED_LOCKEDOUT:
				show5TimesLimitError();
				break;
			case BIOMETRICS_ERROR.KEY_ATTEMPT_IOS:
				setTimeout(() => {
					if (!store.getState().system.isSupportedBiometric) {
						show5TimesLimitError();
					} else {
						show3TimesLimitError();
					}
				}, 700);
				break;
			case BIOMETRICS_ERROR.KEY_ATTEMPT_ANDROID:
				show3TimesLimitAndroid();
				break;
			case BIOMETRICS_ERROR.KEY_SENSOR_DISABLED_ANDROID:
				show5TimesLimitError();
				break;
			default:
				break;
		}
	};

	const saveUserInfo = async (params: { username: string; password: string }) => {
		const { username, password } = params || {};
		try {
			const result = await setUserInfoToKeyChain({
				username,
				password,
			});
			if (result) dispatch(updateStatusBiometric(true));
		} catch (err) {
			// dispatch(updateStatusBiometric(false));
			handleAuthError(err as Error);
		}
	};

	const getUserInfo = async () => {
		try {
			const userSession = await getUserSession();
			return userSession;
		} catch (err) {
			// dispatch(updateStatusBiometric(false));
			handleAuthError(err as Error);
			throw err as Error;
		}
	};

	// const askBiometrics = (params: { username: string; password: string; bioType: string }) => {
	// 	Alert.alert(translate('title_alert_warning'), translate('ask_biometrics1'), [
	// 		{
	// 			text: translate('ok'),
	// 			onPress: () => {
	// 				saveUserInfo(params);
	// 			},
	// 		},
	// 		{
	// 			text: translate('cancel'),
	// 		},
	// 	]);
	// };

	const askBiometrics = (params: {
		username: string;
		password: string;
		bioType?: string | boolean;
		isQsLoginWithNewAccount?: boolean;
	}) => {
		const content = params?.isQsLoginWithNewAccount
			? `${translate('useSwipeAccountBio')} ${typeof params?.bioType === 'string' ? params?.bioType : ''} ? `
			: `${translate('ask_biometrics1')} ${typeof params?.bioType === 'string' ? params?.bioType : ''} ${translate(
					'ask_biometrics2',
			  )}`;

		return new Promise<void>((resolve, reject) => {
			Alert.alert(translate('title_alert_warning'), content, [
				{
					text: translate('Accept'),
					onPress: async () => {
						await setUserInfoToKeyChain({
							username: params.username,
							password: params.password,
						})
							.then(() => {
								// dispatch(updateStatusBiometric(true));
								resolve();
							})
							.catch(err => {
								handleAuthError(err as Error);
								reject();
								throw err as Error;
							});
					},
				},
				{
					text: translate('cancelAlert'),
					onPress: () => {
						if (isSupportedBiometric) {
							resetUserSession().finally(() => {
								dispatch(updateStatusBiometric(false));
								reject();
							});
						} else {
							reject();
						}
					},
				},
			]);
		});
	};

	const asyncSaveBio = (params: { username: string; password: string }) => {
		return new Promise<void>((resolve, reject) => {
			saveUserInfo(params).finally(() => resolve());
		});
	};

	const checkBiometricsAvailability = () => {
		getSupportedBiometryType().then(isSupported => {
			if (!isSupported) {
				Alert.alert(
					translate('title_alert_warning'),
					// 'Thiết bị hiện tại không hỗ trợ phương thức xác thực này hoặc đã bị tắt trong phần cài đặt. Bạn cần kiểm tra lại để tiếp tục sử dụng tính năng này',
					translate('check_biometrics_availability'),
					[
						{
							text: translate('setting'),
							onPress: () => {
								Linking.openSettings();
							},
						},
						{ text: translate('cancel'), style: 'cancel' },
					],
				);
				return false;
			}
			if (!!isSupported !== isSupportedBiometric) {
				dispatch(updateStatusSupportingBiometric(!!isSupported));
				return true;
			}
		});

		return true;
	};

	return {
		getUserInfo,
		saveUserInfo,
		askBiometrics,
		checkBiometricsAvailability,
		asyncSaveBio,
	};
};

export default useBiometrics;
