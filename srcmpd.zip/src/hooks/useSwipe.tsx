import { Dimensions, GestureResponderEvent } from 'react-native';
import store, { useAppSelector } from 'stores';

const windowWidth = Dimensions.get('window').width;

export function useSwipe(onSwipeRight?: () => void, rangeOffset = 4) {
	let firstTouch = 0;

	// set user touch start position
	function onTouchStart(event: GestureResponderEvent) {
		firstTouch = event.nativeEvent.pageX;
	}

	// when touch ends check for swipe directions
	function onTouchEnd(event: GestureResponderEvent) {
		// get touch position and screen size
		const positionX = event.nativeEvent.pageX;
		const range = windowWidth / rangeOffset;
		// check if position is growing positively and has reached specified range
		if (positionX - firstTouch > range) onSwipeRight?.();
		// check if position is growing negatively and has reached specified range
		// else if (firstTouch - positionX > range) onSwipeLeft?.();
	}

	function onTouchCancel(event: GestureResponderEvent) {
		// get touch position and screen size
		const positionX = event.nativeEvent.pageX;
		// check if position is growing positively and has reached specified range
		if (positionX - firstTouch > 30) onSwipeRight?.(true);
		if (positionX - firstTouch < -30) onSwipeRight?.(false);
		// check if position is growing negatively and has reached specified range
		// else if (firstTouch - positionX > range) onSwipeLeft?.();
	}

	return { onTouchStart, onTouchEnd, onTouchCancel };
}
