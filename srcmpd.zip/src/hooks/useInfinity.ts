/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable no-unsafe-optional-chaining */
import { HTTP } from 'http/modules/Request';
import { HTTPRequestMethods } from 'http/restfulBuilder';

import { useCallback, useMemo, useRef } from 'react';

import { getSideName } from 'utils/storage';

import { useAsyncAction } from './useAsyncAction';

export interface ResponseData<R> extends BaseAPIMetaResponse {
	map(arg0: (e: any) => void): unknown;
	Data: R;
}

export interface InfinityOptions<R> {
	size?: number;
	params?: { [key: string]: unknown };
	requireAuthentication?: true;
	onSuccess?: (res: BaseAPIResponse<ResponseData<R>>) => void;
}

const defaultData = {
	totalPages: 0,
	size: 0,
	total: 0,
	page: 0,
	loading: false,
	refreshing: false,
	data: null,
};

const useInfinity = <R>(path: string, options?: InfinityOptions<R>) => {
	const { size = 10, requireAuthentication, onSuccess } = options || {};
	const isRefreshing = useRef<boolean>(false);
	const countPageRef = useRef<number>(0);
	const CountPage = useRef<number>(0);

	const getPageData = useCallback(
		async (pageIndex = 0, paramsOptions?: InfinityOptions<R>) => {
			const side = await getSideName();
			countPageRef.current = pageIndex;
			const { data: resData } = await HTTP.call<BaseAPIResponse<ResponseData<R>>>({
				method: HTTPRequestMethods.GET,
				url: `${side}${path}`,
				config: {
					_shouldAuthorize: requireAuthentication ? true : undefined,
					params: {
						limit: size,
						offset: pageIndex,
						...(paramsOptions?.params || { ...options?.params }),
					},
				},
			});
			if (resData.data?.length === 10) CountPage.current = pageIndex + 1;
			return resData;
		},
		[options?.params, path, requireAuthentication, size],
	);

	const [gotoPage, state, reset] = useAsyncAction(getPageData, {
		onSuccess: res => {
			if (isRefreshing.current) isRefreshing.current = false;
			if (onSuccess) onSuccess(res);
		},
		onFailed: () => {
			if (isRefreshing.current) isRefreshing.current = false;
		},
		keepPrevData: true,
	});

	const infinityState = useMemo(
		() => ({
			...defaultData,
			loading: state.status !== 'READY',
			data: state.data?.data,
			page: countPageRef.current,
			totalPages: !state.data?.data?.TotalRecord ? 0 : Math.floor(state.data?.data?.TotalRecord / 10) + 1 || 0,
		}),
		[state],
	);

	const gotoFirstPage = useCallback(
		(paramsOptions?: InfinityOptions<R>) => {
			reset();
			gotoPage(0, paramsOptions);
		},
		[gotoPage, reset],
	);

	const fetchMore = useCallback(() => {
		const { loading, page, totalPages } = infinityState;
		if (!loading && page === 0 && totalPages === 0) {
			return gotoPage(infinityState.page + 1);
		}
		if (!loading && page < totalPages - 1) {
			return gotoPage(infinityState.page + 1);
		}
		if (CountPage.current > countPageRef.current) {
			return gotoPage(CountPage.current);
		}
	}, [gotoPage, infinityState]);

	const refreshPage = useCallback(() => {
		isRefreshing.current = true;
		CountPage.current = 0;
		gotoFirstPage();
	}, [gotoFirstPage]);

	return {
		state: { ...infinityState, refreshing: isRefreshing.current },
		gotoFirstPage,
		refreshPage,
		fetchMore,
	};
};

export default useInfinity;
