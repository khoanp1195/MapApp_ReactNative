import store, { useAppSelector, useAppDispatch } from 'stores';
import { getProcedure, getListSheet } from 'stores/NewRelated/slice';
import * as TYPE from 'stores/NewRelated/type';

const useNewRelated = () => {
	const { procedure, listSheet } = useAppSelector(state => state.newRelated);
	const dispatch = useAppDispatch();

	const getProcedureData = (payload: TYPE.IGetProcedurePayloadType) => {
		dispatch(getProcedure(payload));
	};
	const getListSheetData = (payload: TYPE.ISheetListPayloadType) => {
		dispatch(getListSheet(payload));
	};

	return {
		getProcedureData,
		procedure,
		getListSheetData,
		listSheet,
	};
};

export default useNewRelated;
