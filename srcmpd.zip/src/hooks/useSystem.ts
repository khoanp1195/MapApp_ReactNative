import { useEffect, useState } from 'react';

import { useAppSelector, useAppDispatch } from 'stores';
import { getTokenFromKeyChain } from 'utils/keychain';

const useSystem = () => {
	const { beanAppStatus } = useAppSelector(state => state.system);
	const { language } = useAppSelector(state => state.dataNotRemove);

	const [Cookie, setCookie] = useState('');

	useEffect(() => {
		async function getCK() {
			const { accessToken } = await getTokenFromKeyChain();
			const { info } = JSON.parse(accessToken || '{}');
			setCookie(`ASP.NET_SessionId=${info?.['ASP.NET_SessionId']}; FedAuth=${info?.FedAuth}; WSS_FullScreenMode=false`);
		}
		getCK();
	}, []);

	const isVN = language === 'vi';
	const lid = isVN ? 1066 : 1033;
	const formatDate = isVN ? 'DD/MM/YYYY' : 'MM/DD/YYYY';
	const formatDateTime = isVN ? 'DD/MM/YYYY HH:mm' : 'MM/DD/YYYY HH:mm';
	const formatYY = isVN ? 'DD/MM/YY HH:mm' : 'MM/DD/YY HH:mm';
	return {
		language, // vi
		lid, // 1033
		beanAppStatus,
		isVN, // true
		Cookie,
		formatDate,
		formatDateTime,
		formatYY,
	};
};

export default useSystem;
