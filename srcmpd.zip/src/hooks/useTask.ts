import store, { useAppSelector, useAppDispatch } from 'stores';
import { getTask, updateTask } from 'stores/Task/slice';
import * as TYPE from 'stores/Task/type';

const useTask = () => {
	const { isGettingTask, taskData, isUpdatingTask } = useAppSelector(state => state.task);
	const user = useAppSelector(state => state.dataNotRemove.customer);
	const dispatch = useAppDispatch();

	const getTaskData = (payload: TYPE.IGetTaskPayloadType) => {
		dispatch(getTask(payload));
	};
	const updateDataTask = (payload: TYPE.IUpdateTaskPayloadType) => {
		dispatch(updateTask(payload));
	};

	return {
		getTaskData,
		isGettingTask,
		taskData,

		updateDataTask,
		isUpdatingTask,
		user,
	};
};

export default useTask;
