import { useEffect } from 'react';

import { AppState } from 'react-native';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateStatusSupportingBiometric } from 'stores/System';
import { getSupportedBiometryType } from 'utils/biometricAuthentication';

/**
 * Do things that is required for the biometric authentication.
 */
export const BiometricAuthenticationInitializer = () => {
	const dispatch = useAppDispatch();
	const { isSupportedBiometric } = useAppSelector(state => state.system);
	useEffect(() => {
		const subscription = AppState.addEventListener('change', nextAppState => {
			if (nextAppState === 'active') {
				getSupportedBiometryType().then(isSupported => {
					if (!!isSupported !== isSupportedBiometric) dispatch(updateStatusSupportingBiometric(!!isSupported));
				});
			}
		});
		return () => {
			subscription.remove();
		};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [isSupportedBiometric]);

	return null;
};
