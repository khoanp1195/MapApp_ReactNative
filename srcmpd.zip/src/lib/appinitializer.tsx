import React, { useEffect } from 'react';

import { unwrapResult } from '@reduxjs/toolkit';
import useAuthentication from 'hooks/useAuthentication';
import useDidMount from 'hooks/useDidMount';
import { Alert } from 'react-native';
import { getLanguages } from 'react-native-i18n';
import { useAppDispatch, useAppSelector } from 'stores';
import { clearUser, fetchCustomerInformation, updateStatus } from 'stores/Auth';
import { clearCustomer, updateLanguage, updateLogin } from 'stores/DataNotRemove';
import {
	fetchBeanAppStatus,
	fetchBeanWorkflowStatus,
	fetchSettingSystem,
	updateStatusExpiredUserSession,
} from 'stores/System';
import { clearToken, getTokenFromKeyChain } from 'utils/keychain';
import { translate } from 'utils/translate';

/**
 * Do things that is required for the app iniatilly.
 * e.g. take token, fetch user info, etc.
 */
export const AppInitializer: React.FC = () => {
	const dispatch = useAppDispatch();
	const { language } = useAppSelector(state => state.dataNotRemove);

	const { username } = useAppSelector(state => state.dataNotRemove);
	const { isExpiredUserSession } = useAppSelector(state => state.system);
	const { logout } = useAuthentication();

	useEffect(() => {
		dispatch(updateLanguage(language));
	}, []);

	// useDidMount(() => {
	// 	getLanguages().then(languages => {
	// 		console.log('languages', languages);
	// 		if (languages?.[0].substring(0, 2) === 'vi') {
	// 			dispatch(updateLanguage('vi'));
	// 		}
	// 		if (languages?.[0].substring(0, 2) === 'en') {
	// 			dispatch(updateLanguage('en'));
	// 		}
	// 	});
	// });

	// eslint-disable-next-line @typescript-eslint/no-misused-promises
	// useDidMount(async () => {
	// 	try {
	// 		const { accessToken } = await getTokenFromKeyChain();
	// 		if (!accessToken || !username) return;
	// 		dispatch(fetchCustomerInformation())
	// 			.then(() => {
	// 				dispatch(updateStatus('AUTH'));
	// 			})
	// 			.catch(logout);
	// 		dispatch(fetchBeanAppStatus());
	// 		dispatch(fetchBeanWorkflowStatus());
	// 		dispatch(fetchSettingSystem());
	// 	} catch {
	// 		// Error handler
	// 	}
	// });

	useEffect(() => {
		if (!isExpiredUserSession) return;
		(async () => {
			try {
				dispatch(clearUser());
				dispatch(clearCustomer());
				dispatch(updateLogin(false));
				// dispatch(clearNotifications());
				// dispatch(clearSetting());
				await Promise.allSettled([clearToken()]);
				Alert.alert(translate('title_alert_warning'), translate('session_expired'), [
					{ text: translate('ok'), style: 'cancel', onPress: () => dispatch(updateStatusExpiredUserSession(false)) },
				]);
			} catch {
				// Error handler
			}
		})();
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [isExpiredUserSession]);

	return null;
};
