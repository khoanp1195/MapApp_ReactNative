/* eslint-disable @typescript-eslint/restrict-template-expressions */
import { ENDPOINT } from 'http/modules/Request';

import { useMemo, useRef, useState, useEffect } from 'react';

import { FilterValuesType } from 'components/Organisms/TaskFilter';
import { Flag, ViewType } from 'components/Organisms/TaskFilter/constant';
import useDidMount from 'hooks/useDidMount';
import useInfinity from 'hooks/useInfinity';
import { navigate } from 'navigation/RootNavigation';
import { RoutesNames } from 'navigation/RoutesNames';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ITask, ResourcetypeTask } from 'services/Tasks/types';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateStatusDrawer } from 'stores/System';
import dayjs from 'utils/dayjs';
import { translate } from 'utils/translate';

export const useMyRequests = (isFollow: boolean) => {
	const totalPageRef = useRef<number>(0);

	const dispatch = useAppDispatch();
	const dateNow = new Date();
	const date30 = new Date(new Date().setDate(new Date().getDate() - 30));
	const refFilter = useRef(null);
	const { count } = useAppSelector(state => state.count);

	const currentFilterValues = useRef<FilterValuesType>({
		viewType: ViewType[0],
		flag: Flag[0],
		statusGroup: [{ label: translate('flag_all'), value: 0, labelEN: 'All' }],
		fromDate: date30,
		toDate: dateNow,
	});
	const [dataTask, setDattaTask] = useState<Array<ITask>>([]);

	const [isOpenSearch, setOpenSearch] = useState<boolean>(false);
	const [isOpenFilter, setIsOpenFilter] = useState<boolean>(false);

	const { bottom } = useSafeAreaInsets();
	const customerInfo = useAppSelector(state => state.dataNotRemove.customer);
	const { beanAppStatus } = useAppSelector(state => state.system);
	const { language } = useAppSelector(state => state.dataNotRemove);

	const {
		state: { data: dataRes, refreshing, loading, page },
		gotoFirstPage,
		refreshPage,
		fetchMore,
	} = useInfinity<Array<ITask>>(`${ENDPOINT.WORKFLOW}`, {
		size: 10,
		requireAuthentication: true,
		params: {
			func: 'getList',
			data: isFollow ? null : `{"WorkflowID":0,"ViewType":2,"Flag":0,"FromDate":"","ToDate":""}`,
			resourcetype: isFollow ? 'MyFollowItem' : ResourcetypeTask.MYREQUEST,
			lid: language === 'vi' ? 1066 : 1033,
			totalrecord: totalPageRef.current,
		},
		onSuccess: res => {
			if (!res.data) return;
			totalPageRef.current = res.data?.TotalRecord;
		},
	});

	useDidMount(() => gotoFirstPage());

	const handleToggleSearch = () => setOpenSearch(prev => !prev);

	const handleTogleFilter = () => setIsOpenFilter(prev => !prev);

	const handleFillter = (data: FilterValuesType) => {
		refFilter.current = data;
		const { viewType, flag, statusGroup, fromDate, toDate } = data || {};
		totalPageRef.current = 0;
		currentFilterValues.current = data;
		const statusGroupFilter = statusGroup.some(v => v.value === 0)
			? ''
			: `,"StatusGroup":"${statusGroup.map(v => v.value).join(',')}"`;
		setIsOpenFilter(false);
		gotoFirstPage({
			params: {
				func: 'getList',
				data: isFollow
					? `{"FromDate":"${fromDate?.toISOString()}","ToDate":"${toDate?.toISOString()}"${statusGroupFilter}}`
					: `{"WorkflowID":0,"ViewType":${viewType?.value},"Flag":${
							flag?.value
					  }${statusGroupFilter},"FromDate":"${fromDate?.toISOString()}","ToDate":"${toDate?.toISOString()}"}`,
				resourcetype: isFollow ? 'MyFollowItem' : ResourcetypeTask.MYREQUEST,
				lid: language === 'vi' ? 1066 : 1033,
				totalrecord: totalPageRef.current,
			},
		});
	};

	const handleEndReached = (info: { distanceFromEnd: number }) => {
		if (Number(info.distanceFromEnd) > 0) return;
		fetchMore();
	};

	const customizeTasks = useMemo(() => {
		const tasksObj: {
			today: Array<ITask>;
			yesterday: Array<ITask>;
			beforeYesterday: Array<ITask>;
		} = {
			today: [],
			yesterday: [],
			beforeYesterday: [],
		};
		const yesterday = new Date();
		yesterday.setDate(yesterday.getDate() - 1);
		if (!dataTask?.length) return [];
		// eslint-disable-next-line no-unsafe-optional-chaining
		for (const n of dataTask) {
			if (dayjs(n.Created).isSame(new Date(), 'day')) {
				tasksObj.today.push({ ...n, typeCurrent: 'today' });
			} else if (dayjs(n.Created).isSame(yesterday, 'day')) {
				tasksObj.yesterday.push({ ...n, typeCurrent: 'yesterday' });
			} else if (dayjs(n.Created).isBefore(yesterday, 'day')) {
				tasksObj.beforeYesterday.push({ ...n, typeCurrent: 'older' });
			}
		}
		return tasksObj;
	}, [dataTask]);

	const handleOpenDrawer = () => dispatch(updateStatusDrawer(true));

	const checkRefresh = () => {
		if (refFilter.current) {
			handleFillter(refFilter.current);
		} else {
			refreshPage();
		}
	};

	const onUpdateTask = () => {
		checkRefresh();
	};

	useEffect(() => {
		if (totalPageRef.current) {
			checkRefresh();
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [language]);

	useEffect(() => {
		if (dataRes?.Data?.length) {
			setDattaTask(dataRes.Data);
		}
	}, [dataRes]);

	const handleNavigateToDetail = (item: any) =>
		navigate(RoutesNames.TaskDetail, { item, onUpdateTask, onUpdateFollow });

	const updateRead = (ID: number) => {
		const cloneData = [...dataTask];
		const index = dataTask.findIndex(task => task.ID === ID);
		cloneData[index] = { ...cloneData[index], Read: true };
		setDattaTask(cloneData);
	};

	const onUpdateFollow = (ID: number, isFollowed: boolean | number) => {
		if (isFollow) {
			setDattaTask(dataTask.filter(task => task.ID !== ID));
			return;
		}
		const cloneData = [...dataTask];
		const index = dataTask.findIndex(task => task.ID === ID);
		cloneData[index] = { ...cloneData[index], IsFollow: isFollowed ? 1 : 0 };
		setDattaTask(cloneData);
	};

	return {
		page,
		bottom,
		dataRes,
		loading,
		language,
		refreshing,
		isOpenSearch,
		customerInfo,
		customizeTasks,
		beanAppStatus,
		currentFilter: currentFilterValues.current,
		isOpenFilter,
		CountMyFollowItem: count?.CountMyFollowItem,
		refreshPage: checkRefresh,
		handleFillter,
		handleEndReached,
		handleTogleFilter,
		handleOpenDrawer,
		handleToggleSearch,
		handleNavigateToDetail,
		updateRead,
		onUpdateFollow,
	};
};
