import React, { useCallback, useState } from 'react';

import { Text, TextInput } from '@react-native-material/core';
import { useRoute } from '@react-navigation/native';
import { EmptyState } from 'components/Atoms/EmptyState';
import { Icon } from 'components/Atoms/Icon';
import { Loading } from 'components/Atoms/Loading';
import { Header } from 'components/Organisms/Header';
import { TaskCard } from 'components/Organisms/TaskCard';
import { IconWrapper } from 'components/Organisms/TaskCard/styles';
import { TaskFilter } from 'components/Organisms/TaskFilter';
import { COLORS, ICONS, defaultImgUri, imgDummy } from 'config';
import { RoutesNames } from 'navigation/RoutesNames';
import { ActivityIndicator, KeyboardAvoidingView, Platform, RefreshControl, SectionList, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Assigned, ResourcetypeTask } from 'services/Tasks/types';
import { translate } from 'utils/translate';

import { Container, Leading, TextCustom, Trailing, Wrapper, styles } from './styles';
import { useMyRequests } from './useMyRequests';

export const MyRequestsScreen = () => {
	const route = useRoute();
	const from = route.params?.from;
	const isFollow = from === RoutesNames.Follow;
	const {
		page,
		bottom,
		dataRes,
		loading,
		language,
		refreshing,
		customizeTasks,
		isOpenFilter,
		customerInfo,
		currentFilter,
		isOpenSearch,
		beanAppStatus,
		CountMyFollowItem,
		refreshPage,
		handleFillter,
		handleEndReached,
		handleOpenDrawer,
		handleTogleFilter,
		handleToggleSearch,
		handleNavigateToDetail,
		updateRead,
	} = useMyRequests(isFollow);

	const [valid, setValid] = useState<boolean>(true);

	const renderTitle = useCallback(
		(title: string) => {
			return (
				<Wrapper mLeft={15} mTop={14} mBottom={14}>
					<TextCustom allowFontScaling={false} fw={700} fs={15} lh={20} color={COLORS.darkJungleGreen}>
						{translate(title)}
					</TextCustom>
				</Wrapper>
			);
		},
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[language],
	);

	const renderLeading = useCallback(
		() => (
			<Leading onPress={handleOpenDrawer}>
				<Icon src={ICONS.icMenu} width={16} height={16} tintColor="rgba(0, 0, 0, 1)" onPress={handleOpenDrawer} />

				{/* <IconWrapper
					onError={() => setValid(false)}
					source={{ uri: valid ? customerInfo?.ImagePath || imgDummy : imgDummy }}
					style={{ marginRight: 15, alignSelf: 'baseline' }}
				/> */}
				{/* <Avatar size={40} image={{ uri: customerInfo?.ImagePath }} style={{ marginRight: 15 }} /> */}
				<Text style={{ fontSize: 20, fontWeight: '700', marginLeft: 10 }}>
					{/* {translate('my_request')} */}
					{translate('follow')}
					{/* {isFollow && (
						<Text style={{ color: 'rgba(255, 122, 58, 1)', fontWeight: '400' }}> ({CountMyFollowItem})</Text>
					)} */}
				</Text>
			</Leading>
		),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[customerInfo?.ImagePath, valid, language, CountMyFollowItem],
	);

	return (
		<SafeAreaView style={{ flex: 1 }} edges={['top']}>
			<KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
				<Header
					leading={renderLeading()}
					trailing={
						<Trailing>
							<Icon
								style={{ marginRight: 16 }}
								src={ICONS.icFilter}
								tintColor={isOpenFilter ? COLORS.pastelGreen : COLORS.davyGrey}
								width={18}
								height={18}
								onPress={handleTogleFilter}
							/>
							<Icon
								src={ICONS.icSearchAll}
								tintColor={isOpenSearch ? COLORS.trueBlue : COLORS.gray}
								width={24}
								height={24}
								onPress={handleToggleSearch}
							/>
						</Trailing>
					}
				/>
				{isOpenSearch && (
					<TextInput
						label=""
						// labelStyle={{ color: COLORS.white }}
						placeholderTextColor={COLORS.davyGrey}
						placeholder={translate('search_placeholder')}
						color={COLORS.davyGrey}
						maxLength={255}
						variant="outlined"
						isOverWrite
						styleCustom={{
							borderRadius: 5,
							borderWidth: 0,
						}}
						inputStyle={{
							color: COLORS.davyGrey,
							backgroundColor: COLORS.whiteSmoke,
							marginHorizontal: 5,
							borderRadius: 5,
						}}
					/>
				)}
				{isOpenFilter ? (
					<TaskFilter
						onApply={handleFillter}
						type={ResourcetypeTask.MYREQUEST}
						currentFilter={currentFilter}
						isFollow={isFollow}
					/>
				) : (
					<Container>
						{!customizeTasks && page === 0 && loading ? (
							<Loading />
						) : (
							<SectionList
								sections={
									!customizeTasks
										? []
										: [
											{ title: 'today', data: customizeTasks?.today || [] },
											{ title: 'yesterday', data: customizeTasks?.yesterday || [] },
											{ title: 'older', data: customizeTasks?.beforeYesterday || [] },
										]
								}
								renderSectionHeader={({ section: { title, data } }) => (data?.length > 0 ? renderTitle(title) : null)}
								refreshControl={
									<RefreshControl refreshing={refreshing} onRefresh={refreshPage} tintColor={COLORS.trueBlue} />
								}
								contentContainerStyle={styles.listContentContainer}
								keyExtractor={({ ID }) => ID.toString()}
								showsVerticalScrollIndicator={false}
								onEndReached={handleEndReached}
								ListFooterComponent={
									!refreshing && dataRes?.Data && loading ? (
										<Wrapper style={{ backgroundColor: COLORS.whiteSmoke }} mBottom={bottom} mTop={24}>
											<ActivityIndicator size="small" color={COLORS.trueBlue} />
										</Wrapper>
									) : null
								}
								renderItem={({ item }) => {
									const {
										Read,
										Content,
										DueDate,
										IsFollow,
										Workflow,
										Created,
										FileCount,
										StatusGroup,
										AssignedToInfo,
										typeCurrent,
										ID,
										ResourceCategoryId,
									} = item || {};
									const statusGroupItem = beanAppStatus?.find(v => v.ID === StatusGroup);
									const isTask = ResourceCategoryId === 16;
									const {
										ImagePath = '',
										DefaultImagePath = '',
										Name,
										NumExpand,
									} = JSON.parse(AssignedToInfo || '{}') as Assigned;
									return (
										<View style={{ backgroundColor: Read ? COLORS.white : COLORS.aliceBlue }}>
											<TaskCard
												type={ResourcetypeTask.MYREQUEST}
												assignedToName={Name || ''}
												numExpand={NumExpand || 0}
												avatar={ImagePath || defaultImgUri()}
												defaultAvatar={DefaultImagePath || defaultImgUri()}
												status={StatusGroup}
												statusTitle={language === 'vi' ? statusGroupItem?.Title : statusGroupItem?.TitleEN}
												fileCount={!!FileCount}
												isFollow={!!IsFollow}
												title={Content}
												time={Created}
												description={Workflow}
												expire={DueDate}
												isTask={isTask}
												onPress={() => {
													handleNavigateToDetail(item);
													if (!Read) updateRead(ID);
												}}
												typeCurrent={typeCurrent}
											/>
										</View>
									);
								}}
								ListEmptyComponent={<EmptyState />}
							/>
						)}
					</Container>
				)}
			</KeyboardAvoidingView>
		</SafeAreaView>
	);
};
