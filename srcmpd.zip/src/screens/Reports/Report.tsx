import React, { useState } from 'react';

import { COLORS } from 'config';
import { View, FlatList, TouchableOpacity, Animated, StyleSheet, Text } from 'react-native';
import { translate } from 'utils/translate';

const AnimatedFlatList = Animated.createAnimatedComponent(FlatList);

const Report = () => {
	const [selectedItemIndex, setSelectedItemIndex] = useState(2);
	const animatedValue = new Animated.Value(-1);

	const data = [
		{ id: 1, name: 'Item 1' },
		{ id: 2, name: 'Item 2' },
		{ id: 3, name: 'Item 3' },
		// Add more items as needed
	];

	const handleItemPress = index => {
		setSelectedItemIndex(index);
		Animated.timing(animatedValue, {
			toValue: index,
			duration: 200,
			useNativeDriver: true,
		}).start();
	};

	const renderItem = ({ item, index }) => {
		const animatedStyle = {
			opacity: Animated.divide(animatedValue, data.length - 1).interpolate({
				inputRange: [index - 1, index, index + 1],
				outputRange: [0.4, 1, 0.4],
			}),
		};

		return (
			<TouchableOpacity onPress={() => handleItemPress(index)}>
				<Animated.View style={[styles.item, animatedStyle]}>
					<Text style={styles.itemText}>{item.name}</Text>
				</Animated.View>
			</TouchableOpacity>
		);
	};

	return (
		<View style={styles.container}>
			<Text style={{ fontStyle: 'italic', color: COLORS.textGrey }}>{translate('feature_message')}</Text>
			{/* <AnimatedFlatList
				data={data}
				renderItem={renderItem}
				keyExtractor={item => item.id.toString()}
				extraData={selectedItemIndex}
			/> */}
		</View>
	);
};
export default Report;

const styles = StyleSheet.create({
	container: {
		flex: 1,
		alignItems: 'center',
		justifyContent: 'center',
	},
	item: {
		padding: 16,
		borderBottomWidth: 1,
		borderBottomColor: '#ccc',
	},
	itemText: {
		fontSize: 16,
	},
});
