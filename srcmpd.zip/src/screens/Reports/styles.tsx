import { COLORS } from 'config';
import { Dimensions, StyleSheet } from 'react-native';

const { width } = Dimensions.get('window');

export const styles = StyleSheet.create({
	container: {
		backgroundColor: COLORS.white,
	},
	tabViewContainer: {
		backgroundColor: COLORS.white,
	},
	tabViewContainerNonAutoWidth: {
		// paddingHorizontal: 15,
		marginTop: -15,
	},
	tabView: {
		// height: 36,
		justifyContent: 'center',
		alignItems: 'center',
		paddingVertical: 6,
		paddingHorizontal: 12,
		maxWidth: width / 2,
		backgroundColor: COLORS.trueBlue,
		borderRadius: 18,
	},
	tabActive: {
		borderBottomWidth: 3,
	},
	header: {
		marginTop: 0,
	},
	scrollViewContainer: {
		justifyContent: 'space-around',
		flex: 1,
	},
	shadow: {
		shadowColor: COLORS.spaceCadet,
		shadowOffset: {
			width: 0,
			height: 8,
		},
		shadowOpacity: 0.08,
		shadowRadius: 5,
		elevation: 10,
		zIndex: 2,
	},
	tabViewAutoWidth: {
		maxWidth: undefined,
		marginRight: 20,
	},
	tabViewAutoWidthFirstItem: {
		marginLeft: 20,
	},
	unusePaddingScroll: {
		maxWidth: undefined,
		paddingHorizontal: 20,
	},
	itemTab: {
		backgroundColor: COLORS.trueBlue,
		flexDirection: 'row',
		borderRadius: 18,
		margin: 15,
	},
	contentTabView: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
		marginRight: 15,
	},
});
