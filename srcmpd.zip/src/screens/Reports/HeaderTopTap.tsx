import React, { useMemo } from 'react';

import { Text } from '@react-native-material/core';
import { MaterialTopTabBarProps } from '@react-navigation/material-top-tabs';
import en from 'assets/i18n/en';
import { Header } from 'components/Organisms/Header';
import { COLORS, ICONS } from 'config';
import { navigate } from 'navigation/RootNavigation';
import { ScrollView, TouchableOpacity, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppSelector } from 'stores';
import { translate } from 'utils/translate';

import { styles } from './styles';

interface Props extends MaterialTopTabBarProps {
	nameHeader?: string;
	customHeader?: React.ReactNode;
	backBehaviorScreen?: string;
	fullwidth?: boolean;
	bottomView?: React.ReactNode;
	textActiveColor?: string;
	useAutoWidth?: boolean;
	useShadow?: boolean;
	unUsePaddingScroll?: boolean;
	trailing?: React.ReactNode;
	countTask?: { my_task?: number; my_request?: number };
}

export const MaterialTopTabsNavigator: React.FC<Props> = ({
	navigation,
	state,
	nameHeader,
	customHeader,
	backBehaviorScreen,
	fullwidth,
	bottomView,
	trailing,
	textActiveColor,
	useAutoWidth = false,
	useShadow = false,
	unUsePaddingScroll = false,
	countTask = {},
}): React.ReactElement => {
	const onPressLeftIcon = () => {
		if (!backBehaviorScreen) return;
		navigate(backBehaviorScreen);
	};

	const tabViewStyle = useMemo(() => {
		return StyleSheet.create({
			focusStyle: {
				backgroundColor: COLORS.white,
				borderRadius: 18,
				borderWidth: 1,
				borderColor: COLORS.trueBlue,
			},
		});
	}, []);

	const count = useAppSelector(state => state.count.count);

	const _countTask = {
		my_task: count?.CountMyTask || 0,
		my_request: count?.CountMyRequest || 0,
	};

	const ROUTE = [state.routes[0], {}, state.routes[1]];

	return (
		<SafeAreaView edges={['top']}>
			<View>
				<ScrollView
					// style={[styles.tabViewContainer]}
					// contentContainerStyle={[fullwidth && styles.scrollViewContainer]}
					horizontal
					showsHorizontalScrollIndicator={false}
					bounces={false}
				/>
				<View style={{ flexDirection: 'row', marginVertical: 20, marginHorizontal: 24 }}>
					{ROUTE.map((route, index) => {
						if (!route?.name)
							return (
								<View
									style={{
										height: '100%',
										width: 2,
										backgroundColor: 'rgba(217, 217, 217, 1)',
										paddingVertical: -5,
										marginHorizontal: 10,
									}}
								/>
							);
						return (
							<TouchableOpacity>
								<Text style={{ fontSize: 20, fontWeight: '700' }}>{translate(route.name)}</Text>
							</TouchableOpacity>
						);
					})}
				</View>
				{trailing}
			</View>
			{bottomView}
		</SafeAreaView>
	);
};

MaterialTopTabsNavigator.defaultProps = {
	nameHeader: '',
	customHeader: null,
	backBehaviorScreen: undefined,
	fullwidth: false,
	bottomView: null,
	trailing: null,
};
