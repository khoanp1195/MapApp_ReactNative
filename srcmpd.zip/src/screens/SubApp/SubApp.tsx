import React from 'react';
import { Text } from 'react-native';
import { View } from 'react-native';

const SubApp = () => {
	return (
		<View>
			<Text>alo</Text>
		</View>
	);
};

export default SubApp;
