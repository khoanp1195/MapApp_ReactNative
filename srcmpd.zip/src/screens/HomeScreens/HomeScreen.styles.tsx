import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
	containerLeading: { flexDirection: 'row', alignItems: 'center' },
	name: { color: 'rgba(15, 23, 42, 1)', fontSize: 16, fontWeight: '700' },
	position: { color: 'rgba(71, 85, 105, 1)', fontSize: 14, fontWeight: '400' },
	iconScan: { marginHorizontal: 16 },
	header: {
		// paddingHorizontal: 10,
		backgroundColor: 'white',
		shadowColor: '#000',
		shadowOffset: {
			width: 0,
			height: 2,
		},
		shadowRadius: 2,
		zIndex: 99,
		paddingBottom: 8,
	},
});
