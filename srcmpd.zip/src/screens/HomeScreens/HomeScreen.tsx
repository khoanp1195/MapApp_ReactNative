import React, { useEffect, useRef, useState } from 'react';

import { useIsFocused } from '@react-navigation/native';
import ChartReport from 'components/HomeScreens/ChartReport';
import CountBar from 'components/HomeScreens/CountBar';
import FavoriteApps from 'components/HomeScreens/FavoriteApps';
import HeaderHome from 'components/HomeScreens/HeaderHome';
import { COLORS } from 'config';
import SyncForm from 'database/SyncForm';
import useSystem from 'hooks/useSystem';
import { NativeScrollEvent, NativeSyntheticEvent, RefreshControl, View } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { useAppDispatch } from 'stores';
import { fetchCount } from 'stores/Count';
import { fetchBeanAppStatus, fetchBeanWorkflowStatus } from 'stores/System';

const HomeScreen = () => {
	const dispactch = useAppDispatch();
	useSystem();
	const refScrollView = useRef<ScrollView | null>(null);

	const refHeader = useRef<{ handleScroll: (event: NativeSyntheticEvent<NativeScrollEvent>) => void } | null>();

	const isFocused = useIsFocused();
	const onScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => refHeader.current?.handleScroll(event);

	const [refreshing, setrefreshing] = useState(false);

	useEffect(() => {
		refScrollView.current?.scrollTo({
			y: 0,
			animated: true,
		});
	}, [isFocused]);

	const refreshPage = () => {
		setrefreshing(true);
	};

	const updateRefreshing = () => {
		setrefreshing(false);
	};

	useEffect(() => {
		dispactch(fetchCount());
	}, []);

	return (
		<View style={{ flex: 1 }}>
			<HeaderHome ref={refHeader} refreshing={refreshing} />
			<ScrollView
				ref={refScrollView}
				showsVerticalScrollIndicator={false}
				scrollEventThrottle={16}
				onScroll={onScroll}
				refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refreshPage} tintColor={COLORS.trueBlue} />}>
				<CountBar />
				<ChartReport refreshing={refreshing} updateRefreshing={updateRefreshing} />
				<FavoriteApps refreshing={refreshing} updateRefreshing={updateRefreshing} />
				<SyncForm />
			</ScrollView>
		</View>
	);
};

export default HomeScreen;
