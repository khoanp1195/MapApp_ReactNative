/* eslint-disable react/no-unstable-nested-components */
/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useRef, useState } from 'react';

import { useIsFocused, useNavigation, useRoute } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { ShowLoading } from 'components/Atoms/Loading/LoadingGlobal';
import FImage from 'components/Organisms/FImage/FImage';
import { ItemComment } from 'components/WorkflowDetails/Comments/Comment';
import { ICONS } from 'config';
import {
	View,
	Text,
	KeyboardAvoidingView,
	TouchableOpacity,
	TextInput,
	FlatList,
	Alert,
	Platform,
	ScrollView,
} from 'react-native';
import ReactNativeBlobUtil from 'react-native-blob-util';
import DocumentPicker from 'react-native-document-picker';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppDispatch, useAppSelector } from 'stores';
import { getComment, postComment, postLikeComment, updateComment } from 'stores/Workflows/sliceWorkflow';
import { IComment } from 'stores/Workflows/types';
import { getIconFile } from 'utils/functions';
import { translate } from 'utils/translate';

const HeaderReply = ({ Content }: { Content: string }) => {
	const insets = useSafeAreaInsets();
	const navigation = useNavigation();

	return (
		<View
			style={{
				flexDirection: 'row',
				shadowColor: '#000',
				shadowOffset: {
					width: 0,
					height: 2,
				},
				shadowOpacity: 0.1,
				shadowRadius: 2,

				elevation: 5,
				backgroundColor: 'white',
				paddingTop: insets.top,
				paddingBottom: 10,
				paddingHorizontal: 16,
			}}>
			<View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
				<Icon
					src={ICONS.icArrowMenu}
					width={24}
					height={24}
					tintColor="rgba(0, 0, 0, 1)"
					onPress={() => navigation.goBack()}
				/>
				<Text numberOfLines={1} style={{ fontSize: 16, fontWeight: '700', marginLeft: 12, color: 'rgba(0, 0, 0, 1)' }}>
					{translate('comment')}
					{/* <Text style={{ color: 'rgba(157, 157, 157, 1)' }}> / {Content}</Text> */}
				</Text>
			</View>
		</View>
	);
};

const Reply = () => {
	const dispatch = useAppDispatch();
	const route = useRoute();

	const refScrollView = useRef();

	const refInput = useRef<TextInput>(null);
	const refValueInput = useRef<string>('');
	const refComment = useRef<{ ParentCommentId: string; Content: string }>();
	const refResourceId = useRef('');

	const { rid, Content, dataFw, isAttach } = route.params || {};

	const comment = useAppSelector(store => store.workflow.comments);
	const details = useAppSelector(store => store.workflow.details);
	const user = useAppSelector(store => store.dataNotRemove.customer);

	const { OtherResourceId } = details.FormConfig || {};

	const [comments, setComments] = useState([]);
	const [isCommentChild, setIsCommentChild] = useState(false);
	const [file, setFile] = useState<{ Name: string; Base64: string }[]>([]);

	const fetchSuccess = (res: IComment[]) => {
		const cloneData = JSON.parse(JSON.stringify(res));

		// Tạo một đối tượng theo ID để tìm kiếm nhanh
		const lookup = {};
		cloneData?.forEach((item: IComment) => {
			lookup[item.ID] = item;
			item.children = [];
		});
		const result = [];

		cloneData?.forEach((item: { ParentCommentId: string | number }) => {
			const parent = lookup[item.ParentCommentId];
			if (parent) {
				// Thêm mục con vào mục cha
				parent.children.push(item);
			} else {
				// Nếu không có mục cha, đây là một mục cấp cao nhất
				result.push(item);
			}
		});

		setComments(result);
	};

	useEffect(() => {
		if (comment?.length) {
			fetchSuccess(comment);
		}
	}, [comment]);

	const isFocus = useIsFocused();

	useEffect(() => {
		if (refInput.current && isFocus && !isAttach) {
			setTimeout(() => {
				refInput.current?.focus();
			}, 500);
		}
	}, [route.params]);

	const onPressAddFile = () => {
		DocumentPicker.pickSingle().then(res => {
			const realURI = Platform.select({
				android: res.uri,
				ios: decodeURIComponent(res.uri),
			});

			ReactNativeBlobUtil.fs.readFile(realURI.replace('file://', ''), 'base64').then(data => {
				setFile([...file, { Name: res?.name || '', Base64: data }]);
			});
			// refInput.current?.focus();
		});
	};

	useEffect(() => {
		if (isAttach) {
			setTimeout(() => {
				onPressAddFile();
			}, 500);
		}
	}, [isAttach]);

	useEffect(() => {
		if (dataFw) {
			refComment.current = dataFw;
			setIsCommentChild(!isCommentChild);
			// setTimeout(() => {
			// 	refInput.current?.focus();
			// }, 500);
		}
	}, [dataFw]);

	const onComment = (data: {
		ParentCommentId: string;
		CID: number;
		index: number;
		PositionName: string;
		DefaultImagePath: string;
		Content: string;
	}) => {
		refComment.current = data;
		refScrollView.current?.scrollTo({
			y: 0,
			animated: true,
		});
		setFile([]);
		setIsCommentChild(true);
		// if (!isCommentChild) {
		refInput.current?.focus();
		// }
	};

	const onBlur = () => {
		// if (isCommentChild) {
		// 	setIsCommentChild(false);
		// }
	};

	const commentSuccess = (res: BaseAPIResponse<{ ResourceId: string }>) => {
		const { ResourceId } = res?.data || {};
		refResourceId.current = ResourceId;
		refComment.current = null;
		refValueInput.current = '';
		refInput.current?.setNativeProps({ text: '' });
		setFile([]);
		if (isCommentChild) setIsCommentChild(false);
		dispatch(
			getComment({
				params: {
					rid,
					OtherResourceId: OtherResourceId || refResourceId.current,
					isWorkflow: true,
				},
				success: () => {
					ShowLoading(false);
				},
			}),
		);
	};

	const onSendComment = () => {
		const message = isCommentChild ? translate('replyCommentEmpty') : translate('commentEmpty');
		const useFiles = !isCommentChild ? !file?.length : true;
		if (!refValueInput.current && useFiles) return Alert.alert(message);
		if (file?.length) {
			ShowLoading(true);
		}
		dispatch(
			postComment({
				params: {
					rid,
					OtherResourceId: OtherResourceId || refResourceId.current,
					ParentCommentId: refComment.current?.ParentCommentId || '',
					Content: refValueInput.current,
					Files: file,
					isWorkflow: true,
				},
				success: commentSuccess,
			}),
		);
	};

	const likeSuccess = (commentid: string, IsLiked: number, LikeCount: number) => {
		const clone: IComment[] = JSON.parse(JSON.stringify(comment));
		const indexItem = clone.findIndex(element => element.ID === commentid);
		clone[indexItem] = {
			...clone[indexItem],
			IsLiked: IsLiked ? 0 : 1,
			LikeCount: IsLiked ? LikeCount - 1 : LikeCount + 1,
		};
		dispatch(
			updateComment({
				func: 'recall',
				comment: clone,
			}),
		);
	};

	const onPressLike = (commentid: string, IsLiked: number, LikeCount: number) => {
		dispatch(
			postLikeComment({
				params: {
					action: IsLiked ? 'UNLIKE' : 'LIKE',
					rid,
					commentid,
					isWorkflow: true,
				},
				success: () => likeSuccess(commentid, IsLiked, LikeCount),
			}),
		);
	};

	const onPressClose = () => {
		setTimeout(() => {
			refInput.current?.setNativeProps({ text: '' });
		}, 100);
		setIsCommentChild(false);
		setFile([]);
		refInput.current?.blur();
	};

	const onChangeText = (t: string) => {
		refValueInput.current = t;
	};

	const onDeletAttach = (index: number) => {
		setFile(file.filter((f, i) => i !== index));
	};

	return (
		<View style={{ flex: 1 }}>
			<HeaderReply Content={Content} />
			<ScrollView
				ref={refScrollView}
				style={{ flex: 1 }}
				showsVerticalScrollIndicator={false}
				// keyboardDismissMode="on-drag"
				keyboardShouldPersistTaps="handled">
				<KeyboardAvoidingView>
					<View
						style={{
							flexDirection: 'row',
							margin: 16,
						}}>
						<FImage SW={32} mh={0} mt={6} ImagePath={user?.ImagePath} DefaultImagePath={user?.DefaultImagePath} />
						<View
							style={{
								borderWidth: 1,
								borderColor: 'rgba(157, 157, 157, 1)',
								borderRadius: 8,
								flex: 1,
								marginLeft: 8,
								padding: 11,
								justifyContent: 'space-between',
								minHeight: isCommentChild ? 160 : 100,
								// maxHeight: 400,
							}}>
							{isCommentChild && (
								<View
									style={{
										backgroundColor: 'rgba(240, 240, 240, 1)',
										borderRadius: 8,
										paddingVertical: 12,
										paddingHorizontal: 16,
									}}>
									<Text numberOfLines={1} style={{ color: '#7B7B7B' }}>
										{refComment.current?.Content}
									</Text>
								</View>
							)}
							<TextInput
								ref={refInput}
								multiline
								placeholder={translate('EnterComment')}
								style={{ minHeight: 70, maxHeight: 300 }}
								onBlur={onBlur}
								onChangeText={onChangeText}
							/>
							<View style={{ overflow: 'hidden', width: '100%', marginVertical: 16 }}>
								{file?.map((attach: any, key: any) => {
									const splitTitle = attach?.Name?.split('.');
									const ExpFile = splitTitle?.length > 1 ? splitTitle?.[splitTitle?.length - 1] : '';
									return (
										<TouchableOpacity
											key={key?.toString()}
											style={{ flexDirection: 'row', alignItems: 'center', marginVertical: 4 }}>
											<Icon src={getIconFile(ExpFile)} width={18} height={18} />
											<Text numberOfLines={1} style={{ paddingLeft: 6, flex: 1 }}>
												{attach?.Name}
											</Text>
											<Icon src={ICONS.icCancelGrey} width={18} height={18} onPress={() => onDeletAttach(key)} />
										</TouchableOpacity>
									);
								})}
							</View>
							<View style={{ flexDirection: 'row', alignItems: 'center' }}>
								<View style={{ flex: 1 }}>
									{!isCommentChild && (
										<Icon
											src={ICONS.icLink}
											width={20}
											height={20}
											tintColor="rgba(0, 0, 0, 1)"
											onPress={onPressAddFile}
										/>
									)}
								</View>
								{isCommentChild && (
									<TouchableOpacity
										onPress={onPressClose}
										style={{
											borderWidth: 0.8,
											paddingVertical: 6.1,
											paddingHorizontal: 16,
											borderRadius: 12,
											marginRight: 4,
											borderColor: 'rgba(194, 194, 194, 1)',
										}}>
										<Text style={{ fontSize: 12, fontWeight: '600' }}>{translate('close')}</Text>
									</TouchableOpacity>
								)}
								<TouchableOpacity
									onPress={onSendComment}
									style={{
										backgroundColor: 'rgba(0, 95, 212, 1)',
										paddingVertical: 7,
										paddingHorizontal: 16,
										borderRadius: 12,
									}}>
									<Text style={{ fontSize: 12, fontWeight: '600', color: 'white' }}>{translate('sendComment')}</Text>
								</TouchableOpacity>
							</View>
						</View>
					</View>
					<FlatList
						scrollEnabled={false}
						showsVerticalScrollIndicator={false}
						keyboardDismissMode="on-drag"
						contentContainerStyle={{ marginHorizontal: 16 }}
						data={comments}
						keyExtractor={(item, index) => index?.toString()}
						renderItem={({ item, index }) => (
							<ItemComment item={item} index={index} onComment={onComment} onPressLike={onPressLike} />
						)}
						ListFooterComponent={() => {
							return <View style={{ height: 50 }} />;
						}}
					/>
				</KeyboardAvoidingView>
			</ScrollView>
		</View>
	);
};

export default Reply;
