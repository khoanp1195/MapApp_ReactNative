import React, { useEffect, useState, useRef } from 'react';

import { useRoute } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import LoadingRef from 'components/Atoms/Loading/LoadingRef';
import FImage from 'components/Organisms/FImage/FImage';
import { COLORS, ICONS } from 'config';
import useTask from 'hooks/useTask';
import moment from 'moment';
import {
	View,
	Text,
	ScrollView,
	FlatList,
	TouchableOpacity,
	KeyboardAvoidingView,
	TextInput,
	Keyboard,
	LayoutAnimation,
	Dimensions,
} from 'react-native';
import ReactNativeBlobUtil from 'react-native-blob-util';
import DocumentPicker from 'react-native-document-picker';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateOtherResourceId } from 'stores/TaskDetails';
import { fetchAddComment, fetchComment, fetchLikeComment } from 'stores/TaskDetails/thunks';

const windowWidth = Dimensions.get('window').width;

interface ItemProps {
	item: {
		ID: string;
		CID: number;
		Content: string;
		Image: string;
		ResourceId: string;
		ResourceCategoryId: number;
		ResourceSubCategoryId: number;
		LikeCount: number;
		CommentCount: number;
		ParentCommentId: any;
		Created: string;
		IsLiked: number;
		Name: string;
		ImagePath: string;
		DefaultImagePath: string;
		PositionName: string;
		children: any[];
	};
	index: number;
	onComment: (e: any) => void;
	onPressLike: (e: any) => void;
}

const ItemComment = ({ item, index, onComment, onPressLike }: ItemProps) => {
	const {
		ImagePath,
		DefaultImagePath,
		Name,
		PositionName,
		Created,
		Content,
		children,
		LikeCount,
		Image,
		CID,
		IsLiked,
		ID,
		ParentCommentId,
	} = item;
	const dateTime = Created ? moment(new Date(Created)).format('DD/MM/YY hh:mm') : '';
	const Attach = JSON.parse(Image || '[]');
	return (
		<View>
			<View style={{ flexDirection: 'row' }}>
				<FImage ImagePath={ImagePath} DefaultImagePath={DefaultImagePath} />
				<View style={{ flex: 1 }}>
					<View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
						<Text style={{ fontSize: 16, fontWeight: '700' }}>{Name || PositionName}</Text>
						<Text style={{ fontSize: 12, color: 'rgba(94, 94, 94, 1)' }}>{dateTime}</Text>
					</View>
					<View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
						<Text style={{ fontSize: 12, color: 'rgba(94, 94, 94, 1)', paddingVertical: 8 }}>{PositionName}</Text>
						<View style={{ flexDirection: 'row' }}>
							{/* <View style={{ flexDirection: 'row', alignItems: 'center', marginRight: 10 }}>
								<Icon src={ICONS.icFile} width={20} height={20} />
								<Text style={{ marginLeft: 4 }}>3</Text>
							</View> */}
							{!!LikeCount && (
								<View style={{ flexDirection: 'row', alignItems: 'center' }}>
									<Icon src={ICONS.icLike} width={20} height={20} />
									<Text style={{ marginLeft: 4 }}>{LikeCount}</Text>
								</View>
							)}
						</View>
					</View>
					<View>
						<Text style={{ fontSize: 14, fontWeight: '400', color: 'rgba(0, 0, 0, 1)' }}>{Content}</Text>
						{Attach?.map((attach: any, key: any) => {
							return (
								<TouchableOpacity key={key.toString()}>
									<Text style={{ color: 'rgba(0, 95, 212, 1)', paddingVertical: 2 }}>{attach?.Title}</Text>
								</TouchableOpacity>
							);
						})}
						<View style={{ flexDirection: 'row', alignItems: 'center' }}>
							<TouchableOpacity
								onPress={() => {
									onPressLike(ID, IsLiked, LikeCount, index);
								}}>
								<Text style={{ fontSize: 12, color: 'rgba(94, 94, 94, 1)', paddingVertical: 8 }}>
									{IsLiked ? 'Bỏ Thích' : 'Thích'}
								</Text>
							</TouchableOpacity>
							<TouchableOpacity
								onPress={() =>
									onComment({ ParentCommentId: ParentCommentId || ID, CID, index, PositionName, DefaultImagePath })
								}>
								<Text style={{ fontSize: 12, color: 'rgba(94, 94, 94, 1)', paddingVertical: 8 }}> - Trả Lời</Text>
							</TouchableOpacity>
						</View>
						<View style={{ paddingTop: 20 }}>
							{children?.map((e, key) => {
								const {
									Name,
									PositionName,
									ImagePath,
									DefaultImagePath,
									Content,
									LikeCount,
									CID,
									IsLiked,
									Created,
									ID,
									ParentCommentId,
								} = e;
								const dateTimeChil = Created ? moment(new Date(Created)).format('DD/MM/YY hh:mm') : '';
								return (
									<View key={key?.toString()} style={{ flexDirection: 'row', paddingBottom: 18 }}>
										<FImage ImagePath={ImagePath} DefaultImagePath={DefaultImagePath} />
										<View style={{ flex: 1, justifyContent: 'center' }}>
											<View
												style={{
													flexDirection: 'row',
													justifyContent: 'space-between',
													flex: 1,
													alignItems: 'center',
													overflow: 'hidden',
												}}>
												<Text numberOfLines={1} style={{ fontSize: 16, fontWeight: '700', flex: 1, marginRight: 2 }}>
													{Name || PositionName}
												</Text>
												<Text numberOfLines={1} style={{ fontSize: 12, color: 'rgba(94, 94, 94, 1)' }}>
													{dateTimeChil}
												</Text>
											</View>
											<View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
												<Text style={{ fontSize: 12, color: 'rgba(94, 94, 94, 1)' }}>{PositionName}</Text>
												{!!LikeCount && (
													<View style={{ flexDirection: 'row', alignItems: 'center' }}>
														<Icon src={ICONS.icLike} width={20} height={20} />
														<Text style={{ marginLeft: 4 }}>{LikeCount}</Text>
													</View>
												)}
											</View>
											<Text style={{ fontSize: 14, fontWeight: '400', color: 'rgba(0, 0, 0, 1)', paddingTop: 10 }}>
												{Content}
											</Text>
											<View style={{ flexDirection: 'row', alignItems: 'center' }}>
												<TouchableOpacity
													onPress={() => {
														onPressLike(ID, IsLiked, LikeCount, index, key);
													}}>
													<Text style={{ fontSize: 12, color: 'rgba(94, 94, 94, 1)', paddingVertical: 8 }}>
														{IsLiked ? 'Bỏ Thích' : 'Thích'}
													</Text>
												</TouchableOpacity>
												<TouchableOpacity
													onPress={() =>
														onComment({ ParentCommentId, CID, index, key, PositionName, DefaultImagePath })
													}>
													<Text style={{ fontSize: 12, color: 'rgba(94, 94, 94, 1)', paddingVertical: 8 }}>
														{' '}
														- Trả Lời
													</Text>
												</TouchableOpacity>
											</View>
										</View>
									</View>
								);
							})}
						</View>
					</View>
				</View>
			</View>
		</View>
	);
};

export const Comments = (props: any) => {
	const dispatch = useAppDispatch();
	const route = useRoute();

	const { taskData } = useTask();

	const { ID } = props;

	const refInput = useRef(null);
	const refText = useRef('');
	const refTextParent = useRef('');
	const refInputParent = useRef();
	const refOtherResourceId = useRef(null);

	const [comments, setComments] = useState([]);
	const [file, setFile] = useState([]);
	const { taskData: task } = useTask();
	refOtherResourceId.current = taskData?.FormConfig?.OtherResourceId;

	const [isComment, setIsComment] = useState(null);

	const fetchSuccess = (res: any) => {
		const cloneData = JSON.parse(JSON.stringify(res?.data?.data || '[]'));

		// Tạo một đối tượng theo ID để tìm kiếm nhanh
		const lookup = {};
		cloneData?.forEach((item: { ID: string | number; children: never[] }) => {
			lookup[item.ID] = item;
			item.children = [];
		});
		const result = [];

		cloneData?.forEach((item: { ParentCommentId: string | number }) => {
			const parent = lookup[item.ParentCommentId];
			if (parent) {
				// Thêm mục con vào mục cha
				parent.children.push(item);
			} else {
				// Nếu không có mục cha, đây là một mục cấp cao nhất
				result.push(item);
			}
		});

		setComments(result);
	};

	useEffect(() => {
		if (task?.ListComment?.length) {
			const res = {
				data: {
					data: task?.ListComment,
				},
			};
			fetchSuccess(res);
		}
	}, [task]);

	useEffect(() => {
		const keyboardDidHideListener = Keyboard.addListener('keyboardWillHide', () => {
			setIsComment(null);
			// if (!isComment) LayoutAnimation.easeInEaseOut();
		});

		return () => {
			keyboardDidHideListener.remove();
		};
	}, []);

	useEffect(() => {
		if (isComment) {
			refInput.current?.focus();
		} else {
			refInput.current?.blur();
		}
	}, [isComment]);

	const onComment = data => {
		if (data?.CID === isComment?.CID) {
			setIsComment(null);
		} else {
			setIsComment(data);
		}
	};

	const onPressAdd = () => {
		DocumentPicker.pickSingle().then(res => {
			ReactNativeBlobUtil.fs.readFile(res.uri.replace('file://', ''), 'base64').then(data => {
				setFile([...file, { Name: res.name, Base64: data }]);
			});
		});
	};

	const likeSuccess = (res, IsLiked, LikeCount, index, indexChildren) => {
		if (res?.data?.status === 'SUCCESS') {
			const clone = [...comments];
			if (indexChildren || indexChildren === 0) {
				clone[index].children[indexChildren] = {
					...clone[index].children[indexChildren],
					IsLiked: !IsLiked,
					LikeCount: IsLiked ? LikeCount - 1 : LikeCount + 1,
				};
			} else {
				clone[index] = { ...clone[index], IsLiked: !IsLiked, LikeCount: IsLiked ? LikeCount - 1 : LikeCount + 1 };
			}
			setComments(clone);
			LayoutAnimation.easeInEaseOut();
		}
	};

	const onPressLike = (commentid, IsLiked, LikeCount, index, indexChildren) => {
		dispatch(
			fetchLikeComment({
				action: IsLiked ? 'UNLIKE' : 'LIKE',
				rid: ID,
				commentid,
				isTask: true,
				success: res => likeSuccess(res, IsLiked, LikeCount, index, indexChildren),
			}),
		);
	};

	const commentSuccess = res => {
		const { data } = res.data;
		const clone = [...comments];
		if (isComment?.CID) {
			clone[isComment.index].children.push({
				CID: Date.now(),
				CommentCount: 0,
				Content: refText.current,
				Created: data?.Created,
				DefaultImagePath: isComment?.DefaultImagePath,
				ID: data?.ID,
				Image: '',
				ImagePath: data?.ImagePath,
				IsLiked: 0,
				LikeCount: 0,
				Name: data?.FullName,
				ParentCommentId: data?.ParentCommentId,
				PositionName: isComment?.PositionName,
				ResourceCategoryId: 8,
				ResourceId: data?.ResourceId,
				ResourceSubCategoryId: 0,
			});
		}
		setComments(clone);
		setIsComment(null);
		refText.current = '';
	};

	const commentSuccessParent = res => {
		const { data } = res.data;
		refOtherResourceId.current = data?.ResourceId;
		refTextParent.current = '';
		refInputParent.current?.setNativeProps({ text: '' });
		setFile([]);
		if (data?.ResourceId) {
			dispatch(updateOtherResourceId(data?.ResourceId));
			dispatch(
				fetchComment({
					rid: ID,
					otherresourceid: data?.ResourceId,
					success: fetchSuccess,
				}),
			);
		}
	};

	// ResourceCategoryId ==  16 && ResourceSubCategoryId = 0 ==> Task

	const onPressCommentParent = () => {
		dispatch(
			fetchAddComment({
				rid: ID,
				OtherResourceId: refOtherResourceId.current,
				ParentCommentId: isComment?.ParentCommentId,
				Content: refTextParent.current,
				Files: file,
				success: commentSuccessParent,
				isTask: true,
			}),
		);
	};

	const onPressComment = () => {
		dispatch(
			fetchAddComment({
				rid: ID,
				OtherResourceId: refOtherResourceId.current,
				ParentCommentId: isComment?.ParentCommentId,
				Content: refText.current,
				success: commentSuccess,
			}),
		);
	};

	const onDeletAttach = index => {
		setFile(file.filter((f, i) => i !== index));
	};

	return (
		<View style={{ marginTop: 15 }}>
			<Text style={{ marginVertical: 10, fontSize: 12, color: COLORS.black, fontWeight: '600' }}>Ý kiến</Text>
			{!isComment && (
				<View
					style={{
						width: windowWidth - 20,
						borderWidth: 0.8,
						borderColor: 'rgba(94, 94, 94, 0.5)',
						padding: 10,
						borderRadius: 4,
						marginBottom: 20,
					}}>
					<View style={{ height: 100, flexDirection: 'row' }}>
						<TextInput
							ref={refInputParent}
							placeholder="Vui lòng nhập ý kiến tại đây …"
							multiline
							style={{ flex: 1 }}
							onChangeText={text => (refTextParent.current = text)}
						/>
						<Icon src={ICONS.icFile} width={20} height={20} style={{ paddingRight: 10 }} onPress={onPressAdd} />
						<Icon src={ICONS.icSend} width={20} height={20} onPress={onPressCommentParent} />
					</View>
					{file?.map((f, key) => {
						return (
							<View key={key.toString()} style={{ flexDirection: 'row', alignItems: 'center', marginVertical: 5 }}>
								<Text style={{ color: 'rgba(0, 95, 212, 1)', marginRight: 5 }}>{f.Name}</Text>
								<Icon src={ICONS.icCloseRed} width={10} height={10} onPress={() => onDeletAttach(key)} />
							</View>
						);
					})}
				</View>
			)}
			<KeyboardAvoidingView behavior="padding" style={{ flex: 1 }}>
				<ScrollView style={{ paddingHorizontal: 10 }} showsVerticalScrollIndicator={false}>
					<FlatList
						scrollEnabled={false}
						data={comments}
						keyExtractor={(item, index) => index.toString()}
						renderItem={({ item, index }) => (
							<ItemComment item={item} index={index} onComment={onComment} onPressLike={onPressLike} />
						)}
					/>
				</ScrollView>

				{!!isComment && (
					<View
						style={{
							width: windowWidth - 20,
							height: 100,
							borderWidth: 0.8,
							borderColor: 'rgba(94, 94, 94, 0.5)',
							padding: 10,
							borderRadius: 4,
							marginBottom: 20,
							flexDirection: 'row',
							position: 'absolute',
							backgroundColor: 'white',
						}}>
						<TextInput
							ref={refInput}
							placeholder="Trả lời..."
							multiline
							style={{ flex: 1 }}
							onChangeText={text => {
								refText.current = text;
							}}
						/>
						<Icon src={ICONS.icSend} width={20} height={20} onPress={onPressComment} />
					</View>
				)}
			</KeyboardAvoidingView>
		</View>
	);
};
