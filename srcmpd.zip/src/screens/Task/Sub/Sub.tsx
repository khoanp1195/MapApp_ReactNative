import React from 'react';

import { useNavigation } from '@react-navigation/native';
import { TaskCard } from 'components/Organisms/TaskCard';
import { COLORS } from 'config';
import useSystem from 'hooks/useSystem';
import useTask from 'hooks/useTask';
import moment from 'moment';
import { RoutesNames } from 'navigation/RoutesNames';
import { borderColor } from 'polished';
import { Image, Keyboard, ScrollView, Text, View } from 'react-native';
import { useTasks } from 'screens/Home/Containers/Tasks/useTasks';

import { Comments } from '../Comments/Comments';

export const SubScreen = () => {
	const { taskData: task } = useTask();
	const navigation = useNavigation();

	const { beanAppStatus, language } = useSystem();

	return (
		<View style={{ flex: 1, paddingVertical: 10 }}>
			<ScrollView
				showsVerticalScrollIndicator={false}
				keyboardShouldPersistTaps="handled"
				onScrollBeginDrag={Keyboard.dismiss}
				contentContainerStyle={{ flexGrow: 1 }}>
				{task?.ListChildren.map((item: any, key) => {
					const assignTo = JSON.parse(item.AssignedToInfo);
					const statusGroupItem = beanAppStatus?.find(v => v.ID === item.StatusGroup);

					return (
						<View key={key}>
							<TaskCard
								// typeCurrent={typeCurrent}
								assignedToName={assignTo.Name}
								numExpand={assignTo.NumExpand}
								avatar={assignTo.ImagePath}
								defaultAvatar={assignTo.DefaultImagePath}
								status={item.StatusGroup}
								statusTitle={language === 'vi' ? statusGroupItem?.Title : statusGroupItem?.TitleEN}
								// fileCount={!!FileCount}
								// isFollow={!!IsFollow}
								title={item.Title}
								// time={Created}
								// description={Workflow}
								expire={item.DueDate}
								onPress={() => {
									navigation.replace(RoutesNames.Task, { item });
									// if (item.ResourceCategoryId === 16 && item.ResourceSubCategoryId === 0) {
									// } else {
									// }
									// if (!Read) updateRead(ID);
								}}
							/>
						</View>
					);
				})}
				<Comments />
			</ScrollView>
		</View>
	);
};
