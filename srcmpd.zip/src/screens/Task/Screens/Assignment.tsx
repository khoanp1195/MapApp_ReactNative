/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import React, { useRef } from 'react';

import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { ShowLoading } from 'components/Atoms/Loading/LoadingGlobal';
import { Header } from 'components/Organisms/Header';
import { ICONS } from 'config';
import { View, Text, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppDispatch } from 'stores';
import { createTask } from 'stores/Task/slice';

import DetailScreen from '../Detail/Detail';

type Params = {
	Item: {
		action: {
			ActionCode: string;
			Title: string;
		};
		ID: number;
		onUpdateTask: () => void;
		onRefresh: () => void;
		options: any;
		ParentId: number;
	};
};

const Assignment = () => {
	const dispatch = useAppDispatch();
	const navigation = useNavigation();
	const route = useRoute<RouteProp<Params, 'Item'>>();
	const detailRef = useRef<any>(null);

	const { action, ID: SPItemId, onRefresh, options, ParentId, onUpdateTask } = route.params || {}; // ID = SPItemID
	const { Title = '' } = action || {};

	const createTaskSuccess = () => {
		ShowLoading(false);
		onRefresh();
		onUpdateTask();
		navigation.goBack();
	};

	const onPressSave = () => {
		const payload: {
			itemInfo: any;
			attachment: any;
		} = detailRef?.current?.getData() || {};
		const { Title, Content, DueDate, AssignedTo } = payload.itemInfo;
		if (!(Title?.value && Content?.value && DueDate?.value && AssignedTo?.value)) {
			return Alert.alert('Please enter all field!');
		}
		const Info = {
			Title: Title.value,
			Content: Content.value,
			DueDate: DueDate.value,
			AssignedTo: AssignedTo.value,
			SPItemId,
			ParentId,
		};
		ShowLoading(true);
		dispatch(
			createTask({
				params: {
					attachments: JSON.stringify(payload.attachment),
					itemInfo: JSON.stringify(Info),
					lid: 1066,
				},
				success: createTaskSuccess,
			}),
		);
	};

	const trailingHeader = (
		<View style={{ marginLeft: 15 }}>
			<Icon src={ICONS.icCheck} width={20} height={20} onPress={onPressSave} />
		</View>
	);
	return (
		<SafeAreaView style={{ flex: 1 }} edges={['top']}>
			<Header iconLeftSrc={ICONS.icArrowLeft} trailing={trailingHeader}>
				<Text numberOfLines={1} style={{ fontSize: 16, textAlign: 'center', flex: 1 }}>
					{Title || 'Tạo công việc con'}
				</Text>
			</Header>
			<View style={{ flex: 1, paddingHorizontal: 10 }}>
				<DetailScreen ref={detailRef} type="add" options={options} />
			</View>
		</SafeAreaView>
	);
};

export default Assignment;
