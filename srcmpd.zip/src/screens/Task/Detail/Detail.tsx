/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable array-callback-return */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-use-before-define */
import React, { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';

import { Icon } from 'components/Atoms/Icon';
import { COLORS } from 'config';
import { ICONS } from 'config/images';
import useTask from 'hooks/useTask';
import { ActivityIndicator, Keyboard, ScrollView, Text, View, StyleSheet } from 'react-native';
import SelectDropdown from 'react-native-select-dropdown';
import Attachments from 'screens/TaskDetail/Field/Attachments';
import DateTime from 'screens/TaskDetail/Field/DateTime';
import MultipleLines from 'screens/TaskDetail/Field/MultipleLines';
import SingleLine from 'screens/TaskDetail/Field/SingleLine';
import UserGroup from 'screens/TaskDetail/Field/UserGroup';

import { Comments } from '../Comments/Comments';

interface TaskData {
	FormConfig: {
		IsAssignedTo: boolean;
		IsAuthor: boolean;
		IsCompleted: boolean;
		IsHold: boolean;
		NumChildrenCount: number;
		ListButtonAction: string;
		DataSourceTaskStatus: string;
		OtherResourceId: string;
	};
	ItemInfo: {
		ID: number;
		SPItemId: number;
		Title: string;
		ListAssignedTo: string;
		AssignedTo: string;
		Content: any;
		StatusGroup: number;
		DueDate: string;
		AssignedBy: string;
		AssignedByName: string;
		Status: number;
	};
}

const DetailScreen = (
	{ ID, type, options }: { ID?: string; type?: string; options?: { Title: string; Content: string; DueDate: string } },
	ref: React.Ref<unknown> | undefined,
) => {
	const attachRef = useRef<any>({});

	const isAdd = type === 'add';

	const { taskData: task, isGettingTask, user } = useTask();

	const taskData: TaskData = isAdd ? {} : task;

	const { IsAuthor, IsCompleted, IsHold, IsAssignedTo } = taskData?.FormConfig || {};
	const isPermissionEdit = isAdd || (IsAuthor && !IsCompleted && !IsHold);
	const isDisableAttachment = IsCompleted || (IsAuthor && IsHold && !IsAssignedTo);

	const FormRefField = {
		Title: 'Title',
		AssignedTo: 'AssignedTo',
		Content: 'Content',
		DueDate: 'DueDate',
	};

	const fieldRef = useRef<any>({});

	const [selectedOption, setSelectedOption] = useState<{ ID: number; Title: string; StatusGroup: string }>();

	const getData = () => {
		let params = {};

		Object.keys(FormRefField).map(e => {
			const info = fieldRef.current[e]?.getData();
			if (info !== undefined) params = { ...params, [e]: info };
		});

		if (params?.Title === undefined || params?.AssignedTo === undefined) {
			return undefined;
		}
		const itemInfo = { ...params, ID, SPItemId: taskData?.ItemInfo?.SPItemId, Status: selectedOption?.ID };
		const attachment = attachRef.current?.getData();

		return { itemInfo, attachment };
	};

	useImperativeHandle(
		ref,
		() => ({
			getData,
		}),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[selectedOption],
	);

	useEffect(() => {
		if (taskData && !isAdd) {
			setSelectedOption(
				JSON.parse(taskData?.FormConfig?.DataSourceTaskStatus || '[]').find(
					(item: { ID: number; Title: string; StatusGroup: string }) => item.ID === taskData.ItemInfo.Status,
				),
			);
		}
	}, [taskData]);

	const renderDropdownIcon = () => {
		return (
			<View>
				<Icon src={ICONS.icArrowDown} width={8} height={8} tintColor={COLORS.black} />
			</View>
		);
	};

	const renderCustomizedButtonChild = () => {
		return (
			<View>
				<Text>{selectedOption?.Title}</Text>
			</View>
		);
	};

	const renderCustomizedRowChild = (e: { ID: number; Title: string }) => {
		return (
			<View
				style={{
					backgroundColor: 'white',
					flex: 1,
					alignItems: 'center',
					paddingHorizontal: 10,
					flexDirection: 'row',
				}}>
				<View style={{ width: '4%' }}>
					{selectedOption?.ID === e.ID && <Icon src={ICONS.icCheck} width={8} height={8} tintColor={COLORS.black} />}
				</View>

				<Text
					style={{
						color: selectedOption?.ID === e.ID ? COLORS.blueMain : COLORS.black,
						marginLeft: 10,
					}}>
					{e?.Title.trim()}
				</Text>
			</View>
		);
	};

	return (
		<View style={{ flex: 1, paddingVertical: 10 }}>
			{isGettingTask && <ActivityIndicator />}
			{!isGettingTask && taskData && (
				<ScrollView
					showsVerticalScrollIndicator={false}
					keyboardShouldPersistTaps="handled"
					onScrollBeginDrag={Keyboard.dismiss}
					contentContainerStyle={{ flexGrow: 1 }}>
					<SingleLine
						ref={ref => (fieldRef.current[FormRefField.Title] = ref)}
						title="Tiêu đề"
						isGrid={isPermissionEdit}
						defaultValue={taskData?.ItemInfo?.Title || options?.Title}
						name="Title"
						isRequired
						isEdited
					/>
					<UserGroup
						ref={ref => (fieldRef.current[FormRefField.AssignedTo] = ref)}
						title="Người xử lý"
						isGrid={isPermissionEdit}
						defaultValue={taskData?.ItemInfo?.AssignedTo}
						name="AssignedTo"
						isRequired
						options={JSON?.stringify({ U_Allow_Multiple_Yes: true })}
						isTask
						ID={ID}
						isEdited
					/>
					<DateTime
						ref={ref => (fieldRef.current[FormRefField.DueDate] = ref)}
						title="Hạn hoàn tất"
						isGrid={isPermissionEdit}
						defaultValue={taskData?.ItemInfo?.DueDate || options?.DueDate}
						name="DueDate"
						isRequired
						isEdited
					/>
					{!isAdd && (
						<View style={{ marginVertical: 5 }}>
							<Text style={{ color: '#5E5E5E', fontSize: 11, marginBottom: 4 }} numberOfLines={1}>
								Người giao
							</Text>
							<Text style={{ fontSize: 14, color: 'black' }}>{user?.AccountName}</Text>
						</View>
					)}
					<MultipleLines
						ref={ref => (fieldRef.current[FormRefField.Content] = ref)}
						title="Nội dung"
						isGrid={isPermissionEdit}
						defaultValue={taskData?.ItemInfo?.Content || options?.Content}
						name="Content"
						isRequired
						isEdited
					/>
					{IsAssignedTo && !isAdd && (
						<View style={{ marginVertical: 10 }}>
							<Text style={{ color: '#5E5E5E', fontSize: 11, marginBottom: 4 }} numberOfLines={1}>
								Tình trạng
							</Text>
							<SelectDropdown
								disabled={IsCompleted}
								data={JSON.parse(taskData?.FormConfig?.DataSourceTaskStatus)}
								dropdownOverlayColor="transparent"
								onSelect={(selectedItem: { ID: number; Title: string; StatusGroup: string }) => {
									setSelectedOption(selectedItem);
								}}
								renderDropdownIcon={renderDropdownIcon}
								renderCustomizedButtonChild={renderCustomizedButtonChild}
								rowStyle={styles.rowStyle}
								rowTextStyle={styles.rowTextStyle}
								dropdownStyle={styles.dropdownStyle}
								renderCustomizedRowChild={renderCustomizedRowChild}
								buttonStyle={styles.buttonStyle}
								buttonTextStyle={styles.buttonTextStyle}
							/>
						</View>
					)}

					<Attachments
						ID={ID}
						ref={attachRef}
						name="attachment"
						isAddTask={isAdd}
						isTask
						isDisableAttachment={isAdd ? false : isDisableAttachment}
						ListDocumentCategory={[]}
					/>
					{!isAdd && <Comments ID={ID} />}
					<View style={{ marginBottom: 100 }} />
				</ScrollView>
			)}
		</View>
	);
};

export default forwardRef(DetailScreen);

const styles = StyleSheet.create({
	containerCheckBox: { flexDirection: 'row', flexWrap: 'wrap', padding: 2 },
	itemCheckBox: { flexDirection: 'row', marginRight: 20 },
	checkBox: { width: 16, height: 16 },
	nameCheckBox: { fontSize: 14, color: COLORS.black, marginLeft: 4 },
	title: { fontSize: 14, color: COLORS.blueMain },
	rowStyle: { backgroundColor: COLORS.white, height: 36 },
	rowTextStyle: { backgroundColor: COLORS.white },
	dropdownStyle: { backgroundColor: COLORS.white, borderRadius: 4 },
	buttonStyle: {
		height: 30,
		width: '100%',
		borderColor: '#E5E5E5',
		borderWidth: 0.8,
		alignItems: 'center',
		borderRadius: 4,
		backgroundColor: COLORS.white,
	},
	buttonTextStyle: { color: COLORS.black, fontSize: 14, textAlign: 'left' },
	multiSelect: {
		minHeight: 28,
		// borderBottomColor: 'gray',
		borderWidth: 0.8,
		width: '100%',
		paddingHorizontal: 10,
		borderRadius: 4,
		borderColor: '#E5E5E5',
	},
	viewItemMulti: {
		paddingHorizontal: 15,
		paddingVertical: 5,
	},
	containerRadio: {
		flexDirection: 'row',
		marginRight: 20,
		flexWrap: 'wrap',
		overflow: 'hidden',
	},
	buttonRadio: {
		flexDirection: 'row',
		marginRight: 20,
		padding: 5,
	},
	viewRadio: {
		width: 18,
		height: 18,
		borderWidth: 1,
		borderRadius: 10,

		alignItems: 'center',
		justifyContent: 'center',
	},
	checked: { backgroundColor: COLORS.blueMain, width: 9, height: 9, borderRadius: 9 },
	viewMulti: {
		paddingVertical: 5,
		width: '90%',
		flexDirection: 'row',
		alignItems: 'center',
		zIndex: 1,
		overflow: 'hidden',
		flexWrap: 'wrap',
	},
	titleContaier: { color: COLORS.davyGrey, fontSize: 11, marginBottom: 4 },
});
