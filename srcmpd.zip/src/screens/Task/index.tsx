import React, { useEffect, useRef, useState } from 'react';

import { useNavigation, useRoute } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { ShowLoading } from 'components/Atoms/Loading/LoadingGlobal';
import { Header } from 'components/Organisms/Header';
import { COLORS, ICONS } from 'config';
import useSystem from 'hooks/useSystem';
import useTask from 'hooks/useTask';
import { RoutesNames } from 'navigation/RoutesNames';
import { View, Text, SafeAreaView, TouchableOpacity, Dimensions, ActivityIndicator, Alert } from 'react-native';

// components

// common

// lib
import { TabView, SceneMap, TabBar } from 'react-native-tab-view';
import { useAppDispatch } from 'stores';
import { completeTask } from 'stores/Task/slice';
import { updateAtatchmentTasks } from 'stores/TaskDetails';

import { Comments } from './Comments/Comments';
import DetailScreen from './Detail/Detail';
import { SubScreen } from './Sub/Sub';

export const TaskScreen = () => {
	const dispatch = useAppDispatch();
	const navigation = useNavigation();
	const { params } = useRoute();
	const refDetail = useRef();

	const detailRef = useRef(null);

	const { lid } = useSystem();
	const { getTaskData, updateDataTask, isUpdatingTask, taskData } = useTask();

	const renderScene = SceneMap({
		detail: () => <DetailScreen ref={detailRef} ID={params?.item.ID} />,
		sub: () => <SubScreen />,
	});

	// STATE
	// STATE
	const [index, setIndex] = useState(0);
	const [routes, setRoute] = useState([
		{ key: 'detail', title: 'Chi tiết' },
		{
			key: 'sub',
			title: taskData?.ListChildren?.length > 0 ? `Công việc con (${taskData.ListChildren.length})` : 'Công việc con',
		},
	]);

	useEffect(() => {
		setRoute([
			{ key: 'detail', title: 'Chi tiết' },
			{
				key: 'sub',
				title: taskData?.ListChildren?.length > 0 ? `Công việc con (${taskData.ListChildren.length})` : 'Công việc con',
			},
		]);
	}, [taskData]);

	const initialLayout = { width: Dimensions.get('window').width };

	useEffect(() => {
		const payload = {
			rid: params?.item.ID,
			spitemid: params?.item.SPItemId,
			lid,
			func: 'getFormData',
		};
		getTaskData(payload);
		return () => {
			dispatch(updateAtatchmentTasks([]));
			params?.onUpdateTaskFlow && params?.onUpdateTaskFlow();
		};
	}, []);

	const renderTabBar = (props: any) => (
		<TabBar
			{...props}
			indicatorStyle={{ backgroundColor: COLORS.trueBlue }}
			tabStyle={{ width: 'auto' }}
			style={{
				backgroundColor: COLORS.white,
				elevation: 0,
				shadowOffset: { height: 0, width: 0 },
				shadowColor: 'transparent',
				shadowOpacity: 0,
			}}
			pressColor="white"
			renderLabel={({ route, focused }) => (
				<Text
					style={{
						width: route.key === 'sub' ? 130 : 70,
						fontSize: 14,
						textAlign: 'center',
						color: focused ? COLORS.black : COLORS.davyGrey,
						fontWeight: focused ? '700' : '400',
						paddingHorizontal: 5,
					}}>
					{route.title}
				</Text>
			)}
		/>
	);

	const getInfoButton = ActionCode => {
		switch (ActionCode) {
			case 'CREATESUBTASK':
				return ICONS.icAdd;
			case 'COMPLETE':
				return ICONS.icComplete;
			case 'SAVE':
				return ICONS.icSave;

			default:
				return ICONS.icSave;
		}
	};

	const updateSuccess = () => {
		params?.onUpdateTask && params?.onUpdateTask();
		ShowLoading(false);
		navigation.goBack();
	};

	const onPressSave = () => {
		const payload: {
			itemInfo: any;
			attachment: any;
		} = detailRef?.current?.getData();
		const { Title, Content, DueDate, AssignedTo, SPItemId, ID, Status } = payload.itemInfo;
		if (!(Title?.value && Content?.value && DueDate?.value && AssignedTo?.value)) {
			return Alert.alert('Please enter all field!');
		}
		ShowLoading(true);
		const Info = {
			Title: Title.value,
			Content: Content.value,
			DueDate: DueDate.value,
			AssignedTo: AssignedTo.value,
			SPItemId,
			ID,
			Status: Status || 0,
		};
		const formdata = new FormData();
		formdata.append('itemInfo', JSON.stringify(Info));
		formdata.append('attachment', JSON.stringify(payload?.attachment));
		updateDataTask({ params: { func: 'updateTask', lid }, formData: formdata, success: updateSuccess });
	};

	const options = {
		Title: taskData?.ItemInfo?.Title,
		Content: taskData?.ItemInfo?.Content,
		DueDate: taskData?.ItemInfo?.DueDate,
	};

	const onRefresh = () => {
		const payload = {
			rid: params?.item.ID,
			spitemid: params?.item.SPItemId,
			lid,
			func: 'getFormData',
		};
		getTaskData(payload);
	};

	const onCreateSubtask = () => {
		navigation.navigate(RoutesNames.Assignment, {
			ID: taskData?.ItemInfo?.SPItemId,
			options,
			ParentId: params?.item.ID,
			onRefresh,
			onUpdateTask: params?.onUpdateTask,
		});
	};

	const handleActions = ActionCode => {
		switch (ActionCode) {
			case 'CREATESUBTASK':
				return onCreateSubtask();
			case 'COMPLETE':
				ShowLoading(true);
				dispatch(
					completeTask({
						params: {
							rid: params?.item.ID,
							lid,
						},
						success: updateSuccess,
					}),
				);

				return;
			case 'SAVE':
				return onPressSave();

			default:
				return ICONS.icSave;
		}
	};

	// render group icon
	const trailing = () => {
		const listButton = JSON.parse(taskData?.FormConfig?.ListButtonAction || '[]');
		return (
			<View style={{ flexDirection: 'row' }}>
				{listButton?.map((e, key: number) => {
					const infoButton = getInfoButton(e.ActionCode);
					return (
						<TouchableOpacity
							key={e?.ID?.toString()}
							onPress={() => handleActions(e.ActionCode)}
							style={{ marginLeft: 10 }}>
							<Icon tintColor={COLORS.gray} src={infoButton} width={20} height={20} />
						</TouchableOpacity>
					);
				})}
			</View>
		);
	};

	return (
		<SafeAreaView style={{ flex: 1 }}>
			{isUpdatingTask && (
				<View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
					<ActivityIndicator size="large" color={COLORS.trueBlue} />
				</View>
			)}
			<Header iconLeftSrc={ICONS.icArrowLeft} trailing={trailing()}>
				<Text numberOfLines={1} style={{ fontSize: 16, textAlign: 'center', flex: 1, fontWeight: '400' }}>
					Công việc
				</Text>
			</Header>
			<View style={{ width: '100%', height: '100%', paddingHorizontal: 10, flex: 1 }}>
				<TabView
					navigationState={{ index, routes }}
					renderScene={renderScene}
					onIndexChange={setIndex}
					initialLayout={initialLayout}
					lazy
					renderTabBar={renderTabBar}
				/>
			</View>
		</SafeAreaView>
	);
};
