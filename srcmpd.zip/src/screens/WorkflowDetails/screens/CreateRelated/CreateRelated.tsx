import React, { useEffect, useRef, useState } from 'react';

import { useNavigation, useRoute } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { refDropDown } from 'components/Atoms/Loading/DropDown';
import ModalCalendarRef from 'components/LookupScreens/ModalCalendarRef';
import ModalState from 'components/LookupScreens/ModalState';
import ModalWorkflow from 'components/LookupScreens/ModalWorkflow';
import FImage from 'components/Organisms/FImage/FImage';
import { Header } from 'components/Organisms/Header';
import { COLORS, COLOR_STATUS, COLOR_TEXT_STATUS } from 'config/colors';
import { ICONS } from 'config/images';
import dayjs from 'dayjs';
import useDebounce from 'hooks/useDebounce';
import useSystem from 'hooks/useSystem';
import {
	View,
	Text,
	TextInput,
	TouchableOpacity,
	FlatList,
	RefreshControl,
	Keyboard,
	TouchableWithoutFeedback,
	TouchableHighlight,
} from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateRelated } from 'stores/Workflows/sliceWorkflow';
import { translate } from 'utils/translate';

import { styles } from './CreateRelated.styles';
import { useCreateRelated } from './useCreateRelated';

interface IWorkflow {
	ID: number;
	WorkflowID: number;
	Title: string;
	TitleEN: string;
	Description: any;
	ImageURL: string;
	IsFavor: number;
	WorkflowCategory: string;
	WorkflowCategoryID: number;
}

interface IState {
	value: number;
	label: string;
	labelEN: string;
}

const CreateRelated = () => {
	const dispatch = useAppDispatch();
	const navigation = useNavigation();
	const { isVN } = useSystem();
	const route = useRoute();
	const refModalWorkflow = useRef<{ show: (e: IWorkflow[]) => void } | null>(null);
	const refModalState = useRef<{ show: (e: IState[]) => void } | null>(null);
	const refModalCalendar = useRef<{ show: (options: any) => void } | null>(null);
	const refState = useRef<string[]>();

	const related = useAppSelector(store => store.workflow.related);

	const { itemPrams, relatedAdd, from = '' } = route.params || {};

	const getList = () => {
		const listRelated = from === 'addWorkflow' ? relatedAdd : related;
		let list = [itemPrams?.ID];
		listRelated?.forEach(ele => {
			list = [...list, ele.ID];
		});
		return list;
	};

	const ListNotGet = getList();

	const refSubmit = useRef({
		workflow: [{ Title: 'Tất cả', TitleEN: 'All', WorkflowID: 0 }],
		state: [{ label: translate('flag_all'), value: 0, labelEN: 'All' }],
		fromDate: new Date(new Date().setDate(new Date().getDate() - 30)),
		toDate: new Date(),
		Flag: 'flag_all',
	});

	const [kw, setKw] = useState('');
	const [open, setOpen] = useState(false);
	const [select, setSelect] = useState([]);

	const [filter, setFilter] = useState({
		workflow: [{ Title: 'Tất cả', TitleEN: 'All', WorkflowID: 0 }],
		state: [{ label: translate('flag_all'), value: 0, labelEN: 'All' }],
		fromDate: new Date(new Date().setDate(new Date().getDate() - 30)),
		toDate: new Date(),
		keyword: '',
		Flag: 'flag_all',
	});

	const { data, handleEndReached, refreshing, handleRefresh, handleFilter, useFilter, handleReset } = useCreateRelated(
		filter,
		ListNotGet,
	);

	const dbKw = useDebounce(kw, 300);

	useEffect(() => {
		setFilter({ ...filter, keyword: dbKw });
	}, [dbKw]);

	const onSubmitSelectWorkflow = (select: IWorkflow[]) => {
		// setWorkflow(select);
		setFilter({ ...filter, workflow: select });
	};

	const onSubmitSelectState = (select: IState[]) => {
		setFilter({ ...filter, state: select });
	};

	const onSubmitSelectDate = ({ isFromDate, date }: { isFromDate: boolean; date: Date }) => {
		if (isFromDate) {
			return setFilter({ ...filter, fromDate: date });
		}
		return setFilter({ ...filter, toDate: date });
	};

	const onPressSearch = () => {
		refSubmit.current = filter;
		setOpen(false);
		handleFilter(filter);
	};

	const onPressWorkflow = () => refModalWorkflow.current?.show(filter.workflow);

	const onPressState = () => refModalState.current?.show(filter.state);

	const onOpenCalendarFormDate = () => {
		const options = {
			headerTitle: translate('from_date'),
			defaultValue: filter.fromDate,
			maxDate: filter.toDate,
		};
		refModalCalendar.current?.show(options);
	};

	const onOpenCalendarToDate = () => {
		const options = {
			headerTitle: translate('to_date'),
			defaultValue: filter.toDate,
			maxDate: '',
		};
		refModalCalendar.current?.show(options);
	};

	const getNameWorkflow = () => {
		if (!filter.workflow?.length) return translate('select_workflow');
		const listName: string[] = filter.workflow.map(item => (isVN ? item.Title : item.TitleEN));
		return listName.toString().replaceAll(',', ', ') || '';
	};

	const getNameState = () => {
		if (!filter.state?.length) return translate('select_state');
		const listName: string[] = filter.state.map(item => (isVN ? item.label : item.labelEN));
		return listName.toString().replaceAll(',', ', ') || '';
	};

	const getInfoFilter = type => {
		switch (type) {
			case 'workflow':
				return {
					title: isVN ? filter.workflow[0]?.Title : filter.workflow[0]?.TitleEN,
					icon: null,
				};
			case 'state':
				let listLabel: string[] = [];
				if (filter.state?.length) {
					filter.state?.forEach(item => {
						listLabel = [...listLabel, isVN ? item.label : item.labelEN];
					});
				}
				refState.current = listLabel;
				return {
					title: `${listLabel[0]}${listLabel?.length - 1 > 0 ? ` +${listLabel?.length - 1}` : ''}`,
					icon: listLabel?.length - 1 > 0 ? ICONS.icChevronDown : null,
				};
			case 'term':
				return {
					title: translate(filter.Flag),
					icon: null,
				};
			case 'date':
				return {
					title: `${dayjs(filter.fromDate).format(isVN ? 'DD/MM/YYYY' : 'MM/DD/YYYY')} - ${dayjs(filter.toDate).format(
						isVN ? 'DD/MM/YYYY' : 'MM/DD/YYYY',
					)}`,
					icon: ICONS.icCalendarField,
				};

			default:
				return {
					title: ``,
					icon: null,
				};
		}
	};

	const onPressChooseItem = () => {
		if (route.params?.from === 'addWorkflow') {
			route.params?.onCallbackRelated(select);
		} else {
			dispatch(
				updateRelated({
					func: 'add',
					item: select,
				}),
			);
		}
		setSelect([]);
		navigation.goBack();
	};

	const renderLeading = () => (
		<View style={{ flexDirection: 'row', alignItems: 'center' }}>
			<Icon
				src={open ? ICONS.icChevronDown : ICONS.icArrowMenu}
				width={24}
				height={24}
				tintColor="rgba(0, 0, 0, 1)"
				onPress={() => {
					if (open) {
						setOpen(false);
					} else {
						navigation.goBack();
					}
				}}
			/>

			<Text style={{ fontSize: 20, fontWeight: '700', marginLeft: 10 }}>{translate('addAssociated')}</Text>
		</View>
	);

	const onPressFilter = () => {
		Keyboard.dismiss();
		if (open) {
			setFilter({ ...filter, ...refSubmit.current });
		}
		setOpen(!open);
	};

	const trailing = (
		<View style={{ alignItems: 'center', flexDirection: 'row', justifyContent: 'flex-end' }}>
			<View
				style={{
					backgroundColor: useFilter || open ? 'rgba(219, 235, 255, 1)' : 'white',
					padding: 2,
					borderRadius: 4,
				}}>
				<Icon
					src={ICONS.icFilterTask}
					width={24}
					height={24}
					onPress={onPressFilter}
					tintColor={useFilter || open ? 'rgba(0, 95, 212, 1)' : 'black'}
				/>
			</View>
		</View>
	);
	const { beanAppStatus } = useAppSelector(store => store.system);

	const onPressReset = () => {
		if (open) {
			setFilter({
				...filter,
				...{
					workflow: [{ Title: 'Tất cả', TitleEN: 'All', WorkflowID: 0 }],
					state: [{ label: translate('flag_all'), value: 0, labelEN: 'All' }],
					fromDate: new Date(new Date().setDate(new Date().getDate() - 30)),
					toDate: new Date(),
					Flag: 'flag_all',
				},
			});
		}
		setKw('');
		setOpen(false);
		handleReset();
	};

	return (
		<SafeAreaView style={{ flex: 1 }} edges={['top']}>
			<Header leading={renderLeading()} trailing={trailing} />
			<View
				style={{
					borderWidth: 1,
					justifyContent: 'center',
					height: 38,
					flexDirection: 'row',
					alignItems: 'center',
					borderRadius: 8,
					borderColor: 'rgba(217, 217, 217, 1)',
					paddingHorizontal: 8,
					marginHorizontal: 16,
					marginBottom: 10,
					marginTop: 10,
				}}>
				<Icon src={ICONS.icSearchApps} width={18} height={18} tintColor="rgba(123, 123, 123, 1)" />
				<TextInput
					placeholder={translate('title_search')}
					value={kw}
					onChangeText={setKw}
					style={{ flex: 1, marginLeft: 5 }}
					multiline={false}
				/>
			</View>
			<View style={{ flex: 1, backgroundColor: 'white' }}>
				{open && (
					<TouchableWithoutFeedback
						onPress={() => {
							if (open) {
								setFilter({ ...filter, ...refSubmit.current });
							}
							setOpen(false);
						}}>
						<View
							style={{
								position: 'absolute',
								width: '100%',
								height: '100%',
								backgroundColor: 'rgba(0, 0, 0, 0.2)',
								zIndex: 1,
							}}>
							<View style={{ paddingHorizontal: 16, backgroundColor: 'white' }}>
								<View style={styles.options}>
									<Text style={styles.titleWorkflow}>{translate('workflow')}</Text>
									<TouchableOpacity activeOpacity={1} style={styles.buttonWorkflow} onPress={onPressWorkflow}>
										<Text style={styles.nameWf}>{getNameWorkflow()}</Text>
										<Icon src={ICONS.icChevronDown} width={20} height={20} />
									</TouchableOpacity>
								</View>
								<View style={styles.vState}>
									<Text style={styles.tState}>
										{translate('state')}
										<Text style={{ fontSize: 12 }}>
											{filter.state[0]?.value !== 0 ? ` (${filter.state?.length})` : ''}
										</Text>
									</Text>
									<TouchableOpacity activeOpacity={1} style={styles.bState} onPress={onPressState}>
										<Text style={styles.nState}>{getNameState()}</Text>
										<Icon src={ICONS.icChevronDown} width={20} height={20} />
									</TouchableOpacity>
								</View>
								{/* <View style={{ paddingTop: 20 }}>
									<Text style={{ paddingBottom: 20 }}>{translate('processingTerm')}</Text>
									<View style={{ flexDirection: 'row' }}>
										{['flag_all', 'to_day', 'flag_overdue'].map((item, index) => {
											const isSelect = item === filter.Flag;
											return (
												<TouchableOpacity
													activeOpacity={1}
													key={index?.toString()}
													style={{ flexDirection: 'row', marginRight: 30 }}
													onPress={() => {
														setFilter({ ...filter, Flag: item });
													}}>
													<Icon src={isSelect ? ICONS.icCheckUser : ICONS.icUnCheckUser} width={20} height={20} />
													<Text
														style={{
															marginLeft: 6,
															color:
																index === 1 ? 'rgba(139, 79, 183, 1)' : index === 2 ? 'rgba(237, 78, 73, 1)' : '#555',
														}}>
														{translate(item as 'flag_all')}
													</Text>
												</TouchableOpacity>
											);
										})}
									</View>
								</View> */}
								{/* <View style={styles.dvd} /> */}

								<View style={styles.cDate}>
									<View style={styles.vFromDate}>
										<TouchableOpacity style={{ flex: 1 }} onPress={onOpenCalendarFormDate}>
											<Text style={styles.nFromDate}>{translate('from_date')}</Text>
											<View style={styles.vDate}>
												<Text style={styles.tDate}>
													{dayjs(filter.fromDate).format(isVN ? 'DD/MM/YYYY' : 'MM/DD/YYYY')}
												</Text>
												<Icon src={ICONS.icCalendarField} width={20} height={20} />
											</View>
										</TouchableOpacity>
										<TouchableOpacity style={{ flex: 1 }} onPress={onOpenCalendarToDate}>
											<Text style={styles.nFromDate}>{translate('to_date')}</Text>
											<View style={styles.vDate2}>
												<Text style={styles.tDate}>
													{dayjs(filter.toDate).format(isVN ? 'DD/MM/YYYY' : 'MM/DD/YYYY')}
												</Text>
												<Icon src={ICONS.icCalendarField} width={20} height={20} />
											</View>
										</TouchableOpacity>
									</View>
								</View>
								<TouchableOpacity style={styles.bSave} onPress={onPressSearch}>
									<Text style={styles.tSave}>{translate('filter_apply').toLocaleUpperCase()}</Text>
								</TouchableOpacity>
								<TouchableOpacity
									onPress={onPressReset}
									style={{ alignItems: 'center', justifyContent: 'center', marginBottom: 20 }}>
									<Text style={{ color: 'rgba(0, 95, 212, 1)' }}>{translate('Restore')}</Text>
								</TouchableOpacity>
							</View>
						</View>
					</TouchableWithoutFeedback>
				)}
				{useFilter && (
					<View style={{ marginHorizontal: 16 }}>
						<ScrollView horizontal showsHorizontalScrollIndicator={false}>
							{['workflow', 'state', 'date'].map((item, index) => {
								const info = getInfoFilter(item);
								return (
									<View
										key={index?.toString()}
										style={{
											flexDirection: 'row',
											alignItems: 'center',
											padding: 10,
											backgroundColor: 'white',
											borderRadius: 8,
											marginRight: 16,
											marginTop: 10,
											overflow: 'hidden',
											justifyContent: 'center',
											borderWidth: 0.8,
											borderColor: 'rgba(217, 217, 217, 1)',
										}}>
										<View style={{ maxWidth: 200 }}>
											<Text numberOfLines={1} style={{ flex: 1 }}>
												{info?.title}
											</Text>
										</View>
										{!!info?.icon && (
											<TouchableOpacity
												activeOpacity={1}
												onPress={event => {
													if (item === 'state' && refState.current?.length > 1) {
														event.target.measure((x, y, width, height, pageX, pageY) => {
															refDropDown.current?.show(
																{
																	top: pageY - y + 5,
																	left: pageX - x - 55,
																	heightItem: refState.current?.length || 0,
																},
																<View style={{ paddingHorizontal: 20, width: 150 }}>
																	{refState.current?.map((item, index) => {
																		if (index === 0) return null;
																		return (
																			<TouchableOpacity
																				key={index?.toString()}
																				style={{
																					marginVertical: 5,
																					flexDirection: 'row',
																					alignItems: 'center',
																					height: 30,
																				}}>
																				<Text>{item}</Text>
																			</TouchableOpacity>
																		);
																	})}
																</View>,
															);
														});
													}
												}}>
												<Icon src={info.icon} width={18} height={18} tintColor="#000" style={{ marginLeft: 4 }} />
											</TouchableOpacity>
										)}
									</View>
								);
							})}
						</ScrollView>
					</View>
				)}
				<FlatList
					refreshControl={
						<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={COLORS.trueBlue} />
					}
					onEndReached={handleEndReached}
					onEndReachedThreshold={0.7}
					contentContainerStyle={{ paddingHorizontal: 16, paddingVertical: 20 }}
					showsVerticalScrollIndicator={false}
					data={data}
					keyExtractor={(item, index) => index?.toString()}
					renderItem={({ item, index }) => {
						const CreatedByInfo = JSON.parse(item?.CreatedByInfo || '{}');
						const { DefaultImagePath, ImagePath } = CreatedByInfo || {};
						const statusGroupItem = beanAppStatus?.find(v => v.ID === item.StatusGroup);
						const isSl = select.find(elm => elm.ID === item.ID);

						const onPress = () => {
							if (isSl) {
								setSelect(select.filter(elm => elm.ID !== item.ID));
							} else {
								setSelect([...select, item]);
							}
						};

						return (
							<TouchableOpacity
								style={{ flexDirection: 'row', flex: 1, marginBottom: 16, alignItems: 'center' }}
								onPress={onPress}>
								<Icon src={isSl ? ICONS.icCheckUser : ICONS.icUnCheckUser} width={18} height={18} />

								<View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
									<View style={{ flex: 1, marginLeft: 12 }}>
										<View style={{ flexDirection: 'row', alignItems: 'center', overflow: 'hidden' }}>
											<FImage mh={0} SW={36} DefaultImagePath={DefaultImagePath} ImagePath={ImagePath} />
											<Text
												numberOfLines={1}
												style={{
													flex: 1,
													color: 'rgba(123, 123, 123, 1)',
													fontSize: 12,
													fontWeight: '600',
													marginLeft: 12,
												}}>
												{CreatedByInfo?.Name}
											</Text>
											<Text style={{ fontSize: 11, color: 'rgba(157, 157, 157, 1)' }}>
												{dayjs(item.Created).format(isVN ? 'DD/MM/YYYY HH:mm' : 'MM/DD/YYYY HH:mm')}
											</Text>
										</View>
										<View style={{}}>
											<Text numberOfLines={2} style={{ marginBottom: 5, marginTop: 5 }}>
												{item.Content}
											</Text>
											<View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
												<Text
													numberOfLines={2}
													style={{ fontSize: 10, color: 'rgba(157, 157, 157, 1)', marginBottom: 5, flex: 1 }}>
													{item.Workflow}
												</Text>
												<View
													style={{
														backgroundColor: COLOR_STATUS[item.StatusGroup],
														paddingVertical: 4,
														minWidth: 100,
														borderRadius: 4,
														alignItems: 'center',
														marginBottom: 6,
													}}>
													<Text style={{ color: COLOR_TEXT_STATUS[item.StatusGroup], fontSize: 12 }}>
														{isVN ? statusGroupItem?.Title : statusGroupItem?.TitleEN}
													</Text>
												</View>
											</View>
										</View>
									</View>
									{/* <FImage SW={36} DefaultImagePath={DefaultImagePath} ImagePath={ImagePath} />

									<View style={{ flex: 1 }}>
										<View style={{ flexDirection: 'row', flex: 1 }}>
											<View style={{ flex: 1, marginRight: 4 }}>
												<Text numberOfLines={1}>{AssignedToInfo?.Name}</Text>
												<Text numberOfLines={2}>{item.Content}</Text>
												<Text numberOfLines={2} style={{ fontSize: 12, color: 'rgba(157, 157, 157, 1)' }}>
													{item.Workflow}
												</Text>
											</View>
											<View style={{ alignItems: 'flex-end', justifyContent: 'space-between' }}>
												<Text style={{ fontSize: 12, color: 'rgba(157, 157, 157, 1)' }}>
													{dayjs(item.Created).format(isVN ? 'DD/MM/YYYY HH:mm' : 'MM/DD/YYYY HH:mm')}
												</Text>
												<View
													style={{
														backgroundColor: COLOR_STATUS[item.StatusGroup],
														paddingVertical: 4,
														minWidth: 100,
														borderRadius: 4,
														alignItems: 'center',
													}}>
													<Text style={{ color: COLOR_TEXT_STATUS[item.StatusGroup], fontSize: 12 }}>
														{isVN ? statusGroupItem?.Title : statusGroupItem?.TitleEN}
													</Text>
												</View>
											</View>
										</View>
										<View
											style={{ height: 1, width: '100%', backgroundColor: 'rgba(238, 238, 238, 1)', marginTop: 16 }}
										/>
									</View> */}
								</View>
							</TouchableOpacity>
						);
					}}
				/>
				{!!select?.length && (
					<TouchableOpacity
						disabled={!select?.length}
						onPress={onPressChooseItem}
						style={{
							height: 40,
							backgroundColor: select?.length ? 'rgba(0, 95, 212, 1)' : 'grey',
							marginBottom: 20,
							marginHorizontal: 20,
							borderRadius: 8,
							alignItems: 'center',
							justifyContent: 'center',
						}}>
						<Text style={{ color: 'white', fontWeight: '600', fontSize: 16 }}>
							{translate('choose')}
							{select?.length ? ` (${select?.length})` : ''}
						</Text>
					</TouchableOpacity>
				)}
			</View>
			<ModalCalendarRef ref={refModalCalendar} onSubmitSelect={onSubmitSelectDate} />
			<ModalWorkflow isMulti ref={refModalWorkflow} onSubmitSelect={onSubmitSelectWorkflow} />
			<ModalState ref={refModalState} onSubmitSelect={onSubmitSelectState} />
		</SafeAreaView>
	);
};

export default CreateRelated;
