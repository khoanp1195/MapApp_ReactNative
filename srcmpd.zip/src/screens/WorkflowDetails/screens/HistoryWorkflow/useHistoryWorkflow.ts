import { useEffect, useState } from 'react';

import { RouteProp } from '@react-navigation/native';
import { ICONS } from 'config/images';
import { useAppDispatch } from 'stores';
import { getWokflowHistory } from 'stores/Workflows/sliceWorkflow';

import { ChildHistory2, IHistoryWorkflow } from './type';

type Params = {
	Item: {
		ID: number;
		Content: string;
	};
};

export const useHistoryWorkflow = (route: RouteProp<Params, 'Item'>) => {
	const dispatch = useAppDispatch();
	const [history, setHistory] = useState<IHistoryWorkflow[]>([]);

	const getSuccess = (res: { data: ChildHistory2[] }) => {
		const arrHistoryOrg = res?.data;
		const retValue: IHistoryWorkflow[] = [];
		let step = 0;

		if (arrHistoryOrg !== null && arrHistoryOrg.length > 0) {
			let retItem: any = {};
			arrHistoryOrg.forEach((item: ChildHistory2) => {
				if (!(item.ParentId == null || item.ParentId === '') && item.Status !== 0) {
					return true; // continue
				}

				const tempItem: any = { ChildHistory: [] };
				Object.assign(tempItem, item);

				if (tempItem.Step != step) {
					retItem = { ChildHistory: [] };
					Object.assign(retItem, item);
					step = tempItem.Step;
					retValue.push(retItem);
				}
				if (tempItem.Status == 0) retItem.Status = 0;
				if (tempItem.SubmitActionId == 5 || tempItem.SubmitActionId == 51 || tempItem.SubmitActionId == 55) {
					retItem.SubmitActionId = tempItem.SubmitActionId;
				}
				retItem.ChildHistory.push(tempItem);

				let arrChild = arrHistoryOrg.filter((chldItem: any) => {
					if (chldItem.ParentId == tempItem.ID) return chldItem;
				});
				if (arrChild.length == 0) {
					return true; // continue
				}

				arrChild = arrChild.sort((a: any, b: any) => {
					const dtA = new Date(a.Created);
					const dtB = new Date(b.Created);
					return dtA.getTime() - dtB.getTime();
				});

				const childNotCompleted = arrChild.filter((chldItem: any) => chldItem.Status == 0);

				if (typeof childNotCompleted !== 'undefined' && childNotCompleted.length > 0) retItem.Status = 0;

				const childCancel = arrChild.filter(
					(chldItem: any) => chldItem.SubmitActionId == 5 || chldItem.SubmitActionId == 51,
				);
				if (typeof childCancel !== 'undefined' && childCancel.length > 0)
					retItem.SubmitActionId = childCancel[0].SubmitActionId;

				tempItem.ChildHistory = tempItem.ChildHistory.concat(arrChild);
			});
		}
		setHistory(retValue);
	};

	useEffect(() => {
		dispatch(
			getWokflowHistory({
				params: {
					rid: route.params?.ID,
					lid: 1066,
				},
				success: getSuccess,
			}),
		);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [route.params?.ID]);

	const getIconColor = (item: IHistoryWorkflow) => {
		if ([5, 51, 55].includes(item.SubmitActionId))
			return {
				icon: ICONS.icRemoveRed,
				color: '#FFCBCB',
				addSize: 0,
			}; // red
		if (item.Status === 1)
			return {
				icon: ICONS.icCheckGreen,
				color: 'rgba(220, 255, 218, 1)',
				addSize: 0,
			}; // green
		return {
			icon: ICONS.icYellow,
			color: 'rgba(255, 250, 234, 1)',
			addSize: 0,
		}; // yellow
	};

	return { history, getIconColor };

	// const getSuccess = (res: { data: { data: any } }) => {
	// 	fnc(res?.data?.data);
	// 	const cloneData = JSON.parse(JSON.stringify(res?.data?.data));

	// 	// Tạo một đối tượng theo ID để tìm kiếm nhanh
	// 	const lookup = {};
	// 	cloneData.forEach((item: { ID: string | number; children: never[] }) => {
	// 		lookup[item.ID] = item;
	// 		item.children = [];
	// 	});
	// 	const result = [];

	// 	cloneData.forEach(item => {
	// 		const parent = lookup[item.ParentId];
	// 		if (parent) {
	// 			// Thêm mục con vào mục cha
	// 			parent.children.push(item);
	// 		} else {
	// 			// Nếu không có mục cha, đây là một mục cấp cao nhất
	// 			result.push(item);
	// 		}
	// 	});
	// };
};
