import React from 'react';

import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import FImage from 'components/Organisms/FImage/FImage';
import { ICONS, COLOR_WORKFLOW } from 'config';
import dayjs from 'dayjs';
import useSystem from 'hooks/useSystem';
import { View, Text, Image } from 'react-native';
import { FlatList } from 'react-native-gesture-handler';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { translate } from 'utils/translate';

import { styles } from './styles/HistoryWorkflow.styles';
import { IChildHistory, IHistoryWorkflow, ChildHistory2 } from './type';
import { useHistoryWorkflow } from './useHistoryWorkflow';

const HeaderTransfer = ({ Content }: { Content: string }) => {
	const insets = useSafeAreaInsets();
	const navigation = useNavigation();
	return (
		<View style={[styles.cHead, { paddingTop: insets.top }]}>
			<View style={styles.vIcon}>
				<Icon
					src={ICONS.icArrowMenu}
					width={24}
					height={24}
					tintColor="rgba(0, 0, 0, 1)"
					onPress={() => navigation.goBack()}
				/>
				<Text numberOfLines={1} style={styles.tTitle}>
					{translate('worklfowHistory')}
					<Text style={{ color: 'rgba(157, 157, 157, 1)' }}> / {Content}</Text>
				</Text>
			</View>
		</View>
	);
};

const ItemChildHistory = ({ item }: { item: IHistoryWorkflow | IChildHistory | ChildHistory2 }) => {
	const { isVN, formatDateTime } = useSystem();
	const action: number = item?.SubmitActionId || 0;
	return (
		<View style={styles.cItem}>
			<FImage SW={32} ImagePath={item.AssignUserAvatar} mh={0} />
			<View style={styles.vItem}>
				<View style={styles.vName}>
					<Text numberOfLines={1} style={{ flex: 1 }}>
						{item.AssignUserName}
					</Text>
					<Text style={styles.tDate}>
						{item?.CompletedDate ? dayjs(item.CompletedDate).format(formatDateTime) : ''}
					</Text>
				</View>
				<View style={styles.vDesc}>
					<Text style={styles.tPosition}>{item?.AssignPositionTitle}</Text>
					<View style={[styles.vBoxAction, { backgroundColor: COLOR_WORKFLOW[action] || '#F0F0F0' }]}>
						<Text style={styles.tAction}>{isVN ? item?.SubmitAction?.trim() : item?.SubmitActionEN?.trim()}</Text>
					</View>
				</View>
				<Text>{item?.Comment}</Text>
			</View>
		</View>
	);
};

type Params = {
	Item: {
		ID: number;
		Content: string;
	};
};

const HistoryWorkflow = () => {
	const route = useRoute<RouteProp<Params, 'Item'>>();
	const { isVN } = useSystem();
	const { history, getIconColor } = useHistoryWorkflow(route);

	const renderChildren = (children: IChildHistory) => {
		return children?.ChildHistory?.map((item, index) => {
			return (
				<View style={{ marginLeft: 50 }} key={index?.toString()}>
					<ItemChildHistory item={item} />
				</View>
			);
		});
	};

	const renderParent = (item: IHistoryWorkflow) => {
		return (
			<View style={{ marginTop: 10 }}>
				{item?.ChildHistory?.map((children: IChildHistory, index: number) => {
					return (
						<View style={{ marginLeft: 20 }} key={index?.toString()}>
							<ItemChildHistory item={children} />
							{!!children?.ChildHistory?.length && (
								<View style={{ marginVertical: 12 }}>{renderChildren(children)}</View>
							)}
						</View>
					);
				})}
			</View>
		);
	};

	const renderItem = ({ item, index }: { item: IHistoryWorkflow; index: number }) => {
		const info = getIconColor(item);
		return (
			<View
				style={{
					borderLeftWidth: index === history.length - 1 ? 0 : 1,
					borderLeftColor: 'rgba(229, 229, 229, 1)',
				}}>
				<View style={styles.vLine}>
					<View style={styles.vDot}>
						<Icon src={info.icon} width={20 + info.addSize} height={20 + info.addSize} style={{ marginRight: 2 }} />
						<View style={styles.vLineText}>
							<Image source={ICONS.icLineGreen} style={[styles.iLine, { tintColor: info.color }]} />
							<View style={styles.vText}>
								<Text style={{ fontWeight: index === 0 ? '400' : '400' }}>{isVN ? item?.Action : item.ActionEN}</Text>
							</View>
						</View>
					</View>
				</View>
				{renderParent(item)}
			</View>
		);
	};

	return (
		<View style={styles.container}>
			<HeaderTransfer Content={route.params?.Content} />
			<FlatList
				showsVerticalScrollIndicator={false}
				contentContainerStyle={styles.cFlatlist}
				data={history}
				keyExtractor={(item, index) => index?.toString()}
				renderItem={renderItem}
			/>
		</View>
	);
};

export default HistoryWorkflow;
