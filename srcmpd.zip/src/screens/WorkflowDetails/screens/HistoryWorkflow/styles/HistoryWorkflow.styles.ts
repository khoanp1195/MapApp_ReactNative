import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
	container: { flex: 1 },
	cFlatlist: { marginHorizontal: 20, marginTop: 20, paddingBottom: 50 },
	vLine: {
		flexDirection: 'row',
		alignItems: 'flex-start',
	},
	vDot: { flexDirection: 'row', alignItems: 'center', marginTop: -6, marginLeft: -10 },
	vLineText: {
		flex: 1,
		height: 30,
	},
	iLine: { width: '100%', height: '100%' },
	vText: { position: 'absolute', bottom: 6, left: 20 },

	//

	cItem: {
		flexDirection: 'row',
		overflow: 'hidden',
		backgroundColor: 'white',
	},
	vItem: { flex: 1, marginLeft: 8, marginBottom: 8 },
	vName: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		alignItems: 'center',
	},
	tDate: { fontSize: 12, color: 'rgba(94, 94, 94, 1)' },
	vDesc: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
	tPosition: { fontSize: 12, color: 'rgba(94, 94, 94, 1)' },
	vBoxAction: {
		paddingVertical: 4,
		alignItems: 'center',
		borderRadius: 3,
		paddingHorizontal: 8,
	},
	tAction: { fontSize: 12, fontWeight: '400' },

	//

	cHead: {
		flexDirection: 'row',
		shadowColor: '#000',
		shadowOffset: {
			width: 0,
			height: 2,
		},
		shadowOpacity: 0.1,
		shadowRadius: 2,
		elevation: 5,
		backgroundColor: 'white',
		paddingBottom: 10,
		paddingHorizontal: 16,
		zIndex: 99,
	},
	vIcon: { flexDirection: 'row', flex: 1, alignItems: 'center', marginRight: 20 },
	tTitle: { fontSize: 16, fontWeight: '700', marginLeft: 12, color: 'rgba(0, 0, 0, 1)' },
});
