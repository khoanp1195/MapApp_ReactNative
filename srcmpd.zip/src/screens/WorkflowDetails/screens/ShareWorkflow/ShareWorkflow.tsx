/* eslint-disable prettier/prettier */

import React, { useRef, useState, useEffect } from 'react';

import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { ShowLoading } from 'components/Atoms/Loading/LoadingGlobal';
import FImage from 'components/Organisms/FImage/FImage';
import { COLORS, ICONS } from 'config';
import { RoutesNames } from 'navigation/RoutesNames';
import { View, TouchableOpacity, Text, TextInput, Alert } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { IUser } from 'screens/TaskDetail/screens/SearchUser';
import { useAppDispatch } from 'stores';
import { getHistoryShare, postShareWorkflow } from 'stores/Workflows/sliceWorkflow';
import { translate } from 'utils/translate';

import { ItemHistoryShare } from './HistoryShare';


const HeaderShareTask = ({ Content, onPressHitory }: { Content: string; onPressHitory: () => void }) => {
	const insets = useSafeAreaInsets();
	const navigation = useNavigation()
	const refContent = useRef<string>()


	useEffect(() => {
		if (Content) {
			refContent.current = Content
		}
	}, [Content])

	return (
		<View style={{
			flexDirection: 'row', shadowColor: "#000",
			shadowOffset: {
				width: 0,
				height: 2,
			},
			shadowOpacity: 0.1,
			shadowRadius: 2,

			elevation: 5,
			backgroundColor: 'white',
			paddingTop: insets.top,
			paddingBottom: 10,
			paddingHorizontal: 16,

		}}>
			<View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
				<Icon src={ICONS.icArrowMenu} width={24} height={24} tintColor="rgba(0, 0, 0, 1)" onPress={() => navigation.goBack()} />
				<Text numberOfLines={1} style={{ fontSize: 16, fontWeight: '700', marginLeft: 12, color: 'rgba(0, 0, 0, 1)' }} >{translate('share')}
					<Text style={{ color: 'rgba(157, 157, 157, 1)' }}> / {refContent.current}</Text></Text>
			</View>
			<View style={{ marginLeft: 40, alignItems: 'center' }}>
				<Icon src={ICONS.icHistoryShare} width={24} height={24} tintColor="rgba(0, 0, 0, 1)" onPress={onPressHitory} />
			</View>
		</View>
	)
}


type Params = {
	Item: {
		ID: number;
		ParamsCallback: {
			action: string;
			data: IUser[]
		};
		Content: string
	};
};

const ShareWorkflow = () => {
	const route = useRoute<RouteProp<Params, 'Item'>>();
	const dispatch = useAppDispatch();
	const navigation = useNavigation();

	const [err, setErr] = useState(false)
	const [user, setUser] = useState<IUser[]>([]);
	const [history, setHistory] = useState<Array<any>>([]);
	const fistHistory = history?.length > 0 ? history[0] : {}

	const [idea, setIdea] = useState('');
	const refRID = useRef<number>()
	const refContent = useRef<string>()

	const { ID, ParamsCallback, Content } = route.params || {};



	const onSuccess = (res: { data: Array<any> }) => {
		setHistory(res?.data || []);
	};


	useEffect(() => {

		if (ParamsCallback?.action === RoutesNames.ShareWorkflow) {
			setUser(ParamsCallback?.data)
		}
	}, [ParamsCallback]);

	useEffect(() => {
		if (ID) {
			refRID.current = ID
			refContent.current = Content
			dispatch(getHistoryShare({
				params: { rid: refRID.current }, success: onSuccess
			}))
		}
	}, [ID])


	const getUserGroupValues = () => {
		let listUsers = '';
		user?.map((item, index) => {
			if (index === 0) {
				listUsers = listUsers.concat(`${item?.ID}`);
			} else {
				listUsers = listUsers.concat(`,${item?.ID}`);
			}
		});
		return listUsers;
	};

	const onSuccessShare = () => {
		ShowLoading(false)
		navigation.goBack();
	};

	const onSubmit = () => {
		const usergroupvalues = getUserGroupValues();
		if (!usergroupvalues?.length || !idea) return setErr(true)
		ShowLoading(true)
		dispatch(
			postShareWorkflow({
				params: {
					rid: refRID.current,
					usergroupvalues,
					idea,
				},
				success: onSuccessShare,
			}),
		);
	};

	const options = {
		isMultiple: true,
		type: -1,
		isAddInfo: false,
	};

	const searchUser = () => navigation.navigate(RoutesNames.SearchUser, { RID: refRID.current, user, from: RoutesNames.ShareWorkflow, options });

	const onPressSeeAll = () => {
		navigation.navigate(RoutesNames.HistoryShare, { history, Content: refContent.current })
	}


	return (
		<View style={{ backgroundColor: 'white', flex: 1 }}>
			<HeaderShareTask Content={Content} onPressHitory={onPressSeeAll} />
			<ScrollView showsVerticalScrollIndicator={false} style={{ flex: 1, }}>
				<View style={{ marginTop: 20, paddingHorizontal: 16, paddingBottom: 50 }}>
					<TouchableOpacity onPress={searchUser} style={{
						flexDirection: 'row',
						borderRadius: 8,
						borderColor: err && !user.length ? COLORS.red : 'rgba(217, 217, 217, 1)',
						borderWidth: 1,
						padding: 10,
						paddingLeft: 20,
						overflow: 'hidden'
					}}>
						<View style={{ flex: 1, flexWrap: 'wrap', flexDirection: 'row' }}>
							{user?.length ? (
								user.map((item, index) => {
									const { ImagePath, Name, DefaultImagePath, ID } = item
									const onDeleteUser = () => {
										setUser(user.filter(e => e.ID !== ID))
									}

									return <View key={index?.toString()} style={{
										backgroundColor: 'rgba(240, 240, 240, 1)',
										borderRadius: 20,
										padding: 4,
										marginRight: 10,
										marginBottom: 4,
										flexDirection: 'row',
										alignItems: 'center',
										overflow: 'hidden',
										justifyContent: 'space-between',
									}}>
										<View style={{ flexDirection: 'row', alignItems: 'center', maxWidth: '85%', marginRight: 6 }}>
											<FImage ImagePath={ImagePath} DefaultImagePath={DefaultImagePath} SW={20} mh={2} />
											<Text numberOfLines={0} style={{ marginLeft: 4 }}>{Name}</Text>
										</View>
										<Icon src={ICONS.icCancelGrey} width={16} height={16} onPress={onDeleteUser} />
									</View>
								})
							) : <Text style={{ color: 'rgba(157, 157, 157, 1)' }}>{translate('shareUser')}</Text>}



						</View>
						<Icon src={ICONS.icUserAdd} width={24} height={24} onPress={searchUser} />
					</TouchableOpacity>
					{err && !user.length &&
						<Text style={{ fontSize: 12, color: COLORS.red, fontStyle: 'italic' }}>{translate('userRequired')}</Text>}
					<View style={{
						borderRadius: 8,
						borderColor: err && !idea.length ? COLORS.red : 'rgba(217, 217, 217, 1)',
						borderWidth: 1,
						minHeight: 90,
						padding: 10,
						marginTop: 20,
						maxHeight: 150
					}}>
						<TextInput value={idea} multiline placeholder={translate('enterIdea')} onChangeText={setIdea} />

					</View>
					{err && !idea.length && <Text style={{ fontSize: 12, color: COLORS.red, fontStyle: 'italic' }}>{translate('opinionRequired')}</Text>}

					<TouchableOpacity style={{ backgroundColor: 'rgba(0, 95, 212, 1)', alignItems: 'center', paddingVertical: 12, borderRadius: 8, marginTop: 20 }}
						onPress={onSubmit}>
						<Text style={{ fontWeight: '600', color: '#fff' }}>{translate('share').toLocaleUpperCase()}</Text>
					</TouchableOpacity>
				</View>
				{!!history?.length && <View style={{ marginBottom: 100 }}>
					<View style={{ marginTop: 26 }}>
						<View style={{ backgroundColor: 'rgba(238, 238, 238, 1)', paddingHorizontal: 16, paddingVertical: 12 }}>
							<Text style={{ color: 'rgba(123, 123, 123, 1)', fontSize: 12, fontWeight: '700' }}>
								{translate('shareHistory')}
							</Text>
						</View>

					</View>
					<ItemHistoryShare item={fistHistory} />
					{history?.length > 1 && <View style={{ alignItems: 'center', }}>
						<TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center' }} onPress={onPressSeeAll}>
							<Text style={{ color: 'rgba(0, 95, 212, 1)', fontSize: 12 }}>{translate('seeAll')}</Text>
							<Icon src={ICONS.icChevronDown} width={16} height={16} tintColor="rgba(0, 95, 212, 1)" />
						</TouchableOpacity>
					</View>}
				</View>}
			</ScrollView>

		</View>
	);
};

export default ShareWorkflow;
