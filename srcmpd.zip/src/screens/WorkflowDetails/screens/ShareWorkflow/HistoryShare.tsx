import React from 'react';

import { useNavigation, useRoute } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import FImage from 'components/Organisms/FImage/FImage';
import { ICONS } from 'config/images';
import dayjs from 'dayjs';
import useSystem from 'hooks/useSystem';
import { View, Text, FlatList, TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { translate } from 'utils/translate';

const HeaderHistory = ({ Content }) => {
	const insets = useSafeAreaInsets();
	const navigation = useNavigation();
	return (
		<View
			style={{
				flexDirection: 'row',
				shadowColor: '#000',
				shadowOffset: {
					width: 0,
					height: 2,
				},
				shadowOpacity: 0.1,
				shadowRadius: 2,
				elevation: 5,
				backgroundColor: 'white',
				paddingTop: insets.top,
				paddingBottom: 10,
				paddingHorizontal: 16,
			}}>
			<View style={{ flexDirection: 'row', flex: 1, alignItems: 'center', marginRight: 20 }}>
				<Icon
					src={ICONS.icArrowMenu}
					width={24}
					height={24}
					tintColor="rgba(0, 0, 0, 1)"
					onPress={() => navigation.goBack()}
				/>
				<Text numberOfLines={1} style={{ fontSize: 16, fontWeight: '700', marginLeft: 12, color: 'rgba(0, 0, 0, 1)' }}>
					{translate('shareHistory')}
					<Text style={{ color: 'rgba(157, 157, 157, 1)' }}> / {Content}</Text>
				</Text>
			</View>
			{/* <View style={{ marginLeft: 40, alignItems: 'center' }}>
				<Icon src={ICONS.icClock} width={22} height={22} tintColor="rgba(0, 0, 0, 1)" />
			</View> */}
		</View>
	);
};

export const ItemHistoryShare = ({ item }) => {
	const { ImagePath, PositionName, ToUserInfo = '[]', Description = '', Created, Name } = item || {};
	const PToUserInfo = JSON.parse(ToUserInfo || '[]');
	const { formatDateTime } = useSystem();

	const checkScript = () => {
		if (Description?.includes('</')) return true;
		return false;
	};
	// const isHideDes = checkScript();

	return (
		<View style={{ overflow: 'hidden', margin: 16, marginTop: 20 }}>
			<View style={{ flexDirection: 'row' }}>
				<FImage mh={0} ImagePath={ImagePath} />
				<View style={{ flex: 1, marginLeft: 10 }}>
					<View style={{ marginBottom: 8 }}>
						<View style={{ flexDirection: 'row', alignItems: 'center' }}>
							<Text numberOfLines={1} style={{ flex: 1 }}>
								{Name}
							</Text>
							<Text style={{ color: 'rgba(123, 123, 123, 1)', fontSize: 12, fontWeight: '500' }}>
								{dayjs(Created).format(formatDateTime)}
							</Text>
						</View>
						<Text numberOfLines={1} style={{ color: 'rgba(123, 123, 123, 1)', fontSize: 12 }}>
							{PositionName}
						</Text>
					</View>
					<Text>{Description}</Text>
					{!!PToUserInfo?.length && (
						<View style={{ marginTop: 16 }}>
							{PToUserInfo?.map((item, index) => {
								const { Name, PositionName, ImagePath, DefaultImagePath } = item;
								return (
									<View key={index?.toString()} style={{ flexDirection: 'row', marginBottom: 16 }}>
										<FImage mh={0} ImagePath={ImagePath} DefaultImagePath={DefaultImagePath} />
										<View style={{ marginBottom: 8, marginLeft: 10, justifyContent: 'center' }}>
											<Text numberOfLines={1} style={{}}>
												{Name}
											</Text>
											{!!PositionName && (
												<Text numberOfLines={1} style={{ color: 'rgba(123, 123, 123, 1)', fontSize: 12 }}>
													{PositionName}
												</Text>
											)}
										</View>
									</View>
								);
							})}
						</View>
					)}
				</View>
			</View>
			<View style={{ height: 1, width: '100%', backgroundColor: 'rgba(238, 238, 238, 1)' }} />
		</View>
	);
};

const HistoryShare = () => {
	const route = useRoute();
	const { history, Content } = route.params || {};
	return (
		<View>
			<HeaderHistory Content={Content} />
			<FlatList
				data={history || []}
				keyExtractor={(item, index) => index?.toString()}
				renderItem={({ item, index }) => <ItemHistoryShare item={item} />}
				ListFooterComponent={() => <View style={{ height: 100 }} />}
				showsVerticalScrollIndicator={false}
			/>
		</View>
	);
};

export default HistoryShare;
