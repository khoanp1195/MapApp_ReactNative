/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable import/no-cycle */
/* eslint-disable array-callback-return */
/* eslint-disable react/no-children-prop */
/* eslint-disable react/jsx-props-no-spreading */
import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';

import { RouteProp, useRoute } from '@react-navigation/native';
import { ShowLoading } from 'components/Atoms/Loading/LoadingGlobal';
import ActionButton, { IListAction } from 'components/WorkflowDetails/ActionButton';
import Attachment from 'components/WorkflowDetails/Attachments/Attachment';
import Comment from 'components/WorkflowDetails/Comments/Comment';
import HeaderWorkflowDetails from 'components/WorkflowDetails/HeaderWorkflowDetails';
import InfoAssign from 'components/WorkflowDetails/InfoAssign';
import ModalAction from 'components/WorkflowDetails/Modal/ModalAction';
import ModalRelated from 'components/WorkflowDetails/Modal/ModalRelated';
import TabBarWorkFlowDetails, { TABNAME_WORKFLOW } from 'components/WorkflowDetails/TabBarWorkFlowDetails';
import ToastWorkflow from 'components/WorkflowDetails/ToastWorkflow';
import Workflow from 'components/WorkflowDetails/Workflows/Workflow';
import { ICONS } from 'config';
import { navigate } from 'navigation/RootNavigation';
import { RoutesNames } from 'navigation/RoutesNames';
import {
	View,
	NativeSyntheticEvent,
	NativeScrollEvent,
	ScrollView,
	RefreshControl,
	Keyboard,
	Dimensions,
	KeyboardAvoidingView,
	Platform,
	Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ButtomNewTicket } from 'screens/Apps/Containers';
import TaskDetailScreen from 'screens/TaskDetail';
import TaskFlow from 'screens/TaskDetail/Components/TaskFlow';
import { IUser } from 'screens/TaskDetail/screens/SearchUser';
import { usePermisstionAttach } from 'screens/TaskDetail/useHooks/usePermissionEdit';
import { useAppDispatch, useAppSelector } from 'stores';
import { fetchCount } from 'stores/Count/thunks';
import { reloadWorkflow } from 'stores/System';
import { clearDetails, postActionWorkflow, resetFieldHide, setInit } from 'stores/Workflows/sliceWorkflow';
import { translate } from 'utils/translate';

import { useWorkflow } from './useWorkflow';

export interface IItemParams {
	ID: number;
	Read: boolean;
	ListID: string;
	SPItemId: number;
	NotifyId: string;
	NotifyCreated: string;
	Content: string;
	WorkflowId: number;
	AssignedBy: string;
	AssignedByInfo: string;
	AssignedTo: string;
	Created: string;
	StatusGroup: number;
	DueDate: string;
	FileCount: number;
	CommentCount: number;
	Flag: number;
	ResourceCategoryId: number;
	ResourceSubCategoryId: number;
	Workflow: string;
	TotalRecord: number;
	Title?: string;
	TitleEN?: string;
	WorkflowID?: string;
}

type Params = {
	Item: {
		item: IItemParams;
		isScrollToTop: boolean;
		listProcedures: any[];
		onUpdateTask: () => void;
		onUpdateFollow: () => void;
		ParamsCallback: {
			action: string;
			data: any;
		};
	};
};

const WorkflowDetails = () => {
	const dispatch = useAppDispatch();
	const route = useRoute<RouteProp<Params, 'Item'>>();
	const windowHeight = Dimensions.get('window').height;
	const insets = useSafeAreaInsets();

	const refTaskDetailScreen = useRef<{
		getDataGrid: () => void;
		getGrid: (guid: string) => void;
		require: () => void;
	} | null>();
	const refTabBarWorkFlowDetails = useRef<{ ScrollY: (value: any) => void } | null>();
	const refHeaderWorkflowDetails = useRef<{ ScrollY: (value: any) => void } | null>();
	const refInfoAssign = useRef<{ ScrollY: (value: any) => void } | null>();
	const refModalAction = useRef<{ show: (action: IListAction, data?: any) => void; hide: () => void } | null>(null);
	const refToastWorkflow = useRef<{
		show: ({ status, message }: { status: number; message: string }) => void;
		hide: () => void;
	} | null>(null);
	const refModalRelated = useRef<{ show: (action: IListAction, data?: any) => void; hide: () => void } | null>(null);
	const scrollRef = useRef<ScrollView | null>(null);
	const lastOffset = useRef<number>(0);
	const scrollDirection = useRef('');
	// const refPosition = useRef({
	// 	[TABNAME_WORKFLOW.INFOMATION]: 0,
	// 	[TABNAME_WORKFLOW.ATTACHMENT]: 0,
	// });
	const refAction = useRef<IListAction>({});
	const refAttachment = useRef<{ add: () => void; hide: () => void } | null>(null);

	const {
		attachmets,
		related,
		listFieldNameHides,
		details,
		itemInfo: infoItem,
	} = useAppSelector(store => store.workflow);

	const { Content = '', Step } = details?.FormConfig || {};
	// console.log('details', JSON.parse(details.FormConfig?.DefindJsonObj));
	const itemPrams: IItemParams = route.params.item || {};
	const { ID: rid } = itemPrams;
	const {
		forms,
		onRefresh,
		refreshing,
		ListAction,
		NotifiedUsersInfo,
		DocStatus,
		onReloadDetails,
		WorkflowStepRelate,
		ShowToast,
		updateShowToast,
		loadingDetails,
	} = useWorkflow(itemPrams);
	const workflowsApps = useAppSelector(store => store.apps.workflowsApps);
	// Alert.alert(JSON.stringify(itemPrams));

	const { isPermission } = usePermisstionAttach();

	const moreOptionInfo = JSON.parse(forms?.InfoCollection?.FormDefineInfo || '[]')?.[0]?.moreOptionInfo;
	const allowAttach = moreOptionInfo?.allowAttach;

	const ListDocumentCategory: any[] = JSON.parse(details?.FormConfig?.ListDocumentCategory || '[]');
	const listDocumentRequire: any[] = ListDocumentCategory?.filter(item => item.Step === Step && item?.Required);

	const [status, setStatus] = useState(TABNAME_WORKFLOW.INFOMATION);

	const { ParamsCallback } = route.params;

	const onScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
		const { y } = event.nativeEvent.contentOffset;
		scrollDirection.current = y - lastOffset.current > 0 ? 'down' : 'up';
		lastOffset.current = event.nativeEvent.contentOffset.y;
		// refPosition.current = { ...refPosition.current, ...{ [status]: y } };
		refTabBarWorkFlowDetails.current?.ScrollY(y);
		refHeaderWorkflowDetails.current?.ScrollY(y);
		refInfoAssign.current?.ScrollY(y);
	};

	const onScrollEndDrag = () => {
		if (scrollDirection.current === 'down' && lastOffset.current < 150) {
			return scrollRef.current?.scrollTo({
				y: 150,
				animated: true,
			});
		}
		if (scrollDirection.current === 'up' && lastOffset.current < 150) {
			scrollRef.current?.scrollTo({
				y: 0,
				animated: true,
			});
		}
	};

	useEffect(() => {
		if (ParamsCallback?.action === RoutesNames.WorkflowDetails) {
			refModalAction.current?.show(refAction.current, ParamsCallback.data);
		}
		return () => {
			dispatch(setInit(false));
			dispatch(resetFieldHide());
			// dispatch(clearDetails());
		};
	}, [ParamsCallback]);

	useLayoutEffect(() => {
		if (refreshing) {
			setTimeout(() => {
				scrollRef.current?.scrollTo({
					y: 0,
					animated: true,
				});
			}, 500);
		}
	}, [refreshing]);

	useLayoutEffect(() => {
		scrollRef.current?.scrollTo({
			y: 0,
			animated: true,
		});
	}, [status]);

	useEffect(() => {
		if (ShowToast) {
			refToastWorkflow.current?.show(ShowToast);
			updateShowToast();
		}
	}, [ShowToast]);

	const saveSuccess = (res: BaseAPIResponse<{ HaveStepDynamic: boolean }>, action: { Title: string }) => {
		console.log('saveSuccess');

		// dispatch(fetchCount({ WorkflowId: workflowsApps?.WorkflowID || 0 }));
		let message = `${action?.Title} ${translate('successfully')}`;
		let stt = 2;
		if (res?.status === 'SUCCESS') {
			if (res?.data?.HaveStepDynamic) {
				message = translate('processChooseUser');
				stt = 1;
				refToastWorkflow.current?.show({
					status: stt,
					message,
				});
				ShowLoading(false);
			} else {
				onReloadDetails({
					status: stt,
					message,
				});

				// ShowLoading(false);
			}
			refTaskDetailScreen.current?.getDataGrid();
		} else {
			stt = 3;
			message = res?.mess?.Value;
			refToastWorkflow.current?.show({
				status: stt,
				message: `${action?.Title} ${translate('FailedAction')}`,
			});
			ShowLoading(false);
		}
	};

	const getUserGroupValues = (user: IUser[]) => {
		let listUsers = '';
		user?.map((item, index) => {
			if (index === 0) {
				listUsers = listUsers.concat(`${item?.ID}`);
			} else {
				listUsers = listUsers.concat(`,${item?.ID}`);
			}
		});
		return listUsers;
	};

	const callActionDetails = (action: any, formData?: any, attach?: any, workflowrelated?: any) => {
		dispatch(
			postActionWorkflow({
				params: {
					func: action.ActionCode,
					rid,
					itemInfo: formData,
					attachment: attach,
					workflowrelated,
				},
				success: res => saveSuccess(res, action),
				failed: () => {
					refToastWorkflow.current?.show({
						status: 3,
						message: `${action?.Title} ${translate('FailedAction')}`,
					});
					ShowLoading(false);
				},
			}),
		);
	};

	const getAttachments = () => {
		let listConvert: Array<{
			Name: string;
			Base64?: string;
			AttachTypeId: number;
			AttachTypeName: string;
		}> = [];
		const listAtatch = attachmets?.filter(attachment => !attachment?.ID);
		listAtatch?.map(attachment => {
			listConvert = [
				...listConvert,
				{
					Name: `${attachment.Title}.${attachment.Extension}`,
					Base64: attachment?.Base64 || attachment?.base64,
					AttachTypeId: attachment.AttachTypeId,
					AttachTypeName: attachment.AttachTypeName,
				},
			];
		});
		return listConvert;
	};

	const getDataField = () => {
		const defaultInfo = details.ItemInfo;
		const FieldInfo = forms?.FormFieldInfo;
		const changedKeys: { [key: string]: string | any[] } = {};

		for (const key in defaultInfo) {
			if (defaultInfo[key] !== infoItem[key]) {
				changedKeys[key] = infoItem[key];
			}
		}

		const listNameChanged = Object.keys(changedKeys);

		let ListData: Array<any> = [];

		function getValue(Name: string, FieldTypeId: number, Guid: string) {
			const valueItem: string | any[] = changedKeys?.[Name];

			if ([7].includes(FieldTypeId)) {
				const data: any[] = Array.isArray(valueItem) ? valueItem : JSON.parse(valueItem || '[]');
				let id: number[] = [];
				data?.forEach(item => {
					id = [...id, item.ID];
				});
				return id.toString();
			}
			if ([13, 14].includes(FieldTypeId)) {
				const grid: { isGrid: boolean; value: any } = refTaskDetailScreen.current?.getGrid(Guid) || {
					isGrid: false,
					value: null,
				};
				if (grid?.isGrid) {
					return grid?.value;
				}
				const ArrValueSplit: string[] = typeof valueItem === 'string' ? valueItem?.split(';#') : [];

				const Value = ArrValueSplit.filter(item => item !== '').filter((item, index) => index % 2 === 0);

				return Value.toString();
			}
			return valueItem;
		}

		FieldInfo.forEach(fieldInfo => {
			if (listNameChanged.includes(fieldInfo?.Name) && !listFieldNameHides.includes(fieldInfo?.Name)) {
				let detailsListInfo = null;
				const data = JSON.parse(forms?.InfoCollection?.FormDefineInfo || '[]');
				const detailsTableInfoCollection: Array<any> = (data?.length && data[0].detailsTableInfoCollection) || [];
				detailsTableInfoCollection?.map((res: { id: string; detailsListInfo: any }) => {
					if (res.id === fieldInfo?.Guid) {
						detailsListInfo = res.detailsListInfo;
					}
				});

				const convertData = {
					Name: fieldInfo.Name,
					Guid: fieldInfo?.Guid,
					Value: getValue(fieldInfo.Name, fieldInfo?.FieldTypeId, fieldInfo?.Guid),
					FieldTypeId: fieldInfo?.FieldTypeId,
					DetailsListInfo: detailsListInfo,
				};
				ListData = [...ListData, convertData];
			}
		});

		return ListData;
	};

	const getListWorkflowRelated = () => {
		let request: Array<{
			ID: number;
			ListID: string;
			WorkflowId: number;
			Title: string;
		}> = [];
		related.forEach(item => {
			if (!item?.WorkflowRelatedId) {
				request = [
					...request,
					{
						ID: item.ID,
						ListID: item?.ListID,
						WorkflowId: item?.WorkflowId,
						Title: item?.Title,
					},
				];
			}
		});
		return request;
	};

	const onSubmitAction = (action: any, usergroupvalues: IUser[], idea: string) => {
		const attachments = getAttachments();
		const formData = getDataField();
		const workflowrelated = getListWorkflowRelated();

		const isUseData = action.ActionCode === 'APPROVE' || action.ActionCode === 'NEXT';
		ShowLoading(true);

		dispatch(
			postActionWorkflow({
				params: {
					func: action.ActionCode,
					rid,
					itemInfo: isUseData ? formData || null : null,
					attachment: attachments,
					workflowrelated,
					usergroupvalues: getUserGroupValues(usergroupvalues),
					idea,
				},
				success: res => saveSuccess(res, action),
				failed: () => {
					refToastWorkflow.current?.show({
						status: 3,
						message: `${action?.Title} ${translate('FailedAction')}`,
					});
					ShowLoading(false);
				},
			}),
		);
	};

	const refListDocRq = useRef<string[]>([]);

	const checkRequiredAttach = () => {
		if (!moreOptionInfo?.allowAttach) {
			return true;
		}
		let rq = true;
		listDocumentRequire.forEach((elm: { ID: number; Title: string }) => {
			const isPass = attachmets.find(item => item?.AttachTypeId === elm?.ID);
			if (!isPass) {
				rq = false;

				if (!refListDocRq.current?.includes(elm?.Title)) {
					refListDocRq.current = [...refListDocRq.current, elm?.Title];
				}
			} else {
				refListDocRq.current = refListDocRq.current.filter(e => e !== elm?.Title);
			}
		});
		return rq;
	};

	const onPressCallAction = (action: IListAction) => {
		// scrollRef.current?.scrollTo({
		// 	y: 460,
		// 	animated: true,
		// });

		// if (attach === null && action.ActionCode !== 'NEWRELATED') {
		// 	return Alert.alert('Please add attachments');
		// }

		const actionNotCheck = ['RELATED', 'SAVE', 'CANCEL', 'RECALL'].includes(action.ActionCode);
		if (['NEWRELATED'].includes(action.ActionCode))
			return navigate('CreateRelated', { itemPrams: { ...itemPrams, Content } });

		let passing = true;
		if (!actionNotCheck) {
			passing = !!refTaskDetailScreen.current?.require();
		}

		if (!passing && !actionNotCheck) return Alert.alert(translate('requestedInformation'));

		const attachments = getAttachments();

		if (!actionNotCheck) {
			const isRequiredAttach = checkRequiredAttach();
			if (!isRequiredAttach) {
				setStatus(TABNAME_WORKFLOW.ATTACHMENT);
				Alert.alert(`${translate('attachment')}: ${refListDocRq.current.toString()}${translate('isRequire')}`);
				return;
			}
		}

		const formData = getDataField();

		const workflowrelated = getListWorkflowRelated();

		const isQuestionSubmit = DocStatus === 3;

		switch (action.ActionCode) {
			case 'RECALL':
				ShowLoading(true);
				callActionDetails(action);
				break;
			case 'SAVE':
				ShowLoading(true);
				callActionDetails(action, formData, attachments, workflowrelated);
				break;
			case 'SEND':
				ShowLoading(true);
				callActionDetails(action, formData, attachments, workflowrelated);
				break;

			case 'TASK': // Phan cong
				// navigate('Assignment', {
				// 	action,
				// 	ID,
				// 	formData,
				// 	NotifiedUsersInfo,
				// 	isQuestionSubmit,
				// 	onRefresh,
				// 	onUpdateTask,
				// });
				break;
			case 'NEWRELATED':
				navigate('CreateRelated', { itemPrams: { ...itemPrams, Content } });
				break;
			case 'RELATED':
				refModalRelated.current?.show(action);
				break;
			default:
				if (isQuestionSubmit && ['NEXT', 'APPROVE'].includes(action.ActionCode)) {
					Alert.alert(translate('Pending'), '', [
						{
							text: translate('yes'),
							onPress: () => {
								refModalAction.current?.show(action);
							},
						},
						{
							text: translate('no'),
						},
					]);
				} else {
					refModalAction.current?.show(action);
				}
				break;
		}
	};

	const onShowToast = (data: { status: number; message: string }) => {
		refToastWorkflow.current?.show(data);
	};

	const getOptionMultiple = (ActionCode: string) => {
		switch (ActionCode) {
			case 'REPLACE':
				return false;
			case 'ADDINFO':
				return false;

			default:
				return true;
		}
	};

	const onSearchUser = (action: IListAction, user: IUser[]) => {
		refAction.current = action;
		const options = {
			isMultiple: getOptionMultiple(action.ActionCode),
			type: 0,
			isAddInfo: action.ActionCode === 'ADDINFO', // Bo sung thong tin
			NotifiedUsersInfo, // User bo sung thong tin
		};
		navigate(RoutesNames.SearchUser, {
			RID: rid,
			user,
			itemPrams: { ...itemPrams, Content },
			from: RoutesNames.WorkflowDetails,
			options,
		});
	};

	const onAddAttachments = () => {
		refAttachment.current?.add();
	};

	const renderTabScreen = () => {
		switch (status) {
			case TABNAME_WORKFLOW.ATTACHMENT:
				if (!allowAttach) return null;
				return <Attachment ref={refAttachment} rid={rid} moreOptionInfo={moreOptionInfo} />;
			case TABNAME_WORKFLOW.ASSIGN:
				return <TaskFlow ID={rid} />;
			case TABNAME_WORKFLOW.COMMENT:
				return <Comment ID={rid} Content={Content} />;
			case TABNAME_WORKFLOW.RELATED:
				return <Workflow ID={rid} refreshing={refreshing} />;

			default:
				return null;
		}
	};

	const maxHeight = status === TABNAME_WORKFLOW.INFOMATION ? {} : { height: 0 };
	return (
		<View style={{ flex: 1, paddingTop: insets.top - 10 }}>
			<HeaderWorkflowDetails
				ref={refHeaderWorkflowDetails}
				itemPrams={{ ...itemPrams, Content }}
				onShowToast={onShowToast}
			/>
			<KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
				<ScrollView
					shouldRasterizeIOS
					contentContainerStyle={{ minHeight: windowHeight + 100 }}
					ref={scrollRef}
					refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
					onScrollEndDrag={onScrollEndDrag}
					onScroll={onScroll}
					scrollEventThrottle={16}
					stickyHeaderIndices={[1]}
					showsVerticalScrollIndicator={false}
					renderToHardwareTextureAndroid
					// removeClippedSubviews
					nestedScrollEnabled={false}
					onScrollBeginDrag={Keyboard.dismiss}>
					<InfoAssign ref={refInfoAssign} loadingDetails={loadingDetails} />
					<TabBarWorkFlowDetails
						ref={refTabBarWorkFlowDetails}
						itemPrams={{ ...itemPrams, Content }}
						status={status}
						onSetStatus={setStatus}
						allowAttach={allowAttach}
					/>
					{!!Object.keys(forms)?.length && (
						<View style={[{ overflow: 'hidden' }, maxHeight]}>
							<TaskDetailScreen ref={refTaskDetailScreen} forms={forms} itemPrams={{ ...itemPrams, Content }} />
						</View>
					)}
					<View>{renderTabScreen()}</View>
				</ScrollView>
			</KeyboardAvoidingView>
			<ToastWorkflow ref={refToastWorkflow} />
			<ActionButton ListAction={ListAction} onPressCallAction={onPressCallAction} loadingDetails={loadingDetails} />
			<ModalAction ref={refModalAction} onSearchUser={onSearchUser} onSubmitAction={onSubmitAction} />
			<ModalRelated ref={refModalRelated} WorkflowStepRelate={WorkflowStepRelate} itemPrams={itemPrams} />
			{status === TABNAME_WORKFLOW.ATTACHMENT && isPermission && (
				<ButtomNewTicket sizeIcon={20} icon={ICONS.icUpload} onPress={onAddAttachments} />
			)}
		</View>
	);
};

export default WorkflowDetails;
