import React, { useCallback } from 'react';

import en from 'assets/i18n/en';
import { EmptyState } from 'components/Atoms/EmptyState';
import { Loading } from 'components/Atoms/Loading';
import { NotificationCard } from 'components/Organisms/NotificationCard';
import { COLORS } from 'config';
import { ActivityIndicator, RefreshControl, SectionList, View } from 'react-native';
import { translate } from 'utils/translate';

import { Container, styles } from './styles';
import { useNotification } from './useNotification';
import { TextCustom, Wrapper } from '../../styles';

interface Props {
	type: 'ALL' | 'UNREAD';
}

export const NotificationContainer: React.FC<Props> = ({ type }) => {
	const { page, bottom, dataRes, loading, language, refreshing, customizeTasks, refreshPage, handleEndReached } =
		useNotification({
			type,
		});

	const renderTitle = useCallback(
		(title: string) => {
			return (
				<Wrapper mLeft={15} mTop={14} mBottom={14}>
					<TextCustom allowFontScaling={false} fw={700} fs={15} lh={20} color={COLORS.darkJungleGreen}>
						{translate(title as keyof typeof en)}
					</TextCustom>
				</Wrapper>
			);
		},
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[language],
	);

	return (
		<Container>
			{!customizeTasks && page === 0 && loading ? (
				<Loading />
			) : (
				<SectionList
					sections={
						!customizeTasks
							? []
							: [
									{ title: 'today', data: customizeTasks?.today || [] },
									{ title: 'yesterday', data: customizeTasks?.yesterday || [] },
									{ title: 'older', data: customizeTasks?.beforeYesterday || [] },
							  ]
					}
					renderSectionHeader={({ section: { title, data } }) => (data?.length > 0 ? renderTitle(title) : null)}
					refreshControl={
						<RefreshControl refreshing={refreshing} onRefresh={refreshPage} tintColor={COLORS.trueBlue} />
					}
					contentContainerStyle={styles.listContentContainer}
					keyExtractor={({ ID }) => ID.toString()}
					showsVerticalScrollIndicator={false}
					onEndReached={handleEndReached}
					ListFooterComponent={
						!refreshing && dataRes?.Data && loading ? (
							<Wrapper style={{ backgroundColor: COLORS.whiteSmoke }} mBottom={bottom} mTop={24}>
								<ActivityIndicator size="small" color={COLORS.trueBlue} />
							</Wrapper>
						) : null
					}
					renderItem={({ item }) => {
						const { Content, Created, FlgRead, Icon } = item || {};
						return (
							<View style={{ backgroundColor: FlgRead ? COLORS.white : COLORS.aliceBlue }}>
								<NotificationCard icon={Icon} content={Content} created={Created} />
							</View>
						);
					}}
					ListEmptyComponent={<EmptyState />}
				/>
			)}
		</Container>
	);
};
