/* eslint-disable @typescript-eslint/restrict-template-expressions */
import { ENDPOINT } from 'http/modules/Request';

import { useEffect, useMemo, useRef } from 'react';

import { FilterValuesType } from 'components/Organisms/TaskFilter';
import { Flag, ViewType } from 'components/Organisms/TaskFilter/constant';
import useInfinity from 'hooks/useInfinity';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { INotification } from 'services/Notifications/types';
import { useAppSelector } from 'stores';
import dayjs from 'utils/dayjs';
import { translate } from 'utils/translate';

export const useNotification = (params: { type: 'ALL' | 'UNREAD' }) => {
	const { type } = params || {};
	const totalPageRef = useRef<number>(0);

	const currentFilterValues = useRef<FilterValuesType>({
		viewType: ViewType[0],
		flag: Flag[0],
		statusGroup: [{ label: translate('flag_all'), value: 0, labelEN: 'All' }],
		fromDate: new Date(),
		toDate: new Date(),
	});

	const { bottom } = useSafeAreaInsets();
	const { beanAppStatus } = useAppSelector(state => state.system);
	const { language } = useAppSelector(state => state.dataNotRemove);

	const {
		state: { data: dataRes, refreshing, loading, page },
		gotoFirstPage,
		refreshPage,
		fetchMore,
	} = useInfinity<Array<INotification>>(`${ENDPOINT.WORKFLOW}`, {
		size: 10,
		requireAuthentication: true,
		params: {
			func: 'getList',
			// Flag: 0: Chưa đọc, 1: Đã đọc
			data: type === 'ALL' ? undefined : `{"Flag":0}}`,
			resourcetype: 'MySocialNotify',
			lid: language === 'vi' ? 1066 : 1033,
			totalrecord: totalPageRef.current,
		},
		onSuccess: res => {
			if (!res.data) return;
			totalPageRef.current = res.data?.TotalRecord;
		},
	});

	useEffect(() => {
		// gotoFirstPage();
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [type]);

	const handleEndReached = (info: { distanceFromEnd: number }) => {
		if (Number(info.distanceFromEnd) > 0) return;
		fetchMore();
	};

	const customizeTasks = useMemo(() => {
		const tasksObj: {
			today: Array<INotification>;
			yesterday: Array<INotification>;
			beforeYesterday: Array<INotification>;
		} = {
			today: [],
			yesterday: [],
			beforeYesterday: [],
		};
		const yesterday = new Date();
		yesterday.setDate(yesterday.getDate() - 1);
		if (!dataRes?.Data) return;
		// eslint-disable-next-line no-unsafe-optional-chaining
		for (const n of dataRes?.Data) {
			if (dayjs(n.Created).isSame(new Date(), 'day')) {
				tasksObj.today.push(n);
			} else if (dayjs(n.Created).isSame(yesterday, 'day')) {
				tasksObj.yesterday.push(n);
			} else if (dayjs(n.Created).isBefore(yesterday, 'day')) {
				tasksObj.beforeYesterday.push(n);
			}
		}
		return tasksObj;
	}, [dataRes]);

	const handleNavigateToDetail = () => {};

	return {
		page,
		bottom,
		dataRes,
		loading,
		language,
		refreshing,
		customizeTasks,
		beanAppStatus,
		currentFilter: currentFilterValues.current,
		refreshPage,
		handleEndReached,
		handleNavigateToDetail,
	};
};
