/* eslint-disable @typescript-eslint/restrict-template-expressions */
import { ENDPOINT } from 'http/modules/Request';

import { useEffect, useMemo, useRef, useState } from 'react';

import { FilterValuesType } from 'components/Organisms/TaskFilter';
import { Flag, ViewType } from 'components/Organisms/TaskFilter/constant';
import useInfinity from 'hooks/useInfinity';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { INotification } from 'services/Notifications/types';
import { useAppSelector } from 'stores';
import dayjs from 'utils/dayjs';
import { translate } from 'utils/translate';

export const useHooksNoti = () => {
	const totalPageRef = useRef<number>(0);

	const currentFilterValues = useRef<FilterValuesType>({
		viewType: ViewType[0],
		flag: Flag[0],
		statusGroup: [{ label: translate('flag_all'), value: 0, labelEN: 'All' }],
		fromDate: new Date(),
		toDate: new Date(),
	});

	const { bottom } = useSafeAreaInsets();
	const { beanAppStatus } = useAppSelector(state => state.system);
	const { language } = useAppSelector(state => state.dataNotRemove);

	const [t, setT] = useState('');
	const [data, setData] = useState([]);

	const {
		state: { data: dataRes, refreshing, loading, page },
		gotoFirstPage,
		refreshPage,
		fetchMore,
	} = useInfinity<Array<INotification>>(`${ENDPOINT.WORKFLOW}`, {
		size: 12,
		requireAuthentication: true,
		params: {
			func: 'getList',
			// Flag: 0: Chưa đọc, 1: Đã đọc
			data: t === 'ALL' ? `{"Flag":1}` : `{"Flag":0}`,
			resourcetype: 'MySocialNotify',
			lid: language === 'vi' ? 1066 : 1033,
			totalrecord: totalPageRef.current,
		},
		onSuccess: res => {
			if (!res.data) return;
			totalPageRef.current = res.data?.TotalRecord;
		},
	});

	useEffect(() => {
		if (t) {
			gotoFirstPage();
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [t]);

	const handleEndReached = (info: { distanceFromEnd: number }) => {
		// if (Number(info.distanceFromEnd) > 0) return;
		if (data?.length < totalPageRef.current && totalPageRef.current > 9) {
			fetchMore();
		}
	};

	const customizeTasks = useMemo(() => {
		const tasksObj: {
			today: Array<INotification>;
			yesterday: Array<INotification>;
			beforeYesterday: Array<INotification>;
		} = {
			today: [],
			yesterday: [],
			beforeYesterday: [],
		};
		const yesterday = new Date();
		yesterday.setDate(yesterday.getDate() - 1);
		if (!data?.length) return [];
		// eslint-disable-next-line no-unsafe-optional-chaining
		for (const n of data) {
			if (dayjs(n.Created).isSame(new Date(), 'day')) {
				tasksObj.today.push(n);
			} else if (dayjs(n.Created).isSame(yesterday, 'day')) {
				tasksObj.yesterday.push(n);
			} else if (dayjs(n.Created).isBefore(yesterday, 'day')) {
				tasksObj.beforeYesterday.push(n);
			}
		}
		return tasksObj;
	}, [data]);

	useEffect(() => {
		setData(dataRes?.Data);
	}, [dataRes]);

	const handleNavigateToDetail = () => {};

	const handleFist = e => {
		setT(!e ? 'ALL' : 'UNREAD');
		totalPageRef.current = 0;
	};

	const updateRead = (ItemID: number) => {
		console.log('ItemID', ItemID);
		const cloneData = JSON.parse(JSON.stringify(data));
		const index = data.findIndex(task => task.ItemID === ItemID);
		console.log('index', index);
		if (index === -1) return;
		cloneData[index] = { ...cloneData[index], FlgRead: true };
		console.log('cloneData', cloneData);
		setData(cloneData);
	};

	return {
		page,
		bottom,
		dataRes: data,
		loading,
		language,
		refreshing,
		customizeTasks,
		beanAppStatus,
		currentFilter: currentFilterValues.current,
		refreshPage,
		handleEndReached,
		handleNavigateToDetail,
		handleFist,
		gotoFirstPage,
		updateRead,
	};
};
