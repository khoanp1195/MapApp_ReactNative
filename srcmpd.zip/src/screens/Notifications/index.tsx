import React, { useCallback } from 'react';

import { Text } from '@react-native-material/core';
import { createMaterialTopTabNavigator, MaterialTopTabBarProps } from '@react-navigation/material-top-tabs';
import { Icon } from 'components/Atoms/Icon';
import { Header } from 'components/Organisms/Header';
import { MaterialTopTabsNavigator } from 'components/Organisms/MaterialTopTabsNavigator';
import { COLORS, ICONS } from 'config';
import { translate } from 'utils/translate';

import { NotificationContainer } from './Containers';
import { Leading, Trailing } from './styles';
import { useNotifications } from './useNotifications';

const Tab = createMaterialTopTabNavigator();

const RenderTabBar = (props: MaterialTopTabBarProps) => {
	const { index } = props?.state || {};
	const { handleOpenDrawer, language, countTaskRef } = useNotifications({
		index,
	});

	const renderLeading = useCallback(
		() => (
			<Leading onPress={handleOpenDrawer}>
				<Icon src={ICONS.icArrowLeft} width={20} height={20} style={{ marginRight: 15 }} />
				<Text color={COLORS.trueBlue} style={{ fontSize: 16, fontWeight: 'bold' }}>
					{translate('notifications')}
				</Text>
			</Leading>
		),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[language],
	);
	return (
		<MaterialTopTabsNavigator
			{...props}
			textActiveColor={COLORS.trueBlue}
			countTask={countTaskRef.current}
			customHeader={
				<Header
					leading={renderLeading()}
					trailing={
						<Trailing>
							<Icon src={ICONS.icEye} width={24} height={24} />
						</Trailing>
					}
				/>
			}
		/>
	);
};

const AllNotifications = () => <NotificationContainer type="ALL" />;
const UnreadNotifications = () => <NotificationContainer type="UNREAD" />;

export const NotificationsScreen = () => {
	return (
		<Tab.Navigator
			screenOptions={{ lazy: true, swipeEnabled: false }}
			tabBar={RenderTabBar}
			initialRouteName="my_task"
			sceneContainerStyle={{
				backgroundColor: COLORS.whiteSmoke,
			}}>
			<Tab.Screen name="flag_all" component={AllNotifications} />
			<Tab.Screen name="flag_unread" component={UnreadNotifications} />
		</Tab.Navigator>
	);
};
