import { useEffect, useRef } from 'react';

import { useAppDispatch, useAppSelector } from 'stores';
import { updateStatusDrawer } from 'stores/System';

export const useNotifications = () => {
	const dispatch = useAppDispatch();
	const { count } = useAppSelector(state => state.count);

	const countTaskRef = useRef({
		my_task: 0,
		my_request: 0,
	});

	const { language } = useAppSelector(state => state.dataNotRemove);
	const customerInfo = useAppSelector(state => state.dataNotRemove.customer);

	useEffect(() => {
		countTaskRef.current = {
			my_task: count?.CountMyTask || 0,
			my_request: count?.CountMyRequest || 0,
		};
	}, [count]);

	const handleOpenDrawer = () => dispatch(updateStatusDrawer(true));

	return {
		handleOpenDrawer,
		language,
		countTaskRef,
		customerInfo,
	};
};
