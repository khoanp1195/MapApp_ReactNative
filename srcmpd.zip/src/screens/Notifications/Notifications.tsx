/* eslint-disable react/no-unstable-nested-components */
import React, { useEffect, useState } from 'react';

import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { refDropDown } from 'components/Atoms/Loading/DropDown';
import { ShowLoading } from 'components/Atoms/Loading/LoadingGlobal';
import FImage from 'components/Organisms/FImage/FImage';
import { COLORS } from 'config/colors';
import { ICONS } from 'config/images';
import dayjs from 'dayjs';
import useSystem from 'hooks/useSystem';
import { RoutesNames } from 'navigation/RoutesNames';
import { View, Text, FlatList, Switch, TouchableOpacity, RefreshControl } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppDispatch } from 'stores';
import { updateAllReadNotify } from 'stores/Home';
import { translate } from 'utils/translate';

import { useHooksNoti } from './useHooksNoti';

const Header = ({ title, isRead, onValueChange, onSuccessRead }: { title: string }) => {
	const navigation = useNavigation();
	const insets = useSafeAreaInsets();
	const dispatch = useAppDispatch();

	// const onSuccessRead = res => { };

	return (
		<View
			style={{
				flexDirection: 'row',
				shadowColor: '#000',
				shadowOffset: {
					width: 0,
					height: 2,
				},
				shadowOpacity: 0.1,
				shadowRadius: 2,

				elevation: 5,
				backgroundColor: 'white',
				paddingTop: insets.top,
				paddingBottom: 10,
				paddingHorizontal: 16,
				alignItems: 'center',
			}}>
			<View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
				<Icon
					src={ICONS.icArrowMenu}
					width={24}
					height={24}
					tintColor="rgba(0, 0, 0, 1)"
					onPress={() => navigation.goBack()}
				/>
				<Text
					numberOfLines={1}
					style={{ fontSize: 16, fontWeight: '700', marginHorizontal: 12, color: 'rgba(0, 0, 0, 1)' }}>
					{title}
				</Text>
			</View>
			<View style={{ flexDirection: 'row', alignItems: 'center', marginRight: 16 }}>
				<Switch
					trackColor={{ false: '#767577', true: '#005FD4' }}
					thumbColor={isRead ? 'white' : '#f4f3f4'}
					onValueChange={onValueChange}
					value={isRead}
					style={{ transform: [{ scaleX: 0.6 }, { scaleY: 0.6 }] }}
				/>

				<Text numberOfLines={1} style={{ color: 'rgba(0, 0, 0, 1)', marginLeft: -4 }}>
					{translate('unreadOnly')}
				</Text>
			</View>
			<Icon
				src={ICONS.icMoreVertical}
				width={24}
				height={24}
				tintColor="rgba(0, 0, 0, 1)"
				onPress={event => {
					event.target.measure((x, y, width, height, pageX, pageY) => {
						refDropDown.current?.show(
							{
								top: pageY,
								left: pageX,
								heightItem: 50,
							},
							<View style={{ overflow: 'hidden' }}>
								<TouchableOpacity
									onPress={() => {
										refDropDown.current?.hide();
										dispatch(
											updateAllReadNotify({
												success: onSuccessRead,
											}),
										);
									}}
									style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 10, paddingLeft: 10 }}>
									<Icon src={ICONS.icEye} width={20} height={20} tintColor="rgba(0, 0, 0, 1)" />
									<Text style={{ marginLeft: 4 }}>{translate('markRead')}</Text>
								</TouchableOpacity>
							</View>,
						);
					});
				}}
			/>
		</View>
	);
};

const Notifications = () => {
	const navigation = useNavigation();
	const [isRead, setIsRead] = useState(false);
	const { isVN, formatYY } = useSystem();
	const {
		page,
		bottom,
		dataRes,
		loading,
		language,
		refreshing,
		customizeTasks,
		refreshPage,
		handleEndReached,
		handleFist,
		gotoFirstPage,
		updateRead,
	} = useHooksNoti();

	// useEffect(() => {
	// 	ShowLoading(loading);
	// }, [loading]);

	const onValueChange = e => {
		AsyncStorage.setItem('notify_read', JSON.stringify(e));
		setIsRead(e);
		handleFist(e);
	};

	useEffect(() => {
		async function getStatus() {
			await AsyncStorage.getItem('notify_read')
				.then(res => {
					setIsRead(JSON?.parse(res || 'false'));
					handleFist(JSON?.parse(res || 'false'));
				})
				.catch(() => setIsRead('false'));
		}
		getStatus();
	}, []);

	const getIcon = Icon => {
		switch (Icon) {
			case 'ic-star':
				return ICONS.icStar;
			case 'ic-share':
				return ICONS.icShare;
			case 'ic-refuse':
				return ICONS.icMinusCircle;
			case 'ic-cancle':
				return ICONS.icRemoveRectangle;
			case 'ic-comment':
				return ICONS.icChatAction;
			case 'ic-forward':
				return ICONS.icShareRectangle;
			case 'ic-add-info':
				return ICONS.icPencilBook;
			case 'ic-approve':
				return ICONS.icCheckCircle;

			default:
				return ICONS.icHistoryShare;
		}
	};

	const renderItem = ({ item, index }) => {
		const { Created, FlgRead, Content = '', ContentEN = '', ItemID, ListId, WorkflowId } = item || {};
		const Time = Created ? dayjs(Created).format(formatYY) : '';
		// const convertContent = Content?.replace('class="sp-user"', 'style="font-weight: bold"');

		const content = isVN ? Content : ContentEN;
		const cvContent = content
			.replace('<span class="sp-user">', '')
			.replace('</span> ', ',')
			.replace('<span>', '')
			.replace('<span class="sp-action"> ', '')
			.replace(' </span> ', ',')
			.replace('<span class="desc">', '')
			.replace('</span>', '')
			.split(',');

		const icon = getIcon(item?.Icon);

		return (
			<TouchableOpacity
				onPress={() => {
					const params = {
						ID: ItemID,
						ListID: ListId,
						WorkflowId,
					};
					updateRead(ItemID);
					navigation.navigate(RoutesNames.WorkflowDetails, { item: params });
				}}
				activeOpacity={1}
				style={{
					// flexDirection: 'row',
					flex: 1,
					// paddingBottom: 10,
					paddingHorizontal: 16,
					// marginBottom: 10,
				}}>
				<View style={{ flexDirection: 'row' }}>
					<Icon src={icon} width={24} height={24} tintColor="#000" />
					<View style={{ flex: 1 }}>
						{!!cvContent?.length && (
							<Text
								numberOfLines={3}
								// ellipsizeMode="middle"
								style={{ flex: 1, marginLeft: 8, fontWeight: FlgRead ? '500' : '800', fontSize: 15 }}>
								{cvContent[0]?.trim()}
								<Text style={{ fontWeight: FlgRead ? '300' : '600' }}> {cvContent[1]?.trim()} </Text>
								<Text style={{ fontWeight: FlgRead ? '500' : '800', fontSize: 15 }}>
									{cvContent[2]?.replaceAll(/\r\n/g, '')?.trim()}
								</Text>
							</Text>
						)}
					</View>
					<Text style={{ fontSize: 12, fontWeight: '400', marginLeft: 10 }}>{Time}</Text>
				</View>
				<View style={{ height: 3, width: '100%', backgroundColor: 'rgba(123, 123, 123, 0.1)', marginVertical: 10 }} />
			</TouchableOpacity>
		);
	};

	return (
		<View style={{ flex: 1 }}>
			<Header
				title={translate('notifications')}
				isRead={isRead}
				onValueChange={onValueChange}
				onSuccessRead={gotoFirstPage}
			/>
			<FlatList
				contentContainerStyle={{ marginVertical: 20 }}
				data={dataRes || []}
				keyExtractor={(item, index) => index?.toString()}
				renderItem={renderItem}
				showsVerticalScrollIndicator={false}
				onEndReached={handleEndReached}
				onEndReachedThreshold={0.9}
				ListFooterComponent={() => {
					return <View style={{ height: 100 }} />;
				}}
				refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refreshPage} tintColor={COLORS.trueBlue} />}
			/>
		</View>
	);
};

export default Notifications;
