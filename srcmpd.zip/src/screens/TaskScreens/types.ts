export interface IFilter {
	toDate: Date | string;
	fromDate: Date | string;
	state: State[];
	workflow?: Workflow[];
	keyword?: string;
}

export interface State {
	label: string;
	value: number;
	labelEN: string;
}

export interface Workflow {
	Title: string;
	TitleEN: string;
	WorkflowID: number;
}
