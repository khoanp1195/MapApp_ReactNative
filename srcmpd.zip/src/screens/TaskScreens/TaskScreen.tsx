/* eslint-disable react/no-children-prop */
/* eslint-disable react/jsx-props-no-spreading */
import React, { forwardRef, useRef, useImperativeHandle, useState, useEffect } from 'react';

import { createMaterialTopTabNavigator, MaterialTopTabBarProps } from '@react-navigation/material-top-tabs';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { MaterialTopTabsNavigator } from 'components/TaskScreens/MaterialTopTabsNavigator';
import ModalFilter from 'components/TaskScreens/ModalFilter';
import MyRequests from 'components/TaskScreens/MyRequest';
import MyTasks from 'components/TaskScreens/MyTask';
import { ICONS } from 'config';
import { navigate } from 'navigation/RootNavigation';
import { RoutesNames } from 'navigation/RoutesNames';
import { View, Text } from 'react-native';
import { ButtomNewTicket } from 'screens/Apps/Containers/ButtonNewTicket';
import { useAppSelector } from 'stores';

import { IFilter } from './types';

const Tab = createMaterialTopTabNavigator();

const RenderTabBar = forwardRef((props: MaterialTopTabBarProps, ref) => {
	const [activeFilter, setActiveFilter] = useState({
		myTask: false,
		myRequest: false,
	});

	useImperativeHandle(
		ref,
		() => ({
			setActive: status => {
				setActiveFilter({ ...activeFilter, ...status });
			},
		}),
		[activeFilter],
	);

	const {
		state: { index },
		onOpenFilter,
	} = props || {};

	const onPress = () => {
		onOpenFilter && onOpenFilter(index);
	};

	const active = index === 0 ? activeFilter.myTask : activeFilter.myRequest;

	const trailing = (
		<View style={{ alignItems: 'center', flexDirection: 'row', justifyContent: 'flex-end' }}>
			<View style={{ backgroundColor: active ? 'rgba(219, 235, 255, 1)' : 'white', padding: 2, borderRadius: 4 }}>
				<Icon
					src={ICONS.icFilterTask}
					width={24}
					height={24}
					onPress={onPress}
					tintColor={active ? 'rgba(0, 95, 212, 1)' : 'black'}
				/>
			</View>
		</View>
	);
	return <MaterialTopTabsNavigator {...props} trailing={trailing} />;
});

const TaskScreen = () => {
	const workflowsApps = useAppSelector(store => store.apps.workflowsApps);

	const workflow = workflowsApps?.ID
		? [{ Title: workflowsApps?.Title, TitleEN: workflowsApps?.TitleEN, WorkflowID: workflowsApps?.WorkflowID }]
		: [{ Title: 'Tất cả', TitleEN: 'All', WorkflowID: 0 }];

	const DefaultFilter = {
		toDate: '',
		fromDate: '',
		state: [{ label: 'Tất cả', value: 0, labelEN: 'All' }],
		workflow,
		keyword: '',
	};

	const refIndex = useRef<number>(0);

	const refMyTask = useRef<{ handleFilter: (value: IFilter, isReset: boolean) => void } | null>(null);
	const refMyRequest = useRef<{ handleFilter: (value: IFilter, isReset: boolean) => void } | null>(null);
	const refTabbar = useRef<{ setActive: (any: any) => void } | null>(null);

	const [filterMyTask, setFilterMyTask] = useState<IFilter | null>(DefaultFilter);
	const [filterMyRequest, setFilterMyRequest] = useState<IFilter | null>(DefaultFilter);

	useEffect(() => {
		// setFilterMyTask({ ...filterMyTask, ...{ workflow: DefaultFilter.workflow } });
		// setFilterMyRequest({ ...filterMyRequest, ...{ workflow: DefaultFilter.workflow } });
		setFilterMyTask(DefaultFilter);
		setFilterMyRequest(DefaultFilter);
		refTabbar.current?.setActive({ myRequest: false, myTask: false });
	}, [workflowsApps]);

	const onUpdateFilter = (value: IFilter, index: number, isActiveFilter: boolean, isReset: boolean) => {
		if (index === 0) {
			// refMyTask.current?.handleFilter(isReset ? DefaultFilter : value, isReset);
			refTabbar.current?.setActive({ myTask: isReset ? false : isActiveFilter });
			setFilterMyTask(isReset ? DefaultFilter : value);
			return;
		}
		setFilterMyRequest(isReset ? DefaultFilter : value);
		refTabbar.current?.setActive({ myRequest: isReset ? false : isActiveFilter });
	};

	const onOpenFilter = (index: number) => {
		refIndex.current = index;
		navigate(RoutesNames.FilterTask, {
			onUpdateFilter,
			index,
			value: index === 0 ? filterMyTask : filterMyRequest,
			hideState: index === 0 ? ['1'] : [],
		});
	};

	const tabBar = (props: MaterialTopTabBarProps) => {
		const convertProps = { ...props, onOpenFilter };
		return <RenderTabBar {...convertProps} ref={refTabbar} />;
	};

	const route = useRoute();

	const onAddWorkflow = () => {
		if (workflowsApps?.ID) {
			navigate(RoutesNames.AddWorkflow, { item: workflowsApps });
		} else {
			navigate(RoutesNames.SearchWorkflow);
		}
	};

	return (
		<View style={{ flex: 1 }}>
			<Tab.Navigator screenOptions={{ lazy: true, swipeEnabled: false }} tabBar={tabBar} initialRouteName="myTask">
				<Tab.Screen
					name="myTask"
					children={props => {
						const convertProps = { ...props, Route: route, filterMyTask };
						return <MyTasks {...convertProps} ref={refMyTask} />;
					}}
				/>
				<Tab.Screen
					name="myRequest"
					children={props => {
						const convertProps = { ...props, Route: route, filterMyRequest };
						return <MyRequests {...convertProps} ref={refMyRequest} />;
					}}
				/>
			</Tab.Navigator>
			<ButtomNewTicket cStyle={{ bottom: 40 }} onPress={onAddWorkflow} />
		</View>
	);
};

export default TaskScreen;
