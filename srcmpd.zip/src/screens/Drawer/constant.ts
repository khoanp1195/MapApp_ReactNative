import { ICONS } from 'config';

export enum MenuIDs {
	Homepage = 'homepage',
	MyTask = 'MyTask',
	MyRequest = 'MyRequest',
	Follow = 'Follow',
	Search = 'Search',
	Notification = 'Notification',
	Apps = 'Apps',
	AppSubMenu1 = 'AppSubMenu1',
	AppSubMenu2 = 'AppSubMenu2',
	AppSubMenu3 = 'AppSubMenu3',
}

export const DrawerMenu = [
	{
		id: MenuIDs.Homepage,
		title: 'homepage',
		icon: ICONS.icHomeDrawer2,
	},
	{
		id: MenuIDs.MyTask,
		title: 'my_task',
		icon: ICONS.icTaskNew,
	},
	{
		id: MenuIDs.MyRequest,
		title: 'my_request',
		icon: ICONS.icMail,
	},
	{
		id: MenuIDs.Follow,
		title: 'follow',
		icon: ICONS.icStar,
	},
	{
		id: MenuIDs.Search,
		title: 'search',
		icon: ICONS.icSearchAll,
	},
	// {
	// 	id: MenuIDs.Notification,
	// 	title: 'notifications',
	// 	icon: ICONS.icLookup,
	// },
	// {
	// 	id: MenuIDs.Apps,
	// 	title: 'apps',
	// 	icon: ICONS.icApps,
	// 	subMenu: [
	// 		{
	// 			id: MenuIDs.AppSubMenu1,
	// 			icon: ICONS.icSubMenu1,
	// 			title: 'Đăng ký tuyển dụng nhân sự, Đăng ký tuyển dụng nhân sự',
	// 		},
	// 		{
	// 			id: MenuIDs.AppSubMenu2,
	// 			icon: ICONS.icSubMenu2,
	// 			title: 'Đăng ký nghỉ phép phòng kinh, Đăng ký nghỉ phép phòng kinh',
	// 		},
	// 		{
	// 			id: MenuIDs.AppSubMenu3,
	// 			icon: ICONS.icSubMenu3,
	// 			title: 'Quy trình phê duyệt đăng ký đi, Quy trình phê duyệt đăng ký đi …',
	// 		},
	// 	],
	// },
];
