/* eslint-disable prettier/prettier */
import React, { forwardRef, useRef, useState, useImperativeHandle, useMemo, useEffect } from 'react';

import { Icon } from 'components/Atoms/Icon';
import ModalRef from 'components/Molecules/Modal/ModalRef';
import { COLORS } from 'config';
import { ICONS } from 'config/images';
import { useAsyncAction } from 'hooks/useAsyncAction';
import useAuthentication from 'hooks/useAuthentication';
import useBiometrics from 'hooks/useBiometrics';
import useSystem from 'hooks/useSystem';
import { View, FlatList, TouchableOpacity, Text, Dimensions, TextInput, Alert, ActivityIndicator } from 'react-native';
import { apiLogin } from 'services/Auth';
import { useAppDispatch, useAppSelector } from 'stores';
import { translate } from 'utils/translate';

const windowHeight = Dimensions.get('window').height;


const ModalRequestLogin = ({ updateBio }, ref) => {
	const dispatch = useAppDispatch()
	const refModal = useRef()
	const { username: usernameStore, bioType } = useAppSelector(state => state.dataNotRemove);
	const { asyncSaveBio } = useBiometrics();
	const { logout } = useAuthentication();

	const [pass, setPasss] = useState('')
	const [loading, setLoading] = useState(false)
	const [err, setErr] = useState<{ Key: string; Value: string } | null>(null);
	const refBio = useRef(false)

	const show = (state = []) => {
		refModal.current?.show()
	}
	const hide = () => {
		refModal.current?.hide()
	}

	useImperativeHandle(
		ref,
		() => ({
			show,
			hide
		}),
		[],
	);

	const onHide = () => {
		setPasss('')
		if (refBio.current) {
			updateBio(refBio.current)
			refBio.current = false
		}
	}

	const onChangePassword = (text) => {
		setErr(null)
		setPasss(text)
	}

	const [customerLoginExec] = useAsyncAction(apiLogin, {
		onSuccess: res => {
			if (res.data.status === 'SUCCESS') {
				asyncSaveBio({
					username: usernameStore || '',
					password: pass,
				}).finally(() => {
					setLoading(false)
					refBio.current = true
					hide()
				})
			} else {
				setLoading(false)
				setErr(res.data.mess);
				if (res.data.mess?.Key !== '200') {
					hide()
					logout()
					Alert.alert(res.data.mess?.Value)
				}
			}
		},
		onFailed: (error: BaseAPIError) => {
			setLoading(false)
			Alert.alert(translate('title_alert_warning'), error.message || translate('message_alert_error_default'), [
				{ text: 'OK', style: 'cancel' },
			]);
		},
	});

	const handleSubmitForm = () => {
		try {
			if (usernameStore && pass) {
				setLoading(true)
				customerLoginExec({
					username: usernameStore,
					password: pass,
				});
			}
			// TODO: Success handler (Toastify)
		} catch (error) {
			// TODO: Error handler (Toastify)
		}
	};

	const isErr = err?.Key === '200';


	return <ModalRef
		ref={refModal}
		onHide={onHide}
		outsideClickCloseable
		onClose={hide}
		visiblePosition='center'
		isTouch={false}
	>
		<View style={{
			paddingHorizontal: 24, backgroundColor: 'white', borderRadius: 8, paddingVertical: 24
		}}>
			<Text style={{ fontSize: 16, fontWeight: '600', marginBottom: 16 }}>Xác thực đăng nhập với {bioType}</Text>
			<Text style={{ color: COLORS.textGrey, fontWeight: '600' }}>{usernameStore}</Text>
			<TouchableOpacity activeOpacity={1}
				style={{
					borderWidth: 1,
					borderColor: err?.Key ? COLORS.red : '#D9D9D9',
					width: '100%',
					height: 40,
					alignItems: 'center',
					borderRadius: 8,
					flexDirection: 'row',
					paddingHorizontal: 10,
					marginTop: 12,
				}}>
				<Icon src={ICONS.icUnlock} width={18} height={18} />
				<TextInput
					editable={!loading}
					value={pass}
					onChangeText={onChangePassword}
					placeholder={translate('password')}
					secureTextEntry
					style={{ marginLeft: 12, flex: 1 }}
					maxLength={255}
					returnKeyType='done'
					autoCapitalize='none'
					textContentType='password'
					autoComplete='password'
					onSubmitEditing={
						handleSubmitForm
					}
				/>
			</TouchableOpacity>
			{!!err?.Key && (
				<Text style={{ fontSize: 12, fontStyle: 'italic', color: COLORS.red, }}>
					{translate('incorrectPassword')}
				</Text>
			)}
			<View style={{ flexDirection: 'row', marginTop: 20 }}>
				<TouchableOpacity
					disabled={loading || !pass}
					onPress={() => handleSubmitForm()} style={{
						paddingVertical: 8,
						flex: 1,
						backgroundColor: !pass ? '#D9D9D9' : COLORS.blueMain,
						alignItems: 'center',
						borderRadius: 8,
						marginRight: 8
					}}>
					{loading ? (
						<ActivityIndicator color={COLORS.white} />
					) : (
						<Text style={{ color: 'white', }}>{translate('continue')}</Text>

					)}
				</TouchableOpacity>

				<TouchableOpacity onPress={() => {
					hide()
				}} disabled={loading} style={{
					paddingVertical: 6,
					flex: 1,
					borderRadius: 8,
					borderWidth: 1,
					borderColor: '#D9D9D9',
					alignItems: 'center',
					marginLeft: 8
				}}><Text>{translate('cancel').toLocaleUpperCase()}</Text></TouchableOpacity>
			</View>
		</View>
	</ModalRef>
}

export default forwardRef(ModalRequestLogin)
