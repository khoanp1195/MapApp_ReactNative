import { COLORS, colorsAlpha } from 'config';
import { StyleSheet } from 'react-native';
import styled from 'styled-components/native';

export const Container = styled.View``;

export const AvatarWrap = styled.View`
	flex-direction: row;
	align-items: center;
	margin-bottom: 16px;
`;

export const styles = StyleSheet.create({
	styleWhenExpand: {
		backgroundColor: colorsAlpha('trueBlue', 0.1),
		marginHorizontal: -16,
		paddingRight: 16,
		paddingLeft: 10,
		borderLeftWidth: 6,
		borderColor: COLORS.trueBlue,
	},
});
