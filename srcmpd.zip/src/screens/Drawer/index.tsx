/* eslint-disable react/jsx-no-useless-fragment */
/* eslint-disable import/no-extraneous-dependencies */
import React, { useRef, useState } from 'react';

import { Divider, Text } from '@react-native-material/core';
import en from 'assets/i18n/en';
import { Icon } from 'components/Atoms/Icon';
import SwitchLanguage from 'components/Atoms/SwitchLanguage';
import { Section } from 'components/Molecules/Section';
import { IconWrapper } from 'components/Organisms/TaskCard/styles';
import { STATUS_TAKS } from 'components/TaskScreens/consts/consts';
import { COLORS, ICONS, imgDummy } from 'config';
import useBiometrics from 'hooks/useBiometrics';
import useSystem from 'hooks/useSystem';
import { navigate } from 'navigation/RootNavigation';
import { BottomNavigationRoutesNames } from 'navigation/RoutesNames';
import {
	View,
	Pressable,
	KeyboardAvoidingView,
	Platform,
	ScrollView,
	Keyboard,
	TouchableHighlight,
	TouchableWithoutFeedback,
	Image,
	TouchableOpacity,
	Switch,
	RefreshControl,
} from 'react-native';
import { getVersion } from 'react-native-device-info';
import { SafeAreaView } from 'react-native-safe-area-context';
import MenuDrawer from 'react-native-side-drawer';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateWorkflowsApps } from 'stores/Apps/reducer';
import { fetchCount } from 'stores/Count/thunks';
import { updateStatusBiometric } from 'stores/DataNotRemove';
import { getFavoriteHome } from 'stores/Home/reducer';
import { updateStatusDrawer } from 'stores/System';
import { resetUserSession } from 'utils/biometricAuthentication';
import { translate } from 'utils/translate';

import { DrawerMenu, MenuIDs } from './constant';
import { Props } from './interfaces';
import ModalRequestLogin from './ModalRequestLogin';
import { AvatarWrap, styles } from './styles';
import { useDrawer } from './useDrawer';

export const Drawer: React.FC<Props> = ({ children }) => {
	const {
		FullName,
		ImagePath,
		expandApps,
		titlePosition,
		menuIDFocus,
		isTurnOnDrawer,
		renderCount,
		handleLogout,
		handleCloseDrawer,
		handleTrigerMenuAction,
	} = useDrawer();

	const [refreshing, setrefreshing] = useState(false);

	const favorite = useAppSelector(store => store.home.favorite);
	const { isTurnOnBiometric, bioType } = useAppSelector(state => state.dataNotRemove);

	const refModal = useRef();

	const { isVN, Cookie } = useSystem();
	const dispatch = useAppDispatch();

	const getIconBio = () => {
		if (bioType === 'Face ID') return ICONS.icFaceID;
		if (bioType === 'Touch ID') return ICONS.icTouchIos;
		return ICONS.icFaceID;
	};

	const updateRefreshing = () => {
		setrefreshing(false);
	};

	const onRefresh = () => {
		setrefreshing(true);
		dispatch(fetchCount());
		dispatch(
			getFavoriteHome({
				success: updateRefreshing,
				failed: updateRefreshing,
			}),
		);
	};

	const refreshControl = <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.blueMain} />;

	const drawerContent = () => {
		return (
			<SafeAreaView
				style={{
					flex: 1,
					backgroundColor: COLORS.white,
				}}
				edges={['left', 'right', 'top', 'bottom']}>
				<KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
					<ScrollView
						refreshControl={refreshControl}
						showsVerticalScrollIndicator={false}
						keyboardShouldPersistTaps="handled"
						onScrollBeginDrag={Keyboard.dismiss}
						contentContainerStyle={{ flexGrow: 1 }}>
						<View>
							<View style={{ marginBottom: 20, flexDirection: 'row', alignItems: 'center', marginHorizontal: 30 }}>
								<Icon
									src={ICONS.icArrowMenu}
									width={24}
									height={24}
									style={{ marginRight: 20 }}
									onPress={handleCloseDrawer}
								/>
								<Text style={{ fontSize: 20, fontWeight: '700' }}>Menu</Text>
							</View>
							{DrawerMenu.map(({ title, icon, id, subMenu }, index) => {
								// const isAppsAndExpand = id === MenuIDs.Apps && expandApps;
								// const isFocused = menuIDFocus === id;
								const isAppsAndExpand = false;
								const isFocused = false;
								return (
									<View key={index?.toString()} style={{ marginHorizontal: 30 }}>
										<Section
											leading={
												<Icon
													src={icon}
													width={24}
													height={24}
													tintColor={isFocused ? COLORS.trueBlue : 'rgba(100, 116, 139, 1)'}
												/>
											}
											onPress={() => handleTrigerMenuAction(id)}
											style={isFocused ? styles.styleWhenExpand : {}}
											center={
												<Text
													style={{ fontSize: 16, fontWeight: '500' }}
													color={isFocused ? COLORS.trueBlue : COLORS.black}>
													{translate(title as keyof typeof en)}
												</Text>
											}
											trailing={
												<>
													{id === MenuIDs.Apps ? (
														<Icon src={isAppsAndExpand ? ICONS.icArrowUp : ICONS.icArrowDown} width={20} height={20} />
													) : (
														<>
															{id === MenuIDs.Homepage ? null : (
																<Text style={{ fontSize: 16, fontWeight: '500' }} color={COLORS.trueBlue}>
																	{renderCount(id)}
																</Text>
															)}
														</>
													)}
												</>
											}
										/>
										{/* {isAppsAndExpand &&
											subMenu?.map(({ title: subTitle, icon: subIcon, id: subId }) => (
												<Section
													key={subId}
													style={{ paddingLeft: 20 }}
													leading={<Icon src={subIcon} width={20} height={20} />}
													onPress={() => handleTrigerMenuAction(subId)}
													center={
														<Text style={{ fontSize: 15, fontWeight: '400' }} color={COLORS.black} numberOfLines={1}>
															{subTitle}
														</Text>
													}
												/>
											))} */}
									</View>
								);
							})}
							<Divider style={{ marginTop: 10, marginBottom: favorite?.length ? 0 : 20 }} />
							{!!favorite?.length && (
								<>
									<Section
										style={{ marginHorizontal: 30, marginTop: 10 }}
										leading={
											<Text style={{ fontSize: 16, fontWeight: '700' }} color={COLORS.black}>
												{translate('apps')}
											</Text>
										}
									/>
									<ScrollView
										style={{ marginHorizontal: 30, marginBottom: 10, maxHeight: 260 }}
										showsVerticalScrollIndicator={false}>
										{favorite?.map((x, index) => {
											return (
												<TouchableOpacity
													onPress={() => {
														dispatch(fetchCount({ WorkflowId: x?.WorkflowID || 0 }));
														dispatch(updateStatusDrawer(false));
														dispatch(updateWorkflowsApps(x));
														navigate(BottomNavigationRoutesNames.TaskScreen, {
															screen: 'myTask',
															toMyTask: STATUS_TAKS.PROCESSING,
														});
													}}
													key={index?.toString()}
													style={{ flexDirection: 'row', alignItems: 'center', marginVertical: 10 }}>
													{/* <Icon src={ICONS.icSandboxInactive} width={24} height={24} tintColor="rgba(100, 116, 139, 1)" /> */}
													<View
														style={{
															width: 34,
															height: 33,
															backgroundColor: 'rgba(227, 240, 255, 1)',
															borderRadius: 8,
															alignItems: 'center',
															justifyContent: 'center',
															overflow: 'hidden',
														}}>
														{x?.ImageURL && (
															<Image
																source={{
																	uri: x.ImageURL,
																	headers: {
																		Cookie,
																	},
																}}
																style={{ width: '50%', height: '50%' }}
															/>
														)}
													</View>

													<Text
														numberOfLines={1}
														style={{ fontSize: 16, fontWeight: '500', marginLeft: 12, width: '90%' }}>
														{isVN ? x.Title : x.TitleEN}
													</Text>
												</TouchableOpacity>
											);
										})}
									</ScrollView>
									<Divider style={{ marginBottom: 30 }} />
								</>
							)}
							<Section
								style={{ marginHorizontal: 30 }}
								leading={<Icon src={ICONS.icClock2} width={24} height={24} />}
								center={
									<Text style={{ fontSize: 16, fontWeight: '500' }} color={COLORS.black}>
										{translate('application_information')}
									</Text>
								}
								trailing={<Text style={{ fontSize: 16, fontWeight: '500' }}>{getVersion()}</Text>}
							/>
							{!!bioType && (
								<Section
									style={{ marginHorizontal: 30 }}
									leading={<Icon src={getIconBio()} width={24} height={24} tintColor="rgba(100, 116, 139, 1)" />}
									center={
										<Text style={{ fontSize: 16, fontWeight: '500' }} color={COLORS.black}>
											{translate('loginWith')} {bioType}
										</Text>
									}
									trailing={
										<Switch
											trackColor={{ false: '#767577', true: '#005FD4' }}
											thumbColor={isTurnOnBiometric ? 'white' : '#f4f3f4'}
											value={isTurnOnBiometric}
											style={{ transform: [{ scaleX: 0.7 }, { scaleY: 0.7 }], marginRight: -10 }}
											onValueChange={value => {
												if (value) {
													refModal.current?.show();
												} else {
													resetUserSession().finally(() => dispatch(updateStatusBiometric(false)));
												}
											}}
										/>
									}
								/>
							)}
							<Section
								style={{ marginHorizontal: 30 }}
								leading={<Icon src={ICONS.icLanguage2} width={24} height={24} />}
								center={
									<Text style={{ fontSize: 16, fontWeight: '500' }} color={COLORS.black}>
										{translate('language')}
									</Text>
								}
								trailing={<SwitchLanguage />}
							/>
						</View>
					</ScrollView>
				</KeyboardAvoidingView>
				<Section
					style={{ marginHorizontal: 30, marginBottom: Platform.OS === 'ios' ? 0 : 50 }}
					onPress={handleLogout}
					center={
						<Text style={{ fontSize: 16, fontWeight: '500', textAlign: 'center' }} color={COLORS.red}>
							{translate('logout')}
						</Text>
					}
				/>
				<ModalRequestLogin ref={refModal} updateBio={e => dispatch(updateStatusBiometric(e))} />
			</SafeAreaView>
		);
	};

	return (
		// eslint-disable-next-line @typescript-eslint/ban-ts-comment
		// @ts-ignore
		<MenuDrawer
			open={isTurnOnDrawer}
			position="left"
			drawerContent={drawerContent()}
			drawerPercentage={89}
			animationTime={250}
			overlay
			opacity={0.6}>
			{children}
			{isTurnOnDrawer && (
				<Pressable
					onPress={handleCloseDrawer}
					style={{
						position: 'absolute',
						flex: 1,
						backgroundColor: COLORS.eerieBlack,
						opacity: 0.4,
						width: '100%',
						height: '100%',
					}}
				/>
			)}
		</MenuDrawer>
	);
};
