/* eslint-disable @typescript-eslint/no-shadow */
import { useMemo, useState } from 'react';

import { STATUS_TAKS } from 'components/TaskScreens/consts/consts';
import useAuthentication from 'hooks/useAuthentication';
import { navigate } from 'navigation/RootNavigation';
import { BottomNavigationRoutesNames, RoutesNames } from 'navigation/RoutesNames';
import { Alert } from 'react-native';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateStatusDrawer } from 'stores/System';
import { translate } from 'utils/translate';

import { MenuIDs } from './constant';

export const useDrawer = () => {
	const dispatch = useAppDispatch();
	const { logout } = useAuthentication();

	const { isTurnOnDrawer } = useAppSelector(state => state.system);
	const { language } = useAppSelector(state => state.dataNotRemove);

	const customerInfo = useAppSelector(state => state.dataNotRemove.customer);
	const { count } = useAppSelector(state => state.count);

	const [menuIDFocus, setMenuIDFocus] = useState<MenuIDs | undefined>(MenuIDs.Homepage);

	const { FullName, PositionTitle, PositionTitleEN, ImagePath } = customerInfo || {};
	const { CountMyRequest, CountMyTask, CountMyFollowItem } = count || {};

	const titlePosition = useMemo(
		() => (language === 'vi' ? PositionTitle : PositionTitleEN),
		[PositionTitle, PositionTitleEN, language],
	);

	const handleCloseDrawer = () => dispatch(updateStatusDrawer(false));

	const handleLogout = () => {
		Alert.alert(translate('title_alert_warning'), translate('logout_message'), [
			{ text: translate('cancel'), style: 'cancel' },
			{
				text: translate('logout'),
				style: 'cancel',
				onPress: () => {
					dispatch(updateStatusDrawer(false));
					logout();
				},
			},
		]);
	};

	const handleTrigerMenuAction = (id: MenuIDs) => {
		switch (id) {
			case MenuIDs.Homepage: {
				handleCloseDrawer();
				setMenuIDFocus(id);
				navigate(RoutesNames.BottomNavigation, { screen: BottomNavigationRoutesNames.Home, isScrollToTop: true });
				break;
			}
			case MenuIDs.MyTask: {
				handleCloseDrawer();
				setMenuIDFocus(id);
				navigate(BottomNavigationRoutesNames.TaskScreen, {
					screen: 'myTask',
					toMyTask: STATUS_TAKS.PROCESSING,
				});
				break;
			}
			case MenuIDs.MyRequest: {
				handleCloseDrawer();
				setMenuIDFocus(id);
				navigate(BottomNavigationRoutesNames.TaskScreen, {
					screen: 'myRequest',
					toMyRequest: STATUS_TAKS.PROCESSING,
				});
				break;
			}
			case MenuIDs.Search: {
				handleCloseDrawer();
				setMenuIDFocus(id);
				navigate(RoutesNames.BottomNavigation, { screen: BottomNavigationRoutesNames.Search });
				break;
			}
			case MenuIDs.Notification: {
				handleCloseDrawer();
				setMenuIDFocus(id);
				navigate(RoutesNames.Notifications);
				break;
			}
			case MenuIDs.Apps: {
				setMenuIDFocus(id);
				if (menuIDFocus === MenuIDs.Apps) setMenuIDFocus(undefined);
				break;
			}
			case MenuIDs.Follow: {
				handleCloseDrawer();
				setMenuIDFocus(id);
				navigate(RoutesNames.Follow, { from: RoutesNames.Follow });
				break;
			}
			default:
				Alert.alert(translate('title_alert_warning'), translate('feature_message'), [
					{ text: translate('ok'), style: 'cancel' },
				]);
				break;
		}
	};

	const customCount = (count = 0) => {
		if (count === 0) return '';
		if (count < 10) return `0${count}`;
		if (count > 999) return `999+`;
		return count;
	};

	const renderCount = (id: MenuIDs) => {
		switch (id) {
			case MenuIDs.MyTask: {
				return customCount(CountMyTask);
			}
			case MenuIDs.MyRequest: {
				return customCount(CountMyRequest);
			}
			case MenuIDs.Follow: {
				return customCount(CountMyFollowItem);
			}
			default:
				return null;
		}
	};

	return {
		FullName,
		ImagePath,
		expandApps: menuIDFocus === MenuIDs.Apps,
		menuIDFocus,
		titlePosition,
		isTurnOnDrawer,
		renderCount,
		handleLogout,
		handleCloseDrawer,
		handleTrigerMenuAction,
	};
};
