import React from 'react';

import { useRoute } from '@react-navigation/native';
import { ICONS } from 'config';
import { useSwipe } from 'hooks/useSwipe';
import { BottomNavigationRoutesNames } from 'navigation/RoutesNames';
import { GestureResponderEvent } from 'react-native';
import AppsScreen from 'screens/Apps/AppsScreen';
import { Drawer } from 'screens/Drawer';
import { HomeScreen } from 'screens/Home';
import HomeScreenNew from 'screens/HomeScreens/HomeScreen';
import LookupScreen from 'screens/Lookup/LookupScreen';
import Report from 'screens/Reports/Report';
import TaskScreen from 'screens/TaskScreens/TaskScreen';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateStatusDrawer } from 'stores/System';
import styled from 'styled-components/native';

import { NavigationBar } from '../../components/Organisms/NavigationBar';
import { NavBarItemProps } from '../../components/Organisms/NavigationBar/interface';

const Container = styled.View`
	flex: 1;
`;

const NavbarRoutes: NavBarItemProps[] = [
	{
		iconName: ICONS.icHomeInactive,
		iconNameActive: ICONS.icHomeActive,
		path: BottomNavigationRoutesNames.Home,
		label: 'homepage',
		component: HomeScreenNew,
	},
	{
		iconName: ICONS.icTaskInactive,
		path: BottomNavigationRoutesNames.TaskScreen,
		iconNameActive: ICONS.icTaskActive,
		label: 'task',
		component: TaskScreen,
	},
	{
		iconName: ICONS.icSearchInactive,
		path: BottomNavigationRoutesNames.Search,
		iconNameActive: ICONS.icSearchactive,
		label: 'search',
		component: LookupScreen,
	},
	{
		iconName: ICONS.icSandboxInactive,
		iconNameActive: ICONS.icSandboxActive,
		path: BottomNavigationRoutesNames.Apps,
		label: 'apps',
		component: AppsScreen,
	},
	{
		iconName: ICONS.icListInAT,
		iconNameActive: ICONS.icListAT,
		path: BottomNavigationRoutesNames.List,
		label: 'list',
		component: Report,
	},
	{
		iconName: ICONS.icReportInactive,
		iconNameActive: ICONS.icReportActive,
		path: BottomNavigationRoutesNames.Report,
		label: 'report',
		component: Report,
	},
];

export const BottomNavigation = () => {
	return (
		<Container>
			<NavigationBar navbarList={NavbarRoutes} initialRoute={BottomNavigationRoutesNames.Home} />
		</Container>
	);
};
