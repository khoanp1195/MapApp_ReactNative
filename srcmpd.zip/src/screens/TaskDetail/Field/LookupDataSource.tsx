/* eslint-disable @typescript-eslint/no-misused-promises */
/* eslint-disable eqeqeq */
/* eslint-disable array-callback-return */
/* eslint-disable react-hooks/exhaustive-deps */

import React, { useRef, useState, useEffect, forwardRef, useImperativeHandle } from 'react';

import { Icon } from 'components/Atoms/Icon';
import { BoxUser } from 'components/WorkflowDetails/Modal/ModalAction';
import { COLORS, ICONS } from 'config';
import useInfinity from 'hooks/useInfinity';
import { View, Text, TouchableOpacity, TextInput } from 'react-native';
import { Dropdown, MultiSelect } from 'react-native-element-dropdown';
import { useAppDispatch, useAppSelector } from 'stores';
import { editDetailsLockupSQL } from 'stores/TaskDetails';
import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';
import { translate } from 'utils/translate';

import { IField, OptionField } from './InterfaceField';
import ModalLookup from './ModalLookup';
import ModalLookupSQL from './ModalLookupSQL';
import { usePermisstionEdit } from '../useHooks/usePermissionEdit';

interface DataResource {
	FieldSingleTitleVNFieldSingle: string;
	FieldMultilineTitleVNFieldMultil: string;
	NoiDung: string;
	ID: number;
	ListId: string;
	Created: string;
	Modified: string;
}

const LookupDataSource = (
	{
		title,
		options,
		internalName,
		isGrid,
		isRequired,
		index,
		itemInfoGrid,
		onUpdateValueGrid,
		isEditGrid,
		isViewGrid,
	}: IField,
	ref: React.Ref<unknown> | undefined,
) => {
	const dispatch = useAppDispatch();

	const infoItem = useAppSelector(store => store.workflow.itemInfo);
	const info = isGrid ? itemInfoGrid : infoItem;

	const defaultValue = info?.[internalName] || '';

	const option: OptionField = JSON.parse(options || '{}');
	const isMultiple = option?.L_Allow_Multiple_Sql;

	const KeyFeild = option?.L_Fields || 'NoiDung';

	const Require = option?.Require || isRequired;
	const ViewOnly = !!option?.ViewOnly;

	const { isPermission } = usePermisstionEdit(ViewOnly, internalName);
	const isDisable = isGrid ? !ViewOnly && isEditGrid : isPermission;

	const [error, setError] = useState(false);

	const checkRequire = () => {
		if (!isDisable) return true;

		if (Require && !defaultValue) {
			setError(true);
			return false;
		}
		return true;
	};

	useEffect(() => {
		if (defaultValue) {
			setError(false);
		}
	}, [defaultValue]);

	useImperativeHandle(
		ref,
		() => ({
			require: checkRequire,
		}),
		[defaultValue],
	);

	const convertList = () => {
		const clone = defaultValue?.split(';#')?.filter(item => item !== '') || [];
		let listID = [];
		let listName = [];
		clone?.forEach((item, index) => {
			if (index % 2 !== 0) {
				listName = [...listName, item];
			} else {
				listID = [...listID, item];
			}
		});
		let list = [];
		listID.forEach((item, index) => {
			list = [...list, { ID: Number(item), [KeyFeild]: listName[index] }];
		});
		return list;
	};

	const listData = convertList();

	const refModal = useRef();

	const searchUser = () => {
		refModal.current?.show(listData);
	};

	const onSubmitUser = data => {
		setError(false);
		if (!data?.length) {
			if (isGrid) {
				onUpdateValueGrid({ [internalName]: '' });
				``;
			} else {
				dispatch(
					updateValueInternalName({
						[internalName]: '',
					}),
				);
			}
			return;
		}
		const clone = JSON.parse(JSON.stringify(data?.[0]));
		delete clone?.ID;
		delete clone?.ListId;
		delete clone?.Modified;
		delete clone?.Created;

		let value = '';
		data.map(item => {
			value = value.concat(`;#${item.ID};#${item?.[KeyFeild]}`);
		});

		clone[internalName] = value;

		if (!isMultiple) {
			if (isGrid) {
				onUpdateValueGrid({
					...clone,
				});
			} else {
				dispatch(
					updateValueInternalName({
						...clone,
					}),
				);
			}
			return;
		}
		if (isGrid) {
			onUpdateValueGrid({
				[internalName]: value,
			});
		} else {
			dispatch(
				updateValueInternalName({
					[internalName]: value,
				}),
			);
		}
	};

	if (isViewGrid)
		return (
			<View style={{ alignItems: 'center' }}>
				<Text style={{ fontSize: 14, color: '#111' }}>{defaultValue?.split('#')?.filter(item => item !== ';')[1]}</Text>
			</View>
		);

	return (
		<View style={{ flexDirection: 'row', marginVertical: 15 }}>
			<Icon src={isDisable ? ICONS.icTable : ICONS.icChoiceField} width={18} height={18} />

			<View style={{ marginLeft: 6, flex: 1 }}>
				<Text style={{ color: '#7B7B7B', fontSize: 12, marginBottom: 4 }} numberOfLines={1}>
					{title}
					{Require && isDisable && <Text style={{ color: COLORS.red }}> (*)</Text>}
				</Text>
				{!isDisable ? (
					<Text style={{ fontSize: 14, color: '#111' }}>
						{defaultValue?.split('#')?.filter(item => item !== ';')[1]}
					</Text>
				) : (
					<>
						<BoxUser
							err={error}
							user={listData}
							setUser={onSubmitUser}
							index={index}
							searchUser={searchUser}
							icon={ICONS.icChevronDown}
							KeyFeild={KeyFeild}
							fullText
						/>
						{error && isDisable && (
							<Text style={{ fontSize: 12, color: COLORS.red, fontStyle: 'italic', marginTop: 2 }}>
								{title}
								{translate('isRequire')}
							</Text>
						)}
					</>
				)}
			</View>
			<ModalLookupSQL
				ref={refModal}
				options={options}
				title={title}
				onSubmitUser={onSubmitUser}
				isMultiple={isMultiple}
				KeyFeild={KeyFeild}
			/>
		</View>
	);
};

export default forwardRef(LookupDataSource);
