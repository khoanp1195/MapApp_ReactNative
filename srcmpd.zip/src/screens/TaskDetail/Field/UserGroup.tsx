/* eslint-disable no-inner-declarations */
/* eslint-disable @typescript-eslint/await-thenable */
/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable @typescript-eslint/no-misused-promises */
/* eslint-disable array-callback-return */

import React, { forwardRef, useRef, useState, useImperativeHandle, useEffect } from 'react';

import { Icon } from 'components/Atoms/Icon';
import { BoxUser } from 'components/WorkflowDetails/Modal/ModalAction';
import { COLORS, ICONS } from 'config';
import { View, Text } from 'react-native';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';
import { breakExecuteJS } from 'utils/functions';
import { translate } from 'utils/translate';
import { vtUtility } from 'vtUtility/vtUtility';

import { IField, OptionField } from './InterfaceField';
import ModalUserGroup from './ModalUserGroup';
import { usePermisstionEdit } from '../useHooks/usePermissionEdit';

const UserGroup = (
	{
		title,
		options,
		internalName,
		isGrid,
		isRequired,
		ID,
		index,
		onUpdateValueGrid,
		itemInfoGrid,
		isEditGrid,
		isViewGrid,
	}: IField,
	ref: React.Ref<unknown> | undefined,
) => {
	const dispatch = useAppDispatch();
	const refModal = useRef();

	const infoItem = useAppSelector(store => store.workflow.itemInfo);
	const init = useAppSelector(store => store.workflow.init);
	const info = isGrid ? itemInfoGrid || {} : infoItem;
	const isInit = useRef(true);
	const refDef = useRef(null);

	const valueItem: string | any[] = info?.[internalName] || '[]';

	const data = Array.isArray(valueItem)
		? valueItem
		: valueItem?.includes('[')
			? JSON?.parse(valueItem || '[]')
			: valueItem;

	const defaultValue: any[] = data || [];

	const option: OptionField = JSON.parse(options || '{}');
	const { U_Allow_Multiple_Yes, U_PeopleOnly, ExecuteJS, Require, ViewOnly } = option;
	const IsRequire = Require || isRequired;
	const { isPermission } = usePermisstionEdit(!!ViewOnly, internalName);

	const isDisable = isGrid ? !ViewOnly && isEditGrid : isPermission;
	// 0 : user
	// 1 : group

	const [error, setError] = useState(false);
	useEffect(() => {
		if (defaultValue) {
			setError(false);
		}
		try {
			const isRunEff = !refDef.current || defaultValue?.length !== refDef.current?.length;
			if (ExecuteJS && !isInit.current && !isViewGrid && isRunEff) {
				const listExecuteJS = ExecuteJS?.split('vtUtility.')?.filter(elm => elm);
				if (listExecuteJS?.length) {
					listExecuteJS?.forEach(elm => {
						const JS = breakExecuteJS(elm);

						async function handleAsync() {
							const isUserGroup = true;
							const callFunction = await vtUtility[JS.funcName](defaultValue, JS.arrExecuteJS, isUserGroup);
							if (callFunction) {
								dispatch(callFunction.function({ ...callFunction.value }));
							}
						}

						if (JS?.funcName === 'setUserManagerToControl') {
							handleAsync();
						} else {
							const callFunction = vtUtility[JS.funcName](defaultValue, JS.arrExecuteJS);
							if (callFunction) {
								dispatch(callFunction.function({ ...callFunction.value }));
							}
						}
					});
				}
			}
		} catch (error) {
			//
		}
		refDef.current = defaultValue;
	}, [defaultValue]);

	useEffect(() => {
		if (init) {
			isInit.current = false;
		}
	}, [init]);

	// const returnValue = () => {
	// 	const listRef: Array<any> = refChoices.current || [];
	// 	let isChanged = false;
	// 	choices?.map(choice => {
	// 		if (!defaultValue?.includes(choice)) {
	// 			isChanged = true;
	// 		}
	// 	});

	// 	if (IsRequire) {
	// 		if (choices?.length) {
	// 			if (isEdited || listRef?.length !== choices?.length || isChanged)
	// 				return { isEdited: true, value: choices?.toString() };
	// 			return { isEdited: false };
	// 		}
	// 		setError(true);
	// 		return { isEdited: true, value: undefined };
	// 	}
	// 	if (isEdited || listRef?.length !== choices?.length || isChanged) return { value: choices?.toString() };
	// 	return { value: undefined };
	// };

	const require = () => {
		if (!isDisable) return true;

		if (IsRequire && !defaultValue?.length) {
			setError(true);
			return false;
		}
		return true;
	};

	useImperativeHandle(
		ref,
		() => ({
			require,
		}),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[defaultValue],
	);

	// PeopleOnly ? User 0 : User&Group -1
	// U_Allow_Multiple_Yes ? multi : single

	const searchUser = () => {
		refModal.current?.show(defaultValue);
	};

	const onSubmitUser = user => {
		setError(false);
		if (isGrid) {
			onUpdateValueGrid({ [internalName]: user });
		} else {
			dispatch(
				updateValueInternalName({
					[internalName]: user,
				}),
			);
		}
	};

	const nameInfoDisable = () => {
		if (Array.isArray(defaultValue)) {
			let listName = [];
			defaultValue?.map(item => {
				listName = [...listName, item.Name];
			});
			return listName?.toString()?.replaceAll(',', ', ');
		}
		return '';
	};

	if (isViewGrid)
		return (
			<View style={{ alignItems: 'center' }}>
				<Text style={{ fontSize: 14, color: '#111' }}>{nameInfoDisable()}</Text>
			</View>
		);

	return (
		<View style={{ flexDirection: 'row', marginVertical: 15 }}>
			<Icon src={ICONS.icUserField} width={18} height={18} />

			<View style={{ marginLeft: 6, flex: 1 }}>
				<Text style={{ color: '#7B7B7B', fontSize: 12, marginBottom: 3 }}>
					{title}
					{IsRequire && isDisable && <Text style={{ color: COLORS.red }}> (*)</Text>}
				</Text>
				{!isDisable ? (
					<Text style={{ fontSize: 14, color: '#111' }}>{nameInfoDisable()}</Text>
				) : (
					<View style={{ flex: 1 }}>
						<BoxUser
							err={error}
							user={defaultValue || []}
							setUser={onSubmitUser}
							searchUser={searchUser}
							index={index}
							isSearhUser
							fullText
						/>
						{error && isDisable && (
							<Text style={{ fontSize: 12, color: COLORS.red, fontStyle: 'italic', marginTop: 2 }}>
								{title}
								{translate('isRequire')}
							</Text>
						)}
					</View>
				)}
			</View>
			<ModalUserGroup
				ref={refModal}
				RID={ID}
				onSubmitUser={onSubmitUser}
				isMultiple={U_Allow_Multiple_Yes}
				type={U_PeopleOnly ? 0 : -1}
				title={title}
			/>
		</View>
	);
};

export default forwardRef(UserGroup);
