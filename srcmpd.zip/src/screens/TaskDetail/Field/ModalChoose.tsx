/* eslint-disable import/no-cycle */
import React, { forwardRef, useImperativeHandle, useRef, useState } from 'react';

import { Icon } from 'components/Atoms/Icon';
import ModalRef from 'components/Molecules/Modal/ModalRef';
import { ICONS } from 'config/images';
import { View, Text, FlatList, TouchableOpacity } from 'react-native';
import { useAppDispatch } from 'stores';
import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';
import { translate } from 'utils/translate';

import { OptionField } from './InterfaceField';

interface IModalChoose {
	onSubmitUser: (select: string[]) => void;
	option: OptionField;
	isMultiple: boolean;
	title: string;
	internalName: string;
	isGrid: boolean;
}

const ModalChoose = (
	{ onSubmitUser, option, isMultiple = true, title, internalName, isGrid }: IModalChoose,
	ref: React.Ref<unknown> | undefined,
) => {
	const dispatch = useAppDispatch();
	const refModal = useRef<{ show: () => void; hide: () => void } | null>();
	const refSubmit = useRef(false);
	const [select, setSelect] = useState<string[]>([]);

	const convertList = () => {
		const choices = option?.Choices || option?.C_Choice_Value;
		if (!choices) return [];
		if (Array.isArray(choices)) return choices;
		if (typeof choices === 'string') {
			const clone: string = choices;
			return clone?.split('\n');
		}
	};

	const list: string[] = convertList() || [];

	const show = (listDefault = []) => {
		setSelect(listDefault);
		refModal.current?.show();
	};
	const hide = () => {
		refModal.current?.hide();
	};

	useImperativeHandle(
		ref,
		() => ({
			show,
			hide,
		}),
		[],
	);

	const onHide = () => {
		if (refSubmit.current) {
			onSubmitUser(select);
			refSubmit.current = false;
		}
	};

	return (
		<ModalRef
			ref={refModal}
			onHide={onHide}
			outsideClickCloseable
			onClose={hide}
			visiblePosition="bottom"
			isTouch={false}>
			<View style={{ maxHeight: 600, backgroundColor: 'white', borderTopEndRadius: 8, borderTopStartRadius: 8 }}>
				<View style={{ padding: 20 }}>
					<Text style={{ fontSize: 14, fontWeight: '700' }}>{title}</Text>
				</View>
				<FlatList
					contentContainerStyle={{ marginHorizontal: 20, marginBottom: 30 }}
					data={list}
					keyExtractor={(item, index) => index.toString()}
					showsVerticalScrollIndicator={false}
					renderItem={({ item }) => {
						const selected = select.find(itemSelect => itemSelect === item.trim());
						const onPress = () => {
							if (isMultiple) {
								if (selected) {
									setSelect(select.filter(itemSelect => itemSelect !== item.trim()));
								} else {
									setSelect([...select, item.trim()]);
								}
							} else {
								setSelect([item.trim()]);
								if (!isGrid) {
									setTimeout(() => {
										const clone = [item.trim()].toString().replaceAll(',', ';#');
										dispatch(
											updateValueInternalName({
												[internalName]: clone,
											}),
										);
									}, 200);
								}
								refSubmit.current = true;
								hide();
							}
						};
						return (
							<TouchableOpacity
								onPress={onPress}
								style={{
									paddingVertical: 10,
									// borderRadius: 10,
									flexDirection: 'row',
									// alignItems: 'center',
									// justifyContent: 'center',
								}}>
								<Icon src={selected ? ICONS.icCheckUser : ICONS.icUnCheckUser} width={20} height={20} />
								<Text style={{ textAlign: 'center', fontWeight: '500', paddingHorizontal: 12 }}>{item}</Text>
							</TouchableOpacity>
						);
					}}
				/>
				{isMultiple && (
					<View style={{ width: '100%', marginBottom: 20 }}>
						<TouchableOpacity
							onPress={() => {
								refSubmit.current = true;
								// setSelect()
								if (!isGrid) {
									setTimeout(() => {
										const clone = select.toString().replaceAll(',', ';#');
										dispatch(
											updateValueInternalName({
												[internalName]: clone,
											}),
										);
									}, 200);
								}
								hide();
							}}
							style={{
								backgroundColor: 'rgba(0, 95, 212, 1)',
								paddingVertical: 16,
								alignItems: 'center',
								borderRadius: 12,
								marginHorizontal: 20,
							}}>
							<Text style={{ color: 'white', fontSize: 16, fontWeight: '600' }}>{translate('save')}</Text>
						</TouchableOpacity>
					</View>
				)}
			</View>
		</ModalRef>
	);
};

export default forwardRef(ModalChoose);
