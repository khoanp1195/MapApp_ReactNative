/* eslint-disable @typescript-eslint/no-use-before-define */
/* eslint-disable react-hooks/exhaustive-deps */
import React, { forwardRef, useEffect, useState, useImperativeHandle, useRef } from 'react';

import { Icon } from 'components/Atoms/Icon';
import { refModalMonthPicker } from 'components/Atoms/Loading/ModalMonthPicker';
import { COLORS } from 'config/colors';
import { ICONS } from 'config/images';
import useSystem from 'hooks/useSystem';
import moment from 'moment';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateDateMonth, updateValueInternalName } from 'stores/Workflows/sliceWorkflow';
import { breakExecuteJS } from 'utils/functions';
import { translate } from 'utils/translate';
import { vtUtility } from 'vtUtility/vtUtility';

import { IField, OptionField } from './InterfaceField';
import { usePermisstionEdit } from '../useHooks/usePermissionEdit';

const DateTime = (
	{
		title,
		options,
		internalName,
		isGrid,
		isRequired,
		isDate,
		onUpdateValueGrid,
		itemInfoGrid,
		isEditGrid,
		isViewGrid,
	}: IField,
	ref: React.Ref<unknown> | undefined,
) => {
	const dispatch = useAppDispatch();
	const isInit = useRef(true);
	const refTimeout = useRef();

	const infoItem = useAppSelector(store => store.workflow.itemInfo);
	const dateMonth = useAppSelector(store => store.workflow.dateMonth);
	const init = useAppSelector(store => store.workflow.init);
	const info = isGrid ? itemInfoGrid : infoItem;

	const defaultValue = info?.[internalName] || '';

	const { isVN } = useSystem();

	const option: OptionField = JSON.parse(options || '{}');
	const { Require, D_DateOnly: isOnlyDate, ExecuteJS, ViewOnly, D_DateView } = option;
	const { isPermission } = usePermisstionEdit(!!ViewOnly, internalName);
	const isDisable = isGrid ? !ViewOnly && isEditGrid : isPermission;

	const IsRequire = Require || isRequired;

	const formatForm = isOnlyDate ? 'DD/MM/YY' : 'DD/MM/YY HH:mm';

	const getViewDate = () => {
		switch (option.D_DateView) {
			case 'decade':
				return 'YYYY';
			case 'year':
				return 'MM/YYYY';

			default:
				return isOnlyDate ? (isVN ? 'DD/MM/YY' : 'MM/DD/YY') : isVN ? 'DD/MM/YY HH:mm' : 'MM/DD/YY HH:mm';
		}
	};

	const infoViewDateTime = getViewDate();

	const [open, setOpen] = useState(false);
	const [error, setError] = useState(false);

	async function HandleDayWork(JS: { funcName: string; arrExecuteJS: any[] }) {
		const callFunction = await vtUtility[JS.funcName](info, JS.arrExecuteJS, internalName);
		console.log('callFunction', callFunction);
		if (callFunction) {
			if (isGrid && onUpdateValueGrid) {
				onUpdateValueGrid(callFunction.value);
			} else {
				dispatch(callFunction.function(callFunction.value));
			}
		}
	}

	useEffect(() => {
		if (dateMonth?.name && dateMonth?.name === internalName) {
			if (defaultValue !== moment(dateMonth.value).format('YYYY-MM-DDTHH:mm:ss')) {
				isInit.current = false;
				if (isGrid && onUpdateValueGrid) {
					onUpdateValueGrid({
						[internalName]: moment(dateMonth.value).format('YYYY-MM-DDTHH:mm:ss'),
					});
				} else {
					dispatch(
						updateValueInternalName({
							[internalName]: moment(dateMonth.value).format('YYYY-MM-DDTHH:mm:ss'),
						}),
					);
					dispatch(
						updateDateMonth({
							name: '',
							value: '',
						}),
					);
				}
			}
		}
	}, [dateMonth]);

	useEffect(() => {
		try {
			if (ExecuteJS && !isInit.current && !isViewGrid) {
				const listExecuteJS = ExecuteJS?.split('vtUtility.')?.filter(elm => elm);
				if (listExecuteJS?.length) {
					listExecuteJS?.forEach(elm => {
						const JS = breakExecuteJS(elm);
						if (JS?.funcName === 'getTotalDateWork') {
							HandleDayWork(JS);
						} else {
							const callFunction = vtUtility[JS.funcName](info, JS.arrExecuteJS, internalName);
							if (callFunction) {
								if (isGrid && onUpdateValueGrid) {
									onUpdateValueGrid(callFunction.value);
								} else {
									dispatch(callFunction.function(callFunction.value));
								}
							}
						}
					});
				}
			}
		} catch (error) {
			//
		}
	}, [defaultValue]);

	useEffect(() => {
		if (init) {
			isInit.current = false;
		}
		return () => {
			if (refTimeout.current) {
				clearTimeout(refTimeout.current);
			}
		};
	}, [init]);

	const dateTime = defaultValue ? moment(new Date(defaultValue)).format(formatForm) : '';
	const viewDateTime = defaultValue ? moment(new Date(defaultValue)).format(infoViewDateTime) : '';

	useImperativeHandle(
		ref,
		() => ({
			require: () => {
				if (!isDisable) return true;

				if (IsRequire && !defaultValue) {
					setError(true);
					return false;
				}
				return true;
			},
		}),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[dateTime],
	);

	const handleConfirm = (res: moment.MomentInput) => {
		setOpen(false);
		setError(false);
		refTimeout.current = setTimeout(() => {
			if (defaultValue !== moment(res).format('YYYY-MM-DDTHH:mm:ss')) {
				isInit.current = false;
				if (isGrid) {
					onUpdateValueGrid({
						[internalName]: moment(res).format('YYYY-MM-DDTHH:mm:ss'),
					});
				} else {
					dispatch(
						updateValueInternalName({
							[internalName]: moment(res).format('YYYY-MM-DDTHH:mm:ss'),
						}),
					);
				}
			}
		}, 200);
	};

	const hideDatePicker = () => {
		setOpen(false);
	};

	if (isViewGrid)
		return (
			<View style={{ alignItems: 'center' }}>
				<Text style={{ fontSize: 14, color: '#111' }}>{viewDateTime}</Text>
			</View>
		);

	return (
		<View style={styles.container}>
			<Icon src={ICONS.icCalendarField} width={18} height={18} />
			<View style={styles.body}>
				<Text numberOfLines={1} style={styles.title}>
					{title}
					{IsRequire && isDisable && <Text style={{ color: COLORS.red }}> (*)</Text>}
				</Text>

				<TouchableOpacity
					disabled={!isDisable}
					onPress={() => {
						if (isOnlyDate && D_DateView === 'year') {
							refModalMonthPicker.current?.show(defaultValue, internalName);
						} else {
							setOpen(true);
						}
					}}
					activeOpacity={1}
					style={{
						borderWidth: isDisable ? 0.8 : 0,
						paddingHorizontal: isDisable ? 10 : 0,
						paddingVertical: isDisable ? 5 : 0,
						borderColor: error ? COLORS.red : open ? '#335FB3' : 'rgba(217, 217, 217, 1)',
						height: isDisable ? 38 : 28,
						justifyContent: 'space-between',
						flexDirection: 'row',
						alignItems: 'center',
						borderRadius: 8,
					}}>
					<Text style={{ fontSize: 14, color: isDisable ? '#000' : '#111', flex: 1 }}>{viewDateTime}</Text>
					{isDisable && (
						<Icon src={ICONS.icCalendarField} width={16} height={16} tintColor={open ? '#335FB3' : '#28303F'} />
					)}
				</TouchableOpacity>
				<DateTimePickerModal
					isVisible={open}
					mode={isOnlyDate || isDate ? 'date' : 'datetime'}
					onConfirm={handleConfirm}
					onCancel={hideDatePicker}
					date={defaultValue ? new Date(defaultValue) : new Date()}
					locale={isVN ? 'vi' : 'en'}
				/>
				{error && isDisable && (
					<Text style={styles.rq}>
						{title}
						{translate('isRequire')}
					</Text>
				)}
			</View>
		</View>
	);
};

export default forwardRef(DateTime);

const styles = StyleSheet.create({
	container: { flexDirection: 'row', marginVertical: 15 },
	body: { marginLeft: 6, flex: 1 },
	title: { color: '#7B7B7B', fontSize: 12, marginBottom: 3, fontWeight: '400' },
	vTitle: { flexDirection: 'row', alignItems: 'center' },
	value: { fontSize: 14, color: '#111', fontWeight: '400' },
	bPlain: {
		width: '100%',
		height: 70,
		borderWidth: 0.8,
		borderRadius: 8,
		paddingHorizontal: 10,
	},
	cRich: {
		width: '100%',
		borderRadius: 8,
		height: 200,
	},
	rq: { fontSize: 12, color: COLORS.red, fontStyle: 'italic', marginTop: 2 },
});
