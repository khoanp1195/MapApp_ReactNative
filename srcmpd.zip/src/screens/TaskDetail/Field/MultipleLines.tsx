/* eslint-disable @typescript-eslint/no-use-before-define */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useRef, useEffect, forwardRef, useImperativeHandle } from 'react';

import AsyncStorage from '@react-native-async-storage/async-storage';
import { Icon } from 'components/Atoms/Icon';
import { COLORS, ICONS } from 'config';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { actions, RichEditor, RichToolbar } from 'react-native-pell-rich-editor';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';
import { breakExecuteJS } from 'utils/functions';
import { translate } from 'utils/translate';
import { vtUtility } from 'vtUtility/vtUtility';

import { IField, OptionField } from './InterfaceField';
import { usePermisstionEdit } from '../useHooks/usePermissionEdit';

const MultipleLines = (
	{ title, options, internalName, isGrid, isRequired, itemInfoGrid, onUpdateValueGrid, isEditGrid, isViewGrid }: IField,
	ref: React.Ref<unknown> | undefined,
) => {
	const dispatch = useAppDispatch();
	const refInput = useRef<TextInput>(null);
	const refValueField = useRef<string>('');
	const isInit = useRef(true);
	const refTimeout = useRef(null);
	const richtext = useRef<{ setContentHTML: (defaultValue: any) => void }>(null);
	const init = useAppSelector(store => store.workflow.init);
	const infoItem = useAppSelector(store => store.workflow.itemInfo);
	const info = isGrid ? itemInfoGrid : infoItem;
	const defaultValue = info?.[internalName] || '';

	const option: OptionField = JSON.parse(options || '{}');
	const { Require, ExecuteJS, M_PlainText: PlainText, ViewOnly } = option;
	const { isPermission } = usePermisstionEdit(!!ViewOnly, internalName);
	const isDisable = isGrid ? !ViewOnly && isEditGrid : isPermission;
	const IsRequire = Require || isRequired;

	const [error, setError] = useState(false);
	const [isFocus, setIsFocus] = useState(false);
	const [value, setValue] = useState('');

	// const [tk, setTk] = useState('');

	// useEffect(() => {
	// 	AsyncStorage.getItem('FCM_TOKEN').then(res => {
	// 		setTk(res);
	// 	});
	// }, []);

	useEffect(() => {
		refValueField.current = defaultValue;
		setValue(defaultValue);
		try {
			if (richtext.current) {
				richtext.current?.setContentHTML(defaultValue);
			}

			if (ExecuteJS && !isInit.current && !isViewGrid) {
				const listExecuteJS = ExecuteJS?.split('vtUtility.')?.filter(elm => elm);
				if (listExecuteJS?.length) {
					listExecuteJS?.forEach(elm => {
						const JS = breakExecuteJS(elm);
						const callFunction = vtUtility[JS.funcName](info, JS.arrExecuteJS);
						if (callFunction) {
							if (isGrid) {
								onUpdateValueGrid(callFunction.value);
							} else {
								dispatch(callFunction.function(callFunction.value));
							}
						}
					});
				}
			}
		} catch (err) {
			//
		}
	}, [defaultValue]);

	useEffect(() => {
		if (init) {
			isInit.current = false;
		}
		return () => {
			if (refTimeout.current) {
				clearTimeout(refTimeout.current);
			}
		};
	}, [init]);

	useImperativeHandle(
		ref,
		() => ({
			require: () => {
				if (!isDisable) return true;
				if (IsRequire && !defaultValue) {
					setError(true);
					return false;
				}
				return true;
			},
		}),
		[defaultValue],
	);

	const onFocus = () => {
		setIsFocus(true);
	};

	const onBlur = () => {
		setIsFocus(false);
		refTimeout.current = setTimeout(() => {
			if (refValueField.current !== defaultValue) {
				if (isGrid) {
					onUpdateValueGrid({ [internalName]: refValueField.current });
				} else {
					dispatch(
						updateValueInternalName({
							[internalName]: refValueField.current,
						}),
					);
				}
			}
		}, 100);
	};

	const onChangeText = (text: string) => {
		setError(false);
		refValueField.current = text;
		setValue(text);
	};

	const onPressFocus = () => refInput.current?.focus();

	const customIcon = () => {
		return <Text style={{ color: '#71787F' }}>H1</Text>;
	};
	const customIcon2 = () => {
		return <Text style={{ color: '#71787F' }}>H2</Text>;
	};
	const customIcon3 = () => {
		return <Text style={{ color: '#71787F' }}>H3</Text>;
	};

	const customIcon4 = () => {
		return <Text style={{ color: '#71787F' }}>H4</Text>;
	};
	const customIcon5 = () => {
		return <Text style={{ color: '#71787F' }}>H5</Text>;
	};
	const customIcon6 = () => {
		return <Text style={{ color: '#71787F' }}>H6</Text>;
	};

	const customIconParagraph = () => {
		return <Text style={{ color: '#71787F' }}>Par</Text>;
	};

	const border = error ? COLORS.red : isFocus ? (!error ? '#335FB3' : COLORS.red) : 'rgba(217, 217, 217, 1)';

	const fontFamily = 'Arial,sans-serif';
	const initialCSSText = { contentCSSText: `font-family: ${fontFamily}`, color: '#111' };

	const removeStyle = (inputString: string) => {
		// Remove inline styles using regular expression
		const cleanString = inputString.replace(/style="[^"]*"/g, '');
		return cleanString;
	};

	const a = `<div><span style="font-family: baomoi, AvenirNextCondensed-Medium, HelveticaNeue-CondensedBold, sans-serif-condensed, Calibri, Corbel, &quot;Liberation Sans Narrow&quot;, &quot;Lohit Odia&quot;; font-size: 22px;">Được thành lập từ tháng 4/2023 với 31 thành viên, câu lạc bộ (CLB) Cựu chiến binh tự quản bảo vệ môi trường thôn An Thịnh (xã An Hòa Thịnh) đã có nhiều đóng góp cho xây dựng nông thôn mới. Mỗi tuần một lần, 31 hội viên của CLB sẽ cùng ra quân làm sạch đường làng, ngõ xóm, khu dân cư; khơi thông cống rãnh, thu gom rác thải…&nbsp;</span></div>`;
	// console.log('first', JSON.stringify({ a }));
	if (isViewGrid)
		return (
			<View style={{ alignItems: 'center' }}>
				<Text style={styles.value}>{defaultValue}</Text>
			</View>
		);

	return (
		<View style={styles.container}>
			<Icon src={PlainText ? ICONS.icSubject : ICONS.icRichText} width={18} height={18} />
			<View style={styles.body}>
				<Text style={styles.title}>
					{title}
					{IsRequire && isDisable && <Text style={{ color: COLORS.red }}> (*)</Text>}
				</Text>

				{PlainText || isGrid ? (
					!isDisable ? (
						<Text style={styles.value}>{defaultValue}</Text>
					) : (
						<TouchableOpacity onPress={onPressFocus} activeOpacity={1} style={[styles.bPlain, { borderColor: border }]}>
							<TextInput
								ref={refInput}
								value={value}
								multiline
								onChangeText={onChangeText}
								onFocus={onFocus}
								onBlur={onBlur}
							/>
							{/* <TextInput value={tk} multiline onChangeText={setTk} style={{ marginTop: 10, borderWidth: 1 }} /> */}
						</TouchableOpacity>
					)
				) : (
					<View style={{}}>
						<RichEditor
							ref={richtext}
							androidLayerType="software"
							disabled={!isDisable}
							containerStyle={[
								styles.cRich,
								{
									borderWidth: !isDisable ? 0 : 0.8,
									borderColor: border,
								},
							]}
							editorStyle={initialCSSText}
							style={{}}
							initialContentHTML={defaultValue?.toString()}
							useContainer={false}
							onFocus={onFocus}
							onBlur={onBlur}
							onChange={text => {
								console.log('text', text);
								setError(false);
								refValueField.current = text;
							}}
							hideKeyboardAccessoryView
							keyboardDisplayRequiresUserAction
							showSoftInputOnFocus={false}
							renderToHardwareTextureAndroid
						/>
						{isDisable && (
							<RichToolbar
								editor={richtext}
								actions={[
									actions.keyboard,
									actions.setBold,
									actions.setItalic,
									actions.setUnderline,
									actions.insertBulletsList,
									actions.insertOrderedList,
									actions.alignLeft,
									actions.alignCenter,
									actions.alignRight,
									actions.alignFull,
									actions.indent,
									actions.setParagraph,
									actions.heading1,
									actions.heading2,
									actions.heading3,
									actions.heading4,
									actions.heading5,
									actions.heading6,
								]}
								selectedButtonStyle={{ backgroundColor: COLORS.lineGrey }}
								iconMap={{
									[actions.setParagraph]: customIconParagraph,
									[actions.heading1]: customIcon,
									[actions.heading2]: customIcon2,
									[actions.heading3]: customIcon3,
									[actions.heading4]: customIcon4,
									[actions.heading5]: customIcon5,
									[actions.heading6]: customIcon6,
								}}
							/>
						)}
					</View>
				)}
				{error && isDisable && (
					<Text style={styles.rq}>
						{title}
						{translate('isRequire')}
					</Text>
				)}
			</View>
		</View>
	);
};

export default forwardRef(MultipleLines);

const styles = StyleSheet.create({
	container: { flexDirection: 'row', marginVertical: 15 },
	body: { marginLeft: 6, flex: 1 },
	title: { color: '#7B7B7B', fontSize: 12, marginBottom: 3, fontWeight: '400' },
	vTitle: { flexDirection: 'row', alignItems: 'center' },
	value: { fontSize: 14, color: '#111', fontWeight: '400' },
	bPlain: {
		width: '100%',
		height: 70,
		borderWidth: 0.8,
		borderRadius: 8,
		paddingHorizontal: 10,
	},
	cRich: {
		width: '100%',
		borderRadius: 8,
		height: 200,
	},
	rq: { fontSize: 12, color: COLORS.red, fontStyle: 'italic', marginTop: 2 },
});
