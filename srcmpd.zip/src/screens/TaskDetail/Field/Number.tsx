/* eslint-disable prettier/prettier */
import React, { forwardRef, useEffect, useRef, useState, useImperativeHandle, createRef, memo } from 'react';

import { Icon } from 'components/Atoms/Icon';
import { COLORS } from 'config/colors';
import { ICONS } from 'config/images';
import useSystem from 'hooks/useSystem';
import { View, Text, TouchableOpacity, TextInput, Keyboard, Alert } from 'react-native';
import { useAppDispatch, useAppSelector } from 'stores';
import { editDetails, updateItemInfo } from 'stores/TaskDetails';
import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';
import { breakExecuteJS, containsAllAlphabets, filterAndRemoveNonAlphabets } from 'utils/functions';
import { translate } from 'utils/translate';
import { vtUtility } from 'vtUtility/vtUtility';

import { IField, OptionField } from './InterfaceField';
import { usePermisstionEdit } from '../useHooks/usePermissionEdit';


const NumberField = (
	{ title, options, internalName, isGrid = false, itemInfoGrid, isRequired, onUpdateValueGrid, isEditGrid, isViewGrid
	}: IField,
	ref: React.Ref<unknown> | undefined,
) => {
	const dispatch = useAppDispatch();
	const refInput = useRef<TextInput>(null);
	const isInit = useRef(true);
	const refTimeout = useRef();
	const { isVN } = useSystem();

	const init = useAppSelector(store => store.workflow.init);
	const infoItem = useAppSelector(store => store.workflow.itemInfo);

	const info = isGrid ? itemInfoGrid : infoItem;


	const defaultValue = info?.[internalName] || '';


	const option: OptionField = JSON.parse(options || '{}');


	const { Require, ExecuteJS, ViewOnly, N_Min, N_Max } = option
	const IsRequire = Require || isRequired;
	const { isPermission } = usePermisstionEdit(!!ViewOnly, internalName);
	const isDisable = isGrid ? !ViewOnly && isEditGrid : isPermission;


	const [isFocus, setIsFocus] = useState(false);
	const [error, setError] = useState(false);
	const [value, setValue] = useState()
	// vtUtility.onCalculatorPlusToEffect(that,"FieldNumberTitleVNFieldNumber","Number2","FieldNumber3");
	useEffect(() => {
		console.log('defaultValue', defaultValue)
		try {
			const iNotNumber = containsAllAlphabets(defaultValue?.toString())
			if (iNotNumber) {
				const valueRemove = filterAndRemoveNonAlphabets(defaultValue?.toString())
				if (isGrid) {
					onUpdateValueGrid({
						[internalName]: valueRemove
					})
				} else {
					dispatch(updateValueInternalName({
						[internalName]: valueRemove
					}));
				}
			} else {
				setValue(defaultValue)

				if (ExecuteJS && !isInit.current && !isViewGrid) {
					const listExecuteJS = ExecuteJS?.split('vtUtility.')?.filter(elm => elm);

					if (listExecuteJS?.length) {
						listExecuteJS?.forEach(elm => {
							const JS = breakExecuteJS(elm)
							const callFunction = vtUtility[JS.funcName](info, JS.arrExecuteJS, internalName, { isVN, unit: '' });
							if (callFunction) {
								if (isGrid) {
									onUpdateValueGrid(callFunction.value)
								} else {
									dispatch(callFunction.function(callFunction.value));
								}
							}
						})

					}

				}
			}
		} catch (err) {
			//
		}
	}, [defaultValue]);

	useEffect(() => {
		if (init) {
			isInit.current = false;
		}

	}, [init]);



	const checkRequire = () => {
		if (!isDisable) return true;

		if (IsRequire && !defaultValue) {
			setError(true)
			return false;
		}
		return true;
	};


	useImperativeHandle(
		ref,
		() => ({
			require: checkRequire,
		}),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[defaultValue],
	);


	useEffect(() => {
		if (isFocus) {
			refInput.current?.focus();
		}
	}, [isFocus]);

	const onFocus = () => setIsFocus(true);

	const onBlur = () => {
		setIsFocus(false);
		let realValue = value
		if (N_Min) {
			if (Number(value) < Number(N_Min)) realValue = N_Min
		}
		if (N_Max) {
			if (Number(value) > Number(N_Max)) realValue = N_Max
		}

		const valueNumber = Number(realValue).toFixed(option?.N_Number_Decimal || 0)

		setValue(valueNumber)

		refTimeout.current = setTimeout(() => {
			// if (value !== defaultValue) {
			isInit.current = false
			if (isGrid) {
				onUpdateValueGrid({
					[internalName]: valueNumber
				})
			} else {
				dispatch(
					updateValueInternalName({
						[internalName]: valueNumber,
					}),
				);
			}
			// }
		}, 100);
	}


	const myViewRef = useRef(null);

	const measureView = () => {
		// console.log('myViewRef', myViewRef)
		// if (myViewRef.current) {
		// 	myViewRef.current?.measureInWindow((x, y, width, height, pageX, pageY) => {
		// 		console.log('x:', x);
		// 		console.log('y:', y);
		// 		console.log('width:', width);
		// 		console.log('height:', height);
		// 		console.log('pageX:', pageX);
		// 		console.log('pageY:', pageY);
		// 	});
		// }
	};

	const onPressFocus = () => {
		setIsFocus(true);
		measureView()
	};

	function numberWithCommas(x: string) {
		if (!x && x !== 0) return '';
		const number = Number(x).toFixed(option?.N_Number_Decimal || 0)
		const numberReplace = number.replace('.', ',').replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, '.')
		return numberReplace
	}

	const commas = !value && value == '' ? value : numberWithCommas(value?.toString());


	// useEffect(() => {

	// }, [value])



	const onChangeText = (text: string) => {
		setError(false)
		const isMax = text?.includes('e+')
		if (isMax) {
			if (text?.length < value?.length) return setValue('');
			return setValue(value)
		}
		const textDot = text.replace(',', '.')
		const arr: any[] = textDot?.split('.');
		if (arr?.length > 2) {
			setValue(value);
		} else {
			setValue(textDot);
		}
	};

	if (isViewGrid)
		return (
			<View style={{ alignItems: 'center' }}>
				<Text style={{ fontSize: 14, color: '#111' }}>{commas}</Text>
			</View>
		);

	// const onLayout = event => {
	// 	event.target.measure((x, y, width, height, pageX, pageY) => {
	// 		console.log('onLayout', y);
	// 	});

	// };




	return (
		<View ref={myViewRef} style={{ flexDirection: 'row', marginVertical: 15 }} onLayout={(event) => {
			const { layout } = event.nativeEvent;
		}}>
			<Icon src={ICONS.icNumeric} width={18} height={18} />

			<View style={{ marginLeft: 6, flex: 1 }}>
				<Text style={{ color: '#7B7B7B', fontSize: 12, marginBottom: 3 }} >
					{title}{IsRequire && isDisable && <Text style={{ color: COLORS.red }}> (*)</Text>}
				</Text>
				{!isDisable ? (
					<Text style={{ fontSize: 14, color: '#111' }}>{commas}</Text>
				) : (
					isFocus ? <TextInput ref={refInput}
						value={value ? value?.toString() : ''}
						onChangeText={onChangeText}
						onFocus={onFocus}
						onBlur={onBlur}
						keyboardType="numeric"
						returnKeyType='done'
						style={{
							borderWidth: 0.8,
							height: 38,
							padding: 10,
							borderRadius: 8,
							borderColor: error ? COLORS.red : isFocus ? (!error ? '#335FB3' : COLORS.red) : 'rgba(217, 217, 217, 1)',
						}} />
						:
						(
							<TouchableOpacity
								onPress={onPressFocus}
								activeOpacity={1}
								style={{
									width: '100%',
									borderWidth: 0.8,
									borderRadius: 8,
									paddingHorizontal: 10,
									borderColor: error ? COLORS.red : isFocus ? (!error ? '#335FB3' : COLORS.red) : 'rgba(217, 217, 217, 1)',
									height: 38,
									justifyContent: 'center',
								}}>
								<Text >{commas}</Text>
							</TouchableOpacity>
						)
				)}
				{error && isDisable && (
					<Text style={{ fontSize: 12, color: COLORS.red, fontStyle: 'italic', marginTop: 2 }}>
						{title}
						{translate('isRequire')}
					</Text>
				)}
			</View>
		</View>
	);
};

export default memo(forwardRef(NumberField));
