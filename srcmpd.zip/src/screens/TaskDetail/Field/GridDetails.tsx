import React, { useState, useEffect, forwardRef, useRef, useImperativeHandle } from 'react';

import { useNavigation } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { COLORS, ICONS } from 'config';
import moment from 'moment';
import { View, Text, TouchableOpacity, ScrollView } from 'react-native';
import { useAppDispatch } from 'stores';
import { fetchGirdDetails } from 'stores/TaskDetails/thunks';
import { vtUtility } from 'vtUtility/vtUtility';

import { IField, OptionField } from './InterfaceField';
import { usePermisstionEditGrid } from '../useHooks/usePermissionEdit';

const GridDetails = (
	{ title, internalName, ID, SPItemId, forms, refreshing, options, isRequired }: IField,
	ref: React.Ref<unknown> | undefined,
) => {
	const dispatch = useAppDispatch();
	const navigation = useNavigation();
	const refGridDetails = useRef([]);
	const refListEdit = useRef([]);
	const option: OptionField = JSON.parse(options || '{}');
	const Require = option?.Require || isRequired;

	const ExecuteJS = option?.ExecuteJS;

	// ExecuteJS vtUtility.onCalculatorUpdateTotalMasterEffect(this, "FieldNumber2", "FieldTotalGridDetailsNew");

	const { isPermissionEdit } = usePermisstionEditGrid(internalName?.replace('_17_', '')?.replace('_Mobile', ''));

	const [header, setHeader] = useState([]);

	const [data, setData] = useState([]);
	const [listField, setListField] = useState([]);
	const [detailsListInfo, setDetailsListInfo] = useState({});
	const [error, setError] = useState(false);
	const [fieldSum, setFieldSum] = useState<number[]>([]);

	const getToTalValue = index => {
		let total = 0;
		data?.map(item => {
			total += Number(Object.values(item)[index]);
		});
		return Number(total);
	};

	useEffect(() => {
		if (data?.length) {
			try {
				const arrExecuteJS = ExecuteJS.replace('vtUtility.', '').replace(');', '').split('(');
				const funcName = arrExecuteJS[0] as 'onCalculatorUpdateTotalMasterEffect';
				let valueControl = 0;
				if (funcName === 'onCalculatorUpdateTotalMasterEffect') {
					const params = arrExecuteJS[1];
					const arrParams = params.replaceAll('"', '').split(',');
					const index = listField?.findIndex(item => {
						return item?.Name === arrParams[1]?.trim();
					});
					valueControl = getToTalValue(index + 1);

					const callFunction = vtUtility[funcName](valueControl, arrExecuteJS);
					if (callFunction) {
						dispatch(callFunction.function({ ...callFunction.value }));
					}
				}
			} catch (err) {
				//
			}
		}
	}, [data, listField]);

	useEffect(() => {
		let fieldSum = [];
		listField.map((item, index) => {
			if (item?.Option?.IsSum == 'true') {
				fieldSum = [...fieldSum, index + 1];
			}
		});
		setFieldSum(fieldSum);
	}, [listField]);

	const getData = () => {
		if (!refGridDetails.current?.length) setError(true);
		return refGridDetails.current?.length ? { value: refGridDetails.current } : { value: undefined };
	};

	const checkRequire = () => {
		return true;
	};

	useImperativeHandle(
		ref,
		() => ({
			getData,
			require: checkRequire,
		}),
		[data, refGridDetails.current],
	);

	const success = res => {
		setData(res.data.data.Data);
		setListField(res.data.data.ListField);
	};

	const getDataGrid = () => {
		if (forms?.rid === ID) {
			const formsData = JSON.parse(forms?.InfoCollection?.FormDefineInfo || '[]');
			const formFromName = formsData?.[0]?.detailsTableInfoCollection?.find(
				res => res?.masterFieldInfo?.internalName === internalName?.replace('_17_', '')?.replace('_Mobile', ''),
			);
			let listHeader = [];
			let _internalName = [];
			formFromName?.detailsFieldInfoCollection?.map(res => {
				listHeader = [...listHeader, res.title];
				_internalName = [..._internalName, { internalName: res?.internalName }];
			});
			setDetailsListInfo(formFromName?.detailsListInfo);
			setHeader(listHeader);
			dispatch(
				fetchGirdDetails({
					rid: ID,
					spitemid: SPItemId,
					detailsFieldInfoCollection: _internalName,
					detailsListInfo: formFromName?.detailsListInfo,
					success,
				}),
			);
		}
	};

	useEffect(() => {
		getDataGrid();
	}, [forms?.rid]);

	useEffect(() => {
		if (refreshing) {
			getDataGrid();
		}
	}, [refreshing]);

	const renderValue = (value, name) => {
		const keyName = listField.find(field => field.Name === name);
		switch (keyName?.FieldType) {
			case 1:
				return value;
			case 2:
				return value;
			case 3:
				return value;
			case 4:
				return moment(new Date(value)).format('DD/MM/YY hh:mm');
			case 5:
				return value;
			case 6:
				return value;
			case 7:
				const nameLookup = value?.split(';#')?.map((data, index) => {
					if (index % 2 !== 0) {
						return data;
					}
				});
				return nameLookup?.filter(data => data !== undefined)?.toString();
			case 8:
				return value ? '√' : '';
			case 9:
				return Number(value);
			case 10:
				return value;
			case 11:
				return value;
			case 12:
				return value;
			case 13:
				return value;
			case 14:
				return value;
			case 17:
				return Number(value?.split(';#')[1]);
			case 20:
				const name = value?.split(';#')?.map((data, index) => {
					if (index % 2 !== 0) {
						return data;
					}
				});
				return name?.filter(data => data !== undefined)?.toString();

			default:
				return value;
		}
	};

	const onCallback = (item, index, action, ListEdit) => {
		setError(false);
		if (action === 'add') {
			let listData = { _RowNumber_: data?.length + 1 };
			item?.map(e => {
				listData = {
					...listData,
					[e.Name]: e.Value,
				};
			});
			const _ID_ = Math.floor(Math.random() * 100);
			refGridDetails.current = [...refGridDetails.current, { _ID_, ActionType: 1, Value: item }];

			setData(data.concat({ ...listData, _ID_ }));
		} else if (action === 'update') {
			const listData = JSON.parse(JSON.stringify(data));

			const indexRef = refGridDetails.current?.findIndex(item => item._ID_ === listData[index]._ID_);
			if (indexRef !== -1) {
				if (refGridDetails.current[indexRef]?.ActionType === 1) {
					refGridDetails.current[indexRef] = {
						...refGridDetails.current[indexRef],
						Value: { ...refGridDetails.current[indexRef].Value, ...item },
					};
				} else {
					refGridDetails.current[indexRef] = { _ID_: listData[index]._ID_, Value: item, ActionType: 2 };
				}
			} else {
				refGridDetails.current = [
					...refGridDetails.current,
					{ _ID_: listData[index]._ID_, ActionType: 2, Value: item },
				];
			}
			item?.map(res => {
				listData[index][res.Name] = res?.ConvertName || res.Value;
			});
			refListEdit.current = [...refListEdit.current, ...ListEdit];
			setData(listData);
		} else {
			const listData = data;
			const indexRef = refGridDetails.current?.findIndex(item => item._ID_ === listData[index]._ID_);
			if (indexRef !== -1) {
				refGridDetails.current[indexRef] = { _ID_: listData[index]._ID_, ActionType: 3 };
			} else {
				refGridDetails.current = [...refGridDetails.current, { _ID_: listData[index]._ID_, ActionType: 3 }];
			}
			setData(data?.filter((e, i) => i !== index));
		}
	};

	// const dataTest = {
	// 	_RowNumber_: '',
	// 	_ID_: 0,
	// };

	const CvDatatTest = () => {
		let list = {};
		header.map(item => {
			if (item === '#') {
				list = { ...list, ...{ _RowNumber_: '' } };
			} else {
				list = { ...list, ...{ [item]: '' } };
			}
		});
		return { ...list, _ID_: 0 };
	};

	const dataCustom = fieldSum?.length ? [...data, CvDatatTest()] : data;

	return (
		<View style={{ marginVertical: 10, marginHorizontal: -16 }}>
			<View
				style={{
					flexDirection: 'row',
					justifyContent: 'space-between',
					backgroundColor: 'rgba(245, 245, 245, 1)',
					paddingHorizontal: 16,
					paddingVertical: 12,
				}}>
				<Text numberOfLines={1} style={{ color: '#7B7B7B', fontSize: 12, marginBottom: 4, fontWeight: '700', flex: 1 }}>
					{title}
				</Text>
				{Require && <Text style={{ color: COLORS.red }}>(*)</Text>}

				{!isPermissionEdit && (
					<TouchableOpacity
						style={{ flexDirection: 'row', alignItems: 'center', marginLeft: 12 }}
						onPress={() => {
							navigation.navigate('EditGridDeatils', {
								ID,
								header,
								detailsListInfo,
								listField,
								isAdd: true,
								onCallback,
							});
						}}>
						<Icon src={ICONS.icPlus} width={20} height={20} />
					</TouchableOpacity>
				)}
			</View>
			{/* <ScrollView
				horizontal
				showsHorizontalScrollIndicator={false}>
				<ScrollView
					scrollEnabled={!!dataCustom?.length}
					style={[{ overflow: 'hidden', borderColor: '#F5F5F5' }, dataCustom?.length ? {} : { height: 50 }]}
					showsVerticalScrollIndicator={false}>
					<View
						style={{
							flexDirection: 'row',
							// backgroundColor: '#F9F9F9',
							overflow: 'hidden',
							alignItems: 'center',
							// borderRadius: 6,
							// height: 50,
							borderBottomWidth: 1,
							borderBottomColor: 'rgba(238, 238, 238, 1)',
						}}>
						<View
							style={{
								flexDirection: 'row',
								justifyContent: 'space-between',
								paddingHorizontal: 15,
								width: header?.length ? 160 * (header?.length - 1) + 50 : 160,
								overflow: 'hidden',
								alignItems: 'flex-end',
								paddingVertical: 8,
								marginTop: 12,
							}}>
							{header?.map((res, key) => {
								return (
									<Text
										numberOfLines={1}
										key={key?.toString()}
										style={{ width: key === 0 ? 50 : 160, fontSize: 12, fontWeight: '700', color: '#7B7B7B' }}>
										{res}
									</Text>
								);
							})}
						</View>
					</View>
					{!!dataCustom?.length &&
						dataCustom?.map((e, key) => {
							return (
								<TouchableOpacity
									disabled={key === dataCustom.length - 1}
									onPress={() =>
										navigation.navigate('EditGridDeatils', {
											item: e,
											header,
											listField,
											ID,
											detailsListInfo,
											isPermissionEdit,
											isAdd: false,
											onCallback,
											index: key,
											listEdited: refListEdit.current,
										})
									}
									key={key?.toString()}
									style={{
										flexDirection: 'row',
										borderBottomWidth: 0.8,
										borderBottomColor: 'rgba(238, 238, 238, 1)',
									}}>
									{Object.values(e)?.map((res, index) => {
										const isSum = fieldSum.includes(index) && key === dataCustom.length - 1;
										if (index === Object.values(e)?.length - 1) return null;
										return (
											<View key={index?.toString()} style={{ marginBottom: 1, width: index === 0 ? 50 : 160 }}>
												<View
													style={{
														padding: 15,
														flexDirection: 'row',
														alignItems: 'center',
													}}>
													<Text style={{ fontSize: 14, fontWeight: '400', color: '#111' }}>
														{isSum ? getToTalValue(index) : renderValue(res, Object.keys(e)[index])}
													</Text>
												</View>
											</View>
										);
									})}
								</TouchableOpacity>
							);
						})}
				</ScrollView>
			</ScrollView> */}
		</View>
	);
};

export default forwardRef(GridDetails);
