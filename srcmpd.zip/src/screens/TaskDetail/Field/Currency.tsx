/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useRef, useState, useEffect, forwardRef, useImperativeHandle } from 'react';

import { Icon } from 'components/Atoms/Icon';
import { COLORS } from 'config/colors';
import { ICONS } from 'config/images';
import useDebounce from 'hooks/useDebounce';
import useSystem from 'hooks/useSystem';
import { View, Text, TouchableOpacity, TextInput } from 'react-native';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateDetails } from 'stores/TaskDetails';
import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';
import { breakExecuteJS, containsAllAlphabets, filterAndRemoveNonAlphabets } from 'utils/functions';
import { translate } from 'utils/translate';
import { vtUtility } from 'vtUtility/vtUtility';

import { IField, OptionField } from './InterfaceField';
import { usePermisstionEdit } from '../useHooks/usePermissionEdit';

const Currency = (
	{ title, options, isGrid, internalName, isRequired, onUpdateValueGrid, itemInfoGrid, isEditGrid, isViewGrid }: IField,
	ref: React.Ref<unknown> | undefined,
) => {
	const dispatch = useAppDispatch();
	const refInput = useRef<TextInput>();
	const isInit = useRef(true);
	const refTimeout = useRef();
	const refValueField = useRef<string>('');
	const { isVN } = useSystem();

	const infoItem = useAppSelector(store => store.workflow.itemInfo);
	const init = useAppSelector(store => store.workflow.init);

	const option: OptionField = JSON.parse(options || '{}');

	const { Require, ExecuteJS, ViewOnly, DisplayFormat, C_Min, C_Max } = option;
	const IsRequire = Require || isRequired;

	const info = isGrid ? itemInfoGrid : infoItem;

	const defaultValue = info?.[internalName] || '';

	const { isPermission } = usePermisstionEdit(!!ViewOnly, internalName);
	const isDisable = isGrid ? !ViewOnly && isEditGrid : isPermission;

	const [isFocus, setIsFocus] = useState(false);
	const [error, setError] = useState(false);
	const [value, setValue] = useState();

	useEffect(() => {
		try {
			const iNotNumber = containsAllAlphabets(defaultValue?.toString());
			if (iNotNumber) {
				const valueRemove = filterAndRemoveNonAlphabets(defaultValue?.toString());
				if (isGrid) {
					onUpdateValueGrid({
						[internalName]: valueRemove,
					});
				} else {
					dispatch(
						updateValueInternalName({
							[internalName]: valueRemove,
						}),
					);
				}
			} else if (ExecuteJS && !isViewGrid) {
				const listExecuteJS = ExecuteJS?.split('vtUtility.')?.filter(elm => elm);
				if (listExecuteJS?.length) {
					listExecuteJS?.forEach(elm => {
						const JS = breakExecuteJS(elm);

						const callFunction = vtUtility[JS.funcName](info, JS.arrExecuteJS, internalName, { isVN, unit: '' });
						if (callFunction) {
							if (isGrid) {
								onUpdateValueGrid(callFunction.value);
							} else {
								dispatch(callFunction.function(callFunction.value));
							}
						}
					});
				}
			}
		} catch (err) {
			console.log('err', err);
			//
		}
	}, [defaultValue]);

	useEffect(() => {
		setValue(info[internalName]);
	}, [info]);

	useEffect(() => {
		if (init) {
			isInit.current = false;
		}
		return () => {
			if (refTimeout.current) {
				clearTimeout(refTimeout.current);
			}
		};
	}, [init]);

	const require = () => {
		if (!isDisable) return true;

		if (IsRequire && !defaultValue) {
			setError(true);
			return false;
		}
		return true;
	};

	useImperativeHandle(
		ref,
		() => ({
			require,
		}),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[defaultValue],
	);

	const convertField = (DisplayFormat: string) => {
		switch (DisplayFormat) {
			case 'FiveDecimals':
				return 5;
			case 'FourDecimals':
				return 4;
			case 'NoDecimal':
				return 0;
			case 'OneDecimal':
				return 1;
			case 'ThreeDecimals':
				return 3;
			case 'TwoDecimals':
				return 2;
			default:
				return 0;
		}
	};

	function numberWithCommas(x: string) {
		if (!x && x !== 0) return '';
		const number = Number(x).toFixed(convertField(DisplayFormat || ''));
		const numberReplace = number.replaceAll('.', ',').replaceAll(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, '.');
		return numberReplace;
	}

	const commas = !value && value == '' && value != 0 ? value : numberWithCommas(value?.toString());

	useEffect(() => {
		refInput.current?.focus();
	}, [isFocus]);

	const onFocus = () => setIsFocus(true);

	const onBlur = () => {
		setIsFocus(false);
		let realValue = value;
		if (C_Min) {
			if (Number(value) < Number(C_Min)) realValue = C_Min;
		}
		if (C_Max) {
			if (Number(value) > Number(C_Max)) realValue = C_Max;
		}

		refTimeout.current = setTimeout(() => {
			if (isGrid) {
				onUpdateValueGrid({
					[internalName]: realValue == '' ? '' : Number(realValue).toFixed(option?.N_Number_Decimal || 0),
				});
			} else {
				dispatch(
					updateValueInternalName({
						[internalName]: realValue == '' ? '' : Number(realValue).toFixed(option?.N_Number_Decimal || 0),
					}),
				);
			}
		}, 100);
	};

	const onPressFocus = () => {
		setIsFocus(true);
	};

	const onChangeText = (text: string) => {
		setError(false);
		const isMax = text?.includes('e+');
		if (isMax) {
			if (text?.length < value?.length) return setValue('');
			return setValue(value);
		}
		const textDot = text.replace(',', '.');

		const arr: any[] = text?.split('.');
		if (arr?.length > 2) {
			setValue(value);
		} else {
			setValue(textDot);
		}
	};

	if (isViewGrid)
		return (
			<View style={{ alignItems: 'center' }}>
				<Text style={{ fontSize: 14, color: '#111' }}>{commas}</Text>
			</View>
		);

	return (
		<View style={{ flexDirection: 'row', marginVertical: 15 }}>
			<Icon src={ICONS.icCurrency} width={18} height={18} />

			<View style={{ marginLeft: 6, flex: 1 }}>
				<Text numberOfLines={1} style={{ color: '#7B7B7B', fontSize: 12, marginBottom: 3 }}>
					{title}
					{IsRequire && isDisable && <Text style={{ color: COLORS.red }}> (*)</Text>}
				</Text>
				{!isDisable ? (
					<Text style={{ fontSize: 14, color: '#111' }}>{commas}</Text>
				) : (
					<>
						<TouchableOpacity
							onPress={onPressFocus}
							activeOpacity={1}
							style={{
								width: '100%',
								borderWidth: 0.8,
								borderRadius: 8,
								paddingHorizontal: 10,
								paddingVertical: 5,
								borderColor:
									error && !value
										? COLORS.red
										: isFocus
											? error && !value
												? COLORS.red
												: '#335FB3'
											: 'rgba(217, 217, 217, 1)',
								height: 38,
								justifyContent: 'center',
							}}>
							{isFocus ? (
								<TextInput
									ref={refInput}
									value={value?.toString()}
									onChangeText={onChangeText}
									onFocus={onFocus}
									onBlur={onBlur}
									keyboardType="numeric"
									returnKeyType="done"
								/>
							) : (
								<Text>{commas}</Text>
							)}
						</TouchableOpacity>
						{error && isDisable && !value && (
							<Text style={{ fontSize: 12, color: COLORS.red, fontStyle: 'italic', marginTop: 2 }}>
								{title}
								{translate('isRequire')}
							</Text>
						)}
					</>
				)}
			</View>
		</View>
	);
};

export default forwardRef(Currency);
