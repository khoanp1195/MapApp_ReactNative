/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable no-return-assign */
/* eslint-disable array-callback-return */
import React, { useState, useEffect, forwardRef, useRef, useImperativeHandle } from 'react';

import { useNavigation, useRoute } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { COLORS, ICONS } from 'config';
import { View, Text, TouchableOpacity, Animated } from 'react-native';
import Swipeable, { SwipeableProps } from 'react-native-gesture-handler/Swipeable';
import { useAppDispatch, useAppSelector } from 'stores';
import { deleteAttachment } from 'stores/TaskDetails';
import { fetchDeleteAttachment } from 'stores/TaskDetails/thunks';

import { IField } from './InterfaceField';
import { usePermisstionAttach, usePermisstionEditAtatch } from '../useHooks/usePermissionEdit';

interface Item {
	ID: string;
	Title: string;
	Name: string;
	AttachTypeId: number;
	Extension: string;
	Size: number;
	Path: string;
	CreatedName: string;
	PositionName: string;
	AttachTypeName: string;
	IsAuthor: number;
	Base64: string;
	isAdd: boolean;
}

// isAddTask add new task
// isTask  is task component

const Attachmets = (
	{ ID, isAddTask, isTask, isDisableAttachment, ListDocumentCategory = [] }: IField,
	ref: React.Ref<unknown> | undefined,
) => {
	const route = useRoute();
	const dispatch = useAppDispatch();
	const navigation = useNavigation();
	const SwipeableRef = useRef<SwipeableProps>();
	const refIDSwip = useRef<string>();
	const { isPermission } = usePermisstionAttach();

	const ListDocumentRequire = route.params?.ListDocumentRq?.length
		? route.params?.ListDocumentRq
		: ListDocumentCategory || [];

	const Require = ListDocumentRequire.find(item => item.Required);

	const isPermissionAdd = isTask ? !isDisableAttachment : isPermission;

	const [acttchs, setAttachs] = useState<Array<Item>>([]);

	const attachmet = useAppSelector(store => store.taskDetails.attachmets);

	const attachmets = isAddTask ? acttchs : attachmet;

	const { isPermissionEdit } = usePermisstionEditAtatch();

	const [indexHide, setIndexHide] = useState<number[]>([]);

	const [list, setList] = useState<Array<any>>([]);
	const [error, setError] = useState([]);

	const getData = () => {
		let noList = [];
		ListDocumentRequire.map(category => {
			const err = attachmet?.find(cate => cate.AttachTypeId === category.ID);
			if (!err) noList = [...noList, category.ID];
		});

		setError(noList);
		if (noList?.length) return null;
		let listConvert: Array<{ Name: string; Base64: string; AttachTypeId: number; AttachTypeName: string }> = [];
		const listAtatch = attachmets?.filter(attachment => !attachment?.ID);
		listAtatch?.map(attachment => {
			listConvert = [
				...listConvert,
				{
					Name: attachment.Title,
					Base64: attachment?.Base64 || attachment?.base64,
					AttachTypeId: attachment.AttachTypeId,
					AttachTypeName: attachment.AttachTypeName,
				},
			];
		});
		return listConvert;
	};

	useImperativeHandle(
		ref,
		() => ({
			getData,
		}),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[attachmets],
	);

	useEffect(() => {
		let typeName: Array<{ type: string; list: Array<any> }> = [];

		attachmets?.map(e => {
			const isType = typeName?.findIndex((item: { type: string }) => item.type === e.AttachTypeName);

			if (isType === -1) {
				typeName = [...typeName, { type: e.AttachTypeName, list: [e], AttachTypeId: e.AttachTypeId }];
			} else {
				typeName[isType].list.push(e);
			}
		});

		let listClone = JSON.parse(JSON.stringify(typeName));

		if (!isTask) {
			ListDocumentRequire.map(item => {
				const index = listClone.findIndex(e => e.AttachTypeId === item.ID);
				if (index === -1) {
					listClone = [
						...listClone,
						{
							type: item.Title,
							list: [
								{
									AttachTypeId: item.ID,
									AttachTypeName: item.Title,
									CreatedName: 'qc.admin4@vuthao.vn',
									PositionName: 'Tổng giám đốc',
								},
							],
							AttachTypeId: item.ID,
						},
					];
				}
			});
		}

		setList(listClone);
	}, [attachmets, ListDocumentRequire]);

	const onHide = (index: number) => {
		const isHide = indexHide.find(e => e === index);
		if (isHide === undefined) {
			setIndexHide(indexHide.concat(index));
			return;
		}

		setIndexHide(indexHide.filter(e => e !== index));
	};

	function formatBytes(bytes: number, decimals = 2) {
		if (!+bytes) return '0 Bytes';

		const k = 1024;
		const dm = decimals < 0 ? 0 : decimals;
		const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

		const i = Math.floor(Math.log(bytes) / Math.log(k));

		return `${parseFloat((bytes / k ** i).toFixed(dm))} ${sizes[i]}`;
	}

	const getIcon = (extension: string) => {
		switch (extension) {
			case 'doc':
				return ICONS.icWord;
			case 'docx':
				return ICONS.icWord;
			case 'xlsx':
				return ICONS.icExel;
			case 'xls':
				return ICONS.icExel;
			case 'pdf':
				return ICONS.icPdf;
			case 'ppt':
				return ICONS.icPp;

			default:
				return ICONS.icAdd;
		}
	};

	const onCallback = (e: Item) => {
		return setAttachs([...acttchs, e]);
	};

	const onSubmitAttach = id => {
		setError(error.filter(err => err !== id));
	};

	const renderRightActions = (
		_progress: Animated.AnimatedInterpolation<string | number>,
		dragX: Animated.AnimatedInterpolation<string | number>,
		x: Item,
		isAuthor: boolean,
	) => {
		if (!isAuthor) return null;

		const transform = dragX.interpolate({
			inputRange: [0, 50, 100, 101],
			outputRange: [0, 0, 0, 1],
		});
		const opacity = dragX.interpolate({
			inputRange: [-150, 0],
			outputRange: [1, 1],
			extrapolate: 'clamp',
		});

		const onDeleteClick = (data: Item) => {
			if (isTask) {
				if (isAddTask) return setAttachs(acttchs?.filter(att => att.Name !== data.Name));
			}
			if (data?.ID) {
				return dispatch(
					fetchDeleteAttachment({
						rid: ID,
						data: {
							ID: data.ID,
							Path: data.Path,
						},
						isTask,
					}),
				);
			}
			return dispatch(
				deleteAttachment({
					Name: data.Name,
				}),
			);
		};

		const onPressEdit = () => {
			SwipeableRef[x.Name]?.close();
			navigation.navigate('EditAttachments', { item: x, ID, type: 'edit', isTask, onCallback, onSubmitAttach });
		};

		const onPressDelete = () => {
			SwipeableRef[x.Name]?.close();
			onDeleteClick(x);
		};

		return (
			<Animated.View style={[{ flexDirection: 'row' }, { opacity, transform: [{ translateX: transform }] }]}>
				{!isTask && (
					<TouchableOpacity
						onPress={onPressEdit}
						style={{ alignItems: 'center', justifyContent: 'center', backgroundColor: '#005FD4', width: 44 }}>
						<Text style={{ color: 'white' }}>Edit</Text>
					</TouchableOpacity>
				)}
				<TouchableOpacity
					onPress={onPressDelete}
					style={{ alignItems: 'center', justifyContent: 'center', backgroundColor: COLORS.red, width: 44 }}>
					<Text style={{ color: 'white' }}>Delete</Text>
				</TouchableOpacity>
			</Animated.View>
		);
	};

	const onPressAdd = () =>
		navigation.navigate('EditAttachments', { ID, type: 'add', isTask, isAddTask, onCallback, onSubmitAttach });

	const onPressOpenFile = item => { };

	return (
		<View style={{}}>
			<View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 }}>
				<Text style={{ color: '#5E5E5E', fontSize: 11, marginBottom: 4 }} numberOfLines={1}>
					Tài liệu đính kèm{!!Require && <Text style={{ color: COLORS.red }}> (*)</Text>}
				</Text>
				{isPermissionAdd && (
					<TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center' }} onPress={onPressAdd}>
						<Icon src={ICONS.icShape} width={17} height={18} style={{ marginRight: 2 }} />
						<Text style={{ color: '#5E5E5E', fontSize: 11, marginBottom: 4 }}>Tạo mới</Text>
					</TouchableOpacity>
				)}
			</View>
			<View style={{}}>
				<View
					style={{
						flexDirection: 'row',
						justifyContent: 'space-between',
						backgroundColor: '#F9F9F9',
						padding: 15,
						borderRadius: 6,
					}}>
					<Text style={{ flex: 1.5, fontSize: 11, fontWeight: '700' }}>Tên tài liệu</Text>
					<Text style={{ flex: 1, fontSize: 11, fontWeight: '700' }}>Người tạo</Text>
				</View>
				<View>
					{list?.map((e: { type: string; list: Array<any>; AttachTypeId: number }, i) => {
						const isHide = indexHide.find(item => item === i);
						return (
							<View
								key={i?.toString()}
								style={{
									marginBottom: 1,
									borderWidth: error.includes(e.AttachTypeId) ? 1 : 0,
									borderColor: COLORS.red,
								}}>
								<TouchableOpacity
									onPress={() => onHide(i)}
									style={{ backgroundColor: '#F5F5F5', padding: 15, flexDirection: 'row', alignItems: 'center' }}>
									<Text style={{ fontSize: 14, fontWeight: '700', color: '#005FD4', marginRight: 10 }}>
										{e?.type || 'Other'} ({e?.list?.length})
									</Text>
									<Icon
										src={isHide === undefined ? ICONS.icArrowDown : ICONS.icArrowRight}
										width={12}
										height={12}
										style={{ marginRight: 10 }}
									/>
								</TouchableOpacity>
								{isHide === undefined &&
									e?.list?.map((x: Item, index: number) => {
										const isAuthor = x?.IsAuthor === 1 && isPermissionEdit;
										return (
											<Swipeable
												ref={ref => (SwipeableRef[x.Name] = ref)}
												onSwipeableOpen={() => (refIDSwip.current = x.Name)}
												onSwipeableWillClose={() => {
													if (refIDSwip.current === x.Name) {
														refIDSwip.current = '';
													}
												}}
												onSwipeableWillOpen={() => SwipeableRef[refIDSwip.current]?.close()}
												key={index?.toString()}
												renderLeftActions={(progress, dragX) => renderRightActions(progress, dragX, x, isAuthor)}
												renderRightActions={(progress, dragX) => renderRightActions(progress, dragX, x, isAuthor)}>
												<View
													style={{
														flexDirection: 'row',
														justifyContent: 'space-between',
														backgroundColor: !(index % 2) ? COLORS.white : '#F3F9FF',
														padding: 15,
													}}>
													<View
														style={{
															flex: 1.5,
															marginRight: 10,
															flexDirection: 'row',
															overflow: 'hidden',
															alignItems: 'flex-start',
														}}>
														<Icon
															src={getIcon(x.Extension)}
															width={24}
															height={24}
															style={{ marginRight: 10 }}
															onPress={onPressAdd}
														/>
														<TouchableOpacity
															style={{ flex: 1 }}
															onPress={() => {
																onPressOpenFile(x);
															}}>
															<Text numberOfLines={1} style={{ color: '#335FB3' }}>
																{x?.Title}
															</Text>
															<Text style={{ color: '#999999', fontSize: 11 }}>
																{x.Size ? formatBytes(x.Size) : ''}
															</Text>
														</TouchableOpacity>
													</View>
													<View style={{ flex: 1 }}>
														<Text style={{ flex: 1 }}>{x?.CreatedName}</Text>
														<Text style={{ flex: 1, color: '#5E5E5E', fontSize: 11 }}>{x?.PositionName}</Text>
													</View>
												</View>
											</Swipeable>
										);
									})}
							</View>
						);
					})}
				</View>
			</View>
		</View>
	);
};

export default forwardRef(Attachmets);
