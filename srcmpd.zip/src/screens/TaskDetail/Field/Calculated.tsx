/* eslint-disable import/no-cycle */
/* eslint-disable @typescript-eslint/no-shadow */
/* eslint-disable no-eval */
/* eslint-disable react-hooks/exhaustive-deps */
import React, { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';

import { Icon } from 'components/Atoms/Icon';
import { ICONS } from 'config/images';
import useSystem from 'hooks/useSystem';
import { View, Text, Alert } from 'react-native';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';
import { breakExecuteJS } from 'utils/functions';
import { VTFomular } from 'vtUtility/vtFomular';
import { vtUtility } from 'vtUtility/vtUtility';

import { IField, OptionField } from './InterfaceField';

const Calculated = (
	{ title, options, internalName, isGrid, isEdited, itemInfoGrid, onUpdateValueGrid, isViewGrid }: IField,
	ref: React.Ref<unknown> | undefined,
) => {
	const dispatch = useAppDispatch();
	const option: OptionField = JSON.parse(options || '{}');
	const isInit = useRef(true);
	const init = useAppSelector(store => store.workflow.init);
	const { isVN } = useSystem();

	const refDefaultValue = useRef<string | number>('');
	const refValueChange = useRef<{ name: string; value: number }[]>([]);

	const infoItem = useAppSelector(store => store.workflow.itemInfo);
	const info = (isGrid ? itemInfoGrid : infoItem) || {};

	const defaultValue = info?.[internalName] || '';

	const formula = option?.C_Formula || option?.Formula || '';

	const OutputType = option?.OutputType;
	const isNumber = OutputType === 'Number' || option?.C_Number || OutputType === 'Currency' || option?.C_Currency;

	const NumberDecimal = option?.N_Number_Decimal || 0;

	const regex = (parsedFormula: string) => {
		const string = parsedFormula.replace(/(])(\s|)(\=)+/g, ']==');
		const regexForm = /\[(\d|\w|\.|_)+\]/g;
		const ArrayFieldInFormula: string[] = string.match(regexForm) || [];
		return ArrayFieldInFormula;
	};

	const convert = () => {
		let valueArrName: any[] = [];
		const arrName = regex(formula);
		arrName?.forEach(elm => {
			const rpElm = elm.replace('[', '').replace(']', '');
			const checkKey = Object.keys(info)?.findIndex(e => e === rpElm);
			if (checkKey !== -1) {
				const value = info?.[rpElm];
				const objValue = { value, name: elm };
				valueArrName = [...valueArrName, objValue];
			}
		});

		let converFomular = formula?.replace('=', '');
		valueArrName?.forEach((elm: { name: string; value: number }) => {
			converFomular = converFomular.replace(elm?.name, elm?.value || 0);
		});

		refValueChange.current = valueArrName;
		return converFomular;
	};

	const checkChangeValue = () => {
		let changed = false;
		if (!refValueChange.current?.length) return true;
		refValueChange.current.forEach((elm: { name: string; value: number }) => {
			const rpElm = elm?.name?.replace('[', '').replace(']', '');
			const isChanged = elm?.value?.toString() === info?.[rpElm]?.toString();
			if (!isChanged) changed = true;
		});
		return changed;
	};

	const replaceNameFunction = (input: string, conditionArray: string[]) => {
		conditionArray.forEach(elm => {
			const condition = elm;
			const regexUpperCase = new RegExp(condition, 'g');
			const regexLowerCase = new RegExp(condition.toLocaleLowerCase(), 'g');
			input = input.replace(regexUpperCase, `vtFomular.${condition}`).replace(regexLowerCase, `vtFomular.${condition}`);
		});
		return input;
	};

	useEffect(() => {
		try {
			refDefaultValue.current = info?.[internalName] || '';
			const isRunUseEffect = checkChangeValue();
			if (Object.keys(info)?.length && isRunUseEffect) {
				const vtFomular = VTFomular;

				const valueConvert = convert()?.replaceAll('^', '**');

				const valueString = replaceNameFunction(valueConvert, Object.keys(vtFomular));

				if (valueString && !regex(valueString)?.length) {
					let valueField = isNumber ? 0 : '';

					const dynamicFunction = new Function('vtFomular', `return ${valueString}`);

					const valueDynamic = dynamicFunction(vtFomular);
					if (valueDynamic || valueDynamic === 0) {
						valueField = valueDynamic;
					} else {
						valueField = valueConvert;
					}

					const value = valueField?.toString() === 'Infinity' ? 0 : valueField;
					const valueCalculated = typeof value === 'string' ? value || '' : Number(value).toFixed(NumberDecimal) || 0;
					if (refDefaultValue.current !== valueCalculated) {
						refDefaultValue.current = valueCalculated;
						if (isGrid && onUpdateValueGrid) {
							onUpdateValueGrid({
								[internalName]: valueCalculated,
							});
						} else {
							dispatch(
								updateValueInternalName({
									[internalName]: valueCalculated,
								}),
							);
						}
					}
				}
			}
		} catch (error) {
			console.log('error', error);
		}
	}, [info]);

	const ExecuteJS = option?.ExecuteJS;

	useEffect(() => {
		try {
			if (ExecuteJS && !isInit.current && !isViewGrid) {
				const listExecuteJS = ExecuteJS?.split('vtUtility.')?.filter(elm => elm);
				if (listExecuteJS?.length) {
					listExecuteJS?.forEach(elm => {
						const JS = breakExecuteJS(elm);
						const callFunction = vtUtility[JS.funcName](info, JS.arrExecuteJS, internalName, { isVN, unit: '' });
						if (callFunction) {
							if (isGrid && onUpdateValueGrid) {
								onUpdateValueGrid(callFunction.value);
							} else {
								dispatch(callFunction.function(callFunction.value));
							}
						}
					});
				}
			}
		} catch (error) {
			//
		}
	}, [defaultValue]);

	useEffect(() => {
		if (init) {
			isInit.current = false;
		}
	}, [init]);

	const getData = () => {
		if (isEdited) return { value: '0' };
		return { value: '0' };
	};
	const checkRequire = () => {
		return true;
	};

	useImperativeHandle(
		ref,
		() => ({
			getData,
			require: checkRequire,
		}),
		[],
	);

	function numberWithCommas(x: string) {
		if (!x) return '';
		const number = Number(x).toFixed();
		const numberReplace = number.replaceAll('.', ',').replaceAll(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, '.');
		return numberReplace;
	}

	const convertValueCalculated = () => {
		if (typeof defaultValue === 'string') {
			const value = defaultValue?.includes(';#') ? defaultValue?.split(';#')?.[1] : defaultValue;
			if (isNumber) {
				const valueNumber = numberWithCommas(value) || 0;
				return valueNumber;
			}
			return value || '';
		}
		if (isNumber) {
			const valueNumber = numberWithCommas(defaultValue) || 0;
			return valueNumber;
		}
		return defaultValue || '';
	};

	const valueCalculated = convertValueCalculated();

	if (isViewGrid)
		return (
			<View style={{ alignItems: 'center' }}>
				<Text style={{ fontSize: 14, color: '#111' }}>{valueCalculated}</Text>
			</View>
		);

	return (
		<View style={{ flexDirection: 'row', marginVertical: 15 }}>
			<Icon src={ICONS.icCalculator} width={18} height={18} />

			<View style={{ marginLeft: 6 }}>
				<Text numberOfLines={1} style={{ color: '#7B7B7B', fontSize: 12, marginBottom: 3 }}>
					{title}
				</Text>
				<Text style={{ fontSize: 14, color: '#111' }}>{valueCalculated}</Text>
			</View>
		</View>
	);
};

export default forwardRef(Calculated);
