/* eslint-disable no-inner-declarations */
/* eslint-disable eqeqeq */
/* eslint-disable array-callback-return */
/* eslint-disable react-hooks/exhaustive-deps */

import React, { forwardRef, useEffect, useRef, useState, useImperativeHandle } from 'react';

import { Icon } from 'components/Atoms/Icon';
import { BoxUser } from 'components/WorkflowDetails/Modal/ModalAction';
import { COLORS, ICONS } from 'config';
import { View, Text } from 'react-native';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';
import { translate } from 'utils/translate';
import { vtUtility } from 'vtUtility/vtUtility';

import { IField, OptionField } from './InterfaceField';
import ModalLookup from './ModalLookup';
import { usePermisstionEdit } from '../useHooks/usePermissionEdit';

const Lookup = (
	{
		title = '',
		options,
		internalName,
		Guid,
		isGrid,
		isRequired,
		FieldInfo,
		index,
		onUpdateValueGrid,
		itemInfoGrid,
		isEditGrid,
		isViewGrid,
	}: IField,
	ref: React.Ref<unknown> | undefined,
) => {
	const dispatch = useAppDispatch();

	const infoItem = useAppSelector(store => store.workflow.itemInfo);
	const info = isGrid ? itemInfoGrid : infoItem;

	const defaultValue = info?.[internalName] || '';

	const isInit = useRef(true);

	const option: OptionField = JSON.parse(options || '{}');
	const Require = option?.Require || isRequired;
	const ExecuteJS = option?.ExecuteJS;
	const ViewOnly = !!option?.ViewOnly;

	const { isPermission } = usePermisstionEdit(ViewOnly, internalName);
	const isDisable = isGrid ? !ViewOnly && isEditGrid : isPermission;

	const isMultiple = option?.L_Allow_Multiple;

	const KeyFeild = option?.L_Fields || 'Title';

	const init = useAppSelector(store => store.workflow.init);

	const [choices, setChoices] = useState<Array<number | string>>();
	const [error, setError] = useState(false);

	const convertJS = (inputString: string) => {
		const regex = /([\w.]+)\((.*?)\)/;
		const matches = inputString?.replaceAll(' ', '').match(regex);
		if (matches) {
			const functionName = matches[1].replace('vtUtility.', '');
			const parameters = matches[2];

			// Tạo mảng kết quả
			const resultArray = [functionName, parameters];
			return resultArray;
		}
		return null;
	};
	useEffect(() => {
		try {
			if (defaultValue) {
				setError(false);
			}
			if (ExecuteJS && !isInit.current && !isViewGrid) {
				// const listExecuteJS = ExecuteJS?.split(';')?.filter(elm => elm !== ' ');
				const listExecuteJS = ExecuteJS?.split('vtUtility.')?.filter(elm => elm);

				async function handleAsync(funcName: string, arrExecuteJS: string[]) {
					const isUserGroup = false;
					const callFunction = await vtUtility[funcName](choices, arrExecuteJS, isUserGroup);
					if (callFunction) {
						if (isGrid) {
							onUpdateValueGrid({ ...callFunction.value });
						} else {
							dispatch(callFunction.function({ ...callFunction.value }));
						}
					}
				}

				listExecuteJS.forEach(elm => {
					const arrExecuteJS = convertJS(elm);
					if (arrExecuteJS) {
						const funcName = arrExecuteJS[0] as 'IFunction';

						if (funcName === 'setUserManagerToControl') {
							handleAsync(funcName, arrExecuteJS);
						} else {
							let FieldInfoClone = {};
							FieldInfo?.forEach((element: { Name: any }) => {
								FieldInfoClone = {
									...FieldInfoClone,
									...{ [element.Name]: element },
								};
							});

							const callFunction = vtUtility[funcName](choices, arrExecuteJS, FieldInfoClone);
							if (callFunction) {
								if (isGrid) {
									onUpdateValueGrid(callFunction.value);
								} else {
									dispatch(callFunction.function(callFunction.value));
								}
							}
						}
					}
				});
			}
		} catch (error) {
			//
		}
	}, [defaultValue, FieldInfo, choices]);

	useEffect(() => {
		if (init) {
			isInit.current = false;
		}
	}, [init]);

	// case change position choices

	const checkRequire = () => {
		if (!isDisable) return true;

		if (Require && !defaultValue) {
			setError(true);
			return false;
		}
		return true;
	};

	useImperativeHandle(
		ref,
		() => ({
			require: checkRequire,
		}),
		[defaultValue],
	);

	const convertList = () => {
		try {
			const clone: any[] = defaultValue?.split(';#')?.filter((item: string) => item !== '') || [];
			if (!clone?.length) return [];

			let listID: any[] = [];
			let listName: any[] = [];
			clone?.forEach((item, index) => {
				if (index % 2 !== 0) {
					listName = [...listName, item];
				} else {
					listID = [...listID, item];
				}
			});

			let list: any[] = [];
			listID.forEach((item, index) => {
				list = [...list, { ID: Number(item), [KeyFeild]: listName?.[index] || '' }];
			});
			return list;
		} catch (error) { }
	};

	const listData = convertList();

	const contentValue = listData?.map(elm => {
		return elm?.[KeyFeild];
	});

	const refModal = useRef();

	const searchUser = () => {
		refModal.current?.show(listData);
	};

	const onSubmitUser = (data: any[]) => {
		console.log('data', data);
		try {
			setError(false);
			setChoices(data);
			let value = '';
			data.map(item => {
				const name = item?.[KeyFeild] || '';
				value = value.concat(`;#${item?.ID};#${name || ''}`);
			});
			if (isGrid) {
				onUpdateValueGrid({ [internalName]: value });
			} else {
				dispatch(
					updateValueInternalName({
						[internalName]: value,
					}),
				);
			}
		} catch (error) { }
	};

	if (isViewGrid)
		return (
			<View style={{ alignItems: 'center' }}>
				<Text style={{ fontSize: 14, color: '#111' }}>{contentValue?.toString()?.replaceAll(',', ', ')}</Text>
			</View>
		);

	return (
		<View style={{ flexDirection: 'row', marginVertical: 15 }}>
			<Icon src={isDisable ? ICONS.icTable : ICONS.icChoiceField} width={18} height={18} />

			<View style={{ marginLeft: 6, flex: 1 }}>
				<Text style={{ color: '#5E5E5E', fontSize: 11, marginBottom: 4 }}>
					{title}
					{Require && isDisable && <Text style={{ color: COLORS.red }}> (*)</Text>}
				</Text>
				{!isDisable ? (
					<Text style={{ fontSize: 14, color: '#111' }}>{contentValue?.toString()?.replaceAll(',', ', ')}</Text>
				) : (
					<>
						<BoxUser
							err={error}
							user={listData}
							setUser={onSubmitUser}
							icon={ICONS.icChevronDown}
							index={index}
							searchUser={searchUser}
							KeyFeild={KeyFeild}
							fullText
						/>
						{error && isDisable && (
							<Text style={{ fontSize: 12, color: COLORS.red, fontStyle: 'italic', marginTop: 2 }}>
								{title}
								{translate('isRequire')}
							</Text>
						)}
					</>
				)}
			</View>
			<ModalLookup
				ref={refModal}
				options={options}
				Guid={Guid}
				title={title}
				onSubmitUser={onSubmitUser}
				isMultiple={isMultiple}
				KeyFeild={KeyFeild}
			/>
		</View>
	);
};

export default forwardRef(Lookup);
