import React, { forwardRef, useImperativeHandle, useRef, useState } from 'react';

import ModalRef from 'components/Molecules/Modal/ModalRef';
import { Dimensions, View, Text } from 'react-native';

import SearchUser from '../screens/SearchUser';

const ModalUserGroup = ({ RID, onSubmitUser, isMultiple, type, title }, ref) => {
	const refModal = useRef();
	const [user, setUser] = useState([]);
	const windowHeight = Dimensions.get('window').height;

	const show = (user = []) => {
		setUser(user);
		refModal.current?.show();
	};
	const hide = () => {
		refModal.current?.hide();
	};

	useImperativeHandle(
		ref,
		() => ({
			show,
			hide,
		}),
		[],
	);

	const options = {
		isMultiple,
		type,
		isAddInfo: false,
		user,
	};

	const paramsProps = {
		options,
		RID,
	};

	const onSelectUser = user => {
		setUser(user);
		hide();
	};

	const onHide = () => {
		onSubmitUser(user);
	};

	return (
		<ModalRef
			ref={refModal}
			onHide={onHide}
			outsideClickCloseable
			onClose={hide}
			visiblePosition="bottom"
			isTouch={false}
			avoidKeyboard={false}>
			<View
				style={{
					height: windowHeight * 0.9,
					backgroundColor: 'white',
					borderTopEndRadius: 8,
					borderTopStartRadius: 8,
					overflow: 'hidden',
				}}>
				{/* <View style={{ marginTop: 20 }} /> */}
				<View style={{ padding: 20 }}>
					<Text style={{ fontSize: 14, fontWeight: '700' }}>{title}</Text>
				</View>
				<SearchUser userProps={user} paramsProps={paramsProps} isComponent onSelectUser={onSelectUser} isField />
			</View>
		</ModalRef>
	);
};

export default forwardRef(ModalUserGroup);
