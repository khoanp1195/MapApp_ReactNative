import { ENDPOINT } from 'http/modules';

import React, { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';

import { Icon } from 'components/Atoms/Icon';
import ModalRef from 'components/Molecules/Modal/ModalRef';
import { ICONS } from 'config/images';
import useInfinity from 'hooks/useInfinity';
import { View, Text, TouchableOpacity, Dimensions } from 'react-native';
import { FlatList } from 'react-native-gesture-handler';
import { useAppDispatch, useAppSelector } from 'stores';
import { fetchLookup } from 'stores/TaskDetails/thunks';
import { getListLookup } from 'stores/Workflows/sliceWorkflow';
import { translate } from 'utils/translate';

const ModalLookup = ({ options, title = '', onSubmitUser, isMultiple, KeyFeild }, ref) => {
	const dispatch = useAppDispatch();
	const refModal = useRef();
	const [select, setSelect] = useState([]);
	const [keyword, setKeyWord] = useState('');
	const [open, setOpen] = useState(false);
	const refPagingInfo = useRef(null);
	const refSubmit = useRef(false);
	const windowHeight = Dimensions.get('window').height;

	const [data, setData] = useState([]);

	const getSuccess = res => {
		setData([...data, ...res.data.Data]);
		refPagingInfo.current = res.data.PagingInfo;
	};

	const show = (data = []) => {
		setOpen(true);
		setSelect(data);
		dispatch(
			getListLookup({
				params: {
					options,
					keyword,
					PagingInfo: null,
				},
				success: getSuccess,
			}),
		);
		refModal.current?.show();
	};
	const hide = () => {
		setOpen(false);
		refPagingInfo.current = null;
		setData([]);
		refModal.current?.hide();
	};

	useImperativeHandle(
		ref,
		() => ({
			show,
			hide,
		}),
		[],
	);

	useEffect(() => {
		// if (!choices?.length && !dataUser?.length && choices !== null && keyword?.length > 2) {
		if (open) {
			dispatch(
				getListLookup({
					params: {
						options,
						keyword,
						PagingInfo: null,
					},
					success: getSuccess,
				}),
			);
		}
		// }
	}, [keyword]);

	const onSelectUser = user => {
		setUser(user);
		hide();
	};

	const onHide = () => {
		if (refSubmit.current) {
			refSubmit.current = false;
			onSubmitUser(select);
		}
	};

	const onEndReachedHandler = () => {
		if (refPagingInfo.current && open) {
			dispatch(
				getListLookup({
					params: {
						options,
						keyword,
						PagingInfo: refPagingInfo.current,
					},
					success: getSuccess,
				}),
			);
		}
	};

	return (
		<ModalRef
			ref={refModal}
			onHide={onHide}
			outsideClickCloseable
			onClose={hide}
			visiblePosition="bottom"
			isTouch={false}>
			<View
				style={{
					height: windowHeight * 0.65,
					backgroundColor: 'white',
					borderTopEndRadius: 8,
					borderTopStartRadius: 8,
					overflow: 'hidden',
				}}>
				<View style={{ padding: 20 }}>
					<Text style={{ fontSize: 14, fontWeight: '700' }}>{title}</Text>
				</View>
				<FlatList
					contentContainerStyle={{ marginHorizontal: 20 }}
					data={data}
					keyExtractor={(item, index) => index?.toString()}
					renderItem={({ item, index }) => {
						const selected = select.find(itemSelect => itemSelect.ID === item.ID);
						const onPress = () => {
							if (isMultiple) {
								if (selected) {
									setSelect(select.filter(itemSelect => itemSelect.ID !== item.ID));
								} else {
									setSelect([...select, item]);
								}
							} else {
								setSelect([item]);
								refSubmit.current = true;
								hide();
							}
						};
						return (
							<TouchableOpacity
								onPress={onPress}
								style={{
									paddingVertical: 15,
									borderRadius: 10,
									flexDirection: 'row',
									alignItems: 'center',
								}}>
								<Icon src={selected ? ICONS.icCheckUser : ICONS.icUnCheckUser} width={20} height={20} />
								<Text numberOfLines={1} style={{ textAlign: 'left', fontWeight: '500', paddingHorizontal: 12 }}>
									{item?.[KeyFeild] || ''}
								</Text>
							</TouchableOpacity>
						);
					}}
					onEndReachedThreshold={0.1}
					onEndReached={onEndReachedHandler}
				/>
				{isMultiple && (
					<View style={{ width: '100%', marginBottom: 20 }}>
						<TouchableOpacity
							onPress={() => {
								refSubmit.current = true;
								hide();
							}}
							style={{
								backgroundColor: 'rgba(0, 95, 212, 1)',
								paddingVertical: 16,
								alignItems: 'center',
								borderRadius: 12,
								marginHorizontal: 20,
							}}>
							<Text style={{ color: 'white', fontSize: 16, fontWeight: '600' }}>{translate('save')}</Text>
						</TouchableOpacity>
					</View>
				)}
			</View>
		</ModalRef>
	);
};

export default forwardRef(ModalLookup);
