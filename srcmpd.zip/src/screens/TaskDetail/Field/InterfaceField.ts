import { IItemParams } from 'screens/WorkflowDetails/WorkflowDetails';
import { IItemInfo } from 'stores/Workflows/types';

import { FormsParams, ItemParams } from '..';

/* eslint-disable @typescript-eslint/no-explicit-any */
export interface IField {
	title?: string | number | never[] | undefined;
	defaultValue?: string;
	options?: string;
	internalName: string;
	numberField?: number;
	isEnable?: boolean;
	ID?: number;
	SPItemId?: string | number;
	listCatulated?: Array<string>;
	isGrid?: boolean;
	editDetailsGrid?: (e: any) => void;
	isEdited?: boolean;
	FieldInfo?: any;
	sendCaculated?: () => void;
	forms?: FormsParams | any;
	refreshing?: boolean;
	Guid?: string;
	isRequired?: boolean;
	isAddTask?: boolean;
	isTask?: boolean;
	isDisableAttachment?: boolean;
	isDate?: boolean;
	onUpdateValueGrid?: (value: any) => void;
	itemInfoGrid?: IItemInfo;
	isEditGrid?: boolean;
	isAddWorkflow?: boolean;
	itemPrams?: ItemParams | IItemParams;
	index?: number;
	isViewGrid?: boolean;
}

export interface OptionField {
	ViewOnly: boolean;
	TypeCustom: string;
	Choices: Array<string>;
	DateOnly: boolean;
	PeopleOnly: boolean;
	U_Allow_Multiple_Yes: boolean;
	C_Choice_Type: string;
	C_Choice_Value: string;
	DisplayFormat: string;
	C_Formula: string;
	Formula: string;
	L_Allow_Multiple: boolean;
	L_Fields: string;
	D_DateOnly: string;
	D_DateView: string;
	ExecuteJS: string;
	Require: boolean;
	M_PlainText: boolean;
	Description: string;
	U_PeopleOnly: boolean;
	OutputType: any;
	C_Number: string;
	N_Number_Decimal: number;
	C_Currency: boolean;
}
