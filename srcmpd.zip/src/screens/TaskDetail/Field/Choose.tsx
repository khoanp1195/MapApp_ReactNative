/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable no-case-declarations */
/* eslint-disable @typescript-eslint/no-use-before-define */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import React, { useEffect, useState, useRef, forwardRef, useImperativeHandle } from 'react';

import { Icon } from 'components/Atoms/Icon';
import { BoxUser } from 'components/WorkflowDetails/Modal/ModalAction';
import { COLORS } from 'config';
import { ICONS } from 'config/images';
import { View, Text, StyleSheet } from 'react-native';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';
import { breakExecuteJS } from 'utils/functions';
import { translate } from 'utils/translate';
import { vtUtility } from 'vtUtility/vtUtility';

import { IField, OptionField } from './InterfaceField';
import ModalChoose from './ModalChoose';
import { usePermisstionEdit } from '../useHooks/usePermissionEdit';

const CHECKBOXES = 'Checkboxes';
const DROPDOWN = 'DropDown';
const MULTISELECT = 'MultiSelect';
const RADIO = 'Radio';

const Choose = (
	{
		title,
		options,
		internalName,
		isGrid,
		isRequired,
		index,
		onUpdateValueGrid,
		itemInfoGrid,
		isEditGrid,
		isAddWorkflow,
		isViewGrid,
	}: IField,
	ref: React.Ref<unknown> | undefined,
) => {
	const dispatch = useAppDispatch();
	const isInit = useRef(true);
	const refModal = useRef();

	const infoItem = useAppSelector(store => store.workflow.itemInfo);
	const init = useAppSelector(store => store.workflow.init);

	const [error, setError] = useState(false);
	const info = isGrid ? itemInfoGrid : infoItem;
	const option: OptionField = JSON.parse(options || '{}');
	const { Require, ViewOnly } = option;

	const defaultValue: string = info?.[internalName] || '';

	const IsRequire = Require || isRequired;
	const { isPermission } = usePermisstionEdit(!!ViewOnly, internalName);
	const isDisable = isGrid ? !ViewOnly && isEditGrid : isPermission;

	const ExecuteJS = option?.ExecuteJS || option?.Description;

	const type = option?.TypeCustom || option?.C_Choice_Type;

	const isMultiple = [CHECKBOXES, MULTISELECT].includes(type);

	// ExecuteJS: "vtUtility.onVisibleRowByValue(that, "Option 1","FieldYesNo;FieldLookup");"

	useEffect(() => {
		try {
			if (!defaultValue && isInit.current && isDisable) {
				if (isGrid && onUpdateValueGrid) {
					onUpdateValueGrid({ [internalName]: option?.C_Default_Value });
				} else {
					dispatch(
						updateValueInternalName({
							[internalName]: option?.C_Default_Value,
						}),
					);
				}
			}
		} catch (error) { }
	}, [option?.C_Default_Value, defaultValue]);

	useEffect(() => {
		if (defaultValue) {
			setError(false);
		}
		try {
			if (ExecuteJS) {
				const listExecuteJS = ExecuteJS?.split('vtUtility.')?.filter(elm => elm);
				if (listExecuteJS?.length) {
					listExecuteJS?.forEach(elm => {
						const JS = breakExecuteJS(elm);
						const callFunction = vtUtility?.[JS.funcName](info, JS.arrExecuteJS, internalName);
						if (callFunction) {
							if (isGrid) {
								// onUpdateValueGrid();
							} else {
								dispatch(callFunction.function(callFunction));
							}
						}
					});
				}
			}
		} catch (error) { }
	}, [defaultValue]);

	useEffect(() => {
		if (init) {
			isInit.current = false;
		}
	}, [init]);

	const require = () => {
		if (!isDisable) return true;

		if (IsRequire && !defaultValue) {
			setError(true);
			return false;
		}
		return true;
	};

	useImperativeHandle(
		ref,
		() => ({
			require,
		}),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[defaultValue],
	);

	const listDefault = defaultValue ? defaultValue?.split(';#')?.filter(item => item !== '') : [];

	const searchUser = () => {
		refModal.current?.show(listDefault);
	};

	const onSubmitUser = (data: string) => {
		if (!error) {
			setError(false);
		}
		const clone = data.toString().replaceAll(',', ';#');
		if (isGrid) {
			onUpdateValueGrid({ [internalName]: clone });
		} else {
			dispatch(
				updateValueInternalName({
					[internalName]: clone,
				}),
			);
		}
	};

	if (isViewGrid)
		return (
			<View style={{ alignItems: 'center' }}>
				<Text style={styles.title}>{listDefault?.toString()}</Text>
			</View>
		);

	return (
		<View style={{ flexDirection: 'row', marginVertical: 15 }}>
			<Icon src={ICONS.icChoiceField} width={18} height={18} />
			<View style={{ marginLeft: 6, flex: 1 }}>
				<Text style={styles.titleContaier}>
					{title}
					{IsRequire && isDisable && <Text style={{ color: COLORS.red }}> (*)</Text>}
				</Text>
				{!isDisable ? (
					<Text style={styles.title}>{listDefault?.toString()}</Text>
				) : (
					<>
						<BoxUser
							err={error}
							user={listDefault}
							setUser={onSubmitUser}
							icon={ICONS.icChevronDown}
							searchUser={searchUser}
							index={index}
							fullText
						/>
						{error && isDisable && (
							<Text style={{ fontSize: 12, color: COLORS.red, fontStyle: 'italic', marginTop: 2 }}>
								{title}
								{translate('isRequire')}
							</Text>
						)}
					</>
				)}
			</View>

			<ModalChoose
				ref={refModal}
				title={title}
				option={option}
				onSubmitUser={onSubmitUser}
				isMultiple={isMultiple}
				internalName={internalName}
				isGrid={isGrid}
			/>
		</View>
	);
};

export default forwardRef(Choose);

const styles = StyleSheet.create({
	containerCheckBox: { flexDirection: 'row', flexWrap: 'wrap', padding: 2 },
	itemCheckBox: { flexDirection: 'row', marginRight: 20 },
	checkBox: { width: 16, height: 16 },
	nameCheckBox: { fontSize: 14, color: COLORS.black, marginLeft: 4 },
	title: { fontSize: 14, color: '#111' },
	rowStyle: { backgroundColor: COLORS.white, height: 36 },
	rowTextStyle: { backgroundColor: COLORS.white },
	dropdownStyle: { backgroundColor: COLORS.white, borderRadius: 4 },
	buttonStyle: {
		height: 30,
		width: '100%',
		borderColor: '#E5E5E5',
		borderWidth: 0.8,
		alignItems: 'center',
		borderRadius: 4,
		backgroundColor: COLORS.white,
	},
	buttonTextStyle: { color: COLORS.black, fontSize: 14, textAlign: 'left' },
	multiSelect: {
		minHeight: 28,
		// borderBottomColor: 'gray',
		borderWidth: 0.8,
		width: '100%',
		paddingHorizontal: 10,
		borderRadius: 4,
		borderColor: '#E5E5E5',
	},
	viewItemMulti: {
		paddingHorizontal: 15,
		paddingVertical: 5,
	},
	containerRadio: {
		flexDirection: 'row',
		marginRight: 20,
		flexWrap: 'wrap',
		overflow: 'hidden',
	},
	buttonRadio: {
		flexDirection: 'row',
		marginRight: 20,
		padding: 5,
	},
	viewRadio: {
		width: 18,
		height: 18,
		borderWidth: 1,
		borderRadius: 10,

		alignItems: 'center',
		justifyContent: 'center',
	},
	checked: { backgroundColor: COLORS.blueMain, width: 9, height: 9, borderRadius: 9 },
	viewMulti: {
		paddingVertical: 5,
		width: '90%',
		flexDirection: 'row',
		alignItems: 'center',
		zIndex: 1,
		overflow: 'hidden',
		flexWrap: 'wrap',
	},
	titleContaier: { color: '#7B7B7B', fontSize: 12, marginBottom: 4 },
});
