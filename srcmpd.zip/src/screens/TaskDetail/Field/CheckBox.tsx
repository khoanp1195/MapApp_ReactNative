import React from 'react';

import { View, Text } from 'react-native';

import { IField } from './InterfaceField';

const CheckBox = ({ title, defaultValue }: IField) => {
	return (
		<View style={{}}>
			<Text style={{ color: '#5E5E5E', fontSize: 11, marginBottom: 4 }}>CHECKBOX{title}</Text>
			<Text style={{ fontSize: 14, color: '#335FB3' }}>{defaultValue?.split('#')?.[1]}</Text>
		</View>
	);
};

export default CheckBox;
