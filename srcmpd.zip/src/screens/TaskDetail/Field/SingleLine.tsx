/* eslint-disable @typescript-eslint/no-use-before-define */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react-hooks/exhaustive-deps */
import React, { useRef, useState, useEffect, forwardRef, useImperativeHandle, memo } from 'react';

import { Icon } from 'components/Atoms/Icon';
import { COLORS } from 'config/colors';
import { ICONS } from 'config/images';
import { View, Text, TextInput, StyleSheet } from 'react-native';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';
import { breakExecuteJS } from 'utils/functions';
import { translate } from 'utils/translate';
import { vtUtility } from 'vtUtility/vtUtility';

import { IField, OptionField } from './InterfaceField';
import { usePermisstionEdit } from '../useHooks/usePermissionEdit';

const SingleLine = (
	{
		title,
		options,
		internalName = '',
		isGrid,
		isRequired,
		itemInfoGrid,
		onUpdateValueGrid,
		isEditGrid,
		isViewGrid = false,
	}: IField,
	ref: React.Ref<unknown> | undefined,
) => {
	const dispatch = useAppDispatch();
	const isInit = useRef(true);
	const refValueField = useRef<string>('');
	const refInput = useRef<TextInput>(null);
	const refTimeout = useRef();

	const { itemInfo, init } = useAppSelector(store => store.workflow);
	const info = isGrid ? itemInfoGrid : itemInfo;
	const defaultValue = info?.[internalName] || '';

	const option: OptionField = JSON.parse(options || '{}');

	const { Require, ViewOnly, ExecuteJS } = option;

	const IsRequire = Require || !!isRequired;

	const { isPermission } = usePermisstionEdit(!!ViewOnly, internalName);
	const isDisable = isGrid ? !ViewOnly && isEditGrid : isPermission;

	const [isFocus, setIsFocus] = useState(false);
	const [error, setError] = useState(false);

	useEffect(() => {
		try {
			refValueField.current = defaultValue;
			if (ExecuteJS && !isInit.current && !isViewGrid) {
				const listExecuteJS = ExecuteJS?.split('vtUtility.')?.filter(elm => elm);
				if (listExecuteJS?.length) {
					listExecuteJS?.forEach(elm => {
						const JS = breakExecuteJS(elm);
						const callFunction = vtUtility?.[JS.funcName](info, JS.arrExecuteJS);
						if (callFunction) {
							if (isGrid) {
								onUpdateValueGrid(callFunction.value);
							} else {
								dispatch(callFunction.function(callFunction.value));
							}
						}
					});
				}
			}
		} catch (err) {
			//
		}
	}, [defaultValue]);

	useEffect(() => {
		if (init) {
			isInit.current = false;
		}
		return () => {
			if (refTimeout.current) {
				clearTimeout(refTimeout.current);
			}
		};
	}, [init]);

	const require = () => {
		if (!isDisable) return true;
		if (!!IsRequire && !defaultValue) {
			setError(true);
			return false;
		}
		return true;
	};

	useImperativeHandle(
		ref,
		() => ({
			require,
		}),
		[defaultValue],
	);

	const onFocus = () => setIsFocus(true);

	const onBlur = () => {
		setIsFocus(false);
		refTimeout.current = setTimeout(() => {
			if (refValueField.current !== defaultValue) {
				isInit.current = false;
				if (isGrid) {
					onUpdateValueGrid({ [internalName]: refValueField.current });
				} else {
					dispatch(
						updateValueInternalName({
							[internalName]: refValueField.current,
						}),
					);
				}
			}
		}, 100);
	};

	const onChangeText = (text: string) => {
		setError(false);
		refValueField.current = text;
	};
	if (isViewGrid)
		return (
			<View style={{ alignItems: 'center' }}>
				<Text style={styles.value}>{defaultValue}</Text>
			</View>
		);

	return (
		<View style={styles.container}>
			<Icon src={ICONS.icSubject} width={18} height={18} />
			<View style={styles.body}>
				<View style={styles.vTitle}>
					<Text style={styles.title}>
						{title}
						{IsRequire && isDisable && <Text style={{ color: COLORS.red }}> (*)</Text>}
					</Text>
				</View>
				{!isDisable ? (
					<Text style={styles.value}>{defaultValue}</Text>
				) : (
					<TextInput
						ref={refInput}
						defaultValue={defaultValue?.toString()}
						onChangeText={onChangeText}
						onFocus={onFocus}
						onBlur={onBlur}
						returnKeyType="done"
						style={[
							styles.input,
							{
								borderColor: error
									? COLORS.red
									: isFocus
										? !error
											? '#335FB3'
											: COLORS.red
										: 'rgba(217, 217, 217, 1)',
							},
						]}
						maxLength={255}
					/>
				)}
				{error && isDisable && (
					<Text style={styles.rq}>
						{title}
						{translate('isRequire')}
					</Text>
				)}
			</View>
		</View>
	);
};

export default memo(forwardRef(SingleLine));

const styles = StyleSheet.create({
	container: { flexDirection: 'row', marginVertical: 15 },
	body: { marginLeft: 6, flex: 1 },
	title: { color: '#7B7B7B', fontSize: 12, marginBottom: 3, fontWeight: '400' },
	vTitle: { flexDirection: 'row', alignItems: 'center' },
	value: { fontSize: 14, color: '#111', fontWeight: '400' },
	input: {
		borderWidth: 0.8,
		height: 38,
		padding: 10,
		borderRadius: 8,
	},
	rq: { fontSize: 12, color: COLORS.red, fontStyle: 'italic', marginTop: 2 },
});
