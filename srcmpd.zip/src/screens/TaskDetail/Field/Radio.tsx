/* eslint-disable react-hooks/exhaustive-deps */
import React, { forwardRef, useEffect, useState, useImperativeHandle, useRef } from 'react';

import { Icon } from 'components/Atoms/Icon';
import { COLORS } from 'config/colors';
import { ICONS } from 'config/images';
import { View, Text, Switch, TouchableOpacity, LayoutAnimation } from 'react-native';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';
import { breakExecuteJS } from 'utils/functions';
import { translate } from 'utils/translate';
import { vtUtility } from 'vtUtility/vtUtility';

import { IField, OptionField } from './InterfaceField';
import { usePermisstionEdit } from '../useHooks/usePermissionEdit';

const Radio = (
	{ title, options, internalName, isGrid, isRequired, itemInfoGrid, onUpdateValueGrid, isEditGrid, isViewGrid }: IField,
	ref: React.Ref<unknown> | undefined,
) => {
	const dispatch = useAppDispatch();
	const option: OptionField = JSON.parse(options || '{}');
	const Require = option?.Require || isRequired;
	const isInit = useRef(true);
	const ExecuteJS = option?.ExecuteJS;

	const infoItem = useAppSelector(store => store.workflow.itemInfo);
	const info = isGrid ? itemInfoGrid : infoItem;

	const isEnable = info?.[internalName]
		? typeof info?.[internalName] === 'string'
			? info?.[internalName] !== 'False'
			: !!info?.[internalName]
		: false;

	const init = useAppSelector(store => store.workflow.init);

	const ViewOnly = !!option?.ViewOnly;

	const { isPermission } = usePermisstionEdit(ViewOnly, internalName);
	const isDisable = isGrid ? !ViewOnly && isEditGrid : isPermission;

	const checkRequire = () => {
		return true;
	};

	useEffect(() => {
		try {
			if (ExecuteJS && !isViewGrid) {
				const listExecuteJS = ExecuteJS?.split('vtUtility.')?.filter(elm => elm);
				if (listExecuteJS?.length) {
					listExecuteJS?.forEach(elm => {
						const JS = breakExecuteJS(elm);
						const callFunction = vtUtility[JS.funcName](info, JS.arrExecuteJS, internalName);
						if (callFunction) {
							if (isGrid && onUpdateValueGrid) {
								onUpdateValueGrid(callFunction.value);
							} else {
								dispatch(callFunction.function(callFunction.value));
							}
						}
					});
				}
			}
		} catch (error) {
			//
		}
	}, [isEnable]);

	useEffect(() => {
		if (init) {
			isInit.current = false;
		}
	}, [init]);

	useImperativeHandle(
		ref,
		() => ({
			require: checkRequire,
		}),
		[isEnable],
	);

	if (isViewGrid)
		return (
			<View style={{ alignItems: 'center' }}>
				{!!isEnable && <Icon src={ICONS.icCheck} width={16} height={16} tintColor="#000" />}
			</View>
		);

	return (
		<View style={{ flexDirection: 'row', marginVertical: 15 }}>
			<Icon src={ICONS.icYesNo} width={18} height={18} />

			<View style={{ marginLeft: 6 }}>
				<Text style={{ color: '#7B7B7B', fontSize: 12 }} numberOfLines={1}>
					{title}
					{Require && <Text style={{ color: COLORS.red }}> (*)</Text>}
				</Text>
				{/* <TouchableOpacity
					disabled={!isDisable}
					activeOpacity={1}
					onPress={() => {
						setEnabled(!enabled);
						LayoutAnimation.easeInEaseOut();
					}}
					style={{
						flexDirection: 'row',
						width: 75,
						backgroundColor: enabled ? 'rgba(219, 235, 255, 1)' : 'rgba(255, 214, 212, 1)',
						paddingVertical: 4,
						alignItems: 'center',
						justifyContent: 'center',
						borderRadius: 4,
					}}>
					<Icon src={enabled ? ICONS.icYes : ICONS.icNo} width={18} height={18} />
					<Text style={{ color: enabled ? 'rgba(0, 95, 212, 1)' : 'rgba(235, 55, 50, 1)', fontSize: 12 }}>
						{enabled ? 'Có' : 'Không'}
					</Text>
				</TouchableOpacity> */}

				{!isDisable ? (
					<View>
						<Text>{isEnable ? translate('yes') : translate('no')}</Text>
					</View>
				) : (
					<Switch
						disabled={!isDisable}
						trackColor={{ false: '#767577', true: '#005FD4' }}
						thumbColor={isEnable ? 'white' : '#f4f3f4'}
						onValueChange={value => {
							if (isGrid) {
								onUpdateValueGrid({ [internalName]: value });
							} else {
								dispatch(
									updateValueInternalName({
										[internalName]: value,
									}),
								);
							}
						}}
						value={isEnable}
						style={{ transform: [{ scaleX: 0.7 }, { scaleY: 0.7 }] }}
					/>
				)}
			</View>
		</View>
	);
};

export default forwardRef(Radio);
