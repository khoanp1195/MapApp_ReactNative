/* eslint-disable @typescript-eslint/no-use-before-define */
import React, { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';

import { useNavigation } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import ModalTypeDoc from 'components/WorkflowDetails/Attachments/Upload/ModalTypeDoc';
import { COLORS } from 'config/colors';
import { ICONS } from 'config/images';
import useSystem from 'hooks/useSystem';
import { RoutesNames } from 'navigation/RoutesNames';
import { View, Text, FlatList, Platform, TouchableOpacity, StyleSheet, Animated } from 'react-native';
import FileViewer from 'react-native-file-viewer';
import { Swipeable } from 'react-native-gesture-handler';
import { useAppSelector } from 'stores';
import { IAttachments } from 'stores/Workflows/types';
import dayjs from 'utils/dayjs';
import { formatBytes, getIconFile } from 'utils/functions';
import { translate } from 'utils/translate';

const AttachmentField = ({ moreOptionInfo, options }, ref) => {
	const navigation = useNavigation();
	const { formatDateTime } = useSystem();
	const SwipeableRef = useRef();
	const refIDSwip = useRef();
	const refModalType = useRef();

	const [attach, setAttach] = useState([]);
	const details = useAppSelector(store => store.workflow.details);
	const { DefindJsonObj = '{}' } = details?.FormConfig || {};

	const [err, setErr] = useState(false);

	const test = JSON.parse(DefindJsonObj || '{}');

	const ListDocumentCategory = JSON.parse(details?.FormConfig?.ListDocumentCategory || '[]');

	const listDocumentRequire: any[] = ListDocumentCategory?.filter(
		item => item.Step === details.FormConfig.Step && item.Required,
	);
	// ListDocumentCategory.Step === FieldInfo.Step => Yeu cau Attachments Phai co file voi Required: true
	const refListDocRq = useRef([]);

	const require = () => {
		if (!moreOptionInfo?.allowAttach) {
			return true;
		}
		let rq = true;
		listDocumentRequire.forEach(elm => {
			const isPass = attach.find(item => item?.AttachTypeId === elm?.ID);
			if (!isPass) {
				rq = false;

				if (!refListDocRq.current?.includes(elm?.Title)) {
					refListDocRq.current = [...refListDocRq.current, elm?.Title];
				}
			} else {
				refListDocRq.current = refListDocRq.current.filter(e => e !== elm?.Title);
			}
		});
		if (!rq) setErr(true);
		return rq;
	};

	useImperativeHandle(
		ref,
		() => ({
			require,
			getAttach: () => {
				return attach;
			},
		}),
		[attach],
	);

	const { fileExtentions = [], limitWeightAllFiles, limitWeightSingleFile } = moreOptionInfo || {};
	const emptyFileExtentions = fileExtentions?.filter(e => e !== '') || [];
	const option = `${emptyFileExtentions?.length ? `${translate('extension')} ${emptyFileExtentions.toString()}.` : ''}${limitWeightSingleFile ? ` ${translate('maxSizeFile')} ${limitWeightSingleFile}MB.` : ''
		}${limitWeightAllFiles ? ` ${translate('maxAllSizeFile')} ${limitWeightAllFiles}MB` : ''}`;

	const onCallbackFile = files => {
		setErr(false);
		setAttach([...attach, ...files]);
	};

	const convertAttach = () => {
		let typeName: Array<{ type: string; list: Array<IAttachments>; AttachTypeId: number }> = [];

		attach?.map(e => {
			const isType = typeName?.findIndex((item: { type: string }) => {
				if (e?.AttachTypeName) {
					return item.type === e?.AttachTypeName;
				}
				return item.type === '-';
			});

			if (isType === -1) {
				typeName = [...typeName, { type: e?.AttachTypeName || '-', list: [e], AttachTypeId: e.AttachTypeId }];
			} else {
				typeName[isType].list.push(e);
			}
		});

		const listClone: Array<{ type: string; list: Array<IAttachments>; AttachTypeId: number }> = JSON.parse(
			JSON.stringify(typeName),
		);
		return listClone;
	};

	const cvAttach = convertAttach();

	const onPressUpload = () => {
		navigation.navigate(RoutesNames.Upload, { moreOptionInfo, type: 'add', onCallbackFile, from: 'addWorkflow' });
	};

	const renderRightActions = (
		_progress: Animated.AnimatedInterpolation<string | number>,
		dragX: Animated.AnimatedInterpolation<string | number>,
		child: IAttachments,
	) => {
		const transform = dragX.interpolate({
			inputRange: [0, 50],
			outputRange: [0, 0],
		});
		const opacity = dragX.interpolate({
			inputRange: [-50, 0],
			outputRange: [1, 0],
			extrapolate: 'clamp',
		});

		const onDeleteSuccess = (res: BaseAPIResponse) => { };

		const onDeleteClick = () => {
			SwipeableRef[child?.idLocal]?.close();
			setAttach(attach.filter(elm => elm.idLocal !== child.idLocal));
		};

		const onPressEdit = () => {
			SwipeableRef[child?.idLocal]?.close();
			refModalType.current?.show(child);
		};

		const onPressDownload = () => { };

		return (
			<Animated.View style={[styles.containerSwipe, { opacity, transform: [{ translateX: transform }] }]}>
				<TouchableOpacity onPress={onDeleteClick} style={styles.bDelete}>
					<Icon src={ICONS.icTrash} width={20} height={20} tintColor="white" />
					<Text style={styles.tDelete}>{translate('delete')}</Text>
				</TouchableOpacity>

				<TouchableOpacity onPress={onPressEdit} style={styles.bEdit}>
					<Icon src={ICONS.icPencil} width={20} height={20} tintColor="white" />
					<Text style={styles.tEdit}>{translate('edit')}</Text>
				</TouchableOpacity>

				{!!child?.ID && (
					<TouchableOpacity onPress={onPressDownload} style={styles.bDown}>
						<Icon src={ICONS.icDownload} width={20} height={20} tintColor="white" />

						<Text style={styles.tDown}>{translate('download')}</Text>
					</TouchableOpacity>
				)}
			</Animated.View>
		);
	};

	const onPressContinute = data => {
		const clone: any[] = JSON.parse(JSON.stringify(attach));
		const index = clone.findIndex(elm => elm.idLocal === data.idLocal);
		clone[index] = data;
		setErr(false);
		setAttach(clone);
	};

	const onPressFile = (item: IAttachments) => {
		if (item?.uri) {
			FileViewer.open(item?.uri, {
				showOpenWithDialog: true,
			}).catch(() => {
				//
			});
		}
	};

	return (
		<View style={{ marginVertical: 20, flex: 1 }}>
			<View style={{ flexDirection: 'row', alignItems: 'flex-start', flex: 1 }}>
				<Icon src={ICONS.icLinkField} width={18} height={18} />
				<View style={{ flex: 1, marginLeft: 8 }}>
					<Text style={{ color: '#7B7B7B', fontSize: 12, marginBottom: 3, fontWeight: '400' }}>
						{translate('attachedDocuments')}{' '}
						{!!listDocumentRequire?.length && <Text style={{ color: COLORS.red }}>(*)</Text>}
					</Text>
					{cvAttach.map((elm, i) => {
						return (
							<View key={i}>
								<View
									style={{
										backgroundColor: 'rgba(245, 245, 245, 1)',
										paddingHorizontal: 10,
										paddingVertical: 10,
									}}>
									{i === 0 && (
										<TouchableOpacity
											activeOpacity={1}
											onPress={onPressUpload}
											style={{
												width: 50,
												height: 50,
												backgroundColor: 'white',
												borderRadius: 30,
												alignItems: 'center',
												justifyContent: 'center',
												position: 'absolute',
												top: -25,
												right: 10,
												padding: 4,
											}}>
											<View
												style={{
													backgroundColor: 'rgba(241, 245, 255, 1)',
													borderRadius: 23,
													width: '98%',
													height: '98%',
													alignItems: 'center',
													justifyContent: 'center',
												}}>
												<Icon src={ICONS.icUpload} width={18} height={18} />
											</View>
										</TouchableOpacity>
									)}
									<Text
										style={{ fontSize: 12, fontWeight: '700', color: 'rgba(123, 123, 123, 1)', paddingVertical: 4 }}>
										{elm.type === '-' ? '' : elm.type}
									</Text>
								</View>
								<View style={{ paddingTop: 16 }}>
									{elm.list.map((child, k) => {
										const created = dayjs(child.Created || new Date()).format(formatDateTime);
										const setRef = ref => (SwipeableRef[child.idLocal] = ref);
										const onSwipeableWillClose = () => {
											if (refIDSwip.current === child.idLocal) {
												refIDSwip.current = '';
											}
										};

										const onSwipeableOpen = () => {
											refIDSwip.current = child.idLocal;
										};

										const onSwipeableWillOpen = () => SwipeableRef[refIDSwip.current]?.close();
										return (
											<Swipeable
												ref={setRef}
												onSwipeableOpen={onSwipeableOpen}
												onSwipeableWillClose={onSwipeableWillClose}
												onSwipeableWillOpen={onSwipeableWillOpen}
												key={k?.toString()}
												renderRightActions={(progress, dragX) => renderRightActions(progress, dragX, child)}>
												<View style={styles.itemAttach}>
													<Icon src={getIconFile(child.Extension)} width={18} height={18} style={styles.vIcon} />
													<View style={styles.vAttach}>
														<TouchableOpacity onPress={() => onPressFile(child)}>
															<Text numberOfLines={1}>{child.Title}</Text>
														</TouchableOpacity>
														<View style={styles.vName}>
															<Text numberOfLines={1} style={styles.tName}>
																{child.CreatedName}
															</Text>
															<View style={styles.vSize} />
															<Text numberOfLines={1} style={styles.tSize}>
																{formatBytes(child.Size)}
															</Text>
														</View>
													</View>
													<View style={styles.vDate}>
														<Text style={styles.tDate}>{created}</Text>
													</View>
												</View>
											</Swipeable>
										);
									})}
								</View>
							</View>
						);
					})}
					{!attach?.length && (
						<View
							style={{
								width: '100%',
								height: 130,
								borderStyle: 'dotted',
								borderWidth: 1,
								borderRadius: 8,
								borderColor: err ? COLORS.red : '#E5E5E5',
								marginTop: 8,
								alignItems: 'center',
								justifyContent: 'center',
								paddingHorizontal: 16,
								backgroundColor: '#FAFAFA',
							}}>
							<TouchableOpacity
								activeOpacity={1}
								onPress={onPressUpload}
								style={{
									width: 46,
									height: 46,
									backgroundColor: 'rgba(241, 245, 255, 1)',
									borderRadius: 23,
									alignItems: 'center',
									justifyContent: 'center',
								}}>
								<Icon src={ICONS.icUpload} width={18} height={18} />
							</TouchableOpacity>
							<Text style={{ color: '#555', marginVertical: 2 }}>{translate('attachedDocuments')}</Text>
							{!!option && <Text style={{ textAlign: 'center', fontSize: 12, color: '#7B7B7B' }}>{option}</Text>}
						</View>
					)}
				</View>
			</View>
			{err && (
				<Text style={{ fontSize: 12, fontStyle: 'italic', color: COLORS.red, marginLeft: 25 }}>
					{translate('attachment')} {refListDocRq.current.toString()}
					{translate('isRequire')}
				</Text>
			)}

			<ModalTypeDoc ref={refModalType} onPressContinute={onPressContinute} />
		</View>
	);
};

export default forwardRef(AttachmentField);

export const styles = StyleSheet.create({
	bHeader: { backgroundColor: 'rgba(245, 245, 245, 1)' },
	tHeader: { padding: 16, fontSize: 12, fontWeight: '700', color: 'rgba(123, 123, 123, 1)' },
	body: { paddingHorizontal: 16, marginVertical: 8 },
	itemAttach: {
		flexDirection: 'row',
		overflow: 'hidden',
		paddingBottom: 16,
		backgroundColor: 'white',
	},
	vAttach: { flex: 1, marginRight: 20, overflow: 'hidden' },
	vName: { flexDirection: 'row' },
	tName: { fontSize: 12, color: 'rgba(123, 123, 123, 1)' },
	vSize: {
		height: '100%',
		width: 1,
		backgroundColor: 'rgba(123, 123, 123, 1)',
		marginHorizontal: 4,
	},
	tSize: { fontSize: 12, color: 'rgba(123, 123, 123, 1)', flex: 1 },
	vDate: { justifyContent: 'center' },
	tDate: { fontSize: 12, color: 'rgba(123, 123, 123, 1)' },
	vIcon: { paddingRight: 12 },
	containerSwipe: { flexDirection: 'row', zIndex: 99, marginLeft: 10 },
	bDelete: {
		alignItems: 'center',
		justifyContent: 'center',
		backgroundColor: 'rgba(235, 55, 50, 1)',
		width: 50,
		height: 50,
	},
	tDelete: { color: 'white', fontSize: 11, textAlign: 'center' },
	bEdit: {
		alignItems: 'center',
		justifyContent: 'center',
		backgroundColor: 'rgba(0, 95, 212, 1)',
		width: 50,
	},
	tEdit: { color: 'white', fontSize: 11 },
	bDown: {
		alignItems: 'center',
		justifyContent: 'center',
		backgroundColor: 'rgba(166, 166, 166, 1)',
		width: 50,
	},
	tDown: { color: 'white', fontSize: 10, textAlign: 'center' },
});
