import React from 'react';

import { Icon } from 'components/Atoms/Icon';
import FImage from 'components/Organisms/FImage/FImage';
import { COLORS, COLOR_TEXT_STATUS, ICONS } from 'config';
import moment from 'moment';
import { View, Text, TouchableOpacity, Animated, TouchableWithoutFeedback } from 'react-native';
import Swipeable from 'react-native-gesture-handler/Swipeable';
import { useAppDispatch, useAppSelector } from 'stores';
import { fetchDeleteTaskFlow } from 'stores/TaskDetails/thunks';

interface IItemInfoUser {
	item: string;
	index?: number;
	StatusGroup: number;
	DueDate: string;
	color: string | undefined;
	ID: number;
	IsAllowDelete: number;
	onPressTask: () => void;
}

interface IItems {
	ID: string;
	ImagePath: string;
	DefaultImagePath: string;
	Name: string;
	PositionName: string;
	PositionId: number;
	NumExpand: number;
	Type: number;
	AllUserGroup: string;
}

const COLOR_STATUS = {
	1: '#F0F0F0',
	2: '#F0F0F0',
	4: '#D1E9FF',
	8: '#DCFFDA',
	16: '#FFCBCB',
	32: '#D1E9FF',
	64: '#FFCBCB',
};

const WorkflowItem = ({
	item,
	index,
	StatusGroup = 0,
	DueDate,
	ID,
	IsAllowDelete,
	onPressTask,
	Title,
}: IItemInfoUser) => {
	const dispacth = useAppDispatch();

	const { beanAppStatus } = useAppSelector(state => state.system);

	const items: IItems = JSON?.parse(item || '{}');
	const { ImagePath, DefaultImagePath, Name, PositionName, NumExpand } = items;

	const Time = DueDate ? moment(new Date(DueDate)).format('DD/MM/YY hh:mm') : '';
	const statusGroupItem = beanAppStatus?.find(v => v.ID === StatusGroup);

	const renderRightActions = (
		_progress: Animated.AnimatedInterpolation<string | number>,
		dragX: Animated.AnimatedInterpolation<string | number>,
	) => {
		// isAllowDelete = 1
		if (IsAllowDelete === 0) return null;
		const transform = dragX.interpolate({
			inputRange: [0, 50, 100, 101],
			outputRange: [0, 0, 0, 1],
		});
		const opacity = dragX.interpolate({
			inputRange: [-150, 0],
			outputRange: [1, 1],
			extrapolate: 'clamp',
		});

		const onPressDelete = () => {
			dispacth(
				fetchDeleteTaskFlow({
					rid: ID,
				}),
			);
		};

		return (
			<Animated.View
				style={[
					{ flexDirection: 'row', marginLeft: 4 },
					{ opacity, transform: [{ translateX: transform }] },
				]}>
				<TouchableOpacity
					onPress={onPressDelete}
					style={{
						alignItems: 'center',
						justifyContent: 'center',
						backgroundColor: COLORS.deepCarminePink,
						width: 44,
					}}>
					<Icon src={ICONS.icTrash} width={20} height={20} style={{}} tintColor="white" />
				</TouchableOpacity>
			</Animated.View>
		);
	};

	return (
		<Swipeable
			// ref={SwipeableRef}

			// ref={ref => (SwipeableRef[x.ID] = ref)}
			// onSwipeableOpen={() => (refIDSwip.current = x.ID)}
			// onSwipeableWillClose={() => {
			// 	if (refIDSwip.current === x.ID) {
			// 		refIDSwip.current = null;
			// 	}
			// }}
			// onSwipeableWillOpen={() => SwipeableRef[refIDSwip.current]?.close()}
			key={index?.toString()}
			// renderLeftActions={(progress, dragX) => renderRightActions(progress, dragX, x, isAuthor, index)}
			renderRightActions={(progress, dragX) => renderRightActions(progress, dragX)}>
			<View
				style={{
					flexDirection: 'row',
					alignItems: 'center',
					justifyContent: 'space-between',
					backgroundColor: 'white',
				}}>
				<Text numberOfLines={2} style={{ fontSize: 14 }}>
					{Title}
				</Text>
				<Text style={{ fontSize: 12, fontWeight: '400', color: '#5E5E5E' }}>12h</Text>
			</View>

			<TouchableWithoutFeedback onPress={onPressTask}>
				<View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: 'white' }}>
					<View style={{ marginRight: 10 }}>
						<FImage ImagePath={ImagePath} DefaultImagePath={DefaultImagePath} SW={32} mh={0} />
						{!!NumExpand && (
							<View
								style={{
									width: 20,
									height: 20,
									backgroundColor: 'rgba(17, 17, 17, 0.5)',
									zIndex: 1,
									position: 'absolute',
									bottom: -2,
									right: -6,
									borderRadius: 10,
									alignItems: 'center',
									justifyContent: 'center',
								}}>
								<Text style={{ color: 'white', fontSize: 12 }}>+{NumExpand}</Text>
							</View>
						)}
					</View>
					<View style={{ flex: 1 }}>
						<View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
							<Text style={{ fontSize: 14, fontWeight: '400', flex: 1 }} numberOfLines={1}>
								{Name}
							</Text>
						</View>

						<View
							style={{
								flexDirection: 'row',
								justifyContent: 'space-between',
								alignItems: 'center',
								overflow: 'hidden',
							}}>
							<Text style={{ fontSize: 12, fontWeight: '400', color: '#5E5E5E' }}>{PositionName || ''}</Text>
							<View
								style={{
									width: 120,
									backgroundColor: COLOR_STATUS?.[StatusGroup] || '#F0F0F0',
									paddingVertical: 4,
									alignItems: 'center',
									borderRadius: 3,
								}}>
								<Text style={{ fontSize: 12, fontWeight: '400', color: COLOR_TEXT_STATUS?.[StatusGroup] }}>
									{statusGroupItem?.Title}
								</Text>
							</View>
						</View>
					</View>
				</View>
			</TouchableWithoutFeedback>
		</Swipeable>
	);
};

export default WorkflowItem;
