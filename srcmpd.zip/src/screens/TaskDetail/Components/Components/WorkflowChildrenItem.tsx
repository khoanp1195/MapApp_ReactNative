/* eslint-disable import/no-cycle */
/* eslint-disable prettier/prettier */
/* eslint-disable react/no-array-index-key */
import React from 'react';

import { Icon } from 'components/Atoms/Icon';
import { COLORS, ICONS } from 'config';
import { View, Text, TouchableOpacity } from 'react-native';
import { ITaskFlow } from 'stores/TaskDetails';

import WorkflowItem from './WorkflowItem';
import { EnhancedItemParent } from '../TaskFlow';

export interface IRenderItem {
	item: ITaskFlow;
	show: number[];
	onPressItem?: (ID: number) => void; s
	onPressTask?: (item: ITaskFlow) => void;
	index?: number;
}


function WorkflowChildrenItem({ item, onPressItem = () => { }, show, onPressTask = () => { }, index }: IRenderItem) {
	const { children, ID, level, Title } = item || {}; // level: 2, 4, 6
	const isShow = show?.find(s => s === ID);

	const OnPressTask = () => {
		onPressTask(item);
	};

	const OnPressItem = () => {
		onPressItem(ID);
	};

	const renderChildren = () => {
		return (
			<View>
				{children?.map((child, i) => {
					return <EnhancedItemParent key={i.toString()} item={child} show={show} onPressItem={onPressItem} onPressTask={onPressTask} />;
				})}
			</View>
		);
	};

	return (
		<View
			style={{
				paddingLeft: level ? level - 1 * 10 : 0,
				flexDirection: 'row',
				marginTop: 10
			}}>
			<View style={{ flexDirection: 'row', marginRight: children?.length ? 6 : 26 }}>
				{!!children?.length && (
					<Icon src={isShow ? ICONS.icPlusRectangle : ICONS.icMinusRectangle} width={20} height={20} onPress={OnPressItem} />
				)}

			</View>
			<View style={{ flex: 1, }}>
				<WorkflowItem
					item={item?.AssignedToInfo}
					StatusGroup={item?.StatusGroup}
					DueDate={item?.DueDate}
					ID={item?.ID}
					IsAllowDelete={item?.IsAllowDelete}
					onPressTask={OnPressTask}
					Title={Title}
				/>
				{!isShow && renderChildren()}
			</View>
		</View>
	);
}


export default WorkflowChildrenItem
