/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable import/no-cycle */
/* eslint-disable prettier/prettier */
/* eslint-disable react/no-array-index-key */
import React from 'react';

import { Icon } from 'components/Atoms/Icon';
import { COLORS, ICONS } from 'config';
import { View, Text, TouchableOpacity } from 'react-native';
import { ITaskFlow } from 'stores/TaskDetails';

import WorkflowItem from './WorkflowItem';
import { EnhancedItemChildren } from '../TaskFlow';

export interface IRenderItem {
	item: ITaskFlow;
	show: number[];
	onPressItem?: (ID: number) => void;
	onPressTask?: (item: ITaskFlow) => void;
	index?: number;
}

const WorkflowParentItem = ({ item, index = 0, onPressItem = () => { }, show, onPressTask = () => { } }: IRenderItem) => {
	const { children, ID, level, Title } = item || {}; // level: 1, 2, 5

	const isShow = show?.find(s => s === ID);

	const OnPressTask = () => {
		onPressTask(item);
	};

	const OnPressItem = () => {
		onPressItem(ID);
	};

	const renderChildren = () => {
		return (
			<View>
				{children?.map((child, i) => {
					return (
						<EnhancedItemChildren
							key={i.toString()}
							item={child}
							onPressItem={onPressItem}
							show={show}
							onPressTask={onPressTask}
						/>
					);
				})}
			</View>
		);
	};

	return (
		<View
			style={{
				paddingLeft: level ? level * 10 : 0,
				padding: level === 1 ? 10 : 0,
				overflow: 'hidden',
				flexDirection: 'row',
				borderBottomWidth: item?.Parent === 0 ? 4 : 0,
				borderBottomColor: 'rgba(123, 123, 123, 0.2)',
				marginTop: 10
			}}>
			<View style={{ flexDirection: 'row', marginRight: children?.length ? 6 : 26, }}>
				{!!children?.length && (
					<Icon src={isShow ? ICONS.icPlusRectangle : ICONS.icMinusRectangle} width={20} height={20} onPress={OnPressItem} />
				)}
			</View>
			<View style={{ flex: 1 }}>
				<WorkflowItem
					item={item?.AssignedToInfo}
					StatusGroup={item?.StatusGroup}
					DueDate={item?.DueDate}
					ID={item?.ID}
					IsAllowDelete={item?.IsAllowDelete}
					onPressTask={OnPressTask}
					Title={Title}
				/>
				{!isShow && renderChildren()}
			</View>

		</View>
	);
};

export default WorkflowParentItem


