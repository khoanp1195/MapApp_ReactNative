/* eslint-disable import/no-cycle */
/* eslint-disable prettier/prettier */
/* eslint-disable react/no-array-index-key */
import React, { useEffect, useState } from 'react';

import { navigate } from 'navigation/RootNavigation';
import { RoutesNames } from 'navigation/RoutesNames';
import { View, Text, FlatList, Platform } from 'react-native';
import { useAppDispatch, useAppSelector } from 'stores';
import { ITaskFlow } from 'stores/TaskDetails';
import { fetchTaskFlow } from 'stores/TaskDetails/thunks';

import WorkflowChildrenItem from './Components/WorkflowChildrenItem';
import WorkflowParentItem from './Components/WorkflowParentItem';

const EnhancedComponent = (WrappedComponent) => {
	const Enhanced = (props: React.JSX.IntrinsicAttributes) => (
		// eslint-disable-next-line react/jsx-props-no-spreading
		<WrappedComponent {...props} />
	);
	return Enhanced;
};

export const EnhancedItemParent = EnhancedComponent(WorkflowParentItem);
export const EnhancedItemChildren = EnhancedComponent(WorkflowChildrenItem);

const TaskFlow = ({ ID, onUpdateTask }: { ID?: number; onUpdateTask?: () => void }) => {
	const dispactch = useAppDispatch();
	const taskFlow = useAppSelector(store => store.workflow.assignTask);

	const [convertTaskFlow, setConvertTaskFlow] = useState<ITaskFlow[]>([]);
	const [show, setShow] = useState<number[]>([]);

	const onUpdateTaskFlow = () => {
		onUpdateTask();
		dispactch(
			fetchTaskFlow({
				rid: ID,
				lid: 1066,
			}),
		);
	};

	const onPressTask = (item: ITaskFlow) => {
		navigate(RoutesNames.Task, { item, onUpdateTaskFlow, onUpdateTask });
	};

	function createNestedArray(data: ITaskFlow) {
		// Tạo một bản sao của mảng gốc để không làm thay đổi dữ liệu gốc
		const cloneData = JSON.parse(JSON.stringify(data));

		// Tạo một đối tượng theo ID để tìm kiếm nhanh
		const lookup = {};
		cloneData?.forEach(item => {
			lookup[item.ID] = item;
			item.children = [];
		});

		const result = [];

		cloneData?.forEach(item => {
			const parent = lookup[item.Parent];
			if (parent) {
				// Thêm mục con vào mục cha
				parent.children.push(item);
			} else {
				// Nếu không có mục cha, đây là một mục cấp cao nhất
				result.push(item);
			}
		});

		// Thêm trường level cho từng mục
		const addLevel = (items, level) => {
			items.forEach(item => {
				item.level = level;
				if (item.children.length > 0) {
					addLevel(item.children, level + 1);
				}
			});
		};

		// Gọi hàm addLevel với level ban đầu là 1
		addLevel(result, 1);

		// Sửa đổi cấp độ của tất cả các mục con thành cùng một cấp độ với mức 3
		const adjustLevel = (items, targetLevel) => {
			items.forEach(item => {
				if (item.level > targetLevel) {
					item.level = targetLevel;
				}
				if (item.children.length > 0) {
					adjustLevel(item.children, targetLevel);
				}
			});
		};

		// Gọi hàm adjustLevel với cấp độ mục tiêu là 3
		adjustLevel(result, 3);

		return result;
	}

	useEffect(() => {
		setConvertTaskFlow(createNestedArray(taskFlow));
	}, [taskFlow]);

	const getItemLayout = (_data: unknown, index: number) => ({
		length: 90,
		offset: 90 * index,
		index,
	});

	const onPressItem = (id: number) => {
		const isId = show?.find(i => i === id);
		if (isId) {
			setShow(show.filter(i => i !== id));
		} else {
			setShow(show.concat(id));
		}
	};

	if (!convertTaskFlow?.length) return null;

	const renderItem = ({ item, index }: { item: ITaskFlow, index: number }) => (
		<EnhancedItemParent item={item} index={index} show={show} onPressItem={onPressItem} onPressTask={onPressTask} />
	)

	return (
		<View style={{ marginBottom: 100 }}>
			<View>
				<FlatList
					getItemLayout={getItemLayout}
					scrollEnabled={false}
					initialNumToRender={5}
					maxToRenderPerBatch={5}
					updateCellsBatchingPeriod={5}
					renderToHardwareTextureAndroid
					removeClippedSubviews={Platform.OS !== 'ios'}
					data={convertTaskFlow}
					keyExtractor={(_item, index) => index?.toString()}
					renderItem={renderItem}
				/>
			</View>
		</View>
	);
};
export default TaskFlow;
