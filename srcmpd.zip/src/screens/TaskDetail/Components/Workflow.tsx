/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable array-callback-return */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import React, { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';

import { useNavigation, StackActions } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import FImage from 'components/Organisms/FImage/FImage';
import { COLORS, ICONS } from 'config';
import moment from 'moment';
import { RoutesNames } from 'navigation/RoutesNames';
import { View, Text, FlatList, TouchableOpacity, Platform, LayoutAnimation, Animated } from 'react-native';
import { TouchableWithoutFeedback } from 'react-native-gesture-handler';
import Swipeable from 'react-native-gesture-handler/Swipeable';
import { useAppDispatch, useAppSelector } from 'stores';
import { fetchDeleteWorkflowRelated } from 'stores/TaskDetails/thunks';

const COLOR_STATUS = {
	1: '#F0F0F0',
	2: '#F0F0F0',
	4: '#D1E9FF',
	8: '#DCFFDA',
	16: '#FFCBCB',
	32: '#D1E9FF',
	64: '#FFCBCB',
};

interface IItem {
	ID: number;
	Title: string;
	Content: string;
	Created: string;
	CreatedBy: string;
	StatusGroup: number;
	ImagePath: string;
	DefaultImagePath: string;
	Workflow: string;
	WorkflowId: number;
	ListID: string;
	WorkflowRelatedId?: number;
	SPItemId: number;
	AssignedTo?: string;
	AssignedToInfo?: string;
	ApprovalStatus?: number;
	Flag?: number;
	TotalRecord?: number;
}

interface IRenderItem {
	item: IItem;
	index: number;
	onDeleteLocal: (item: any) => void;
}

const RenderItem = ({ item, index, onDeleteLocal }: IRenderItem) => {
	const navigation = useNavigation();
	const dispactch = useAppDispatch();

	const SwipeableRef = useRef({});
	const refIDSwip = useRef();

	const { beanAppStatus } = useAppSelector(state => state.system);
	const {
		ImagePath,
		DefaultImagePath,
		Content,
		Title,
		Created,
		StatusGroup,
		WorkflowRelatedId = null,
		AssignedToInfo = '',
	} = item;

	const Assigned: { ImagePath: string; DefaultImagePath: string } = JSON.parse(
		!WorkflowRelatedId ? AssignedToInfo : '{}',
	);

	const Time = Created ? moment(new Date(Created)).format('DD/MM/YY hh:mm') : '';
	const statusGroupItem = beanAppStatus?.find(v => v.ID === StatusGroup);
	const details = useAppSelector(store => store.taskDetails.details);
	const isAllow = details?.FormConfig?.IsAdmin || details?.FormConfig?.AllowRelatedEdit;

	const renderRightActions = (progress: any, dragX: { interpolate: any }) => {
		if (!isAllow) return null;
		const transform = dragX.interpolate({
			inputRange: [0, 50, 100, 101],
			outputRange: [0, 0, 0, 1],
		});
		const opacity = dragX.interpolate({
			inputRange: [-150, 0],
			outputRange: [1, 1],
			extrapolate: 'clamp',
		});

		const onPressDelete = () => {
			SwipeableRef[item.ID]?.close();

			if (!item.WorkflowRelatedId) {
				onDeleteLocal(item);
			} else {
				dispactch(
					fetchDeleteWorkflowRelated({
						workflowrelatedid: item?.WorkflowRelatedId,
						success: () => onDeleteLocal(item),
					}),
				);
			}
			LayoutAnimation.easeInEaseOut();
		};

		return (
			<Animated.View style={[{ flexDirection: 'row' }, { opacity, transform: [{ translateX: transform }] }]}>
				<TouchableOpacity
					onPress={onPressDelete}
					style={{ alignItems: 'center', justifyContent: 'center', backgroundColor: '#EB342E', width: 44 }}>
					<Text style={{ color: 'white' }}>Delete</Text>
				</TouchableOpacity>
			</Animated.View>
		);
	};

	const handleNavigateToDetail = () => {
		if (!item.WorkflowRelatedId) return;
		navigation.dispatch(StackActions.replace(RoutesNames.TaskDetail, { item, isScrollToTop: true }));
	};

	const onSwipeableOpen = () => (refIDSwip.current = item.ID);

	const onSwipeableWillClose = () => {
		if (refIDSwip.current === item.ID) {
			refIDSwip.current = null;
		}
	};

	const onSwipeableWillOpen = () => SwipeableRef[refIDSwip.current]?.close();

	const setRef = ref => (SwipeableRef[item.ID] = ref);

	return (
		<Swipeable
			renderRightActions={renderRightActions}
			ref={setRef}
			onSwipeableOpen={onSwipeableOpen}
			onSwipeableWillClose={onSwipeableWillClose}
			onSwipeableWillOpen={onSwipeableWillOpen}>
			<TouchableWithoutFeedback
				onPress={handleNavigateToDetail}
				style={{
					height: 90,
					backgroundColor: !(index % 2) ? '#F3F9FF' : COLORS.white,
					alignItems: 'center',
					justifyContent: 'center',
				}}>
				<View style={{ flexDirection: 'row' }}>
					<FImage
						ImagePath={ImagePath || Assigned?.ImagePath}
						DefaultImagePath={DefaultImagePath || Assigned?.DefaultImagePath}
					/>

					<View style={{ flex: 1 }}>
						<Text style={{ fontSize: 15, fontWeight: '400' }} numberOfLines={1}>
							{Content}
						</Text>
						<View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 7 }}>
							<Text style={{ fontSize: 12, fontWeight: '400', color: '#5E5E5E' }}>{Title}</Text>
							<Text style={{ fontSize: 12, fontWeight: '400', color: '#5E5E5E' }}>{Time}</Text>
						</View>
						<View
							style={{
								width: 120,
								backgroundColor: COLOR_STATUS?.[StatusGroup] || COLOR_STATUS[1],
								paddingVertical: 4,
								alignItems: 'center',
								borderRadius: 3,
							}}>
							<Text style={{ fontSize: 12, fontWeight: '400' }}>{statusGroupItem?.Title}</Text>
						</View>
					</View>
				</View>
			</TouchableWithoutFeedback>
		</Swipeable>
	);
};

interface IListWorkflow {
	WorkflowId: number;
	name: string;
	list: Array<IItem>;
}

const Workflow = ({ ID }: { ID?: number }, ref: React.Ref<unknown> | undefined) => {
	const workflow = useAppSelector(store => store.taskDetails.workflowRelated);

	const [listWorkflow, setListWorkflow] = useState<IListWorkflow[]>([]);
	const [indexHide, setIndexHide] = useState<number[]>([]);

	useEffect(() => {
		let list: Array<IListWorkflow> = [];
		workflow?.map(e => {
			const isIndexWorkflow = list?.findIndex(item => item.WorkflowId === e.WorkflowId);
			if (isIndexWorkflow === -1) {
				list = [...list, { WorkflowId: e.WorkflowId, list: [e], name: e.Workflow }];
			} else {
				list[isIndexWorkflow].list.push(e);
			}
		});
		setListWorkflow(list);
	}, [workflow]);

	const getIdSeleted = () => {
		const listClone = listWorkflow;

		let listID = ID?.toString();

		listClone.forEach(data => {
			data.list.forEach(item => {
				listID = listID.concat(`,${item.ID}`);
			});
		});

		return listID;
	};

	const onDeleteLocal = (data: IItem) => {
		let listCv = [...listWorkflow];

		const indexParent = listWorkflow?.findIndex(e => e.WorkflowId === data.WorkflowId);

		listCv[indexParent].list = listCv[indexParent].list.filter(e => e.ID !== data.ID);

		if (!listCv[indexParent].list?.length) {
			listCv = listCv.filter(e => e.WorkflowId !== data.WorkflowId);
		}

		setListWorkflow(listCv);
	};

	const setSelectWorkFlow = (data: Array<IItem>) => {
		let list = [...listWorkflow];
		data?.map(e => {
			const isIndexWorkflow = list?.findIndex(item => item.WorkflowId === e.WorkflowId);
			if (isIndexWorkflow === -1) {
				list = [...list, { WorkflowId: e.WorkflowId, list: [e], name: e.Workflow }];
			} else {
				list[isIndexWorkflow].list.push(e);
			}
		});

		setListWorkflow([...list]);
	};

	const getListWorkflowRelated = () => {
		let request: Array<{
			ID: number;
			ListID: string;
			WorkflowId: number;
			Title: string;
		}> = [];
		listWorkflow.forEach(data => {
			data.list.forEach(item => {
				if (!item?.WorkflowRelatedId) {
					request = [
						...request,
						{
							ID: item.ID,
							ListID: item?.ListID,
							WorkflowId: item?.WorkflowId,
							Title: item?.Title,
						},
					];
				}
			});
		});
		return request;
	};

	useImperativeHandle(
		ref,
		() => ({
			setData: setSelectWorkFlow,
			getIdSeleted,
			getListWorkflowRelated,
		}),
		[listWorkflow],
	);

	const getItemLayout = (_: any, index: number) => ({
		length: 90,
		offset: 90 * index,
		index,
	});

	const onHide = (index: number) => {
		const isHide = indexHide.find(e => e === index);
		if (isHide === undefined) {
			setIndexHide(indexHide.concat(index));
			return;
		}

		setIndexHide(indexHide.filter(e => e !== index));
	};

	const renderItem = ({ item, index }: { item: IListWorkflow; index: number }) => {
		const isHide = indexHide.find(e => e === index);
		return (
			<View>
				<TouchableOpacity
					onPress={() => onHide(index)}
					style={{ backgroundColor: '#F5F5F5', padding: 15, flexDirection: 'row', alignItems: 'center' }}>
					<Text style={{ fontSize: 14, fontWeight: '700', color: '#005FD4', marginRight: 10 }}>
						{item?.name || 'Other'} ({item?.list?.length})
					</Text>
					<Icon
						src={isHide === undefined ? ICONS.icArrowDown : ICONS.icArrowRight}
						width={12}
						height={12}
						style={{ marginRight: 10 }}
					/>
				</TouchableOpacity>
				{isHide === undefined &&
					item?.list?.map((wf, idx) => {
						return <RenderItem key={idx?.toString()} item={wf} index={idx} onDeleteLocal={onDeleteLocal} />;
					})}
			</View>
		);
	};

	return (
		<View style={{ marginBottom: 20 }}>
			<Text style={{ color: '#000', fontSize: 14, marginBottom: 14, fontWeight: '700' }} numberOfLines={1}>
				Danh sách quy trình liên kết
			</Text>
			<View>
				<FlatList
					getItemLayout={getItemLayout}
					scrollEnabled={false}
					initialNumToRender={5}
					maxToRenderPerBatch={5}
					updateCellsBatchingPeriod={5}
					renderToHardwareTextureAndroid
					removeClippedSubviews={Platform.OS !== 'ios'}
					data={listWorkflow}
					keyExtractor={(item, index) => index?.toString()}
					renderItem={renderItem}
					contentContainerStyle={{ borderWidth: 0.8, borderColor: '#F5F5F5', borderRadius: 4 }}
				/>
			</View>
		</View>
	);
};

export default forwardRef(Workflow);
