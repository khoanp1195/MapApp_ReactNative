/* eslint-disable prettier/prettier */
import React, { useRef, useState } from 'react';

import { Icon } from 'components/Atoms/Icon';
import { ModalComponent } from 'components/Molecules/Modal';
import { COLORS, ICONS } from 'config';
import { View, FlatList, TouchableOpacity, Text } from 'react-native';

// Chuyển xử lý: Nhập 1 User
// Bổ sung thông tin: Chọn 1 User (danh sách user là các users đã xử lý trước đó ngoại trừ user login)
// Yêu câu tham vấn: Nhập nhiều User
// Chia sẻ: Nhập nhiều User và Group

export const getIconAction = (ActionCode: string) => {
	switch (ActionCode) {
		case 'SAVE':
			return ICONS.icSave;
		case 'IDEA':
			return ICONS.icIdea;
		case 'APPROVE':
			return ICONS.icCheck;
		case 'NEXT':
			return ICONS.icCheck;
		case 'RETURN':
			return ICONS.icReturn;
		case 'TASK':
			return ICONS.icTask;
		case 'REPLACE':
			return ICONS.icReplace;
		case 'ADDINFO':
			return ICONS.icAddInfo;
		case 'REQUESTIDEA':
			return ICONS.icRequestIdea;
		case 'RECALL':
			return ICONS.icRecall;
		case 'CANCEL':
			return ICONS.icCancel2;
		case 'REJECT':
			return ICONS.icCancel;
		case 'SEND':
			return ICONS.icSend;

		default:
			return ICONS.icCheck;
	}
};

export interface ActionParams {
	ActionCode: string;
	Class: string;
	ID: string;
	Index: string;
	Title: string;
}

export interface Props {
	modal?: boolean;
	onClose?: () => void;
	ListAction?: Array<ActionParams>;
	submitAction?: (e: string) => void;
	onHide?: (res: any) => void;
}

const ModalActionBottom = ({ modal = false, onClose, ListAction, submitAction = () => { }, onHide = () => { } }: Props) => {
	const refAction = useRef()

	const _onHide = () => {
		if (refAction.current) {
			onHide(refAction.current)
			refAction.current = null
		}
	}

	return (
		<ModalComponent
			open={modal}
			onHide={_onHide}
			outsideClickCloseable
			onClose={onClose}
			visiblePosition="bottom"
			containerStyle={{ backgroundColor: 'transparent' }}>
			<View style={{ backgroundColor: 'transparent' }}>
				<View style={{ marginBottom: 20, marginHorizontal: 20 }}>
					<FlatList
						scrollEnabled={false}
						contentContainerStyle={{ backgroundColor: 'white', borderRadius: 6, marginBottom: 20 }}
						data={ListAction}
						renderItem={({ item, index }) => {
							if (index < 2) return null;
							return (
								<View style={{ borderBottomWidth: 0.8, borderBottomColor: '#F5F5F5' }}>
									<TouchableOpacity
										onPress={() => {
											refAction.current = item
											onClose()
										}}
										style={{
											paddingVertical: 20,
											marginHorizontal: 20,
											flexDirection: 'row',
										}}>
										<Icon src={getIconAction(item?.ActionCode)} width={20} height={20} style={{ marginRight: 10 }} />
										<Text>{item?.Title}</Text>
									</TouchableOpacity>
								</View>
							);
						}}
						keyExtractor={(item, index) => index?.toString()}
					/>
					<TouchableOpacity
						onPress={onClose}
						style={{ alignItems: 'center', paddingVertical: 20, backgroundColor: '#005FD4', borderRadius: 6 }}>
						<Text style={{ color: COLORS.white }}>Huỷ</Text>
					</TouchableOpacity>
				</View>
			</View>
		</ModalComponent>
	);
};

export default ModalActionBottom;
