/* eslint-disable prettier/prettier */
import React from 'react';

import { Icon } from 'components/Atoms/Icon';
import { ICONS } from 'config';
import { TouchableOpacity, Text } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { ActionParams, getIconAction } from './ModalActionBottom';
import { Option } from '../styles';

export interface Props {
	setModal?: (e: boolean) => void;
	ListAction?: Array<ActionParams>;
	submitAction?: (e?: any) => void;
}

const ActionBottom = ({ setModal = () => { }, ListAction = [], submitAction = () => { } }: Props) => {
	const { bottom } = useSafeAreaInsets();
	const Action: Array<ActionParams> = ListAction?.length > 2 ? ListAction.slice(0, 2) : ListAction || [];
	return (
		<Option style={{ paddingBottom: bottom }}>
			{Action?.map((action, index: React.Key) => {
				return (
					<TouchableOpacity onPress={() => submitAction(action)}
						key={index?.toString()}
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							flex: 1,
							justifyContent: index === 0 ? 'flex-start' : 'center',
						}}>
						<Icon src={getIconAction(action?.ActionCode)} width={20} height={20} style={{ marginRight: 10 }} />
						<Text>{action?.Title}</Text>
					</TouchableOpacity>
				);
			})}
			<TouchableOpacity
				style={{ flexDirection: 'row', alignItems: 'center', flex: 1, justifyContent: 'flex-end' }}
				onPress={() => {
					if (ListAction?.length > 2) {
						setModal(true)
					}
				}}>
				{ListAction?.length > 2 && <Icon src={ICONS.icMore} width={20} height={20} />}
			</TouchableOpacity>
		</Option>
	);
};

export default ActionBottom;
