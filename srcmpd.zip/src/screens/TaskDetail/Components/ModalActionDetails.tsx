import React, { useState } from 'react';

import { Icon } from 'components/Atoms/Icon';
import { ModalComponent } from 'components/Molecules/Modal';
import { COLORS, ICONS } from 'config';
import { View, FlatList, TouchableOpacity, Text, TextInput, KeyboardAvoidingView, Platform } from 'react-native';
import { Dropdown, MultiSelect } from 'react-native-element-dropdown';

import { getIconAction } from './ModalActionBottom';

const ModalActionDetails = ({ modal = {}, onClose }) => {
	const [choices, setChoices] = useState([]);
	const MuliComponent = () => {
		return (
			<MultiSelect
				maxSelect={1}
				// dropdownPosition="top"
				style={{
					minHeight: 28,
					borderColor: '#E5E5E5',
					borderWidth: 0.5,
					width: '100%',
					// padding: 10,
					paddingHorizontal: 10,
					borderRadius: 4,
				}}
				placeholderStyle={{ fontSize: 14 }}
				selectedTextStyle={{ fontSize: 14 }}
				selectedStyle={{ borderWidth: 0, backgroundColor: 'white', padding: 0 }}
				inputSearchStyle={{ height: 28 }}
				// iconStyle={styles.iconStyle}
				data={[]}
				search
				// renderInputSearch={() => {
				// 	return (
				// 		<View
				// 			style={{
				// 				backgroundColor: 'white',
				// 				padding: 10,
				// 				borderWidth: 1,
				// 				borderRadius: 4,
				// 				borderColor: '#5E5E5E',
				// 			}}>
				// 			<TextInput
				// 				value={keyword}
				// 				placeholder="Search..."
				// 				style={{ fontStyle: 'italic' }}
				// 				onChangeText={onChangeText}
				// 			/>
				// 		</View>
				// 	);
				// }}
				maxHeight={250}
				labelField="label"
				valueField="value"
				placeholder=""
				searchPlaceholder="Search..."
				value={[]}
				onChange={item => {
					setChoices(item);
				}}
				renderItem={(item, index) => {
					return (
						<View
							key={index.toString()}
							style={{
								backgroundColor: 'rgba(194, 194, 194, 0.5)',
								paddingHorizontal: 15,
								paddingVertical: 5,
							}}>
							<Text>{item?.[KeyFeild]}</Text>
						</View>
					);
				}}
				renderSelectedItem={item => {
					return <></>;
				}}
				alwaysRenderSelectedItem
				flatListProps={{
					onEndReached: () => fetchMore(),
				}}>
				<View
					style={{
						paddingVertical: 5,
						width: '90%',
						flexDirection: 'row',
						alignItems: 'center',
						zIndex: 1,
						overflow: 'hidden',
						// height: 100,
						flexWrap: 'wrap',
					}}>
					{choices?.length ? (
						<View>
							{choices?.map((e, index) => {
								const labelUser = dataUser.find((data: any) => data.id === e);
								return (
									<Text key={index?.toString()} style={{ fontSize: 14, marginRight: 10 }}>
										{labelUser?.Title || listChoiceslabel[index]}
										<TouchableOpacity
											style={{
												zIndex: 1,
												marginTop: -2,
												paddingLeft: 4,
											}}
											onPress={() => onClear(e)}>
											<Text style={{ fontSize: 12 }}>ⓧ</Text>
										</TouchableOpacity>
									</Text>
								);
							})}
						</View>
					) : (
						<View>
							<Text style={{ color: 'rgba(153, 153, 153, 1)', fontStyle: 'italic', fontSize: 12 }}>
								Người được yêu cầu bổ sung
							</Text>
						</View>
					)}
				</View>
			</MultiSelect>
		);
	};

	const hideDropdown = () => {
		switch (modal?.ActionCode) {
			case 'SAVE':
				return true;
			case 'IDEA':
				return true;
			case 'APPROVE':
				return true;
			case 'NEXT':
				return true;
			case 'RETURN':
				return false;
			case 'TASK':
				return true;
			case 'REPLACE':
				return true;
			case 'ADDINFO':
				return true;
			case 'REQUESTIDEA':
				return true;
			case 'RECALL':
				return true;
			case 'CANCEL':
				return false;
			case 'REJECT':
				return false;
			case 'SEND':
				return true;

			default:
				return false;
		}
	};

	const isHideDropdown = hideDropdown();

	return (
		<ModalComponent
			open={!!modal?.ID}
			outsideClickCloseable
			onClose={onClose}
			visiblePosition="center"
			containerStyle={{ backgroundColor: 'transparent' }}>
			<View style={{ backgroundColor: 'transparent' }}>
				<KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ width: '100%' }}>
					<View style={{ width: '100%', backgroundColor: 'white', borderRadius: 6 }}>
						<View
							style={{
								flexDirection: 'row',
								alignItems: 'center',
								marginHorizontal: 15,
								borderBottomWidth: 0.8,
								paddingVertical: 15,
								borderBottomColor: 'rgba(153, 153, 153, 0.5)',
								marginBottom: 15,
							}}>
							<Icon src={getIconAction(modal?.ActionCode)} width={20} height={20} style={{ marginRight: 10 }} />
							<Text style={{ fontSize: 15, fontWeight: '700' }}>{modal?.Title}</Text>
						</View>
						{isHideDropdown && (
							// <TouchableOpacity
							// 	style={{
							// 		borderWidth: 0.8,
							// 		borderColor: 'rgba(153, 153, 153, 0.5)',
							// 		padding: 15,
							// 		marginHorizontal: 15,
							// 		borderRadius: 6,
							// 	}}>
							// 	<Text style={{ color: 'rgba(153, 153, 153, 1)', fontStyle: 'italic' }}>
							// 		Người được yêu cầu bổ sung{' '}
							// 	</Text>
							// </TouchableOpacity>
							<View style={{ marginHorizontal: 15 }}>
								<MuliComponent />
							</View>
						)}
						<View
							style={{
								height: 150,
								borderRadius: 6,
								borderWidth: 0.8,
								borderColor: 'rgba(153, 153, 153, 0.5)',
								padding: 15,
								margin: 15,
								overflow: 'hidden',
								marginTop: isHideDropdown ? 15 : 0,
							}}>
							<TextInput multiline placeholder="Vui lòng nhập ý kiến" placeholderTextColor="rgba(153, 153, 153, 1)" />
						</View>
						<View style={{ flexDirection: 'row', justifyContent: 'flex-end', margin: 15 }}>
							<TouchableOpacity
								onPress={onClose}
								style={{
									width: 120,
									height: 40,
									backgroundColor: 'white',
									borderRadius: 6,
									alignItems: 'center',
									justifyContent: 'center',
								}}>
								<Text style={{ color: 'rgba(235, 52, 46, 1)', fontSize: 15, fontWeight: '400' }}>Thoát</Text>
							</TouchableOpacity>
							<TouchableOpacity
								style={{
									width: 120,
									height: 40,
									backgroundColor: 'rgba(0, 95, 212, 1)',
									borderRadius: 6,
									alignItems: 'center',
									justifyContent: 'center',
								}}>
								<Text style={{ color: 'white', fontSize: 15, fontWeight: '400' }}>Hoàn tất</Text>
							</TouchableOpacity>
						</View>
					</View>
				</KeyboardAvoidingView>
			</View>
		</ModalComponent>
	);
};

export default ModalActionDetails;
