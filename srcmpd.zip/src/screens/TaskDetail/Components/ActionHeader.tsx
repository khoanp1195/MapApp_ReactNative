/* eslint-disable no-underscore-dangle */
/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';

import { useNavigation } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { COLORS, ICONS } from 'config';
import { RoutesNames } from 'navigation/RoutesNames';
import { View } from 'react-native';
import { useAppDispatch } from 'stores';
import { fetchCount } from 'stores/Count';
import { fetchFollowTask } from 'stores/TaskDetails/thunks';

const ActionHeader = ({
	IsFollowed = false,
	ID,
	attachment,
	// onUpdateFollow,
	ListDocumentCategory,
}: {
	IsFollowed?: boolean;
	ID?: number | string;
	attachment: { allowAttach: boolean };
	// onUpdateFollow: (ID: number, isFollowed: boolean | number) => void;
}) => {
	const dispatch = useAppDispatch();
	const [isFollowed, setIsFollowed] = useState<boolean | number>(IsFollowed);
	const isAllowAttach = !!attachment?.allowAttach;

	useEffect(() => {
		setIsFollowed(IsFollowed);
	}, [IsFollowed]);

	// useEffect(() => {
	// 	return () => {
	// 		if (!!IsFollowed !== !!isFollowed) {
	// 			onUpdateFollow(ID, isFollowed);
	// 		}
	// 	};
	// }, [isFollowed]);

	const navigation = useNavigation();
	const getIcon = (id: number) => {
		switch (id) {
			case 1:
				return ICONS.icStat;
			case 2:
				return ICONS.icShare;
			case 3:
				return ICONS.icFile;
			case 4:
				return ICONS.icChat;
			case 5:
				return ICONS.icClock;

			default:
				return ICONS.icStat;
		}
	};

	const getTintColor = (id: number) => {
		switch (id) {
			case 1:
				return isFollowed ? 'rgba(255, 236, 0, 1)' : null;
			case 2:
				return null;
			case 3:
				return null;
			case 4:
				return null;
			case 5:
				return null;

			default:
				return null;
		}
	};

	const success = (res: { data: { status: string } }) => {
		if (res?.data?.status === 'SUCCESS') {
			setIsFollowed(!isFollowed);
			dispatch(fetchCount({ countType: 4 }));
		}
	};

	const onPressFollow = () => {
		dispatch(
			fetchFollowTask({
				rid: JSON.stringify(ID),
				flag: isFollowed ? 0 : 1,
				success,
			}),
		);
	};

	const onPressIcon = (action: number) => {
		switch (action) {
			case 1:
				return onPressFollow();
			case 2:
				return navigation.navigate(RoutesNames.ShareWorkflow, { ID });
			case 3:
				if (isAllowAttach)
					return navigation.navigate(RoutesNames.AttachmentsDetails, {
						ID,
						attachment,
						ListDocumentRq: ListDocumentCategory,
					});
				return null;
			case 4:
				return navigation.navigate(RoutesNames.Comments, { ID });
			case 5:
				return navigation.navigate(RoutesNames.TaskHistory, { ID });

			default:
				return null;
		}
	};

	const onGetAllow = (id: number) => {
		switch (id) {
			case 1:
				return true;
			case 2:
				return true;
			case 3:
				return isAllowAttach;
			case 4:
				return true;
			case 5:
				return true;

			default:
				return true;
		}
	};

	return (
		<View style={{ flexDirection: 'row' }}>
			{[1, 2, 3, 4, 5].map((e, i) => {
				const onPress = () => {
					onPressIcon(e);
				};
				return (
					<View key={i?.toString()} style={{ marginLeft: 15 }}>
						<Icon src={getIcon(e)} width={20} height={20} tintColor={getTintColor(e)} onPress={onPress} />
					</View>
				);
			})}
		</View>
	);
};

export default ActionHeader;
