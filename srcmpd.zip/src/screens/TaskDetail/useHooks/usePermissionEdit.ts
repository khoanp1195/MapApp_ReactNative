/* eslint-disable no-bitwise */
/* eslint-disable react-hooks/exhaustive-deps */
import { useEffect, useRef, useState } from 'react';

import { useAppDispatch, useAppSelector } from 'stores';

// ${(Var_VTF_EditMode = (((';' + WFDefine.FieldNameEdits + ';').includes(';<#FormField.Name#>;') != true)&&_VTF_DocConfig.WFStepConfig.Step != 1
// && _VTF_DocConfig.WFStepConfig.Step != 0) ? 0 : Var_VTF_EditMode ),''}

export const usePermisstionEdit = (viewOnly?: boolean, fieldNameEdit?: string) => {
	const [isPermission, setIsPermission] = useState(false);
	const { details } = useAppSelector(store => store.workflow);
	const Permission: number = details?.FormConfig?.Permission || 0;
	const DefindJsonObj: { FieldNameEdits: string; Step: number } = JSON.parse(
		details?.FormConfig?.DefindJsonObj || '{}',
	);
	const FieldNameEdits = DefindJsonObj?.FieldNameEdits;
	const docStep1 = DefindJsonObj?.Step !== 1;
	const docStep0 = DefindJsonObj?.Step !== 0;

	const IsCompleted = details?.FormConfig?.IsCompleted;

	useEffect(() => {
		// eslint-disable-next-line no-bitwise
		const isUserPermissions = (Permission & 4) > 0;
		const isFieldNameEdits = !!FieldNameEdits?.includes(fieldNameEdit || '');

		let isP = 0;
		isP = isUserPermissions ? 1 : 0;
		isP = viewOnly ? 0 : isP;
		isP = !isFieldNameEdits && docStep1 && docStep0 ? 0 : isP;

		setIsPermission(IsCompleted ? false : !!isP);
	}, [viewOnly, fieldNameEdit, details, Permission, FieldNameEdits]);

	return {
		isPermission,
	};
};

export const usePermisstionAttach = () => {
	const [isPermission, setIsPermission] = useState(false);
	const { details } = useAppSelector(store => store.workflow);
	useEffect(() => {
		// eslint-disable-next-line no-bitwise
		const Roles = details?.FormConfig?.Roles || 0;
		const isUserPermissions = (Roles & 2) > 0;
		const isAddinfoUser = details?.FormConfig?.IsAddinfoUser === 1;
		const docStep = details?.FormConfig?.DocStep === 1;

		const IsCompleted = details?.FormConfig?.IsCompleted;

		setIsPermission(IsCompleted ? false : isUserPermissions || isAddinfoUser || docStep);
	}, [details]);

	return {
		isPermission,
	};
};

export const usePermisstionEditAtatch = () => {
	const [isPermissionEdit, setIsPermission] = useState(false);
	const { details } = useAppSelector(store => store.workflow);

	useEffect(() => {
		// eslint-disable-next-line no-bitwise
		const isUserPermissions = (details?.FormConfig?.Roles || 0 & 2) > 0;
		const isAddinfoUser = details?.FormConfig?.IsAddinfoUser === 1;

		const IsCompleted = details?.FormConfig?.IsCompleted;

		setIsPermission(IsCompleted ? false : isUserPermissions || isAddinfoUser);
	}, [details]);

	return {
		isPermissionEdit,
	};
};

// (!FormConfig.IsCompleted && FormConfig.IsCreatedByMe && FormConfig.DocStep <=1 ) || (FormConfig.Roles & 2 > 0 && $.inArray(detailsTableInfo.masterFieldInfo.internalName, that.FieldNameEdits) != -1)

export const usePermisstionEditGrid = (internalName: string) => {
	const [isPermissionEdit, setIsPermission] = useState(false);
	const { details } = useAppSelector(store => store.workflow);

	const DefindJsonObj: { FieldNameEdits: string } = JSON.parse(details?.FormConfig?.DefindJsonObj || '{}');
	const FieldNameEdits = DefindJsonObj?.FieldNameEdits;

	const IsCompleted = details?.FormConfig?.IsCompleted;
	const IsCreatedByMe = details?.FormConfig?.IsCreatedByMe;
	const DocStep = details?.FormConfig?.DocStep || 0;
	const Roles = details?.FormConfig?.Roles || 0;
	const isFieldNameEdits = !!FieldNameEdits?.includes(internalName);

	const permission1 = IsCreatedByMe && DocStep <= 1;
	const permission2 = (Roles & 2) > 0 && isFieldNameEdits;

	useEffect(() => {
		// eslint-disable-next-line no-bitwise
		if (!IsCompleted && (permission1 || permission2)) {
			setIsPermission(true);
		} else {
			setIsPermission(false);
		}
	}, [details]);

	return {
		isPermissionEdit,
	};
};
