import { COLORS } from 'config';
import styled from 'styled-components/native';

export const Container = styled.View``;

export const Row = styled.View`
	flex-direction: row;
	align-items: center;
`;

export const Option = styled(Row)`
	background-color: ${COLORS.whiteSmoke};
	padding: 20px 20px;
	justify-content: space-between;
`;
