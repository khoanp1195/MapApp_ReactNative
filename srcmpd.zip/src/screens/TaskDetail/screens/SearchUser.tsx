/* eslint-disable @typescript-eslint/no-use-before-define */
/* eslint-disable react-hooks/exhaustive-deps */
import { ENDPOINT } from 'http/modules';

import React, { useEffect, useRef, useState } from 'react';

import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import ItemSearchUser from 'components/SearchUser/ItemSearchUser';
import { ICONS } from 'config';
import useDebounce from 'hooks/useDebounce';
import useInfinity from 'hooks/useInfinity';
import { TextInput, View, StyleSheet, Text, FlatList, TouchableOpacity, KeyboardAvoidingView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppDispatch } from 'stores';
import { trackingUser } from 'stores/System';
import { translate } from 'utils/translate';

export type IUser = {
	ID: string;
	Name: string;
	ImagePath: string;
	DefaultImagePath: string;
	Type: number;
	PositionId: number;
	PositionName: string;
	Mobile: string;
	Email: string;
	DepartmentId: number;
	DepartmentName: string;
	AccountName: string;
	Status: number;
	FullName: string;
};

type Params = {
	Item: {
		options: {
			NotifiedUsersInfo: string;
			isAddInfo: boolean;
			type: number;
			isMultiple: boolean;
		};
		user: Array<IUser>;
		RID: string;
		itemPrams: any;
		from: string;
	};
};

export interface ISuggest {
	Title: string;
	ViewType: number;
	Data: string;
}

const RenderSuggest = ({
	suggest,
	onSelectItem,
	selected,
	isField,
}: {
	suggest: ISuggest;
	onSelectItem: (item: IUser, isSelected: boolean) => void;
	selected: IUser[];
}) => {
	const data = JSON.parse(suggest?.Data || '[]');
	return (
		<View style={{ paddingHorizontal: 24, marginTop: 10 }}>
			<Text style={{ fontWeight: '600', paddingVertical: 10 }}>{suggest?.Title}</Text>
			<FlatList
				style={{ height: '100%' }}
				keyExtractor={(item, index) => index?.toString()}
				data={data}
				renderItem={({ item, index }) => (
					<ItemSearchUser item={item} onSelectItem={onSelectItem} selected={selected} isField={isField} />
				)}
			/>
		</View>
	);
};

const SearchUser = ({ paramsProps, isComponent = false, onSelectUser, userProps, isField }) => {
	const dispatch = useAppDispatch();
	const route = useRoute<RouteProp<Params, 'Item'>>();
	const navigation = useNavigation();
	const inputRef = useRef<TextInput | null>(null);
	const [keyword, setKeyWord] = useState('');
	const [dataUser, setDataUser] = useState<Array<IUser>>([]);
	const [selected, setSelected] = useState<Array<IUser>>([]);
	const [DataSuggest, setDataSuggest] = useState<ISuggest[]>([]);

	const debounceInput = useDebounce(keyword, 300); // min 250ms

	const { options, user = [], RID = '', itemPrams, from } = isComponent ? paramsProps : route.params || {};

	const { isMultiple = false, type = 0, isAddInfo = true, NotifiedUsersInfo } = options || {};

	const notifiedUsersInfo: Array<IUser> = JSON.parse(NotifiedUsersInfo || '[]');
	const refUpdate = useRef(false);

	useEffect(() => {
		if (!isAddInfo) {
			gotoFirstPage();
		} else {
			let l: any[] = JSON.parse(JSON.stringify(notifiedUsersInfo));
			l = l.filter(
				elm =>
					elm?.Name.toLocaleLowerCase().includes(debounceInput.toLocaleLowerCase()) ||
					elm?.Email?.toLocaleLowerCase().includes(debounceInput.toLocaleLowerCase()),
			);
			setDataUser(l);
		}
	}, [debounceInput, isAddInfo]);

	useEffect(() => {
		const userParams = isComponent ? userProps : user;
		setSelected(userParams || []);
	}, [route.params, paramsProps, userProps]);

	const {
		state: { data: dataRes, refreshing },
		gotoFirstPage,
		refreshPage,
		fetchMore,
	} = useInfinity<Array<IUser>>(`${ENDPOINT.USERGROUP}`, {
		size: 10,
		requireAuthentication: true,
		params: {
			func: 'searchUserAndGroup',
			type, // 0: user only - 1; all user + group
			data: `{ Keyword: ${JSON.stringify(keyword)}}`,
		},
	});

	useEffect(() => {
		// inputRef.current?.focus();
		if (isAddInfo && notifiedUsersInfo) {
			setDataUser(notifiedUsersInfo);
		}
	}, [isAddInfo]);

	useEffect(() => {
		if (!isAddInfo) {
			setDataUser(dataRes?.Data || []);
			setDataSuggest(dataRes?.DataSuggest || []);
		}
	}, [dataRes]);

	const onChangeText = (text: string) => {
		setKeyWord(text);
	};

	const TrackingUser = (item: IUser) => {
		if (isAddInfo) return;
		dispatch(
			trackingUser({
				params: {
					Data: item?.ID,
					ResourceCategoryId: 8,
					ResourceSubCategoryId: 9,
					ActionCategoryId: item?.Type === 0 ? 58 : 59,
					ResourceId: RID,
				},
			}),
		);
	};

	useEffect(() => {
		setTimeout(() => {
			if (refUpdate.current) {
				refUpdate.current = false;
				if (from) {
					goBack({
						item: itemPrams,
						ParamsCallback: {
							data: selected,
							action: from,
						},
					});
				} else {
					onSelectUser(selected);
				}
			}
		}, 50);
	}, [selected]);

	const onSelectItem = (item: IUser, isSelected: boolean) => {
		try {
			if (!isMultiple) {
				setSelected([item]);
				TrackingUser(item);
				refUpdate.current = true;

				return;
			}
			if (isSelected) {
				setSelected(selected.filter(s => s.ID !== item.ID));
			} else {
				setSelected([...selected, item]);
				TrackingUser(item);
			}
		} catch (error) {
			console.log('error', error);
		}
	};

	const goBack = data => {
		navigation.navigate(from, data);
	};

	const insets = useSafeAreaInsets();

	const shadow = !isComponent
		? {
			shadowColor: '#000',
			shadowOffset: {
				width: 0,
				height: 1,
			},
			shadowOpacity: 0.2,
			shadowRadius: 2,
			elevation: 10,
		}
		: {};

	return (
		<KeyboardAvoidingView style={{ flex: 1, zIndex: 99 }} behavior="padding">
			<View
				style={[
					{
						flexDirection: 'row',
						alignItems: 'center',
						paddingBottom: 5,

						zIndex: 99,
						backgroundColor: 'white',
						paddingTop: !isComponent ? insets.top : 5,
						paddingHorizontal: !isComponent ? 20 : 10,

						borderWidth: !isComponent ? 0 : 1,
						marginHorizontal: !isComponent ? 0 : 16,
						borderRadius: !isComponent ? 0 : 8,
						borderColor: 'rgba(217, 217, 217, 1)',
					},
					shadow,
				]}>
				{!isComponent && (
					<Icon
						src={ICONS.icArrowMenu}
						width={24}
						height={24}
						onPress={() => {
							goBack({
								item: itemPrams,
								ParamsCallback: {
									data: user,
									action: from,
								},
							});
						}}
					/>
				)}
				<View style={styles.container}>
					<TextInput
						ref={inputRef}
						value={keyword}
						style={styles.textInput}
						placeholder={translate('search')}
						placeholderTextColor="rgba(94, 94, 94, 1)"
						onChangeText={onChangeText}
					/>
				</View>
			</View>

			{!dataUser?.length ? (
				keyword?.length ? (
					<Text style={{ fontSize: 12, fontStyle: 'italic', textAlign: 'center', paddingTop: 10 }}>
						{translate('noResult')}
					</Text>
				) : (
					<View style={{ flex: 1 }}>
						{DataSuggest?.map((suggest, index) => (
							<RenderSuggest
								key={index?.toString()}
								suggest={suggest}
								onSelectItem={onSelectItem}
								selected={selected}
								isField={isField}
							/>
						))}
					</View>
				)
			) : (
				<FlatList
					showsVerticalScrollIndicator={false}
					data={dataUser}
					keyExtractor={(item, index) => index?.toString()}
					renderItem={({ item, index }) => (
						<ItemSearchUser item={item} onSelectItem={onSelectItem} selected={selected} isField={isField} />
					)}
					contentContainerStyle={{ paddingBottom: 50, paddingHorizontal: 24, paddingTop: 20 }}
					keyboardDismissMode="on-drag"
				/>
			)}
			{isMultiple && !!selected?.length && (
				<View style={{ position: 'absolute', bottom: 0, width: '100%', backgroundColor: 'white' }}>
					<TouchableOpacity
						onPress={() => {
							if (!isComponent) {
								goBack({
									item: itemPrams,
									ParamsCallback: {
										data: selected,
										action: from,
									},
								});
							} else {
								onSelectUser(selected);
							}
						}}
						style={{
							backgroundColor: 'rgba(0, 95, 212, 1)',
							paddingVertical: 12,
							alignItems: 'center',
							marginBottom: 20,
							marginHorizontal: 20,
							borderRadius: 8,
						}}>
						<Text style={{ fontWeight: '600', color: 'white' }}>
							{translate('selected').toLocaleUpperCase()} {selected?.length ? `(${selected?.length})` : ''}
						</Text>
					</TouchableOpacity>
				</View>
			)}
		</KeyboardAvoidingView>
	);
};

export default SearchUser;

const styles = StyleSheet.create({
	container: {
		height: 38,
		// backgroundColor: '#F5F5F5',
		// borderRadius: 20,
		// justifyContent: 'center',
		paddingRight: 12,
		overflow: 'hidden',
		// marginHorizontal: 5,
		// marginBottom: 5,
		flexDirection: 'row',
		alignItems: 'center',
		flex: 1,
		marginLeft: 10,
	},

	textInput: { fontStyle: 'italic', flex: 1 },
});
