import React, { useEffect, useState } from 'react';

import CheckBox from '@react-native-community/checkbox';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { Header } from 'components/Organisms/Header';
import { COLORS, ICONS } from 'config';
import { Text, TextInput, View, StyleSheet, TouchableOpacity } from 'react-native';
import ReactNativeBlobUtil from 'react-native-blob-util';
import DocumentPicker from 'react-native-document-picker';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import SelectDropdown from 'react-native-select-dropdown';
import { useAppDispatch, useAppSelector } from 'stores';
import { addAttachment, editAttachment } from 'stores/TaskDetails';
import { fetchEditAttachment } from 'stores/TaskDetails/thunks';

const EditAttachments = () => {
	const navigation = useNavigation();
	const dispatch = useAppDispatch();
	const route = useRoute();
	const { item = {}, ID, type, onCallback, isTask, isAddTask, onSubmitAttach } = route.params || {};

	const isAdd = type === 'add';

	const details = useAppSelector(store => store.taskDetails.details);
	const ListAction = JSON?.parse(details?.FormConfig?.ListDocumentCategory || '[]');

	const [choices, setChoices] = useState('');
	const [listAction, setListAction] = useState([]);
	const [value, setValue] = useState('');
	const [file, setFile] = useState(null);

	useEffect(() => {
		if (ListAction?.length) {
			let action = [];
			ListAction.map(item => {
				action = [...action, item.Title];
			});
			setListAction(action);
		}
	}, [details]);

	useEffect(() => {
		if (item?.AttachTypeName) {
			setChoices(item.AttachTypeName);
		}
		if (item?.Title) {
			setValue(item.Title);
		}
	}, [item]);

	const findAttachType = () => {
		const res = ListAction?.find(e => e.Title === choices);
		return res;
	};

	const onSubmitClick = () => {
		if (!file) return;
		if (isTask) {
			if (isAddTask) {
				onCallback({
					CreatedName: 'qc.admin4@vuthao.vn',
					Extension: file.name.split('.')[1],
					IsAuthor: 1,
					Name: Math.floor(Math.random() * 100),
					Path: null,
					PositionName: 'Tổng giám đốc',
					Size: file.size,
					Title: file.name,
					Base64: file.Base64,
					PathLocal: file.uri,
					isAdd,
				});
			} else {
				dispatch(
					addAttachment({
						CreatedName: 'qc.admin4@vuthao.vn',
						Extension: file.name.split('.')[1],
						IsAuthor: 1,
						Name: Math.floor(Math.random() * 100),
						Path: null,
						PositionName: 'Tổng giám đốc',
						Size: file.size,
						Title: file.name,
						Base64: file.Base64,
						PathLocal: file.uri,
						isAdd,
					}),
				);
			}

			return navigation.goBack();
		}
		const selected = findAttachType();
		if (isAdd) {
			dispatch(
				addAttachment({
					AttachTypeId: selected?.ID || null,
					AttachTypeName: selected?.Title || null,
					CreatedName: 'qc.admin4@vuthao.vn',
					Extension: file.name.split('.')[1],
					IsAuthor: 1,
					Name: Math.floor(Math.random() * 100),
					Path: null,
					PositionName: 'Tổng giám đốc',
					Size: file.size,
					Title: file.name,
					Base64: file.Base64,
					PathLocal: file.uri,
				}),
			);
		} else if (item?.ID) {
			dispatch(
				fetchEditAttachment({
					rid: ID,
					data: {
						ID: item.ID,
						Title: value,
						Path: item.Path,
						AttachTypeId: selected?.ID,
						AttachTypeName: selected?.Title,
					},
				}),
			);
		} else {
			// edit
			dispatch(
				editAttachment({
					AttachTypeId: selected?.ID || null,
					AttachTypeName: selected?.Title || null,
					Name: item.Name,
				}),
			);
		}
		onSubmitAttach(selected?.ID);
		navigation.goBack();
	};

	const onPressAdd = () => {
		DocumentPicker.pickSingle().then(res => {
			ReactNativeBlobUtil.fs.readFile(res.uri.replace('file://', ''), 'base64').then(data => {
				setFile({ ...res, Base64: data });
			});
		});
	};

	const renderDropdownIcon = () => {
		return (
			<View>
				<Icon src={ICONS.icArrowDown} width={8} height={8} tintColor={COLORS.black} />
			</View>
		);
	};

	const renderCustomizedButtonChild = () => {
		return (
			<View>
				<Text>{choices?.toString()?.trim()}</Text>
			</View>
		);
	};

	const renderCustomizedRowChild = (e: string) => {
		return (
			<View
				style={{
					backgroundColor: 'rgba(194, 194, 194, 0.1)',
					flex: 1,
					alignItems: 'center',
					paddingHorizontal: 20,
					flexDirection: 'row',
				}}>
				<CheckBox disabled style={{ width: 14, height: 14 }} value={choices?.toString()?.trim() === e?.trim()} />
				<Text
					style={{
						color: choices?.toString()?.trim() === e?.trim() ? COLORS.blueMain : COLORS.black,
						marginLeft: 4,
					}}>
					{e?.trim()}
				</Text>
			</View>
		);
	};

	return (
		<SafeAreaView style={{ flex: 1 }} edges={['top']}>
			<Header iconLeftSrc={ICONS.icArrowLeft}>
				<Text numberOfLines={1} style={{ fontSize: 16, flex: 1, textAlign: 'center' }}>
					{isAdd ? 'Add' : 'Edit'} Attachments
				</Text>
			</Header>
			<View style={{ marginHorizontal: 20 }}>
				<View style={{ marginTop: 14 }}>
					<Text style={{ color: '#5E5E5E', fontSize: 11, marginBottom: 4 }}>{isAdd ? 'Tệp' : 'Tiêu đề(*)'}</Text>
					{isAdd ? (
						<View style={{ flexDirection: 'row' }}>
							<View
								style={{
									flexDirection: 'row',
									borderWidth: 0.3,
									borderColor: '#5E5E5E',
									borderRadius: 4,
									padding: 7,
									flex: 1,
								}}>
								<Text style={{ flex: 1 }}>{file?.name}</Text>
							</View>
							<TouchableOpacity
								onPress={onPressAdd}
								style={{
									backgroundColor: COLORS.lineGrey,
									borderRadius: 4,
									paddingHorizontal: 5,
									alignItems: 'center',
									justifyContent: 'center',
									borderWidth: 0.3,
									borderColor: '#5E5E5E',
									marginLeft: 2,
								}}>
								<Text style={{ fontSize: 12 }}>Chọn</Text>
							</TouchableOpacity>
						</View>
					) : (
						<View style={{ borderWidth: 0.5, padding: 8, borderRadius: 4, borderColor: '#5E5E5E' }}>
							<TextInput value={value} onChangeText={setValue} editable={!!item?.ID} />
						</View>
					)}
				</View>
				{!isTask && (
					<View style={{ marginTop: 14 }}>
						<Text style={{ color: '#5E5E5E', fontSize: 11, marginBottom: 4 }}>Loại tài liệu</Text>
						<SelectDropdown
							disabled={!listAction?.length}
							defaultValue={choices?.toString()?.trim()}
							data={listAction}
							dropdownOverlayColor="transparent"
							onSelect={(selectedItem: string) => {
								setChoices(selectedItem?.trim());
							}}
							renderDropdownIcon={renderDropdownIcon}
							renderCustomizedButtonChild={renderCustomizedButtonChild}
							rowStyle={styles.rowStyle}
							rowTextStyle={styles.rowTextStyle}
							dropdownStyle={styles.dropdownStyle}
							renderCustomizedRowChild={renderCustomizedRowChild}
							buttonStyle={styles.buttonStyle}
							buttonTextStyle={styles.buttonTextStyle}
						/>
					</View>
				)}

				<View>
					<TouchableOpacity
						onPress={onSubmitClick}
						style={{
							paddingVertical: 10,
							backgroundColor: '#005FD4',
							alignItems: 'center',
							borderRadius: 4,
							marginVertical: 20,
						}}>
						<Text style={{ color: COLORS.white, fontWeight: '700' }}>Save</Text>
					</TouchableOpacity>
				</View>
			</View>
		</SafeAreaView>
	);
};

export default EditAttachments;

const styles = StyleSheet.create({
	containerCheckBox: { flexDirection: 'row' },
	itemCheckBox: { flexDirection: 'row', marginRight: 20 },
	checkBox: { width: 16, height: 16 },
	nameCheckBox: { fontSize: 14, color: COLORS.black, marginLeft: 4 },
	title: { fontSize: 14, color: COLORS.blueMain, marginLeft: 4 },
	rowStyle: { backgroundColor: COLORS.white, height: 36 },
	rowTextStyle: { backgroundColor: COLORS.white },
	dropdownStyle: { backgroundColor: COLORS.white, borderRadius: 4 },
	buttonStyle: {
		height: 30,
		width: '100%',
		borderColor: COLORS.davyGrey,
		borderWidth: 0.5,
		alignItems: 'center',
		borderRadius: 4,
		backgroundColor: COLORS.white,
	},
	buttonTextStyle: { color: COLORS.black, fontSize: 14, textAlign: 'left' },
	multiSelect: {
		minHeight: 28,
		borderBottomColor: 'gray',
		borderWidth: 0.5,
		width: '100%',
		paddingHorizontal: 10,
		borderRadius: 4,
	},
	viewItemMulti: {
		paddingHorizontal: 15,
		paddingVertical: 5,
	},
	containerRadio: {
		flexDirection: 'row',
		marginRight: 20,
		flexWrap: 'wrap',
		overflow: 'hidden',
	},
	buttonRadio: {
		flexDirection: 'row',
		marginRight: 20,
		padding: 5,
	},
	viewRadio: {
		width: 18,
		height: 18,
		borderWidth: 1,
		borderRadius: 10,

		alignItems: 'center',
		justifyContent: 'center',
	},
	checked: { backgroundColor: COLORS.blueMain, width: 9, height: 9, borderRadius: 9 },
	viewMulti: {
		paddingVertical: 5,
		width: '90%',
		flexDirection: 'row',
		alignItems: 'center',
		zIndex: 1,
		overflow: 'hidden',
		flexWrap: 'wrap',
	},
	titleContaier: { color: COLORS.davyGrey, fontSize: 11, marginBottom: 4 },
});
