/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-underscore-dangle */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-shadow */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import React, { useEffect, useState, useRef } from 'react';

import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { ICONS } from 'config';
import useSystem from 'hooks/useSystem';
import {
	Text,
	View,
	TouchableOpacity,
	Keyboard,
	ScrollView,
	FlatList,
	Platform,
	KeyboardAvoidingView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppDispatch } from 'stores';
import { getFormGirdDetails } from 'stores/Workflows/sliceWorkflow';
import { IItemInfo } from 'stores/Workflows/types';
import { exportFieldTypeIdWithFTypeId } from 'utils/functions';
import { translate } from 'utils/translate';

import Calculated from '../Field/Calculated';
import Choose from '../Field/Choose';
import Currency from '../Field/Currency';
import DateTime from '../Field/DateTime';
import Lookup from '../Field/Lookup';
import LookupDataSource from '../Field/LookupDataSource';
import MultipleLines from '../Field/MultipleLines';
import NumberField from '../Field/Number';
import Radio from '../Field/Radio';
import SingleLine from '../Field/SingleLine';
import UserGroup from '../Field/UserGroup';

const HeaderEdit = ({
	title,
	onDeleteRow,
	isAdd,
	isPermissionEdit,
}: {
	title: string;
	onDeleteRow: () => void;
	isAdd: boolean;
	isPermissionEdit: boolean;
}) => {
	const navigation = useNavigation();

	return (
		<View
			style={{
				flexDirection: 'row',
				shadowColor: '#000',
				shadowOffset: {
					width: 0,
					height: 2,
				},
				shadowOpacity: 0.1,
				shadowRadius: 2,

				elevation: 5,
				backgroundColor: 'white',
				paddingBottom: 10,
				paddingHorizontal: 16,
			}}>
			<View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
				<Icon
					src={ICONS.icArrowMenu}
					width={24}
					height={24}
					tintColor="rgba(0, 0, 0, 1)"
					onPress={() => navigation.goBack()}
				/>
				<Text numberOfLines={1} style={{ fontSize: 16, fontWeight: '700', marginLeft: 12, color: 'rgba(0, 0, 0, 1)' }}>
					{title}
				</Text>
			</View>
			{!isAdd && isPermissionEdit && (
				<Icon src={ICONS.icTrash} width={20} height={20} onPress={onDeleteRow} tintColor="red" />
			)}
		</View>
	);
};
type Params = {
	Item: {
		item: IItemInfo;
		ID: number;
		detailsListInfo: {
			listID: string;
			WorkflowId: string;
		};
		isPermissionEdit: boolean;
		isAdd: boolean;
		ListIDAdd: number[];
		onCallbackData: (value: { data: IItemInfo; action: string; ListData?: any[] }) => void;
		detailsFieldInfoCollection: any[];
		title: string;
	};
};

const EditGridDeatils = () => {
	const navigation = useNavigation();
	const refFieldGrid = useRef<any>({});
	const { lid, isVN } = useSystem();
	const refDefaultDetailInfo = useRef('{}');

	const refInfoItem = useRef({});

	const route = useRoute<RouteProp<Params, 'Item'>>();
	const dispatch = useAppDispatch();
	const {
		item,

		detailsListInfo,
		detailsFieldInfoCollection = [],
		isPermissionEdit,
		isAdd = false,
		ListIDAdd = [],
		onCallbackData,
		title,
	} = route.params;

	const isPermission = isAdd || isPermissionEdit;

	const [listControl, setListControl] = useState<any[]>([]);
	const [itemInfo, setItemInfo] = useState<IItemInfo>(item);
	const [formField, setFormField] = useState<{ Name: string; Guid: string; FieldTypeId: number; FieldType: number }[]>(
		[],
	);

	useEffect(() => {
		if (isAdd) {
			let arr: IItemInfo = {};
			const ojbDefaultDetailInfo = JSON.parse(refDefaultDetailInfo.current) || {};
			formField.forEach((element: { Name: string }) => {
				arr = { ...arr, [element.Name]: ojbDefaultDetailInfo?.[element?.Name] || null };
			});
			setItemInfo(arr);
		} else {
			refInfoItem.current = item;
			setItemInfo(item);
		}
	}, [formField, isAdd, item]);

	const successCallback = (res: { data: { FormFieldInfo: any[]; DefaultDetailInfo: string } }) => {
		const { FormFieldInfo, DefaultDetailInfo = '{}' } = res.data;
		refDefaultDetailInfo.current = DefaultDetailInfo;
		let form: any[] = [];
		detailsFieldInfoCollection?.forEach((element: { internalName: any }) => {
			const item: any = FormFieldInfo?.find((elm: { Name: string }) => elm?.Name === element?.internalName);
			if (item) {
				form = [...form, item];
			}
		});

		setFormField(form);
		setListControl(res.data?.FormFieldInfo);
	};

	useEffect(() => {
		if (detailsListInfo?.listID) {
			dispatch(
				getFormGirdDetails({
					params: {
						listid: detailsListInfo?.listID,
						wid: detailsListInfo?.WorkflowId || 0,
						lid,
						flag: 1,
						detailsListInfo,
						detailsFieldInfoCollection,
					},
					success: successCallback,
				}),
			);
		}
	}, [detailsListInfo]);

	const getDataField = (name: string) => {
		const data: {
			Title: string;
			TitleEN: string;
			FieldTypeId: number;
			Option: string | any;
			Guid: string;
			FieldType: number;
		} = listControl?.find((list: { Name: string }) => list.Name === name);

		const { Title = '', TitleEN = '', FieldTypeId = 0, Option = '', Guid = '', FieldType = 0 } = data || {};

		let FTypeId = 0;

		if (FieldType) {
			FTypeId = exportFieldTypeIdWithFTypeId(FieldType);
		}

		return {
			Title: isVN ? Title : TitleEN,
			FieldTypeId: FieldTypeId || FTypeId,
			Option: typeof Option === 'string' ? Option : JSON.stringify(Option),
			Guid,
		};
	};

	const editDetailsGrid = (res: { name: any; text: any }) => {
		let data = item;
		data = {
			...data,
			...{
				[res.name]: Number(res.text),
			},
		};

		setItemInfo(data);
	};

	const onUpdateValueGrid = (value: IItemInfo) => {
		setItemInfo(old => {
			return { ...old, ...value };
		});
	};

	const checkRequire = () => {
		try {
			let passing = true;
			listControl.forEach(field => {
				const require = refFieldGrid.current?.[field?.Guid]?.require();
				if (require === false) passing = false;
			});
			return passing;
		} catch (error) {
			//
		}
	};
	// eslint-disable-next-line react/no-unstable-nested-components
	const RenderFeild = (listItem: { Name: string }) => {
		const internalName = listItem?.Name;
		const Field = getDataField(internalName);
		const { Title, FieldTypeId, Option, Guid } = Field;

		const setFeildRef = (ref: any) => {
			refFieldGrid.current[Guid] = ref;
		};
		switch (FieldTypeId) {
			case 1:
				return (
					<SingleLine
						ref={setFeildRef}
						title={Title}
						itemInfoGrid={itemInfo}
						onUpdateValueGrid={onUpdateValueGrid}
						options={Option}
						internalName={internalName}
						isGrid
						isEditGrid={isPermission}
					/>
				);
			case 2:
				return (
					<MultipleLines
						ref={setFeildRef}
						title={Title}
						itemInfoGrid={itemInfo}
						onUpdateValueGrid={onUpdateValueGrid}
						options={Option}
						internalName={internalName}
						isGrid
						isEditGrid={isPermission}
					/>
				);
			case 3:
				return (
					<Choose
						ref={setFeildRef}
						title={Title}
						options={Option}
						internalName={internalName}
						itemInfoGrid={itemInfo}
						onUpdateValueGrid={onUpdateValueGrid}
						isGrid
						isEditGrid={isPermission}
					/>
				);
			case 4:
				return (
					<NumberField
						ref={setFeildRef}
						title={Title}
						itemInfoGrid={itemInfo}
						onUpdateValueGrid={onUpdateValueGrid}
						options={Option}
						internalName={internalName}
						// listCatulated={listCatulated}
						isGrid
						editDetailsGrid={editDetailsGrid}
						isEditGrid={isPermission}
					/>
				);
			case 5:
				return (
					<DateTime
						ref={setFeildRef}
						title={Title}
						itemInfoGrid={itemInfo}
						onUpdateValueGrid={onUpdateValueGrid}
						options={Option}
						internalName={internalName}
						isGrid
						isEditGrid={isPermission}
					/>
				);
			case 7:
				return (
					<UserGroup
						ref={setFeildRef}
						title={Title}
						itemInfoGrid={itemInfo}
						onUpdateValueGrid={onUpdateValueGrid}
						options={Option}
						internalName={internalName}
						isGrid
						isEditGrid={isPermission}
					/>
				);
			case 8:
				return (
					<Currency
						ref={setFeildRef}
						title={Title}
						itemInfoGrid={itemInfo}
						onUpdateValueGrid={onUpdateValueGrid}
						options={Option}
						internalName={internalName}
						isGrid
						isEditGrid={isPermission}
					/>
				);
			case 9:
				return (
					<Calculated
						ref={setFeildRef}
						title={Title}
						itemInfoGrid={itemInfo}
						onUpdateValueGrid={onUpdateValueGrid}
						options={Option}
						internalName={internalName}
						FieldInfo={itemInfo}
						// sendCaculated={sendCaculated}
						isGrid
						isEditGrid={isPermission}
					/>
				);
			case 10:
				return (
					<Radio
						ref={setFeildRef}
						title={Title}
						options={Option}
						internalName={internalName}
						isGrid
						itemInfoGrid={itemInfo}
						onUpdateValueGrid={onUpdateValueGrid}
						isEditGrid={isPermission}
					/>
				);
			case 13:
				return (
					<Lookup
						ref={setFeildRef}
						title={Title}
						options={Option}
						internalName={internalName}
						Guid={Guid}
						itemInfoGrid={itemInfo}
						onUpdateValueGrid={onUpdateValueGrid}
						isGrid
						isEditGrid={isPermission}
					/>
				);
			case 14:
				return (
					<Lookup
						ref={setFeildRef}
						title={Title}
						options={Option}
						internalName={internalName}
						Guid={Guid}
						itemInfoGrid={itemInfo}
						onUpdateValueGrid={onUpdateValueGrid}
						isGrid
						isEditGrid={isPermission}
					/>
				);

			case 18:
				return (
					<LookupDataSource
						ref={setFeildRef}
						title={Title}
						itemInfoGrid={itemInfo}
						onUpdateValueGrid={onUpdateValueGrid}
						options={Option}
						internalName={internalName}
						Guid={Guid}
						isGrid
						isEditGrid={isPermission}
					/>
				);

			default:
				return null;
		}
	};

	const onSubmitData = () => {
		const rq = checkRequire();

		function getValue(Name: string, FieldTypeId: number) {
			const valueItem = itemInfo?.[Name];

			if ([7].includes(FieldTypeId)) {
				const data = Array.isArray(valueItem)
					? valueItem
					: JSON.parse(typeof valueItem === 'string' ? valueItem : '[]');

				let id: string[] = [];
				const list = data || [];
				if (Array.isArray(list)) {
					list?.forEach((item: { ID: string }) => {
						id = [...id, item.ID];
					});
				}
				return id.toString();
			}
			if ([13, 14].includes(FieldTypeId)) {
				const ArrValueSplit: string[] = typeof valueItem === 'string' ? valueItem?.split(';#') : [];
				const Value: string[] = ArrValueSplit?.filter((item: string) => item !== '')?.filter(
					(_: any, index: number) => index % 2 === 0,
				);

				return Value?.toString();
			}
			return valueItem?.toString();
		}
		// add
		if (rq) {
			let ListData: {
				Name: string;
				Guid: string;
				Value: string;
				FieldTypeId: number;
			}[] = [];
			if (isAdd || ListIDAdd?.includes(itemInfo?._ID_)) {
				formField?.forEach((e: { Name: string; Guid: string; FieldTypeId: number; FieldType: number }) => {
					const infoField: { Name: string; Guid: string; FieldTypeId: number } = listControl?.find(
						(field: { Name: string }) => field?.Name === e.Name,
					);

					let FTypeId = e?.FieldTypeId || 0;
					if (e?.FieldType) {
						FTypeId = exportFieldTypeIdWithFTypeId(e?.FieldType);
					}

					const convertData = {
						Name: infoField?.Name,
						Guid: infoField?.Guid,
						Value: getValue(e.Name, FTypeId),
						FieldTypeId: FTypeId,
						// DetailsListInfo: detailsListInfo,
					};
					ListData = [...ListData, convertData];
				});
			} else {
				const defaultInfo: IItemInfo = refInfoItem.current;
				const changedKeys: IItemInfo = {};

				for (const key in defaultInfo) {
					if (defaultInfo[key] !== itemInfo[key]) {
						changedKeys[key] = itemInfo[key];
					}
				}
				const listNameChanged = Object.keys(changedKeys);
				formField.forEach((elm: { Name: string; Guid: string; FieldTypeId: number; FieldType: number }) => {
					let FTypeId = elm?.FieldTypeId || 0;
					if (elm?.FieldType) {
						FTypeId = exportFieldTypeIdWithFTypeId(elm?.FieldType);
					}
					if (listNameChanged.includes(elm.Name)) {
						const convertData = {
							Name: elm?.Name,
							Guid: elm?.Guid,
							Value: getValue(elm.Name, FTypeId),
							FieldTypeId: FTypeId,
						};
						ListData = [...ListData, convertData];
					}
				});
			}
			onCallbackData({
				data: itemInfo,
				action: isAdd ? 'add' : 'edit',
				ListData,
			});
			navigation.goBack();
		}
	};

	const onPressDelete = () => {
		onCallbackData({
			data: itemInfo,
			action: 'delete',
		});
		navigation.goBack();
	};

	return (
		<SafeAreaView style={{ flex: 1 }} edges={['top']}>
			<HeaderEdit title={title} onDeleteRow={onPressDelete} isAdd={isAdd} isPermissionEdit={isPermissionEdit} />
			<KeyboardAvoidingView
				behavior={Platform.OS === 'ios' ? 'padding' : undefined}
				style={{ flex: 1 }}
				keyboardVerticalOffset={10}>
				<ScrollView
					showsVerticalScrollIndicator={false}
					keyboardShouldPersistTaps="handled"
					onScrollBeginDrag={Keyboard.dismiss}
					contentContainerStyle={{ flexGrow: 1 }}>
					<View style={{ paddingLeft: 10, paddingRight: 10 }}>
						<FlatList
							// inverted
							scrollEnabled={false}
							initialNumToRender={10}
							maxToRenderPerBatch={5}
							updateCellsBatchingPeriod={5}
							renderToHardwareTextureAndroid
							removeClippedSubviews={Platform.OS !== 'ios'}
							nestedScrollEnabled={false}
							contentContainerStyle={{ flex: 1 }}
							data={formField}
							keyExtractor={(item, index) => index?.toString()}
							renderItem={({ item }) => {
								return <View style={{ marginBottom: 20 }}>{RenderFeild(item)}</View>;
							}}
						/>
					</View>
				</ScrollView>
			</KeyboardAvoidingView>
			{isPermission && (
				<View>
					<TouchableOpacity
						onPress={onSubmitData}
						style={{
							backgroundColor: 'rgba(0, 95, 212, 1)',
							paddingVertical: 12,
							borderRadius: 8,
							marginHorizontal: 16,
							marginBottom: 24,
							alignItems: 'center',
							justifyContent: 'center',
						}}>
						<Text style={{ color: 'white', fontWeight: '600' }}>{translate('completed')}</Text>
					</TouchableOpacity>
				</View>
			)}
		</SafeAreaView>
	);
};

export default EditGridDeatils;
