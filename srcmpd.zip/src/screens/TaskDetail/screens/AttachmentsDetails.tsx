import React from 'react';

import { RouteProp, useRoute } from '@react-navigation/native';
import { Header } from 'components/Organisms/Header';
import { ICONS } from 'config';
import { Text, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import Attachments from '../Field/Attachments';

type ItemParams = {
	ID: string;
};

type Params = {
	Item: {
		item: ItemParams;
	};
};

const AttachmentsDetails = () => {
	const route = useRoute<RouteProp<Params, 'Item'>>();
	const itemPrams: ItemParams = route.params.item || {};
	const { ID } = itemPrams;
	return (
		<SafeAreaView style={{ flex: 1 }} edges={['top']}>
			<Header iconLeftSrc={ICONS.icArrowLeft}>
				<Text numberOfLines={1} style={{ fontSize: 16, textAlign: 'center', flex: 1 }}>
					Chi tiết đính kèm
				</Text>
			</Header>
			<ScrollView style={{ paddingHorizontal: 10 }}>
				<Attachments ID={ID} />
			</ScrollView>
		</SafeAreaView>
	);
};

export default AttachmentsDetails;
