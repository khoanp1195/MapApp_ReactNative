/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable import/no-cycle */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable array-callback-return */
import React, { forwardRef, useImperativeHandle, useRef } from 'react';

import GridPreview from 'components/WorkflowDetails/Grid/GirdPreview';
import useSystem from 'hooks/useSystem';
import {
	Platform,
	View,
	FlatList,
	TouchableHighlight,
	TouchableWithoutFeedback,
	TouchableHighlightBase,
	TouchableOpacity,
} from 'react-native';
import { IItemParams } from 'screens/WorkflowDetails/WorkflowDetails';
import { useAppSelector } from 'stores';

import Calculated from './Field/Calculated';
import Choose from './Field/Choose';
import Currency from './Field/Currency';
import DateTime from './Field/DateTime';
import GridDetails from './Field/GridDetails';
import Lookup from './Field/Lookup';
import LookupDataSource from './Field/LookupDataSource';
import MultipleLines from './Field/MultipleLines';
import NumberField from './Field/Number';
import Radio from './Field/Radio';
import SingleLine from './Field/SingleLine';
import UserGroup from './Field/UserGroup';

export interface FormFieldInfoPrams {
	FieldMapping: string;
	FieldTypeId: number;
	Guid: string;
	ID: number;
	ListId: string;
	Name: string;
	Option?: string;
	Status: number;
	Title: string;
	TitleEN: string;
	WorkflowId: number;
}

interface RowDefineInfoCollection {
	author: string;
	className: string;
	id: string;
	internalName: string;
}

export interface FormsParams {
	FormFieldInfo: Array<FormFieldInfoPrams>;
	InfoCollection: {
		FormDefineInfo: string;
	};
	rid: number;
}

export interface ItemParams {
	ID?: number;
	ListID?: string;
	WorkflowId?: string;
	IsFollow?: boolean;
	SPItemId?: string;
}

// Flag init frame => Disable call funtion Calculate
// InfoItem default => not change
// InfoItem for Details => update when request change data field => Render JSX
// InfoItem for Calculate => allway update when change all data in field  => Used calculate field

const TaskDetailScreen = ({ forms, itemPrams }: { forms: FormsParams; itemPrams: IItemParams }, ref) => {
	const fieldRef = useRef<any>({});

	const { isVN } = useSystem();
	const { ID, SPItemId } = itemPrams;

	const { FormFieldInfo, InfoCollection } = forms || {};
	const FormDefineInfo = InfoCollection?.FormDefineInfo || '[]';
	const rowInfo: RowDefineInfoCollection[][] = JSON.parse(FormDefineInfo || '[]')?.[0]?.rowDefineInfoCollection || [];

	const { details, listFieldNameHides } = useAppSelector(store => store.workflow);
	const { DefindJsonObj = '{}' } = details?.FormConfig || {}; // ListDocumentCategory
	const { FieldNameHides = '' } = JSON.parse(DefindJsonObj || '{}');
	const checkRequire = () => {
		try {
			let passing = true;
			FormFieldInfo.forEach(field => {
				const require = fieldRef.current?.[field?.Guid]?.require();
				if (require === false) passing = false;
			});
			return passing;
		} catch (error) {
			//
		}
	};

	const getGrid = guid => {
		try {
			return fieldRef.current?.[guid]?.getGrid();
		} catch (error) {
			return undefined;
		}
	};

	const getDataGrid = () => {
		//  fieldRef.current[getDataGrid]?.getDataGrid();
		FormFieldInfo.forEach(elm => {
			if (fieldRef.current?.[elm.Guid]?.getDataGrid) {
				fieldRef.current[elm.Guid]?.getDataGrid();
			}
		});
	};

	useImperativeHandle(
		ref,
		() => ({
			getGrid,
			getDataGrid,
			require: checkRequire,
		}),
		[],
	);

	// const listDocumentCategory = JSON.parse(ListDocumentCategory || '[]')?.filter(
	// 	item => item.Step !== details.FormConfig.Step,
	// );
	// ListDocumentCategory.Step === FieldInfo.Step => Yeu cau Attachments Phai co file voi Required: true

	// const [rowInfo, setRowInfo] = useState<Array<RowDefineInfoCollection> | []>([]);
	// const [attachment, setAttachment] = useState<{ allowAttach: boolean }>({});

	// useEffect(() => {
	// 	if (route.params?.isScrollToTop) {
	// 		refScrollView.current?.scrollTo({
	// 			y: 0,
	// 			animated: true,
	// 		});
	// 	}
	// }, [route]);

	// useEffect(() => {
	// 	if (forms?.InfoCollection?.FormDefineInfo) {
	// 		const data: Array<RowDefine> = JSON.parse(forms?.InfoCollection?.FormDefineInfo || '[]');
	// 		// const isAttachment = data?.[0]?.moreOptionInfo?.allowAttach;
	// 		// if (isAttachment) {
	// 		// 	setAttachment(data?.[0]?.moreOptionInfo);
	// 		// }
	// 		const rowData: RowDefine = data?.[0];
	// 		setRowInfo(rowData?.rowDefineInfoCollection);
	// 	}
	// }, [forms]);

	const getDataField = (name: string) => {
		const data: FormFieldInfoPrams | undefined = FormFieldInfo?.find(list => list.Name === name);
		const { Title = '', TitleEN = '', FieldTypeId = 0, Option: options = '', Guid = '' } = data || {};
		const title = isVN ? Title : TitleEN;
		return {
			title,
			FieldTypeId,
			options,
			Guid,
			TitleEN,
		};
	};

	// eslint-disable-next-line react/no-unstable-nested-components
	const RenderFeild = (internalName: string, index) => {
		const isHideFiled = FieldNameHides?.includes(internalName?.replace('_17_', '')?.replace('_Mobile', ''));
		const islNameHides = listFieldNameHides?.includes(internalName?.replace('_17_', '')?.replace('_Mobile', ''));
		if (isHideFiled || islNameHides) return null;

		// if (internalName === '_18_' && attachment?.allowAttach)
		// 	return <Attachments ref={refAttachment} ID={ID} ListDocumentCategory={ListDocumentCategory} />;

		const Field = getDataField(internalName?.replace('_17_', '')?.replace('_Mobile', '')); // _Mobile is not supported
		const { title, FieldTypeId, options, Guid } = Field;
		const setFeildRef = (ref: any) => {
			fieldRef.current[Guid] = ref;
		};

		if (internalName?.includes('_17_') && FieldTypeId) {
			return (
				<GridPreview
					ref={setFeildRef}
					title={title}
					internalName={internalName}
					ID={ID}
					SPItemId={SPItemId || details?.FormConfig?.SPItemId}
					forms={forms}
					refreshing={false}
					options={options}
					itemPrams={itemPrams}
				/>
			);
		}

		switch (FieldTypeId) {
			case 1:
				return <SingleLine ref={setFeildRef} title={title} options={options} internalName={internalName} />;
			case 2:
				return <MultipleLines ref={setFeildRef} title={title} options={options} internalName={internalName} />;
			case 3:
				return (
					<Choose
						ref={setFeildRef}
						title={title}
						options={options}
						internalName={internalName}
						refreshing={false}
						index={index}
					/>
				);
			case 4:
				return (
					<NumberField ref={setFeildRef} title={title} options={options} internalName={internalName} Guid={Guid} />
				);
			case 5:
				return <DateTime ref={setFeildRef} title={title} options={options} internalName={internalName} />;
			case 7:
				return (
					<UserGroup
						ref={setFeildRef}
						title={title}
						options={options}
						internalName={internalName}
						ID={ID}
						index={index}
					/>
				);
			case 8:
				return <Currency ref={setFeildRef} title={title} options={options} internalName={internalName} />;
			case 9:
				return <Calculated ref={setFeildRef} title={title} options={options} internalName={internalName} />;
			case 10:
				return <Radio ref={setFeildRef} title={title} options={options} internalName={internalName} />;
			case 13:
				return (
					<Lookup
						index={index}
						ref={setFeildRef}
						title={title}
						options={options}
						internalName={internalName}
						Guid={Guid}
						refreshing={false}
						FieldInfo={FormFieldInfo}
					/>
				);
			case 14:
				return (
					<Lookup
						index={index}
						ref={setFeildRef}
						title={title}
						options={options}
						internalName={internalName}
						Guid={Guid}
						refreshing={false}
						FieldInfo={FormFieldInfo}
					/>
				);

			case 18:
				return (
					<LookupDataSource
						ref={setFeildRef}
						title={title}
						options={options}
						internalName={internalName}
						Guid={Guid}
						index={index}
					/>
				);

			default:
				return null;
		}
	};

	// const handleKeyboard =() =>{

	// }

	// const getFormData = () => {
	// 	let ListData: Array<any> = [];
	// 	let isStop = false;
	// 	FieldInfo?.map(fieldInfo => {
	// 		let detailsListInfo = null;
	// 		const data: Array<{
	// 			detailsTableInfoCollection: any;
	// 		}> = JSON.parse( forms?.InfoCollection?.FormDefineInfo || '[]');
	// 		const detailsTableInfoCollection: Array<any> = (data?.length && data[0].detailsTableInfoCollection) || [];

	// 		detailsTableInfoCollection?.map((res: { id: string; detailsListInfo: any }) => {
	// 			if (res.id === fieldInfo?.Guid) {
	// 				detailsListInfo = res.detailsListInfo;
	// 			}
	// 		});

	// 		const { isRequired, value, isEdited } = fieldRef.current[fieldInfo?.Guid]?.getData() || {};

	// 		if (isRequired) {
	// 			if (isEdited) {
	// 				if (value) {
	// 					const convertData = {
	// 						Name: fieldInfo?.Name,
	// 						Guid: fieldInfo?.Guid,
	// 						Value: value,
	// 						FieldTypeId: fieldInfo?.FieldTypeId,
	// 						DetailsListInfo: detailsListInfo,
	// 					};
	// 					ListData = [...ListData, convertData];
	// 				} else {
	// 					isStop = true;
	// 				}
	// 			}
	// 		} else if (value !== undefined) {
	// 			const convertData = {
	// 				Name: fieldInfo?.Name,
	// 				Guid: fieldInfo?.Guid,
	// 				Value: value,
	// 				FieldTypeId: fieldInfo?.FieldTypeId,
	// 				DetailsListInfo: detailsListInfo,
	// 			};
	// 			ListData = [...ListData, convertData];
	// 		}
	// 	});
	// 	if (isStop) return null;
	// 	return ListData;
	// };

	// NEXT APPROVE => confirm submit
	// FormConfig.DocStatus == 3
	// const workflowrelated = workflowRef.current?.getListWorkflowRelated();
	// const attach = refAttachment.current?.getData();

	// const formData: Array<any> = getFormData();
	// if (formData === null && action.ActionCode !== 'NEWRELATED') {
	// 	return Alert.alert('Please insert all  forms fields');
	// }
	// if (attach === null && action.ActionCode !== 'NEWRELATED') {
	// 	return Alert.alert('Please add attachments');
	// }

	const getItemLayout = (_data: unknown, index: number) => ({
		length: 70,
		offset: 70 * index,
		index,
	});

	const renderItem = ({ item }: { item: RowDefineInfoCollection[] }) => {
		if (!item?.length) return null;
		return (
			<View
				style={{
					// marginVertical: 10,
					flexDirection: 'row',
					justifyContent: 'space-between',
					flex: 1,
					marginHorizontal: 16,
				}}>
				{item?.map((listItem: RowDefineInfoCollection) => {
					return (
						<View style={{ flex: 1 }} key={listItem.id}>
							{RenderFeild(listItem.internalName, item.length)}
						</View>
					);
				})}
			</View>
		);
	};

	return (
		<View style={{ flex: 1, backgroundColor: 'white' }}>
			{/* <TouchableOpacity onPress={handleKeyboard} activeOpacity={1}> */}
			<FlatList
				// inverted
				data={rowInfo || []}
				keyExtractor={(item, index) => index?.toString()}
				renderItem={renderItem}
				getItemLayout={getItemLayout}
				scrollEnabled={false}
				initialNumToRender={10}
				maxToRenderPerBatch={10}
				updateCellsBatchingPeriod={10}
				renderToHardwareTextureAndroid
				removeClippedSubviews={Platform.OS !== 'ios'}
				nestedScrollEnabled={false}
				contentContainerStyle={{ flex: 1 }}
				shouldRasterizeIOS
			/>
			{/* </TouchableOpacity> */}
		</View>
	);
};

export default forwardRef(TaskDetailScreen);
