/* eslint-disable import/no-extraneous-dependencies */
import React, { useEffect } from 'react';

import { Icon } from 'components/Atoms/Icon';
import { ICONS } from 'config';
import { View, ImageBackground, Text, ActivityIndicator } from 'react-native';
import DeviceInfo from 'react-native-device-info';
import { useAppDispatch, useAppSelector } from 'stores';
import { fetchCustomerInformation, updateSplash } from 'stores/Auth';
import { fetchBeanAppStatus, fetchBeanWorkflowStatus, fetchSettingSystem } from 'stores/System';
import { updateLoadingUser } from 'stores/System/reducer';

const SplashScreen = () => {
	const dispatch = useAppDispatch();

	const loadingUser = useAppSelector(store => store.system.loadingUser);
	const isLogin = useAppSelector(store => store.dataNotRemove.isLogin);

	useEffect(() => {
		if (!loadingUser) {
			dispatch(updateSplash(false));
		}
	}, [loadingUser]);

	useEffect(() => {
		async function CallInitApi() {
			await Promise.allSettled([
				dispatch(fetchBeanAppStatus()),
				dispatch(fetchBeanWorkflowStatus()),
				dispatch(fetchSettingSystem()),
				dispatch(fetchCustomerInformation()),
			]);
			dispatch(updateLoadingUser(false));
		}
		try {
			if (isLogin) {
				CallInitApi();
			} else {
				setTimeout(() => {
					dispatch(updateLoadingUser(false));
				}, 1000);
			}
		} catch (error) {
			//
		}
	}, []);

	return (
		<ImageBackground source={ICONS.bgSplash} style={{ width: '100%', height: '100%', alignItems: 'center' }}>
			<View style={{ alignItems: 'center', justifyContent: 'center', marginTop: 200 }}>
				<View
					style={{
						width: 95,
						height: 95,
						borderRadius: 50,
						backgroundColor: 'rgba(26,50,65, 1)',
						alignItems: 'center',
						justifyContent: 'center',
					}}>
					<Icon src={ICONS.icLogo} width={54} height={36} />
				</View>
				<Text
					style={{
						color: 'white',
						fontSize: 32,
						fontWeight: '800',
						marginTop: 6,
						marginBottom: 12,
						textAlign: 'center',
					}}>
					Digital Process Management
				</Text>
				<Text style={{ color: 'white', fontSize: 12 }}>Version: {DeviceInfo.getVersion()} © Vu Thao Company</Text>
			</View>
			<View style={{ marginTop: 80 }}>
				<ActivityIndicator size="small" />
			</View>
		</ImageBackground>
	);
};

export default SplashScreen;
