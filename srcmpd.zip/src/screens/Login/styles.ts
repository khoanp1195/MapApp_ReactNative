import { COLORS } from 'config';
import styled from 'styled-components/native';

export const Container = styled.ImageBackground`
	flex: 1;
	padding: 0px 32px;
`;
export const Header = styled.View`
	flex: 1;
	justify-content: center;
`;
export const LoginWrap = styled.View`
	flex-direction: row;
`;
export const Footer = styled.View`
	flex: 1;
	justify-content: space-around;
	align-items: center;
`;
export const Logo = styled.View`
	flex-direction: row;
	align-items: center;
	align-self: center;
`;

export const LoginButton = styled.TouchableOpacity`
	border-radius: 5px;
	flex: 1;
	padding: 12px;
	justify-content: center;
	align-items: center;
	align-self: center;
	background-color: ${COLORS.trueBlue};
`;

export const LoginFaceIDButton = styled.TouchableOpacity`
	border-radius: 5px;
	padding: 5px;
	justify-content: center;
	align-items: center;
	align-self: center;
	margin-left: 16px;
	background-color: ${COLORS.trueBlue};
`;

export const WaitWrap = styled.View`
	padding: 7px;
	align-items: center;
	justify-content: center;
	border: 1px dashed #eb342e;
	min-width: 70%;
`;
