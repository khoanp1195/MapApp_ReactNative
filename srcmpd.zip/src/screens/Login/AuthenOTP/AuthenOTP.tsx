import React, { useEffect, useRef, useState } from 'react';

import { useNavigation } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { ICONS } from 'config/images';
import { View, Text, TextInput, TouchableOpacity, Dimensions } from 'react-native';

const AuthenOTP = () => {
	const navigation = useNavigation();

	const windowsHeight = Dimensions.get('window').height;
	const windowWidth = Dimensions.get('window').width;
	const designHeight = 812;
	const designWidth = 375;

	const convertWidth = (width: number) => {
		return width * (windowWidth / designWidth);
	};

	const refInput1 = useRef();
	const refInput2 = useRef();
	const refInput3 = useRef();
	const refInput4 = useRef();
	const refInput5 = useRef();
	const refInput6 = useRef();

	const [input1, setInput1] = useState('');
	const [input2, setInput2] = useState('');
	const [input3, setInput3] = useState('');
	const [input4, setInput4] = useState('');
	const [input5, setInput5] = useState('');
	const [input6, setInput6] = useState('');

	useEffect(() => {
		refInput1.current?.focus();
	}, []);

	useEffect(() => {
		if (input1) {
			refInput2.current?.focus();
		}
	}, [input1]);

	useEffect(() => {
		if (input2) {
			refInput3.current?.focus();
		}
	}, [input2]);

	useEffect(() => {
		if (input3) {
			refInput4.current?.focus();
		}
	}, [input3]);

	useEffect(() => {
		if (input4) {
			refInput5.current?.focus();
		}
	}, [input4]);

	useEffect(() => {
		if (input5) {
			refInput6.current?.focus();
		}
	}, [input5]);

	useEffect(() => {
		if (input6) {
			refInput6.current?.blur();
		}
	}, [input6]);

	return (
		<View style={{ flex: 1 }}>
			<View style={{ flex: 1, paddingTop: 75, paddingHorizontal: 24 }}>
				<View
					style={{
						width: 48,
						height: 48,
						borderRadius: 30,
						backgroundColor: 'rgba(17, 17, 17, 0.1)',
						alignItems: 'center',
						justifyContent: 'center',
						marginBottom: 32,
					}}>
					<Icon src={ICONS.icArrowMenu} width={24} height={24} onPress={() => navigation.goBack()} />
				</View>
				<Text style={{ textAlign: 'center', fontSize: 24, fontWeight: '700' }}>2 - Factor Authentication</Text>
				<Text style={{ textAlign: 'center', fontWeight: '500', color: '#6C6C6C', marginTop: 8 }}>
					Enter 6 number from Authentication application
				</Text>
				<View
					style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 80, width: convertWidth(305) }}>
					<View
						style={{
							width: 42,
							height: 42,
							borderWidth: 1,
							borderColor: '#D9D9D9',
							borderRadius: 8,
							alignItems: 'center',
							justifyContent: 'center',
						}}>
						<TextInput
							onChangeText={setInput1}
							value={input1}
							ref={refInput1}
							style={{ fontSize: 24, fontWeight: '700' }}
							maxLength={1}
							keyboardType="number-pad"
						/>
					</View>
					<View
						style={{
							width: 42,
							height: 42,
							borderWidth: 1,
							borderColor: '#D9D9D9',
							borderRadius: 8,
							alignItems: 'center',
							justifyContent: 'center',
						}}>
						<TextInput
							onChangeText={setInput2}
							value={input2}
							ref={refInput2}
							style={{ fontSize: 24, fontWeight: '700' }}
							maxLength={1}
							keyboardType="number-pad"
						/>
					</View>
					<View
						style={{
							width: 42,
							height: 42,
							borderWidth: 1,
							borderColor: '#D9D9D9',
							borderRadius: 8,
							alignItems: 'center',
							justifyContent: 'center',
						}}>
						<TextInput
							onChangeText={setInput3}
							value={input3}
							ref={refInput3}
							style={{ fontSize: 24, fontWeight: '700' }}
							maxLength={1}
							keyboardType="number-pad"
						/>
					</View>
					<View
						style={{
							width: 42,
							height: 42,
							borderWidth: 1,
							borderColor: '#D9D9D9',
							borderRadius: 8,
							alignItems: 'center',
							justifyContent: 'center',
						}}>
						<TextInput
							onChangeText={setInput4}
							value={input4}
							ref={refInput4}
							style={{ fontSize: 24, fontWeight: '700' }}
							maxLength={1}
							keyboardType="number-pad"
						/>
					</View>
					<View
						style={{
							width: 42,
							height: 42,
							borderWidth: 1,
							borderColor: '#D9D9D9',
							borderRadius: 8,
							alignItems: 'center',
							justifyContent: 'center',
						}}>
						<TextInput
							onChangeText={setInput5}
							value={input5}
							ref={refInput5}
							style={{ fontSize: 24, fontWeight: '700' }}
							maxLength={1}
							keyboardType="number-pad"
						/>
					</View>
					<View
						style={{
							width: 42,
							height: 42,
							borderWidth: 1,
							borderColor: '#D9D9D9',
							borderRadius: 8,
							alignItems: 'center',
							justifyContent: 'center',
						}}>
						<TextInput
							onChangeText={setInput6}
							value={input6}
							ref={refInput6}
							style={{ fontSize: 24, fontWeight: '700' }}
							keyboardType="number-pad"
							maxLength={1}
						/>
					</View>
				</View>
				<View style={{ alignItems: 'center', marginTop: 28 }}>
					<TouchableOpacity
						style={{
							width: convertWidth(305),
							backgroundColor: '#005FD4',
							paddingVertical: 12,
							borderRadius: 8,
							alignItems: 'center',
						}}>
						<Text style={{ color: 'white', fontWeight: '600' }}>TIẾP TỤC</Text>
					</TouchableOpacity>
				</View>
			</View>
		</View>
	);
};

export default AuthenOTP;
