/* eslint-disable @typescript-eslint/no-shadow */
/* eslint-disable @typescript-eslint/require-await */
/* eslint-disable prettier/prettier */
/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable @typescript-eslint/no-misused-promises */

import React, { useEffect, useRef, useState } from 'react';

import AsyncStorage from '@react-native-async-storage/async-storage';
import messaging, { firebase } from '@react-native-firebase/messaging';
import { ActivityIndicator } from '@react-native-material/core';
import { unwrapResult } from '@reduxjs/toolkit';
import { Icon } from 'components/Atoms/Icon';
import { Text } from 'components/Atoms/Text';
import FImage from 'components/Organisms/FImage/FImage';
import { COLORS, ICONS } from 'config';
import { useAsyncAction } from 'hooks/useAsyncAction';
import useAuthentication from 'hooks/useAuthentication';
import useBiometrics from 'hooks/useBiometrics';
import useDidMount from 'hooks/useDidMount';
import {
	Alert,
	Dimensions,
	KeyboardAvoidingView,
	Platform,
	ScrollView,
	View,
	TextInput,
	TouchableOpacity,
} from 'react-native';
import DeviceInfo from 'react-native-device-info';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import SInfo from 'react-native-sensitive-info';
import { apiLogin } from 'services/Auth';
import { useAppDispatch, useAppSelector } from 'stores';
import { fetchCustomerInformation, updateAfterSplash } from 'stores/Auth';
import { clearUsername, saveUsername, updateBioType, updateSide, updateLogin, updateStatusBiometric, updateLanguage } from 'stores/DataNotRemove';
import { fetchBeanAppStatus, fetchBeanWorkflowStatus, fetchSettingSystem } from 'stores/System';
import { BIOMETRICS_ERROR } from 'utils/biometricAuthentication';
import { saveTokenToKeyChain } from 'utils/keychain';
import { translate } from 'utils/translate';

interface IDevice {
	DeviceId: string;
	DevicePushToken: string;
	DeviceOSVersion: string;
	AppVersion: string;
	DeviceName: string;
	DeviceModel: string;
}

const windowsHeight = Dimensions.get('window').height;
const windowWidth = Dimensions.get('window').width;
const designHeight = 812;
const designWidth = 375;

const convertHeight = (height: number) => {
	return height * (windowsHeight / designHeight);
};

const convertWidth = (width: number) => {
	return width * (windowWidth / designWidth);
};


export const LoginScreen = () => {
	const dispatch = useAppDispatch();
	const insets = useSafeAreaInsets();

	const phoneNumberRef = useRef<string>('');
	const passwordRef = useRef<string>('');
	const previousPhoneNumberRef = useRef<string>();
	const refDeviceInfo = useRef<IDevice>();
	const refInputUser = useRef<TextInput | null>(null)
	const refInputPass = useRef<TextInput | null>(null)


	const { logout } = useAuthentication();

	const { askBiometrics, checkBiometricsAvailability, getUserInfo } = useBiometrics();

	const { username: usernameStore, isTurnOnBiometric, bioType, customer, language } = useAppSelector(state => state.dataNotRemove);


	const { ImagePath, FullName } = customer || {};

	const [user, setUser] = useState('');
	// const [pass, setPass] = useState('VuThao123!@#');
	const [pass, setPass] = useState('');
	const [errUser, setErrUser] = useState(false);
	const [errPass, setErrPass] = useState(false);
	const [err, setErr] = useState<{ Key: string; Value: string } | null>(null);
	const [version, setVersion] = useState<string>('1.0');
	const [loadingLogin, setLoadingLogin] = useState<boolean>(false)


	const getDeviceId = async () => {
		let id = '';
		if (Platform.OS === 'ios') {
			await DeviceInfo.getUniqueId().then(uniqueId => {
				id = uniqueId;
			});
		} else {
			await DeviceInfo.getAndroidId().then(androidId => {
				id = androidId;
			});
		}

		return id;
	};


	useDidMount(async () => {
		if (usernameStore) {
			previousPhoneNumberRef.current = usernameStore;
			setUser(usernameStore);
		}
		const biometricType = await SInfo.isSensorAvailable();
		dispatch(updateBioType(biometricType))
		dispatch(updateAfterSplash(true))

		const versionDevice = DeviceInfo.getVersion();
		setVersion(versionDevice);

		const deviceId = await getDeviceId();
		let token = '';
		try {
			token = await messaging().getToken();
		} catch (error) {
			//
		}

		const deviceInfo = {
			DeviceId: deviceId,
			DevicePushToken: token,
			DeviceOSVersion: DeviceInfo.getSystemVersion(),
			AppVersion: versionDevice,
			DeviceName: await DeviceInfo.getDeviceName(),
			DeviceModel: DeviceInfo.getModel(),
		};

		refDeviceInfo.current = deviceInfo;
	});

	const onChangeUser = (name: string) => {
		setErr(null);
		setUser(name);
	};

	const onChangePassword = (pw: string) => {
		setErr(null);
		setPass(pw);
	};

	// useEffect(() => {
	// 	dispatch(updateStatus(FullName ? 'AUTH' : 'UNAUTH'));
	// }, [FullName]);

	const handleLoginSuccess = async (res: { data: { data: any; }; }, status?: boolean,) => {
		const { Client, Sso } = res.data.data || {};

		const url = Client?.url || ''
		const side: string = url?.split('/')?.pop();

		await Promise.allSettled([
			dispatch(saveUsername(phoneNumberRef.current)),
			dispatch(updateSide(side)),
			AsyncStorage.setItem('SIDE', side),
			saveTokenToKeyChain({ refreshToken: JSON.stringify(Sso), accessToken: JSON.stringify(Client) }),
			dispatch(fetchCustomerInformation())
				.then(unwrapResult)
				.catch(() => {
					logout();
					Alert.alert('Warning', 'An error has occurred. Please try again later', [
						{ text: 'OK', style: 'cancel' },
					]);
				})
		]);
		dispatch(updateLogin(true))
		setLoadingLogin(false)
		dispatch(fetchBeanAppStatus());
		dispatch(fetchBeanWorkflowStatus());
		dispatch(fetchSettingSystem());
		if (status) {
			dispatch(updateStatusBiometric(status));

		}
	}

	const [customerLoginExec, customerLoginState] = useAsyncAction(apiLogin, {
		onSuccess: async res => {
			if (res.data.status === 'SUCCESS') {
				if (!!bioType && (usernameStore !== phoneNumberRef.current || !isTurnOnBiometric)) {
					askBiometrics({
						username: phoneNumberRef.current,
						password: passwordRef.current,
						bioType,
						isQsLoginWithNewAccount: usernameStore !== phoneNumberRef.current
					})
						.then(() => handleLoginSuccess(res, true))
						.catch(() => handleLoginSuccess(res))
				} else {
					return handleLoginSuccess(res)
				}
			} else {
				setLoadingLogin(false)
				setErr(res.data.mess);
			}
		},
		onFailed: (error: BaseAPIError) => {
			setLoadingLogin(false)
			Alert.alert(translate('title_alert_warning'), error.message || translate('message_alert_error_default'), [
				{ text: 'OK', style: 'cancel' },
			]);
		},
	});


	const handleSubmitForm = ({ username = '', password = '' }) => {
		try {
			if (username && password) {
				setLoadingLogin(true)
				phoneNumberRef.current = username || user;
				passwordRef.current = password || pass;
				customerLoginExec({
					username: username || user,
					password: password || pass,
					deviceInfo: refDeviceInfo.current,
				});
			}
			// TODO: Success handler (Toastify)
		} catch (error) {
			setLoadingLogin(false)
			// TODO: Error handler (Toastify)
		}
	};

	const handleBiometricAuthentication = async () => {
		try {
			const available = checkBiometricsAvailability();
			// phoneNumberRef.current = user;
			if (available) {
				// const isFirstLogin = previousPhoneNumberRef.current === '' && phoneNumberRef.current === '';
				// if (previousPhoneNumberRef.current !== phoneNumberRef.current || isFirstLogin) {
				// 	Alert.alert(translate('title_alert_warning'), translate('require_firstlogin'), [{ text: translate('ok') }]);
				// 	return;
				// }
				const userSession = await getUserInfo();
				if (!userSession?.password && !userSession?.username) {
					return
				}
				setUser(userSession.username)
				setPass(userSession?.password);
				handleSubmitForm({ username: userSession.username, password: userSession.password });
			}
		} catch (err) {
			const errorMessage = (err as Error).message;
			if (errorMessage === BIOMETRICS_ERROR.KEY_INVALIDATED) {
				previousPhoneNumberRef.current = '';
				dispatch(clearUsername());
			}
		}
	};

	const isErr = err?.Key === '201' || err?.Key === '202' || err?.Key === '198';
	// 200: sai user/pass
	// 201: lock 15p
	// 202: lock

	const getIconBio = () => {
		if (bioType === 'Face ID') return ICONS.icFaceID;
		if (bioType === 'Touch ID') return ICONS.icTouchIos;
		return ICONS.icFaceID;
	};

	const keyboardVerticalOffset = Platform.OS === 'ios' ? 80 : 0;

	const onSubmitUsername = () => {
		setTimeout(() => {
			refInputPass.current?.focus()
		}, 300);
	}

	const onSubmitPassword = () => {
		if (!user) setErrUser(true);
		if (!pass) setErrPass(true);
		if (!user || !pass) return;
		handleSubmitForm({ username: user, password: pass });
	}

	return (
		<View style={{ flex: 1, backgroundColor: '#005FD4' }}>
			<SafeAreaView style={{ flex: 1 }} edges={['top']}>
				{/* <TouchableOpacity hitSlop={{
					top: 10, left: 10, right: 10, bottom: 10

				}} onPress={() => dispatch(updateLanguage(language === 'vi' ? 'en' : 'vi'))}
					style={{ position: 'absolute', top: convertHeight(insets.top), right: convertWidth(18), zIndex: 99 }} >
					<Icon src={language === 'vi' ? ICONS.icFlagVN : ICONS.icFlagEN} width={18} height={18} />
				</TouchableOpacity> */}
				<KeyboardAvoidingView style={{ flex: 1 }}
					behavior={Platform.OS === 'ios' ? 'padding' : undefined}
				>
					<ScrollView contentContainerStyle={{ flexGrow: 1, backgroundColor: 'white' }}
						keyboardDismissMode='interactive'
						keyboardShouldPersistTaps='handled'
					>
						<View
							style={{
								backgroundColor: '#005FD4',
								flex: 3,
								marginBottom: -20,
								alignItems: 'center',
								justifyContent: 'center',
							}}>
							<Text style={{ fontSize: 24, fontWeight: '700', color: '#fff', paddingVertical: 20, paddingBottom: 75 }}>
								{translate('signIn')}
							</Text>
						</View>
						<View
							// behavior={Platform.OS === 'ios' ? 'padding' : undefined}
							// keyboardVerticalOffset={keyboardVerticalOffset}
							style={{ zIndex: 1, flex: 1 }}>
							<View
								style={{
									backgroundColor: 'white',
									borderTopRightRadius: 10,
									borderTopLeftRadius: 10,
									alignItems: 'center',
									zIndex: 10,
								}}>
								<View style={{ alignItems: 'center', top: -50 }}>
									<FImage ImagePath={ImagePath} SW={96} />
								</View>
								<View style={{ alignItems: 'center', marginTop: -35, width: convertWidth(305) }}>
									{!isErr ? FullName ? (
										<Text style={{ fontWeight: '500', textAlign: 'center' }}>
											{translate('hi')} <Text style={{ fontWeight: '700' }}>{FullName}</Text>! {translate('comeback')}
										</Text>
									) : (
										<Text style={{ fontWeight: '500', textAlign: 'center' }}>{translate('signinInformation')}</Text>
									) : <View style={{ marginTop: -20 }} />}

									{!FullName && (
										<View>
											<TouchableOpacity disabled={!!isErr} activeOpacity={1} onPress={() => refInputUser.current?.focus()}
												style={{

													borderWidth: 1,
													borderColor: errUser && !user ? COLORS.red : '#D9D9D9',
													width: convertWidth(305),
													height: convertHeight(40),
													alignItems: 'center',
													borderRadius: 8,
													flexDirection: 'row',
													paddingHorizontal: 10,
													marginTop: 25,
												}}>
												<Icon src={ICONS.icUserCircle} width={18} height={18} />
												<TextInput
													editable={!isErr}
													ref={refInputUser}
													value={user}
													onChangeText={onChangeUser}
													placeholder={translate('placeholder_username')}
													style={{ marginLeft: 12, flex: 1 }}
													maxLength={255}
													returnKeyType='next'
													keyboardType='email-address'
													importantForAutofill='yes'
													autoCapitalize='none'
													onSubmitEditing={
														onSubmitUsername
													}
												/>
											</TouchableOpacity>
											{errUser && !user && (
												<Text style={{ fontSize: 12, fontStyle: 'italic', color: COLORS.red }}>
													{translate('require_username')}
												</Text>
											)}
										</View>
									)}
									{!isErr && (
										<>

											<View style={{ marginBottom: 25 }}>
												<TouchableOpacity activeOpacity={1} onPress={() => refInputPass.current?.focus()}
													style={{
														borderWidth: 1,
														borderColor: errPass && !pass ? COLORS.red : '#D9D9D9',
														width: convertWidth(305),
														height: convertHeight(40),
														alignItems: 'center',
														borderRadius: 8,
														flexDirection: 'row',
														paddingHorizontal: 10,

														marginTop: 21,
													}}>
													<Icon src={ICONS.icUnlock} width={18} height={18} />
													<TextInput
														ref={refInputPass}
														value={pass}
														onChangeText={onChangePassword}
														placeholder={translate('password')}
														secureTextEntry
														style={{ marginLeft: 12, flex: 1 }}
														maxLength={255}
														returnKeyType='done'
														autoCapitalize='none'
														textContentType='password'
														autoComplete='password'
														onSubmitEditing={
															onSubmitPassword
														}
													/>
												</TouchableOpacity>
												{errPass && !pass && (
													<Text style={{ fontSize: 12, fontStyle: 'italic', color: COLORS.red }}>
														{translate('require_password')}
													</Text>
												)}
											</View>
											{!!err?.Key && (
												<Text style={{ fontSize: 12, fontStyle: 'italic', color: COLORS.red, marginBottom: 24 }}>
													{FullName ? translate('incorrectPassword') : err?.Value}
												</Text>
											)}
											<TouchableOpacity
												disabled={loadingLogin}
												onPress={() => {
													refInputPass.current?.blur()

													if (!user) setErrUser(true);
													if (!pass) setErrPass(true);
													if (!user || !pass) return;
													handleSubmitForm({ username: user, password: pass });
												}}
												style={{
													backgroundColor: '#005FD4',
													width: convertWidth(305),
													height: convertHeight(40),
													alignItems: 'center',
													borderRadius: 8,
													paddingHorizontal: 10,
													justifyContent: 'center',
													marginBottom: 20,
													flexDirection: 'row',
													zIndex: 99
												}}>
												{loadingLogin ? (
													<ActivityIndicator color={COLORS.white} />
												) : (
													<Text fw="bold" color={COLORS.white}>
														{translate('continue')}
													</Text>
												)}
											</TouchableOpacity>
										</>
									)}
									{isErr && (
										<View style={{ alignItems: 'center', marginTop: 24 }}>
											<View
												style={{
													backgroundColor: COLORS.red,
													width: convertWidth(305),
													padding: 16,
													borderRadius: 8,
													alignItems: 'center',
												}}>
												<View
													style={{
														width: 12,
														height: 12,
														backgroundColor: COLORS.red,
														position: 'absolute',
														transform: [{ rotate: '45deg' }],
														top: -5,
													}}
												/>
												<Text style={{ color: '#fff', textAlign: 'center' }}>{err?.Value}</Text>
												{/* <Text
												style={{
													color: '#fff',
													textAlign: 'center',
													paddingVertical: 10,
													fontSize: 20,
													marginTop: 10,
												}}>
												00:23
											</Text> */}
											</View>
										</View>
									)}
								</View>
							</View>
						</View>

						<View style={{ backgroundColor: 'white', justifyContent: 'center', alignItems: 'center', flex: 5 }}>
							<View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
								{isTurnOnBiometric && !!bioType && (
									<Icon
										src={getIconBio()}
										width={48}
										height={48}
										tintColor={isErr ? 'rgba(157, 157, 157, 1)' : 'rgba(0, 95, 212, 1)'}
										onPress={() => {
											if (!isErr) {
												handleBiometricAuthentication();
											}
										}}
									/>
								)}
							</View>
							<View style={{ flex: 1, justifyContent: 'flex-end', marginBottom: insets.bottom }}>
								{FullName || isErr ? (
									<TouchableOpacity
										disabled={loadingLogin}
										onPress={() => {
											setErr(null);
											setUser('')
											setPass('')
											logout();
										}}>
										<Text style={{ color: '#005FD4', fontSize: 14 }}>{translate('otherAccount')}</Text>
									</TouchableOpacity>
								) : (
									<Text style={{ color: '#7B7B7B', fontSize: 12 }}>
										{translate('version')}: {version.toString()} © Vu Thao Technology
									</Text>
								)}
							</View>
						</View>
					</ScrollView>
				</KeyboardAvoidingView>

				{/* <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
					<ScrollView
						showsVerticalScrollIndicator={false}
						keyboardShouldPersistTaps="handled"
						// onScrollBeginDrag={() => {
						// 	Keyboard.dismiss;
						// }}
						contentContainerStyle={{ flexGrow: 1 }}>
						<Header>
							<Logo>
								<Icon src={ICONS.icLogo} width={52} height={36} />
								<Text fw="bold" fs={20} color={COLORS.purpleNavy} style={{ marginLeft: 18 }}>
									DIGITAL PROCESS
								</Text>
							</Logo>
							<Box mt={27}>
								<Controller
									control={control}
									name="username"
									render={({ field: { onChange, value } }) => (
										<TextInput
											label=""
											// labelStyle={{ color: COLORS.white }}
											placeholderTextColor={COLORS.davyGrey}
											placeholder={translate('placeholder_username')}
											color={COLORS.davyGrey}
											maxLength={255}
											variant="outlined"
											value={value}
											isOverWrite
											styleCustom={{
												borderRadius: 5,
												borderWidth: 0.8,
												borderColor: errors.username?.message ? COLORS.redOrange : COLORS.platinum,
											}}
											inputStyle={{ fontStyle: 'italic', color: COLORS.davyGrey }}
											onChangeText={handleChangeUserName(onChange)}
											helperText={errors.username?.message}
											styleHelper={{ color: COLORS.redOrange }}
											leading={
												<Icon
													src={ICONS.icUser}
													resizeMode="contain"
													tintColor={COLORS.davyGrey}
													width={18}
													height={18}
												/>
											}
										/>
									)}
									defaultValue=""
								/>
							</Box>
							<Box mb={30} mt={27}>
								<Controller
									control={control}
									name="password"
									render={({ field: { onChange, value } }) => (
										<TextInput
											label=""
											// labelStyle={{ color: COLORS.white }}
											placeholderTextColor={COLORS.davyGrey}
											placeholder={translate('placeholder_password')}
											color={COLORS.davyGrey}
											maxLength={255}
											variant="outlined"
											value={value}
											isOverWrite
											styleCustom={{
												borderRadius: 5,
												borderWidth: 0.8,
												borderColor: errors.password?.message ? COLORS.redOrange : COLORS.platinum,
											}}
											secureTextEntry
											inputStyle={{ fontStyle: 'italic', color: COLORS.davyGrey }}
											onChangeText={onChange}
											helperText={errors.password?.message}
											styleHelper={{ color: COLORS.redOrange }}
											leading={
												<Icon
													src={ICONS.icKey}
													resizeMode="contain"
													tintColor={COLORS.davyGrey}
													width={18}
													height={18}
												/>
											}
										/>
									)}
									defaultValue=""
								/>
							</Box>
							<LoginWrap>
								<LoginButton onPress={handleSubmit(handleSubmitForm)} disabled={customerLoginState.loading}>
									{customerLoginState.loading ? (
										<ActivityIndicator color={COLORS.white} />
									) : (
										<Text fw="bold" color={COLORS.white}>
											{translate('login')}
										</Text>
									)}
								</LoginButton>
								<LoginFaceIDButton onPress={handleBiometricAuthentication}>
									<Icon src={ICONS.icFaceID} width={32} height={32} tintColor={COLORS.white} />
								</LoginFaceIDButton>
							</LoginWrap>
						</Header>
						<Footer>
							<Icon src={ICONS.icLogin} width={width * 0.7} aspectRatio={263 / 226} />
							<WaitWrap>
								<Text style={{ fontStyle: 'italic' }} fw={400} fs={14} color={COLORS.trueBlue}>
									Please wait a minute
								</Text>
							</WaitWrap>
						</Footer>
					</ScrollView>
				</KeyboardAvoidingView> */}
			</SafeAreaView>
		</View >
	);
};
