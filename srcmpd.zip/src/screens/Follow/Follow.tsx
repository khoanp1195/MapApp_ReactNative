/* eslint-disable react/no-unstable-nested-components */
import React, { useEffect, useRef, useState } from 'react';

import { useNavigation } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { refDropDown } from 'components/Atoms/Loading/DropDown';
import ModalCalendarRef from 'components/LookupScreens/ModalCalendarRef';
import ModalState from 'components/LookupScreens/ModalState';
import ModalWorkflow from 'components/LookupScreens/ModalWorkflow';
import { Header } from 'components/Organisms/Header';
import ItemTask, { IItemTask } from 'components/TaskScreens/ItemTask';
import { COLORS } from 'config';
import { ICONS } from 'config/images';
import dayjs from 'dayjs';
import useDebounce from 'hooks/useDebounce';
import useSystem from 'hooks/useSystem';
import { RoutesNames } from 'navigation/RoutesNames';
import { View, Text, TouchableOpacity, TextInput, ScrollView, FlatList, RefreshControl, Keyboard } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import LookupScreen from 'screens/Lookup/LookupScreen';
import { useAppDispatch } from 'stores';
import { updateStatusDrawer } from 'stores/System';
import { translate } from 'utils/translate';

import { styles } from './Follow.styles';
import { useFollow } from './useFollow';

interface IWorkflow {
	ID: number;
	WorkflowID: number;
	Title: string;
	TitleEN: string;
	Description: any;
	ImageURL: string;
	IsFavor: number;
	WorkflowCategory: string;
	WorkflowCategoryID: number;
}

interface IState {
	value: number;
	label: string;
	labelEN: string;
}

const defaultFillter = {
	workflow: [{ Title: 'Tất cả', TitleEN: 'All', WorkflowID: 0 }],
	state: [{ label: translate('flag_all'), value: 0, labelEN: 'All' }],
	fromDate: new Date(new Date().setDate(new Date().getDate() - 30)),
	toDate: new Date(),
	keyword: '',
};

const Follow = () => {
	const dispatch = useAppDispatch();
	const { isVN } = useSystem();
	const navigation = useNavigation();

	const refModalWorkflow = useRef<{ show: (e: IWorkflow[]) => void } | null>(null);
	const refModalState = useRef<{ show: (e: IState[]) => void } | null>(null);
	const refModalCalendar = useRef<{ show: (options: any) => void } | null>(null);
	const refState = useRef<string[]>();
	const refSubmit = useRef(defaultFillter);
	const [filter, setFilter] = useState({
		...defaultFillter,
		keyword: '',
	});

	const [open, setOpen] = useState(false);
	const [kw, setKw] = useState('');

	const dbKw = useDebounce(kw, 300);

	useEffect(() => {
		setFilter({ ...filter, keyword: dbKw });
	}, [dbKw]);

	const { data, useFilter, refreshing, total, handleRefresh, handleFilter, handleEndReached } = useFollow(filter);

	const onSubmitSelectWorkflow = (select: IWorkflow[]) => {
		// setWorkflow(select);
		setFilter({ ...filter, workflow: select });
	};

	const onSubmitSelectState = (select: IState[]) => {
		setFilter({ ...filter, state: select });
	};

	const onSubmitSelectDate = ({ isFromDate, date }: { isFromDate: boolean; date: Date }) => {
		if (isFromDate) {
			return setFilter({ ...filter, fromDate: date });
		}
		return setFilter({ ...filter, toDate: date });
	};

	const handleOpenDrawer = () => {
		Keyboard.dismiss();
		// dispatch(updateStatusDrawer(true));
		navigation.goBack();
	};

	const onPressFilter = () => {
		Keyboard.dismiss();
		if (open) {
			setFilter({ ...filter, ...refSubmit.current });
		}
		setOpen(!open);
	};

	const renderLeading = () => (
		<View style={{ flexDirection: 'row', alignItems: 'center' }}>
			<Icon src={ICONS.icArrowMenu} width={24} height={24} tintColor="rgba(0, 0, 0, 1)" onPress={handleOpenDrawer} />

			<Text style={{ fontSize: 20, fontWeight: '700', marginLeft: 10 }}>{translate('followings')}</Text>
		</View>
	);

	const trailing = (
		<View style={{ alignItems: 'center', flexDirection: 'row', justifyContent: 'flex-end' }}>
			<View style={{ backgroundColor: useFilter ? 'rgba(219, 235, 255, 1)' : 'white', padding: 2, borderRadius: 4 }}>
				<Icon
					src={ICONS.icFilterTask}
					width={24}
					height={24}
					onPress={onPressFilter}
					tintColor={useFilter ? 'rgba(0, 95, 212, 1)' : 'black'}
				/>
			</View>
		</View>
	);

	const onPressWorkflow = () => refModalWorkflow.current?.show(filter.workflow);

	const onPressState = () => refModalState.current?.show(filter.state);

	const onOpenCalendarFormDate = () => {
		const options = {
			headerTitle: translate('from_date'),
			defaultValue: filter.fromDate,
			maxDate: filter.toDate,
		};
		refModalCalendar.current?.show(options);
	};

	const onOpenCalendarToDate = () => {
		const options = {
			headerTitle: translate('to_date'),
			defaultValue: filter.toDate,
			maxDate: '',
		};
		refModalCalendar.current?.show(options);
	};

	const getNameWorkflow = () => {
		if (!filter.workflow?.length) return translate('select_workflow');
		const listName: string[] = filter.workflow.map(item => (isVN ? item.Title : item.TitleEN));
		return listName.toString().replaceAll(',', ', ') || '';
	};

	const getNameState = () => {
		if (!filter.state?.length) return translate('select_state');
		const listName: string[] = filter.state.map(item => (isVN ? item.label : item.labelEN));
		return listName.toString().replaceAll(',', ', ') || '';
	};

	const onPressSearch = () => {
		refSubmit.current = filter;
		setOpen(false);
		handleFilter(filter, false);
	};

	const onResetFilter = () => {
		refSubmit.current = defaultFillter;
		setFilter({ ...filter, ...defaultFillter });
		setOpen(false);
		setKw('');
		handleFilter({ ...defaultFillter, fromDate: '', toDate: '' }, true);
	};

	const getInfoFilter = type => {
		switch (type) {
			case 'workflow':
				return {
					title: isVN ? filter.workflow[0]?.Title : filter.workflow[0]?.TitleEN,
					icon: null,
				};
			case 'state':
				let listLabel: string[] = [];
				if (filter.state?.length) {
					filter.state?.forEach(item => {
						listLabel = [...listLabel, isVN ? item.label : item.labelEN];
					});
				}
				refState.current = listLabel;
				return {
					title: `${listLabel[0]}${listLabel?.length - 1 > 0 ? ` +${listLabel?.length - 1}` : ''}`,
					icon: listLabel?.length - 1 > 0 ? ICONS.icChevronDown : null,
				};
			case 'date':
				return {
					title: `${dayjs(filter.fromDate).format(isVN ? 'DD/MM/YYYY' : 'MM/DD/YYYY')} - ${dayjs(filter.toDate).format(
						isVN ? 'DD/MM/YYYY' : 'MM/DD/YYYY',
					)}`,
					icon: ICONS.icCalendarField,
				};

			default:
				return {
					title: ``,
					icon: null,
				};
		}
	};

	const handleNavigateToDetail = (item: IItemTask) => navigation.navigate(RoutesNames.WorkflowDetails, { item });

	const renderItem = ({ item }: { item: IItemTask }) => {
		return <ItemTask item={item} handleNavigateToDetail={handleNavigateToDetail} isLookup />;
	};

	const ListFooterComponent = () => {
		return <View style={{ height: 250 }} />;
	};

	return (
		<SafeAreaView style={{ flex: 1 }} edges={['top']}>
			<Header leading={renderLeading()} trailing={trailing} />
			<View
				style={{
					borderWidth: 1,
					justifyContent: 'center',
					height: 38,
					flexDirection: 'row',
					alignItems: 'center',
					borderRadius: 8,
					borderColor: 'rgba(217, 217, 217, 1)',
					paddingHorizontal: 8,
					marginHorizontal: 16,
					marginTop: 10,
				}}>
				<Icon src={ICONS.icSearchApps} width={18} height={18} tintColor="rgba(123, 123, 123, 1)" />
				<TextInput
					placeholder={translate('content')}
					value={kw}
					onChangeText={setKw}
					style={{ flex: 1, marginLeft: 5 }}
					multiline={false}
				/>
			</View>
			{open ? (
				<View style={{ marginHorizontal: 16 }}>
					<View style={styles.options}>
						<Text style={styles.titleWorkflow}>{translate('workflow')}</Text>
						<TouchableOpacity onPress={onPressWorkflow} activeOpacity={1} style={styles.buttonWorkflow}>
							<Text style={styles.nameWf}>{getNameWorkflow()}</Text>
							<Icon src={ICONS.icChevronDown} width={20} height={20} />
						</TouchableOpacity>
					</View>
					<View style={styles.vState}>
						<Text style={styles.tState}>
							{translate('state')}
							<Text style={{ fontSize: 12 }}>{filter.state[0]?.value !== 0 ? ` (${filter.state?.length})` : ''}</Text>
						</Text>
						<TouchableOpacity onPress={onPressState} activeOpacity={1} style={styles.bState}>
							<Text style={styles.nState}>{getNameState()}</Text>
							<Icon src={ICONS.icChevronDown} width={20} height={20} />
						</TouchableOpacity>
					</View>
					<View style={styles.cDate}>
						<View style={styles.vFromDate}>
							<TouchableOpacity style={{ flex: 1 }} onPress={onOpenCalendarFormDate}>
								<Text style={styles.nFromDate}>{translate('from_date')}</Text>
								<View style={styles.vDate}>
									<Icon src={ICONS.icCalendarNew} width={20} height={20} />
									<Text style={styles.tDate}>{dayjs(filter.fromDate).format(isVN ? 'DD/MM/YYYY' : 'MM/DD/YYYY')}</Text>
								</View>
							</TouchableOpacity>
							<TouchableOpacity style={{ flex: 1 }} onPress={onOpenCalendarToDate}>
								<Text style={styles.nFromDate}>{translate('to_date')}</Text>
								<View style={styles.vDate}>
									<Icon src={ICONS.icCalendarNew} width={20} height={20} />
									<Text style={styles.tDate}>{dayjs(filter.toDate).format(isVN ? 'DD/MM/YYYY' : 'MM/DD/YYYY')}</Text>
								</View>
							</TouchableOpacity>
						</View>
					</View>
					<TouchableOpacity style={styles.bSave} onPress={onPressSearch}>
						<Text style={styles.tSave}>{translate('searchButton')}</Text>
					</TouchableOpacity>
					<TouchableOpacity
						onPress={onResetFilter}
						style={{
							marginHorizontal: 24,
							marginBottom: 32,
						}}>
						<Text
							style={{
								textAlign: 'center',
								fontSize: 14,
								fontWeight: '600',
								color: COLORS.red,
							}}>
							{translate('clearFilter')}
						</Text>
					</TouchableOpacity>
				</View>
			) : (
				<View>
					{useFilter && (
						<View style={{ marginHorizontal: 16, paddingBottom: 10 }}>
							<ScrollView horizontal showsHorizontalScrollIndicator={false}>
								{['workflow', 'state', 'date'].map((item, index) => {
									const info = getInfoFilter(item);
									return (
										<View
											key={index?.toString()}
											style={{
												flexDirection: 'row',
												alignItems: 'center',
												padding: 10,
												// backgroundColor: 'white',
												borderRadius: 8,
												marginRight: 16,
												marginTop: 10,
												overflow: 'hidden',
												justifyContent: 'center',
												// borderWidth: 0.8,
												// borderColor: 'rgba(217, 217, 217, 1)',
												backgroundColor: 'rgba(245, 245, 245, 1)',
											}}>
											<View style={{ maxWidth: 200 }}>
												<Text numberOfLines={1} style={{ flex: 1, fontSize: 12 }}>
													{info?.title}
												</Text>
											</View>
											{!!info?.icon && (
												<TouchableOpacity
													activeOpacity={1}
													onPress={event => {
														if (item === 'state' && refState.current?.length > 1) {
															event.target.measure((x, y, width, height, pageX, pageY) => {
																refDropDown.current?.show(
																	{
																		top: pageY - y + 5,
																		left: pageX - x - 55,
																		heightItem: refState.current?.length || 0,
																	},
																	<View style={{ paddingHorizontal: 20, width: 150 }}>
																		{refState.current?.map((item, index) => {
																			if (index === 0) return null;
																			return (
																				<TouchableOpacity
																					key={index?.toString()}
																					style={{
																						marginVertical: 5,
																						flexDirection: 'row',
																						alignItems: 'center',
																						height: 30,
																					}}>
																					<Text>{item}</Text>
																				</TouchableOpacity>
																			);
																		})}
																	</View>,
																);
															});
														}
													}}>
													<Icon src={info.icon} width={18} height={18} tintColor="#000" style={{ marginLeft: 4 }} />
												</TouchableOpacity>
											)}
										</View>
									);
								})}
							</ScrollView>
						</View>
					)}
					{!data?.length && (
						<View
							style={{
								// backgroundColor: 'rgba(245, 245, 245, 1)',
								paddingVertical: 10,
								paddingHorizontal: 16,
								marginTop: 10,
								alignItems: 'center',
							}}>
							<Text style={{ fontSize: 12, fontWeight: '400', color: '#7B7B7B', fontStyle: 'italic' }}>
								{filter.keyword?.length ? translate('noResult') : translate('noData')}
								{/* {translate('noData')} */}
							</Text>
						</View>
					)}
					<FlatList
						keyboardDismissMode="on-drag"
						style={{ zIndex: 1 }}
						contentContainerStyle={{}}
						onEndReached={handleEndReached}
						onEndReachedThreshold={0.7}
						data={data || []}
						keyExtractor={(item, index) => index.toString()}
						renderItem={renderItem}
						showsVerticalScrollIndicator={false}
						scrollEventThrottle={16}
						ListFooterComponent={ListFooterComponent}
						nestedScrollEnabled
						refreshControl={
							<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={COLORS.trueBlue} />
						}
					/>
				</View>
			)}

			<ModalCalendarRef ref={refModalCalendar} onSubmitSelect={onSubmitSelectDate} />
			<ModalWorkflow isMulti ref={refModalWorkflow} onSubmitSelect={onSubmitSelectWorkflow} />
			<ModalState ref={refModalState} onSubmitSelect={onSubmitSelectState} hideState={['2', '128']} />
		</SafeAreaView>
	);
};

export default Follow;
