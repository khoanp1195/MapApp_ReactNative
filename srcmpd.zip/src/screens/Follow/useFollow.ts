/* eslint-disable @typescript-eslint/no-shadow */
/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable @typescript-eslint/restrict-template-expressions */
import { ENDPOINT } from 'http/modules/Request';

import { useCallback, useEffect, useRef, useState } from 'react';

import { useIsFocused } from '@react-navigation/native';
import { IItemTask } from 'components/TaskScreens/ItemTask';
import useInfinity from 'hooks/useInfinity';
import useSystem from 'hooks/useSystem';
import { IFilter } from 'screens/TaskScreens/types';
import store, { useAppDispatch, useAppSelector } from 'stores';
import { reloadWorkflow } from 'stores/System';
import dayjs from 'utils/dayjs';
import { translate } from 'utils/translate';

// WorkflowStatus

export const useFollow = (filter: IFilter) => {
	const totalPageRef = useRef<number>(0);
	const { isReload } = useAppSelector(store => store.system);
	const dispatch = useAppDispatch();
	const isFocused = useIsFocused();
	const refUseFilter = useRef(false);
	const refCallApi = useRef(false);
	const { lid } = useSystem();
	const refLid = useRef(lid);
	const initCount = useRef(null);

	const refFilter = useRef({
		workflow: [{ Title: 'Tất cả', TitleEN: 'All', WorkflowID: 0 }],
		state: [{ label: translate('flag_all'), value: 0, labelEN: 'All' }],
		fromDate: new Date(new Date().setDate(new Date().getDate() - 30)),
		toDate: new Date(),
		keyword: '',
	});

	const { CountMyFollowItem = 0 } = useAppSelector(store => store.count.count) || {};

	const { workflow, state = [], toDate, fromDate } = refFilter.current || {};

	const [data, setData] = useState<IItemTask[]>(0);

	const getStatus = () => {
		if (state?.length) {
			const statusGroupFilter = state?.some(v => v.value === 0) ? '' : state?.map(v => v.value).join(',');
			return statusGroupFilter;
		}
	};

	const getDataFilter = () => {
		const WorkflowID = refUseFilter.current ? workflow[0]?.WorkflowID?.toString() : 0;
		const StatusGroup = refUseFilter.current ? getStatus() : '';
		const FromDate = refUseFilter.current ? dayjs(fromDate).format('YYYY-MM-DD') : '';
		const ToDate = refUseFilter.current ? dayjs(toDate).format('YYYY-MM-DD') : '';
		return { WorkflowID, StatusGroup, FromDate, ToDate, Keyword: filter.keyword };
	};

	const dataFilter = getDataFilter();

	const {
		state: { data: dataRes, refreshing, loading, page },
		gotoFirstPage,
		refreshPage,
		fetchMore,
	} = useInfinity<Array<IItemTask>>(`${ENDPOINT.WORKFLOW}`, {
		size: 10,
		requireAuthentication: true,
		params: {
			func: 'getList',
			data: JSON.stringify(dataFilter),
			resourcetype: 'MyFollowItem',
			lid,
			// totalrecord: totalPageRef.current,
		},
		onSuccess: res => {
			if (!res.data) return;
			totalPageRef.current = res.data?.TotalRecord;
			refCallApi.current = true;
		},
	});

	useEffect(() => {
		if (initCount.current !== null) {
			refreshPage();
		}
		initCount.current = CountMyFollowItem;
	}, [CountMyFollowItem]);

	useEffect(() => {
		// gotoFirstPage();
		if (filter.keyword?.length > 2 || filter.keyword?.length === 0) {
			gotoFirstPage();
		} else if (refCallApi.current) {
			setData([]);
			totalPageRef.current = 0;
		}
	}, [filter.keyword]);

	// useEffect(() => {
	// 	if (useFilter && filter.keyword?.length > 2) {
	// 		gotoFirstPage();
	// 	}
	// }, [useFilter]);

	useEffect(() => {
		if (dataRes !== undefined) {
			setData(dataRes?.Data || []);
			// totalPageRef.current = dataRes?.Data?.length || 0;
		}
	}, [dataRes]);

	const handleEndReached = () => {
		if (totalPageRef.current > 9 && data.length < totalPageRef.current) {
			fetchMore();
		}
	};

	useEffect(() => {
		if (isReload && isFocused) {
			gotoFirstPage();
			dispatch(reloadWorkflow(false));
		}
	}, [isReload, isFocused]);

	useEffect(() => {
		if (lid !== refLid.current) {
			refLid.current = lid;
			gotoFirstPage();
		}
	}, [lid]);

	const handleFilter = (data, isReset) => {
		refFilter.current = data;
		refUseFilter.current = !isReset;
		totalPageRef.current = 0;
		const WorkflowID = data.workflow[0]?.WorkflowID?.toString();
		const FromDate = dayjs(data.fromDate).format('YYYY-MM-DD');
		const ToDate = dayjs(data.toDate).format('YYYY-MM-DD');
		const statusGroupFilter = data.state?.some(v => v.value === 0) ? '' : data.state?.map(v => v.value).join(',');
		gotoFirstPage({
			params: {
				func: 'getList',
				data: JSON.stringify({
					WorkflowID,
					StatusGroup: statusGroupFilter,
					FromDate,
					ToDate,
					Keyword: filter.keyword,
				}),
				resourcetype: 'MyFollowItem',
				lid,
				totalrecord: totalPageRef.current,
			},
		});
	};

	const handleRefresh = () => {
		// if (filter.keyword?.length > 2) {
		refreshPage();
		// }
	};

	return {
		data,
		handleEndReached,
		handleRefresh,
		refreshing,
		handleFilter,
		useFilter: refUseFilter.current,
		total: totalPageRef.current,
	};
};
