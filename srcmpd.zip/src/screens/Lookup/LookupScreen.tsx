/* eslint-disable @typescript-eslint/no-shadow */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-return */
import React, { useEffect, useRef, useState } from 'react';

import { useIsFocused, useNavigation, useRoute } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import ModalCalendarRef from 'components/LookupScreens/ModalCalendarRef';
import ModalState from 'components/LookupScreens/ModalState';
import ModalWorkflow from 'components/LookupScreens/ModalWorkflow';
import { COLORS } from 'config/colors';
import { ICONS } from 'config/images';
import dayjs from 'dayjs';
import useSystem from 'hooks/useSystem';
import { navigate } from 'navigation/RootNavigation';
import { BottomNavigationRoutesNames } from 'navigation/RoutesNames';
import {
	View,
	Text,
	TextInput,
	TouchableOpacity,
	KeyboardAvoidingView,
	Platform,
	Keyboard,
	TouchableWithoutFeedback,
	ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { IFilter } from 'screens/TaskScreens/types';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateStatusDrawer } from 'stores/System';
import { translate } from 'utils/translate';

import { styles } from './LookupScreen.styles';

interface IWorkflow {
	ID: number;
	WorkflowID: number;
	Title: string;
	TitleEN: string;
	Description: any;
	ImageURL: string;
	IsFavor: number;
	WorkflowCategory: string;
	WorkflowCategoryID: number;
}

interface IState {
	value: number;
	label: string;
	labelEN: string;
}

interface IProps {
	onUpdateFilterProps?: (value: IFilter) => void;
	value?: IFilter;
	isTask?: boolean;
	hideState: stirng[];
}

const LookupScreen = ({ isTask = false, onUpdateFilterProps, value, hideState }: IProps) => {
	const dispatch = useAppDispatch();
	const navigation = useNavigation();
	const refModalWorkflow = useRef<{ show: (e: IWorkflow[]) => void } | null>(null);
	const refModalState = useRef<{ show: (e: IState[]) => void } | null>(null);
	const refModalCalendar = useRef<{ show: (options: any) => void } | null>(null);
	const { isVN } = useSystem();
	const isFocus = useIsFocused();
	const refInput = useRef();

	const workflowsApps = useAppSelector(store => store.apps.workflowsApps);

	const isWorkflowsApps = !!workflowsApps?.ID;

	const workflowDefault = isWorkflowsApps
		? [{ Title: workflowsApps?.Title, TitleEN: workflowsApps?.TitleEN, WorkflowID: workflowsApps?.WorkflowID }]
		: [{ Title: 'Tất cả', TitleEN: 'All', WorkflowID: 0 }];

	const [workflow, setWorkflow] = useState<IWorkflow[]>(workflowDefault);
	const [state, setState] = useState<IState[]>([{ label: 'Tất cả', value: 0, labelEN: 'All' }]);
	const [fromDate, setFromDate] = useState(new Date(new Date().setDate(new Date().getDate() - 30)));
	const [toDate, setToDate] = useState(new Date());
	const [keyword, setKeyword] = useState<string>('');
	const [selected, setSelected] = useState('flag_all');

	useEffect(() => {
		setWorkflow(workflowDefault);
	}, [workflowsApps]);

	useEffect(() => {
		if (!isFocus) {
			refInput.current?.blur();
		}
	}, [isFocus]);

	const refReset = useRef(false);

	const onSubmitSelectWorkflow = (select: IWorkflow[]) => setWorkflow(select);

	const onSubmitSelectState = (select: IState[]) => setState(select);

	const onSubmitSelectDate = ({ isFromDate, date }: { isFromDate: boolean; date: Date }) => {
		if (isFromDate) return setFromDate(date);
		return setToDate(date);
	};

	const getNameWorkflow = () => {
		if (!workflow?.length) return translate('select_workflow');
		const listName: string[] = workflow.map(item => (isVN ? item.Title : item.TitleEN));
		return listName.toString().replaceAll(',', ', ') || '';
	};

	const getNameState = () => {
		if (!state?.length) return translate('select_state');
		const listName: string[] = state.map(item => (isVN ? item.label : item.labelEN));
		return listName.toString().replaceAll(',', ', ') || '';
	};

	const onOpenCalendarFormDate = () => {
		const options = {
			headerTitle: translate('from_date'),
			defaultValue: fromDate,
			maxDate: toDate,
			minDate: '',
		};
		refModalCalendar.current?.show(options);
	};

	const onOpenCalendarToDate = () => {
		const options = {
			headerTitle: translate('to_date'),
			defaultValue: toDate,
			maxDate: '',
			minDate: fromDate,
		};
		refModalCalendar.current?.show(options);
	};

	const onPressState = () => {
		refInput.current?.blur();
		refModalState.current?.show(state);
	};

	const onPressWorkflow = () => {
		refInput.current?.blur();

		refModalWorkflow.current?.show(workflow);
	};
	const handleOpenDrawer = () => {
		refInput.current?.blur();
		if (isTask) return navigation.goBack();
		if (isWorkflowsApps) return navigate(BottomNavigationRoutesNames.Home);
		dispatch(updateStatusDrawer(true));
	};

	const updateFilter = (filter: IFilter) => {
		const { workflow, state, toDate, fromDate, keyword } = filter || {};
		setWorkflow(workflow);
		setState(state);
		setToDate(toDate ? new Date(toDate) : new Date());
		setFromDate(fromDate ? new Date(fromDate) : new Date(new Date().setDate(new Date().getDate() - 30)));
		setKeyword(keyword);
	};

	useEffect(() => {
		if (value) {
			updateFilter(value);
		}
	}, [value]);

	const updateFilterFormSearch = kw => setKeyword(kw);

	const onPressSearch = () => {
		const value = {
			keyword,
			workflow,
			state,
			toDate: dayjs(toDate).toString(),
			fromDate: dayjs(fromDate).toString(),
			selected,
		};
		if (isTask) {
			if (onUpdateFilterProps) {
				onUpdateFilterProps(value, refReset.current);
			}
			refReset.current = false;
			navigation.goBack();
			return;
		}
		// refReset.current = false;
		navigation.navigate('ListLookupScreen', { value, updateFilterFormSearch });
	};

	const onResetFilter = () => {
		setWorkflow([{ Title: 'Tất cả', TitleEN: 'All', WorkflowID: 0 }]);
		setState([{ label: translate('flag_all'), value: 0, labelEN: 'All' }]);
		setToDate(new Date(toDate));

		setFromDate(new Date(new Date().setDate(new Date().getDate() - 30)));
		setKeyword('');
		refReset.current = true;
		onPressSearch();
	};

	return (
		<SafeAreaView style={styles.container} edges={['top']}>
			{/* <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}> */}
			<View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingBottom: 16 }}>
				<Icon
					src={isTask || isWorkflowsApps ? ICONS.icArrowMenu : ICONS.icMenu}
					width={isTask || isWorkflowsApps ? 24 : 16}
					height={isTask || isWorkflowsApps ? 24 : 16}
					tintColor="rgba(0, 0, 0, 1)"
					onPress={handleOpenDrawer}
					style={{ marginTop: 2 }}
				/>
				<Text style={styles.search}>{isTask ? translate('filter') : translate('search')}</Text>
			</View>
			<ScrollView
				style={{ flex: 1, paddingBottom: 50 }}
				keyboardShouldPersistTaps="handled"
				keyboardDismissMode="on-drag"
				showsVerticalScrollIndicator={false}>
				<View style={styles.viewSearch}>
					<View style={styles.borderSearch}>
						<Text style={styles.titleSearch}>{translate('search_keyword')}</Text>
						<TextInput
							ref={refInput}
							value={keyword}
							onChangeText={setKeyword}
							placeholder={translate(isTask ? 'content' : 'title_search')}
							style={styles.inputSearch}
							placeholderTextColor="#9D9D9D"
							maxLength={255}
							returnKeyType="done"
						/>
					</View>
					<View style={[styles.options, { opacity: isWorkflowsApps ? 0.5 : 1 }]}>
						<Text style={styles.titleWorkflow}>{translate('workflow')}</Text>
						<TouchableOpacity
							disabled={isWorkflowsApps}
							onPress={onPressWorkflow}
							activeOpacity={1}
							style={styles.buttonWorkflow}>
							<Text style={styles.nameWf}>{getNameWorkflow()}</Text>
							{!isWorkflowsApps && <Icon src={ICONS.icChevronDown} width={20} height={20} />}
						</TouchableOpacity>
					</View>
					<View style={styles.vState}>
						<Text style={styles.tState}>
							{translate('state')}
							<Text style={{ fontSize: 12 }}>{state[0]?.value !== 0 ? ` (${state?.length})` : ''}</Text>
						</Text>
						<TouchableOpacity onPress={onPressState} activeOpacity={1} style={styles.bState}>
							<Text style={styles.nState}>{getNameState()}</Text>
							<Icon src={ICONS.icChevronDown} width={20} height={20} />
						</TouchableOpacity>
					</View>
				</View>

				{!isTask && (
					<View style={{ paddingHorizontal: 24, paddingTop: 20 }}>
						<Text style={{ paddingBottom: 20, fontSize: 14, fontWeight: '500', color: '#555' }}>
							{translate('processingTerm')}
						</Text>
						<View style={{ flexDirection: 'row' }}>
							{['flag_all', 'to_day', 'flag_overdue'].map((item, index) => {
								const isSelect = selected === item;
								return (
									<TouchableOpacity
										activeOpacity={1}
										key={index?.toString()}
										style={{ flexDirection: 'row', marginRight: 30 }}
										onPress={() => {
											setSelected(item);
										}}>
										<Icon src={isSelect ? ICONS.icCheckUser : ICONS.icUnCheckUser} width={20} height={20} />
										<Text
											style={{
												marginLeft: 6,
												color: index === 1 ? 'rgba(139, 79, 183, 1)' : index === 2 ? 'rgba(237, 78, 73, 1)' : '#555',
											}}>
											{translate(item as 'flag_all')}
										</Text>
									</TouchableOpacity>
								);
							})}
						</View>
					</View>
				)}

				<View style={styles.dvd} />

				<View style={styles.cDate}>
					<View style={styles.vFromDate}>
						<TouchableOpacity style={{ flex: 1 }} onPress={onOpenCalendarFormDate}>
							<Text style={styles.nFromDate}>{translate('from_date')}</Text>
							<View style={styles.vDate}>
								<Icon src={ICONS.icCalendarNew} width={16.33} height={18} />
								<Text style={styles.tDate}>{dayjs(fromDate).format(isVN ? 'DD/MM/YYYY' : 'MM/DD/YYYY')}</Text>
							</View>
						</TouchableOpacity>
						<TouchableOpacity style={{ flex: 1 }} onPress={onOpenCalendarToDate}>
							<Text style={styles.nFromDate}>{translate('to_date')}</Text>
							<View style={styles.vDate}>
								<Icon src={ICONS.icCalendarNew} width={16.33} height={18} />
								<Text style={styles.tDate}>{dayjs(toDate).format(isVN ? 'DD/MM/YYYY' : 'MM/DD/YYYY')}</Text>
							</View>
						</TouchableOpacity>
					</View>
				</View>
			</ScrollView>
			{/* </TouchableWithoutFeedback> */}
			<KeyboardAvoidingView behavior="padding" collapsable keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 0}>
				<TouchableOpacity style={styles.bSave} onPress={onPressSearch}>
					<Text style={styles.tSave}>{isTask ? translate('filter_apply') : translate('searchButton')}</Text>
				</TouchableOpacity>
			</KeyboardAvoidingView>
			{isTask ? (
				<TouchableOpacity
					onPress={onResetFilter}
					style={{
						marginHorizontal: 24,
						marginBottom: 32,
						marginTop: 20,
					}}>
					<Text
						style={{
							textAlign: 'center',
							fontSize: 14,
							fontWeight: '600',
							color: COLORS.red,
						}}>
						{translate('clearFilter')}
					</Text>
				</TouchableOpacity>
			) : (
				<View style={{ height: 20 }} />
			)}

			<ModalCalendarRef ref={refModalCalendar} onSubmitSelect={onSubmitSelectDate} />
			<ModalWorkflow isMulti ref={refModalWorkflow} onSubmitSelect={onSubmitSelectWorkflow} />
			<ModalState ref={refModalState} onSubmitSelect={onSubmitSelectState} hideState={hideState} />
		</SafeAreaView>
	);
};

export default LookupScreen;
