/* eslint-disable @typescript-eslint/no-shadow */
/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable @typescript-eslint/restrict-template-expressions */
import { ENDPOINT } from 'http/modules/Request';

import { useEffect, useRef, useState } from 'react';

import { useIsFocused } from '@react-navigation/native';
import { ShowLoading } from 'components/Atoms/Loading/LoadingGlobal';
import { IItemTask } from 'components/TaskScreens/ItemTask';
import useInfinity from 'hooks/useInfinity';
import useSystem from 'hooks/useSystem';
import { IFilter } from 'screens/TaskScreens/types';
import { useAppDispatch, useAppSelector } from 'stores';
import { reloadWorkflow } from 'stores/System';
import dayjs from 'utils/dayjs';
import { translate } from 'utils/translate';

// WorkflowStatus

export const useListLookup = (filter: IFilter) => {
	const totalPageRef = useRef<number>(0);
	const { isReload } = useAppSelector(store => store.system);
	const dispatch = useAppDispatch();
	const isFocused = useIsFocused();

	const { keyword, workflow, state = [], toDate, fromDate, selected } = filter || {};

	const { lid } = useSystem();

	const [data, setData] = useState<IItemTask[]>(null);
	const [loadingState, setLoadingState] = useState(true);

	const getStatus = () => {
		if (state?.length) {
			const statusGroupFilter = state?.some(v => v.value === 0) ? '' : state?.map(v => v.value).join(',');
			return statusGroupFilter;
		}
	};

	const gerFlagOverdue = () => {
		if (selected === 'flag_all') return 0;
		if (selected === 'to_day') return 1;
		return 2;
	};

	const getDataFilter = () => {
		const WorkflowID = workflow[0]?.WorkflowID?.toString();
		const StatusGroup = getStatus();
		const FromDate = dayjs(fromDate).format('YYYY-MM-DD');
		const ToDate = dayjs(toDate).format('YYYY-MM-DD');
		const Flag = gerFlagOverdue();
		return { WorkflowID, StatusGroup, FromDate, ToDate, Keyword: keyword, Flag };
	};

	const dataFilter = getDataFilter();

	const {
		state: { data: dataRes, refreshing, loading, page },
		gotoFirstPage,
		refreshPage,
		fetchMore,
	} = useInfinity<Array<IItemTask>>(`${ENDPOINT.WORKFLOW}`, {
		size: 10,
		requireAuthentication: true,
		params: {
			func: 'getList',
			data: JSON.stringify(dataFilter),
			resourcetype: 'FilterWorkflowItem',
			lid,
			totalrecord: totalPageRef.current,
		},
		onSuccess: res => {
			if (!res.data) return;
			totalPageRef.current = res.data?.TotalRecord;
		},
	});

	useEffect(() => {
		if (filter?.toDate) {
			setLoadingState(true);
			gotoFirstPage();
		}
	}, [filter, keyword]);

	useEffect(() => {
		setLoadingState(false);
		if (dataRes !== undefined) {
			setData(dataRes?.Data || []);
		}
	}, [dataRes]);

	const handleEndReached = () => {
		if (totalPageRef.current > 9 && data?.length > 9 && !loading) {
			fetchMore();
		}
	};

	useEffect(() => {
		if (isReload && isFocused) {
			gotoFirstPage();
			setLoadingState(true);
			dispatch(reloadWorkflow(false));
		}
	}, [isReload, isFocused]);

	const handleRefresh = () => {
		refreshPage();
	};

	return { data, handleEndReached, handleRefresh, refreshing, loading, loadingState };
};
