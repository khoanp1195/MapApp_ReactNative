/* eslint-disable react/no-unstable-nested-components */
/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useRef, useState } from 'react';

import { useNavigation, useRoute } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { refDropDown } from 'components/Atoms/Loading/DropDown';
import ItemTask, { IItemTask } from 'components/TaskScreens/ItemTask';
import { COLORS } from 'config/colors';
import { ICONS } from 'config/images';
import dayjs from 'dayjs';
import useDebounce from 'hooks/useDebounce';
import useSystem from 'hooks/useSystem';
import { BottomNavigationRoutesNames, RoutesNames } from 'navigation/RoutesNames';
import {
	View,
	Text,
	TextInput,
	FlatList,
	RefreshControl,
	ScrollView,
	TouchableOpacity,
	ActivityIndicator,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { IFilter } from 'screens/TaskScreens/types';
import { translate } from 'utils/translate';

import { useListLookup } from './useListLookup';

const HeaderListLookup = ({
	keyword,
	onChangeText,
	onGoBack,
}: {
	keyword: string;
	onChangeText: (res: string) => void;
	onGoBack: () => void;
}) => {
	const insets = useSafeAreaInsets();

	// const ;
	const [kw, setKw] = useState('');
	const dbKeyword = useDebounce(kw, 300);

	useEffect(() => {
		setKw(keyword);
	}, [keyword]);

	useEffect(() => {
		onChangeText(dbKeyword);
	}, [dbKeyword]);

	return (
		<View
			style={{
				flexDirection: 'row',
				alignItems: 'center',
				justifyContent: 'center',
				paddingHorizontal: 16,
				backgroundColor: 'white',
				paddingBottom: 20,
				paddingTop: insets.top,
				shadowColor: '#000',
				shadowOffset: {
					width: 0,
					height: 1,
				},
				shadowOpacity: 0.2,
				shadowRadius: 2,
				elevation: 5,
				zIndex: 99,
			}}>
			<Icon src={ICONS.icArrowMenu} width={24} height={24} onPress={onGoBack} />
			<TextInput
				value={kw}
				defaultValue={keyword}
				placeholder={translate('title_search')}
				style={{
					height: 38,
					paddingHorizontal: 10,
					borderRadius: 8,
					fontSize: 14,
					borderWidth: 0.8,
					borderColor: 'rgba(229, 229, 229, 1)',
					flex: 1,
					marginLeft: 10,
					marginRight: 20,
				}}
				placeholderTextColor="#9D9D9D"
				onChangeText={setKw}
			// editable={false}
			/>
			{/* <View style={{ backgroundColor: 'rgba(219, 235, 255, 1)', padding: 2, borderRadius: 4 }}>
				<Icon src={ICONS.icFilterTask} width={24} height={24} tintColor="rgba(0, 95, 212, 1)" />
			</View> */}
		</View>
	);
};

const ListLookupScreen = () => {
	const navigation = useNavigation();
	const refState = useRef<string[]>();
	const { isVN, formatDate } = useSystem();
	const route = useRoute();
	const [filter, setFilter] = useState<IFilter>({
		keyword: '',
		workflow: '',
		state: '',
		toDate: '',
		fromDate: '',
		selected: '',
	});

	useEffect(() => {
		setFilter(route.params?.value);
	}, [route.params]);

	const { data, refreshing, handleRefresh, handleEndReached, loading, loadingState } = useListLookup(filter);
	const handleNavigateToDetail = (item: IItemTask) => navigation.navigate(RoutesNames.WorkflowDetails, { item });

	const renderItem = ({ item }: { item: IItemTask }) => {
		return <ItemTask item={item} handleNavigateToDetail={handleNavigateToDetail} isLookup />;
	};

	const ListFooterComponent = () => {
		return <View style={{ height: 100 }} />;
	};

	const onChangeText = (text: string) => {
		setFilter({ ...filter, keyword: text });
	};

	const onGoBack = () => {
		navigation.navigate(RoutesNames.BottomNavigation, { screen: BottomNavigationRoutesNames.Search });
		route?.params?.updateFilterFormSearch && route?.params?.updateFilterFormSearch(filter.keyword);
	};

	const getInfoFilter = type => {
		switch (type) {
			case 'workflow':
				return {
					title: isVN ? filter.workflow[0]?.Title : filter.workflow[0]?.TitleEN,
					icon: null,
				};
			case 'state':
				let listLabel: string[] = [];
				if (filter?.state?.length) {
					filter?.state?.forEach(item => {
						listLabel = [...listLabel, isVN ? item.label : item.labelEN];
					});
				}
				refState.current = listLabel;
				return {
					title: `${listLabel[0]}${listLabel?.length - 1 > 0 ? ` +${listLabel?.length - 1}` : ''}`,
					icon: listLabel?.length - 1 > 0 ? ICONS.icChevronDown : null,
				};
			case 'term':
				return {
					title: translate(filter.selected),
					icon: null,
				};
			case 'date':
				return {
					title: `${dayjs(filter?.fromDate).format(formatDate)} - ${dayjs(filter?.toDate).format(formatDate)}`,
					icon: ICONS.icCalendarField,
				};

			default:
				return {
					title: ``,
					icon: null,
				};
		}
	};

	return (
		<View style={{ flex: 1 }}>
			<HeaderListLookup keyword={filter.keyword} onChangeText={onChangeText} onGoBack={onGoBack} />
			<View style={{ backgroundColor: 'rgba(245, 245, 245, 1)' }}>
				<ScrollView horizontal showsHorizontalScrollIndicator={false}>
					{['workflow', 'state', 'term', 'date'].map((item, index) => {
						const info = getInfoFilter(item);
						return (
							<View
								key={index?.toString()}
								style={{
									flexDirection: 'row',
									alignItems: 'center',
									padding: 10,
									backgroundColor: 'white',
									borderRadius: 8,
									margin: 10,
									overflow: 'hidden',
									justifyContent: 'center',
								}}>
								<View style={{ maxWidth: 200 }}>
									<Text numberOfLines={1} style={{ flex: 1, fontSize: 12 }}>
										{info?.title}
									</Text>
								</View>
								{!!info?.icon && (
									<TouchableOpacity
										activeOpacity={1}
										onPress={event => {
											if (item === 'state' && refState.current?.length > 1) {
												event.target.measure((x, y, width, height, pageX, pageY) => {
													refDropDown.current?.show(
														{
															top: pageY - y + 5,
															left: pageX - x - 55,
															heightItem: refState.current?.length || 0,
														},
														<View style={{ paddingHorizontal: 20, width: 150 }}>
															{refState.current?.map((item, index) => {
																if (index === 0) return null;
																return (
																	<TouchableOpacity
																		key={index?.toString()}
																		style={{
																			marginVertical: 5,
																			flexDirection: 'row',
																			alignItems: 'center',
																			height: 30,
																		}}>
																		<Text>{item}</Text>
																	</TouchableOpacity>
																);
															})}
														</View>,
													);
												});
											}
										}}>
										<Icon src={info.icon} width={18} height={18} tintColor="#000" style={{ marginLeft: 4 }} />
									</TouchableOpacity>
								)}
							</View>
						);
					})}
				</ScrollView>
			</View>
			{!data?.length && !loadingState && (
				<Text style={{ fontSize: 12, fontStyle: 'italic', textAlign: 'center', paddingTop: 10 }}>
					{translate('noResult')}
				</Text>
			)}
			{loadingState && (
				<View style={{ marginTop: 8 }}>
					<ActivityIndicator size="small" />
				</View>
			)}
			<FlatList
				style={{ flex: 1, zIndex: 1 }}
				contentContainerStyle={{}}
				onEndReached={handleEndReached}
				onEndReachedThreshold={0.7}
				data={data || []}
				keyExtractor={(item, index) => index.toString()}
				renderItem={renderItem}
				showsVerticalScrollIndicator={false}
				scrollEventThrottle={16}
				ListFooterComponent={ListFooterComponent}
				nestedScrollEnabled
				refreshControl={
					<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={COLORS.trueBlue} />
				}
			/>
		</View>
	);
};

export default ListLookupScreen;
