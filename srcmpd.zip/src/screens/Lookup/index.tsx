import React, { useCallback, useState } from 'react';

import { Text, TextInput } from '@react-native-material/core';
import en from 'assets/i18n/en';
import { EmptyState } from 'components/Atoms/EmptyState';
import { Icon } from 'components/Atoms/Icon';
import { Loading } from 'components/Atoms/Loading';
import { Header } from 'components/Organisms/Header';
import { TaskCard } from 'components/Organisms/TaskCard';
import { IconWrapper } from 'components/Organisms/TaskCard/styles';
import { TaskFilter } from 'components/Organisms/TaskFilter';
import { COLORS, ICONS, defaultImgUri, imgDummy } from 'config';
import { ActivityIndicator, KeyboardAvoidingView, Platform, RefreshControl, SectionList, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Assigned, ResourcetypeTask } from 'services/Tasks/types';
import { translate } from 'utils/translate';

import { Container, Leading, TextCustom, Trailing, Wrapper, styles } from './styles';
import { useLookUp } from './useLookUp';

export const LookUpScreen = () => {
	const {
		page,
		bottom,
		dataRes,
		loading,
		language,
		refreshing,
		customizeTasks,
		isOpenFilter,
		customerInfo,
		currentFilter,
		isOpenSearch,
		beanAppStatus,
		refreshPage,
		handleFillter,
		handleEndReached,
		handleOpenDrawer,
		handleTogleFilter,
		handleToggleSearch,
		onSearchKeyword,
		handleNavigateToDetail,
		handleNavigateToTask,
		updateRead,
	} = useLookUp();

	const [valid, setValid] = useState<boolean>(true);

	const renderTitle = useCallback(
		(title: string) => {
			return (
				<Wrapper mLeft={15} mTop={14} mBottom={14}>
					<TextCustom allowFontScaling={false} fw={700} fs={15} lh={20} color={COLORS.darkJungleGreen}>
						{translate(title as keyof typeof en)}
					</TextCustom>
				</Wrapper>
			);
		},
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[language],
	);

	const renderLeading = useCallback(
		() => (
			<Leading onPress={handleOpenDrawer}>
				<IconWrapper
					onError={() => setValid(false)}
					source={{ uri: valid ? customerInfo?.ImagePath || imgDummy : imgDummy }}
					style={{ marginRight: 15, alignSelf: 'baseline' }}
				/>
				{/* <Avatar size={40} image={{ uri: customerInfo?.ImagePath }} style={{ marginRight: 15 }} /> */}
				<Text color={COLORS.trueBlue} style={{ fontSize: 16, fontWeight: 'bold' }}>
					{translate('lookup')}
				</Text>
			</Leading>
		),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[customerInfo?.ImagePath, valid, language],
	);

	const section = [
		{ title: 'today', data: customizeTasks?.today || [] },
		{ title: 'yesterday', data: customizeTasks?.yesterday || [] },
		{ title: 'older', data: customizeTasks?.beforeYesterday || [] },
	];

	return (
		<SafeAreaView style={{ flex: 1 }} edges={['top']}>
			<KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
				<Header
					leading={renderLeading()}
					trailing={
						<Trailing>
							<Icon
								style={{ marginRight: 16 }}
								src={ICONS.icFilter}
								tintColor={isOpenFilter ? COLORS.pastelGreen : COLORS.davyGrey}
								width={18}
								height={18}
								onPress={handleTogleFilter}
							/>
							<Icon
								src={ICONS.icSearchAll}
								tintColor={isOpenSearch ? COLORS.trueBlue : COLORS.gray}
								width={24}
								height={24}
								onPress={handleToggleSearch}
							/>
						</Trailing>
					}
				/>
				{isOpenSearch && (
					<TextInput
						label=""
						// labelStyle={{ color: COLORS.white }}
						placeholderTextColor={COLORS.davyGrey}
						placeholder={translate('search_placeholder')}
						color={COLORS.davyGrey}
						maxLength={255}
						variant="outlined"
						isOverWrite
						styleCustom={{
							borderRadius: 5,
							borderWidth: 0,
						}}
						inputStyle={{
							color: COLORS.davyGrey,
							backgroundColor: COLORS.whiteSmoke,
							marginHorizontal: 5,
							borderRadius: 5,
						}}
						onChangeText={onSearchKeyword}
					/>
				)}
				{isOpenFilter ? (
					<TaskFilter onApply={handleFillter} type={ResourcetypeTask.FILTER} currentFilter={currentFilter} />
				) : (
					<Container>
						{!customizeTasks && page === 0 && loading ? (
							<Loading />
						) : (
							<SectionList
								sections={!customizeTasks ? [] : section}
								renderSectionHeader={({ section: { title, data } }) => (data?.length > 0 ? renderTitle(title) : null)}
								refreshControl={
									<RefreshControl refreshing={refreshing} onRefresh={refreshPage} tintColor={COLORS.trueBlue} />
								}
								contentContainerStyle={styles.listContentContainer}
								keyExtractor={({ ID }) => ID.toString()}
								showsVerticalScrollIndicator={false}
								onEndReached={handleEndReached}
								ListFooterComponent={
									!refreshing && dataRes?.Data && loading ? (
										<Wrapper style={{ backgroundColor: COLORS.whiteSmoke }} mBottom={bottom} mTop={24}>
											<ActivityIndicator size="small" color={COLORS.trueBlue} />
										</Wrapper>
									) : null
								}
								renderItem={({ item }) => {
									const {
										Read,
										Content,
										DueDate,
										IsFollow,
										Workflow,
										Created,
										FileCount,
										StatusGroup,
										AssignedToInfo,
										ResourceCategoryId,
										ResourceSubCategoryId,
										ID,
									} = item || {};
									const statusGroupItem = beanAppStatus?.find(v => v.ID === StatusGroup);
									const {
										ImagePath = '',
										DefaultImagePath = '',
										Name,
										NumExpand,
									} = JSON.parse(AssignedToInfo || '{}') as Assigned;
									return (
										<View style={{ backgroundColor: Read ? COLORS.white : COLORS.aliceBlue }}>
											<TaskCard
												type={ResourcetypeTask.MYREQUEST}
												assignedToName={Name || ''}
												numExpand={NumExpand || 0}
												avatar={ImagePath || defaultImgUri()}
												defaultAvatar={DefaultImagePath || defaultImgUri()}
												status={StatusGroup}
												statusTitle={language === 'vi' ? statusGroupItem?.Title : statusGroupItem?.TitleEN}
												fileCount={!!FileCount}
												isFollow={!!IsFollow}
												title={Content}
												time={Created}
												description={Workflow}
												expire={DueDate}
												onPress={() => {
													if (ResourceCategoryId === 16 && ResourceSubCategoryId === 0) {
														handleNavigateToTask(item);
													} else {
														handleNavigateToDetail(item);
													}
													// if (!Read) updateRead(ID);
												}}
											/>
										</View>
									);
								}}
								ListEmptyComponent={<EmptyState />}
							/>
						)}
					</Container>
				)}
			</KeyboardAvoidingView>
		</SafeAreaView>
	);
};
