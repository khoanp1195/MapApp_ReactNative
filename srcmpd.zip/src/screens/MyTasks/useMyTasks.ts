import { useEffect, useRef } from 'react';

import { useAppDispatch, useAppSelector } from 'stores';
import { updateTurnOnFilterMyTaskCompleted, updateTurnOnFilterMyTaskInProcess } from 'stores/Mytasks';
import { updateStatusDrawer } from 'stores/System';

export const useMyTasks = (params: { index: number }) => {
	const { index } = params || {};
	const dispatch = useAppDispatch();
	const { count } = useAppSelector(state => state.count);

	const countTaskRef = useRef({
		my_task: 0,
		my_request: 0,
	});

	const { language } = useAppSelector(state => state.dataNotRemove);
	const customerInfo = useAppSelector(state => state.dataNotRemove.customer);
	const { isTurnOnFilterMyTaskInProcess, isTurnOnFilterMyTaskCompleted } = useAppSelector(state => state.mytask);

	useEffect(() => {
		countTaskRef.current = {
			my_task: count?.CountMyTask || 0,
			my_request: count?.CountMyRequest || 0,
		};
	}, [count]);

	const handleOpenDrawer = () => dispatch(updateStatusDrawer(true));

	const handleTogleFilter = () =>
		dispatch(
			index === 0
				? updateTurnOnFilterMyTaskInProcess(!isTurnOnFilterMyTaskInProcess)
				: updateTurnOnFilterMyTaskCompleted(!isTurnOnFilterMyTaskCompleted),
		);

	return {
		handleOpenDrawer,
		language,
		openFilter: index === 0 ? isTurnOnFilterMyTaskInProcess : isTurnOnFilterMyTaskCompleted,
		countTaskRef,
		customerInfo,
		handleTogleFilter,
	};
};
