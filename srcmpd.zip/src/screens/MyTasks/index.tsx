import React, { useCallback, useState } from 'react';

import { Text } from '@react-native-material/core';
import { createMaterialTopTabNavigator, MaterialTopTabBarProps } from '@react-navigation/material-top-tabs';
import { Icon } from 'components/Atoms/Icon';
import { Header } from 'components/Organisms/Header';
import { MaterialTopTabsNavigator } from 'components/Organisms/MaterialTopTabsNavigator';
import { IconWrapper } from 'components/Organisms/TaskCard/styles';
import { COLORS, ICONS, imgDummy } from 'config';
import { translate } from 'utils/translate';

import { TasksContainer } from './Containers';
import { Leading, Trailing } from './styles';
import { useMyTasks } from './useMyTasks';

const Tab = createMaterialTopTabNavigator();

const RenderTabBar = (props: MaterialTopTabBarProps) => {
	const { index } = props?.state || {};
	const { handleOpenDrawer, customerInfo, language, countTaskRef, openFilter, handleTogleFilter } = useMyTasks({
		index,
	});

	const [valid, setValid] = useState<boolean>(true);

	const renderLeading = useCallback(
		() => (
			<Leading onPress={handleOpenDrawer}>
				<IconWrapper
					onError={() => setValid(false)}
					source={{ uri: valid ? customerInfo?.ImagePath || imgDummy : imgDummy }}
					style={{ marginRight: 15, alignSelf: 'baseline' }}
				/>
				{/* <Avatar size={40} image={{ uri: customerInfo?.ImagePath }} style={{ marginRight: 15 }} /> */}
				<Text color={COLORS.trueBlue} style={{ fontSize: 16, fontWeight: 'bold' }}>
					{translate('my_task')}
				</Text>
			</Leading>
		),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[customerInfo?.ImagePath, valid, language],
	);
	return (
		<MaterialTopTabsNavigator
			{...props}
			textActiveColor={COLORS.trueBlue}
			countTask={countTaskRef.current}
			customHeader={
				<Header
					leading={renderLeading()}
					trailing={
						<Trailing>
							<Icon src={ICONS.icSearchAll} width={24} height={24} />
						</Trailing>
					}
				/>
			}
			trailing={
				<Trailing>
					<Icon src={ICONS.icQrcode} width={18} height={18} style={{ marginRight: 15 }} />
					<Icon
						src={ICONS.icFilter}
						tintColor={openFilter ? COLORS.pastelGreen : COLORS.davyGrey}
						width={18}
						height={18}
						onPress={handleTogleFilter}
					/>
				</Trailing>
			}
		/>
	);
};

const InProgress = () => <TasksContainer type={2} />;
const Completed = () => <TasksContainer type={4} />;

export const MyTasksScreen = () => {
	return (
		<Tab.Navigator
			screenOptions={{ lazy: true, swipeEnabled: false }}
			tabBar={RenderTabBar}
			initialRouteName="status_in_progress"
			sceneContainerStyle={{
				backgroundColor: COLORS.whiteSmoke,
			}}>
			<Tab.Screen name="status_in_progress" component={InProgress} />
			<Tab.Screen name="status_completed" component={Completed} />
		</Tab.Navigator>
	);
};
