/* eslint-disable @typescript-eslint/restrict-template-expressions */
import { ENDPOINT } from 'http/modules/Request';

import { useEffect, useMemo, useRef, useState } from 'react';

import { FilterValuesType } from 'components/Organisms/TaskFilter';
import { Flag, ViewType } from 'components/Organisms/TaskFilter/constant';
import useInfinity from 'hooks/useInfinity';
import moment from 'moment';
import { navigate } from 'navigation/RootNavigation';
import { RoutesNames } from 'navigation/RoutesNames';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ITask, ResourcetypeTask } from 'services/Tasks/types';
import { useAppDispatch, useAppSelector } from 'stores';
import { fetchCount } from 'stores/Count';
import { updateTurnOnFilterMyTaskCompleted, updateTurnOnFilterMyTaskInProcess } from 'stores/Mytasks';
import dayjs from 'utils/dayjs';
import { translate } from 'utils/translate';

export const useTasks = (params: { type: 2 | 4 }) => {
	const { type } = params || {};
	const dispatch = useAppDispatch();
	const refFilter = useRef<FilterValuesType>(null);
	const totalPageRef = useRef<number>(0);

	const [isOpenSearch, setOpenSearch] = useState<boolean>(false);
	const [dataTask, setDattaTask] = useState<Array<ITask>>([]);

	const dateNow = new Date();
	const date30 = new Date(new Date().setDate(new Date().getDate() - 30));

	const currentFilterValues = useRef<FilterValuesType>({
		viewType: ViewType[0],
		flag: Flag[0],
		statusGroup: [{ label: translate('flag_all'), value: 0, labelEN: 'All' }],
		fromDate: date30,
		toDate: dateNow,
	});

	const { bottom } = useSafeAreaInsets();
	const { beanAppStatus } = useAppSelector(state => state.system);
	const { language } = useAppSelector(state => state.dataNotRemove);
	const { isTurnOnFilterMyTaskInProcess, isTurnOnFilterMyTaskCompleted } = useAppSelector(state => state.mytask);

	const {
		state: { data: dataRes, refreshing, loading, page },
		gotoFirstPage,
		refreshPage,
		fetchMore,
	} = useInfinity<Array<ITask>>(`${ENDPOINT.WORKFLOW}`, {
		size: 10,
		requireAuthentication: true,
		params: {
			func: 'getList',
			data: `{"WorkflowID":0,"ViewType":${type},"Flag":0,"FromDate":"","ToDate":""}`,
			resourcetype: ResourcetypeTask.MYTASK,
			lid: language === 'vi' ? 1066 : 1033,
			totalrecord: totalPageRef.current,
		},
		onSuccess: res => {
			if (!res.data) return;
			totalPageRef.current = res.data?.TotalRecord;
		},
	});

	const handleFillter = (data: FilterValuesType) => {
		refFilter.current = data;
		const { flag, statusGroup, fromDate, toDate } = data || {};
		totalPageRef.current = 0;
		currentFilterValues.current = data;
		const statusGroupFilter = statusGroup.some(v => v.value === 0)
			? ''
			: `,"StatusGroup":"${statusGroup.map(v => v.value).join(',')}"`;
		dispatch(type === 2 ? updateTurnOnFilterMyTaskInProcess(false) : updateTurnOnFilterMyTaskCompleted(false));
		gotoFirstPage({
			params: {
				func: 'getList',
				data: `{"WorkflowID":0,"ViewType":2,"Flag":${flag?.value}${statusGroupFilter},"FromDate":"${moment(
					fromDate,
				).format('YYYY-MM-DD')}","ToDate":"${moment(toDate).format('YYYY-MM-DD')}"}`,
				resourcetype: ResourcetypeTask.MYTASK,
				lid: language === 'vi' ? 1066 : 1033,
				totalrecord: totalPageRef.current,
			},
		});
	};

	useEffect(() => {
		gotoFirstPage();
		dispatch(fetchCount());
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [type]);

	useEffect(() => {
		if (dataRes?.Data?.length) {
			setDattaTask(dataRes.Data);
		}
	}, [dataRes]);

	const handleEndReached = (info: { distanceFromEnd: number }) => {
		if (Number(info.distanceFromEnd) > 0) return;
		fetchMore();
	};

	const customizeTasks = useMemo(() => {
		const tasksObj: {
			today: Array<ITask>;
			yesterday: Array<ITask>;
			beforeYesterday: Array<ITask>;
		} = {
			today: [],
			yesterday: [],
			beforeYesterday: [],
		};
		const yesterday = new Date();
		yesterday.setDate(yesterday.getDate() - 1);
		if (!dataTask?.length) return [];
		// eslint-disable-next-line no-unsafe-optional-chaining
		for (const n of dataTask) {
			if (dayjs(n.Created).isSame(new Date(), 'day')) {
				tasksObj.today.push({ ...n, typeCurrent: 'today' });
			} else if (dayjs(n.Created).isSame(yesterday, 'day')) {
				tasksObj.yesterday.push({ ...n, typeCurrent: 'yesterday' });
			} else if (dayjs(n.Created).isBefore(yesterday, 'day')) {
				tasksObj.beforeYesterday.push({ ...n, typeCurrent: 'older' });
			}
		}
		return tasksObj;
	}, [dataTask]);

	const handleToggleSearch = () => setOpenSearch(prev => !prev);

	const checkRefresh = () => {
		if (refFilter.current) {
			handleFillter(refFilter.current);
		} else {
			refreshPage();
		}
		dispatch(fetchCount());
	};

	useEffect(() => {
		if (totalPageRef.current) {
			checkRefresh();
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [language]);

	const onUpdateTask = () => {
		checkRefresh();
	};
	const updateRead = (ID: number) => {
		const cloneData = [...dataTask];
		const index = dataTask.findIndex(task => task.ID === ID);
		cloneData[index] = { ...cloneData[index], Read: true };
		setDattaTask(cloneData);
	};

	const onUpdateFollow = (ID: number, isFollowed: boolean | number) => {
		const cloneData = [...dataTask];
		const index = dataTask.findIndex(task => task.ID === ID);
		cloneData[index] = { ...cloneData[index], IsFollow: isFollowed ? 1 : 0 };
		setDattaTask(cloneData);
	};

	const handleNavigateToDetail = (item: any) =>
		navigate(RoutesNames.TaskDetail, { item, onUpdateTask, onUpdateFollow });

	return {
		page,
		bottom,
		dataRes,
		loading,
		language,
		refreshing,
		isOpenSearch,
		customizeTasks,
		beanAppStatus,
		currentFilter: currentFilterValues.current,
		isOpenFilter: type === 2 ? isTurnOnFilterMyTaskInProcess : isTurnOnFilterMyTaskCompleted,
		refreshPage: checkRefresh,
		handleFillter,
		handleEndReached,
		handleToggleSearch,
		handleNavigateToDetail,
		updateRead,
		onUpdateFollow,
	};
};
