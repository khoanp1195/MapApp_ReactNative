/* eslint-disable prettier/prettier */
import React, { useCallback } from 'react';

import { TextInput } from '@react-native-material/core';
import en from 'assets/i18n/en';
import { EmptyState } from 'components/Atoms/EmptyState';
import { Loading } from 'components/Atoms/Loading';
import { TaskCard } from 'components/Organisms/TaskCard';
import { TaskFilter } from 'components/Organisms/TaskFilter';
import { COLORS, defaultImgUri } from 'config';
import { ActivityIndicator, RefreshControl, SectionList, View } from 'react-native';
import { Assigned, ResourcetypeTask } from 'services/Tasks/types';
import { translate } from 'utils/translate';

import { Container, styles } from './styles';
import { useTasks } from './useTasks';
import { TextCustom, Wrapper } from '../../styles';

interface Props {
	type: 2 | 4;
}

export const TasksContainer: React.FC<Props> = ({ type }) => {
	const {
		page,
		bottom,
		dataRes,
		loading,
		language,
		refreshing,
		customizeTasks,
		isOpenFilter,
		currentFilter,
		isOpenSearch,
		beanAppStatus,
		refreshPage,
		handleFillter,
		handleEndReached,
		handleNavigateToDetail,
		updateRead
	} = useTasks({
		type,
	});

	const renderTitle = useCallback(
		(title: string) => {
			return (
				<Wrapper mLeft={15} mTop={14} mBottom={14}>
					<TextCustom allowFontScaling={false} fw={700} fs={15} lh={20} color={COLORS.darkJungleGreen}>
						{translate(title as keyof typeof en)}
					</TextCustom>
				</Wrapper>
			);
		},
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[language],
	);

	if (isOpenFilter) return <TaskFilter onApply={handleFillter} viewType={type} currentFilter={currentFilter} />;

	return (
		<Container>
			{isOpenSearch && (
				<TextInput
					label=""
					// labelStyle={{ color: COLORS.white }}
					placeholderTextColor={COLORS.davyGrey}
					placeholder={translate('search_placeholder')}
					color={COLORS.davyGrey}
					maxLength={255}
					variant="outlined"
					isOverWrite
					styleCustom={{
						borderRadius: 5,
						borderWidth: 0,
					}}
					inputStyle={{
						color: COLORS.davyGrey,
						backgroundColor: COLORS.whiteSmoke,
						marginHorizontal: 5,
						borderRadius: 5,
					}}
				/>
			)}
			{!customizeTasks && page === 0 && loading ? (
				<Loading />
			) : (
				<SectionList
					sections={
						!customizeTasks
							? []
							: [
								{ title: 'today', data: customizeTasks?.today || [] },
								{ title: 'yesterday', data: customizeTasks?.yesterday || [] },
								{ title: 'older', data: customizeTasks?.beforeYesterday || [] },
							]
					}
					renderSectionHeader={({ section: { title, data } }) => (data?.length > 0 ? renderTitle(title) : null)}
					refreshControl={
						<RefreshControl refreshing={refreshing} onRefresh={refreshPage} tintColor={COLORS.trueBlue} />
					}
					contentContainerStyle={styles.listContentContainer}
					keyExtractor={({ ID }) => ID.toString()}
					showsVerticalScrollIndicator={false}
					onEndReached={handleEndReached}
					ListFooterComponent={
						!refreshing && dataRes?.Data && loading ? (
							<Wrapper style={{ backgroundColor: COLORS.whiteSmoke }} mBottom={bottom} mTop={24}>
								<ActivityIndicator size="small" color={COLORS.trueBlue} />
							</Wrapper>
						) : null
					}
					renderItem={({ item }) => {
						const { Read, Content, DueDate, IsFollow, Workflow, Created, FileCount, StatusGroup, AssignedByInfo, typeCurrent, ID, ResourceCategoryId } =
							item || {};
						const isTask = ResourceCategoryId === 16;
						const statusGroupItem = beanAppStatus?.find(v => v.ID === StatusGroup);
						const { ImagePath = '', DefaultImagePath = '', Name, NumExpand } = JSON.parse(AssignedByInfo || '{}') as Assigned;
						return (
							<View style={{ backgroundColor: Read ? COLORS.white : COLORS.aliceBlue }}>
								<TaskCard
									isTask={isTask}
									type={ResourcetypeTask.MYTASK}
									assignedToName={Name || ''}
									numExpand={NumExpand || 0}
									avatar={ImagePath || defaultImgUri()}
									defaultAvatar={DefaultImagePath || defaultImgUri()}
									status={StatusGroup}
									statusTitle={language === 'vi' ? statusGroupItem?.Title : statusGroupItem?.TitleEN}
									fileCount={!!FileCount}
									isFollow={!!IsFollow}
									title={Content}
									time={Created}
									description={Workflow}
									expire={DueDate}
									onPress={() => {
										handleNavigateToDetail(item)
										if (!Read) updateRead(ID)
									}}
									typeCurrent={typeCurrent}
								/>
							</View>
						);
					}}
					ListEmptyComponent={<EmptyState />}
				/>
			)}
		</Container>
	);
};
