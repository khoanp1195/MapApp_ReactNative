/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable @typescript-eslint/no-use-before-define */
import React, { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';

import { useNavigation, useRoute } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { TaskCard } from 'components/Organisms/TaskCard';
import { COLORS } from 'config';
import { ICONS } from 'config/images';
import useDebounce from 'hooks/useDebounce';
import useNewRelated from 'hooks/useNewRelated';
import useSystem from 'hooks/useSystem';
import useTask from 'hooks/useTask';
import moment from 'moment';
import { goBack, navigate, navigationRef } from 'navigation/RootNavigation';
import { Keyboard, ScrollView, Text, View, StyleSheet, TextInput, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import SelectDropdown from 'react-native-select-dropdown';
import DateTime from 'screens/TaskDetail/Field/DateTime';

export const NewRelated = () => {
	const navigation = useNavigation();

	const { getProcedureData, procedure, getListSheetData, listSheet } = useNewRelated();
	const { language, lid, beanAppStatus } = useSystem();

	const FormRefField = {
		FromDate: 'FromDate',
		ToDate: 'ToDate',
	};

	const { params } = useRoute();

	const fieldRef = useRef<any>({});

	const [selectedOption, setSelectedOption] = useState<any>({
		CreatedBy: 'null',
		ID: 0,
		Index: 8,
		IsShow: true,
		Modified: '2021-01-13T14:37:00',
		ModifiedBy: '',
		ResourceCategoryIds: 0,
		StatusDetails: 'null',
		Title: 'Tất cả',
		TitleEN: 'All',
		TotalRecord: 0,
	});
	const [selectedProcedure, setSelectedProcedure] = useState<any>({
		ID: 0,
		WorkflowID: 0,
		Title: 'Tất cả',
		TitleEN: 'All',
		Description: null,
		ImageURL: '',
		IsFavor: 0,
		WorkflowCategory: '',
		WorkflowCategoryID: 41,
	});

	const [keyword, setKeyWord] = useState<string>('');
	const [procedureKeyWord, setProcedureKeyWord] = useState<string>('');
	const [selectedSheet, setSelectedSheet] = useState<any[]>([]);

	const debounceKeyword = useDebounce(keyword, 300);
	const debounceProcedureKeyWord = useDebounce(procedureKeyWord, 300);

	// Get the current date as a string
	const currentDate = moment().format('YYYY-MM-DD');

	// Get the date of the same day last month as a string
	const lastMonthDate = moment().subtract(1, 'months').format('YYYY-MM-DD');

	const renderDropdownIcon = () => {
		return (
			<View>
				<Icon src={ICONS.icArrowDown} width={8} height={8} tintColor={COLORS.black} />
			</View>
		);
	};

	const renderCustomizedButtonChild = (type: string) => {
		return (
			<View>
				<Text>{type === 'status' ? selectedOption?.Title : selectedProcedure?.Title}</Text>
			</View>
		);
	};
	const renderCustomizedRowChild = (e: any, type: string) => {
		return (
			<View
				style={{
					backgroundColor: 'white',
					flex: 1,
					alignItems: 'center',
					paddingHorizontal: 10,
					flexDirection: 'row',
				}}>
				<View style={{ width: '4%' }}>
					{type === 'status' && selectedOption?.ID === e.ID ? (
						<Icon src={ICONS.icCheck} width={8} height={8} tintColor={COLORS.black} />
					) : type === 'procedure' && selectedProcedure?.ID === e.ID ? (
						<Icon src={ICONS.icCheck} width={8} height={8} tintColor={COLORS.black} />
					) : null}
				</View>

				<Text
					style={{
						color: selectedOption?.ID === e.id ? COLORS.blueMain : COLORS.black,
						marginLeft: 10,
					}}>
					{e?.Title?.trim()}
				</Text>
			</View>
		);
	};

	useEffect(() => {
		const fromDate = fieldRef.current.FromDate?.getData()?.value;
		const toDate = fieldRef.current.ToDate?.getData()?.value;

		// getProcedureData({
		// 	data: JSON.stringify({ PerType: -1, WorkflowCategoryId: 0, Keyword: procedureKeyWord }),
		// 	func: 'getOrSearchListWorkflow',
		// 	flag: 0,
		// 	limit: 10,
		// 	offset: 0,
		// 	lid,
		// });

		const idString = selectedSheet.length > 0 ? selectedSheet?.map(item => item.ID).join(',') : '';

		getListSheetData({
			data: JSON.stringify({
				PerType: -1,
				WorkflowCategoryId: 0,
				Keyword: keyword,
				WorkflowId: selectedProcedure.WorkflowID,
				WorkflowStatus: selectedOption.ID,
				FromDate: fromDate.split('T')[0],
				ToDate: toDate.split('T')[0],
				ListItemNotGet: params?.ID,
			}),
			func: 'getList',
			resourcetype: 'SearchAddWorkflowRelated',
			flag: 0,
			limit: 10,
			offset: 0,
			lid,
			totalrecord: 0,
		});
	}, [params]);

	const callGetList = () => {
		const fromDate = fieldRef.current.FromDate?.getData();
		const toDate = fieldRef.current.ToDate?.getData();

		getListSheetData({
			data: JSON.stringify({
				PerType: -1,
				WorkflowCategoryId: 0,
				Keyword: keyword,
				WorkflowId: selectedProcedure.WorkflowID,
				WorkflowStatus: selectedOption.ID,
				FromDate: fromDate.split('T')[0],
				ToDate: toDate.split('T')[0],
				ListItemNotGet: params?.ID,
			}),
			func: 'getList',
			resourcetype: 'SearchAddWorkflowRelated',
			flag: 0,
			limit: 10,
			offset: 0,
			lid,
			totalrecord: 0,
		});
	};

	useEffect(() => {
		if (debounceKeyword.length > 2) {
			callGetList();
		}
	}, [debounceKeyword]);

	const onPressSearch = () => {
		callGetList();
	};

	useEffect(() => {
		if (debounceProcedureKeyWord.length > 2) {
			getProcedureData({
				data: JSON.stringify({ PerType: -1, WorkflowCategoryId: 0, Keyword: procedureKeyWord }),
				func: 'getOrSearchListWorkflow',
				flag: 0,
				limit: 10,
				offset: 0,
				lid,
			});
		}
	}, [debounceProcedureKeyWord]);

	const customBeanAppStatus = [
		{
			CreatedBy: 'null',
			ID: 0,
			Index: 8,
			IsShow: true,
			Modified: '2021-01-13T14:37:00',
			ModifiedBy: '',
			ResourceCategoryIds: 0,
			StatusDetails: 'null',
			Title: 'Tất cả',
			TitleEN: 'All',
			TotalRecord: 0,
		},
		...(beanAppStatus || []),
	];

	return (
		<SafeAreaView style={{ flex: 1 }}>
			<View style={{ flex: 1, paddingVertical: 10, paddingHorizontal: 10 }}>
				<View style={{ width: '100%', justifyContent: 'center', alignItems: 'center', marginBottom: 25 }}>
					<Text style={{ color: COLORS.trueBlue, fontWeight: '600', fontSize: 16 }}>Quy trình liên quan</Text>
					<TouchableOpacity style={{ position: 'absolute', left: 10 }} onPress={() => navigationRef.goBack()}>
						<Icon src={ICONS.icArrowLeft} width={14} height={14} tintColor={COLORS.black} />
					</TouchableOpacity>
					<TouchableOpacity
						style={{ position: 'absolute', right: 10 }}
						onPress={() => {
							const idString = selectedSheet.length > 0 ? `,${selectedSheet?.map(item => item.ID).join(',')}` : '';
							params?.callBackData({ listItemNotGet: `${params?.ID}${idString}`, listProcedures: selectedSheet });
							navigation.goBack();
							// navigate('TaskDetail', { listItemNotGet: params?.ID + '' + idString, listProcedures: selectedSheet });
						}}>
						<Icon src={ICONS.icCheck} width={16} height={16} tintColor={COLORS.northTexasGreen} />
					</TouchableOpacity>
				</View>

				<View
					style={{
						marginBottom: 10,
						flexDirection: 'row',
						alignItems: 'center',
						borderColor: 'silver',
						borderWidth: 1,
						borderRadius: 20,
					}}>
					<TextInput
						style={{
							height: 40,

							paddingHorizontal: 10,
							flex: 1,
						}}
						onChangeText={text => setKeyWord(text)}
						value={keyword}
						placeholder="Search..."
					/>
					<TouchableOpacity style={{ paddingHorizontal: 10 }} onPress={onPressSearch}>
						<Icon src={ICONS.icSearch} width={24} height={24} tintColor={COLORS.black} />
					</TouchableOpacity>
				</View>
				<DateTime
					ref={ref => (fieldRef.current[FormRefField.FromDate] = ref)}
					title="Từ ngày"
					isGrid
					defaultValue={lastMonthDate}
					name="DueDate"
					isDate
				/>
				<DateTime
					ref={ref => (fieldRef.current[FormRefField.ToDate] = ref)}
					title="Đến ngày"
					isGrid
					defaultValue={currentDate}
					name="DueDate"
					isDate
				/>

				<View style={{ marginVertical: 10 }}>
					<Text style={{ color: '#5E5E5E', fontSize: 11, marginBottom: 4 }} numberOfLines={1}>
						Tình trạng
					</Text>
					<SelectDropdown
						data={customBeanAppStatus}
						dropdownOverlayColor="transparent"
						onSelect={(selectedItem: any) => {
							setSelectedOption(selectedItem);
						}}
						renderDropdownIcon={renderDropdownIcon}
						renderCustomizedButtonChild={() => renderCustomizedButtonChild('status')}
						rowStyle={styles.rowStyle}
						rowTextStyle={styles.rowTextStyle}
						dropdownStyle={styles.dropdownStyle}
						renderCustomizedRowChild={e => renderCustomizedRowChild(e, 'status')}
						buttonStyle={styles.buttonStyle}
						buttonTextStyle={styles.buttonTextStyle}
					/>
				</View>

				<View style={{ marginVertical: 10 }}>
					<Text style={{ color: '#5E5E5E', fontSize: 11, marginBottom: 4 }} numberOfLines={1}>
						Quy trình
					</Text>
					<SelectDropdown
						data={procedure || []}
						searchInputStyle={{
							alignSelf: 'center',
							width: '90%',
							shadowColor: '#000',
							shadowOffset: {
								width: 0,
								height: 1,
							},
							shadowOpacity: 0.22,
							shadowRadius: 2.22,

							elevation: 3,
						}}
						onChangeSearchInputText={txt => setProcedureKeyWord(txt)}
						dropdownOverlayColor="transparent"
						search
						onSelect={(selectedItem: any) => {
							setSelectedProcedure(selectedItem);
						}}
						renderDropdownIcon={renderDropdownIcon}
						renderCustomizedButtonChild={() => renderCustomizedButtonChild('procedure')}
						rowStyle={styles.rowStyle}
						rowTextStyle={styles.rowTextStyle}
						dropdownStyle={styles.dropdownStyle}
						renderCustomizedRowChild={e => renderCustomizedRowChild(e, 'procedure')}
						buttonStyle={styles.buttonStyle}
						buttonTextStyle={styles.buttonTextStyle}
					/>
				</View>

				<ScrollView
					showsVerticalScrollIndicator={false}
					keyboardShouldPersistTaps="handled"
					onScrollBeginDrag={Keyboard.dismiss}
					contentContainerStyle={{ flexGrow: 1 }}>
					{listSheet?.Data?.map((item: any, key: number) => {
						const assignTo = JSON.parse(item.AssignedToInfo);
						const statusGroupItem = beanAppStatus?.find(v => v.ID === item?.StatusGroup);
						return (
							<View
								key={key.toString()}
								style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
								<View style={{ width: '5%', height: 50 }}>
									<TouchableOpacity
										onPress={() => {
											if (selectedSheet.some(e => e.ID === item.ID)) {
												setSelectedSheet(prev => prev.filter(e => e.ID !== item.ID));
											} else {
												setSelectedSheet(prev => [...prev, item]);
											}
										}}
										style={{
											width: 18,
											height: 18,
											borderRadius: 4,
											backgroundColor: 'white',
											borderColor: 'silver',
											borderWidth: 1,
											justifyContent: 'center',
											alignItems: 'center',
										}}>
										{selectedSheet.some(e => e.ID === item.ID) ? (
											<Icon src={ICONS.icCheck} width={8} height={8} tintColor={COLORS.black} />
										) : null}
									</TouchableOpacity>
								</View>
								<View key={item.ID} style={{ width: '95%' }}>
									<TaskCard
										// typeCurrent={typeCurrent}
										assignedToName={assignTo.Name}
										numExpand={assignTo.NumExpand}
										avatar={assignTo.ImagePath}
										defaultAvatar={assignTo.DefaultImagePath}
										status={item.StatusGroup}
										statusTitle={language === 'vi' ? statusGroupItem?.Title : statusGroupItem?.TitleEN}
										isTask
										isShowCode
										code={item.Title}
										typeCurrent="older"
										// fileCount={!!FileCount}
										// isFollow={!!IsFollow}
										title={item.Content}
										// time={Created}
										// description={Workflow}
										expire={item.DueDate}
									// onPress={() => {
									// 	if (item.ResourceCategoryId === 16 && item.ResourceSubCategoryId === 0) {
									// 	} else {
									// 	}
									// 	if (!Read) updateRead(ID);
									// }}
									/>
								</View>
							</View>
						);
					})}

					<View style={{ marginBottom: 100 }} />
				</ScrollView>
			</View>
		</SafeAreaView>
	);
};
const styles = StyleSheet.create({
	containerCheckBox: { flexDirection: 'row', flexWrap: 'wrap', padding: 2 },
	itemCheckBox: { flexDirection: 'row', marginRight: 20 },
	checkBox: { width: 16, height: 16 },
	nameCheckBox: { fontSize: 14, color: COLORS.black, marginLeft: 4 },
	title: { fontSize: 14, color: COLORS.blueMain },
	rowStyle: { backgroundColor: COLORS.white, height: 36 },
	rowTextStyle: { backgroundColor: COLORS.white },
	dropdownStyle: { backgroundColor: COLORS.white, borderRadius: 4 },
	buttonStyle: {
		height: 30,
		width: '100%',
		borderColor: '#E5E5E5',
		borderWidth: 0.8,
		alignItems: 'center',
		borderRadius: 4,
		backgroundColor: COLORS.white,
	},
	buttonTextStyle: { color: COLORS.black, fontSize: 14, textAlign: 'left' },
	multiSelect: {
		minHeight: 28,
		// borderBottomColor: 'gray',
		borderWidth: 0.8,
		width: '100%',
		paddingHorizontal: 10,
		borderRadius: 4,
		borderColor: '#E5E5E5',
	},
	viewItemMulti: {
		paddingHorizontal: 15,
		paddingVertical: 5,
	},
	containerRadio: {
		flexDirection: 'row',
		marginRight: 20,
		flexWrap: 'wrap',
		overflow: 'hidden',
	},
	buttonRadio: {
		flexDirection: 'row',
		marginRight: 20,
		padding: 5,
	},
	viewRadio: {
		width: 18,
		height: 18,
		borderWidth: 1,
		borderRadius: 10,

		alignItems: 'center',
		justifyContent: 'center',
	},
	checked: { backgroundColor: COLORS.blueMain, width: 9, height: 9, borderRadius: 9 },
	viewMulti: {
		paddingVertical: 5,
		width: '90%',
		flexDirection: 'row',
		alignItems: 'center',
		zIndex: 1,
		overflow: 'hidden',
		flexWrap: 'wrap',
	},
	titleContaier: { color: COLORS.davyGrey, fontSize: 11, marginBottom: 4 },
});
