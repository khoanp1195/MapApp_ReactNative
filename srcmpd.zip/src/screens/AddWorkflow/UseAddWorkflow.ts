/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable @typescript-eslint/require-await */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
import { useEffect, useState } from 'react';

import { Q } from '@nozbe/watermelondb';
import { useDatabase } from '@nozbe/watermelondb/hooks';
import { ShowLoading } from 'components/Atoms/Loading/LoadingGlobal';
import { TABLE } from 'database/contains';
import { FormFieldInfoPrams } from 'screens/TaskDetail';
import { IItemParams } from 'screens/WorkflowDetails/WorkflowDetails';
import { useAppDispatch, useAppSelector } from 'stores';
import { changeItemInfo, getDetailsNewWorkflow, getFormWorkFlow } from 'stores/Workflows/sliceWorkflow';

// eslint-disable-next-line import/no-cycle

interface FormsParams {
	FormFieldInfo: Array<FormFieldInfoPrams>;
	InfoCollection: {
		FormDefineInfo: string;
	};
	rid: string | undefined;
	DateModified: string;
}

export interface IItemRelated {
	ListID: string;
	ID: number;
}

export const useAddWorkflow = (infoForm: IItemParams, itemRelated: IItemRelated) => {
	const dispatch = useAppDispatch();
	const [forms, setForm] = useState<FormsParams>({});
	const [refreshing, setRefreshing] = useState(false);
	const { language } = useAppSelector(state => state.dataNotRemove);

	const { details } = useAppSelector(store => store.workflow);
	const [loadingDetails, setLoadingDetails] = useState(false);

	const ListAction = JSON.parse(details.FormConfig?.ListButtonAction || '[]');

	const lid = language === 'vi' ? 1066 : 1033;
	const database = useDatabase();

	const { ID, ListID = '', WorkflowID: WorkflowId } = infoForm || {};

	const success = async (res: {
		data: { FormFieldInfo?: any; InfoCollection: { FormDefineInfo: string }; DateModified: string };
	}) => {
		try {
			if (res?.data?.FormFieldInfo) {
				const { FormFieldInfo, InfoCollection, DateModified } = res?.data || {};

				setForm({
					FormFieldInfo,
					InfoCollection,
					rid: ID,
					DateModified,
				});
				await database.write(async () => {
					await database.get(TABLE.TASKFORM).create(field => {
						field.ListId = ListID;
						field.FormFieldInfo = JSON.stringify(FormFieldInfo);
						field.InfoCollection = InfoCollection.FormDefineInfo;
						field.DateModified = DateModified;
					});
				});
			}
		} catch (error) {
			//
		}
	};

	const getFormTaskDetailsSuccess = async res => {
		try {
			setRefreshing(false);
			if (res?.data?.FormFieldInfo) {
				const { FormFieldInfo, InfoCollection, DateModified } = res?.data || {};
				setForm({
					FormFieldInfo,
					InfoCollection,
					rid: ID,
					DateModified,
				});
				const formDB = await database.get(TABLE.TASKFORM).query(Q.where('ListId', ListID)).fetch();
				if (formDB?.length) {
					await database.write(async () => {
						formDB[0].update((form: { FormFieldInfo: string; InfoCollection: string; DateModified: string }) => {
							form.FormFieldInfo = JSON.stringify(FormFieldInfo);
							form.InfoCollection = InfoCollection.FormDefineInfo;
							form.DateModified = DateModified;
						});
					});
				}
			}
		} catch (error) {
			console.log('error', error);
			//
		}
	};

	const queryFormTask = async () => {
		try {
			const formDB = await database.get(TABLE.TASKFORM).query(Q.where('ListId', ListID)).fetch();
			if (formDB?.length) {
				const { _raw: rawInfo } = formDB[0] || {};
				setForm({
					FormFieldInfo: JSON.parse(rawInfo?.FormFieldInfo || '[]'),
					InfoCollection: { FormDefineInfo: rawInfo?.InfoCollection },
					rid: ID,
					DateModified: rawInfo?.DateModified,
				});

				const rowInfo: RowDefineInfoCollection[][] =
					JSON.parse(rawInfo?.InfoCollection || '[]')?.[0]?.rowDefineInfoCollection || [];
				let refListName = {};
				rowInfo.forEach(elm => {
					elm.forEach(e => {
						refListName = { ...refListName, [e.internalName]: '' };
					});
				});

				// dispatch(changeItemInfo(refListName));
			} else {
				dispatch(
					getFormWorkFlow({
						params: {
							listid: ListID,
							wid: WorkflowId,
							lid,
						},
						success,
					}),
				);
			}
		} catch (error) {
			//
		}
	};

	const getDetails = () => {
		ShowLoading(true);
		dispatch(
			getDetailsNewWorkflow({
				params: {
					lid,
					relatedListID: itemRelated?.ListID || '',
					itemRLID: itemRelated?.ID || '',
					listId: ListID,
				},
				success: () => {
					ShowLoading(false);
					setLoadingDetails(false);
				},
				failed: () => {
					ShowLoading(false);
					setLoadingDetails(false);
				},
			}),
		);
	};

	const onRefresh = () => {
		setRefreshing(true);
		dispatch(
			getFormWorkFlow({
				params: {
					listid: ListID,
					wid: WorkflowId,
					lid,
					modified: forms?.DateModified,
				},
				success: getFormTaskDetailsSuccess,
			}),
		);
		getDetails();
	};

	useEffect(() => {
		let isMounted = true;
		if (isMounted) {
			queryFormTask();
			setLoadingDetails(true);
			getDetails();
		}
		return () => {
			isMounted = false;
			dispatch(changeItemInfo({}));
		};
	}, []);

	return { forms, refreshing, onRefresh, ListAction, details, loadingDetails };
};
