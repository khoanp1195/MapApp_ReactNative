/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable react/no-unstable-nested-components */
import React, { useRef } from 'react';

import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { ShowLoading } from 'components/Atoms/Loading/LoadingGlobal';
import ActionButton from 'components/WorkflowDetails/ActionButton';
import GirdPreview from 'components/WorkflowDetails/Grid/GirdPreview';
import ToastWorkflow from 'components/WorkflowDetails/ToastWorkflow';
import Workflow from 'components/WorkflowDetails/Workflows/Workflow';
import { ICONS } from 'config/images';
import useSystem from 'hooks/useSystem';
import { navigate } from 'navigation/RootNavigation';
import { View, Text, FlatList, Platform, RefreshControl, ScrollView, Alert, KeyboardAvoidingView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { FormFieldInfoPrams } from 'screens/TaskDetail';
import AttachmentField from 'screens/TaskDetail/Field/AttachmentField';
import Calculated from 'screens/TaskDetail/Field/Calculated';
import Choose from 'screens/TaskDetail/Field/Choose';
import Currency from 'screens/TaskDetail/Field/Currency';
import DateTime from 'screens/TaskDetail/Field/DateTime';
import Lookup from 'screens/TaskDetail/Field/Lookup';
import LookupDataSource from 'screens/TaskDetail/Field/LookupDataSource';
import MultipleLines from 'screens/TaskDetail/Field/MultipleLines';
import NumberField from 'screens/TaskDetail/Field/Number';
import Radio from 'screens/TaskDetail/Field/Radio';
import SingleLine from 'screens/TaskDetail/Field/SingleLine';
import UserGroup from 'screens/TaskDetail/Field/UserGroup';
import { IItemParams } from 'screens/WorkflowDetails/WorkflowDetails';
import { useAppDispatch, useAppSelector } from 'stores';
import { reloadWorkflow } from 'stores/System';
import { postActionWorkflow } from 'stores/Workflows/sliceWorkflow';
import { translate } from 'utils/translate';

import { IItemRelated, useAddWorkflow } from './UseAddWorkflow';

const Header = ({
	title = '',
	loadingDetails,
	isFromSearch,
}: {
	title: string | undefined;
	loadingDetails: boolean;
	isFromSearch: boolean;
}) => {
	const navigation = useNavigation();
	const insets = useSafeAreaInsets();

	const onGoback = () => {
		if (isFromSearch) {
			navigation.pop(2);
		} else {
			navigation.goBack();
		}
	};

	return (
		<View
			style={{
				flexDirection: 'row',
				shadowColor: '#000',
				shadowOffset: {
					width: 0,
					height: 2,
				},
				shadowOpacity: 0.1,
				shadowRadius: 2,

				elevation: 5,
				backgroundColor: 'white',
				paddingTop: insets.top,
				paddingBottom: 10,
				paddingHorizontal: 16,
			}}>
			<View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
				<Icon src={ICONS.icArrowMenu} width={24} height={24} tintColor="rgba(0, 0, 0, 1)" onPress={onGoback} />
				<Text
					numberOfLines={2}
					style={{ fontSize: 16, fontWeight: '700', marginHorizontal: 12, color: 'rgba(0, 0, 0, 1)' }}>
					{loadingDetails ? '' : title || ''}
				</Text>
			</View>
		</View>
	);
};

interface RowDefineInfoCollection {
	author: string;
	className: string;
	id: string;
	internalName: string;
}

type Params = {
	Item: {
		item: IItemParams;
		itemRelated: any;
		isFromSearch: boolean;
	};
};

const AddWorkflow = () => {
	const dispatch = useAppDispatch();
	const naviagtion = useNavigation<any>();
	const route = useRoute<RouteProp<Params, 'Item'>>();
	const itemPrams: IItemParams = route.params?.item || {};
	const itemRelated: IItemRelated = route.params?.itemRelated || {};
	const isFromSearch = route.params?.isFromSearch;
	const refToastWorkflow = useRef();
	// const { Title, TitleEN } = itemPrams || {};
	const fieldRef = useRef<any>({});
	const { isVN } = useSystem();

	const refWorkflow = useRef<{ getRelated: () => void; updateRelated: (value: any) => void } | null>();
	const refAttach = useRef<{ getAttach: () => void; require: () => void } | null>();

	const { forms, onRefresh, refreshing, ListAction, details, loadingDetails } = useAddWorkflow(itemPrams, itemRelated);
	const { FormFieldInfo, InfoCollection } = forms || {};

	const Title = details.FormConfig?.WorkflowTitle || '';

	const { DefindJsonObj = '{}' } = details?.FormConfig || {}; // ListDocumentCategory
	const { FieldNameHides = '' } = JSON.parse(DefindJsonObj || '{}');

	const FormDefineInfo: string = InfoCollection?.FormDefineInfo || '[]';

	const PFormDefineInfo: {
		rowDefineInfoCollection: RowDefineInfoCollection[][];
		moreOptionInfo: { allowAttach: boolean };
	}[] = JSON.parse(FormDefineInfo || '[]');
	const rowInfo: RowDefineInfoCollection[][] = PFormDefineInfo?.[0]?.rowDefineInfoCollection || [];

	const moreOptionInfo = PFormDefineInfo?.[0]?.moreOptionInfo;

	const listFieldNameHides = useAppSelector(store => store.workflow.listFieldNameHides);

	const getDataField = (name: string) => {
		const data: FormFieldInfoPrams | undefined = FormFieldInfo?.find(list => list.Name === name);
		const { Title: ti = '', TitleEN: tiEN = '', FieldTypeId = 0, Option: options = '', Guid = '' } = data || {};
		const title = isVN ? ti : tiEN;
		return {
			title,
			FieldTypeId,
			options,
			Guid,
		};
	};

	const infoItem = useAppSelector(store => store.workflow.itemInfo);

	const RenderFeild = (internalName: string, index: number) => {
		const isHideFiled = FieldNameHides?.includes(internalName?.replace('_17_', '')?.replace('_Mobile', ''));
		const islNameHides = listFieldNameHides?.includes(internalName?.replace('_17_', '')?.replace('_Mobile', ''));
		if (islNameHides || isHideFiled) return null;

		const Field = getDataField(internalName?.replace('_17_', '')?.replace('_Mobile', '')); // _Mobile is not supported
		const { title, FieldTypeId, options, Guid } = Field;

		const setFeildRef = (ref: any) => {
			if (Guid) {
				fieldRef.current[Guid] = ref;
			}
		};

		if (internalName === '_18_' && moreOptionInfo?.allowAttach)
			return <AttachmentField ref={refAttach} moreOptionInfo={moreOptionInfo} options={options} />;

		if (internalName?.includes('_17_')) {
			return (
				<GirdPreview
					ref={setFeildRef}
					title={title}
					internalName={internalName}
					// ID={ID}
					// SPItemId={SPItemId}
					forms={forms}
					refreshing={false}
					options={options}
					itemPrams={itemPrams}
				/>
			);
		}

		switch (FieldTypeId) {
			case 1:
				return <SingleLine ref={setFeildRef} title={title} options={options} internalName={internalName} />;
			case 2:
				return <MultipleLines ref={setFeildRef} title={title} options={options} internalName={internalName} />;
			case 3:
				return (
					<Choose
						ref={setFeildRef}
						title={title}
						options={options}
						internalName={internalName}
						refreshing={false}
						index={index}
						isAddWorkflow
					/>
				);
			case 4:
				return (
					<NumberField ref={setFeildRef} title={title} options={options} internalName={internalName} Guid={Guid} />
				);
			case 5:
				return <DateTime ref={setFeildRef} title={title} options={options} internalName={internalName} />;
			case 7:
				return (
					<UserGroup
						ref={setFeildRef}
						title={title}
						options={options}
						internalName={internalName}
						// ID={ID}
						index={index}
					/>
				);
			case 8:
				return <Currency ref={setFeildRef} title={title} options={options} internalName={internalName} />;
			case 9:
				return <Calculated ref={setFeildRef} title={title} options={options} internalName={internalName} />;
			case 10:
				return <Radio ref={setFeildRef} title={title} options={options} internalName={internalName} />;
			case 13:
				return (
					<Lookup
						index={index}
						ref={setFeildRef}
						title={title}
						options={options}
						internalName={internalName}
						Guid={Guid}
						refreshing={false}
						FieldInfo={FormFieldInfo}
					/>
				);
			case 14:
				return (
					<Lookup
						index={index}
						ref={setFeildRef}
						title={title}
						options={options}
						internalName={internalName}
						Guid={Guid}
						refreshing={false}
						FieldInfo={FormFieldInfo}
					/>
				);

			case 18:
				return (
					<LookupDataSource
						ref={setFeildRef}
						title={title}
						options={options}
						internalName={internalName}
						Guid={Guid}
						index={index}
					/>
				);

			default:
				return null;
		}
	};

	const renderItem = ({ item }: { item: RowDefineInfoCollection[] }) => {
		if (!item?.length) return null;
		return (
			<View
				style={{
					flexDirection: 'row',
					justifyContent: 'space-between',
					flex: 1,
					marginHorizontal: 16,
				}}>
				{item?.map((listItem: RowDefineInfoCollection) => {
					return (
						<View style={{ flex: 1 }} key={listItem.id}>
							{RenderFeild(listItem.internalName, item.length)}
						</View>
					);
				})}
			</View>
		);
	};

	const getItemLayout = (_data: unknown, index: number) => ({
		length: 70,
		offset: 70 * index,
		index,
	});

	const getListWorkflowRelated = () => {
		let request: Array<{
			ID: number;
			ListID: string;
			WorkflowId: number;
			Title: string;
		}> = [];
		const related: { WorkflowRelatedId: number; ID: number; ListID: string; WorkflowId: number; Title: string }[] =
			refWorkflow.current?.getRelated() || [];
		related.forEach(item => {
			if (!item?.WorkflowRelatedId) {
				request = [
					...request,
					{
						ID: item.ID,
						ListID: item?.ListID,
						WorkflowId: item?.WorkflowId,
						Title: item?.Title,
					},
				];
			}
		});
		return request;
	};

	const getAttachments = () => {
		let listConvert: Array<{
			Name: string;
			Base64?: string;
			AttachTypeId: number;
			AttachTypeName: string;
		}> = [];
		const attach: {
			Title: string;
			Extension: string;
			ID: number;
			Base64: string;
			AttachTypeId: number;
			AttachTypeName: string;
		}[] = refAttach.current?.getAttach() || [];
		const listAtatch = attach?.filter(attachment => !attachment?.ID);
		listAtatch?.forEach(attachment => {
			listConvert = [
				...listConvert,
				{
					Name: `${attachment.Title}.${attachment.Extension}`,
					Base64: attachment?.Base64 || attachment?.base64,
					AttachTypeId: attachment.AttachTypeId,
					AttachTypeName: attachment.AttachTypeName,
				},
			];
		});
		return listConvert;
	};

	const saveSuccess = (res, action) => {
		let message = `${action?.Title} ${translate('successfully')}`;
		let stt = 2;
		if (res?.status === 'SUCCESS') {
			if (res?.data?.HaveStepDynamic) {
				message = translate('processChooseUser');
				stt = 1;
			} else {
				dispatch(reloadWorkflow(true));
				naviagtion.pop(2);
			}
		} else {
			stt = 3;
			message = res?.mess?.Value;
		}
		refToastWorkflow.current?.show({
			status: stt,
			message,
		});
		ShowLoading(false);

		// if (action?.ActionCode === 'SAVE') {
		// 	const message = `${action?.Title} ${translate('successfully')}`;
		// 	const stt = 2;
		// 	refToastWorkflow.current?.show({
		// 		status: stt,
		// 		message,
		// 	});
		// } else {
		// 	naviagtion.goBack();
		// }
	};

	function getValue(Name: string, FieldTypeId: number, Guid: string) {
		const valueItem: string | any[] = infoItem?.[Name];
		if ([7].includes(FieldTypeId)) {
			const data = valueItem?.includes('[') ? JSON?.parse(valueItem || '[]') : valueItem;

			let id: string[] = [];
			const list = data || [];
			if (Array.isArray(list)) {
				list?.forEach((item: { ID: string }) => {
					id = [...id, item.ID];
				});
			}
			return id.toString();
		}
		if ([13, 14].includes(FieldTypeId)) {
			const grid: { isGrid: boolean; value: any } = fieldRef.current?.[Guid]?.getGrid
				? fieldRef.current?.[Guid]?.getGrid()
				: {};
			if (grid?.isGrid) return grid?.value;

			const ArrValueSplit: string[] = typeof valueItem === 'string' ? valueItem?.split(';#') : [];

			const Value: string[] = ArrValueSplit.filter((item: string) => item !== '').filter(
				(_: unknown, index: number) => index % 2 === 0,
			);

			return Value.toString();
		}
		return valueItem?.toString()?.trim();
	}

	const getFormData = () => {
		try {
			const FieldInfo = forms?.FormFieldInfo;
			const listNameChanged = Object.keys(infoItem);
			let ListData: Array<any> = [];
			FieldInfo.forEach(fieldInfo => {
				if (listNameChanged.includes(fieldInfo?.Name) && !listFieldNameHides.includes(fieldInfo?.Name)) {
					let detailsListInfo = null;
					const data: { detailsTableInfoCollection: any }[] = JSON.parse(forms?.InfoCollection?.FormDefineInfo || '[]');
					const detailsTableInfoCollection: Array<any> = (data?.length && data[0].detailsTableInfoCollection) || [];
					detailsTableInfoCollection?.forEach((res: { id: string; detailsListInfo: any }) => {
						if (res.id === fieldInfo?.Guid) {
							detailsListInfo = res.detailsListInfo;
						}
					});

					const convertData = {
						Name: fieldInfo.Name,
						Guid: fieldInfo?.Guid,
						Value: getValue(fieldInfo.Name, fieldInfo?.FieldTypeId, fieldInfo?.Guid) || null,
						FieldTypeId: fieldInfo?.FieldTypeId,
						DetailsListInfo: detailsListInfo,
					};
					ListData = [...ListData, convertData];
				}
			});
			return ListData;
		} catch (error) {
			console.log('error', error);
			//
		}
	};

	const callActionDetails = (action: { ActionCode: string }) => {
		const formData = getFormData();
		const attach = getAttachments();
		const workflowrelated = getListWorkflowRelated();
		let params = {
			func: action.ActionCode,
			itemInfo: formData,
			attachment: attach,
			workflowrelated,
			rid: 0,
			ListId: itemPrams.ListID,
		};

		if (itemRelated?.ListID) {
			params = { ...params, relatedListID: itemRelated?.ListID, itemRLID: itemRelated?.ID };
		}
		ShowLoading(true);
		dispatch(
			postActionWorkflow({
				params,
				success: res => saveSuccess(res, action),
			}),
		);
	};

	const checkRequire = (action: { ActionCode: string }) => {
		try {
			if (action.ActionCode === 'SAVE') return callActionDetails(action);
			let passing = true;
			const rqAttach: boolean = refAttach.current?.require() || false;
			if (refAttach.current?.require && rqAttach === false) passing = false;
			FormFieldInfo.forEach((field: { Guid: string }) => {
				const require = fieldRef.current?.[field?.Guid]?.require();
				if (require === false) passing = false;
			});
			if (passing) {
				callActionDetails(action);
			} else {
				return Alert.alert(translate('requestedInformation'));
			}
		} catch (error) {
			//
		}
	};

	const onCallbackRelated = (rl: any) => {
		refWorkflow.current?.updateRelated(rl);
	};

	const onPressCallAction = (action: { ActionCode: string }) => {
		if (['NEWRELATED'].includes(action.ActionCode))
			return navigate('CreateRelated', {
				itemPrams: { ...itemPrams, Content: Title },
				onCallbackRelated,
				from: 'addWorkflow',
				relatedAdd: refWorkflow.current?.getRelated(),
			});
		checkRequire(action);
	};

	return (
		<View style={{ flex: 1 }}>
			<Header title={Title} loadingDetails={loadingDetails} isFromSearch={isFromSearch} />
			<KeyboardAvoidingView
				behavior={Platform.OS === 'ios' ? 'padding' : undefined}
				keyboardVerticalOffset={10}
				style={{ flex: 1 }}>
				<ScrollView
					showsVerticalScrollIndicator={false}
					keyboardDismissMode="on-drag"
					refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
					style={{ flex: 1 }}>
					<FlatList
						// inverted
						data={rowInfo || []}
						keyExtractor={(item, index) => index?.toString()}
						renderItem={renderItem}
						getItemLayout={getItemLayout}
						scrollEnabled={false}
						initialNumToRender={10}
						maxToRenderPerBatch={10}
						updateCellsBatchingPeriod={10}
						renderToHardwareTextureAndroid
						removeClippedSubviews={Platform.OS !== 'ios'}
						nestedScrollEnabled={false}
						shouldRasterizeIOS
						showsVerticalScrollIndicator={false}
					/>

					<Workflow ref={refWorkflow} isAddWorkflow />
				</ScrollView>
			</KeyboardAvoidingView>
			<ToastWorkflow ref={refToastWorkflow} />
			<ActionButton ListAction={ListAction} onPressCallAction={onPressCallAction} loadingDetails={loadingDetails} />
		</View>
	);
};

export default AddWorkflow;
