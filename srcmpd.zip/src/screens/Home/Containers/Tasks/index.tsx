/* eslint-disable prettier/prettier */
import React, { useCallback, useRef } from 'react';

import en from 'assets/i18n/en';
import { EmptyState } from 'components/Atoms/EmptyState';
import { Loading } from 'components/Atoms/Loading';
import { TaskCard } from 'components/Organisms/TaskCard';
import { TaskFilter } from 'components/Organisms/TaskFilter';
import { COLORS, defaultImgUri } from 'config';
import { ActivityIndicator, RefreshControl, SectionList, View } from 'react-native';
import { Assigned, ResourcetypeTask } from 'services/Tasks/types';
import { translate } from 'utils/translate';

import { Container, styles } from './styles';
import { useTasks } from './useTasks';
import { TextCustom, Wrapper } from '../../styles';

interface Props {
	type: ResourcetypeTask;
}

export const TasksContainer: React.FC<Props> = ({ type }) => {
	const refSectionList = useRef()
	const {
		page,
		bottom,
		dataRes,
		loading,
		language,
		refreshing,
		customizeTasks,
		isOpenFilter,
		currentFilter,
		beanAppStatus,
		refreshPage,
		handleFillter,
		handleEndReached,
		handleNavigateToDetail,
		handleNavigateToTask,
		updateRead,
	} = useTasks({
		type,
	});
	const renderTitle = useCallback(
		(title: string) => {
			return (
				<Wrapper mLeft={15} mTop={14} mBottom={14}>
					<TextCustom allowFontScaling={false} fw={700} fs={15} lh={20} color={COLORS.darkJungleGreen}>
						{translate(title as keyof typeof en)}
					</TextCustom>
				</Wrapper>
			);
		},
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[language],
	);

	if (isOpenFilter) return <TaskFilter onApply={handleFillter} type={type} currentFilter={currentFilter} />;

	return (
		<Container>
			{!customizeTasks && page === 0 && loading ? (
				<Loading />
			) : (
				<SectionList
					ref={refSectionList}
					sections={
						!customizeTasks
							? []
							: [
								{ title: 'today', data: customizeTasks?.today || [] },
								{ title: 'yesterday', data: customizeTasks?.yesterday || [] },
								{ title: 'older', data: customizeTasks?.beforeYesterday || [] },
							]
					}
					renderSectionHeader={({ section: { title, data } }) => (data?.length > 0 ? renderTitle(title) : null)}
					refreshControl={
						<RefreshControl refreshing={refreshing} onRefresh={refreshPage} tintColor={COLORS.trueBlue} />
					}
					contentContainerStyle={styles.listContentContainer}
					keyExtractor={(item, index) => index.toString()}
					showsVerticalScrollIndicator={false}
					onEndReached={handleEndReached}
					ListFooterComponent={
						!refreshing && dataRes?.Data && loading ? (
							<Wrapper style={{ backgroundColor: COLORS.whiteSmoke }} mBottom={bottom} mTop={24}>
								<ActivityIndicator size="small" color={COLORS.trueBlue} />
							</Wrapper>
						) : null
					}
					renderItem={({ item, index }) => {
						const {
							Read,
							Content,
							DueDate,
							IsFollow,
							Workflow,
							Created,
							FileCount,
							StatusGroup,
							AssignedByInfo,
							AssignedToInfo,
							typeCurrent,
							ID,
							ResourceCategoryId,
						} = item || {};

						const isTask = ResourceCategoryId === 16;

						const statusGroupItem = beanAppStatus?.find(v => v.ID === StatusGroup);
						const {
							DefaultImagePath = '',
							Name,
							NumExpand,
							ImagePath = '',
						} = JSON.parse(type === ResourcetypeTask.MYTASK ? AssignedByInfo : AssignedToInfo || '{}') as Assigned;
						return (
							<View style={{ backgroundColor: Read ? COLORS.white : COLORS.aliceBlue }}>
								<TaskCard
									isTask={isTask}
									type={type}
									typeCurrent={typeCurrent}
									assignedToName={Name}
									numExpand={NumExpand}
									avatar={ImagePath}
									defaultAvatar={DefaultImagePath}
									status={StatusGroup}
									statusTitle={language === 'vi' ? statusGroupItem?.Title : statusGroupItem?.TitleEN}
									fileCount={!!FileCount}
									isFollow={!!IsFollow}
									title={Content}
									time={Created}
									description={Workflow}
									expire={DueDate}
									onPress={() => {
										if (item.ResourceCategoryId === 16 && item.ResourceSubCategoryId === 0) {
											handleNavigateToTask(item);
										} else {
											handleNavigateToDetail(item);
										}
										if (!Read) updateRead(ID);
									}}
								/>
							</View>
						);
					}}
					ListEmptyComponent={<EmptyState />}
				/>
			)}
		</Container>
	);
};
