import { StyleSheet } from 'react-native';
import styled from 'styled-components/native';

export const Container = styled.View`
	flex: 1;
`;

export const styles = StyleSheet.create({
	listContentContainer: {
		flexGrow: 1,
		paddingBottom: 30,
	},
});
