import { COLORS } from 'config';
import styled from 'styled-components/native';

type TextCustomProps = {
	fs?: number;
	color?: string;
	lh?: number;
	fw?: number;
	mBottom?: number;
};

type WrapperProps = {
	mTop?: number;
	mBottom?: number;
	mLeft?: number;
	mRight?: number;
};

export const TextCustom = styled.Text<TextCustomProps>`
	font-size: ${props => (props.fs ? props.fs : 0)}px;
	line-height: ${props => (props.lh ? props.lh : 0)}px;
	font-weight: ${props => (props.fw ? props.fw : 0)};
	margin-bottom: ${props => (props.mBottom ? props.mBottom : 0)}px;
	margin-left: 5px;
`;

export const Wrapper = styled.View<WrapperProps>`
	padding-top: ${props => (props.mTop ? props.mTop : 0)}px;
	padding-right: ${props => (props.mRight ? props.mRight : 0)}px;
	padding-left: ${props => (props.mLeft ? props.mLeft : 0)}px;
	padding-bottom: ${props => (props.mBottom ? props.mBottom : 0)}px;
	background-color: ${COLORS.whiteSmoke};
`;
export const Leading = styled.Pressable`
	flex-direction: row;
	align-items: center;
`;

export const Trailing = styled.View`
	flex-direction: row;
	align-items: center;
`;
