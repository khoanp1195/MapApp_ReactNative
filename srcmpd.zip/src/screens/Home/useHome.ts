import { useEffect, useRef } from 'react';

import { useAppDispatch, useAppSelector } from 'stores';
import { updateTurnOnFilterMyRequest, updateTurnOnFilterMyTask } from 'stores/Home';
import { updateStatusDrawer } from 'stores/System';

export const useHome = (params: { index: number }) => {
	const { index } = params || {};
	const dispatch = useAppDispatch();
	const { count } = useAppSelector(state => state.count);

	const countTaskRef = useRef({
		my_task: 0,
		my_request: 0,
	});

	const { language } = useAppSelector(state => state.dataNotRemove);
	const customerInfo = useAppSelector(state => state.dataNotRemove.customer);
	const { isTurnOnFilterMyTask, isTurnOnFilterMyRequest } = useAppSelector(state => state.home);

	useEffect(() => {
		countTaskRef.current = {
			my_task: count?.CountMyTask || 0,
			my_request: count?.CountMyRequest || 0,
		};
	}, [count]);

	const handleOpenDrawer = () => dispatch(updateStatusDrawer(true));

	const handleTogleFilter = () =>
		dispatch(
			index === 0
				? updateTurnOnFilterMyTask(!isTurnOnFilterMyTask)
				: updateTurnOnFilterMyRequest(!isTurnOnFilterMyRequest),
		);

	return {
		handleOpenDrawer,
		language,
		openFilter: index === 0 ? isTurnOnFilterMyTask : isTurnOnFilterMyRequest,
		countTaskRef,
		customerInfo,
		handleTogleFilter,
	};
};
