/* eslint-disable react/no-children-prop */
/* eslint-disable react/no-unstable-nested-components */
/* eslint-disable react-hooks/rules-of-hooks */
/* eslint-disable react/jsx-props-no-spreading */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable react-hooks/exhaustive-deps */

import React, { useEffect, useRef } from 'react';

import { Text } from '@react-native-material/core';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import { useIsFocused, useRoute } from '@react-navigation/native';
import AllApps from 'components/Apps/AllApps';
import FavoriteApps from 'components/Apps/FavoriteApps';
import TabbarApps from 'components/Apps/TabbarApps';
import { Icon } from 'components/Atoms/Icon';
import { Header } from 'components/Organisms/Header';
import { ICONS } from 'config';
import useSystem from 'hooks/useSystem';
import { navigate } from 'navigation/RootNavigation';
import { RoutesNames } from 'navigation/RoutesNames';
import { TouchableOpacity, View, Animated, ScrollView } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppDispatch } from 'stores';
import { IItemFavorite } from 'stores/Home';
import { updateStatusDrawer } from 'stores/System';
import { translate } from 'utils/translate';

const Tab = createMaterialTopTabNavigator();

const AppsScreen = () => {
	const dispatch = useAppDispatch();
	const route = useRoute();
	const insets = useSafeAreaInsets();

	useSystem();

	useEffect(() => {
		navigate(route?.params?.screen || 'all_apps');
	}, [route.params]);

	const refAllApps = useRef<{ handleFovorite: (item: IItemFavorite, flag: number) => void } | null>();

	const handleOpenDrawer = () => dispatch(updateStatusDrawer(true));

	const onUpdateFavoriteAllApps = (item: IItemFavorite, flag: number) => {
		refAllApps.current?.handleFovorite(item, flag);
	};

	const leading = () => (
		<View style={{ flexDirection: 'row', alignItems: 'center' }}>
			<Icon
				src={ICONS.icMenu}
				width={16}
				height={16}
				tintColor="rgba(0, 0, 0, 1)"
				onPress={handleOpenDrawer}
				style={{ marginTop: 2 }}
			/>

			<Text style={{ fontSize: 20, fontWeight: '700', marginLeft: 10 }}>{translate('apps')}</Text>
		</View>
	);

	const trailing = () => (
		<View style={{ flexDirection: 'row' }}>
			<TouchableOpacity
				onPress={() => {
					navigate(RoutesNames.SearchApps, { onUpdateFavoriteAllApps });
				}}>
				<Icon src={ICONS.icSearchApps} width={24} height={24} />
			</TouchableOpacity>
		</View>
	);

	return (
		// <SafeAreaView style={{ flex: 1 }} edges={['top']}>
		<View style={{ flex: 1, backgroundColor: 'transparent', paddingTop: insets.top }}>
			<Header leading={leading()} trailing={trailing()} />
			<Tab.Navigator
				screenOptions={{ lazy: true, swipeEnabled: false }}
				tabBar={props => {
					const translateValue = useRef(new Animated.Value(0)).current;
					const convertProps = { ...props, translateValue };
					return <TabbarApps {...convertProps} />;
				}}
				initialRouteName="all_apps"
				sceneContainerStyle={{
					backgroundColor: 'transparent',
				}}
				style={{ backgroundColor: 'transparent' }}>
				<Tab.Screen name="all_apps" children={props => <AllApps {...props} ref={refAllApps} />} />
				<Tab.Screen
					name="favorite"
					children={props => {
						const convertProps = { ...props, onUpdateFavoriteAllApps };
						return <FavoriteApps {...convertProps} />;
					}}
				/>
			</Tab.Navigator>
		</View>
		// </SafeAreaView>
	);
};

export default AppsScreen;
