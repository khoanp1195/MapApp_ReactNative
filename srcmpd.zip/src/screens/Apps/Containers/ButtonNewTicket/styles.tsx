import { COLORS } from 'config';
import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
	container: {
		position: 'absolute',
		bottom: 100,
		right: 15,
		width: 48,
		height: 48,
		backgroundColor: COLORS.trueBlue,
		borderRadius: 50,
		justifyContent: 'center',
		alignItems: 'center',
		shadowColor: '#000',
		shadowOffset: {
			width: 0,
			height: 5,
		},
		shadowOpacity: 0.5,
		shadowRadius: 3.84,

		elevation: 10,
	},

	textInput: { fontStyle: 'italic' },
});
