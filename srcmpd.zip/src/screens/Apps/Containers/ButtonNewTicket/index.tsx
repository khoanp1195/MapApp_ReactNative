/* eslint-disable react/jsx-props-no-spreading */
import React, { useRef } from 'react';

import { Icon } from 'components/Atoms/Icon';
import { ICONS } from 'config';
import { ImageSourcePropType, TouchableOpacity, Animated, PanResponder, Dimensions } from 'react-native';

import { styles } from './styles';

export const ButtomNewTicket = ({
	onPress,
	cStyle = {},
	icon,
	sizeIcon = 24,
}: {
	onPress?: () => void;
	cStyle?: any;
	icon?: ImageSourcePropType;
	sizeIcon?: number;
}) => {
	const pan = useRef(new Animated.ValueXY()).current;

	const panResponder = useRef(
		PanResponder.create({
			onMoveShouldSetPanResponder: () => true,

			onPanResponderGrant: () => {
				pan.setOffset({
					x: pan.x._value,
					y: pan.y._value,
				});
			},
			onPanResponderMove: Animated.event([null, { dx: pan.x, dy: pan.y }], { useNativeDriver: false }),
			onPanResponderRelease: () => {
				pan.flattenOffset();

				// // Get the current Y position
				// const currentY = pan.y._value;

				// // Get the dimensions of the screen
				// const screenHeight = Dimensions.get('window').height;

				// // Animate the button to the edge of the screen with the current Y position
				// Animated.spring(pan, {
				// 	toValue: { x: 0, y: currentY },
				// 	useNativeDriver: true,
				// }).start();
			},
			onPanResponderEnd: () => {
				const finalY = pan.y._value; // Get the current Y value from pan
				pan.setOffset({
					x: 0,
					y: finalY,
				});
				// Animated.spring(pan, {
				// 	toValue: { x: 0, y: finalY }, // Move only in the Y direction
				// 	useNativeDriver: true,
				// }).start();
			},
		}),
	).current;

	return (
		// <Animated.View
		// 	style={{
		// 		// transform: [{ translateX: pan.x }, { translateY: pan.y }],
		// 		zIndex: 1000,
		// 	}}
		// 	{...panResponder.panHandlers}>
		<TouchableOpacity activeOpacity={1} style={[styles.container, cStyle]} onPress={onPress}>
			<Icon src={icon || ICONS.icPlus} width={sizeIcon} height={sizeIcon} tintColor="white" />
		</TouchableOpacity>
		// </Animated.View>
	);
};
