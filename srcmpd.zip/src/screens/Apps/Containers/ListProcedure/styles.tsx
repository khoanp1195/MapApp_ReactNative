import { COLORS } from 'config';
import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
	container: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
		marginHorizontal: 5,
		borderWidth: 0.8,
		borderColor: COLORS.whiteSmoke,
		padding: 12,
		borderRadius: 4,
	},

	textInput: { fontStyle: 'italic' },
	button: {
		flexDirection: 'row',
		alignItems: 'center',
		height: 47,
		backgroundColor: COLORS.lightGray,
		paddingHorizontal: 15,
	},
	title: { fontSize: 15, fontWeight: '700', color: COLORS.trueBlue, paddingLeft: 8 },
	buttonItem: {
		flexDirection: 'row',
		height: 90,
		paddingHorizontal: 20,
		overflow: 'hidden',
		flex: 1,
	},
	description: { flex: 1, paddingHorizontal: 20, justifyContent: 'center' },
	defaultValue: { fontWeight: '400', fontSize: 14 },
	desc2: { fontSize: 11, fontWeight: '400', color: COLORS.davyGrey },
	iconRight: { justifyContent: 'flex-start', marginVertical: 30 },
});
