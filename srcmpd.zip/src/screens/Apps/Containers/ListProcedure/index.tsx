/* eslint-disable prettier/prettier */
/* eslint-disable react/no-array-index-key */
import React, { useEffect, useState } from 'react';

import { Text } from '@react-native-material/core';
import { Icon } from 'components/Atoms/Icon';
import FImage from 'components/Organisms/FImage/FImage';
import { COLORS, ICONS } from 'config';
import { navigate } from 'navigation/RootNavigation';
import { Image, RefreshControl, SectionList, TouchableOpacity, View, FlatList } from 'react-native';

import { styles } from './styles';

export interface ItemWorkflow {
	ID: number
	WorkflowID: number
	Title: string
	TitleEN: string
	Description: any
	ImageURL: string
	IsFavor: number
	WorkflowCategory: any
	WorkflowCategoryID: number
}

export interface ItemListWorkflow {
	ImageURL: string;
	title?: string;
	data?: Array<ItemWorkflow>;
	WorkflowCategoryID?: number;
}

export interface ParamsProps {
	id: number;
	flag: number;
	WorkflowCategoryID: number;
}

interface Props {
	data?: Array<ItemWorkflow> | Array<ItemListWorkflow>;
	refreshing?: boolean;
	isBookmark?: boolean;
	onOpenModal?: () => void;
	handleEndReached?: () => void;
	handFavorite?: (params: ParamsProps) => void;
	refreshPage?: () => void;
}

export const ListProcedure = ({
	data = [],
	refreshing,
	isBookmark,
	handleEndReached,
	handFavorite = () => { },
	refreshPage,
	onOpenModal,
}: Props) => {
	// eslint-disable-next-line react/no-unstable-nested-components
	const ListFooter = () => <View style={{ height: 100 }} />;

	return (
		<View>
			{isBookmark ? (
				<FlatList
					data={data}
					keyExtractor={(item, index) => index.toString()}
					renderItem={({ item, index }) => {
						return (
							<TouchableOpacity
								style={[styles.buttonItem, { backgroundColor: index % 2 ? 'white' : '#F3F9FF' }]}
								onPress={() => {
									console.log('alo');
								}}>
								<View style={{ justifyContent: 'center' }}>
									<FImage
										ImagePath={item?.ImageURL}
										DefaultImagePath="https://dpmclouduat.vuthao.com/qc/Pictures/457/638152713418151767.png"
									/>
								</View>
								<View style={styles.description}>
									<Text style={styles.defaultValue} numberOfLines={1}>
										{item?.Title}
									</Text>
									<Text style={styles.desc2} numberOfLines={2}>
										{item?.Description}
									</Text>
								</View>
								<TouchableOpacity
									style={styles.iconRight}
									onPress={() => {
										const params = {
											id: item?.WorkflowID,
											flag: item?.IsFavor ? 0 : 1,
											WorkflowCategoryID: item?.WorkflowCategoryID,
										};
										handFavorite(params);
									}}>
									<Icon src={!item?.IsFavor ? ICONS.icBookMark : ICONS.icActiveBookMark} width={20} height={20} />
								</TouchableOpacity>
							</TouchableOpacity>
						);
					}}
				/>
			) : (
				<>
					<TouchableOpacity onPress={onOpenModal} style={styles.container}>
						<Text>Nhóm quy trình</Text>
						<Icon src={ICONS.icArrowRight} width={18} height={18} />
					</TouchableOpacity>
					<SectionList
						style={{ marginBottom: 250 }}
						showsVerticalScrollIndicator={false}
						sections={data}
						keyExtractor={(item, index) => index.toString()}
						renderItem={({ item, index }) => {
							return (
								<TouchableOpacity
									style={[styles.buttonItem, { backgroundColor: index % 2 ? 'white' : '#F3F9FF' }]}
									onPress={() => {
										navigate('SubApp');
									}}>
									<View style={{ justifyContent: 'center' }}>
										<FImage
											ImagePath={item?.ImageURL}
											DefaultImagePath="https://dpmclouduat.vuthao.com/qc/Pictures/457/638152713418151767.png"
										/>
									</View>
									<View style={styles.description}>
										<Text style={styles.defaultValue} numberOfLines={1}>
											{item?.Title}
										</Text>
										<Text style={styles.desc2} numberOfLines={2}>
											{item?.Description}
										</Text>
									</View>
									<TouchableOpacity
										style={styles.iconRight}
										onPress={() => {
											const params = {
												id: item?.WorkflowID,
												flag: item?.IsFavor ? 0 : 1,
												WorkflowCategoryID: item.WorkflowCategoryID,
											};
											handFavorite(params);
										}}>
										<Icon src={!item?.IsFavor ? ICONS.icBookMark : ICONS.icActiveBookMark} width={20} height={20} />
									</TouchableOpacity>
								</TouchableOpacity>
							);
						}}
						renderSectionHeader={({ section: { title } }) => (
							<View style={styles.button}>
								<Icon src={ICONS.icArrowDownBlue} width={8} height={8} />
								<Text style={styles.title}>{title}</Text>
							</View>
						)}
						onEndReached={handleEndReached}
						onEndReachedThreshold={0.1}
						ListFooterComponent={<ListFooter />}
						refreshControl={
							<RefreshControl refreshing={refreshing} onRefresh={refreshPage} tintColor={COLORS.trueBlue} />
						}
					/>
				</>
			)}
		</View>
	);
};
