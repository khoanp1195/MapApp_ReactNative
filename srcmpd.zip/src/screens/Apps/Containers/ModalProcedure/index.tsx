/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';

import { Text } from '@react-native-material/core';
import { Icon } from 'components/Atoms/Icon';
import { ModalComponent } from 'components/Molecules/Modal';
import { Header } from 'components/Organisms/Header';
import { COLORS, ICONS } from 'config';
import { TouchableOpacity, View, FlatList } from 'react-native';
import { useAppDispatch, useAppSelector } from 'stores';
import { fetchWorkFlow } from 'stores/Apps';

import { styles } from './styles';

interface Props {
	modal: boolean;
	setModal: (e: boolean) => void;
	setWorkflowCategoryId: (e: number) => void;
}

interface ItemProps {
	item?: {
		ID?: number;
		Title?: string;
	};
	index?: number;
}

export const ModalProcedure = ({ modal, setModal, setWorkflowCategoryId }: Props) => {
	const dispacth = useAppDispatch();
	// eslint-disable-next-line @typescript-eslint/no-unsafe-return
	const workflow = useAppSelector(store => store.apps.workflow);
	const [selected, setSelected] = useState(0);

	useEffect(() => {
		dispacth(fetchWorkFlow());
	}, []);

	const renderItem = ({ item, index }: ItemProps) => {
		const isSelect = selected === item?.ID;
		const onPressItem = () => {
			setSelected(item?.ID || 0);
			setWorkflowCategoryId(item?.ID || 0);
			setModal(false);
		};

		return (
			<TouchableOpacity
				onPress={onPressItem}
				style={[
					styles.item,
					{ borderBottomWidth: index === (workflow?.length || 0) ? 0 : 1, borderTopWidth: index === 0 ? 1 : 0 },
				]}>
				<Text style={styles.titleItem}>{item?.Title}</Text>
				{isSelect && (
					<TouchableOpacity>
						<Icon tintColor={COLORS.trueBlue} src={ICONS.icCheck} width={22} height={22} />
					</TouchableOpacity>
				)}
			</TouchableOpacity>
		);
	};

	const leading = () => (
		<TouchableOpacity onPress={() => setModal(false)}>
			<Icon src={ICONS.icArrowLeft} width={20} height={20} />
		</TouchableOpacity>
	);

	return (
		<ModalComponent open={modal} outsideClickCloseable visiblePosition="bottom">
			<View style={styles.container}>
				<Header leading={leading()}>
					<Text style={styles.title}>Quy trình</Text>
				</Header>
				<View style={styles.flatlist}>
					<FlatList
						contentContainerStyle={{ backgroundColor: 'white' }}
						data={[{ ID: 0, Title: 'All' }, ...workflow]}
						renderItem={renderItem}
						keyExtractor={(item, index) => index?.toString()}
					/>
				</View>
			</View>
		</ModalComponent>
	);
};
