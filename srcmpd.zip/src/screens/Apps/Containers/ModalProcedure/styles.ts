import { COLORS } from 'config';
import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
	container: { backgroundColor: 'white', width: '100%', height: '100%', paddingTop: 50 },
	title: { flex: 1, textAlign: 'center', fontWeight: '400', color: COLORS.trueBlue },
	flatlist: { flex: 1, backgroundColor: COLORS.lightGray },
	item: {
		marginHorizontal: 15,
		borderBottomColor: COLORS.platinumGray,
		borderTopColor: COLORS.platinumGray,
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
	},
	titleItem: { paddingVertical: 15, fontSize: 15, fontWeight: '400' },
});
