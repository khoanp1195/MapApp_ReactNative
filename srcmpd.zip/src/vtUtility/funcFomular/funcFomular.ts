import dayjs from 'dayjs';

function isNullOrUndefined(obj) {
	const nullObject = null;
	return obj === nullObject || obj === undefined;
}

function isEmptyOrSpaces(str) {
	return isNullOrUndefined(str) || typeof str !== 'string' || str.match(/^ *$/) !== null;
}

function tryParseString(obj) {
	return obj ? obj?.toString() : '';
}

function trim(str, chr) {
	const rgxtrim = !chr ? new RegExp('^\\s+|\\s+$', 'g') : new RegExp(`^${chr}+|${chr}+$`, 'g');
	return str.replace(rgxtrim, '');
}

// return parseFloat(obj, vtUtility.getCorrectLanguageValue("vi-VN", "en-US"));

export function NUMBER(obj) {
	return new Number(obj);
}

export function COUNTA() {
	if (isNullOrUndefined(arguments) || arguments.length == 0) throw 'COUNTA không truyền tham số';
	let Value = 0;
	for (let i = 0; i < arguments.length; i++) {
		Value += isEmptyOrSpaces(tryParseString(arguments[i]));
	}
	return Value;
}

export function ISNULL() {
	if (isNullOrUndefined(arguments) || arguments.length == 0) throw 'ISNULL không truyền tham số';
	return isNullOrUndefined(arguments[0]);
}

export const IF = (condition, trueValue, falseValue) => {
	return condition ? trueValue : falseValue;
};

export function AND() {
	let Value = false;
	if (isNullOrUndefined(arguments) || arguments?.length === 0) return Value;
	Value = true;
	for (let i = 0; i < arguments.length; i++) {
		Value = Value && arguments[i];
	}
	return Value;
}

export function OR() {
	let Value = false;
	if (isNullOrUndefined(arguments) || arguments?.length == 0) return Value;
	for (let i = 0; i < arguments.length; i++) {
		Value = Value || arguments[i];
	}
	return Value;
}

export function NOT(obj) {
	return !obj;
}

export function INT(obj) {
	return Math.round(NUMBER(obj));
}

export function SUM() {
	if (isNullOrUndefined(arguments) || arguments.length == 0) throw 'SUM không truyền tham số';
	let Value = 0;
	for (let i = 0; i < arguments.length; i++) {
		Value += INT(arguments[i]);
	}
	return Value;
}

export function PRODUCT() {
	if (isNullOrUndefined(arguments) || arguments.length == 0) throw 'PRODUCT không truyền tham số';
	let Value = 1;
	for (let i = 0; i < arguments.length; i++) {
		Value *= INT(arguments[i]);
	}
	return Value;
}

export function AVERAGE() {
	if (isNullOrUndefined(arguments) || arguments.length == 0) throw 'AVERAGE không truyền tham số';
	let Value = 0;
	return (Value = SUM.apply(null, arguments) / arguments.length);
}

export function MIN() {
	if (isNullOrUndefined(arguments) || arguments.length == 0) throw 'MIN không truyền tham số';
	return Math.min.apply(null, arguments);
}

export function MAX() {
	if (isNullOrUndefined(arguments) || arguments.length == 0) throw 'MAX không truyền tham số';
	return Math.max.apply(null, arguments);
}

export function COUNT() {
	if (isNullOrUndefined(arguments) || arguments.length == 0) throw 'COUNT không truyền tham số';
	let Value = 0;
	for (let i = 0; i < arguments.length; i++) {
		if (typeof arguments[i] === 'number') Value++;
	}
	return Value;
}

export function POWER() {
	if (isNullOrUndefined(arguments) || arguments.length != 2) throw 'POWER số lượng tham số không đúng';
	return Math.pow.apply(null, arguments);
}

export function ROUND() {
	if (isNullOrUndefined(arguments) || arguments.length == 0) throw 'ROUND số lượng tham số không đúng';
	const precision = isNullOrUndefined(arguments[1]) ? 0 : INT(arguments[1]);
	const Value = NUMBER(arguments[0]);
	const factor = 10 ** precision;
	return Math.round(Value * factor) / factor;
}

export function ROUNDUP() {
	if (isNullOrUndefined(arguments) || arguments.length == 0) throw 'ROUNDUP số lượng tham số không đúng';
	const precision = isNullOrUndefined(arguments[1]) ? 0 : INT(arguments[1]);
	const Value = NUMBER(arguments[0]);
	const factor = 10 ** precision;
	return Math.ceil(Value * factor) / factor;
}

export function ROUNDDOWN() {
	if (isNullOrUndefined(arguments) || arguments.length == 0) throw 'ROUNDDOWN số lượng tham số không đúng';
	const precision = isNullOrUndefined(arguments[1]) ? 0 : INT(arguments[1]);
	const Value = NUMBER(arguments[0]);
	const factor = 10 ** precision;
	return Math.floor(Value * factor) / factor;
}

// Date Time

export function DATE() {
	const Value = null;
	if (isNullOrUndefined(arguments) || arguments.length == 0) throw 'Formula DATE không đúng';
	if (isNullOrUndefined(arguments[0])) return null;

	const typeInput = $.type(arguments[0]);
	if (typeInput == 'string') {
		return new Date(arguments[0]);
	}
	if (typeInput == 'date') {
		return arguments[0];
	}

	let month = arguments[1];
	if (!isNullOrUndefined(month)) month -= 1;
	if (arguments.length > 5) {
		return new Date(arguments[0], month, arguments[2], arguments[3], arguments[4], arguments[5], arguments[6]);
	}

	return new Date(arguments[0], month, arguments[2]);
}

export function YEAR(obj) {
	let date = obj;
	if (isNullOrUndefined(obj)) return null;
	if (typeof obj !== 'date') date = DATE(obj);
	return date.getFullYear();
}

export function MONTH(obj) {
	let date = obj;
	if (typeof obj !== 'date') date = DATE(obj);
	return date.getMonth() + 1;
}

export function DAY(obj) {
	let date = obj;
	if (typeof obj !== 'date') date = DATE(obj);
	return date.getDate();
}

export function NOW() {
	return new Date();
}

export function NOWDATE() {
	const DateNow = new Date();
	DateNow.setHours(0, 0, 0, 0);
	return DateNow;
}

export function DATEONLY() {
	if (isNullOrUndefined(arguments) || arguments.length == 0) throw 'Formula DATEONLY không đúng';
	// return vtUtility.getDateOnly(that.DATE.apply(null, arguments));
	return dayjs(arguments?.[0] || new Date()).format('DD/MM/YYYY');
}

export function ADDDAY(obj, days) {
	let date = obj;
	if (typeof obj !== 'date') date = DATE(obj);
	else date = new Date(obj.getTime());
	return new Date(date.setDate(date.getDate() + days));
}

export function SUBDAY(obj1, obj2) {
	let date1 = obj1;
	if (typeof obj !== 'date') date1 = DATE(obj1);
	else date1 = new Date(obj1.getTime());
	let date2 = obj2;
	if (typeof obj !== 'date') date2 = DATE(obj2);
	else date2 = new Date(obj2.getTime());
	if (!isNullOrUndefined(date1) && !isNullOrUndefined(date2)) {
		const Value = NUMBER(date2 - date1);
		if (Value > 0) return Value / (1000 * 3600 * 24);
		return 0;
	}
	return 0;
}

// #region Text

export function TEXT() {
	if (isNullOrUndefined(arguments) || arguments.length == 0) throw 'Ép kiểu Text không truyền tham số';
	return tryParseString.apply(null, arguments);
}

export function LENGTH(obj) {
	const str = tryParseString(obj);
	return str.length;
}

export function UPPER(obj) {
	const str = tryParseString(obj);
	return str.toUpperCase();
}
export function LOWER(obj) {
	const str = tryParseString(obj);
	return str.toLowerCase();
}

export function PROPER(obj) {
	const str = tryParseString(obj);
	return str.replace(/\w\S*/g, function (txt) {
		return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
	});
}
export function CONCATENATE() {
	if (isNullOrUndefined(arguments) || arguments.length == 0) throw 'CONCATENATE Không truyền tham số';
	let Value = '';
	for (let i = 0; i < arguments.length; i++) {
		Value += tryParseString(arguments[i]);
	}
	return Value;
}
export function EXACT(left, right) {
	return left == right;
}
export function LEFT(obj, iLength) {
	const str = tryParseString(obj);
	return str.substring(0, iLength);
}
export function RIGHT(obj, iLength) {
	const str = tryParseString(obj);
	return str.substring(str.length - iLength);
}

export function TRIM(obj) {
	const str = tryParseString(obj);
	return trim(str);
}

export function REPT(obj, iTimes) {
	const str = tryParseString(obj);
	let Value = '';
	for (let i = 0; i < iTimes; i++) {
		Value += str;
	}
	return Value;
}
