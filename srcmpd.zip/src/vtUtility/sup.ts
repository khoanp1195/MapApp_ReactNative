VTF.KDE_Formula = function () {
	const that = this;
	that.AllFunction = [];

	// #region Common
	that.replaceFunction_Replacer = function (match, p1, p2, p3, offset, string) {
		try {
			return `${p1}that.${p2.toUpperCase()}${p3}`;
		} catch (e) {
			console.log(e);
		}
	};

	that.EXCUTE_FORMULA = function (internalName, strFormula) {
		const DataReturn = { Valid: false, Value: null };
		let IsValidFormula = true;
		try {
			if (vtUtility.isEmptyOrSpaces(strFormula)) return DataReturn;
			let parsedFormula = new String(strFormula);
			const mainDiv = $('#WorkflowFormDefination');

			// Replace Function
			$.each(that.AllFunction, function (index, funcName) {
				const regex = new RegExp(`(\\s|\\=|\\(|\\,)(${funcName})(\\()`, 'gi');
				parsedFormula = parsedFormula.replace(regex, that.replaceFunction_Replacer);
			});

			// Replace Field
			parsedFormula = parsedFormula.replace(/(])(\s|)(\=)+/g, ']==');
			const regex = /\[(\d|\w|\.|_)+\]/g;
			const ArrayField_InFormula = parsedFormula.match(regex);
			if (!(vtUtility.isNullOrUndefined(ArrayField_InFormula) || ArrayField_InFormula.length == 0)) {
				$.each(ArrayField_InFormula, function (index, value) {
					let ObjId = value.match(/(\d|\w|\.|_)+/g);
					if (vtUtility.isNullOrUndefined(ObjId) || ObjId.length == 0) {
						return (IsValidFormula = false);
					}
					ObjId = ObjId[0];
					const newID = ObjId;
					const KDEControl = $(mainDiv)
						.find(`input.kde${newID},.divKDE${newID}`)
						.closest('.ItemControl')
						.data('KDEControl');
					let KDEvalue = '';
					if (!vtUtility.isNullOrUndefined(KDEControl)) {
						KDEvalue = KDEControl.getValue();
						if (KDEControl.option.N_Show_Percent) KDEvalue /= 100;
						if (
							KDEControl.option.FieldType.toLowerCase() != 'number' &&
							KDEControl.option.FieldType.toLowerCase() != 'currency'
						)
							KDEvalue = `"${KDEvalue}"`;
					} else {
						if (typeof _VTF_DocConfig !== 'undefined' && _VTF_DocConfig.basicData) {
							KDEvalue = _VTF_DocConfig.basicData[ObjId];
						}

						let currentField = null;
						jQuery.grep(VTF_ArrFieldEdit, function (item) {
							if (item.Field == ObjId) return (currentField = item);
						});
						if (vtUtility.isNullOrUndefined(currentField.Control.control)) {
							currentField.Control.control = $($(`.divKDE${currentField.Field}`).children()[0]);
						}
						if (currentField && currentField.Control.control) {
							const fieldType = currentField.Control.option.FieldType;
							if (fieldType != 'User' && fieldType != 'DateTime') {
								KDEvalue = currentField.Control.control.text();
								if (fieldType.toLowerCase() == 'number')
									KDEvalue = kendo.parseFloat(KDEvalue, vtUtility.getCorrectLanguageValue('vi-VN', 'en-US'));
							}
						}
					}

					parsedFormula = parsedFormula.replace(value, KDEvalue);
				});
			}
			if (!IsValidFormula) {
				console.log('Formula không đúng: ', strFormula);
				return DataReturn;
			}
			eval(`DataReturn.Value ${parsedFormula}`);
			DataReturn.Valid = IsValidFormula;
			const ctrl = $(mainDiv)
				.find(`input.kde${internalName},.divKDE${internalName}`)
				.closest('.ItemControl')
				.data('KDEControl');
			ctrl.setValue(DataReturn.Value);
			ctrl.setMode();
			ctrl.control.trigger('change');
			ctrl.option.isLoad = false;
			ctrl.setEvent();
		} catch (e) {
			console.log(strFormula, e);
			DataReturn.Valid = false;
			DataReturn.Value = null;
		}
		return DataReturn;
	};

	// #endregion

	// #region Common Date Type
	that.COUNTA = function () {
		if (vtUtility.isNullOrUndefined(arguments) || arguments.length == 0) throw 'COUNTA không truyền tham số';
		let Value = 0;
		for (let i = 0; i < arguments.length; i++) {
			Value += vtUtility.isEmptyOrSpaces(vtUtility.tryParseString(arguments[i]));
		}
		return Value;
	};

	that.ISNULL = function () {
		if (vtUtility.isNullOrUndefined(arguments) || arguments.length == 0) throw 'ISNULL không truyền tham số';
		return vtUtility.isNullOrUndefined(arguments[0]);
	};
	// #endregion

	// #region Bool

	('IF(A>B, AND(A , B), NOT(A>B,A, B))');

	('IF(A>B, 3,4)');

	('IF(true, 3,4)');

	('3');

	// eval('IF(A>B, AND(A , B), NOT(A>B,A, B))')

	that.IF = function (condition, trueValue, falseValue) {
		return condition ? trueValue : falseValue;
	};

	that.AND = function () {
		let Value = false;
		if (vtUtility.isNullOrUndefined(arguments) || arguments.length == 0) return Value;
		Value = true;
		for (let i = 0; i < arguments.length; i++) {
			Value = Value && arguments[i];
		}
		return Value;
	};
	that.OR = function () {
		let Value = false;
		if (vtUtility.isNullOrUndefined(arguments) || arguments.length == 0) return Value;
		for (let i = 0; i < arguments.length; i++) {
			Value = Value || arguments[i];
		}
		return Value;
	};
	that.NOT = function (obj) {
		return !obj;
	};
	// #endregion

	// #region NUMBER
	that.INT = function (obj) {
		return Math.round(that.NUMBER(obj));
	};
	that.NUMBER = function (obj) {
		if (vtUtility.isNullOrUndefined(kendo))
			return kendo.parseFloat(obj, vtUtility.getCorrectLanguageValue('vi-VN', 'en-US'));
		return new Number(obj);
	};

	that.SUM = function () {
		if (vtUtility.isNullOrUndefined(arguments) || arguments.length == 0) throw 'SUM không truyền tham số';
		let Value = 0;
		for (let i = 0; i < arguments.length; i++) {
			Value += that.INT(arguments[i]);
		}
		return Value;
	};
	that.PRODUCT = function () {
		if (vtUtility.isNullOrUndefined(arguments) || arguments.length == 0) throw 'PRODUCT không truyền tham số';
		let Value = 1;
		for (let i = 0; i < arguments.length; i++) {
			Value *= that.INT(arguments[i]);
		}
		return Value;
	};
	that.AVERAGE = function () {
		if (vtUtility.isNullOrUndefined(arguments) || arguments.length == 0) throw 'AVERAGE không truyền tham số';
		let Value = 0;
		return (Value = that.SUM.apply(null, arguments) / arguments.length);
	};
	that.MIN = function () {
		if (vtUtility.isNullOrUndefined(arguments) || arguments.length == 0) throw 'MIN không truyền tham số';
		return Math.min.apply(null, arguments);
	};
	that.MAX = function () {
		if (vtUtility.isNullOrUndefined(arguments) || arguments.length == 0) throw 'MAX không truyền tham số';
		return Math.max.apply(null, arguments);
	};
	that.COUNT = function () {
		if (vtUtility.isNullOrUndefined(arguments) || arguments.length == 0) throw 'COUNT không truyền tham số';
		let Value = 0;
		for (let i = 0; i < arguments.length; i++) {
			if ($.type(arguments[i]) == 'number') Value++;
		}
		return Value;
	};

	that.POWER = function () {
		if (vtUtility.isNullOrUndefined(arguments) || arguments.length != 2) throw 'POWER số lượng tham số không đúng';
		return Math.pow.apply(null, arguments);
	};
	that.ROUND = function () {
		if (vtUtility.isNullOrUndefined(arguments) || arguments.length == 0) throw 'ROUND số lượng tham số không đúng';
		const precision = vtUtility.isNullOrUndefined(arguments[1]) ? 0 : that.INT(arguments[1]);
		const Value = that.NUMBER(arguments[0]);
		const factor = 10 ** precision;
		return Math.round(Value * factor) / factor;
	};
	that.ROUNDUP = function () {
		if (vtUtility.isNullOrUndefined(arguments) || arguments.length == 0) throw 'ROUNDUP số lượng tham số không đúng';
		const precision = vtUtility.isNullOrUndefined(arguments[1]) ? 0 : that.INT(arguments[1]);
		const Value = that.NUMBER(arguments[0]);
		const factor = 10 ** precision;
		return Math.ceil(Value * factor) / factor;
	};
	that.ROUNDDOWN = function () {
		if (vtUtility.isNullOrUndefined(arguments) || arguments.length == 0) throw 'ROUNDDOWN số lượng tham số không đúng';
		const precision = vtUtility.isNullOrUndefined(arguments[1]) ? 0 : that.INT(arguments[1]);
		const Value = that.NUMBER(arguments[0]);
		const factor = 10 ** precision;
		return Math.floor(Value * factor) / factor;
	};

	// #endregion

	// #region Date Time
	that.DATE = function () {
		const Value = null;
		if (vtUtility.isNullOrUndefined(arguments) || arguments.length == 0) throw 'Formula DATE không đúng';
		if (vtUtility.isNullOrUndefined(arguments[0])) return null;

		const typeInput = $.type(arguments[0]);
		if (typeInput == 'string') {
			if (!vtUtility.isNullOrUndefined(kendo)) {
				return kendo.parseDate(arguments[0], arguments[1]);
			}
			return new Date(arguments[0]);
		}
		if (typeInput == 'date') {
			return arguments[0];
		}

		let month = arguments[1];
		if (!vtUtility.isNullOrUndefined(month)) month -= 1;
		if (arguments.length > 5) {
			return new Date(arguments[0], month, arguments[2], arguments[3], arguments[4], arguments[5], arguments[6]);
		}

		return new Date(arguments[0], month, arguments[2]);
	};

	that.YEAR = function (obj) {
		let date = obj;
		if (vtUtility.isNullOrUndefined(obj)) return null;
		if ($.type(obj) != 'date') date = that.DATE(obj);
		return date.getFullYear();
	};

	that.MONTH = function (obj) {
		let date = obj;
		if ($.type(obj) != 'date') date = that.DATE(obj);
		return date.getMonth() + 1;
	};

	that.DAY = function (obj) {
		let date = obj;
		if ($.type(obj) != 'date') date = that.DATE(obj);
		return date.getDate();
	};

	that.NOW = function () {
		// var DateNow = new Date();
		// DateNow.setHours(0, 0, 0, 0);
		// return DateNow;
		return new Date();
	};

	that.NOWDATE = function () {
		const DateNow = new Date();
		DateNow.setHours(0, 0, 0, 0);
		return DateNow;
	};

	that.DATEONLY = function () {
		if (vtUtility.isNullOrUndefined(arguments) || arguments.length == 0) throw 'Formula DATEONLY không đúng';
		return vtUtility.getDateOnly(that.DATE.apply(null, arguments));
	};

	that.ADDDAY = function (obj, days) {
		let date = obj;
		if ($.type(obj) != 'date') date = that.DATE(obj);
		else date = new Date(obj.getTime());
		return new Date(date.setDate(date.getDate() + days));
	};

	that.SUBDAY = function (obj1, obj2) {
		let date1 = obj1;
		if ($.type(obj1) != 'date') date1 = that.DATE(obj1);
		else date1 = new Date(obj1.getTime());
		let date2 = obj2;
		if ($.type(obj2) != 'date') date2 = that.DATE(obj2);
		else date2 = new Date(obj2.getTime());
		if (!vtUtility.isNullOrUndefined(date1) && !vtUtility.isNullOrUndefined(date2)) {
			const Value = that.NUMBER(date2 - date1);
			if (Value > 0) return Value / (1000 * 3600 * 24);
			return 0;
		}
		return 0;
	};
	// #endregion

	// #region Text
	that.TEXT = function () {
		if (vtUtility.isNullOrUndefined(arguments) || arguments.length == 0) throw 'Ép kiểu Text không truyền tham số';
		return vtUtility.tryParseString.apply(null, arguments);
	};

	that.LENGTH = function (obj) {
		const str = vtUtility.tryParseString(obj);
		return str.length;
	};

	that.UPPER = function (obj) {
		const str = vtUtility.tryParseString(obj);
		return str.toUpperCase();
	};
	that.LOWER = function (obj) {
		const str = vtUtility.tryParseString(obj);
		return str.toLowerCase();
	};

	that.PROPER = function (obj) {
		const str = vtUtility.tryParseString(obj);
		return str.replace(/\w\S*/g, function (txt) {
			return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
		});
	};
	that.CONCATENATE = function () {
		if (vtUtility.isNullOrUndefined(arguments) || arguments.length == 0) throw 'CONCATENATE Không truyền tham số';
		let Value = '';
		for (let i = 0; i < arguments.length; i++) {
			Value += vtUtility.tryParseString(arguments[i]);
		}
		return Value;
	};
	that.EXACT = function (left, right) {
		return left == right;
	};
	that.LEFT = function (obj, iLength) {
		const str = vtUtility.tryParseString(obj);
		return str.substring(0, iLength);
	};
	that.RIGHT = function (obj, iLength) {
		const str = vtUtility.tryParseString(obj);
		return str.substring(str.length - iLength);
	};

	that.TRIM = function (obj) {
		const str = vtUtility.tryParseString(obj);
		return vtUtility.trim(str);
	};

	that.REPT = function (obj, iTimes) {
		const str = vtUtility.tryParseString(obj);
		let Value = '';
		for (let i = 0; i < iTimes; i++) {
			Value += str;
		}
		return Value;
	};

	// #endregion

	// #region Load
	that.AllFunction = Object.getOwnPropertyNames(that).filter(function (p) {
		return typeof that[p] === 'function';
	});

	// #endregion
};

const vtFormula = new VTF.KDE_Formula();
