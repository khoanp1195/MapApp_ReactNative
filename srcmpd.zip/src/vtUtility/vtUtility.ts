import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';

import { getTotalDateWork } from './funcUtility/getTotalDateWork';
import { onCalculatorConvert } from './funcUtility/onCalculatorConvert';
import {
	onCalculatorDivideToEffect,
	onCalculatorMinusToEffect,
	onCalculatorMultiplyToEffect,
	onCalculatorPlusToEffect,
} from './funcUtility/onCalculatorNumberEffect';
import { onCalculatorUpdateTotalMasterEffect } from './funcUtility/onCalculatorUpdateTotalMasterEffect';
import { onVisibleRowByValue } from './funcUtility/onVisibleRowByValue';
import { setCppUserByExtentValueToEffect } from './funcUtility/setCppUserByExtentValueToEffect';
import { setUserManagerToControl } from './funcUtility/setUserManagerToControl';
import { setValueControlByExtentValue } from './funcUtility/setValueControlByExtentValue';
import { setValueNumberByExtentValue } from './funcUtility/setValueNumberByExtentValue';
import { setValueTextBoxByExtentValue } from './funcUtility/setValueTextBoxByExtentValue';
import { setValueTextBoxJoinTextFields } from './funcUtility/setValueTextBoxJoinTextFields';

export const vtUtility = {
	IFunction: (valueControl: any[], arrExecuteJS: any[]) => {
		return {
			value: null,
			function: updateValueInternalName,
		};
	},
	onCalculatorConvert, // current,
	onVisibleRowByValue,
	onCalculatorUpdateTotalMasterEffect, // Grid
	setCppUserByExtentValueToEffect, // Lookup
	setValueTextBoxByExtentValue,
	setValueControlByExtentValue, // Lookup //Hanlde multi user/group
	onCalculatorPlusToEffect, // Number +
	onCalculatorMinusToEffect, // Number -
	onCalculatorMultiplyToEffect, // Number *
	onCalculatorDivideToEffect, // Number /
	setValueTextBoxJoinTextFields, // single
	getTotalDateWork, // datetime
	setUserManagerToControl,
	setValueNumberByExtentValue,
};
