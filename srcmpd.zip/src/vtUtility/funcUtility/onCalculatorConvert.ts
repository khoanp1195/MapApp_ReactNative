/* eslint-disable @typescript-eslint/no-use-before-define */
import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';

const onCalculatorConvert = (infoItem: number, arrExecuteJS?: string[], internalName, options) => {
	try {
		if (!internalName) return null;
		const { isVN, unit } = options || {};
		const params = arrExecuteJS?.[1];
		const arrParams = params?.replaceAll(' ', '').replaceAll('"', '').split(',');
		const valueControl: string = infoItem?.[internalName] ? infoItem?.[internalName] : '';

		let value: string = num2Word(valueControl?.toString(), isVN);

		if (unit) {
			value += ` ${unit}`;
		}
		return {
			value: { [arrParams?.[1] || '']: value },
			function: updateValueInternalName,
		};
	} catch (e) {
		console.log('e', e);
		//
	}
};

const capitalizeFirstLetter = (str: string): string => {
	return str.charAt(0).toUpperCase() + str.slice(1);
};

const num2Word = (number: string, isVN: boolean) => {
	let result = '';
	let valueNumber: string = number;
	const separator = valueNumber?.indexOf(',') > -1 ? ',' : '.';
	const nums: string[] = valueNumber?.split(separator);
	valueNumber = nums?.[0];

	if (!isVN) {
		result = num2WordEN.convert(valueNumber);
		const checkNumber = num2WordEN.convert(nums[1]);

		if (nums.length === 2 && checkNumber) {
			const fraction = num2WordEN.convert(nums[1]);
			result += ` point ${fraction.toLowerCase()}`;
		}
	} else {
		result = num2WordVN.convert(valueNumber);

		const checkNumber = num2WordVN.convert(nums[1]);

		if (nums.length === 2 && checkNumber) {
			const fraction = num2WordVN.convert(nums[1]);
			result += ` phẩy ${fraction.toLowerCase()}`;
		}
	}

	return result;
};

const num2WordVN = (() => {
	const t: string[] = ['không', 'một', 'hai', 'ba', 'bốn', 'năm', 'sáu', 'bảy', 'tám', 'chín'];

	const r = (r: number, n: boolean): string => {
		let o = '';
		const a = Math.floor(r / 10);
		const e = r % 10;

		if (a > 1) {
			o = ` ${t[a]} mươi`;

			if (e === 1) {
				o += ' mốt';
			}
		} else if (a === 1) {
			o = ' mười';

			if (e === 1) {
				o += ' một';
			}
		} else if (n && e > 0) {
			o = ' lẻ';
		}

		if (e === 5 && a >= 1) {
			o += ' lăm';
		} else if (e === 4 && a >= 1) {
			o += ' bốn';
		} else if (e > 1 || (e === 1 && a === 0)) {
			o += ` ${t[e]}`;
		}

		return o;
	};

	const n = (n: number, o: boolean): string => {
		let a = '';
		const e = Math.floor(n / 100);
		n %= 100;

		if (o || e > 0) {
			a = ` ${t[e]} trăm`;
			a += r(n, true);
		} else {
			a = r(n, false);
		}

		return a;
	};

	const o = (t: number, r: boolean): string => {
		let o = '';
		const a = Math.floor(t / 1000000);
		t %= 1000000;

		if (a > 0) {
			o = `${n(a, r)} triệu`;
			r = true;
		}

		const e = Math.floor(t / 1000);
		t %= 1000;

		if (e > 0) {
			o += `${n(e, r)} ngàn`;
			r = true;
		}

		if (t > 0) {
			o += n(t, r);
		}

		return o;
	};

	return {
		convert: (r: string): string => {
			r = r?.toString();

			if (r === '0') {
				return t[0];
			}

			let n = '';
			let a = '';

			do {
				const ty = Number(r) % 1000000000;
				r = Math.floor(Number(r) / 1000000000);

				if (r > 0) {
					n = `${o(ty, true)}${a}${n}`;
				} else {
					n = `${o(ty, false)}${a}${n}`;
				}

				a = ' tỷ';
			} while (r > 0);

			const result = capitalizeFirstLetter(n.trim());

			return result;
		},
	};
})();

const num2WordEN = (() => {
	const th: string[] = ['', 'thousand', 'million', 'billion', 'trillion'];
	const dg: string[] = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine'];
	const tn: string[] = [
		'ten',
		'eleven',
		'twelve',
		'thirteen',
		'fourteen',
		'fifteen',
		'sixteen',
		'seventeen',
		'eighteen',
		'nineteen',
	];
	const tw: string[] = ['twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];

	return {
		convert: (num: string): string => {
			num = num?.toString();
			num = num?.replace(/[\, ]/g, '');
			num = num?.replace(/[\. ]/g, '');

			if (num != parseFloat(num)) {
				return 'not a number';
			}

			let x = num.indexOf('.');

			if (x === -1) {
				x = num.length;
			}

			if (x > 15) {
				return 'too big';
			}

			const n = num.split('');
			let str = '';
			let sk = 0;

			for (let i = 0; i < x; i++) {
				if ((x - i) % 3 === 2) {
					if (n[i] === '1') {
						str += `${tn[Number(n[i + 1])]} `;
						i++;
						sk = 1;
					} else if (n[i] !== '0') {
						str += `${tw[n[i] - 2]} `;
						sk = 1;
					}
				} else if (n[i] !== '0') {
					str += `${dg[Number(n[i])]} `;

					if ((x - i) % 3 === 0) {
						str += 'hundred ';
					}

					sk = 1;
				}

				if ((x - i) % 3 === 1) {
					if (sk) {
						str += `${th[(x - i - 1) / 3]} `;
					}

					sk = 0;
				}
			}

			if (x !== num.length) {
				const y = num.length;
				str += 'point ';

				for (let i = x + 1; i < y; i++) {
					str += `${dg[Number(n[i])]} `;
				}
			}

			return capitalizeFirstLetter(str?.replace(/\s+/g, ' '));
		},
	};
})();

export { onCalculatorConvert };
