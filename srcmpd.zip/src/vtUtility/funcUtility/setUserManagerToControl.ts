import { GET } from 'http/modules';

import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';

export async function setUserManagerToControl(valueControl = [], arrExecuteJS, iseUserGroup) {
	const params = arrExecuteJS?.[1];
	const arrParams = params?.replaceAll(' ', '').replaceAll('"', '').split(',');

	function getDelimiter() {
		let list = [];
		valueControl?.forEach(elm => {
			list = [...list, elm?.ID];
		});

		return list?.toString();
	}
	const body = iseUserGroup
		? {
				func: 'GetLineManagerUserSQL',
				getInGroup: true,
				Delimiter: ',',
				data: getDelimiter() || '',
		  }
		: {
				func: 'GetGroupManagerDepartmentSQL',
				rid: valueControl?.[0]?.ID || 0,
		  };

	const res = await GET(`/_layouts/15/VuThao.BPMOP.API/ApiUser.ashx`, body);

	return {
		value: { [arrParams[1]]: iseUserGroup ? res?.data?.data : res?.data?.data ? [res?.data?.data] : [] || [] },
		function: updateValueInternalName,
		err: res?.data?.status,
	};
}
