import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';

export const onCalculatorUpdateTotalMasterEffect = (valueControl, arrExecuteJS) => {
	const params = arrExecuteJS?.[1];
	const arrParams = params?.replaceAll(' ', '').replaceAll('"', '').split(',');
	return {
		value: { [arrParams?.[2] || '']: valueControl },
		function: updateValueInternalName,
	};
};
