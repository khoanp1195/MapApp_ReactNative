import { ENDPOINT, GET, POST, baseURL } from 'http/modules';

import dayjs from 'dayjs';
import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';

const workingTimeCalculate = async (fromDate, toDate) => {
	const URL = `/_layouts/15/VuThao.BPMOP.API/ApiPublish.ashx`;

	const body = {
		func: 'WorkingTimeCalculate',
		fromDate: dayjs(fromDate).format('YYYY-MM-DD HH:mm:ss'),
		toDate: dayjs(toDate).format('YYYY-MM-DD HH:mm:ss'),
	};

	const response = await GET(URL, body);

	return response;
};

const checkDateTime = (from, to) => {
	const fromDate = new Date(from);
	const toDate = new Date(to);
	if (
		fromDate.getFullYear() === toDate.getFullYear() &&
		fromDate.getMonth() === toDate.getMonth() &&
		fromDate.getDate() === toDate.getDate() &&
		fromDate.getHours() === toDate.getHours() &&
		fromDate.getMinutes() === toDate.getMinutes()
	) {
		return true;
	}
	return false;
};

export const getTotalDateWork = async (infoItem, arrExecuteJS, internalName) => {
	const params = arrExecuteJS?.[1];
	const arrParams = params?.replaceAll(' ', '').replaceAll('"', '').split(',');
	const fromDate = dayjs(infoItem[arrParams[1]]);
	const toDate = dayjs(infoItem[arrParams[2]]);

	const check = checkDateTime(fromDate, toDate);

	if (check) {
		return {
			value: { [arrParams[0]]: '0' },
			function: updateValueInternalName,
		};
	}
	const response = await workingTimeCalculate(fromDate, toDate);

	return {
		value: { [arrParams[0]]: JSON.stringify(response?.data?.data || 0) },
		function: updateValueInternalName,
	};
};

//   //Tính thời gian làm việc
// 	that.workingTimeCalculate = function (fromDate, toDate) {
// 		var total = 0;
// 		vtAjax({
// 				type: 'GET',
// 				scriptCharset: "utf8",
// 				dataType: 'json',
// 				async: false,
// 				url: _spPageContextInfo.webAbsoluteUrl + "/_layouts/15/VuThao.BPMOP.API/ApiPublish.ashx",
// 				data: {
// 						func: "WorkingTimeCalculate",
// 						fromDate: kendo.toString(fromDate, "yyyy-MM-dd HH:mm:ss"),
// 						toDate: kendo.toString(toDate, "yyyy-MM-dd HH:mm:ss")
// 				},
// 				success: function (result) {
// 						if (result.status == "SUCCESS") {
// 								total = result.data || 0;
// 						}
// 				},
// 				error: function (e) {
// 						console.log(e);
// 				},
// 		});
// 		return total;
// }
