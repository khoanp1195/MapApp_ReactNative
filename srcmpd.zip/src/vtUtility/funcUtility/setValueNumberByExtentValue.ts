import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';

export function setValueNumberByExtentValue(valueControl: any[], arrExecuteJS: any[], FieldInfo) {
	const params = arrExecuteJS?.[1];
	const arrParams = params?.replaceAll(' ', '').replaceAll('"', '').split(',');

	const arrNameValueControl = arrParams[1].split(';');
	const arrNameFieldChange = arrParams[2].split(';');

	return {
		value: {},
		function: updateValueInternalName,
	};
}
