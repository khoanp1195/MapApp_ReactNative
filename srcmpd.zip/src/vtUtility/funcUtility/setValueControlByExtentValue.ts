import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';

export const setValueControlByExtentValue = (valueControl: any[], arrExecuteJS: any[], FieldInfo) => {
	try {
		const params = arrExecuteJS?.[1];
		const arrParams = params?.replaceAll(' ', '').replaceAll('"', '').split(',');

		const arrNameValueControl = arrParams[1].split(';');
		const arrNameFieldChange = arrParams[2].split(';');

		let value2 = {};
		arrNameFieldChange.forEach((e, index) => {
			const infoField = FieldInfo[e];
			let vl = '';
			valueControl?.map(item => {
				vl = vl
					? `${vl}${infoField?.FieldTypeId === 7 ? ';#' : '###'}${item[arrNameValueControl[index]]}`
					: item[arrNameValueControl[index]];
			});

			value2 = { ...value2, ...{ [e]: vl } };
		});

		return {
			value: value2,
			function: updateValueInternalName,
		};
	} catch (error) {
		console.log('errorerror', error);
	}
};
