import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';

export function setValueTextBoxByExtentValue(valueControl: any[], arrExecuteJS: any[], FieldInfo) {
	const params = arrExecuteJS?.[1];
	const arrParams = params?.replaceAll(' ', '').replaceAll('"', '').split(',');

	const arrNameValueControl = arrParams[1].split(';');
	const arrNameFieldChange = arrParams[2].split(';');

	const valueChange = valueControl?.length ? valueControl?.[valueControl?.length - 1] : null;
	if (!valueChange)
		return {
			value: {},
			function: updateValueInternalName,
		};

	const value2 = {
		[arrNameFieldChange[0]]: valueChange?.[arrNameValueControl[0]],
	};

	return {
		value: value2,
		function: updateValueInternalName,
	};
}

//  that.setValueTextBoxByExtentValue = function (_that, internalNames, effectInternalName) {
//       try {
//           var arrFieldName = internalNames.split(';');
//           var mode = that.getMode();//that.getQueryStringV2("mode");
//           var thisFieldName = _that.option.StaticName;
//           //Nếu Field cho phép edit hoặc mode = 1 or 3
//           if (mode != 2 || (';' + _VTF_DocConfig.WFStepConfig.FieldNameEdits + ';').includes(';' + thisFieldName + ';')) {
//               var mainDiv = _that.control.closest('.WorkflowFormDefination');
//               var arrFieldEffect = arrFieldName;
//               if (effectInternalName) arrFieldEffect = effectInternalName.split(';');
//               for (var i = 0; i < arrFieldName.length; i++) {
//                   var ctlfieldExpect = $(mainDiv).find('input.kde' + arrFieldEffect[i]).last();
//                   var kdeControlParent = $(_that.control.closest(".ItemControl")).data("KDEControl");
//                   var extentValue = kdeControlParent.getFieldExtentValueByInternalName(kdeControlParent.kendoControl.dataSource._data, kdeControlParent.kendoControl.value(), arrFieldName[i]);

//                   if (extentValue && ctlfieldExpect.length > 0 && ctlfieldExpect.data("kendoNumericTextBox")) {
//                       extentValue = kendo.toString(parseInt(extentValue), 'n0')
//                   }

//                   $(ctlfieldExpect).val(extentValue).change();
//                   var divEffect = $(mainDiv).find('div.div' + arrFieldEffect[i]);
//                   divEffect.html(extentValue);
//               }
//           }
//       } catch (e) { console.log(e); }
//   }
