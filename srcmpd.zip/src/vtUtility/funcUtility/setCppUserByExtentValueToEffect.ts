import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';

export const setCppUserByExtentValueToEffect = (valueControl: any[], arrExecuteJS: any[]) => {
	try {
		const params = arrExecuteJS?.[1];
		const arrParams = params?.replaceAll(' ', '').replaceAll('"', '').split(',');
		const valueChanged = valueControl?.[0]?.[arrParams?.[1]] || '';
		return {
			value: { [arrParams?.[2] || '']: valueChanged },
			function: updateValueInternalName,
		};
	} catch (error) {
		//
	}
};
