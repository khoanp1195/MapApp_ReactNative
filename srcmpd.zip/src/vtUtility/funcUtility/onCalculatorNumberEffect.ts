import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';

export const onCalculatorPlusToEffect = (infoItem, arrExecuteJS?: string[], internalName) => {
	const params = arrExecuteJS?.[1];
	const arrParams = params?.replaceAll(' ', '').replaceAll('"', '').split(',');
	const value = Number(infoItem[arrParams[1]]) + Number(infoItem[arrParams[2]]);
	return {
		value: { [arrParams?.[3] || '']: value },
		function: updateValueInternalName,
	};
};

export const onCalculatorMinusToEffect = (infoItem, arrExecuteJS?: string[], internalName) => {
	const params = arrExecuteJS?.[1];
	const arrParams = params?.replaceAll(' ', '').replaceAll('"', '').split(',');
	const value = Number(infoItem[arrParams[1]]) - Number(infoItem[arrParams[2]]);
	return {
		value: { [arrParams?.[3] || '']: value },
		function: updateValueInternalName,
	};
};

export const onCalculatorMultiplyToEffect = (infoItem, arrExecuteJS?: string[], internalName) => {
	const params = arrExecuteJS?.[1];
	const arrParams = params?.replaceAll(' ', '').replaceAll('"', '').split(',');
	const value = Number(infoItem[arrParams[1]]) * Number(infoItem[arrParams[2]]);
	return {
		value: { [arrParams?.[3] || '']: value },
		function: updateValueInternalName,
	};
};

export const onCalculatorDivideToEffect = (infoItem, arrExecuteJS?: string[], internalName) => {
	const params = arrExecuteJS?.[1];
	const arrParams = params?.replaceAll(' ', '').replaceAll('"', '').split(',');
	const value = Number(infoItem[arrParams[1]]) / Number(infoItem[arrParams[2]]);
	return {
		value: { [arrParams?.[3] || '']: value },
		function: updateValueInternalName,
	};
};
