import { updateValueInternalName } from 'stores/Workflows/sliceWorkflow';

export const setValueTextBoxJoinTextFields = (infoItem: any, arrExecuteJS: any[]) => {
	const params = arrExecuteJS?.[1];
	const arrParams = params?.replaceAll(' ', '').replaceAll('"', '').split(',');
	let value = {};
	const valueFiled = infoItem[arrParams[1]];
	arrParams?.map((e, i) => {
		if (i > 1) {
			value = { ...value, ...{ [e]: valueFiled } };
		}
	});
	return {
		value,
		function: updateValueInternalName,
	};
};
