import { updateFieldHide } from 'stores/Workflows/sliceWorkflow';

export const onVisibleRowByValue = (infoItem, arrExecuteJS, internalName) => {
	try {
		const valueControl = infoItem[internalName];
		const params = arrExecuteJS[1];
		const arrParams = params.replaceAll('"', '')?.trim()?.split(',');
		const arrFieldName = arrParams[2].split(';');
		if (valueControl?.toString()?.trim() === arrParams[1]?.toString()?.trim()) {
			return { isShow: true, arrFieldName, function: updateFieldHide };
		}
		return { isShow: false, arrFieldName, function: updateFieldHide };
	} catch (error) {
		console.log('error', error);
		// s
	}
};
