import { ComponentType } from 'react';

import { NativeStackNavigationOptions } from '@react-navigation/native-stack';
import { LoginScreen } from 'screens/Login';
import AuthenOTP from 'screens/Login/AuthenOTP/AuthenOTP';
import store from 'stores';

import { RoutesNames } from './RoutesNames';

export const RoutesAuth: {
	[key: string]: {
		name: string;
		screen: ComponentType;
		options?: NativeStackNavigationOptions;
	};
} = {
	Login: {
		name: RoutesNames.Login,
		screen: LoginScreen,
	},
	AuthenOTP: {
		name: RoutesNames.AuthenOTP,
		screen: AuthenOTP,
	},
};
