import { ComponentType } from 'react';

import { NativeStackNavigationOptions } from '@react-navigation/native-stack';
import SplashScreen from 'screens/SplashScreen/SplashScreen';

import { RoutesNames } from './RoutesNames';

export const RoutesSplash: {
	[key: string]: {
		name: string;
		screen: ComponentType;
		options?: NativeStackNavigationOptions;
	};
} = {
	SplashScreen: {
		name: RoutesNames.SplashScreen,
		screen: SplashScreen,
		options: {
			animationTypeForReplace: 'push',
		},
	},
};
