/* eslint-disable react/no-unstable-nested-components */
import React, { useEffect } from 'react';

import { DefaultTheme, NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import DropDown from 'components/Atoms/Loading/DropDown';
import LoadingGlobal from 'components/Atoms/Loading/LoadingGlobal';
import ModalMonthPicker from 'components/Atoms/Loading/ModalMonthPicker';
import ToastWorkflow from 'components/WorkflowDetails/ToastWorkflow';
import { COLORS } from 'config';
import { useSwipe } from 'hooks/useSwipe';
import { AppInitializer } from 'lib/appinitializer';
import { BiometricAuthenticationInitializer } from 'lib/biometricAuthenticationInitializer';
import { StatusBar, GestureResponderEvent, AppState } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import SInfo from 'react-native-sensitive-info';
import { Drawer } from 'screens/Drawer';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateLogin, updateBioType } from 'stores/DataNotRemove';
import styled from 'styled-components/native';
import NotifyService from 'utils/NotifyService';

import { navigationRef } from './RootNavigation';
import { RoutesAuth } from './RouteAuth';
import { Routes } from './Routes';
import { RoutesNames } from './RoutesNames';
import { RoutesSplash } from './RoutesSplash';

const theme = {
	...DefaultTheme,
	colors: {
		...DefaultTheme.colors,
		background: COLORS.white,
	},
};

const Container = styled.View`
	flex: 1;
`;

const Stack = createNativeStackNavigator();

export const MainNavigator = () => {
	const dispatch = useAppDispatch();
	const { isSplash, isAfterSplash } = useAppSelector(store => store.auth);
	const { bioType, isLogin } = useAppSelector(state => state.dataNotRemove);
	NotifyService();

	const checkBio = async () => {
		const biometricType = await SInfo.isSensorAvailable();
		if (bioType !== biometricType) {
			dispatch(updateBioType(biometricType));
		}
	};

	useEffect(() => {
		const subscription = AppState.addEventListener('change', nextAppState => {
			if (nextAppState === 'active') {
				checkBio();
			}
		});

		return () => {
			subscription.remove();
			dispatch(updateLogin(false));
		};
	}, []);

	const onSwipeRight = () => { };

	const { onTouchStart, onTouchEnd, onTouchCancel } = useSwipe(onSwipeRight, 6);

	const RoutesStack = isSplash ? RoutesSplash : isLogin ? Routes : RoutesAuth;

	return (
		<Container
			onTouchStart={event => onTouchStart(event as unknown as GestureResponderEvent)}
			onTouchEnd={event => onTouchEnd(event as unknown as GestureResponderEvent)}
			onTouchCancel={event => onTouchCancel(event as unknown as GestureResponderEvent)}>
			<StatusBar backgroundColor={COLORS.raisinBlack} barStyle="dark-content" />
			<AppInitializer />
			<BiometricAuthenticationInitializer />
			{/* <FloatButton /> */}
			<SafeAreaProvider
				style={{
					flex: 1,
				}}>
				<LoadingGlobal />
				<ToastWorkflow />
				<Drawer>
					<NavigationContainer theme={theme} ref={navigationRef}>
						<Stack.Navigator
							screenOptions={{
								headerShown: false,
							}}
							initialRouteName={RoutesNames.BottomNavigation}>
							{Object.values(RoutesStack).map(route => (
								<Stack.Screen
									key={route.name}
									name={route.name}
									component={route.screen}
									options={{
										...route.options,
										animationTypeForReplace:
											route.name === RoutesNames.Login ? (isAfterSplash ? 'pop' : 'push') : 'push',
									}}
								/>
							))}
						</Stack.Navigator>
					</NavigationContainer>
				</Drawer>
				<DropDown />
				<ModalMonthPicker />
			</SafeAreaProvider>
		</Container>
	);
};
