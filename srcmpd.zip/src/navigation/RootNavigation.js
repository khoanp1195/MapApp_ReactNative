import { CommonActions, createNavigationContainerRef } from '@react-navigation/native';

import { RoutesNames } from './RoutesNames';

/**
 * @see https://reactnavigation.org/docs/navigating-without-navigation-prop/
 */
export const navigationRef = createNavigationContainerRef();

export function navigate(name, params) {
	if (!navigationRef.isReady()) {
		return;
	}

	navigationRef.navigate(name, params);
}

export function goBack() {
	if (!navigationRef.isReady() || !navigationRef.canGoBack()) {
		return;
	}

	navigationRef.goBack();
}

export function resetStackNavigation() {
	navigationRef.dispatch(
		CommonActions.reset({
			index: 0,
			routes: [{ name: RoutesNames.BottomNavigation }],
		}),
	);
}
