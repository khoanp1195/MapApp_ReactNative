type RootStackParamsList = {
	ExampleScreenParams: {
		example: string;
	};
};
