import { ComponentType } from 'react';

import { NativeStackNavigationOptions } from '@react-navigation/native-stack';
import SearchWorkflow from 'components/AddWorkflow/SearchWorkflow';
import SearchApps from 'components/Apps/SearchApps';
import FilterTask from 'components/TaskScreens/FilterTask';
import Upload from 'components/WorkflowDetails/Attachments/Upload/Upload';
import GridDetails from 'components/WorkflowDetails/Grid/GridDetails';
import { withAuth } from 'hocs/withAuth';
import AddWorkflow from 'screens/AddWorkflow/AddWorkflow';
import { BottomNavigation } from 'screens/BottomNavigation';
import Follow from 'screens/Follow/Follow';
import { HomeScreen } from 'screens/Home';
import ListLookupScreen from 'screens/Lookup/ListLookupScreen/ListLookupScreen';
import { MyRequestsScreen } from 'screens/MyRequests';
import { MyTasksScreen } from 'screens/MyTasks';
import { NewRelated } from 'screens/NewRelated/NewRelated';
import Notifications from 'screens/Notifications/Notifications';
import SubApp from 'screens/SubApp/SubApp';
import { TaskScreen } from 'screens/Task';
import Reply from 'screens/Task/Comments/Reply';
import Assignment from 'screens/Task/Screens/Assignment';
import AttachmentsDetails from 'screens/TaskDetail/screens/AttachmentsDetails';
import Comments from 'screens/TaskDetail/screens/Comments';
import EditAttachments from 'screens/TaskDetail/screens/EditAttachments';
import EditGridDeatils from 'screens/TaskDetail/screens/EditGridDetails';
import SearchUser from 'screens/TaskDetail/screens/SearchUser';
import CreateRelated from 'screens/WorkflowDetails/screens/CreateRelated/CreateRelated';
import WorkflowHistory from 'screens/WorkflowDetails/screens/HistoryWorkflow/HistoryWorkflow';
import HistoryShare from 'screens/WorkflowDetails/screens/ShareWorkflow/HistoryShare';
import ShareWorkflow from 'screens/WorkflowDetails/screens/ShareWorkflow/ShareWorkflow';
import WorkflowDetails from 'screens/WorkflowDetails/WorkflowDetails';

import { RoutesNames } from './RoutesNames';

export const Routes: {
	[key: string]: {
		name: string;
		screen: ComponentType;
		options?: NativeStackNavigationOptions;
	};
} = {
	BottomNavigation: {
		name: RoutesNames.BottomNavigation,
		screen: withAuth(BottomNavigation),
	},
	Home: {
		name: RoutesNames.Home,
		screen: HomeScreen,
	},
	MyTasks: {
		name: RoutesNames.MyTasks,
		screen: MyTasksScreen,
	},
	MyRequests: {
		name: RoutesNames.MyRequests,
		screen: MyRequestsScreen,
	},

	Notifications: {
		name: RoutesNames.Notifications,
		screen: Notifications,
	},
	EditAttachments: {
		name: RoutesNames.EditAttachments,
		screen: EditAttachments,
	},
	EditGridDeatils: {
		name: RoutesNames.EditGridDeatils,
		screen: EditGridDeatils,
	},
	ShareWorkflow: {
		name: RoutesNames.ShareWorkflow,
		screen: ShareWorkflow,
	},
	SearchUser: {
		name: RoutesNames.SearchUser,
		screen: SearchUser,
	},
	WorkflowHistory: {
		name: RoutesNames.WorkflowHistory,
		screen: WorkflowHistory,
	},
	AttachmentsDetails: {
		name: RoutesNames.AttachmentsDetails,
		screen: AttachmentsDetails,
	},
	Comments: {
		name: RoutesNames.Comments,
		screen: Comments,
	},
	Follow: {
		name: RoutesNames.Follow,
		screen: Follow,
	},
	Task: {
		name: RoutesNames.Task,
		screen: TaskScreen,
	},
	Assignment: {
		name: RoutesNames.Assignment,
		screen: Assignment,
	},
	NewRelated: {
		name: RoutesNames.NewRelated,
		screen: NewRelated,
	},
	SubApp: {
		name: RoutesNames.SubApp,
		screen: SubApp,
	},
	SearchApps: {
		name: RoutesNames.SearchApps,
		screen: SearchApps,
	},
	WorkflowDetails: {
		name: RoutesNames.WorkflowDetails,
		screen: WorkflowDetails,
	},
	ListLookupScreen: {
		name: RoutesNames.ListLookupScreen,
		screen: ListLookupScreen,
	},
	Upload: {
		name: RoutesNames.Upload,
		screen: Upload,
	},
	FilterTask: {
		name: RoutesNames.FilterTask,
		screen: FilterTask,
	},
	HistoryShare: {
		name: RoutesNames.HistoryShare,
		screen: HistoryShare,
	},
	Reply: {
		name: RoutesNames.Reply,
		screen: Reply,
	},
	CreateRelated: {
		name: RoutesNames.CreateRelated,
		screen: CreateRelated,
	},
	GridDetails: {
		name: RoutesNames.GridDetails,
		screen: GridDetails,
	},
	AddWorkflow: {
		name: RoutesNames.AddWorkflow,
		screen: AddWorkflow,
	},
	SearchWorkflow: {
		name: RoutesNames.SearchWorkflow,
		screen: SearchWorkflow,
	},
} as const;
