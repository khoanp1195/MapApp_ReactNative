import React from 'react';

import { LoginScreen } from 'screens/Login';
import { useAppSelector } from 'stores';

export const withAuth =
	<P,>(WrappedComponent: React.FC<P>): React.FC<P> =>
		props => {
			const { status, loading } = useAppSelector(state => state.auth);
			const customerInfo = useAppSelector(store => store.dataNotRemove.customer);

			if (status === 'UNAUTH' && !loading && !customerInfo) return <LoginScreen />;

			return (
				// eslint-disable-next-line @typescript-eslint/ban-ts-comment
				// @ts-ignore
				<WrappedComponent
					// eslint-disable-next-line react/jsx-props-no-spreading
					{...props}
				/>
			);
		};
