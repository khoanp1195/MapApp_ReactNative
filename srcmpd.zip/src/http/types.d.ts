interface BaseAPIResponse<R = unknown> {
	status: string;
	mess: BaseMessError;
	data: R;
	dateNow: string;
}

interface BaseMessError {
	Key: string;
	Value: string;
}

interface BaseAPIMetaResponse {
	TotalRecord: number;
}

interface ErrorField {
	field: string;
	message: string;
}

interface BaseAPIError {
	errors: ErrorField[];
	message: string;
}
