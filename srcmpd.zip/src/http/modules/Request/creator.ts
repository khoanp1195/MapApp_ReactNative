import { ApiBaseUrl } from 'config';
import { getSideName } from 'utils/storage';

import { HTTPRequestMethods, HTTPRestfulBuilder } from '../../restfulBuilder';

// export const baseURL = 'https://dpmclouddev.vuthao.com';
export const baseURL = 'https://dpmclouduat.vuthao.com';
// export const baseURL = 'https://dpmmig.ketnoiphang.com';
// export const baseURL = 'https://dpm.ketnoiphang.com';

export const HTTP = new HTTPRestfulBuilder({
	baseURL,
});

export const AuthHTTP = new HTTPRestfulBuilder({
	baseURL,
	headers: {
		'Content-Type': 'multipart/form-data',
		Accept: '*/*',
	},
});

export const GET = async (endPoint?: string, params?: any, headers?: any) => {
	const side = await getSideName();

	return new HTTPRestfulBuilder({
		baseURL: `${baseURL}/${side}`,
		headers,
	}).call<BaseAPIResponse>({
		method: HTTPRequestMethods.GET,
		url: endPoint,
		config: {
			params,
		},
	});
};

export const POST = async (endPoint?: string, params?: any, formdata?: FormData, headers?: any) => {
	const headersFormData = formdata ? { 'Content-Type': 'multipart/form-data', Accept: '*/*' } : {};
	const side = await getSideName();

	return new HTTPRestfulBuilder({
		baseURL: `${baseURL}/${side}`,
		headers: {
			...headers,
			...headersFormData,
		},
	}).call<BaseAPIResponse>({
		method: HTTPRequestMethods.POST,
		url: endPoint,
		config: {
			params,
		},
		data: formdata,
	});
};
