export const ENDPOINT = {
	AUTH: '/_layouts/15/FN.DPM.API/ApiAccount.ashx',
	WORKFLOW: '/_layouts/15/FN.DPM.API/Mobile/Workflow.ashx',
	USERGROUP: '/_layouts/15/FN.DPM.API/Mobile/UserGroup.ashx',
	MASTERDATA: '/_layouts/15/FN.DPM.API/Mobile/MasterData.ashx',
	BOARD: '/_layouts/15/FN.DPM.API/Mobile/Board.ashx',
	WORKFLOWREQUEST: '/_layouts/15/FN.DPM.API/Mobile/WorkflowRequest.ashx',
	TASK: '/_layouts/15/FN.DPM.API/Mobile/Task.ashx',
	SOCIAL: '/_layouts/15/FN.DPM.API/Mobile/Social.ashx',
	SETTING: '/_layouts/15/FN.DPM.API/Mobile/Settings.ashx',
	TRACKING: '/_layouts/15/FN.DPM.API/Mobile/Tracking.ashx',
} as const;
