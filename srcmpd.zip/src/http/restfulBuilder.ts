/* eslint-disable @typescript-eslint/require-await */
/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/no-explicit-any */
import axios, { AxiosError, AxiosInstance, AxiosRequestConfig, AxiosRequestHeaders, AxiosResponse } from 'axios';
// import { customerRefreshTokenService } from 'services/Auth';
// import store from 'stores';
// import { updateStatusExpiredUserSession } from 'stores/System';
import { apiRefreshToken } from 'services/Auth';
import store from 'stores';
import { updateStatusExpiredUserSession } from 'stores/System';
import { getTokenFromKeyChain, saveTokenToKeyChain } from 'utils/keychain';

// import { getAppVersion } from 'utils/system';
// import { v4 as requestId } from 'uuid';

// `ASP.NET_SessionId=${info['ASP.NET_SessionId']}; FedAuth=${info.FedAuth}; WSS_FullScreenMode=false`
import { configHeader } from './headers';

export type BaseAxiosRequestConfig = AxiosRequestConfig & {
	_shouldAuthorize?: boolean;
};

declare module 'axios' {
	export interface AxiosInstance {
		request<T = any, R = AxiosResponse<T>>(config: BaseAxiosRequestConfig): Promise<R>;
		get<T = any, R = AxiosResponse<T>>(url: string, config?: BaseAxiosRequestConfig): Promise<R>;
		delete<T = any, R = AxiosResponse<T>>(url: string, config?: BaseAxiosRequestConfig): Promise<R>;
		head<T = any, R = AxiosResponse<T>>(url: string, config?: BaseAxiosRequestConfig): Promise<R>;
		options<T = any, R = AxiosResponse<T>>(url: string, config?: BaseAxiosRequestConfig): Promise<R>;
		post<T = any, D = any, R = AxiosResponse<T>>(url: string, data?: D, config?: BaseAxiosRequestConfig): Promise<R>;
		put<T = any, D = any, R = AxiosResponse<T>>(url: string, data?: D, config?: BaseAxiosRequestConfig): Promise<R>;
		patch<T = any, D = any, R = AxiosResponse<T>>(url: string, data?: D, config?: BaseAxiosRequestConfig): Promise<R>;
	}
}

type FailedQueueTypes = {
	reject: (error: Error) => void;
	resolve: (value: unknown) => void;
};

export enum HTTPRequestMethods {
	REQUEST = 'request',
	GET = 'get',
	POST = 'post',
	PUT = 'put',
	PATCH = 'patch',
	DELETE = 'delete',
	OPTIONS = 'options',
}

const refreshTokenHandler = async () => {
	const { refreshToken } = await getTokenFromKeyChain();
	if (!refreshToken) throw new Error('Refresh Token is empty!!!');
	return new Promise<{ token: string; refreshToken: string }>((resolve, reject) => {
		apiRefreshToken({ ssoData: refreshToken, username: '', password: '' })
			.then(({ data }) => {
				const { Client: newAccessToken, Sso: newRefreshToken } = data?.data || {};
				if (!newAccessToken || !newRefreshToken) return reject();
				return resolve({ token: JSON.stringify(newAccessToken), refreshToken: JSON.stringify(newRefreshToken) });
			})
			.catch(error => reject(error));
	});
};

export class HTTPRestfulBuilder {
	private instance?: AxiosInstance;

	private isTokenRefreshing = false;

	private failedQueueByInvaldiatedToken: Array<FailedQueueTypes> = [];

	constructor(baseConfig: BaseAxiosRequestConfig) {
		if (!baseConfig) throw new Error('Base config should not be empty!!!');

		this.instance = axios.create({
			...baseConfig,
			// withCredentials: true,
		});

		this.instance.interceptors.request.use(
			// @ts-ignore
			async (config: BaseAxiosRequestConfig) => {
				Object.assign(config.headers as AxiosRequestHeaders, {
					...configHeader,
				});

				return config;
			},
			(error: AxiosError) => {
				return Promise.reject(error);
			},
		);

		this.instance.interceptors.response.use(
			(response: AxiosResponse) => {
				const originalResponse = response.data;
				// eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
				if (originalResponse.status === 'ERR' && originalResponse.mess.Key === '998') {
					// NOTE: when token is updating, return API connection queue
					if (this.isTokenRefreshing) {
						return new Promise((resolve, reject) => {
							this.setFailedQueueByInvaldiatedToken({ resolve, reject });
						})
							.then(() => {
								return this.call({ method: HTTPRequestMethods.REQUEST, config: response.config });
							})
							.catch(err => {
								return Promise.reject(err);
							});
					}

					this.setTokenRefreshing(true);

					return new Promise((resolve, reject) => {
						refreshTokenHandler()
							.then(res => {
								const { refreshToken, token } = res || {};
								saveTokenToKeyChain({ refreshToken, accessToken: token });
								this.processQueue(null, res.token);
								resolve(this.call({ method: HTTPRequestMethods.REQUEST, config: response.config }));
							})
							.catch((err: AxiosError) => {
								this.processQueue(err, null);
								store.dispatch(updateStatusExpiredUserSession(true));
								reject(err);
							})
							.finally(() => {
								this.setTokenRefreshing(false);
							});
					});
				}
				return response;
			},
			(error: AxiosError) => {
				const originalRequest = error.config;
				// eslint-disable-next-line no-underscore-dangle
				if (error.response?.status === 401) {
					// NOTE: when token is updating, return API connection queue
					if (this.isTokenRefreshing) {
						return new Promise((resolve, reject) => {
							this.setFailedQueueByInvaldiatedToken({ resolve, reject });
						})
							.then(() => {
								return this.call({ method: HTTPRequestMethods.REQUEST, config: originalRequest });
							})
							.catch(err => {
								return Promise.reject(err);
							});
					}

					this.setTokenRefreshing(true);

					return new Promise((resolve, reject) => {
						refreshTokenHandler()
							.then(res => {
								const { refreshToken, token } = res || {};
								saveTokenToKeyChain({ refreshToken, accessToken: token });
								this.processQueue(null, res.token);
								resolve(this.call({ method: HTTPRequestMethods.REQUEST, config: originalRequest }));
							})
							.catch((err: AxiosError) => {
								this.processQueue(err, null);
								store.dispatch(updateStatusExpiredUserSession(true));
								reject(err);
							})
							.finally(() => {
								this.setTokenRefreshing(false);
							});
					});
				}
				return Promise.reject(error);
			},
		);
	}

	private processQueue = (error: Error | null, token: string | null = null) => {
		this.failedQueueByInvaldiatedToken.forEach(prom => {
			if (error) {
				prom.reject(error);
			} else {
				prom.resolve(token);
			}
		});
		this.clearFailedQueueByInvaldiatedToken();
	};

	private setTokenRefreshing = (value: boolean) => {
		this.isTokenRefreshing = value;
	};

	private setFailedQueueByInvaldiatedToken = (value: FailedQueueTypes) => {
		this.failedQueueByInvaldiatedToken.push(value);
	};

	private clearFailedQueueByInvaldiatedToken = () => {
		this.failedQueueByInvaldiatedToken = [];
	};

	call = <T = any, D = any, R = AxiosResponse<T>>(params: {
		method: HTTPRequestMethods;
		url?: string;
		data?: D;
		config?: BaseAxiosRequestConfig;
	}): Promise<R> => {
		if (!this.instance) throw new Error('HTTP instance has not been supplied!!!');
		const { method, url, data, config } = params;
		switch (method) {
			case HTTPRequestMethods.REQUEST: {
				if (!config) throw new Error('Config has not been supplied!!!');
				return this.instance.request(config);
			}
			case HTTPRequestMethods.GET:
			case HTTPRequestMethods.DELETE:
			case HTTPRequestMethods.OPTIONS: {
				if (!url) throw new Error('URL has not been supplied!!!');
				return this.instance[method]?.(url, config);
			}
			case HTTPRequestMethods.POST:
			case HTTPRequestMethods.PUT:
			case HTTPRequestMethods.PATCH: {
				if (!url) throw new Error('URL has not been supplied!!!');
				return this.instance[method]?.(url, data, config);
			}
			default:
				throw new Error(`The ${(method as string).toUpperCase()} method does not support!!!`);
		}
	};
}
