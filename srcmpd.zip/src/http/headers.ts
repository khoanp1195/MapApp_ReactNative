import { Platform } from 'react-native';
import DeviceInfo from 'react-native-device-info';

const deviceInfo = () => {
	const platform = Platform.OS;
	const majorVersionIOS =
		platform === 'ios' ? Platform.constants.osVersion : platform === 'android' ? Platform.constants.Version : '';
	const deviceName = DeviceInfo.getDeviceNameSync();
	return `${platform}/${majorVersionIOS} ${deviceName}`;
};

const getDeviceLang = () => {
	const appLanguage = 'vi';
	return appLanguage;
};

export const configHeader = {
	'X-Device-Info': deviceInfo(),
	'Content-Language': getDeviceLang(),
};
