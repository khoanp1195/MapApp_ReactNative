export interface INotification {
	ID: string;
	UserId: string;
	Content: string;
	ContentEN: string;
	ItemImage: string;
	Link: string;
	Icon: string;
	IDMessage: string;
	FlgRead: boolean;
	flgConfirmed: boolean;
	ItemID: number;
	ListID: string;
	Created: string;
	TotalRecord: number;
}
