import { ENDPOINT, HTTP } from 'http/modules';
import { HTTPRequestMethods } from 'http/restfulBuilder';

import store from 'stores';
import { getSideName } from 'utils/storage';

import { IUserGroupByListID } from './types';

export const apigetUserGroupByListID = async (params: { userIDs: Array<string> }) => {
	const side = await getSideName();
	return HTTP.call<BaseAPIResponse<Array<IUserGroupByListID>>>({
		method: HTTPRequestMethods.GET,
		url: `${side}${ENDPOINT.USERGROUP}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'getUserGroupByListID',
				data: `{"ListID": ${params.userIDs.join(',')} }`,
				lid: store.getState().system.language === 'vi' ? 1066 : 1033,
			},
		},
	});
};
