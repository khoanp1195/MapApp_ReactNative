export interface IUserGroupByListID {
	ID: string;
	Name: string;
	ImagePath?: string;
	Type: number;
	PositionId?: number;
	PositionName?: string;
	Mobile: string;
	Email: string;
	DepartmentId?: number;
	DepartmentName?: string;
	AccountName: string;
	Status: number;
}
