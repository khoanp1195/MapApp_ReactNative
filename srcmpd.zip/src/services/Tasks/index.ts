import { ENDPOINT, HTTP } from 'http/modules';
import { HTTPRequestMethods } from 'http/restfulBuilder';

import { ResponseData } from 'hooks/useInfinity';
import store from 'stores';
import { getSideName } from 'utils/storage';

import { ITask, ResourcetypeTask } from './types';

export const apiGetTotalItem = async (params: { ViewType: '2' | '4'; resourcetype: ResourcetypeTask }) => {
	const side = await getSideName();
	return HTTP.call<BaseAPIResponse<ResponseData<Array<ITask>>>>({
		method: HTTPRequestMethods.GET,
		url: `${side}${ENDPOINT.WORKFLOW}`,
		config: {
			_shouldAuthorize: true,
			params: {
				limit: 1,
				offset: 0,
				func: 'getList',
				data:
					params.resourcetype === ResourcetypeTask.MYTASK
						? `{WorkflowID:0,ViewType:${params.ViewType},Flag:0,FromDate:'',ToDate:''}`
						: `{WorkflowID:0}`,
				resourcetype: params.resourcetype,
				lid: store.getState().dataNotRemove.language === 'vi' ? 1066 : 1033,
				totalrecord: 0,
			},
		},
	});
};
//
