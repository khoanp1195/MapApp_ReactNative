export interface ITask {
	ID: number;
	IsFollow: number;
	Read: boolean;
	ListID?: string;
	SPItemId?: number;
	NotifyId: string;
	NotifyCreated: string;
	Content: string;
	WorkflowId: number;
	AssignedBy: string;
	Created: string;
	StatusGroup: number;
	DueDate?: string;
	Workflow: string;
	TotalRecord: number;
	FileCount: number;
	AssignedByInfo: string;
	AssignedToInfo: string;
	typeCurrent?: string;
	ResourceCategoryId?: number;
	ResourceSubCategoryId?: number;
}

export interface Assigned {
	ID: string;
	ImagePath: string;
	DefaultImagePath: string;
	Name: string;
	PositionName: string;
	PositionId: string;
	NumExpand: number;
	Type: number;
	AllUserGroup: string;
}

export enum ResourcetypeTask {
	MYTASK = 'MyTask',
	MYREQUEST = 'MyRequest',
	FILTER = 'FilterWorkflowItem',
}
