import { AuthHTTP, HTTP, ENDPOINT } from 'http/modules';
import { HTTPRequestMethods } from 'http/restfulBuilder';

import store from 'stores';
import { getSideName } from 'utils/storage';

import { IAuthData, ICustomerProfile } from './types';

export const apiLogin = async (params: { username: string; password: string; deviceInfo?: any }) => {
	const { username, password, deviceInfo } = params || {};
	const formdata = new FormData();
	formdata.append('account', `{"User":"${username}","Pass":"${password}"}`);
	if (deviceInfo) {
		formdata.append('deviceInfo', JSON.stringify(deviceInfo));
	}
	return AuthHTTP.call<BaseAPIResponse<IAuthData>>({
		method: HTTPRequestMethods.POST,
		url: `${ENDPOINT.AUTH}`,
		data: formdata,
		config: {
			params: {
				func: 'authent',
				lid: store.getState().dataNotRemove.language === 'vi' ? 1066 : 1033,
			},
		},
	});
};

export const apiRefreshToken = async (params: { username: string; password: string; ssoData: string }) => {
	const { username, password, ssoData } = params || {};

	const formdata = new FormData();
	formdata.append('ssoData', ssoData);
	formdata.append('account', `{"User":"${username}","Pass":"${password}"}`);

	return AuthHTTP.call<BaseAPIResponse<IAuthData>>({
		method: HTTPRequestMethods.POST,
		url: `${ENDPOINT.AUTH}`,
		data: formdata,
		config: {
			params: {
				func: 'refreshToken',
			},
		},
	});
};

export const apiGetMe = async () => {
	const side = await getSideName();
	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.GET,
		url: `${side}${ENDPOINT.USERGROUP}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'getCurrentUserInfo',
			},
		},
	});
};
