export interface IAuthMess {
	Key: string;
	Value: string;
}

export interface IAuthData {
	Client: Client;
	Sso: Sso;
}

export interface Client {
	url: string;
	info: Info;
}

export interface Info {
	FedAuth: string;
	'ASP.NET_SessionId': string;
}

export interface Sso {
	url: string;
	info: Info2;
}

export interface Info2 {
	'.AspNetCore.Antiforgery.nhtBn18RDbY': string;
	'.AspNetCore.Culture': string;
	'idsrv.session': string;
	'.AspNetCore.Identity.Application': string;
}

export interface ICustomerProfile {
	ID: string;
	AccountName: string;
	FullName: string;
	FirstName: string;
	LastName: string;
	Email: string;
	StaffID: string;
	Gender: boolean;
	BirthDay: string;
	Address: string;
	Mobile: string;
	Ext: string;
	ImagePath: string;
	LineManagerId: string;
	DepartmentId: number;
	PositionId: number;
	Status: number;
	Level: number;
	Modified: string;
	ModifiedBy: string;
	Created: string;
	CreatedBy: string;
	Manager: string;
	DateOfHire: string;
	PublicSiteRedirect: string;
	SubSiteRedirect: string;
	SocialChatOnline: number;
	SendMailOnline: boolean;
	DeviceOS: number;
	DeviceInfo: string;
	SocialLastAccessNotify: string;
	SecurityLevel: number;
	SendOTP: boolean;
	SiteName: string;
	Language: number;
	SettingNotify: number;
	SettingMailNotify: boolean;
	DepartmentTitle: string;
	PositionTitle: string;
	DepartmentTitleEN: string;
	PositionTitleEN: string;
	CurrentCustomerId: number;
	AnnouncementReaded: string;
	LastSiteAccess: string;
}
