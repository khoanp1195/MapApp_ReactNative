import { ENDPOINT, HTTP } from 'http/modules';
import { HTTPRequestMethods } from 'http/restfulBuilder';

import { ParamsProps } from 'screens/Apps/Containers';
import { ICustomerProfile } from 'services/Auth/types';
import { WorkflowProps } from 'stores/Apps/reducer';
import { getSideName } from 'utils/storage';

export const apiGetAllWorkFlow = async () => {
	const side = await getSideName();
	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.GET,
		url: `${side}${ENDPOINT.WORKFLOW}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'getOrSearchListWorkflow',
				data: `{"PerType": -1,"WorkflowCategoryId": 0,"Keyword":""}`,
			},
		},
	});
};

export const apiGetWorkFlow = async () => {
	const side = await getSideName();

	return HTTP.call<BaseAPIResponse<WorkflowProps>>({
		method: HTTPRequestMethods.GET,
		url: `${side}${ENDPOINT.MASTERDATA}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'get',
				type: 2,
				bname: 'BeanWorkflowCategory',
			},
		},
	});
};

export const apiSetFavorite = async (data: ParamsProps) => {
	const side = await getSideName();

	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.POST,
		url: `${side}${ENDPOINT.BOARD}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'setFavorite',
				flag: data.flag,
				data: `{"WorkflowId":${data.id}}`,
			},
		},
	});
};

export const apiGetListFormTemplateModified = async (params: ParamsProps) => {
	const side = await getSideName();

	const formdata = new FormData();
	formdata.append('lstlistid', params.listid);
	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.POST,
		url: `${side}${ENDPOINT.WORKFLOW}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'getListFormTemplateModified',
				modified: params.modified,
			},
		},
		data: formdata,
	});
};
