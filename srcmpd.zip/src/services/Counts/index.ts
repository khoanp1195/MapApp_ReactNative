import { ENDPOINT, HTTP } from 'http/modules';
import { HTTPRequestMethods } from 'http/restfulBuilder';

import { getSideName } from 'utils/storage';

import { ICount } from './types';

export const apiCount = async (params: { WorkflowId: number; countType: number }) => {
	const side = await getSideName();
	return HTTP.call<BaseAPIResponse<Array<ICount>>>({
		method: HTTPRequestMethods.GET,
		url: `${side}${ENDPOINT.BOARD}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'getCount',
				data: `{"WorkflowId":${params?.WorkflowId || 0},"CountType":${params?.countType || 2044}}`,
			},
		},
	});
};
//
