export interface ICount {
	CountMyTodoList: number;
	CountMySocialNotify: number;
	CountMyFollowItem: number;
	CountMyTask: number;
	CountMyTaskToDay: number;
	CountMyTaskOverdue: number;
	CountMyRequest: number;
	CountMyTaskProcessed: number;
	CountMyRequestProcessed: number;
	CountMyRequestOverdue: number;
	CountMyRequestToDay: number;
}
