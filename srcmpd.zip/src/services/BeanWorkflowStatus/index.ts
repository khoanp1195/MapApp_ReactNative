import { ENDPOINT, HTTP } from 'http/modules';
import { HTTPRequestMethods } from 'http/restfulBuilder';

import { getSideName } from 'utils/storage';

import { IBeanWorkflowStatus } from './types';

export const apiBeanAppStatus = async () => {
	const side = await getSideName();
	return HTTP.call<BaseAPIResponse<Array<IBeanWorkflowStatus>>>({
		method: HTTPRequestMethods.GET,
		url: `${side}${ENDPOINT.MASTERDATA}`,
		config: {
			params: {
				type: 2,
				limit: -1,
				offset: 0,
				func: 'get',
				isfirst: 0,
				bname: 'BeanAppStatus',
			},
		},
	});
};
export const apiBeanWorkflowStatus = async () => {
	const side = await getSideName();
	return HTTP.call<BaseAPIResponse<Array<IBeanWorkflowStatus>>>({
		method: HTTPRequestMethods.GET,
		url: `${side}${ENDPOINT.MASTERDATA}`,
		config: {
			params: {
				type: 2,
				limit: -1,
				offset: 0,
				func: 'get',
				isfirst: 0,
				bname: 'BeanWorkflowStatus',
			},
		},
	});
};

export const apiSettingSystem = async () => {
	const side = await getSideName();
	return HTTP.call<BaseAPIResponse<Array<IBeanWorkflowStatus>>>({
		method: HTTPRequestMethods.GET,
		url: `${side}${ENDPOINT.SETTING}`,
		config: {
			params: {
				func: 'getByKey',
				KEY: 'MOBILE_APPSTATUS_FILTER_SEARCH',
			},
		},
	});
};
//
//
