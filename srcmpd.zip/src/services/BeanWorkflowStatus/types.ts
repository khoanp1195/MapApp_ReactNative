export interface IBeanWorkflowStatus {
	ID: number;
	Title: string;
	TitleEN: string;
	Index: number;
	StatusDetails: string;
	ResourceCategoryIds?: number;
	IsShow: boolean;
	Modified?: string;
	CreatedBy: string;
	ModifiedBy: string;
	TotalRecord: number;
	Description?: string;
}
