import { AuthHTTP, ENDPOINT, HTTP } from 'http/modules';
import { HTTPRequestMethods } from 'http/restfulBuilder';

import { ICustomerProfile } from 'services/Auth/types';
import { getSideName } from 'utils/storage';

export const apiGetFormTaskDetails = async params => {
	const side = await getSideName();
	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.GET,
		url: `${side}${ENDPOINT.WORKFLOWREQUEST}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'getFormTemplate',
				mode: 2,
				rid: params.rid,
				listid: params.listid,
				wid: params.wid,
				lid: 1066,
				flag: params?.flag || 0,
				modified: params?.modified,
			},
		},
	});
};

export const apiGetTaskDetails = async params => {
	const side = await getSideName();

	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.GET,
		url: `${side}${ENDPOINT.WORKFLOWREQUEST}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'getFormData',
				rid: params.rid,
				lid: params.lid,
			},
		},
	});
};

export const apiGetUserGroup = async params => {
	const side = await getSideName();

	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.GET,
		url: `${side}${ENDPOINT.USERGROUP}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'searchUserAndGroup',
				type: -1,
				data: { Keyword: '' },
			},
		},
	});
};

export const apiGetAttachments = async params => {
	const side = await getSideName();

	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.GET,
		url: `${side}${ENDPOINT.WORKFLOWREQUEST}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'getAttachments',
				rid: params.rid,
			},
		},
	});
};

export const apiDeleteAttachment = async params => {
	const side = await getSideName();

	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.POST,
		url: params?.isTask ? `${side}${ENDPOINT.TASK}` : `${side}${ENDPOINT.WORKFLOWREQUEST}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'deleteAttachments',
				rid: params.rid,
				data: JSON.stringify(params.data),
			},
		},
	});
};

export const apiEditAttachment = async params => {
	const side = await getSideName();

	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.POST,
		url: `${side}${ENDPOINT.WORKFLOWREQUEST}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'updateAttachments',
				rid: params.rid,
				data: JSON.stringify(params.data),
			},
		},
	});
};

export const apiGetLookup = async params => {
	const side = await getSideName();

	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.GET,
		url: `${side}${ENDPOINT.WORKFLOWREQUEST}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'getLookupDataSource',
				keyword: params.keyword,
				FormFieldOption: params.options,
				PagingInfo: params.PagingInfo,
				limit: 10,
			},
		},
	});
};

export const apiGridDetails = async params => {
	const formdata = new FormData();
	formdata.append(
		'data',
		JSON.stringify({
			detailsListInfo: params.detailsListInfo,
			detailsFieldInfoCollection: params.detailsFieldInfoCollection,
		}),
	);
	const side = await getSideName();

	return AuthHTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.POST,
		url: `${side}${ENDPOINT.WORKFLOWREQUEST}`,
		config: {
			_shouldAuthorize: true,
			maxBodyLength: Infinity,
			params: {
				func: 'getDataGridDetails',
				rid: params.rid,
				spitemid: params.spitemid,
				flag: 1,
			},
		},
		data: formdata,
	});
};

export const apiGetWorkflowRelated = async params => {
	const side = await getSideName();

	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.GET,
		url: `${side}${ENDPOINT.WORKFLOWREQUEST}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'getWorkflowRelated',
				rid: params.rid,
				lid: params.lid,
			},
		},
	});
};

export const apiGetTaskFlow = async params => {
	const side = await getSideName();

	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.GET,
		url: `${side}${ENDPOINT.WORKFLOWREQUEST}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'getTask',
				rid: params.rid,
				lid: params.lid,
			},
		},
	});
};

export const apiPostActionTaskDetails = async params => {
	const side = await getSideName();

	const formdata = new FormData();
	formdata.append('itemInfo', params?.itemInfo ? JSON.stringify(params?.itemInfo) : '');
	formdata.append('idea', params?.idea || '');
	formdata.append('attachment', JSON.stringify(params?.attachment) || '');
	formdata.append('workflowrelated', JSON.stringify(params?.workflowrelated || []));

	return AuthHTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.POST,
		url: `${side}${ENDPOINT.WORKFLOWREQUEST}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: params?.func,
				rid: params.rid,
				lid: 1066,
				usergroupvalues: params?.usergroupvalues || null,
				SSN: 'workflow',
			},
		},
		data: formdata,
	});
};

export const apiPostFollowTask = async params => {
	const side = await getSideName();

	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.POST,
		url: `${side}${ENDPOINT.WORKFLOWREQUEST}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'FOLLOW',
				rid: params.rid,
				lid: 1066,
				flag: params.flag,
				SSN: 'workflow',
			},
		},
	});
};

export const apiGetHistoryShare = async params => {
	const side = await getSideName();

	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.GET,
		url: `${side}${ENDPOINT.WORKFLOWREQUEST}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'getShareHistory',
				rid: params.rid,
				lid: 1066,
				SSN: 'workflow',
			},
		},
	});
};

export const apiPostShareTask = async params => {
	const side = await getSideName();

	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.POST,
		url: `${side}${ENDPOINT.WORKFLOWREQUEST}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'SHARE',
				rid: params.rid,
				lid: 1066,
				SSN: 'workflow',
				usergroupvalues: params.usergroupvalues,
				idea: params.idea,
			},
		},
	});
};

export const apiGetHistoryTask = async params => {
	const side = await getSideName();

	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.GET,
		url: `${side}${ENDPOINT.WORKFLOWREQUEST}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'getHistory',
				rid: params.rid,
				lid: params.lid,
			},
		},
	});
};

export const apiDeleteWorkflowRelated = async params => {
	const side = await getSideName();

	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.POST,
		url: `${side}${ENDPOINT.WORKFLOWREQUEST}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'deleteWorkflowRelatedByID',
				lid: 1066,
				workflowrelatedid: params?.workflowrelatedid,
			},
		},
	});
};

export const apiDeleteTaskFlow = async params => {
	const side = await getSideName();

	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.POST,
		url: `${side}${ENDPOINT.TASK}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'deleteTask',
				lid: 1066,
				rid: params.rid,
			},
		},
	});
};

export const apiGetComments = async params => {
	const side = await getSideName();

	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.GET,
		url: `${side}${ENDPOINT.SOCIAL}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'getCommentByOtherResourceId',
				lid: 1066,
				rid: params.rid,
				otherresourceid: params.otherresourceid,
				resourcecategoryid: params?.isTask ? 16 : 8, // cv : 16
				resourcesubcategoryid: params?.isTask ? 0 : 9, // cv : 0
			},
		},
	});
};

export const apiLikeComments = async params => {
	const side = await getSideName();

	return HTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.POST,
		url: `${side}${ENDPOINT.SOCIAL}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: params.action,
				lid: 1066,
				rid: params.rid,
				commentid: params.commentid,
				resourcecategoryid: params?.isTask ? 16 : 8, // cv : 16
				resourcesubcategoryid: params?.isTask ? 0 : 9, // cv : 0
			},
		},
	});
};

export const apiAddComments = async params => {
	// formdata.append('OtherResourceId', params.OtherResourceId);
	// formdata.append('ParentCommentId', params.ParentCommentId);
	// formdata.append('ResourceCategoryId', '8');
	// formdata.append('ResourceSubCategoryId', '9');
	// formdata.append('Content', params.Content);
	// formdata.append('Files', params?.Files?.length ? JSON.stringify(params?.Files) : '');
	const side = await getSideName();

	const data = {
		OtherResourceId: params.OtherResourceId || '',
		ParentCommentId: params.ParentCommentId || '',
		Resourcecategoryid: params?.isTask ? 16 : 8, // cv : 16
		Resourcesubcategoryid: params?.isTask ? 0 : 9, // cv : 0
		Content: params.Content,
		// Files: params?.Files?.length ? JSON.stringify(params?.Files) : null,
	};

	const formdata = new FormData();
	formdata.append('data', JSON.stringify(data));
	formdata.append('Files', params?.Files?.length ? JSON.stringify(params?.Files) : '');

	return AuthHTTP.call<BaseAPIResponse<ICustomerProfile>>({
		method: HTTPRequestMethods.POST,
		url: `${side}${ENDPOINT.SOCIAL}`,
		config: {
			_shouldAuthorize: true,
			params: {
				func: 'ADDCOMMENT',
				rid: params.rid,
			},
		},
		data: formdata,
	});
};
