import { COLORS, FONTS } from 'config';
import { StyleSheet } from 'react-native';
import styled from 'styled-components/native';

export const styles = StyleSheet.create({
	container: {
		flexDirection: 'row',
		alignItems: 'center',
		width: '100%',
		backgroundColor: COLORS.raisinBlack,
		paddingHorizontal: 16,
		// paddingVertical: 12,
		zIndex: 2,
	},
	shadow: {
		shadowColor: COLORS.spaceCadet,
		shadowOffset: {
			width: 0,
			height: 8,
		},
		shadowOpacity: 0.08,
		shadowRadius: 5,
		elevation: 10,
	},
	indicator: {
		height: 20,
	},
});

export const Title = styled.Text`
	color: ${COLORS.trueBlue};
	font-size: 17px;
	font-family: ${FONTS['Roboto-Bold']};
	font-weight: bold;
	line-height: 24px;
	/* text-align: center; */
	flex: 2;
`;

export const ButtonContent = styled.View`
	flex: 1;
	/* width: 24px;
	height: 24px; */
`;
