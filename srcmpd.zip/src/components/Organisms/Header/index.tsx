import React from 'react';

import { Icon } from 'components/Atoms/Icon';
import { goBack } from 'navigation/RootNavigation';
import { Animated, View } from 'react-native';

import { Props } from './interfaces';
import { ButtonContent, styles, Title } from './styles';

export const Header: React.FC<Props> = ({
	iconLeftSrc,
	iconRightSrc,
	leading,
	trailing,
	isUseDivider = false,
	allowFontScaling = false,
	children,
	onPressLeftIcon,
	onPressRightIcon,
	containerStyle = {},
}) => {
	const onPressLeft = () => {
		if (onPressLeftIcon) {
			onPressLeftIcon();
			return;
		}
		goBack();
	};

	return (
		<View style={[styles.container, isUseDivider && styles.shadow, containerStyle]}>
			<ButtonContent style={{ alignItems: 'flex-start' }}>
				{leading}
				{iconLeftSrc && <Icon width={20} height={20} src={iconLeftSrc} onPress={onPressLeft} />}
			</ButtonContent>
			{!!children && <Title allowFontScaling={allowFontScaling}>{children}</Title>}
			<ButtonContent style={{ alignItems: 'flex-end' }}>
				{iconRightSrc && <Icon width={20} height={20} src={iconRightSrc} onPress={onPressRightIcon} />}
				{trailing}
			</ButtonContent>
		</View>
	);
};
