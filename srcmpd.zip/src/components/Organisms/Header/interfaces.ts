import React from 'react';

import { ImageSourcePropType } from 'react-native';

export interface Props {
	iconLeftSrc?: ImageSourcePropType;
	iconRightSrc?: ImageSourcePropType;
	leading?: React.ReactNode;
	trailing?: React.ReactNode;
	isUseDivider?: boolean;
	allowFontScaling?: boolean;
	children?: React.ReactNode;
	onPressLeftIcon?: () => void;
	onPressRightIcon?: () => void;
	containerStyle?: object;
}
