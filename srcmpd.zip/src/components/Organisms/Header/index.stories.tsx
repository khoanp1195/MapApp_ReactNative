import React from 'react';

import { storiesOf } from '@storybook/react-native';
import { ICONS } from 'config';
import { View } from 'react-native';

import { Header } from '.';
import { styles } from './styles';

storiesOf('Organisms/Header', module).add('default', () => (
	<>
		<Header iconLeftSrc={ICONS.backLeft} iconRightSrc={ICONS.notification} isUseDivider={false}>
			Organisms/Header
		</Header>
		<View style={styles.indicator} />
		<Header iconRightSrc={ICONS.notification}>Organisms/Header</Header>
		<View style={styles.indicator} />
		<Header iconLeftSrc={ICONS.backLeft} isUseDivider>
			Organisms/Header
		</Header>
	</>
));
