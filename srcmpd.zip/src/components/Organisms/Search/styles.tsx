import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
	container: {
		height: 40,
		backgroundColor: '#F5F5F5',
		borderRadius: 4,
		justifyContent: 'center',
		paddingHorizontal: 10,
		overflow: 'hidden',
		marginHorizontal: 5,
		marginBottom: 5,
	},

	textInput: { fontStyle: 'italic' },
});
