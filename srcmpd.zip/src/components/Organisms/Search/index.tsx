import React from 'react';

import { TextInput, View } from 'react-native';

import { styles } from './styles';

interface Props {
	onChangeText?: (text: string) => void;
	placeColor?: string;
	placeholder?: string;
}

export const Search = ({
	placeholder = 'Tìm kiếm theo tên quy trình …',
	placeColor = '#999999',
	onChangeText,
}: Props) => {
	return (
		<View style={styles.container}>
			<TextInput
				style={styles.textInput}
				placeholder={placeholder}
				placeholderTextColor={placeColor}
				onChangeText={onChangeText}
			/>
		</View>
	);
};
