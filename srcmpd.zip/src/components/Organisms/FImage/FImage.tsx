/* eslint-disable prettier/prettier */
import { baseURL } from 'http/modules';

import React, { memo, useEffect, useState } from 'react';

import { TouchableOpacity } from 'react-native';
import FastImage from 'react-native-fast-image'
import { getSideName } from 'utils/storage';



const FImage = ({ ImagePath = '', DefaultImagePath = '', SW = 40, SH, onPress, mh = 10, mt = 0 }: { mt?: number; ImagePath?: string; DefaultImagePath?: string, SW?: number, SH?: number, onPress?: () => void; mh?: number }) => {
	const [uri, setUri] = useState<string>();


	useEffect(() => {
		async function getImage() {
			const side = await getSideName()
			const image = `${baseURL}/${side}/_layouts/15/images/VuThao.BPMOP.eOffice/avarta-default.png`
			setUri(image);
		}
		if (!ImagePath) {
			getImage()
		} else {
			setUri(ImagePath);
		}

		return () => {
			// FastImage.clearDiskCache()
			// FastImage.clearMemoryCache()

		}
	}, [ImagePath]);

	return (
		<TouchableOpacity
			disabled={!onPress}
			onPress={onPress}
			activeOpacity={1}
			style={{
				width: SW,
				height: SH || SW,
				marginHorizontal: mh,
				backgroundColor: 'rgba(217, 217, 217, 0.3)',
				borderRadius: SW / 2,
				overflow: 'hidden',
				marginTop: mt
			}}>
			{!!uri && (
				<FastImage

					source={{
						uri,
						// cache: FastImage.cacheControl.immutable
					}}
					style={{ width: '100%', height: '100%' }}
					onError={async () => {
						const side = await getSideName()
						const image = `${baseURL}/${side}/_layouts/15/images/VuThao.BPMOP.eOffice/avarta-default.png`
						setUri(DefaultImagePath || image);
					}}
					resizeMode={FastImage.resizeMode.cover}
				/>
			)}
		</TouchableOpacity>
	);
};

export default memo(FImage);
