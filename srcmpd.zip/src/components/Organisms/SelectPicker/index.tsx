import React, { useState } from 'react';

import { Button, Text } from '@react-native-material/core';
import { COLORS } from 'config';
import { useForceUpdate } from 'hooks/useForceUpdate';
import { FlatList, View } from 'react-native';
import { translate } from 'utils/translate';

import { Props, Option } from './interfaces';
import { Wrapper, Container, Content, styles } from './styles';

export const SelectPicker: React.FC<Props> = ({
	options,
	isCenter = true,
	isMultiple = false,
	isTranslate = true,
	defaultValue,
	onSelect,
}) => {
	const forceUpdate = useForceUpdate();
	const [selectedGenderValue, setSelectedGenderValue] = useState<Option[]>(defaultValue);

	const handleApply = () => {
		if (!selectedGenderValue) return;
		onSelect?.(selectedGenderValue);
	};

	const renderItem = ({ item, index }: { item: Option; index: number }) => {
		const handlePressItem = () => {
			let selectedGenderValueTarget = selectedGenderValue;
			const hasExistIndex = selectedGenderValueTarget?.findIndex(e => e.value === item.value);
			const indexOfAll = selectedGenderValueTarget?.findIndex(e => e.value === 0);
			if (item.value === 0) {
				selectedGenderValueTarget = [item];
			} else if (hasExistIndex !== -1 && selectedGenderValueTarget.length > 1) {
				selectedGenderValueTarget.splice(hasExistIndex, 1);
			} else {
				if (indexOfAll !== -1) {
					selectedGenderValueTarget.splice(indexOfAll, 1);
				}
				selectedGenderValueTarget.push(item);
			}

			setSelectedGenderValue(isMultiple ? selectedGenderValueTarget : [item]);
			forceUpdate();
		};
		return (
			<Wrapper
				activeOpacity={0.8}
				onPress={() => handlePressItem()}
				isSelect={selectedGenderValue.some(e => e.value === item.value)}
				mTop={index === 0 ? 0 : 4}
				style={
					!isCenter
						? { justifyContent: 'flex-start', flexDirection: 'row', paddingVertical: 16, paddingHorizontal: 16 }
						: {}
				}>
				<Text
					color={selectedGenderValue.some(e => e.value === item.value) ? COLORS.darkJungleGreen : COLORS.lavenderGray}>
					{isTranslate ? translate(item.label) : item.label}
				</Text>
			</Wrapper>
		);
	};

	return (
		<Container>
			<Content>
				<FlatList
					data={options}
					showsVerticalScrollIndicator={false}
					nestedScrollEnabled
					keyExtractor={({ value }) => value.toString()}
					contentContainerStyle={{ flexGrow: 1 }}
					renderItem={renderItem}
				/>
			</Content>
			<View style={styles.viewFooter}>
				<Button
					titleStyle={{ fontSize: 16, fontWeight: 'bold' }}
					color={COLORS.trueBlue}
					title={translate('filter_apply')}
					onPress={handleApply}
				/>
			</View>
		</Container>
	);
};
