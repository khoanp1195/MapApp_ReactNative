import { COLORS } from 'config';
import { Dimensions, Platform, StyleSheet } from 'react-native';
import styled from 'styled-components/native';

const { height } = Dimensions.get('window');

export const styles = StyleSheet.create({
	viewFooter: {
		backgroundColor: COLORS.white,
		shadowColor: COLORS.spaceCadet,
		shadowOffset: {
			width: 0,
			height: -8,
		},
		shadowOpacity: 0.08,
		shadowRadius: 5,
		elevation: 10,
		width: '100%',
		paddingHorizontal: 20,
		paddingVertical: 8,
		marginBottom: Platform.OS === 'android' ? -20 : 0,
	},
});

export const Container = styled.View`
	margin-right: -20px;
	margin-left: -20px;
`;

export const Content = styled.View`
	padding: 0 20px 5px;
	max-height: ${height / 2}px;
`;

export const Title = styled.View`
	margin-bottom: 8px;
`;

export const Wrapper = styled.TouchableOpacity<{ isSelect?: boolean; mTop: number }>`
	align-items: center;
	justify-content: center;
	background-color: ${props => (props.isSelect ? COLORS.whiteSmoke : COLORS.white)};
	min-height: 28px;
	margin-top: ${props => props.mTop}px;
`;
