export interface Option {
	value: number;
	label: string;
	labelEN?: string;
}

export interface Props {
	options: Array<Option>;
	isCenter?: boolean;
	isMultiple?: boolean;
	isTranslate?: boolean;
	defaultValue: Option[];
	onSelect?: (option: Option[]) => void;
}
