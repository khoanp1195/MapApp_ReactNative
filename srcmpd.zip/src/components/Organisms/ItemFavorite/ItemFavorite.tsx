import React from 'react';

import { Icon } from 'components/Atoms/Icon';
import { ICONS } from 'config';
import useSystem from 'hooks/useSystem';
import { View, Text, Image, Dimensions, TouchableOpacity } from 'react-native';
import { IItemFavorite } from 'stores/Home';

import { styles } from './styles';

const windowWidth = Dimensions.get('window').width;
const WidthMargin = windowWidth - 48;

const ItemFavorite = ({
	item,
	index,
	isFW,
	useBookmark = false,
	handFavorite,
	onPressItem = () => { },
}: {
	item: IItemFavorite;
	index: number;
	isFW?: boolean;
	useBookmark?: boolean;
	handFavorite?: (params: any, item: any) => void;
	onPressItem?: (item: any) => void;
}) => {
	const { isVN, Cookie } = useSystem();

	const styleView = isFW
		? { marginRight: index % 2 !== 0 ? 1 : 8, marginLeft: index % 2 === 0 ? 1 : 8, width: WidthMargin / 2 - 9 }
		: { width: WidthMargin - 2 };

	const onPress = () => onPressItem(item);

	return (
		<TouchableOpacity
			onPress={onPress}
			style={[styles.containerItem, styleView, { marginHorizontal: 1, flexDirection: 'row' }]}>
			<View style={styles.item}>
				<View style={styles.imageItem}>
					{item?.ImageURL && (
						<Image
							source={{
								uri: item.ImageURL,
								headers: {
									Cookie,
								},
							}}
							style={styles.image}
						/>
					)}
				</View>
				<View style={styles.description}>
					<Text style={styles.titleItem} numberOfLines={2}>
						{isVN ? item.Title : item.TitleEN}
					</Text>
					{/* <Text style={styles.descItem} numberOfLines={1}>
						{item.WorkflowCategory}
					</Text> */}
				</View>
			</View>
			{useBookmark && (
				<TouchableOpacity
					hitSlop={{ top: 20, bottom: 20, right: 20, left: 20 }}
					onPress={() => {
						const params = {
							id: item?.WorkflowID,
							flag: item?.IsFavor ? 0 : 1,
							WorkflowCategoryID: item?.WorkflowCategoryID,
						};
						handFavorite(params, item);
					}}>
					<Icon src={item.IsFavor ? ICONS.icActiveBookMark : ICONS.icBookMark} width={20} height={20} />
				</TouchableOpacity>
			)}
		</TouchableOpacity>
	);
};

export default ItemFavorite;
