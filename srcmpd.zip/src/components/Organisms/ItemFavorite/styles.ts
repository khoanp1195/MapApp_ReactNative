import { Platform, StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
	container: { marginHorizontal: 24, flex: 1, marginVertical: 30 },
	title: { fontSize: 16, fontWeight: '700' },
	all: { fontSize: 12, fontWeight: '400', color: 'rgba(0, 95, 212, 1)' },
	flatlist: { flexDirection: 'column', marginVertical: 10 },
	containerItem: {
		height: 67,
		borderRadius: 12,
		shadowColor: `{rgba(0, 0, 0, ${Platform.OS === 'ios' ? 1 : 0.3})}`,
		shadowOffset: {
			width: 0,
			height: 0.5,
		},
		shadowOpacity: 0.2,
		shadowRadius: 1,
		elevation: 3,
		backgroundColor: 'rgba(255, 255, 255, 1)',
		marginVertical: 10,

		alignItems: 'center',
		justifyContent: 'center',
		borderWidth: 0.8,
		borderColor: 'rgba(226, 232, 240, 0.5)',
	},
	item: {
		flexDirection: 'row',
		overflow: 'hidden',
		width: '80%',
	},
	imageItem: {
		width: 34,
		height: 33,
		backgroundColor: 'rgba(227, 240, 255, 1)',
		borderRadius: 8,
		marginRight: 8,
		alignItems: 'center',
		justifyContent: 'center',
		overflow: 'hidden',
	},
	image: { width: '50%', height: '50%' },
	description: { flex: 1, justifyContent: 'center', marginRight: 2 },
	titleItem: { fontSize: 12, fontWeight: '700' },
	descItem: { fontSize: 12, fontWeight: '400', color: 'rgba(71, 85, 105, 1)' },
});
