import React, { useMemo } from 'react';

import { Text } from '@react-native-material/core';
import { MaterialTopTabBarProps } from '@react-navigation/material-top-tabs';
import en from 'assets/i18n/en';
import { Header } from 'components/Organisms/Header';
import { COLORS, ICONS } from 'config';
import { navigate } from 'navigation/RootNavigation';
import { ScrollView, TouchableOpacity, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppSelector } from 'stores';
import { translate } from 'utils/translate';

import { styles } from './styles';

interface Props extends MaterialTopTabBarProps {
	nameHeader?: string;
	customHeader?: React.ReactNode;
	backBehaviorScreen?: string;
	fullwidth?: boolean;
	bottomView?: React.ReactNode;
	textActiveColor?: string;
	useAutoWidth?: boolean;
	useShadow?: boolean;
	unUsePaddingScroll?: boolean;
	trailing?: React.ReactNode;
	countTask?: { my_task?: number; my_request?: number };
}

export const MaterialTopTabsNavigator: React.FC<Props> = ({
	navigation,
	state,
	nameHeader,
	customHeader,
	backBehaviorScreen,
	fullwidth,
	bottomView,
	trailing,
	textActiveColor,
	useAutoWidth = false,
	useShadow = false,
	unUsePaddingScroll = false,
	countTask = {},
}): React.ReactElement => {
	const onPressLeftIcon = () => {
		if (!backBehaviorScreen) return;
		navigate(backBehaviorScreen);
	};

	const tabViewStyle = useMemo(() => {
		return StyleSheet.create({
			focusStyle: {
				backgroundColor: COLORS.white,
				borderRadius: 18,
				borderWidth: 1,
				borderColor: COLORS.trueBlue,
			},
		});
	}, []);

	const count = useAppSelector(state => state.count.count);

	const _countTask = {
		my_task: count?.CountMyTask || 0,
		my_request: count?.CountMyRequest || 0,
	};

	return (
		<SafeAreaView edges={['top']} style={[styles.container, useShadow && styles.shadow]}>
			{!customHeader ? (
				<Header
					onPressLeftIcon={backBehaviorScreen ? onPressLeftIcon : undefined}
					iconLeftSrc={ICONS.backLeft}
					isUseDivider={false}>
					{nameHeader}
				</Header>
			) : (
				customHeader
			)}
			<View style={[styles.contentTabView, styles.tabViewContainerNonAutoWidth]}>
				<ScrollView
					style={[styles.tabViewContainer]}
					contentContainerStyle={[fullwidth && styles.scrollViewContainer]}
					horizontal
					showsHorizontalScrollIndicator={false}
					bounces={false}>
					<View style={[styles.itemTab, styles.shadow]}>
						{state.routes.map((route, index) => {
							const isFocused = state.index === index;
							const onPress = () => {
								const event = navigation.emit({
									type: 'tabPress',
									target: route.key,
									canPreventDefault: true,
								});

								if (!isFocused && !event.defaultPrevented) {
									navigate(route.name);
								}
							};
							const countTaskTarget = _countTask[route.name as keyof typeof _countTask] || 0;
							return (
								<TouchableOpacity
									// eslint-disable-next-line react/no-array-index-key
									key={index.toString()}
									style={[
										styles.tabView,
										useAutoWidth && [styles.tabViewAutoWidth, index === 0 && styles.tabViewAutoWidthFirstItem],
										unUsePaddingScroll && styles.unusePaddingScroll,
										isFocused && tabViewStyle.focusStyle,
										fullwidth && { flex: 1 },
									]}
									onPress={onPress}>
									<Text
										style={{ fontWeight: isFocused ? 'bold' : 'normal', fontSize: 14 }}
										numberOfLines={1}
										color={isFocused ? textActiveColor || COLORS.white : COLORS.white}>
										{translate(route.name as keyof typeof en)}
										{countTaskTarget > 0 && (
											<Text
												color={isFocused ? COLORS.orange : COLORS.white}
												style={{ fontSize: 14 }}>{` (${countTaskTarget})`}</Text>
										)}
									</Text>
								</TouchableOpacity>
							);
						})}
					</View>
				</ScrollView>
				{trailing}
			</View>
			{bottomView}
		</SafeAreaView>
	);
};

MaterialTopTabsNavigator.defaultProps = {
	nameHeader: '',
	customHeader: null,
	backBehaviorScreen: undefined,
	fullwidth: false,
	bottomView: null,
	trailing: null,
};
