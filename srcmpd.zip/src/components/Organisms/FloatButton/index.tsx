import React from 'react';

import { Icon } from 'components/Atoms/Icon';
import { ICONS } from 'config';

import { Container, styles } from './styles';

export const FloatButton = () => {
	return (
		<Container style={styles.shadow}>
			<Icon src={ICONS.icCreate} width={24} height={24} />
		</Container>
	);
};
