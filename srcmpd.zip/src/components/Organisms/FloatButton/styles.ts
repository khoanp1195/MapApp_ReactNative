import { COLORS } from 'config';
import { StyleSheet } from 'react-native';
import styled from 'styled-components/native';

export const Container = styled.View`
	border-radius: 50px;
	padding: 18px;
	background-color: ${COLORS.trueBlue};
	position: absolute;
	z-index: 999999999;
	bottom: 106px;
	right: 16px;
`;

export const styles = StyleSheet.create({
	shadow: {
		shadowColor: COLORS.spaceCadet,
		shadowOffset: {
			width: 0,
			height: 8,
		},
		shadowOpacity: 0.08,
		shadowRadius: 5,
		elevation: 10,
		zIndex: 2,
	},
});
