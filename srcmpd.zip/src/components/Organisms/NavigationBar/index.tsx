/* eslint-disable react/no-unused-prop-types */
import React, { useCallback } from 'react';

import { createBottomTabNavigator, BottomTabBarOptions } from '@react-navigation/bottom-tabs';
import { Icon } from 'components/Atoms/Icon';
import { COLORS } from 'config';
import { ImageSourcePropType, Platform, Text } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppSelector } from 'stores';
import { translate } from 'utils/translate';

import { NavBarProps } from './interface';
import { flattenText, styles, tabStyles } from './styles';

const Tab = createBottomTabNavigator();

interface TabBarIconProps {
	focused: boolean;
	iconName: ImageSourcePropType;
	iconNameActive: ImageSourcePropType;
}

interface TabBarLabelProps {
	focused: boolean;
	label: string;
}

const TabBarIcon = ({ iconName, focused, iconNameActive }: TabBarIconProps) => (
	<Icon src={focused ? iconNameActive : iconName} width={24} height={24} />
);

export const NavigationBar: React.FC<NavBarProps> = ({ initialRoute, navbarList }) => {
	const insets = useSafeAreaInsets();
	const { language } = useAppSelector(state => state.dataNotRemove);

	const TabBarLabel = useCallback(
		({ label, focused }: TabBarLabelProps) => (
			<Text numberOfLines={1} style={focused ? flattenText : styles.text}>
				{translate(label)}
			</Text>
		),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[language],
	);

	const workflowsApps = useAppSelector(store => store.apps.workflowsApps);
	const isChildrenApps = !!workflowsApps?.ID;

	return (
		<Tab.Navigator
			initialRouteName={initialRoute}
			tabBarOptions={{
				style: {
					...tabStyles.style,
					zIndex: 20,
					height: Platform.OS === 'android' ? 65 : 56 + insets.bottom,
				} as BottomTabBarOptions['style'],
				tabStyle: { height: 92 },
				keyboardHidesTabBar: Platform.OS === 'android',
			}}
			screenOptions={
				{
					// unmountOnBlur: true,
					// lazy: true,
				}
			}>
			{navbarList.map(({ path, iconName, label, component, iconNameActive }, index) => {
				if (isChildrenApps && path === 'Apps') return null;
				if (!isChildrenApps && path === 'List') return null;
				return (
					<Tab.Screen
						// eslint-disable-next-line react/no-array-index-key
						key={index.toString()}
						name={path}
						component={component}
						options={{
							tabBarIcon: ({ focused }) =>
								TabBarIcon({
									focused,
									iconName,
									iconNameActive,
								}),
							tabBarLabel: ({ focused }) =>
								TabBarLabel({
									focused,
									label,
								}),
						}}
					/>
				);
			})}
		</Tab.Navigator>
	);
};
