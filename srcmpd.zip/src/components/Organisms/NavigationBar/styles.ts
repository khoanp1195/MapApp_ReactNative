import { COLORS, FONTS } from 'config';
import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
	iconWrapper: {
		marginTop: 10,
	},
	containerIconQR: {
		marginTop: 12,
		borderColor: COLORS.isabelline,
		borderWidth: 1,
		paddingVertical: 8,
		paddingHorizontal: 8,
		borderRadius: 24,
	},
	text: {
		fontFamily: FONTS['Roboto-Regular'],
		fontSize: 12,
		marginBottom: 44,
		lineHeight: 14,
		color: COLORS.gray,
		textTransform: 'capitalize',
	},
	textActive: {
		fontFamily: FONTS['Roboto-Bold'],
		color: COLORS.trueBlue,
		fontSize: 12,
		fontWeight: 'bold',
		lineHeight: 14,
	},
	tabBarBadgeStyle: {
		fontSize: 10,
		fontFamily: FONTS['Roboto-Regular'],
	},
	QRCodeContainer: {
		marginTop: 8,
	},
});

export const tabStyles = {
	style: {
		// backgroundColor: COLORS.black,
		// borderTopWidth: 0,
		// borderBottomWidth: 0,
		// borderTopColor: 'transparent',
		// borderBottomColor: 'transparent',
		shadowColor: COLORS.black,
		shadowOffset: {
			width: 0,
			height: -1,
		},
		shadowOpacity: 0.12,
		shadowRadius: 5,
		elevation: 20,
		paddingTop: 6,
		marginTop: -24,
	},
};

export const flattenText = StyleSheet.flatten([styles.text, styles.textActive]);
