import { ImageProps } from 'react-native';

export interface NavBarItemProps {
	path: string;
	iconName: ImageProps['source'];
	iconNameActive: ImageProps['source'];
	label: string;
	component: React.ComponentType<unknown>;
}

export interface NavBarProps {
	initialRoute?: string;
	navbarList: NavBarItemProps[];
}
