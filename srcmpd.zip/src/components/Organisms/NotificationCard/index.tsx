import React from 'react';

import { COLORS } from 'config';
import { Image, TouchableOpacity } from 'react-native';
import { TextCustom } from 'screens/Home/styles';
import dayjs from 'utils/dayjs';

import { Props } from './interfaces';
import { Body, styles } from './styles';

export const NotificationCard: React.FC<Props> = ({ content, icon, created, onPress }) => {
	return (
		<TouchableOpacity style={styles.container} onPress={onPress}>
			<Image source={{ uri: icon }} style={{ width: 16, height: 16 }} />
			<Body>
				<TextCustom
					style={{ flex: 1, marginBottom: 6 }}
					fw={400}
					fs={15}
					lh={20}
					color={COLORS.eerieBlack}
					numberOfLines={2}>
					{content || ''}
				</TextCustom>
				<TextCustom style={{ flex: 1 }} fw={400} fs={12} lh={16} color={COLORS.davyGrey} mBottom={6} numberOfLines={1}>
					{dayjs(created).format('DD/MM/YYYY hh:mm')}
				</TextCustom>
			</Body>
		</TouchableOpacity>
	);
};
