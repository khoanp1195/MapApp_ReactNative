export interface Props {
	content?: string;
	icon: string;
	flgRead?: boolean;
	created?: string;
	onPress?: () => void;
}
