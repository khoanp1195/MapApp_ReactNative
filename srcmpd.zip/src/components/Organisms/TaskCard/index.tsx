import React, { useState } from 'react';

import { Text } from '@react-native-material/core';
import { Icon } from 'components/Atoms/Icon';
import { ICONS, COLORS } from 'config';
import { TouchableOpacity, View } from 'react-native';
import { TouchableWithoutFeedback } from 'react-native-gesture-handler';
import { TextCustom } from 'screens/Home/styles';
import { ResourcetypeTask } from 'services/Tasks/types';
import dayjs from 'utils/dayjs';

import { Props } from './interfaces';
import { IconWrapper, Body, styles, Status, Row, Action } from './styles';
import FImage from '../FImage/FImage';

export const TaskCard: React.FC<Props> = ({
	title,
	description,
	time,
	allowFontScaling = false,
	expire,
	isFollow,
	fileCount,
	avatar,
	assignedToName,
	numExpand = 0,
	type,
	defaultAvatar,
	statusTitle,
	typeCurrent,
	onPress,
	isTask,
	isShowCode = false,
	code,
}) => {
	const [valid, setValid] = useState<boolean>(true);

	const renderExpireText = () => {
		let expireObj = { color: COLORS.black, content: '' };
		if (dayjs(expire).isSame(new Date(), 'day')) {
			expireObj = { color: COLORS.deepLilac, content: 'Hết hạn hôm nay' };
		} else if (dayjs(expire).isBefore(new Date(), 'day')) {
			const hours = dayjs().diff(dayjs(expire), 'hours');
			const days = Math.floor(hours / 24);
			expireObj = { color: COLORS.deepCarminePink, content: `Quá hạn ${days} ngày` };
		} else if (dayjs(expire).isAfter(new Date(), 'day')) {
			const hours = dayjs(expire).diff(dayjs(), 'hours');
			const days = Math.floor(hours / 24);
			if (days > 7) {
				expireObj = { color: COLORS.davyGrey, content: dayjs(expire).format('DD/MM/YYYY HH:mm') };
			} else {
				expireObj = { color: COLORS.black, content: `Còn ${days} ngày` };
			}
		}
		return expireObj;
	};

	// const renderStatus = () => {
	// 	let expireObj = { color: COLORS.black, content: '' };
	// 	switch (status?.ID) {
	// 		case value:

	// 			break;

	// 		default:
	// 			break;
	// 	}
	// 	return expireObj;
	// };

	const getDateTimeCreated = () => {
		if (typeCurrent === 'older') return dayjs(time).format('DD/MM/YYYY hh:mm') || '';
		return dayjs(time).format('hh:mm') || '';
	};

	return (
		<TouchableWithoutFeedback style={styles.container} onPress={onPress}>
			<FImage ImagePath={avatar} DefaultImagePath={defaultAvatar} />
			<Body>
				<Row>
					<TextCustom
						style={{ flex: 1 }}
						allowFontScaling={allowFontScaling}
						fw={400}
						fs={15}
						lh={20}
						color={COLORS.eerieBlack}
						numberOfLines={1}>
						{title || ''}
					</TextCustom>
					<TextCustom
						style={{ flex: 1, textAlign: 'right' }}
						allowFontScaling={allowFontScaling}
						fw={400}
						fs={12}
						lh={14}
						color={COLORS.davyGrey}
						mBottom={2}
						numberOfLines={1}>
						{getDateTimeCreated()}
					</TextCustom>
				</Row>
				<Row>
					<TextCustom
						style={{ flex: 4 }}
						allowFontScaling={allowFontScaling}
						fw={400}
						fs={12}
						lh={16}
						color={COLORS.davyGrey}
						mBottom={6}
						numberOfLines={1}>
						{type === ResourcetypeTask.MYTASK
							? description || ''
							: `Đến: ${assignedToName || ''} ${!(numExpand > 0) ? '' : `, +${numExpand || 0}`}`}
					</TextCustom>
					<Action>
						{!isTask && (
							<>
								{isFollow ? (
									<Icon src={ICONS.icStat} width={15} height={15} tintColor={COLORS.aureolin} />
								) : (
									<Icon src={ICONS.icStat} width={15} height={15} />
								)}
							</>
						)}
						{fileCount && <Icon src={ICONS.icFile} width={15} height={15} style={{ marginLeft: 12 }} />}
					</Action>
				</Row>
				<Row>
					<Status style={{ backgroundColor: COLORS.azureishWhite }}>
						<TextCustom
							allowFontScaling={allowFontScaling}
							fw={400}
							fs={12}
							lh={16}
							color={COLORS.black}
							numberOfLines={1}>
							{statusTitle}
						</TextCustom>
					</Status>
					<Text
						style={{ flex: 1, textAlign: 'right', fontSize: 12, fontWeight: '400', marginBottom: 6 }}
						color={renderExpireText().color}
						numberOfLines={1}>
						{isShowCode ? code : renderExpireText().content || ''}
					</Text>
				</Row>
			</Body>
		</TouchableWithoutFeedback>
	);
};
