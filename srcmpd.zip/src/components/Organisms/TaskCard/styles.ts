import { COLORS } from 'config';
import { StyleSheet } from 'react-native';
import styled from 'styled-components/native';

export const Container = styled.View<{ isRead?: boolean }>`
	padding: 10px;
	background-color: ${props => (props.isRead ? COLORS.white : COLORS.aliceBlue)};
	border: 1px solid ${props => (props.isRead ? COLORS.azureishWhite : COLORS.patrickBlue)};
	border-radius: 8px;
`;

export const Heading = styled.View`
	flex: 1;
	flex-direction: row;
	align-items: center;
`;

export const IconWrapper = styled.Image`
	width: 40px;
	height: 40px;
	justify-content: center;
	align-items: center;
	border-radius: 50px;
`;

export const Body = styled.View`
	flex: 1;
	margin-left: 12px;
`;

export const Status = styled.View`
	align-self: baseline;
	padding: 3px 10px;
	justify-content: center;
	align-items: center;
	border-radius: 5px;
`;

export const Row = styled.View`
	flex-direction: row;
	align-items: center;
	justify-content: space-between;
`;

export const Action = styled.View`
	flex: 1;
	justify-content: flex-end;
	flex-direction: row;
	align-items: center;
`;

export const styles = StyleSheet.create({
	container: {
		flexDirection: 'row',
		paddingVertical: 13,
		paddingHorizontal: 15,
	},
	containerRead: {
		borderColor: COLORS.azureishWhite,
	},
	containerNotRead: {
		borderColor: COLORS.patrickBlue,
	},
	shadow: {
		backgroundColor: COLORS.white,
		shadowColor: COLORS.spaceCadet,
		shadowOffset: {
			width: 0,
			height: 8,
		},
		shadowOpacity: 0.08,
		shadowRadius: 5,
		elevation: 10,
	},
});
