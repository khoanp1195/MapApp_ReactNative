import React from 'react';
import { ResourcetypeTask } from 'services/Tasks/types';

export interface Props {
	title?: string;
	description?: string;
	time?: string;
	onPress?: () => void;
	expire?: string;
	isFollow?: boolean;
	fileCount?: boolean;
	status?: number;
	statusTitle?: string;
	avatar?: string;
	defaultAvatar?: string;
	assignedToName?: string;
	numExpand?: number;
	type?: ResourcetypeTask;
	allowFontScaling?: boolean;
	typeCurrent?: string;
	isTask?: boolean;
	isShowCode?: boolean;
	code?: string;
	renderLeftSide?: React.JSX.Element;
}
