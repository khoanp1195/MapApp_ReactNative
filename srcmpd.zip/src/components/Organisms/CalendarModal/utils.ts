/* eslint-disable import/no-extraneous-dependencies */
import { COLORS, FONTS } from 'config';
import { LocaleConfig } from 'react-native-calendars';
import { MarkingProps } from 'react-native-calendars/src/calendar/day/marking';
import dayjs from 'utils/dayjs';

import { DatePickerProps, DatePickerState } from './interfaces';

export const DATE_FORMAT = 'YYYY-MM-DD';

export const THEME_CONFIG = {
	textDayFontFamily: FONTS['Roboto-Regular'],
	dayTextColor: COLORS.independence,
	textDayFontSize: 13,
	todayTextColor: COLORS.darkCandyAppleRed,
	'stylesheet.calendar.main': {
		dayContainer: {
			flex: 1,
			width: 46,
			height: 48,
			alignItems: 'center',
			justifyContent: 'center',
		},
		monthView: {
			width: '100%',
		},
	},
	'stylesheet.day.basic': {
		base: {
			width: 46,
			height: 48,
			alignItems: 'center',
			justifyContent: 'center',
		},
		selected: {
			borderRadius: 0,
			backgroundColor: COLORS.darkCandyAppleRed,
		},
	},
} as const;

export const nameDay = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];

export const setupLocation = () => {
	LocaleConfig.locales.vi = {
		monthNames: [
			'Tháng 1',
			'Tháng 2',
			'Tháng 3',
			'Tháng 4',
			'Tháng 5',
			'Tháng 6',
			'Tháng 7',
			'Tháng 8',
			'Tháng 9',
			'Tháng 10',
			'Tháng 11',
			'Tháng 12',
		],
		monthNamesShort: [
			'Th 1',
			'Th 2',
			'Th 3',
			'Th 4',
			'Th 5',
			'Th 6',
			'Th 7',
			'Th 8',
			'Th 9',
			'Th 10',
			'Th 11',
			'Th 12',
		],
		dayNames: ['Thứ hai', 'Thứ ba', 'Thứ 4', 'Thứ 5', 'Thứ 6', 'Thứ 7', 'Chủ nhật'],
		dayNamesShort: ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'],
	};

	LocaleConfig.defaultLocale = 'vi';
};

export const initialSelectedDateDateFromProps = ({
	defaultValue,
	value,
}: Pick<DatePickerProps, 'defaultValue' | 'value'>) => {
	const normalizeValue = value && (Array.isArray(value) ? value : [value]);
	const normalizeDefaultValue = defaultValue && (Array.isArray(defaultValue) ? defaultValue : [defaultValue]);

	return normalizeValue || normalizeDefaultValue || [];
};

export const getDateToDate = (startDate: string, stopDate: string) => {
	const dateArray: Array<string> = [];
	let fromDate = dayjs(startDate);
	const endDate = dayjs(stopDate);
	while (fromDate <= endDate) {
		dateArray.push(dayjs(fromDate).format('YYYY-MM-DD'));
		fromDate = dayjs(fromDate).add(1, 'days');
	}
	return dateArray;
};

export const generateMarkFromSelectedDate = ({ selectedDate, color }: DatePickerState) => {
	if (selectedDate.length === 0) return {};
	return {
		[selectedDate[0]]: {
			customStyles: {
				container: {
					backgroundColor: color,
					borderRadius: 5,
					width: '100%',
					height: '100%',
				},
				text: {
					color: COLORS.white,
					fontFamily: FONTS['Roboto-Regular'],
					fontWeight: '400',
				},
			},
		} as MarkingProps,
	};
};
