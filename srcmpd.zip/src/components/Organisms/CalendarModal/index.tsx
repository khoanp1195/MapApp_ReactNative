/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable import/no-extraneous-dependencies */
import React, { useCallback, useMemo, useState } from 'react';

import en from 'assets/i18n/en';
import { Text } from 'components/Atoms/Text';
import { ModalComponent } from 'components/Molecules/Modal';
import { COLORS } from 'config';
import { Dimensions, TouchableOpacity, View } from 'react-native';
import { CalendarList } from 'react-native-calendars';
import { DateData } from 'react-native-calendars/src/types';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import dayjs from 'utils/dayjs';
import { translate } from 'utils/translate';

import { DatePickerState, Props } from './interfaces';
import { CustomHeader, Schedule, Footer, styles } from './styles';
import {
	DATE_FORMAT,
	generateMarkFromSelectedDate,
	initialSelectedDateDateFromProps,
	nameDay,
	setupLocation,
	THEME_CONFIG,
} from './utils';

export const CalendarModal: React.FC<Props> = ({
	isVisible,
	footerTitle,
	headerTitle,
	defaultValue,
	value,
	disabled,
	color,
	onClose,
	onDateSelected,
	minDate,
	maxDate,
	markingType = 'custom',
	calendarStyle,
}) => {
	setupLocation();
	const [state, setState] = useState<DatePickerState>(() => {
		const selectedDate = initialSelectedDateDateFromProps({ defaultValue, value });
		return {
			selectedDate,
		};
	});

	const insets = useSafeAreaInsets();

	const windowHeight = Dimensions.get('window').height;

	const buttonDisable = useMemo(() => state.selectedDate.length !== 0, [state.selectedDate]);

	const handleSelectDate = useCallback(
		(dateObject: DateData) => {
			const nextSelectedDateState = [dateObject.dateString];
			if (value === undefined) {
				setState(prevState => ({
					...prevState,
					selectedDate:
						markingType === 'period'
							? new Date(dateObject.dateString).getTime() <= new Date(prevState.selectedDate?.[0]).getTime()
								? nextSelectedDateState
								: [...prevState.selectedDate, dateObject.dateString]
							: nextSelectedDateState,
				}));
			}
		},
		[value, markingType],
	);

	const handleOnPressDay = useCallback(
		// eslint-disable-next-line @typescript-eslint/ban-ts-comment
		// @ts-ignore
		dateObject => {
			if (disabled) return;
			handleSelectDate(dateObject as DateData);
		},
		[disabled, handleSelectDate],
	);

	const handleApply = useCallback(() => {
		if (onDateSelected) {
			onDateSelected(
				dayjs(state.selectedDate[0], DATE_FORMAT).toDate(),
				dayjs(state.selectedDate[state.selectedDate.length - 1], DATE_FORMAT).toDate(),
			);
		}
	}, [onDateSelected, state.selectedDate]);

	const renderFooter = () => (
		<View style={{ position: 'absolute', bottom: -insets.bottom, width: '100%', alignItems: 'center', left: 20 }}>
			<TouchableOpacity
				disabled={!buttonDisable}
				onPress={handleApply}
				style={{
					backgroundColor: COLORS.trueBlue,
					width: '100%',
					height: 42,
					alignItems: 'center',
					justifyContent: 'center',
					borderRadius: 8,
				}}>
				<Text style={{ color: 'white', fontWeight: '600' }}>{footerTitle}</Text>
			</TouchableOpacity>
		</View>
		// <Footer>
		// 	<Schedule
		// 		borderRadius={4}
		// 		height={44}
		// 		activeOpacity={0.8}
		// 		color={color}
		// 		disabled={!buttonDisable}
		// 		onPress={handleApply}>
		// 		<Text fw="bold" lh={20} color={!buttonDisable ? COLORS.cadetGrey : COLORS.white}>
		// 			{footerTitle}
		// 		</Text>
		// 	</Schedule>
		// </Footer>
	);

	return (
		<ModalComponent
			open={isVisible}
			outsideClickCloseable
			onClose={onClose}
			// visiblePosition="bottom"
			headerTitle={headerTitle}
			// renderFooter={renderFooter}
			container={{}}>
			<View style={{ minHeight: windowHeight * 0.8 }}>
				<CustomHeader>
					{nameDay.map((i, index) => (
						// eslint-disable-next-line react/no-array-index-key
						<Text key={index.toString()} fs={13} lh={16} color={COLORS.independence}>
							{translate(i as keyof typeof en)}
						</Text>
					))}
				</CustomHeader>
				<View style={{ flex: 1 }}>
					<CalendarList
						// horizontal
						// pagingEnabled
						maxDate={maxDate}
						// style={styles.calendar}
						firstDay={2}
						onDayPress={handleOnPressDay}
						markingType={markingType}
						pastScrollRange={24}
						futureScrollRange={24}
						hideArrows
						hideDayNames
						minDate={minDate}
						current={String(state.selectedDate)}
						markedDates={generateMarkFromSelectedDate({ selectedDate: state.selectedDate, color })}
						theme={{ ...THEME_CONFIG, todayTextColor: String(color) }}
						renderHeader={date => {
							const currentMonth = defaultValue || value ? new Date(String(defaultValue || value)) : new Date();
							const calendarHeaderStyle = {
								borderTopColor: COLORS.whiteSmoke,
								borderTopWidth: 12,
								height: 36,
								width: '100%',
								flex: 1,
								marginHorizontal: -20,
								paddingLeft: 20,
								paddingTop: 8,
							};

							return (
								<View style={calendarHeaderStyle}>
									<Text fs={13} lh={16} fw="bold" color={COLORS.darkJungleGreen}>
										{Number(date?.getMonth()) + 1} - {date?.getFullYear()}
									</Text>
								</View>
							);
						}}
					/>
				</View>
				<View
					style={{
						// position: 'absolute',
						marginBottom: insets.bottom || 10,
						width: '100%',
						alignItems: 'center',
						paddingHorizontal: 20,
					}}>
					<TouchableOpacity
						disabled={!buttonDisable}
						onPress={handleApply}
						style={{
							backgroundColor: COLORS.trueBlue,
							width: '100%',
							height: 42,
							alignItems: 'center',
							justifyContent: 'center',
							borderRadius: 8,
						}}>
						<Text style={{ color: 'white', fontWeight: '600' }}>{footerTitle}</Text>
					</TouchableOpacity>
				</View>
			</View>
		</ModalComponent>
	);
};
