import { COLORS } from 'config';
import { Dimensions, StyleSheet } from 'react-native';
import styled, { css } from 'styled-components/native';

const { width } = Dimensions.get('window');

export const styles = StyleSheet.create({
	calendarList: { marginHorizontal: -20, height: '75%' },
	calendar: { width: '100%', aspectRatio: 375 / 525 },
});

export const Schedule = styled.TouchableOpacity<{
	isBorder?: boolean;
	height?: number;
	borderRadius?: number;
	color?: keyof typeof COLORS;
	isCancel?: boolean;
}>`
	${props =>
		props.isBorder
			? css`
					border: 1px solid ${props.color || COLORS.yellowGreen};
			  `
			: css`
					background-color: ${props.color || COLORS.yellowGreen};
			  `};
	${props =>
		props.disabled &&
		css`
			background-color: ${COLORS.azureishWhite};
		`};
	${props =>
		props.isCancel
			? css`
					width: ${width * 0.3}px;
					margin-right: 12px;
			  `
			: css`
					flex: 1;
			  `};
	border-radius: ${props => props.borderRadius || 2}px;
	align-items: center;
	justify-content: center;
	height: ${props => props.height || 36}px;
`;

export const CustomHeader = styled.View`
	flex-direction: row;
	justify-content: space-evenly;
	padding: 16px 0px;
	margin: -20px -20px 0px -20px;
	background-color: ${COLORS.whiteSmoke};
`;

export const Footer = styled.View`
	flex-direction: row;
	align-items: center;
	margin: -20px;
	padding: 20px;
	margin-bottom: -40px;
	background-color: ${COLORS.white};
`;
