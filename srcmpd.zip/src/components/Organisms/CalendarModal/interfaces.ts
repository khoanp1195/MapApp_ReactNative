/* eslint-disable import/no-extraneous-dependencies */
import { COLORS } from 'config';
import { StyleProp, ViewStyle } from 'react-native';
import { MarkingTypes } from 'react-native-calendars/src/types';

export interface DatePickerProps {
	/**
	 *  A string or array of string has 'YYYY-MM-DD' format
	 */
	defaultValue?: string;
	value?: string;
	disabled?: boolean;
	onDateSelected?: (startDate: Date, endDate?: Date) => void;
	minDate?: string;
	markingType?: MarkingTypes;
}

export interface DatePickerState extends Pick<DatePickerProps, 'markingType'> {
	/**
	 *  A string or array of string has 'YYYY-MM-DD' format
	 */
	selectedDate: string[];
	color?: keyof typeof COLORS;
}

export interface Props extends DatePickerProps {
	isVisible: boolean;
	headerTitle: string;
	footerTitle: string;
	color?: keyof typeof COLORS;
	pastScrollRange?: boolean;
	onClose?: () => void;
	titleCancel?: string;
	onCancel?: () => void;
	calendarStyle?: StyleProp<ViewStyle>;
	maxDate?: string;
}
