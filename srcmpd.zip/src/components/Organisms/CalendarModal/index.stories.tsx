import React from 'react';

// eslint-disable-next-line import/no-extraneous-dependencies
import { useState } from '@storybook/addons';
import { storiesOf } from '@storybook/react-native';
import { COLORS } from 'config';
import { Pressable, Text } from 'react-native';

import { CalendarModal } from '.';

storiesOf('Organisms/CalendarModal', module).add('default', () => {
	const [open, setOpen] = useState(false);
	return (
		<>
			<Pressable onPress={() => setOpen(true)}>
				<Text>Open modal</Text>
			</Pressable>
			<CalendarModal
				headerTitle="Ngày"
				footerTitle="ÁP DỤNG"
				isVisible={open}
				onClose={() => setOpen(false)}
				color={COLORS.dodgerblue}
			/>
		</>
	);
});
