export enum ModalTypes {
	STATUS = 'status',
	STATE = 'state',
	DUA_DATE = 'dua_date',
	FROM_DATE = 'date_received_from',
	TO_DATE = 'date_received_to',
	WOLKFLOW = 'workflow',
}

// ViewType: 2: Đang xử lý, 4: Đã xử lý
export const ViewType = [
	{ value: 2, label: 'status_in_progress' },
	{ value: 4, label: 'status_completed' },
];
// Flag: 0: lấy tất cả các phiếu, 1: Lấy các phiếu trong ngày, 2: Lấy các phiếu trễ hạn

export const Flag = [
	{ value: 0, label: 'flag_all' },
	{ value: 1, label: 'flag_same_day' },
	{ value: 2, label: 'flag_overdue' },
];
