/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable import/no-cycle */
import { ENDPOINT } from 'http/modules';

import React, { useEffect, useMemo, useRef, useState } from 'react';

import { Text } from '@react-native-material/core';
import en from 'assets/i18n/en';
import { Divider } from 'components/Atoms/Divider';
import { Icon } from 'components/Atoms/Icon';
import { ModalComponent } from 'components/Molecules/Modal';
import { Section } from 'components/Molecules/Section';
import { CalendarModal } from 'components/Organisms/CalendarModal';
import { SelectPicker } from 'components/Organisms/SelectPicker';
import { Option } from 'components/Organisms/SelectPicker/interfaces';
import { ICONS, COLORS } from 'config';
import { useForceUpdate } from 'hooks/useForceUpdate';
import useInfinity from 'hooks/useInfinity';
import {
	FlatList,
	Keyboard,
	KeyboardAvoidingView,
	Platform,
	ScrollView,
	TextInput,
	TouchableOpacity,
	View,
} from 'react-native';
import { ItemWorkflow } from 'screens/Apps/Containers';
import { ResourcetypeTask } from 'services/Tasks/types';
import { useAppSelector } from 'stores';
import dayjs from 'utils/dayjs';
import { translate } from 'utils/translate';

import { Flag, ModalTypes, ViewType } from './constant';
import { Props } from './interfaces';
import { Block, Container, DateWraper, Row, styles } from './styles';

interface WorkflowProps {
	Title: string;
	TitleEN: string;
	WorkflowID: number;
}

export type FilterValuesType = {
	viewType: Option;
	flag: Option;
	statusGroup: Option[];
	fromDate: Date;
	toDate: Date;
	workFlow: WorkflowProps;
};

export const TaskFilter: React.FC<Props> = ({ onApply, type, currentFilter, isFollow }) => {
	const forceUpdate = useForceUpdate();
	const { beanAppStatus, beanWorkflowStatus, settingSystem } = useAppSelector(state => state.system);
	const { language } = useAppSelector(state => state.dataNotRemove);

	const [keyWork, setKeyWord] = useState('');
	const [selectWf, setSelectWf] = useState({ Title: 'Tất cả', TitleEN: 'All', WorkflowID: 0 });

	const {
		state: { data: dataRes, refreshing },
		gotoFirstPage,
		refreshPage,
		fetchMore,
	} = useInfinity<Array<ItemWorkflow>>(`${ENDPOINT.WORKFLOW}`, {
		size: 10,
		requireAuthentication: true,
		params: {
			func: 'getOrSearchListWorkflow',
			flag: 0,
			data: `{"PerType": -1,"WorkflowCategoryId":"0","Keyword":${JSON.stringify(keyWork || '')}}`,
		},
	});

	useEffect(() => {
		gotoFirstPage();
	}, [keyWork]);

	const [isOpenModal, setOpenModal] = useState<boolean>(false);
	const [modalType, setModalType] = useState<ModalTypes | undefined>(undefined);

	const virtualFilterValues = useRef<FilterValuesType>(
		currentFilter || {
			viewType: ViewType[0],
			flag: Flag[0],
			statusGroup: [{ label: translate('flag_all'), value: 0, labelEN: 'All' }],
			fromDate: new Date(new Date().setDate(new Date().getDate() - 30)),
			toDate: new Date(),
			workFlow: { Title: 'Tất cả', TitleEN: 'All', WorkflowID: 0 },
		},
	);

	const dataFilterStatusGroup = useMemo(
		() =>
			beanAppStatus?.map(({ ID: value, TitleEN: labelEN, Title: labelVN }) => {
				return {
					value,
					label: language === 'vi' ? labelVN : labelEN,
					labelEN,
				};
			}) as Option[],
		[beanAppStatus, language],
	);

	const dataFilterStatusGroupWorkflow = useMemo(
		() =>
			beanAppStatus
				?.map(({ ID: value, TitleEN: labelEN, Title: labelVN }) => {
					if (settingSystem?.includes(value.toString())) {
						return {
							value,
							label: language === 'vi' ? labelVN : labelEN,
							labelEN,
						};
					}
				})
				.filter(data => data !== undefined) as Option[],
		[beanAppStatus, language],
	);

	const defaultData = type === 'FilterWorkflowItem' ? dataFilterStatusGroupWorkflow : dataFilterStatusGroup;

	const handleOpenModal = (value: ModalTypes) => {
		setModalType(value);
		setOpenModal(true);
	};

	const handleSelectViewType = (value: Option[]) => {
		setOpenModal(false);
		virtualFilterValues.current.viewType = value?.[0];
	};

	const handleSelectFlag = (value: Option[]) => {
		setOpenModal(false);
		virtualFilterValues.current.flag = value?.[0];
	};

	const handleSelectStatusGroup = (value: Option[]) => {
		setOpenModal(false);
		forceUpdate();
		virtualFilterValues.current.statusGroup = value;
	};

	const handleSelectDate = (value: Date) => {
		setOpenModal(false);
		if (modalType === ModalTypes.FROM_DATE) {
			virtualFilterValues.current.fromDate = value;
		} else {
			virtualFilterValues.current.toDate = value;
		}
	};

	const handleApply = () => {
		onApply(virtualFilterValues.current);
	};

	const handleReset = () => {
		const dataReset = {
			viewType: ViewType[0],
			flag: Flag[0],
			statusGroup: [{ label: translate('flag_all'), value: 0, labelEN: 'All' }],
			fromDate: new Date(new Date().setDate(new Date().getDate() - 30)),
			toDate: new Date(),
			workFlow: { Title: 'Tất cả', TitleEN: 'All', WorkflowID: 0 },
		};
		virtualFilterValues.current = dataReset;
		forceUpdate();
	};

	const isOpenModalDayByAndroid =
		Platform.OS === 'android' && (modalType === ModalTypes.FROM_DATE || modalType === ModalTypes.TO_DATE);

	const dataWorkFlow: Array<WorkflowProps> = [
		{ Title: 'Tất cả', WorkflowID: 0 },
		...(Array.isArray(dataRes) ? dataRes : []),
	];

	return (
		<KeyboardAvoidingView
			behavior={Platform.OS === 'ios' ? 'padding' : undefined}
			style={{ flex: 1, backgroundColor: COLORS.whiteSmoke }}>
			<ScrollView
				showsVerticalScrollIndicator={false}
				keyboardShouldPersistTaps="handled"
				onScrollBeginDrag={Keyboard.dismiss}
				contentContainerStyle={{ flexGrow: 1 }}>
				<Container>
					{type === ResourcetypeTask.MYTASK && (
						<Section
							onPress={() => handleOpenModal(ModalTypes.STATUS)}
							style={styles.filterSectionWithDivider}
							leading={<Icon src={ICONS.icBook} width={20} height={20} />}
							center={
								<Text style={{ fontSize: 14, fontWeight: '400' }} color={COLORS.davyGrey}>
									{translate('status')}
								</Text>
							}
							trailing={
								<Row>
									<Text style={{ fontSize: 14, fontWeight: '400', marginRight: 15 }} color={COLORS.black}>
										{translate(virtualFilterValues.current.viewType.label as keyof typeof en)}
									</Text>
									<Icon src={ICONS.icArrowRight} width={18} height={18} />
								</Row>
							}
						/>
					)}
					{type === 'FilterWorkflowItem' && (
						<Section
							onPress={() => handleOpenModal(ModalTypes.WOLKFLOW)}
							style={styles.filterSectionWithDivider}
							leading={<Icon src={ICONS.icWorkflow} width={20} height={20} />}
							center={
								<Text style={{ fontSize: 14, fontWeight: '400' }} color={COLORS.davyGrey}>
									Quy trình
								</Text>
							}
							trailing={
								<Row>
									<Text style={{ fontSize: 14, fontWeight: '400', marginRight: 15 }} color={COLORS.black}>
										{virtualFilterValues.current?.workFlow?.Title || ''}
									</Text>
									<Icon src={ICONS.icArrowRight} width={18} height={18} />
								</Row>
							}
						/>
					)}
					<Section
						onPress={() => handleOpenModal(ModalTypes.STATE)}
						style={styles.filterSectionWithDivider}
						leading={<Icon src={ICONS.icNote} width={20} height={20} />}
						center={
							<Text style={{ fontSize: 14, fontWeight: '400' }} color={COLORS.davyGrey}>
								{translate('state')}
							</Text>
						}
						trailing={
							<Row>
								<Text style={{ fontSize: 14, fontWeight: '400', marginRight: 15 }} color={COLORS.black}>
									{language === 'vi'
										? virtualFilterValues.current.statusGroup[0].label
										: (virtualFilterValues.current.statusGroup[0].labelEN as string)}
									{virtualFilterValues.current.statusGroup.length > 1
										? ` (+${virtualFilterValues.current.statusGroup.length - 1})`
										: ''}
								</Text>
								<Icon src={ICONS.icArrowRight} width={18} height={18} />
							</Row>
						}
					/>
					<Divider style={{ marginHorizontal: 15 }} />
					{!isFollow && type !== 'FilterWorkflowItem' && (
						<Section
							onPress={() => handleOpenModal(ModalTypes.DUA_DATE)}
							style={styles.filterSectionBase}
							leading={<Icon src={ICONS.icClock} width={20} height={20} />}
							center={
								<Text style={{ fontSize: 14, fontWeight: '400' }} color={COLORS.davyGrey}>
									{translate('dua_date')}
								</Text>
							}
							trailing={
								<Row>
									<Text style={{ fontSize: 14, fontWeight: '400', marginRight: 15 }} color={COLORS.black}>
										{translate(virtualFilterValues.current.flag.label as keyof typeof en)}
									</Text>
									<Icon src={ICONS.icArrowRight} width={18} height={18} />
								</Row>
							}
						/>
					)}
					<Section
						style={styles.filterSectionWithDivider}
						leading={<Icon src={ICONS.icCalendar} width={20} height={20} />}
						center={
							<Text style={{ fontSize: 14, fontWeight: '400' }} color={COLORS.davyGrey}>
								{translate('date_received')}
							</Text>
						}
					/>
					<Divider style={{ marginHorizontal: 15 }} />
					<Row style={{ justifyContent: 'space-between' }}>
						<View style={{ flex: 1, padding: 15 }}>
							<Text style={{ fontSize: 13, fontWeight: '400', marginBottom: 8 }} color={COLORS.spanishGray}>
								{translate('from_date')}
							</Text>

							<View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
								<Text style={{ fontSize: 15, fontWeight: '400' }} color={COLORS.black}>
									{dayjs(virtualFilterValues.current.fromDate).format('DD/MM/YY')}
								</Text>

								<Icon
									src={ICONS.icClock}
									width={20}
									height={20}
									onPress={() => handleOpenModal(ModalTypes.FROM_DATE)}
								/>
							</View>
						</View>
						<Divider type="vertical" />
						<View style={{ flex: 1, padding: 15 }}>
							<Text style={{ fontSize: 13, fontWeight: '400', marginBottom: 8 }} color={COLORS.spanishGray}>
								{translate('to_date')}
							</Text>
							<View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
								<Text style={{ fontSize: 15, fontWeight: '400' }} color={COLORS.black}>
									{dayjs(virtualFilterValues.current.toDate).format('DD/MM/YY')}
								</Text>
								<Icon src={ICONS.icClock} width={20} height={20} onPress={() => handleOpenModal(ModalTypes.TO_DATE)} />
							</View>
						</View>
					</Row>
					<Row
						style={{
							backgroundColor: COLORS.whiteSmoke,
							justifyContent: 'flex-end',
							paddingTop: 20,
							paddingRight: 15,
						}}>
						<Block onPress={handleReset} style={{ backgroundColor: COLORS.whiteSmoke }}>
							<Text style={{ fontStyle: 'italic', fontWeight: 'bold', fontSize: 12 }} color={COLORS.trueBlue}>
								{translate('filter_reset')}
							</Text>
						</Block>
						<Block onPress={handleApply}>
							<Text style={{ fontWeight: 'bold', fontSize: 12 }} color={COLORS.white}>
								{translate('filter_apply')}
							</Text>
						</Block>
					</Row>
				</Container>
			</ScrollView>
			{isOpenModal && (
				<CalendarModal
					headerTitle={translate(modalType as keyof typeof en)}
					footerTitle={translate('filter_apply')}
					pastScrollRange
					isVisible={
						(isOpenModal && modalType === ModalTypes.FROM_DATE) || (isOpenModal && modalType === ModalTypes.TO_DATE)
					}
					onClose={() => setOpenModal(false)}
					color={COLORS.trueBlue}
					defaultValue={
						modalType === ModalTypes.FROM_DATE
							? dayjs(virtualFilterValues.current.fromDate).format('YYYY-MM-DD')
							: dayjs(virtualFilterValues.current.toDate).format('YYYY-MM-DD')
					}
					onDateSelected={handleSelectDate}
					maxDate={
						modalType === ModalTypes.FROM_DATE ? new Date(virtualFilterValues.current.toDate).toDateString() : ''
					}
				/>
			)}
			<ModalComponent
				open={isOpenModalDayByAndroid ? false : isOpenModal}
				outsideClickCloseable
				visiblePosition="bottom"
				headerTitle={translate(modalType as keyof typeof en)}
				onClose={() => setOpenModal(false)}>
				{modalType === ModalTypes.STATUS && ViewType && (
					<SelectPicker
						options={ViewType}
						defaultValue={[virtualFilterValues.current.viewType]}
						onSelect={handleSelectViewType}
					/>
				)}
				{modalType === ModalTypes.STATE && (type === 'FilterWorkflowItem' ? beanWorkflowStatus : beanAppStatus) && (
					<SelectPicker
						isTranslate={false}
						isMultiple
						options={[{ label: translate('flag_all'), value: 0, labelEN: 'All' }, ...defaultData]}
						defaultValue={virtualFilterValues.current.statusGroup}
						onSelect={handleSelectStatusGroup}
					/>
				)}
				{modalType === ModalTypes.DUA_DATE && Flag && (
					<SelectPicker options={Flag} defaultValue={[virtualFilterValues.current.flag]} onSelect={handleSelectFlag} />
				)}
				{modalType === ModalTypes.WOLKFLOW && (
					<View style={{ height: 500 }}>
						<TextInput
							onChangeText={setKeyWord}
							placeholder="Tìm kiếm quy trình..."
							style={{ borderWidth: 0.8, height: 38, paddingHorizontal: 5, marginHorizontal: 10, borderRadius: 4 }}
						/>
						<FlatList
							contentContainerStyle={{ marginVertical: 10 }}
							data={dataWorkFlow}
							keyExtractor={(item, index) => index.toString()}
							renderItem={({ item }) => {
								const selected = selectWf?.WorkflowID === item?.WorkflowID;
								return (
									<TouchableOpacity
										style={{
											paddingVertical: 8,
											marginHorizontal: 12,
											backgroundColor: selected ? COLORS.platinumGray : COLORS.white,
											paddingHorizontal: 4,
										}}
										onPress={() => {
											setSelectWf(item);
											setOpenModal(false);
											virtualFilterValues.current.workFlow = item;
										}}>
										<Text style={{ textAlign: 'center' }}>{item?.Title}</Text>
									</TouchableOpacity>
								);
							}}
						/>
					</View>
				)}
			</ModalComponent>
		</KeyboardAvoidingView>
	);
};
