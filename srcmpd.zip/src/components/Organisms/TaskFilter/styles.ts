import { COLORS } from 'config';
import { StyleSheet } from 'react-native';
import styled from 'styled-components/native';

export const Container = styled.View<{ isRead?: boolean }>`
	flex: 1;
`;

export const Row = styled.View`
	flex-direction: row;
	align-items: center;
	background-color: ${COLORS.white};
`;

export const DateWraper = styled.TouchableOpacity`
	padding: 15px 15px;
	flex: 1;
`;

export const Block = styled.TouchableOpacity`
	padding: 10px;
	min-width: 100px;
	margin-left: 5px;
	justify-content: center;
	align-items: center;
	background-color: ${COLORS.trueBlue};
	border-radius: 2px;
`;

export const styles = StyleSheet.create({
	listContentContainer: {
		flexGrow: 1,
	},
	filterSectionWithDivider: {
		backgroundColor: COLORS.white,
		borderTopWidth: 20,
		borderTopColor: COLORS.whiteSmoke,
		paddingHorizontal: 15,
	},
	filterSectionBase: {
		backgroundColor: COLORS.white,
		paddingHorizontal: 15,
	},
});
