import { ResourcetypeTask } from 'services/Tasks/types';

// eslint-disable-next-line import/no-cycle
import { FilterValuesType } from '.';

export interface Props {
	title?: string;
	type?: ResourcetypeTask;
	viewType?: 2 | 4;
	currentFilter?: FilterValuesType;
	onApply: (values: FilterValuesType) => void;
	isFollow?: boolean;
}
