import { COLORS } from 'config';
import { StyleSheet } from 'react-native';
import styled from 'styled-components/native';

export const styles = StyleSheet.create({
	viewFooter: {
		backgroundColor: COLORS.white,
		shadowColor: COLORS.spaceCadet,
		shadowOffset: {
			width: 0,
			height: -8,
		},
		shadowOpacity: 0.08,
		shadowRadius: 5,
		elevation: 10,
		width: '100%',
		paddingHorizontal: 20,
		paddingVertical: 8,
	},
});

export const Container = styled.View`
	margin-right: -20px;
	margin-left: -20px;
`;

export const ViewDateTime = styled.View`
	padding: 0 20px;
`;
