export interface Props {
	maximumDate?: Date;
	defaultValue?: Date;
	mode?: 'date' | 'time';
	onApply?: (value: Date) => void;
	onCancel?: () => void;
}
