/* eslint-disable import/no-extraneous-dependencies */
import React, { useRef } from 'react';

import DateTimePicker from '@react-native-community/datetimepicker';
import { Button } from '@react-native-material/core';
import { COLORS } from 'config';
import { Appearance, View, Platform } from 'react-native';

import { Props } from './interfaces';
import { Container, ViewDateTime, styles } from './styles';

export const DatePicker: React.FC<Props> = ({ maximumDate, defaultValue, mode, onApply, onCancel }) => {
	const datetimeValue = useRef<Date>(defaultValue || new Date());

	const onChangeDateIOS = (_: Event, date?: Date) => {
		if (!date) return;
		datetimeValue.current = date;
	};

	const onApplyDateIOS = () => {
		onApply?.(datetimeValue.current);
	};

	const onChangeDateAndroid = (_: Event, date?: Date) => {
		if (!date) {
			onCancel?.();
			return;
		}
		datetimeValue.current = date;
		onApply?.(date);
	};

	return (
		<View>
			{Platform.OS === 'ios' ? (
				<Container>
					<ViewDateTime>
						<DateTimePicker
							value={datetimeValue.current}
							mode={mode || 'date'}
							display="spinner"
							themeVariant={Appearance.getColorScheme() === 'dark' ? 'dark' : 'light'}
							onChange={onChangeDateIOS}
							textColor="black"
							maximumDate={maximumDate}
						/>
					</ViewDateTime>
					<View style={styles.viewFooter}>
						<Button
							titleStyle={{ fontSize: 16, fontWeight: 'bold' }}
							title="ÁP DỤNG"
							style={{ backgroundColor: COLORS.trueBlue }}
							onPress={onApplyDateIOS}
						/>
					</View>
				</Container>
			) : (
				<DateTimePicker
					value={datetimeValue.current}
					mode={mode || 'date'}
					display="spinner"
					themeVariant={Appearance.getColorScheme() === 'dark' ? 'dark' : 'light'}
					onChange={() => onChangeDateAndroid}
					maximumDate={maximumDate}
				/>
			)}
		</View>
	);
};
