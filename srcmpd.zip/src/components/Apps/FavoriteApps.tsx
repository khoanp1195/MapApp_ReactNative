/* eslint-disable react-hooks/exhaustive-deps */
import { ENDPOINT } from 'http/modules';

import React, { useEffect, useState } from 'react';

import { useIsFocused } from '@react-navigation/native';
import { ShowLoading } from 'components/Atoms/Loading/LoadingGlobal';
import ItemFavorite from 'components/Organisms/ItemFavorite/ItemFavorite';
import { STATUS_TAKS } from 'components/TaskScreens/consts/consts';
import { COLORS } from 'config/colors';
import useInfinity from 'hooks/useInfinity';
import { navigate } from 'navigation/RootNavigation';
import { BottomNavigationRoutesNames } from 'navigation/RoutesNames';
import { View, FlatList, RefreshControl, Text } from 'react-native';
import { ParamsProps } from 'screens/Apps/Containers';
import { useAppDispatch } from 'stores';
import { setFavoriteApps, updateWorkflowsApps } from 'stores/Apps/reducer';
import { fetchFavorite } from 'stores/Apps/thunks';
import { fetchCount } from 'stores/Count/thunks';
import { IItemFavorite, updateFavoriteHome } from 'stores/Home';
import { translate } from 'utils/translate';

const FavoriteApps = (props: { onUpdateFavoriteAllApps: (arg0: IItemFavorite, flag: number) => void }) => {
	const { onUpdateFavoriteAllApps = () => { } } = props;
	const dispatch = useAppDispatch();
	const isFocus = useIsFocused();
	const [loading, setLoading] = useState(false);
	const [data, setData] = useState<IItemFavorite[]>([]);
	const {
		state: { data: dataRes, refreshing, loading: loadingApi },
		gotoFirstPage,
		refreshPage,
		fetchMore,
	} = useInfinity<IItemFavorite[]>(`${ENDPOINT.WORKFLOW}`, {
		size: 100,
		requireAuthentication: true,
		params: {
			func: 'getOrSearchListWorkflow',
			flag: 1,
			data: `{"PerType": -1,"WorkflowCategoryId":0}`,
		},
	});

	useEffect(() => {
		if (isFocus) {
			gotoFirstPage();
		}
	}, [isFocus]);

	const success = async (res: { status: string }, item: IItemFavorite, flag: number) => {
		if (res?.status === 'SUCCESS') {
			await Promise.allSettled([
				dispatch(updateFavoriteHome({ ...item, isDelete: true })),
				onUpdateFavoriteAllApps(item, flag),
				setData(data.filter(e => e.WorkflowID !== item.WorkflowID)),
			]);
			setLoading(false);
			ShowLoading(false);
		} else {
			setLoading(false);
			ShowLoading(false);
		}
	};

	const handFavorite = (params: ParamsProps, item: IItemFavorite) => {
		if (data?.length && !loading && !loadingApi) {
			setLoading(true);
			ShowLoading(true);
			dispatch(
				setFavoriteApps({
					params,
					success: (res: { status: string }) => success(res, item, params.flag),
					failed: () => {
						setLoading(false);
						ShowLoading(false);
					},
				}),
			);
		}
	};

	useEffect(() => {
		setData(dataRes);
		if (dataRes?.length) {
			fetchMore();
		}
	}, [dataRes]);

	const handleEndReached = () => {
		// fetchMore();
	};

	const onPressItem = item => {
		dispatch(fetchCount({ WorkflowId: item?.WorkflowID || 0 }));
		dispatch(updateWorkflowsApps(item));
		navigate(BottomNavigationRoutesNames.TaskScreen, {
			screen: 'myTask',
			toMyTask: STATUS_TAKS.PROCESSING,
		});
	};

	const ListFooter = () => <View style={{ height: 100 }} />;

	return (
		<View style={{ paddingHorizontal: 24, flex: 1 }}>
			{data?.length ? (
				<FlatList
					style={{ paddingTop: 20, flex: 1 }}
					data={data}
					keyExtractor={(item, index) => index.toString()}
					renderItem={({ item, index }) => {
						return (
							<ItemFavorite
								item={item}
								index={index}
								useBookmark
								handFavorite={handFavorite}
								onPressItem={onPressItem}
							/>
						);
					}}
					onEndReached={handleEndReached}
					onEndReachedThreshold={0.1}
					refreshControl={
						<RefreshControl refreshing={refreshing} onRefresh={refreshPage} tintColor={COLORS.trueBlue} />
					}
					showsVerticalScrollIndicator={false}
					ListFooterComponent={<ListFooter />}
					maxToRenderPerBatch={10}
					initialNumToRender={10}
				/>
			) : (
				<View style={{ alignItems: 'center', marginTop: 20 }}>
					<Text style={{ fontStyle: 'italic', color: COLORS.textGrey }}>{translate('favoriteApps')}</Text>
				</View>
			)}
		</View>
	);
};

export default FavoriteApps;
