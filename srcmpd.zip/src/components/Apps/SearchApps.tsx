/* eslint-disable react-hooks/exhaustive-deps */
import { ENDPOINT } from 'http/modules';

import React, { useEffect, useState } from 'react';

import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import ItemFavorite from 'components/Organisms/ItemFavorite/ItemFavorite';
import { STATUS_TAKS } from 'components/TaskScreens/consts/consts';
import { COLORS } from 'config';
import { ICONS } from 'config/images';
import useDebounce from 'hooks/useDebounce';
import useInfinity from 'hooks/useInfinity';
import { navigate } from 'navigation/RootNavigation';
import { BottomNavigationRoutesNames, RoutesNames } from 'navigation/RoutesNames';
import { TextInput, View, FlatList, LayoutAnimation, RefreshControl, Text } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ParamsProps } from 'screens/Apps/Containers';
import { useAppDispatch } from 'stores';
import { updateWorkflowsApps } from 'stores/Apps/reducer';
import { fetchFavorite } from 'stores/Apps/thunks';
import { fetchCount } from 'stores/Count/thunks';
import { IItemFavorite, updateFavoriteHome } from 'stores/Home/reducer';
import { translate } from 'utils/translate';

type Params = {
	Item: {
		onUpdateFavoriteAllApps?: (item: IItemFavorite, flag: number) => void;
		isCreateWorkflow?: boolean;
	};
};

const SearchApps = () => {
	const insets = useSafeAreaInsets();
	const navigation = useNavigation();
	const dispatch = useAppDispatch();
	const route = useRoute<RouteProp<Params, 'Item'>>();

	const { onUpdateFavoriteAllApps, isCreateWorkflow = false } = route.params || {};

	const [data, setData] = useState<IItemFavorite[]>();
	const [keyword, setKeyword] = useState<string>('');

	const debounceSearch = useDebounce(keyword, 300);

	const {
		state: { data: dataRes, refreshing, loading },
		gotoFirstPage,
		refreshPage,
		fetchMore,
	} = useInfinity<IItemFavorite[]>(`${ENDPOINT.WORKFLOW}`, {
		size: 10,
		requireAuthentication: true,
		params: {
			func: 'getOrSearchListWorkflow',
			flag: keyword?.length ? 0 : 3,
			data: `{"PerType":${isCreateWorkflow ? 0 : -1},"WorkflowCategoryId":0,"Keyword":${JSON.stringify(
				keyword || '',
			)}}`,
		},
	});

	useEffect(() => {
		if (dataRes) {
			setData(dataRes || []);
		}
	}, [dataRes]);

	useEffect(() => {
		gotoFirstPage();
	}, [debounceSearch]);

	const success = (res: { data: { status: string } }, item: IItemFavorite, flag: number) => {
		if (res?.data?.status === 'SUCCESS') {
			dispatch(updateFavoriteHome({ ...item, isDelete: !flag }));
			if (onUpdateFavoriteAllApps) {
				onUpdateFavoriteAllApps(item, flag);
			}
		}
	};

	const handFavorite = (params: ParamsProps, item: IItemFavorite) => {
		const cloneData: IItemFavorite[] = [...(data || [])];
		const indexFlag = cloneData.findIndex(e => e.WorkflowID === item.WorkflowID);

		if (indexFlag !== -1) {
			cloneData[indexFlag].IsFavor = params.flag;
			setData(cloneData);
			dispatch(fetchFavorite({ ...params, success: data => success(data, item, params.flag) }));
		}
	};

	const handleEndReached = () => {
		if (keyword?.length) {
			fetchMore();
		}
	};

	const onPressItem = item => {
		if (!isCreateWorkflow) {
			dispatch(fetchCount({ WorkflowId: item?.WorkflowID || 0 }));
			dispatch(updateWorkflowsApps(item));
			navigate(BottomNavigationRoutesNames.TaskScreen, {
				screen: 'myTask',
				toMyTask: STATUS_TAKS.PROCESSING,
			});
		} else {
			navigate(RoutesNames.AddWorkflow, { item, isFromSearch: true });
		}
	};

	return (
		<View style={{ flex: 1, backgroundColor: 'white' }}>
			<View
				style={{
					flexDirection: 'row',
					alignItems: 'center',
					shadowColor: '#000',
					shadowOffset: {
						width: 0,
						height: 0.5,
					},
					shadowOpacity: 0.1,
					shadowRadius: 4,
					elevation: 5,
					zIndex: 99,
					backgroundColor: 'white',
					height: 94,
					paddingTop: insets.top,
					paddingBottom: 12,
					paddingHorizontal: 24,
				}}>
				<Icon src={ICONS.icArrowMenu} width={24} height={24} onPress={() => navigation.goBack()} />
				<TextInput
					style={{ flex: 1, marginLeft: 12 }}
					placeholder={translate('searchButton')}
					onChangeText={setKeyword}
					autoFocus
				/>
			</View>
			{keyword?.length > 2 && !dataRes?.length && !loading && (
				<Text
					style={{
						fontSize: 14,
						fontWeight: '400',
						color: COLORS.textGrey,
						fontStyle: 'italic',
						textAlign: 'center',
						marginTop: 10,
					}}>
					{translate('noResult')}
				</Text>
			)}

			{!keyword?.length && (
				<View style={{ marginHorizontal: 16, marginVertical: 10 }}>
					<Text style={{ fontSize: 16, fontWeight: '600' }}>{translate('recentlySelected')}</Text>
				</View>
			)}
			{data?.length ? (
				<View style={{ paddingHorizontal: 24, flex: 1 }}>
					<FlatList
						style={{ flex: 1 }}
						data={data}
						keyExtractor={(item, index) => index?.toString()}
						renderItem={({ item, index }) => (
							<ItemFavorite
								item={item}
								useBookmark={!isCreateWorkflow}
								handFavorite={handFavorite}
								index={index}
								onPressItem={onPressItem}
							/>
						)}
						showsVerticalScrollIndicator={false}
						onEndReached={handleEndReached}
						onEndReachedThreshold={0.1}
						refreshControl={
							<RefreshControl refreshing={refreshing} onRefresh={refreshPage} tintColor={COLORS.trueBlue} />
						}
						ListFooterComponent={() => <View style={{ height: 100 }} />}
					/>
				</View>
			) : (
				<View style={{ marginTop: 20, paddingHorizontal: 24 }}>
					{/* <Text style={{ fontSize: 16, fontWeight: '700' }}>{translate('last_access')}</Text> */}
				</View>
			)}
		</View>
	);
};
export default SearchApps;
