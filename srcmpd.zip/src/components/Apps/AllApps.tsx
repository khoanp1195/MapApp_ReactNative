/* eslint-disable react/no-unstable-nested-components */
/* eslint-disable react-hooks/exhaustive-deps */
import { ENDPOINT } from 'http/modules';

import React, { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';

import { useIsFocused } from '@react-navigation/native';
import ItemFavorite from 'components/Organisms/ItemFavorite/ItemFavorite';
import { STATUS_TAKS } from 'components/TaskScreens/consts/consts';
import { COLORS } from 'config';
import useInfinity from 'hooks/useInfinity';
import { navigate } from 'navigation/RootNavigation';
import { BottomNavigationRoutesNames } from 'navigation/RoutesNames';
import { Text, TouchableOpacity, View, SectionList, RefreshControl, ActivityIndicator } from 'react-native';
import { ParamsProps } from 'screens/Apps/Containers';
import { useAppDispatch } from 'stores';
import { updateWorkflowsApps } from 'stores/Apps/reducer';
import { fetchFavorite } from 'stores/Apps/thunks';
import { fetchCount } from 'stores/Count';
import { IItemFavorite, updateFavoriteHome } from 'stores/Home/reducer';

export interface IDataApps {
	WorkflowCategoryID: number;
	title: any;
	data: IItemFavorite[];
}

const AllApps = (_: unknown, ref: React.Ref<unknown> | undefined) => {
	const dispatch = useAppDispatch();
	const [data, setData] = useState(Array<IDataApps>);
	const [indexHide, setIndexHide] = useState<number[]>([]);
	const isFocus = useIsFocused();
	const [startMore, setStartMore] = useState(false);
	const [startMoreData, setStartMoreData] = useState(false);

	const refData = useRef<number>(0);
	const refLengthData = useRef(0);

	const handleFovorite = (item: IItemFavorite, flag: number) => {
		const indexCategoryID = data?.findIndex(e => e.WorkflowCategoryID === item.WorkflowCategoryID);

		if ((indexCategoryID && indexCategoryID !== -1) || indexCategoryID === 0) {
			const indexItem = data?.[indexCategoryID]?.data?.findIndex(e => e.WorkflowID === item.WorkflowID);

			const list: Array<IDataApps> = [...data];

			list[indexCategoryID].data[indexItem] = {
				...list[indexCategoryID].data[indexItem],
				IsFavor: flag,
			};

			setData(list);
		}
	};

	useImperativeHandle(
		ref,
		() => ({
			handleFovorite,
		}),
		[data],
	);

	useEffect(() => {
		setIndexHide([]);
	}, [isFocus]);

	const {
		state: { data: dataRes, refreshing, loading },
		gotoFirstPage,
		refreshPage,
		fetchMore,
	} = useInfinity<Array<IItemFavorite>>(`${ENDPOINT.WORKFLOW}`, {
		size: 10,
		requireAuthentication: true,
		params: {
			func: 'getOrSearchListWorkflow',
			flag: 0,
			data: `{"PerType": -1,"WorkflowCategoryId":0}`,
		},
	});

	useEffect(() => {
		gotoFirstPage();
	}, []);

	useEffect(() => {
		let list: IDataApps[] = [...(data || [])];
		// eslint-disable-next-line array-callback-return
		const clone = [...(dataRes || [])];
		const dataEnd = clone?.splice(refData.current, clone?.length);

		dataEnd?.map((e: IItemFavorite) => {
			const findIndex = list.findIndex((x: IDataApps) => {
				return x.WorkflowCategoryID === e.WorkflowCategoryID;
			});
			if (findIndex !== -1) {
				list[findIndex].data = list[findIndex].data?.concat(e);
			} else {
				list = [
					...list,
					{
						WorkflowCategoryID: e.WorkflowCategoryID,
						title: e.WorkflowCategory,
						data: [e],
					},
				];
			}
		});

		refData.current = dataRes?.length || 0;

		setData(list);
	}, [dataRes]);

	const handleEndReached = () => {
		fetchMore();
	};

	const success = (res: { data: { status: string } }, item: IItemFavorite, flag: number) => {
		if (res?.data?.status === 'SUCCESS') {
			dispatch(updateFavoriteHome({ ...item, isDelete: !flag }));
		}
	};

	const handFavorite = (params: ParamsProps, item: IItemFavorite) => {
		const indexCategoryID = data.findIndex(e => e.WorkflowCategoryID === params.WorkflowCategoryID);

		const indexItem = data?.[indexCategoryID]?.data?.findIndex(e => e.WorkflowID === params.id);

		const list: IDataApps[] = [...data];

		list[indexCategoryID].data[indexItem] = { ...list[indexCategoryID].data[indexItem], IsFavor: params.flag };

		setData(list);

		dispatch(fetchFavorite({ ...params, success: data => success(data, item, params.flag) }));
	};

	const onPressItem = item => {
		dispatch(fetchCount({ WorkflowId: item?.WorkflowID || 0 }));
		dispatch(updateWorkflowsApps(item));
		navigate(BottomNavigationRoutesNames.TaskScreen, {
			screen: 'myTask',
			toMyTask: STATUS_TAKS.PROCESSING,
		});
	};

	useEffect(() => {
		if (startMore && data?.length < 2 && !startMoreData) {
			fetchMore();
		}
		if (data?.length > 1) {
			setStartMore(false);
		}
	}, [startMore, data]);

	useEffect(() => {
		if (startMoreData && refLengthData.current === data?.length) {
			fetchMore();
		}
		if (refLengthData.current !== data?.length) {
			setStartMore(false);
		}
		refLengthData.current = data?.length;
	}, [startMoreData, data]);

	const ListFooter = () => (
		<View style={{ height: 100 }}>{loading && !refreshing && <ActivityIndicator size="small" />}</View>
	);

	const handleRefreshPage = () => {
		refData.current = 0;
		refLengthData.current = 0;
		setData([]);
		setIndexHide([]);
		refreshPage();
	};

	return (
		<View style={{ paddingHorizontal: 24 }}>
			<SectionList
				style={{}}
				showsVerticalScrollIndicator={false}
				sections={data}
				keyExtractor={(item, index) => index.toString()}
				renderItem={({ item, index }) => {
					const isHideItem = indexHide.includes(item.WorkflowCategoryID);
					if (isHideItem) return null;
					return (
						<ItemFavorite item={item} index={index} useBookmark handFavorite={handFavorite} onPressItem={onPressItem} />
					);
				}}
				renderSectionHeader={({ section }) => {
					return (
						<TouchableOpacity
							activeOpacity={1}
							style={{ paddingVertical: 20, backgroundColor: 'white' }}
							onPress={() => {
								if (data?.length < 2) {
									setStartMore(true);
								}
								if (indexHide.includes(section.WorkflowCategoryID)) {
									setIndexHide(indexHide.filter(e => e !== section.WorkflowCategoryID));
								} else {
									setIndexHide([...indexHide, section.WorkflowCategoryID]);
									setStartMoreData(true);
								}
							}}>
							<Text numberOfLines={2} style={{ fontSize: 16, fontWeight: '700' }}>
								{section?.title || 'Other'}
							</Text>
						</TouchableOpacity>
					);
				}}
				onEndReached={handleEndReached}
				onEndReachedThreshold={0.1}
				ListFooterComponent={<ListFooter />}
				refreshControl={
					<RefreshControl refreshing={refreshing} onRefresh={handleRefreshPage} tintColor={COLORS.trueBlue} />
				}
				stickySectionHeadersEnabled={false}
			/>
		</View>
	);
};

export default forwardRef(AllApps);
