/* eslint-disable @typescript-eslint/no-unsafe-argument */
import React, { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';

import { MaterialTopTabBarProps } from '@react-navigation/material-top-tabs';
import { useNavigation } from '@react-navigation/native';
import { navigate } from 'navigation/RootNavigation';
import { Text, TouchableOpacity, View, Animated, LayoutAnimation, Dimensions } from 'react-native';
import { FlatList } from 'react-native-gesture-handler';
import { useAppSelector } from 'stores';
import { translate } from 'utils/translate';

const windowWidth = Dimensions.get('window').width;

const TabbarApps = (props: MaterialTopTabBarProps) => {
	const { state, translateValue, navigation } = props || {};
	const { index, routes = [] } = state || {};

	useEffect(() => {
		Animated.spring(translateValue, {
			toValue: (index * windowWidth) / 2,
			useNativeDriver: true,
		}).start();
	}, [index]);

	return (
		<View
			style={{
				shadowColor: '#000',
				shadowOffset: {
					width: 0,
					height: 1,
				},
				shadowOpacity: 0.1,
				shadowRadius: 5,
				elevation: 10,
				zIndex: 99,
				backgroundColor: 'white',
			}}>
			<View style={{ flexDirection: 'row', backgroundColor: 'white' }}>
				{routes.map((item, key) => {
					const isSelect = index === key;
					return (
						<TouchableOpacity
							key={key?.toString()}
							style={{ flex: 1, paddingBottom: 4 }}
							onPress={() => {
								const event = navigation.emit({
									type: 'tabPress',
									target: item.key,
									canPreventDefault: true,
								});

								if (!event.defaultPrevented) {
									navigate(item.name);
								}
							}}>
							<Text
								style={{
									textAlign: 'center',
									fontSize: 12,
									fontWeight: isSelect ? '700' : '400',
									color: isSelect ? 'rgba(0, 95, 212, 1)' : 'black',
									lineHeight: 26,
								}}>
								{translate(item.name)}
							</Text>
						</TouchableOpacity>
					);
				})}
			</View>
			<Animated.View
				style={{
					position: 'absolute',
					width: windowWidth / 2,
					backgroundColor: 'rgba(0, 95, 212, 1)',
					bottom: 0,
					transform: [{ translateX: translateValue }],
					borderTopLeftRadius: 4,
					borderTopRightRadius: 4,
					height: 4,
				}}
			/>
		</View>
	);
};

export default TabbarApps;
