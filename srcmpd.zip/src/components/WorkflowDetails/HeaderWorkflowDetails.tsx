import React, { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';

import { useNavigation } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { refDropDown } from 'components/Atoms/Loading/DropDown';
import { ICONS } from 'config/images';
import { RoutesNames } from 'navigation/RoutesNames';
import { View, Text, Animated, Easing, TouchableOpacity } from 'react-native';
import { IItemParams } from 'screens/WorkflowDetails/WorkflowDetails';
import { useAppDispatch, useAppSelector } from 'stores';
import { fetchCount } from 'stores/Count';
import { postFollowWorkflow } from 'stores/Workflows/sliceWorkflow';
import { translate } from 'utils/translate';

const RenderLeading = ({
	opacity,
	itemPrams,
	translateY,
}: {
	opacity: any;
	itemPrams: IItemParams;
	translateY: any;
}) => {
	const navigation = useNavigation();

	return (
		<View style={{ alignItems: 'center', justifyContent: 'center', flexDirection: 'row', flex: 1 }}>
			<Icon
				src={ICONS.icArrowMenu}
				width={24}
				height={24}
				tintColor="rgba(0, 0, 0, 1)"
				onPress={() => navigation.goBack()}
			/>
			<Animated.Text
				numberOfLines={1}
				style={{
					fontSize: 16,
					fontWeight: '700',
					marginHorizontal: 8,
					flex: 1,
					opacity,
					transform: [{ translateY }],
				}}>
				{itemPrams?.Content}
			</Animated.Text>
		</View>
	);
};

const RenderTraling = ({
	itemPrams,
	onShowToast,
}: {
	itemPrams: IItemParams;
	onShowToast: (data: { status: number; message: string }) => void;
}) => {
	const dispatch = useAppDispatch();
	const navigation = useNavigation();
	const refPosition = useRef({});
	const { details } = useAppSelector(store => store.workflow);

	const IsFollowed = details?.FormConfig?.IsFollowed;

	const [isFollowed, setIsFollowed] = useState(false);

	const success = () => {
		setIsFollowed(!isFollowed);
		dispatch(fetchCount({ countType: 4 }));
		onShowToast({
			status: isFollowed ? 1 : 2,
			message: isFollowed ? translate('unfollowSuccessfully') : translate('followSuccessfully'),
		});
	};

	const onPressFollow = () => {
		dispatch(
			postFollowWorkflow({
				params: {
					rid: JSON.stringify(itemPrams?.ID),
					flag: isFollowed ? 0 : 1,
				},
				success,
			}),
		);
	};

	const handleAction = (name: string) => {
		refDropDown.current?.hide();
		// navigation.navigate(RoutesNames.TaskHistory, { ID })

		switch (name) {
			case 'transfer':
				return navigation.navigate(RoutesNames.WorkflowHistory, { ID: itemPrams?.ID, Content: itemPrams?.Content });
			case 'pEForm':
				return onPressFollow();
			case 'pForm':
				return onPressFollow();
			case 'share':
				return navigation.navigate(RoutesNames.ShareWorkflow, { ID: itemPrams?.ID, Content: itemPrams?.Content });
			case 'follow':
				return onPressFollow();

			default:
				return null;
		}
	};

	useEffect(() => {
		setIsFollowed(IsFollowed);
	}, [IsFollowed]);

	const getIcon = (name: string) => {
		switch (name) {
			case 'transfer':
				return ICONS.icTransfer;
			case 'pEForm':
				return ICONS.icCollection;
			case 'pForm':
				return ICONS.icInvoice;
			case 'share':
				return ICONS.icShare;
			case 'follow':
				return !isFollowed ? ICONS.icStar : ICONS.icUnStar;

			default:
				return ICONS.icTransfer;
		}
	};

	const getname = (name: string) => {
		switch (name) {
			case 'transfer':
				return translate('transfer');
			case 'pEForm':
				return translate('pEForm');
			case 'pForm':
				return translate('pForm');
			case 'share':
				return translate('share');
			case 'follow':
				return !isFollowed ? translate('follow') : translate('unfollow');

			default:
				return translate('transfer');
		}
	};

	const button = ['transfer', 'share', 'follow'];

	return (
		<View style={{ flexDirection: 'row', alignItems: 'center', paddingBottom: 10 }}>
			<Icon
				src={ICONS.icShare}
				width={20}
				height={20}
				tintColor="rgba(0, 0, 0, 1)"
				onPress={() =>
					navigation.navigate(RoutesNames.ShareWorkflow, { ID: itemPrams?.ID, Content: itemPrams?.Content })
				}
			/>
			<Icon
				src={ICONS.icTransfer}
				width={22}
				height={22}
				tintColor="rgba(0, 0, 0, 1)"
				style={{ marginHorizontal: 20 }}
				onPress={() =>
					navigation.navigate(RoutesNames.WorkflowHistory, { ID: itemPrams?.ID, Content: itemPrams?.Content })
				}
			/>

			<View ref={refPosition}>
				<Icon
					src={ICONS.icMoreVertical}
					width={28}
					height={28}
					tintColor="rgba(0, 0, 0, 1)"
					onPress={event => {
						event.target.measure((x, y, width, height, pageX, pageY) => {
							refDropDown.current?.show(
								{
									top: pageY,
									left: pageX,
									heightItem: 90,
								},
								<View style={{ overflow: 'hidden' }}>
									{button.map((item: string, index: number) => {
										return (
											<TouchableOpacity
												onPress={() => {
													handleAction(item);
												}}
												key={index?.toString()}
												style={{
													marginVertical: 5,
													flexDirection: 'row',
													alignItems: 'center',
													height: 30,
													paddingLeft: 16,
													borderBottomWidth: index === 0 ? 0.8 : 0,
													borderBottomColor: 'rgba(238, 238, 238, 1)',
												}}>
												<Icon
													src={getIcon(item)}
													width={24}
													height={24}
													tintColor="rgba(0, 0, 0, 1)"
													style={{ marginRight: 6 }}
												/>
												<Text>{getname(item)}</Text>
											</TouchableOpacity>
										);
									})}
								</View>,
							);
						});
					}}
				/>
			</View>
		</View>
	);
};

const HeaderWorkflowDetails = (
	{
		itemPrams,
		onShowToast,
	}: { itemPrams: IItemParams; onShowToast: (data: { status: number; message: string }) => void },
	ref: React.Ref<unknown> | undefined,
) => {
	const scrollY = useRef(new Animated.Value(0)).current;

	const ScrollY = (y: number) => {
		Animated.timing(scrollY, { toValue: y, duration: 0, easing: Easing.ease, useNativeDriver: true }).start();
	};

	const opacity = scrollY.interpolate({
		inputRange: [0, 120], // Adjust the input range as needed
		outputRange: [0, 1], // Adjust the output range as needed
		extrapolate: 'clamp',
	});

	const translateY = scrollY.interpolate({
		inputRange: [0, 120], // Adjust the input range as needed
		outputRange: [29, 0], // Adjust the output range as needed
		extrapolate: 'clamp',
	});

	useImperativeHandle(
		ref,
		() => ({
			ScrollY,
		}),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[],
	);

	return (
		<View
			style={{
				flexDirection: 'row',
				overflow: 'hidden',
				paddingHorizontal: 16,
				// paddingVertical: 5,
			}}
			shouldRasterizeIOS
			renderToHardwareTextureAndroid>
			<RenderLeading opacity={opacity} itemPrams={itemPrams} translateY={translateY} />
			<RenderTraling itemPrams={itemPrams} onShowToast={onShowToast} />
		</View>
	);
};

export default forwardRef(HeaderWorkflowDetails);
