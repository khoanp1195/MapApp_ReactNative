/* eslint-disable array-callback-return */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable no-unsafe-optional-chaining */
/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable no-underscore-dangle */
import React, { useState, useEffect, forwardRef, useRef, useImperativeHandle } from 'react';

import { Icon } from 'components/Atoms/Icon';
import { COLORS, ICONS } from 'config';
import useSystem from 'hooks/useSystem';
import { navigate } from 'navigation/RootNavigation';
import { View, Text, TouchableOpacity, ScrollView, Dimensions } from 'react-native';
import Calculated from 'screens/TaskDetail/Field/Calculated';
import Choose from 'screens/TaskDetail/Field/Choose';
import Currency from 'screens/TaskDetail/Field/Currency';
import DateTime from 'screens/TaskDetail/Field/DateTime';
import { IField, OptionField } from 'screens/TaskDetail/Field/InterfaceField';
import Lookup from 'screens/TaskDetail/Field/Lookup';
import LookupDataSource from 'screens/TaskDetail/Field/LookupDataSource';
import MultipleLines from 'screens/TaskDetail/Field/MultipleLines';
import NumberField from 'screens/TaskDetail/Field/Number';
import Radio from 'screens/TaskDetail/Field/Radio';
import SingleLine from 'screens/TaskDetail/Field/SingleLine';
import UserGroup from 'screens/TaskDetail/Field/UserGroup';
import { usePermisstionEditGrid } from 'screens/TaskDetail/useHooks/usePermissionEdit';
import { IItemParams } from 'screens/WorkflowDetails/WorkflowDetails';
import { useAppDispatch } from 'stores';
import { fetchGirdDetails } from 'stores/TaskDetails/thunks';
import { getFormGirdDetails, updateValueInternalName } from 'stores/Workflows/sliceWorkflow';
import { exportFieldTypeIdWithFTypeId } from 'utils/functions';
import { translate } from 'utils/translate';
import { vtUtility } from 'vtUtility/vtUtility';

const GridPreview = (
	{ title, internalName, ID, SPItemId, forms, options, isRequired, itemPrams }: IField,
	ref: React.Ref<unknown> | undefined,
) => {
	const dispatch = useAppDispatch();
	const option: OptionField = JSON.parse(options || '{}');
	const { Require } = option;
	const refDefaultData = useRef<any[]>([]);

	const ExecuteJS = option?.ExecuteJS;

	const IsRequire = Require || !!isRequired;

	const windowWidth = Dimensions.get('window').width;

	const { isPermissionEdit: isPermission } = usePermisstionEditGrid(
		internalName?.replace('_17_', '')?.replace('_Mobile', ''),
	);
	const isAddNew = !ID;

	const isPermissionEdit = isAddNew || isPermission;

	const [header, setHeader] = useState<string[]>([]);
	const [loading, setLoading] = useState(false);
	const [data, setData] = useState<any[]>([]);
	const [listField, setListField] = useState<any[]>([]);
	const [detailsListInfo, setDetailsListInfo] = useState<any>({});
	const [detailsFieldInfoCollection, setDetailsFieldInfoCollection] = useState({});
	const [error, setError] = useState(false);
	const refItemParams = useRef<IItemParams | null>();
	const refIDIsAdd = useRef<number[]>([]);
	const refEdit = useRef<{ _ID_: number; ActionType: number; value?: any[] }[]>([]);
	const { lid } = useSystem();

	const successCallback = (res: { data: { FormFieldInfo: any[] } }) => {
		const { FormFieldInfo } = res.data;
		setListField(FormFieldInfo);
	};

	const getToTalValue = (index: number) => {
		let total = 0;
		data?.map(item => {
			total += Number(Object.values(item)[index]?.replace('float;#', ''));
		});
		return Number(total);
	};

	useEffect(() => {
		try {
			const arrExecuteJS = ExecuteJS.replace('vtUtility.', '').replace(');', '').split('(');
			const funcName = arrExecuteJS[0] as 'onCalculatorUpdateTotalMasterEffect';
			let valueControl = 0;
			if (funcName === 'onCalculatorUpdateTotalMasterEffect') {
				const params = arrExecuteJS[1];
				const arrParams = params.replaceAll('"', '').split(',');
				const index = listField?.findIndex(item => {
					return item.Name === arrParams[1]?.trim();
				});
				valueControl = getToTalValue(index + 1);
				const callFunction = vtUtility[funcName](valueControl, arrExecuteJS);
				if (callFunction) {
					dispatch(callFunction.function({ ...callFunction.value }));
				}
			}
		} catch (err) {
			//
		}
	}, [data, listField]);

	useEffect(() => {
		if (detailsListInfo?.listID && !ID) {
			dispatch(
				getFormGirdDetails({
					params: {
						listid: detailsListInfo?.listID,
						wid: detailsListInfo?.WorkflowId || 0,
						lid,
						flag: 1,
						detailsListInfo,
						detailsFieldInfoCollection,
					},
					success: successCallback,
				}),
			);
		}
	}, [detailsListInfo]);

	const checkRequire = () => {
		if (!!IsRequire && !data?.length) {
			setError(true);
			return false;
		}
		return true;
	};

	const getGrid = () => {
		if (refEdit.current.length) return { isGrid: true, value: refEdit.current };
		return { isGrid: true, value: '' };
	};

	useEffect(() => {
		if (Object.keys(itemPrams || {}).length) {
			refItemParams.current = itemPrams;
		}
	}, [itemPrams]);

	const success = (res: { data: { data: { Data: any[]; ListField: any[] } } }) => {
		setLoading(false);
		setData(res?.data?.data?.Data);
		refDefaultData.current = res?.data?.data?.Data || [];
		setListField(res?.data?.data?.ListField);
	};

	const getDataGrid = () => {
		refEdit.current = [];
		refIDIsAdd.current = [];
		const formsData: { detailsTableInfoCollection: any[] }[] = JSON.parse(
			forms?.InfoCollection?.FormDefineInfo || '[]',
		);
		const formFromName: { detailsFieldInfoCollection: any[]; detailsListInfo: any } =
			formsData?.[0]?.detailsTableInfoCollection?.find(
				(res: { masterFieldInfo: { internalName: string } }) =>
					res?.masterFieldInfo?.internalName === internalName?.replace('_17_', '')?.replace('_Mobile', ''),
			);

		let listHeader: string[] = [];
		let _internalName: any[] = [];
		formFromName?.detailsFieldInfoCollection?.forEach(res => {
			listHeader = [...listHeader, res.title];
			_internalName = [..._internalName, { internalName: res?.internalName }];
		});
		setDetailsFieldInfoCollection(formFromName?.detailsFieldInfoCollection.filter(elm => elm?.internalName));
		setDetailsListInfo(formFromName?.detailsListInfo);
		setHeader(listHeader);

		if (forms?.rid === ID) {
			setLoading(true);
			dispatch(
				fetchGirdDetails({
					rid: ID,
					spitemid: SPItemId,
					detailsFieldInfoCollection: _internalName,
					detailsListInfo: formFromName?.detailsListInfo,
					success,
				}),
			);
		}
	};
	useImperativeHandle(
		ref,
		() => ({
			getGrid,
			getDataGrid,
			require: checkRequire,
		}),
		[data],
	);

	useEffect(() => {
		getDataGrid();
	}, [forms]);

	const getDataField = (name: string) => {
		const res = listField?.find((list: { Name: string }) => list.Name === name);

		const { Title = '', FieldTypeId = 0, Option = '', Guid = '', FieldType } = res || {};

		let FTypeId = 0;

		if (FieldType) {
			FTypeId = exportFieldTypeIdWithFTypeId(FieldType);
		}

		return {
			Title,
			FieldTypeId: FieldTypeId || FTypeId,
			Option: typeof Option === 'string' ? Option : JSON.stringify(Option),
			Guid,
		};
	};

	const renderValue = (name: string, itemInfo: any) => {
		const Field = getDataField(name);
		const { Title, FieldTypeId, Option, Guid } = Field;

		switch (FieldTypeId) {
			case 1:
				return (
					<SingleLine title={Title} options={Option} internalName={name} isGrid itemInfoGrid={itemInfo} isViewGrid />
				);
			case 2:
				return (
					<MultipleLines
						title={Title}
						//
						//
						options={Option}
						internalName={name}
						isGrid
						itemInfoGrid={itemInfo}
						isViewGrid
					/>
				);
			case 3:
				return <Choose title={Title} options={Option} internalName={name} isGrid itemInfoGrid={itemInfo} isViewGrid />;
			case 4:
				return (
					<NumberField title={Title} options={Option} internalName={name} isGrid itemInfoGrid={itemInfo} isViewGrid />
				);
			case 5:
				return (
					<DateTime title={Title} options={Option} internalName={name} isGrid itemInfoGrid={itemInfo} isViewGrid />
				);
			case 7:
				return (
					<UserGroup title={Title} options={Option} internalName={name} isGrid itemInfoGrid={itemInfo} isViewGrid />
				);
			case 8:
				return (
					<Currency title={Title} options={Option} internalName={name} isGrid itemInfoGrid={itemInfo} isViewGrid />
				);
			case 9:
				return (
					<Calculated title={Title} options={Option} internalName={name} isGrid itemInfoGrid={itemInfo} isViewGrid />
				);
			case 10:
				return <Radio title={Title} options={Option} internalName={name} isGrid itemInfoGrid={itemInfo} isViewGrid />;
			case 13:
				return (
					<Lookup
						title={Title}
						options={Option}
						internalName={name}
						Guid={Guid}
						isGrid
						itemInfoGrid={itemInfo}
						isViewGrid
					/>
				);
			case 14:
				return (
					<Lookup
						title={Title}
						options={Option}
						internalName={name}
						Guid={Guid}
						isGrid
						itemInfoGrid={itemInfo}
						isViewGrid
					/>
				);

			case 18:
				return (
					<LookupDataSource
						title={Title}
						options={Option}
						internalName={name}
						Guid={Guid}
						isGrid
						itemInfoGrid={itemInfo}
						isViewGrid
					/>
				);

			default:
				return null;
		}
	};

	const isMore = (header.length > 4 && data?.length) || data?.length > 4;

	const x4Header = header.slice(0, 4);

	const row = x4Header.length - 1 || 1;

	const wRow = windowWidth / row - 51 / row;

	const onCallbackDetails = (
		res: any[],
		idAdd: number[],
		listEdit: { _ID_: number; ActionType: number; Value?: any[] }[],
	) => {
		dispatch(
			updateValueInternalName({
				[internalName?.replace('_17_', '').replace('_Mobile', '')]: 'update',
			}),
		);
		setData(res);
		refIDIsAdd.current = idAdd;
		refEdit.current = listEdit;
	};

	const onPressMore = () => {
		navigate('GridDetails', {
			title,
			data,
			header,
			listField,
			itemPrams: refItemParams.current,
			detailsListInfo,
			ListIDAdd: refIDIsAdd.current,
			onCallbackDetails,
			isPermissionEdit,
			detailsFieldInfoCollection,
			dataRefEdit: refEdit.current,
		});
	};

	const onCallbackData = (res: { data: { _ID_: number }; action: string; ListData: any[] }) => {
		const { data: value, action, ListData } = res || {};

		try {
			dispatch(
				updateValueInternalName({
					[internalName?.replace('_17_', '').replace('_Mobile', '')]: 'update',
				}),
			);
			if (action === 'add') {
				const _ID_: number = Math.floor(Math.random() * 1000);

				let list = JSON.parse(JSON.stringify(value));
				list = { _RowNumber_: data?.length + 1, ...list, _ID_ };

				refEdit.current = [...refEdit.current, { _ID_, ActionType: 1, Value: ListData }];

				refIDIsAdd.current = [...(refIDIsAdd.current || []), _ID_];
				setData([...data, list]);
			} else if (action === 'edit') {
				const indexRef = refEdit.current?.findIndex(elm => elm._ID_ === value?._ID_);
				const cloneRef = JSON.parse(JSON.stringify(refEdit.current));
				if (indexRef !== -1) {
					cloneRef[indexRef] = { ...cloneRef[indexRef], Value: ListData };
					refEdit.current = cloneRef;
				} else {
					refEdit.current = [...refEdit.current, { _ID_: value?._ID_, ActionType: 2, Value: ListData }];
				}

				const index = data?.findIndex(elm => elm._ID_ === value?._ID_);
				const clone: any[] = JSON.parse(JSON.stringify(data));
				if (index !== -1) {
					clone[index] = value;
				}
				setData(clone);
			} else {
				const indexRef = refEdit.current?.findIndex(elm => elm._ID_ === value?._ID_);
				if (indexRef !== -1) {
					if (refEdit.current[indexRef].ActionType === 1) {
						refEdit.current = refEdit.current.filter(elm => elm._ID_ !== value?._ID_);
					} else {
						const cloneRef = JSON.parse(JSON.stringify(refEdit.current));
						cloneRef[indexRef].ActionType = 3;
						refEdit.current = cloneRef;
					}
				} else {
					refEdit.current = [...refEdit.current, { _ID_: value?._ID_, ActionType: 3 }];
				}
				refIDIsAdd.current = refIDIsAdd.current?.filter(elm => elm !== value?._ID_);
				const clone: any[] = JSON.parse(JSON.stringify(data));
				const cloneFilter = clone.filter(elm => elm._ID_ !== value?._ID_);
				cloneFilter.forEach((element, index) => {
					cloneFilter[index] = {
						...element,
						_RowNumber_: index + 1,
					};
				});

				setData(cloneFilter);
			}
		} catch (err) {
			// console.log('error', error);
		}
	};

	return (
		<View>
			<View
				style={{
					marginVertical: 10,
					marginHorizontal: -16,
					borderWidth: error && !data?.length ? 1 : 0,
					borderColor: COLORS.red,
				}}>
				<View
					style={{
						flexDirection: 'row',
						justifyContent: 'space-between',
						backgroundColor: 'rgba(245, 245, 245, 1)',
						paddingHorizontal: 16,
						paddingVertical: 12,
					}}>
					<Text
						numberOfLines={1}
						style={{ color: '#7B7B7B', fontSize: 12, marginBottom: 4, fontWeight: '700', flex: 1 }}>
						{title}
						{IsRequire && isPermissionEdit && <Text style={{ color: COLORS.red }}>(*)</Text>}
					</Text>

					{isPermissionEdit && (
						<TouchableOpacity
							style={{ flexDirection: 'row', alignItems: 'center', marginLeft: 12 }}
							onPress={() => {
								navigate('EditGridDeatils', {
									ID: refItemParams.current?.ID,
									header,
									detailsListInfo,
									listField,
									isAdd: true,
									itemPrams: refItemParams.current,
									internalName,
									onCallbackData,
									detailsFieldInfoCollection,
									title,
								});
							}}>
							<Icon src={ICONS.icPlus} width={20} height={20} />
						</TouchableOpacity>
					)}
				</View>
				{!data?.length ? (
					!loading ? (
						<View style={{ height: 150, alignItems: 'center', justifyContent: 'center' }}>
							<Icon src={ICONS.icGrid} width={80} height={80} />
							<View style={{ flexDirection: 'row' }}>
								<Text style={{ fontSize: 12, color: '#7B7B7B' }}>{translate('noLines')}</Text>
								{isPermissionEdit && (
									<TouchableOpacity
										onPress={() => {
											navigate('EditGridDeatils', {
												ID: refItemParams.current?.ID,
												header,
												detailsListInfo,
												listField,
												isAdd: true,
												itemPrams: refItemParams.current,
												internalName,
												onCallbackData,
												detailsFieldInfoCollection,
												title,
											});
										}}>
										<Text style={{ fontSize: 12, color: 'rgba(0, 95, 212, 1)' }}>{translate('addNew')}</Text>
									</TouchableOpacity>
								)}
							</View>
						</View>
					) : (
						<View />
					)
				) : (
					<ScrollView horizontal style={{}} showsHorizontalScrollIndicator={false} scrollEnabled={false}>
						<ScrollView
							style={[{ overflow: 'hidden', borderColor: '#F5F5F5' }, data?.length ? {} : { height: 50 }]}
							showsVerticalScrollIndicator={false}
							scrollEnabled={false}>
							<View
								style={{
									flexDirection: 'row',
									overflow: 'hidden',
									alignItems: 'center',
									borderBottomWidth: 1,
									borderBottomColor: 'rgba(238, 238, 238, 1)',
									borderTopWidth: 1,
									borderTopColor: 'rgba(238, 238, 238, 1)',
								}}>
								<View
									style={{
										flexDirection: 'row',
										justifyContent: 'space-between',
										width: x4Header?.length ? wRow * (x4Header?.length > 0 ? x4Header?.length - 1 : 1) + 50 : wRow,
										overflow: 'hidden',
									}}>
									{x4Header?.map((res, key) => {
										return (
											<View
												style={{
													borderRightWidth: 1,
													borderRightColor: 'rgba(238, 238, 238, 1)',
													borderLeftColor: 'rgba(238, 238, 238, 1)',
													borderLeftWidth: key === 0 ? 1 : 0,
													paddingVertical: 12,
													width: key === 0 ? 50 : wRow,
												}}
												key={key?.toString()}>
												<Text
													style={{
														fontSize: 12,
														fontWeight: '400',
														color: '#7B7B7B',
														textAlign: 'center',
													}}>
													{res}
												</Text>
											</View>
										);
									})}
								</View>
							</View>
							{!!data?.length &&
								data?.slice(0, 4)?.map((e, key) => {
									const onPressEditRow = () => {
										navigate('EditGridDeatils', {
											ID: refItemParams.current?.ID,
											header,
											detailsListInfo,
											listField,
											isAdd: false,
											itemPrams: refItemParams.current,
											item: e,
											ListIDAdd: refIDIsAdd.current,
											internalName,
											onCallbackData,
											isPermissionEdit,
											detailsFieldInfoCollection,
											title,
										});
									};

									return (
										<TouchableOpacity
											activeOpacity={0.5}
											onPress={onPressEditRow}
											// disabled
											key={key?.toString()}
											style={{
												flexDirection: 'row',
												borderBottomWidth: 0.8,
												borderBottomColor: 'rgba(238, 238, 238, 1)',
											}}>
											{Object.values(e)
												?.slice(0, 4)
												.map((res, index) => {
													const Field = getDataField(Object.keys(e)[index]);
													if (!Field?.FieldTypeId && index !== 0) return null;
													if (index === Object.values(e)?.length - 1) return null;
													if (index === 0)
														return (
															<View
																key={index?.toString()}
																style={{
																	// marginBottom: 1,
																	width: index === 0 ? 50 : wRow,
																	borderRightWidth: 1,
																	borderRightColor: 'rgba(238, 238, 238, 1)',
																	borderLeftColor: 'rgba(238, 238, 238, 1)',
																	borderLeftWidth: index === 0 ? 1 : 0,
																	paddingVertical: 16,
																	paddingHorizontal: 6,
																}}>
																<Text style={{ fontSize: 14, fontWeight: '400', color: '#111', textAlign: 'center' }}>
																	{res?.toString() || 0}
																</Text>
															</View>
														);

													return (
														<View
															key={index?.toString()}
															style={{
																// marginBottom: 1,
																width: index === 0 ? 50 : wRow,
																borderRightWidth: 1,
																borderRightColor: 'rgba(238, 238, 238, 1)',
																borderLeftColor: 'rgba(238, 238, 238, 1)',
																borderLeftWidth: index === 0 ? 1 : 0,
																paddingVertical: 8,
																paddingHorizontal: 6,
																justifyContent: 'center',
															}}>
															{/* <Text style={{ fontSize: 14, fontWeight: '400', color: '#111', textAlign: 'center' }}>
																{renderValue(res, Object.keys(e)[index])}
															</Text> */}
															{renderValue(Object.keys(e)[index], e)}
														</View>
													);
												})}
										</TouchableOpacity>
									);
								})}
						</ScrollView>
					</ScrollView>
				)}

				{isMore && (
					<View style={{ alignItems: 'center', marginVertical: 10 }}>
						<TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center' }} onPress={onPressMore}>
							<Text style={{ fontSize: 12, color: 'rgba(0, 95, 212, 1)' }}>{translate('seeAll')}</Text>
							<Icon src={ICONS.icChevronDown} width={16} height={16} tintColor="rgba(0, 95, 212, 1)" />
						</TouchableOpacity>
					</View>
				)}
			</View>
			{error && isPermissionEdit && !data?.length && (
				<Text style={{ fontSize: 12, color: COLORS.red, fontStyle: 'italic' }}>
					{title}
					{translate('isRequire')}
				</Text>
			)}
		</View>
	);
};

export default forwardRef(GridPreview);
