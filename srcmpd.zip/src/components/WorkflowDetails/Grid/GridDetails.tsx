/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable no-unsafe-optional-chaining */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable no-underscore-dangle */
import React, { useEffect, useRef, useState } from 'react';

import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { ICONS } from 'config/images';
import moment from 'moment';
import { navigate } from 'navigation/RootNavigation';
import { View, Text, ScrollView, Dimensions, TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ButtomNewTicket } from 'screens/Apps/Containers';
import Calculated from 'screens/TaskDetail/Field/Calculated';
import Choose from 'screens/TaskDetail/Field/Choose';
import Currency from 'screens/TaskDetail/Field/Currency';
import DateTime from 'screens/TaskDetail/Field/DateTime';
import Lookup from 'screens/TaskDetail/Field/Lookup';
import LookupDataSource from 'screens/TaskDetail/Field/LookupDataSource';
import MultipleLines from 'screens/TaskDetail/Field/MultipleLines';
import NumberField from 'screens/TaskDetail/Field/Number';
import Radio from 'screens/TaskDetail/Field/Radio';
import SingleLine from 'screens/TaskDetail/Field/SingleLine';
import UserGroup from 'screens/TaskDetail/Field/UserGroup';
import { IItemParams } from 'screens/WorkflowDetails/WorkflowDetails';
import { exportFieldTypeIdWithFTypeId } from 'utils/functions';

const Header = ({ title, onGoback }: { title: string; onGoback: () => void }) => {
	const insets = useSafeAreaInsets();

	return (
		<View
			style={{
				flexDirection: 'row',
				shadowColor: '#000',
				shadowOffset: {
					width: 0,
					height: 2,
				},
				shadowOpacity: 0.1,
				shadowRadius: 2,

				elevation: 5,
				backgroundColor: 'white',
				paddingTop: insets.top,
				paddingBottom: 10,
				paddingHorizontal: 16,
			}}>
			<View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
				<Icon src={ICONS.icArrowMenu} width={24} height={24} tintColor="rgba(0, 0, 0, 1)" onPress={onGoback} />
				<Text
					numberOfLines={1}
					style={{ fontSize: 16, fontWeight: '700', marginHorizontal: 12, color: 'rgba(0, 0, 0, 1)' }}>
					{title}
				</Text>
			</View>
		</View>
	);
};

type Params = {
	Item: {
		title: string;
		data: any[];
		header: any[];
		listField: any[];
		detailsListInfo: {
			listID: string;
			WorkflowId: string;
		};
		ListIDAdd: number[];
		isPermissionEdit: boolean;
		onCallbackDetails: (data: any[], action: number[], ListData?: any[]) => void;
		detailsFieldInfoCollection: any[];
		itemPrams: IItemParams;
	};
};

const GridDetails = () => {
	const navigation = useNavigation();
	const route = useRoute<RouteProp<Params, 'Item'>>();
	const refIDIsAdd = useRef<number[]>([]);
	const refEdit = useRef<{ _ID_: number; ActionType: number; value?: any[] }[]>([]);

	const {
		title = '',
		data: dataDf = [],
		header = [],
		listField = [],
		itemPrams,
		detailsListInfo,
		ListIDAdd,
		onCallbackDetails,
		isPermissionEdit,
		detailsFieldInfoCollection,
		dataRefEdit,
	} = route.params || {};

	const x4Header = header.slice(0, 4);

	const windowWidth = Dimensions.get('window').width;
	const row = x4Header.length - 1 || 1;
	const wRow = windowWidth / row - 51 / row;

	const [data, setData] = useState<any[]>([]);
	const [fieldSum, setFieldSum] = useState<string[]>([]);

	useEffect(() => {
		refEdit.current = dataRefEdit;
		return () => {
			refEdit.current = [];
			refIDIsAdd.current = [];
		};
	}, [dataRefEdit]);

	useEffect(() => {
		setData(dataDf);
	}, [dataDf]);

	useEffect(() => {
		refIDIsAdd.current = ListIDAdd;
	}, [ListIDAdd]);

	const onGoback = () => {
		onCallbackDetails(data, refIDIsAdd.current, refEdit.current);
		navigation.goBack();
	};

	useEffect(() => {
		let sum: string[] = [];
		listField.map(item => {
			const op = typeof item?.Option === 'string' ? JSON.parse(item?.Option || '{}') : item?.Option || {};

			if (op?.IsSum === true || op?.Is_Sum === true) {
				sum = [...sum, item.Name];
			}
		});
		setFieldSum(sum);
	}, [listField]);

	const CvDatatTest = () => {
		let list = {};
		header.map(item => {
			const find = listField?.find(elm => elm?.Title === item || elm?.TitleEN === item);
			if (item === '#') {
				list = { ...list, ...{ _RowNumber_: '-' } };
			} else if (find) {
				list = { ...list, ...{ [find.Name]: '' } };
			}
		});
		return { ...list, _ID_: 0 };
	};

	const dataCustom = fieldSum?.length ? [...data, CvDatatTest()] : data;

	const onCallbackData = (res: { data: { _ID_: number }; action: string; ListData: any[] }) => {
		const { data: value, action, ListData } = res || {};
		try {
			if (action === 'add') {
				const _ID_ = Math.floor(Math.random() * 1000);
				let list = JSON.parse(JSON.stringify(value));
				list = { _RowNumber_: data?.length + 1, ...list, _ID_ };
				refEdit.current = [...refEdit.current, { _ID_, ActionType: 1, Value: ListData }];
				refIDIsAdd.current = [...(refIDIsAdd.current || []), _ID_];
				setData([...data, list]);
			} else if (action === 'edit') {
				const indexRef = refEdit.current?.findIndex(elm => elm._ID_ === value?._ID_);
				const cloneRef: { _ID_: number; ActionType: number; Value?: any[] }[] = JSON.parse(
					JSON.stringify(refEdit.current),
				);
				if (indexRef !== -1) {
					cloneRef[indexRef] = { ...cloneRef[indexRef], Value: ListData };
					refEdit.current = cloneRef;
				} else {
					refEdit.current = [...refEdit.current, { _ID_: value?._ID_, ActionType: 2, Value: ListData }];
				}

				const index = data?.findIndex((elm: { _ID_: number }) => elm._ID_ === value?._ID_);
				const clone: any[] = JSON.parse(JSON.stringify(data));
				clone[index] = value;
				setData(clone);
			} else {
				const indexRef = refEdit.current?.findIndex(elm => elm._ID_ === value?._ID_);
				if (indexRef !== -1) {
					if (refEdit.current[indexRef].ActionType === 1) {
						refEdit.current = refEdit.current.filter(elm => elm._ID_ !== value?._ID_);
					} else {
						const cloneRef = JSON.parse(JSON.stringify(refEdit.current));
						if (indexRef !== -1) {
							cloneRef[indexRef].ActionType = 3;
						}
						refEdit.current = cloneRef;
					}
				} else {
					refEdit.current = [...refEdit.current, { _ID_: value?._ID_, ActionType: 3 }];
				}
				refIDIsAdd.current = refIDIsAdd.current?.filter(elm => elm !== value?._ID_);
				const clone: any[] = JSON.parse(JSON.stringify(data));
				const cloneFilter = clone.filter((elm: { _ID_: number }) => elm._ID_ !== value?._ID_);
				cloneFilter.forEach((element, index) => {
					cloneFilter[index] = {
						...element,
						_RowNumber_: index + 1,
					};
				});

				setData(cloneFilter);
			}
		} catch (error) {
			//
		}
	};

	const getDataField = (name: string) => {
		const res = listField?.find((list: { Name: string }) => list.Name === name);

		const { Title = '', FieldTypeId = 0, Option = '', Guid = '', FieldType = 0 } = res || {};

		let FTypeId = 0;

		if (FieldType) {
			FTypeId = exportFieldTypeIdWithFTypeId(FieldType);
		}

		return {
			Title,
			FieldTypeId: FieldTypeId || FTypeId,
			Option: typeof Option === 'string' ? Option : JSON.stringify(Option),
			Guid,
		};
	};

	const renderValue = (e: unknown, name: string, itemInfo) => {
		const Field = getDataField(name);
		const { Title, FieldTypeId, Option, Guid } = Field;

		switch (FieldTypeId) {
			case 1:
				return (
					<SingleLine title={Title} options={Option} internalName={name} isGrid itemInfoGrid={itemInfo} isViewGrid />
				);
			case 2:
				return (
					<MultipleLines
						title={Title}
						//
						//
						options={Option}
						internalName={name}
						isGrid
						itemInfoGrid={itemInfo}
						isViewGrid
					/>
				);
			case 3:
				return <Choose title={Title} options={Option} internalName={name} isGrid itemInfoGrid={itemInfo} isViewGrid />;
			case 4:
				return (
					<NumberField
						title={Title}
						options={Option}
						internalName={name}
						// listCatulated={listCatulated}
						isGrid
						itemInfoGrid={itemInfo}
						isViewGrid
					/>
				);
			case 5:
				return (
					<DateTime title={Title} options={Option} internalName={name} isGrid itemInfoGrid={itemInfo} isViewGrid />
				);
			case 7:
				return (
					<UserGroup title={Title} options={Option} internalName={name} isGrid itemInfoGrid={itemInfo} isViewGrid />
				);
			case 8:
				return (
					<Currency title={Title} options={Option} internalName={name} isGrid itemInfoGrid={itemInfo} isViewGrid />
				);
			case 9:
				return (
					<Calculated
						title={Title}
						options={Option}
						internalName={name}
						// sendCaculated={sendCaculated}
						isGrid
						itemInfoGrid={itemInfo}
						isViewGrid
					/>
				);
			case 10:
				return <Radio title={Title} options={Option} internalName={name} isGrid itemInfoGrid={itemInfo} isViewGrid />;
			case 13:
				return (
					<Lookup
						title={Title}
						options={Option}
						internalName={name}
						Guid={Guid}
						isGrid
						itemInfoGrid={itemInfo}
						isViewGrid
					/>
				);
			case 14:
				return (
					<Lookup
						title={Title}
						options={Option}
						internalName={name}
						Guid={Guid}
						isGrid
						itemInfoGrid={itemInfo}
						isViewGrid
					/>
				);

			case 18:
				return (
					<LookupDataSource
						title={Title}
						options={Option}
						internalName={name}
						Guid={Guid}
						isGrid
						itemInfoGrid={itemInfo}
						isViewGrid
					/>
				);

			default:
				return null;
		}
	};

	function numberWithCommas(x: string) {
		if (!x && x !== 0) return '';
		const number = Number(x).toFixed(0);
		const numberReplace = number.replace('.', ',').replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, '.');
		return numberReplace;
	}

	const getToTalValue = index => {
		let total = 0;
		data?.map(item => {
			let value = Object.values(item)[index];
			const isFloat = value?.includes(';#');
			if (isFloat && value) {
				value = value?.split(';#')?.[1];
			}

			total += Number(value);
		});

		return <Text style={{ textAlign: 'center' }}>{numberWithCommas(total)}</Text>;
	};

	return (
		<View style={{ flex: 1 }}>
			<Header title={title} onGoback={onGoback} />

			<ScrollView horizontal showsHorizontalScrollIndicator={false}>
				<ScrollView
					style={[{ overflow: 'hidden', borderColor: '#F5F5F5' }, data?.length ? {} : { height: 50 }]}
					showsVerticalScrollIndicator={false}>
					<View
						style={{
							flexDirection: 'row',
							overflow: 'hidden',
							alignItems: 'center',
							borderBottomWidth: 1,
							borderBottomColor: 'rgba(238, 238, 238, 1)',
							borderTopWidth: 1,
							borderTopColor: 'rgba(238, 238, 238, 1)',
						}}>
						<View
							style={{
								flexDirection: 'row',
								justifyContent: 'space-between',
								width: header?.length > 1 ? wRow * (Number(header?.length) - 1) + 50 : wRow,
								overflow: 'hidden',
							}}>
							{header?.map((res, key) => {
								return (
									<View
										style={{
											borderRightWidth: 1,
											borderRightColor: 'rgba(238, 238, 238, 1)',
											borderLeftColor: 'rgba(238, 238, 238, 1)',
											borderLeftWidth: key === 0 ? 1 : 0,
											paddingVertical: 12,
											width: key === 0 ? 50 : wRow,
										}}
										key={key?.toString()}>
										<Text
											style={{
												fontSize: 12,
												fontWeight: '400',
												color: '#7B7B7B',
												textAlign: 'center',
											}}>
											{res}
										</Text>
									</View>
								);
							})}
						</View>
					</View>
					{!!dataCustom?.length &&
						dataCustom?.map((e, key) => {
							const onPressEditRow = () => {
								navigate('EditGridDeatils', {
									ID: itemPrams.ID,
									header,
									detailsListInfo,
									listField,
									isAdd: false,
									itemPrams,
									item: e,
									ListIDAdd: refIDIsAdd.current,
									from: 'details',
									onCallbackData,
									isPermissionEdit,
									detailsFieldInfoCollection,
									title,
								});
							};

							return (
								<TouchableOpacity
									disabled={e?._RowNumber_ === '-'}
									onPress={onPressEditRow}
									key={key?.toString()}
									style={{
										flexDirection: 'row',
										borderBottomWidth: 0.8,
										borderBottomColor: 'rgba(238, 238, 238, 1)',
									}}>
									{Object.values(e).map((res, index) => {
										const Field = getDataField(Object.keys(e)[index]);
										const isSum = fieldSum.includes(Object.keys(e)[index]) && key === dataCustom.length - 1;
										if (!Field?.FieldTypeId && index !== 0) return null;
										if (index === Object.values(e)?.length - 1) return null;
										if (index === 0)
											return (
												<View
													key={index?.toString()}
													style={{
														// marginBottom: 1,
														width: index === 0 ? 50 : wRow,
														borderRightWidth: 1,
														borderRightColor: 'rgba(238, 238, 238, 1)',
														borderLeftColor: 'rgba(238, 238, 238, 1)',
														borderLeftWidth: index === 0 ? 1 : 0,
														paddingVertical: 16,
														paddingHorizontal: 6,
													}}>
													<Text style={{ fontSize: 14, fontWeight: '400', color: '#111', textAlign: 'center' }}>
														{res === '-' ? '' : res?.toString() || ''}
													</Text>
												</View>
											);
										return (
											<View
												key={index?.toString()}
												style={{
													// marginBottom: 1,
													width: index === 0 ? 50 : wRow,
													borderRightWidth: 1,
													borderRightColor: 'rgba(238, 238, 238, 1)',
													borderLeftColor: 'rgba(238, 238, 238, 1)',
													borderLeftWidth: index === 0 ? 1 : 0,
													paddingVertical: 8,
													paddingHorizontal: 6,
													justifyContent: 'center',
												}}>
												{/* <Text style={{ fontSize: 14, fontWeight: '400', color: '#111', textAlign: 'center' }}> */}

												{isSum ? getToTalValue(index) : renderValue(res, Object.keys(e)[index], e)}
												{/* </Text> */}
											</View>
										);
									})}
								</TouchableOpacity>
							);
						})}
				</ScrollView>
			</ScrollView>
			{isPermissionEdit && (
				<ButtomNewTicket
					cStyle={{ bottom: 40, right: 20 }}
					onPress={() => {
						navigate('EditGridDeatils', {
							ID: itemPrams?.ID,
							header,
							detailsListInfo,
							listField,
							isAdd: true,
							itemPrams,
							from: 'details',
							onCallbackData,
							isPermissionEdit,
							detailsFieldInfoCollection,
							title,
						});
					}}
				/>
			)}
		</View>
	);
};

export default GridDetails;
