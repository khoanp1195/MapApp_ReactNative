/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable @typescript-eslint/restrict-template-expressions */
/* eslint-disable array-callback-return */
import { baseURL } from 'http/modules';

import React, { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';

import { useNavigation } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { ShowLoading } from 'components/Atoms/Loading/LoadingGlobal';
import { ICONS } from 'config/images';
import dayjs from 'dayjs';
import useSystem from 'hooks/useSystem';
import { RoutesNames } from 'navigation/RoutesNames';
import { View, Text, Animated, TouchableOpacity, Platform, Share } from 'react-native';
import ReactNativeBlobUtil from 'react-native-blob-util';
import FileViewer from 'react-native-file-viewer';
import { Swipeable } from 'react-native-gesture-handler';
import { SwipeableProps } from 'react-native-gesture-handler/lib/typescript/components/Swipeable';
import { usePermisstionAttach, usePermisstionEditAtatch } from 'screens/TaskDetail/useHooks/usePermissionEdit';
import { useAppDispatch, useAppSelector } from 'stores';
import { deleteAttachment } from 'stores/TaskDetails';
import { updateAttachments, editAttachment } from 'stores/Workflows/sliceWorkflow';
import { IAttachments } from 'stores/Workflows/types';
import { formatBytes, getIconFile } from 'utils/functions';
import { translate } from 'utils/translate';

import { styles } from './Attachment.styles';
import ModalTypeDoc from './Upload/ModalTypeDoc';

const Attachment = ({ rid, moreOptionInfo }: any, ref: React.Ref<unknown> | undefined) => {
	const refModalType = useRef();
	const navigation = useNavigation();
	const dispatch = useAppDispatch();
	const SwipeableRef = useRef<SwipeableProps>();
	const refIDSwip = useRef<string>();
	const refPosition = useRef({});

	const { formatDateTime } = useSystem();

	const attachmet = useAppSelector(store => store.workflow.attachmets);

	const { isPermissionEdit } = usePermisstionEditAtatch();

	const [acttchs, setAttachs] = useState<Array<{ type: string; list: Array<IAttachments>; AttachTypeId: number }>>([]);
	const [indexHide, setIndexHide] = useState<number[]>([]);

	useImperativeHandle(
		ref,
		() => ({
			add: () => {
				navigation.navigate(RoutesNames.Upload, { moreOptionInfo, type: 'add' });
			},
		}),
		[],
	);

	const onHide = (index: number) => {
		const isHide = indexHide.find(e => e === index);
		if (isHide === undefined) {
			setIndexHide(indexHide.concat(index));
			return;
		}

		setIndexHide(indexHide.filter(e => e !== index));
	};

	useEffect(() => {
		let typeName: Array<{ type: string; list: Array<IAttachments>; AttachTypeId: number }> = [];

		attachmet?.map(e => {
			const isType = typeName?.findIndex((item: { type: string }) => {
				if (e?.AttachTypeName) {
					return item.type === e?.AttachTypeName;
				}
				return item.type === '-';
			});

			if (isType === -1) {
				typeName = [...typeName, { type: e?.AttachTypeName || '-', list: [e], AttachTypeId: e.AttachTypeId }];
			} else {
				typeName[isType].list.push(e);
			}
		});

		const listClone: Array<{ type: string; list: Array<IAttachments>; AttachTypeId: number }> = JSON.parse(
			JSON.stringify(typeName),
		);

		setAttachs(listClone);
	}, [attachmet]);

	const onShare = async (localFile: string) => {
		try {
			const result = await Share.share({
				url: localFile,
			});
			if (result.action === Share.sharedAction) {
				if (result.activityType) {
					// shared with activity type of result.activityType
				} else {
					// shared
				}
			} else if (result.action === Share.dismissedAction) {
				// dismissed
			}
		} catch (error: any) {
			//
		}
	};

	const onPressOpenFile = async (item: IAttachments, isDown?: boolean) => {
		if (!item?.ID && item?.uri) {
			await FileViewer.open(item.uri, {
				showOpenWithDialog: true,
			}).catch(() => {
				//
			});
			return;
		}
		const exFile = item.Path?.split('.');

		const isImage = ['jpg', 'png', 'mp3'].includes(exFile[exFile.length - 1]);

		const localFile = `${ReactNativeBlobUtil.fs?.dirs?.CacheDir}/${item.Title}.${item?.Extension}`;
		let config: { fileCache: boolean; path?: string } = {
			fileCache: true,
		};
		if (Platform.OS === 'ios') {
			config = { ...config, path: localFile };
		}
		const path = `${baseURL}/_layouts/15/VuThao.BPMOP.API/ApiDownload.ashx?file=${encodeURI(
			item?.Path,
		)}&name=${encodeURI(item?.Title)}`;

		ReactNativeBlobUtil.config(config)
			.fetch('GET', path)
			.then(async res => {
				if (Platform.OS !== 'ios') {
					const result = await ReactNativeBlobUtil.MediaCollection.copyToMediaStore(
						{
							name: item?.Title,
							mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
						},
						'Download',
						res.path(),
					);
					await ReactNativeBlobUtil.MediaCollection.copyToInternal(result, localFile);
				}
				if (isDown) {
					onShare(localFile);
				} else if (!isImage) {
					FileViewer.open(localFile, {
						showOpenWithDialog: true,
					}).catch(() => {
						//
					});
				} else {
					onShare(localFile);
				}
			});
	};

	const success = () => {
		ShowLoading(false);
	};

	const onPressContinute = (value: IAttachments) => {
		if (value?.ID) {
			ShowLoading(true);
			dispatch(
				editAttachment({
					params: {
						rid,
						data: {
							ID: value.ID,
							Title: value.Title,
							Path: value.Path,
							AttachTypeId: value.AttachTypeId || 0,
							AttachTypeName: value.AttachTypeName || '',
						},
					},
					success,
				}),
			);
		} else {
			dispatch(
				updateAttachments({
					func: 'editLocal',
					item: {
						AttachTypeId: value.AttachTypeId || 0,
						AttachTypeName: value.AttachTypeName || '',
						Title: value.Title,
					},
					idLocal: value.idLocal,
				}),
			);
		}
	};

	const renderRightActions = (
		_progress: Animated.AnimatedInterpolation<string | number>,
		dragX: Animated.AnimatedInterpolation<string | number>,
		isAuthor: boolean,
		child: IAttachments,
	) => {
		const transform = dragX.interpolate({
			inputRange: [0, 50],
			outputRange: [0, 0],
		});
		const opacity = dragX.interpolate({
			inputRange: [-50, 0],
			outputRange: [1, 0],
			extrapolate: 'clamp',
		});

		const onDeleteSuccess = (res: BaseAPIResponse) => {
			if (res?.status === 'SUCCESS') {
				dispatch(
					updateAttachments({
						func: 'delete',
						item: child,
					}),
				);
			}
			ShowLoading(false);
		};

		const idSwipe = child?.ID || child?.idLocal;

		const onDeleteClick = () => {
			SwipeableRef[idSwipe]?.close();
			if (child?.ID) {
				ShowLoading(true);
				return dispatch(
					deleteAttachment({
						params: {
							rid,
							data: {
								ID: child.ID,
								Path: child.Path,
							},
						},
						success: onDeleteSuccess,
					}),
				);
			}
			return dispatch(
				updateAttachments({
					func: 'deleteLocal',
					idLocal: child.idLocal,
				}),
			);
		};

		const onPressEdit = () => {
			SwipeableRef[idSwipe]?.close();
			refModalType.current?.show(child);
		};

		const onPressDownload = () => {
			SwipeableRef[idSwipe]?.close();
			onPressOpenFile(child, true);
		};

		return (
			<Animated.View style={[styles.containerSwipe, { opacity, transform: [{ translateX: transform }] }]}>
				{isAuthor && (
					<TouchableOpacity onPress={onDeleteClick} style={styles.bDelete}>
						<Icon src={ICONS.icTrash} width={20} height={20} tintColor="white" />
						<Text style={styles.tDelete}>{translate('delete')}</Text>
					</TouchableOpacity>
				)}

				{isAuthor && (
					<TouchableOpacity onPress={onPressEdit} style={styles.bEdit}>
						<Icon src={ICONS.icPencil} width={20} height={20} tintColor="white" />
						<Text style={styles.tEdit}>{translate('edit')}</Text>
					</TouchableOpacity>
				)}

				{!!child?.ID && (
					<TouchableOpacity onPress={onPressDownload} style={styles.bDown}>
						<Icon src={ICONS.icDownload} width={20} height={20} tintColor="white" />

						<Text style={styles.tDown}>{translate('download')}</Text>
					</TouchableOpacity>
				)}
			</Animated.View>
		);
	};

	const getSortAttach = () => {
		const clone = JSON.parse(JSON.stringify(acttchs));
		clone.sort((a, b) => {
			if (a.type === '-') {
				return -1;
			}
			if (b.type === '-') {
				return 1;
			}
			return a.type.localeCompare(b.type, 'en', { sensitivity: 'base' });
		});
		return clone;
	};

	const sortAttach = getSortAttach();

	return (
		<View>
			{!attachmet?.length && (
				<Text style={{ fontSize: 12, fontStyle: 'italic', textAlign: 'center', paddingTop: 10 }}>
					{translate('noAttachments')}
				</Text>
			)}
			{sortAttach?.map((item, index) => {
				const isHide = indexHide.find(e => e === index);
				return (
					<View key={index?.toString()}>
						<TouchableOpacity activeOpacity={1} onPress={() => onHide(index)} style={styles.bHeader}>
							<Text style={styles.tHeader}>{item.type === '-' ? '' : item.type}</Text>
						</TouchableOpacity>
						<View style={styles.body}>
							{isHide === undefined &&
								item.list.map((child, indexChild) => {
									const idSwipe = child?.ID || child?.idLocal;
									const setRef = ref => (SwipeableRef[idSwipe] = ref);

									const onSwipeableWillClose = () => {
										if (refIDSwip.current === idSwipe) {
											refIDSwip.current = '';
										}
									};

									const onSwipeableOpen = () => {
										refIDSwip.current = idSwipe;
									};

									const onSwipeableWillOpen = () => SwipeableRef[refIDSwip.current]?.close();

									const onLayout = event => {
										event.target.measure((x, y, width, height, pageX, pageY) => {
											refPosition.current = {
												...refPosition.current,
												...{ [child.ID]: { right: x + pageX, top: y + pageY + 30 } },
											};
										});
									};

									const onPress = () => onPressOpenFile(child);

									const isAuthor = child?.IsAuthor === 1 && isPermissionEdit;

									const created = dayjs(child.Created || new Date()).format(formatDateTime);

									return (
										<Swipeable
											ref={setRef}
											onSwipeableOpen={onSwipeableOpen}
											onSwipeableWillClose={onSwipeableWillClose}
											onSwipeableWillOpen={onSwipeableWillOpen}
											key={indexChild?.toString()}
											renderRightActions={(progress, dragX) => renderRightActions(progress, dragX, isAuthor, child)}>
											<View onLayout={onLayout} key={indexChild?.toString()} style={styles.itemAttach}>
												<Icon src={getIconFile(child.Extension)} width={18} height={18} style={styles.vIcon} />
												<View style={styles.vAttach}>
													<TouchableOpacity onPress={onPress}>
														<Text numberOfLines={1}>{child.Title}</Text>
													</TouchableOpacity>
													<View style={styles.vName}>
														<Text numberOfLines={1} style={styles.tName}>
															{child.CreatedName}
														</Text>
														<View style={styles.vSize} />
														<Text numberOfLines={1} style={styles.tSize}>
															{formatBytes(child.Size)}
														</Text>
													</View>
												</View>
												<View style={styles.vDate}>
													<Text style={styles.tDate}>{created}</Text>
												</View>
											</View>
										</Swipeable>
									);
								})}
						</View>
					</View>
				);
			})}
			<ModalTypeDoc ref={refModalType} onPressContinute={onPressContinute} />
		</View>
	);
};

export default forwardRef(Attachment);
