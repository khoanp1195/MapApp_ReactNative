import React, { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';

import { Icon } from 'components/Atoms/Icon';
import ModalRef from 'components/Molecules/Modal/ModalRef';
import { COLORS } from 'config';
import { ICONS } from 'config/images';
import {
	View,
	FlatList,
	TouchableOpacity,
	Text,
	Dimensions,
	TextInput,
	KeyboardAvoidingView,
	ScrollView,
} from 'react-native';
import { useAppSelector } from 'stores';
import { translate } from 'utils/translate';

import { IFile } from './Upload';

const ModalTypeDoc = ({ onPressContinute }, ref) => {
	const windowHeight = Dimensions.get('window').height;

	const refModal = useRef<{ show: () => void; hide: () => void } | null>(null);
	const isAcceptFile = useRef(false);
	const [file, setFile] = useState<IFile>({});
	const [select, setSelect] = useState(0);
	const [nameFile, setNameFile] = useState<string>('');
	const [err, setErr] = useState(false);

	const { details } = useAppSelector(store => store.workflow);

	const ListAction = JSON?.parse(details?.FormConfig?.ListDocumentCategory || '[]');

	const show = (value: IFile) => {
		setFile(value);
		setNameFile(value?.Title || '');
		const action = ListAction?.find(item => item.ID === value?.AttachTypeId);
		setSelect(action);
		refModal.current?.show();
	};

	const hide = () => {
		setErr(false);
		refModal.current?.hide();
	};

	useImperativeHandle(
		ref,
		() => ({
			show,
			hide,
		}),
		[],
	);

	const onHide = () => {
		if (isAcceptFile.current) {
			onPressContinute(file);
			isAcceptFile.current = false;
		}
	};

	const renderType = ({ item, index }) => {
		const isSelected = item.ID === select?.ID;
		return (
			<TouchableOpacity
				style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}
				activeOpacity={1}
				onPress={() => {
					if (select?.ID === item?.ID) {
						setSelect();
					} else {
						setSelect(item);
					}
				}}>
				<Icon
					src={isSelected ? ICONS.icCheckUser : ICONS.icUnCheckUser}
					width={20}
					height={20}
					style={{ marginRight: 10 }}
				/>
				<Text>{item?.Title}</Text>
			</TouchableOpacity>
		);
	};

	return (
		<ModalRef
			ref={refModal}
			onHide={onHide}
			outsideClickCloseable
			onClose={hide}
			visiblePosition="bottom"
			isTouch={false}
			avoidKeyboard={false}>
			<View
				style={{
					height: windowHeight * 0.8,
					paddingVertical: 10,
					borderTopEndRadius: 8,
					overflow: 'hidden',
					backgroundColor: 'white',
					borderTopStartRadius: 8,
				}}>
				<View style={{ flex: 1 }}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							justifyContent: 'space-between',
							paddingHorizontal: 16,
						}}>
						<Text style={{ fontSize: 16, fontWeight: '600' }}>{translate('editAttachment')}</Text>
					</View>
					<View style={{ padding: 16 }}>
						<Text>
							{translate('title')}
							<Text style={{ color: COLORS.red }}> (*)</Text>
						</Text>
						<TextInput
							maxLength={255}
							onChangeText={setNameFile}
							value={nameFile}
							style={{
								borderWidth: 0.8,
								padding: 10,
								borderRadius: 8,
								borderColor: err && !nameFile?.length ? COLORS.red : 'rgba(217, 217, 217, 1)',
								marginTop: 8,
							}}
							returnKeyType="done"
						/>
						{err && !nameFile?.length && (
							<Text style={{ color: COLORS.red, fontSize: 12, fontStyle: 'italic', marginTop: 2 }}>
								{translate('opinionRequired')}
							</Text>
						)}
					</View>
					{!!ListAction?.length && (
						<View style={{ paddingHorizontal: 16, paddingTop: 10 }}>
							<Text style={{ fontSize: 14, marginBottom: 10 }}>{translate('documentType')}</Text>
							<FlatList data={ListAction} keyExtractor={(item, index) => index?.toString()} renderItem={renderType} />
						</View>
					)}
				</View>
				<View style={{ flexDirection: 'row', marginHorizontal: 24 }}>
					{/* <TouchableOpacity
						onPress={() => {
							hide();
						}}
						style={{
							// marginHorizontal: 24,
							marginRight: 12,
							alignItems: 'center',
							marginBottom: 10,
							paddingVertical: 12,
							// backgroundColor: 'rgba(0, 95, 212, 1)',
							borderRadius: 8,
							marginTop: 15,
							flex: 1,
							borderWidth: 0.8,
							borderColor: 'rgba(157, 157, 157, 1)',
						}}>
						<Text style={{ color: 'rgba(17, 17, 17, 1)', fontSize: 16, fontWeight: '600' }}>
							{translate('close').toLocaleUpperCase()}
						</Text>
					</TouchableOpacity> */}
					<TouchableOpacity
						disabled={!nameFile?.length}
						onPress={() => {
							if (nameFile) {
								const params = { AttachTypeName: select?.Title, AttachTypeId: select?.ID, Title: nameFile };
								setFile({
									...file,
									...params,
								});
								isAcceptFile.current = true;
								hide();
							} else {
								setErr(true);
							}
						}}
						style={{
							// marginHorizontal: 12,
							marginLeft: 12,
							alignItems: 'center',
							marginBottom: 10,
							paddingVertical: 12,
							backgroundColor: nameFile?.length ? 'rgba(0, 95, 212, 1)' : 'grey',
							borderRadius: 8,
							marginTop: 15,
							flex: 1,
						}}>
						<Text style={{ color: 'white', fontSize: 16, fontWeight: '600' }}>
							{translate('continue').toLocaleUpperCase()}
						</Text>
					</TouchableOpacity>
				</View>
			</View>
		</ModalRef>
	);
};

export default forwardRef(ModalTypeDoc);
