import React, { forwardRef, useImperativeHandle, useRef, useState } from 'react';

import { Icon } from 'components/Atoms/Icon';
import ModalRef from 'components/Molecules/Modal/ModalRef';
import { ICONS } from 'config/images';
import { View, TouchableOpacity, Text } from 'react-native';
import { translate } from 'utils/translate';

const ModalActionUpload = ({ onPressAction, emptyFileExtentions }, ref) => {
	const refModal = useRef<{ show: () => void; hide: () => void } | null>(null);

	const [type, setType] = useState();

	const show = () => {
		refModal.current?.show();
	};

	const hide = () => {
		refModal.current?.hide();
	};

	useImperativeHandle(
		ref,
		() => ({
			show,
			hide,
		}),
		[],
	);

	const onHide = () => {
		onPressAction(type);
		setType();
	};

	const isHideImage =
		!emptyFileExtentions?.length || emptyFileExtentions?.includes('jpg') || emptyFileExtentions?.includes('png');

	return (
		<ModalRef
			ref={refModal}
			onHide={onHide}
			outsideClickCloseable
			onClose={hide}
			visiblePosition="bottom"
			container={{ backgroundColor: 'white' }}
			isTouch={false}>
			<View style={{ height: 180, paddingHorizontal: 16, paddingVertical: 10 }}>
				{['files', 'imageLibrary', 'camera'].map((item, index) => {
					return (
						<TouchableOpacity
							disabled={!isHideImage && index !== 0}
							onPress={() => {
								hide();
								setType(index);
							}}
							key={index?.toString()}
							style={{
								flexDirection: 'row',
								alignItems: 'center',
								paddingVertical: 10,
								opacity: !isHideImage && index !== 0 ? 0.5 : 1,
							}}>
							<Icon
								src={index === 0 ? ICONS.icSdStorage : index === 1 ? ICONS.icGallery : ICONS.icCamera}
								width={24}
								height={24}
							/>
							<Text style={{ marginLeft: 10 }}>{translate(item as 'files')}</Text>
						</TouchableOpacity>
					);
				})}
			</View>
		</ModalRef>
	);
};

export default forwardRef(ModalActionUpload);
