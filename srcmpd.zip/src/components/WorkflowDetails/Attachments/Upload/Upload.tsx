/* eslint-disable no-case-declarations */
/* eslint-disable @typescript-eslint/no-misused-promises */
import React, { useEffect, useRef, useState } from 'react';

import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { ICONS } from 'config/images';
import { View, Text, TouchableOpacity, FlatList, Dimensions, Image, Alert, Animated, Platform } from 'react-native';
import ReactNativeBlobUtil from 'react-native-blob-util';
import DocumentPicker from 'react-native-document-picker';
import FileViewer from 'react-native-file-viewer';
import { Swipeable } from 'react-native-gesture-handler';
import { SwipeableProps } from 'react-native-gesture-handler/lib/typescript/components/Swipeable';
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateAttachments } from 'stores/Workflows/sliceWorkflow';
import { IAttachments } from 'stores/Workflows/types';
import { bytesToMB, formatBytes, generateRandomId, getIconFile } from 'utils/functions';
import { translate } from 'utils/translate';

import ModalActionUpload from './ModalActionUpload';
import ModalTypeDoc from './ModalTypeDoc';
import { styles } from './styles/Upload.styles';

type Params = {
	Item: {
		moreOptionInfo: {
			fileExtentions: any[];
			limitWeightAllFiles: number;
			limitWeightSingleFile: number;
		};
		type: string;
	};
};

export interface IFile {
	size?: number | 0;
	fileSize?: number | 0;
	name?: string;
	fileName?: string;
	Base64?: string;
	Extension?: string;
	idLocal?: string;
	CreatedName?: string;
	PositionName?: string;
	uri?: string;
	Title?: string;
}

const Upload = () => {
	const dispatch = useAppDispatch();
	const navigation = useNavigation();
	const insets = useSafeAreaInsets();

	const route = useRoute<RouteProp<Params, 'Item'>>();

	const SwipeableRef = useRef<SwipeableProps>();
	const refIDSwip = useRef<string>();
	const refTimeOut = useRef();
	const refModal = useRef<{ show: () => void } | null>(null);
	const refModalType = useRef();

	const user = useAppSelector(store => store.dataNotRemove.customer);
	const { FullName: CreatedName, PositionTitle: PositionName } = user || {};
	const { fileExtentions = [], limitWeightAllFiles, limitWeightSingleFile } = route.params?.moreOptionInfo || {};
	const emptyFileExtentions = fileExtentions?.filter(e => e !== '') || [];

	const [files, setFiles] = useState<IFile[]>([]);

	useEffect(() => {
		if (route.params?.type === 'add') {
			refModal.current?.show();
		}
		return () => refTimeOut.current && clearTimeout(refTimeOut.current);
	}, [route.params?.type]);

	const getAllSizeFile = () => {
		let size = 0;
		files?.forEach(e => {
			const z = e?.size || e?.fileSize;
			size += z || 0;
		});
		return size;
	};

	const allSizeFile = getAllSizeFile();

	const onGoBack = () => {
		navigation.goBack();
	};

	const onPressUpload = () => {
		refModal.current?.show();
	};

	const varFile = (file: IFile) => {
		const name = file?.name || file?.fileName;
		const arrName: string[] = name?.split('.') || [];
		const lastIndex = arrName.length - 1;
		const endName = arrName?.[lastIndex];
		const size = file?.size || file?.fileSize;
		const sizeAddAndFile = allSizeFile + size;

		if (emptyFileExtentions?.length && !emptyFileExtentions?.toString()?.split(',')?.includes(`.${endName}`))
			return {
				continue: false,
				message: `${translate('extension')}${emptyFileExtentions.toString()}`,
			};

		if (limitWeightSingleFile && bytesToMB(size) > limitWeightSingleFile)
			return {
				continue: false,
				message: `${translate('maxSizeFile')} ${limitWeightSingleFile}MB`,
			};

		if (limitWeightAllFiles && bytesToMB(sizeAddAndFile) > limitWeightAllFiles)
			return {
				continue: false,
				message: `${translate('maxAllSizeFile')} ${limitWeightAllFiles}MB`,
			};
		return { continue: true, endName, message: '' };
	};

	const convertFile = (file: IFile) => {
		const name = file?.name || file?.fileName;
		const arrName: string[] = name?.split('.') || [];
		const lastIndex = arrName.length - 1;
		const Extension = arrName?.[lastIndex];
		const Title = arrName?.splice(0, lastIndex)?.toString()?.replaceAll(',', '');

		const Size = file?.size || file?.fileSize;
		const IsAuthor = 1;
		const idLocal = generateRandomId(10);
		const cvFile = { ...file, CreatedName, PositionName, Title, Size, IsAuthor, idLocal, Extension };
		setFiles([...files, cvFile]);
	};

	// eslint-disable-next-line @typescript-eslint/require-await
	const onPressAction = async (type: number) => {
		try {
			refTimeOut.current = setTimeout(async () => {
				switch (type) {
					case 0:
						DocumentPicker.pickSingle({
							copyTo: 'documentDirectory',
						})
							.then(res => {
								const require = varFile(res);

								const realURI = Platform.select({
									android: res.uri,
									ios: decodeURIComponent(res.uri),
								});

								const URI = res.uri.replace('file://', '').replaceAll('%20', ' ').replaceAll('%09', '	');

								if (require.continue) {
									ReactNativeBlobUtil.fs
										.readFile(realURI.replace('file://', ''), 'base64')
										.then(data => {
											convertFile({ ...res, Base64: data, Extension: require.endName });
										})
										.catch(err => {
											Alert.alert('No such file');
										});
								} else {
									Alert.alert(require.message);
								}
							})
							.catch(error => {
								// Alert.alert('error', JSON.stringify(error));
							});
						break;
					case 1:
						const result = await launchImageLibrary({ mediaType: 'photo', includeBase64: true, quality: 1 });
						if (!result.didCancel) {
							const file = result?.assets?.length > 0 ? result.assets?.[0] : null;
							if (!file) break;
							const requireLibrary = varFile(file);
							if (requireLibrary.continue) {
								convertFile(file);
							} else {
							}
						}
						break;
					case 2:
						const result1 = await launchCamera({ mediaType: 'photo', includeBase64: true });
						if (!result1.didCancel) {
							const file1 = result1?.assets?.length > 0 ? result1.assets?.[0] : null;
							if (!file1) break;
							const requireCamera = varFile(file1);
							if (requireCamera.continue) {
								convertFile(file1);
							} else {
								Alert.alert(requireCamera.message);
							}
						}
						break;

					default:
						break;
				}
			}, 300);
		} catch (error) {
			//
		}
	};

	const onPressContinute = (file: IFile) => {
		const clone = [...files];
		const find = clone.findIndex(e => e.idLocal === file.idLocal);
		if (find !== -1) {
			clone[find] = { ...clone[find], ...file };
			setFiles(clone);
		}
	};

	const onAddAttachments = () => {
		if (route.params?.from === 'addWorkflow') {
			route.params?.onCallbackFile(files);
		} else {
			dispatch(
				updateAttachments({
					func: 'add',
					item: files,
				}),
			);
		}
		navigation.goBack();
	};

	const option = `${emptyFileExtentions?.length ? `${translate('extension')} ${emptyFileExtentions.toString()}.` : ''}${limitWeightSingleFile ? ` ${translate('maxSizeFile')} ${limitWeightSingleFile}MB.` : ''
		}${limitWeightAllFiles ? ` ${translate('maxAllSizeFile')} ${limitWeightAllFiles}MB` : ''}`;

	const renderItem = ({ item, index }: { item: IFile; index: number }) => {
		const onDeleteFile = () => {
			SwipeableRef[item?.idLocal]?.close();
			setFiles(files.filter((e, i) => i !== index));
		};

		const onPressEdit = () => {
			SwipeableRef[item?.idLocal]?.close();
			refModalType.current?.show(item);
		};

		const renderRightActions = (
			_progress: Animated.AnimatedInterpolation<string | number>,
			dragX: Animated.AnimatedInterpolation<string | number>,
		) => {
			const transform = dragX.interpolate({
				inputRange: [0, 50],
				outputRange: [0, 0],
			});
			const opacity = dragX.interpolate({
				inputRange: [-50, 0],
				outputRange: [1, 0],
				extrapolate: 'clamp',
			});
			return (
				<Animated.View
					style={[
						{ flexDirection: 'row', zIndex: 99, marginLeft: 10 },
						{ opacity, transform: [{ translateX: transform }] },
					]}>
					<TouchableOpacity
						onPress={onPressEdit}
						style={{
							alignItems: 'center',
							justifyContent: 'center',
							backgroundColor: 'rgba(0, 95, 212, 1)',
							width: 50,
							height: 50,
						}}>
						<Icon src={ICONS.icPencil} width={20} height={20} style={{}} tintColor="white" />
						<Text style={{ color: 'white', fontSize: 11 }}>{translate('edit')}</Text>
					</TouchableOpacity>
					<TouchableOpacity
						onPress={onDeleteFile}
						style={{
							alignItems: 'center',
							justifyContent: 'center',
							backgroundColor: 'rgba(235, 55, 50, 1)',
							width: 50,
							height: 50,
						}}>
						<Icon src={ICONS.icTrash} width={20} height={20} style={{}} tintColor="white" />

						<Text style={{ color: 'white', fontSize: 11, textAlign: 'center' }}>{translate('delete')}</Text>
					</TouchableOpacity>
				</Animated.View>
			);
		};

		return (
			<Swipeable
				ref={ref => (SwipeableRef[item.idLocal] = ref)}
				onSwipeableOpen={() => (refIDSwip.current = item.idLocal)}
				onSwipeableWillClose={() => {
					if (refIDSwip.current === item.idLocal) {
						refIDSwip.current = '';
					}
				}}
				onSwipeableWillOpen={() => SwipeableRef[refIDSwip.current]?.close()}
				renderRightActions={renderRightActions}
				containerStyle={{ height: 50, justifyContent: 'center', marginBottom: 10 }}>
				<View style={{ flexDirection: 'row' }}>
					<Icon src={getIconFile(item?.Extension)} width={18} height={18} style={{ paddingRight: 8 }} />
					<View style={{ flex: 1 }}>
						<TouchableOpacity
							onPress={() => {
								if (item?.uri) {
									FileViewer.open(item?.uri, {
										showOpenWithDialog: true,
									}).catch(() => {
										//
									});
								}
							}}>
							<Text>{item.Title}</Text>
						</TouchableOpacity>
						<View style={{ flexDirection: 'row' }}>
							<Text numberOfLines={1} style={{ fontSize: 12, color: '#7B7B7B', flex: 1 }}>
								{item.CreatedName} {item?.PositionName ? `(${item.PositionName})` : ''}
							</Text>
							<View
								style={{ height: '100%', width: 1, backgroundColor: 'rgba(123, 123, 123, 1)', marginHorizontal: 4 }}
							/>
							<Text style={{ fontSize: 12, color: '#7B7B7B' }} numberOfLines={1}>
								{formatBytes(item?.Size || item?.size)}
							</Text>
						</View>
					</View>
				</View>
			</Swipeable>
		);
	};

	return (
		<View style={styles.container}>
			<View style={[styles.vHeader, { paddingTop: insets.top - 10 }]}>
				<Icon src={ICONS.icArrowMenu} width={24} height={24} onPress={onGoBack} />
				<Text style={styles.tTitle}>{translate('upload')}</Text>
			</View>
			<View style={styles.body}>
				<View style={styles.list}>
					<FlatList data={files} keyExtractor={(item, index) => index?.toString()} renderItem={renderItem} />
				</View>
				<View>
					<View style={styles.vButton}>
						<TouchableOpacity
							disabled={limitWeightAllFiles && bytesToMB(allSizeFile) > limitWeightAllFiles}
							activeOpacity={1}
							onPress={onPressUpload}
							style={[
								styles.bUpload,
								{ opacity: limitWeightAllFiles && bytesToMB(allSizeFile) > limitWeightAllFiles ? 0.5 : 1 },
							]}>
							<Icon src={ICONS.icUpload} width={18} height={18} />
						</TouchableOpacity>

						<Text style={styles.desc}>{translate('attachedDocuments')}</Text>
						{!!option && <Text style={styles.tOption}>{option}</Text>}
					</View>
					<TouchableOpacity
						disabled={!files?.length}
						onPress={onAddAttachments}
						style={[styles.bSubmit, { marginBottom: 30, opacity: !files?.length ? 0.5 : 1 }]}>
						<Text style={styles.tSubmit}>{translate('completed').toLocaleUpperCase()}</Text>
					</TouchableOpacity>
				</View>
			</View>
			<ModalActionUpload ref={refModal} onPressAction={onPressAction} emptyFileExtentions={emptyFileExtentions} />
			<ModalTypeDoc ref={refModalType} onPressContinute={onPressContinute} />
		</View>
	);
};

export default Upload;
