import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
	container: { flex: 1 },
	vHeader: {
		flexDirection: 'row',
		alignItems: 'center',
		paddingHorizontal: 16,
		backgroundColor: 'white',
		paddingBottom: 10,

		shadowColor: '#000',
		shadowOffset: {
			width: 0,
			height: 1,
		},
		shadowOpacity: 0.1,
		shadowRadius: 3.84,
		elevation: 5,
		zIndex: 99,
	},
	tTitle: { fontSize: 16, fontWeight: '700', marginLeft: 10 },
	body: { flex: 1 },
	list: { flex: 1, padding: 16 },
	vButton: {
		alignItems: 'center',
		paddingHorizontal: 48,
		paddingVertical: 20,
		borderTopWidth: 1,
		borderBottomColor: 'rgba(238, 238, 238, 1)',
		borderTopColor: 'rgba(238, 238, 238, 1)',
		borderBottomWidth: 1,
	},
	bUpload: {
		width: 46,
		height: 46,
		backgroundColor: 'rgba(241, 245, 255, 1)',
		borderRadius: 23,
		alignItems: 'center',
		justifyContent: 'center',
	},
	desc: { color: '#555', marginVertical: 2 },
	tOption: { textAlign: 'center', fontSize: 12, color: '#7B7B7B' },
	bSubmit: {
		marginHorizontal: 24,
		alignItems: 'center',
		paddingVertical: 12,
		backgroundColor: 'rgba(0, 95, 212, 1)',
		borderRadius: 8,
		marginTop: 15,
	},
	tSubmit: { color: 'white', fontSize: 16, fontWeight: '600' },
});
