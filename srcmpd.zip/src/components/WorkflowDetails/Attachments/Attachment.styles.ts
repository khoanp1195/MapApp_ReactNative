import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
	bHeader: { backgroundColor: 'rgba(245, 245, 245, 1)' },
	tHeader: { padding: 16, fontSize: 12, fontWeight: '700', color: 'rgba(123, 123, 123, 1)' },
	body: { paddingHorizontal: 16, marginVertical: 8 },
	itemAttach: {
		flexDirection: 'row',
		overflow: 'hidden',
		paddingVertical: 8,
		backgroundColor: 'white',
	},
	vAttach: { flex: 1, marginRight: 20, overflow: 'hidden' },
	vName: { flexDirection: 'row' },
	tName: { fontSize: 12, color: 'rgba(123, 123, 123, 1)', flex: 2.5 },
	vSize: {
		height: '100%',
		width: 1,
		backgroundColor: 'rgba(123, 123, 123, 1)',
		marginHorizontal: 4,
	},
	tSize: { fontSize: 12, color: 'rgba(123, 123, 123, 1)', flex: 1 },
	vDate: { justifyContent: 'center' },
	tDate: { fontSize: 12, color: 'rgba(123, 123, 123, 1)' },
	vIcon: { paddingRight: 12 },
	containerSwipe: { flexDirection: 'row', zIndex: 99, marginLeft: 10 },
	bDelete: {
		alignItems: 'center',
		justifyContent: 'center',
		backgroundColor: 'rgba(235, 55, 50, 1)',
		width: 50,
		height: 50,
	},
	tDelete: { color: 'white', fontSize: 11, textAlign: 'center' },
	bEdit: {
		alignItems: 'center',
		justifyContent: 'center',
		backgroundColor: 'rgba(0, 95, 212, 1)',
		width: 50,
	},
	tEdit: { color: 'white', fontSize: 11 },
	bDown: {
		alignItems: 'center',
		justifyContent: 'center',
		backgroundColor: 'rgba(166, 166, 166, 1)',
		width: 50,
	},
	tDown: { color: 'white', fontSize: 10, textAlign: 'center' },
});
