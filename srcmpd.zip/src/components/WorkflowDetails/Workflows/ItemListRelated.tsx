/* eslint-disable @typescript-eslint/no-unsafe-call */
import React, { memo } from 'react';

import { View, Text, TouchableOpacity } from 'react-native';
import { IRelated } from 'stores/Workflows/types';

import ItemWorkflowRelated from './ItemWorkflowRelated';

const ItemList = ({
	name,
	onHide,
	onDeleteLocal,
	isHide,
	index,
	list,
	isAddWorkflow,
}: {
	name: string;
	onHide: (index: number) => void;
	onDeleteLocal: (data: IRelated) => void;
	isHide: any | undefined;
	index: number;
	list: any[];
	isAddWorkflow: boolean;
}) => {
	return (
		<View>
			<TouchableOpacity
				onPress={() => onHide(index)}
				style={{
					backgroundColor: '#F5F5F5',
					padding: 15,
					flexDirection: 'row',
					alignItems: 'center',
					justifyContent: 'space-between',
				}}>
				<Text numberOfLines={1} style={{ fontSize: 12, fontWeight: '700', color: '#7B7B7B', marginRight: 10 }}>
					{name || 'Other'}
				</Text>
			</TouchableOpacity>
			{isHide === undefined &&
				list?.map((wf, idx) => {
					return (
						<ItemWorkflowRelated
							key={idx?.toString()}
							item={wf}
							index={idx}
							onDeleteLocal={onDeleteLocal}
							length={list?.length}
							isAddWorkflow={isAddWorkflow}
						/>
					);
				})}
		</View>
	);
};

export default memo(ItemList);
