/* eslint-disable @typescript-eslint/no-use-before-define */
/* eslint-disable array-callback-return */
/* eslint-disable react-hooks/exhaustive-deps */
import React, { forwardRef, memo, useCallback, useEffect, useImperativeHandle, useState } from 'react';

import { View, Text, FlatList, Platform, StyleSheet } from 'react-native';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateRelated } from 'stores/Workflows/sliceWorkflow';
import { IRelated } from 'stores/Workflows/types';
import { quickSort } from 'utils/functions';
import { translate } from 'utils/translate';

import ItemListRelated from './ItemListRelated';

interface IListWorkflow {
	WorkflowId: number;
	name: string;
	list: Array<IRelated>;
}

const Workflow = (
	{ ID, isAddWorkflow, refreshing }: { ID?: number; isAddWorkflow?: boolean; refreshing?: boolean },
	ref: React.Ref<unknown> | undefined,
) => {
	const dispactch = useAppDispatch();

	const [relatedState, setRelatedState] = useState<IRelated[]>([]);
	const [listWorkflow, setListWorkflow] = useState<IListWorkflow[]>([]);
	const [indexHide, setIndexHide] = useState<number[]>([]);

	const relatedRedux = useAppSelector(store => store.workflow.related);

	const related = !isAddWorkflow ? relatedRedux : relatedState;

	const sortList = useCallback(
		list => {
			const clone = JSON.parse(JSON.stringify(list));
			return quickSort(clone);
			// return clone?.sort(compareTypes);
		},
		[related],
	);

	useEffect(() => {
		if (refreshing) {
			setIndexHide([]);
		}
	}, [refreshing]);

	useEffect(() => {
		let list: IListWorkflow[] = [];
		related?.map(e => {
			const isIndexWorkflow = list?.findIndex(item => item.WorkflowId === e.WorkflowId);
			if (isIndexWorkflow === -1) {
				list = [...list, { WorkflowId: e.WorkflowId, list: [e], name: e.Workflow }];
			} else {
				list[isIndexWorkflow].list.push(e);
			}
		});
		const listSort: IListWorkflow[] = sortList(list || []);
		setListWorkflow(listSort);
	}, [related]);

	const getIdSeleted = () => {
		const listClone = listWorkflow;

		let listID: string = ID?.toString() || '';

		listClone.forEach(data => {
			data.list.forEach(item => {
				listID = listID.concat(`,${item.ID}`);
			});
		});

		return listID;
	};

	const onDeleteLocal = useCallback(
		(data: IRelated) => {
			if (isAddWorkflow) {
				setRelatedState(related.filter(elm => elm.ID !== data.ID));
			} else {
				dispactch(
					updateRelated({
						func: 'delete',
						item: data,
					}),
				);
			}
		},
		[related],
	);

	const setSelectWorkFlow = (data: Array<IRelated>) => {
		let list = [...listWorkflow];
		data?.map(e => {
			const isIndexWorkflow = list?.findIndex(item => item.WorkflowId === e.WorkflowId);
			if (isIndexWorkflow === -1) {
				list = [...list, { WorkflowId: e.WorkflowId, list: [e], name: e.Workflow }];
			} else {
				list[isIndexWorkflow].list.push(e);
			}
		});

		setListWorkflow([...list]);
	};

	const getListWorkflowRelated = () => {
		let request: Array<{
			ID: number;
			ListID: string;
			WorkflowId: number;
			Title: string;
		}> = [];
		listWorkflow.forEach(data => {
			data.list.forEach(item => {
				if (!item?.WorkflowRelatedId) {
					request = [
						...request,
						{
							ID: item.ID,
							ListID: item?.ListID,
							WorkflowId: item?.WorkflowId,
							Title: item?.Title,
						},
					];
				}
			});
		});
		return request;
	};

	const addRelated = (data: IRelated[]) => {
		setRelatedState([...relatedState, ...data]);
	};

	const getRelated = () => relatedState;

	useImperativeHandle(
		ref,
		() => ({
			setData: setSelectWorkFlow,
			getIdSeleted,
			getListWorkflowRelated,
			updateRelated: addRelated,
			getRelated,
		}),
		[listWorkflow, relatedState],
	);

	const getItemLayout = (_: any, index: number) => ({
		length: 90,
		offset: 90 * index,
		index,
	});

	const onHide = (index: number) => {
		const isHide = indexHide.find(e => e === index);
		if (isHide === undefined) {
			setIndexHide(indexHide.concat(index));
			return;
		}

		setIndexHide(indexHide.filter(e => e !== index));
	};

	const renderItem = ({ item, index }: { item: IListWorkflow; index: number }) => {
		const isHide = indexHide.find(e => e === index);
		const { name = '', list = [] } = item || {};
		return (
			<ItemListRelated
				name={name}
				list={list}
				onHide={onHide}
				onDeleteLocal={onDeleteLocal}
				index={index}
				isHide={isHide}
				isAddWorkflow={!!isAddWorkflow}
			/>
		);
	};

	const keyExtractor = (_item: unknown, index: number) => index?.toString();

	const isIos = Platform.OS !== 'ios';
	const isEmpty = !listWorkflow.length && !isAddWorkflow;
	const isRelated = !!isAddWorkflow && !!listWorkflow.length;

	return (
		<View style={styles.container}>
			{isEmpty && <Text style={styles.tTitle}>{translate('noWorkflowRelated')}</Text>}
			{isRelated && <Text style={styles.tRelated}>{translate('related')}</Text>}
			<FlatList
				getItemLayout={getItemLayout}
				scrollEnabled={false}
				renderToHardwareTextureAndroid
				removeClippedSubviews={isIos}
				data={listWorkflow}
				keyExtractor={keyExtractor}
				renderItem={renderItem}
				contentContainerStyle={styles.contentContainerStyle}
				windowSize={20}
				initialNumToRender={10}
			/>
		</View>
	);
};

export default memo(forwardRef(Workflow));

const styles = StyleSheet.create({
	container: { marginBottom: 20 },
	tTitle: { fontSize: 12, fontStyle: 'italic', textAlign: 'center', paddingTop: 10 },
	tRelated: {
		fontSize: 12,
		paddingTop: 20,
		color: '#7B7B7B',
		marginBottom: 3,
		fontWeight: '400',
		marginHorizontal: 16,
		paddingBottom: 8,
	},
	contentContainerStyle: { borderRadius: 4 },
});
