/* eslint-disable array-callback-return */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import React, { memo, useRef } from 'react';

import { useNavigation, StackActions } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import FImage from 'components/Organisms/FImage/FImage';
import { COLOR_STATUS, COLOR_TEXT_STATUS } from 'config';
import dayjs from 'dayjs';
import useSystem from 'hooks/useSystem';
import { RoutesNames } from 'navigation/RoutesNames';
import { View, Text, TouchableOpacity, LayoutAnimation, Animated } from 'react-native';
import { TouchableWithoutFeedback } from 'react-native-gesture-handler';
import Swipeable from 'react-native-gesture-handler/Swipeable';
import { useAppDispatch, useAppSelector } from 'stores';
import { postDeleteWorkflowRelated } from 'stores/Workflows/sliceWorkflow';
import { IRelated } from 'stores/Workflows/types';
import { translate } from 'utils/translate';

interface IRenderItem {
	item: IRelated;
	index: number;
	onDeleteLocal: (item: IRelated) => void;
	length?: number;
	isAddWorkflow: boolean;
}

const ItemWorkflowRelated = ({ item, index, onDeleteLocal, length = 0, isAddWorkflow }: IRenderItem) => {
	const navigation = useNavigation();
	const dispactch = useAppDispatch();
	const { formatDateTime, isVN } = useSystem();

	const SwipeableRef = useRef({});
	const refIDSwip = useRef<number | string>();

	const { beanAppStatus } = useAppSelector(state => state.system);
	const {
		ImagePath,
		DefaultImagePath,
		Content,
		Created,
		StatusGroup,
		WorkflowRelatedId = null,
		AssignedToInfo = '',
		CreatedByInfo = '',
	} = item;

	const ValueUser = AssignedToInfo || CreatedByInfo || '{}';

	const Assigned: { ImagePath: string; DefaultImagePath: string } = JSON.parse(!WorkflowRelatedId ? ValueUser : '{}');

	const Time = Created ? dayjs(Created).format(formatDateTime) : '';
	const statusGroupItem = beanAppStatus?.find(v => v.ID === StatusGroup);
	const details = useAppSelector(store => store.workflow.details);
	const isAllow =
		isAddWorkflow ||
		details?.FormConfig?.IsAdmin ||
		details?.FormConfig?.AllowRelatedEdit ||
		details?.FormConfig?.IsCreatedByMe;

	// const isAllow = details?.FormConfig?.IsAdmin || details?.FormConfig?.IsCreatedByMe;

	const renderRightActions = (_progress: unknown, dragX: Animated.AnimatedInterpolation<string | number>) => {
		if (!isAllow) return null;
		const transform = dragX.interpolate({
			inputRange: [0, 50, 100, 101],
			outputRange: [0, 0, 0, 1],
		});
		const opacity = dragX.interpolate({
			inputRange: [-150, 0],
			outputRange: [1, 1],
			extrapolate: 'clamp',
		});

		const onPressDelete = () => {
			SwipeableRef[item.ID]?.close();

			if (!item.WorkflowRelatedId) {
				onDeleteLocal(item);
			} else {
				dispactch(
					postDeleteWorkflowRelated({
						params: {
							workflowrelatedid: item?.WorkflowRelatedId,
						},
						success: () => onDeleteLocal(item),
					}),
				);
			}
			LayoutAnimation.easeInEaseOut();
		};

		return (
			<Animated.View
				style={[
					{ flexDirection: 'row', zIndex: 1 },
					{ opacity, transform: [{ translateX: transform }] },
				]}>
				<TouchableOpacity
					onPress={onPressDelete}
					style={{ alignItems: 'center', justifyContent: 'center', backgroundColor: '#EB342E', width: 44 }}>
					<Text style={{ color: 'white' }}>{translate('delete')}</Text>
				</TouchableOpacity>
			</Animated.View>
		);
	};

	const handleNavigateToDetail = () => {
		if (!item.WorkflowRelatedId) return;
		navigation.dispatch(StackActions.replace(RoutesNames.WorkflowDetails, { item, isScrollToTop: true }));
	};

	const onSwipeableOpen = () => (refIDSwip.current = item.ID);

	const onSwipeableWillClose = () => {
		if (refIDSwip.current === item.ID) {
			refIDSwip.current = null;
		}
	};

	const onSwipeableWillOpen = () => SwipeableRef[refIDSwip.current]?.close();

	const setRef = ref => (SwipeableRef[item.ID] = ref);

	return (
		<Swipeable
			renderRightActions={renderRightActions}
			ref={setRef}
			onSwipeableOpen={onSwipeableOpen}
			onSwipeableWillClose={onSwipeableWillClose}
			onSwipeableWillOpen={onSwipeableWillOpen}>
			<TouchableWithoutFeedback
				onPress={handleNavigateToDetail}
				style={{
					alignItems: 'center',
					justifyContent: 'center',
					paddingTop: 15,
					backgroundColor: 'white',
				}}>
				<View style={{ flexDirection: 'row', marginHorizontal: 16 }}>
					<FImage
						ImagePath={ImagePath || Assigned?.ImagePath}
						DefaultImagePath={DefaultImagePath || Assigned?.DefaultImagePath}
						mh={0}
					/>

					<View style={{ flex: 1, marginLeft: 9 }}>
						<View style={{ flexDirection: 'row' }}>
							<View style={{ flex: 1, justifyContent: 'center' }}>
								<Text numberOfLines={3} style={{ fontSize: 14, fontWeight: '400' }}>
									{Content}
								</Text>
							</View>
							<View style={{ alignItems: 'flex-end' }}>
								<Text style={{ fontSize: 12, fontWeight: '400', color: '#5E5E5E' }}>{Time}</Text>
								<View
									style={{
										width: 120,
										backgroundColor: COLOR_STATUS?.[StatusGroup] || COLOR_STATUS[1],
										paddingVertical: 4,
										alignItems: 'center',
										borderRadius: 3,
										marginTop: 4,
									}}>
									<Text style={{ fontSize: 12, fontWeight: '400', color: COLOR_TEXT_STATUS[StatusGroup] }}>
										{isVN ? statusGroupItem?.Title : statusGroupItem?.TitleEN}
									</Text>
								</View>
							</View>
						</View>
						<View
							style={{
								height: index !== length - 1 ? 1 : 0,
								backgroundColor: 'rgba(238, 238, 238, 1)',
								width: '100%',
								marginTop: 15,
							}}
						/>
					</View>
				</View>
			</TouchableWithoutFeedback>
		</Swipeable>
	);
};

export default memo(ItemWorkflowRelated);
