import React, { forwardRef, useRef, useState, useImperativeHandle, useEffect, memo } from 'react';

import { useNavigation } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import ModalRef from 'components/Molecules/Modal/ModalRef';
import { ICONS } from 'config/images';
import useSystem from 'hooks/useSystem';
import { navigate } from 'navigation/RootNavigation';
import { RoutesNames } from 'navigation/RoutesNames';
import { View, TouchableOpacity, Text, Dimensions, TextInput, Modal, FlatList } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { IItemParams } from 'screens/WorkflowDetails/WorkflowDetails';
import { translate } from 'utils/translate';

import { IListAction } from '../ActionButton';

const ModalRelated = (
	{ WorkflowStepRelate = [], itemPrams }: { WorkflowStepRelate: any[]; itemPrams: IItemParams },
	ref: React.Ref<unknown> | undefined,
) => {
	const navigation = useNavigation();
	const refModal = useRef<{ show: () => void; hide: () => void } | null>(null);
	const { isVN } = useSystem();
	const refSubmit = useRef(false);
	const insets = useSafeAreaInsets();

	const [action, setAction] = useState();
	const [select, setSelect] = useState();

	useEffect(() => {
		if (WorkflowStepRelate?.length) {
			setSelect(WorkflowStepRelate[0]);
		}
	}, [WorkflowStepRelate]);

	const show = e => {
		setAction(e);
		refModal.current?.show();
	};
	const hide = () => refModal.current?.hide();

	const onHide = () => {
		if (refSubmit.current) {
			refSubmit.current = false;
			navigation.replace(RoutesNames.AddWorkflow, { item: select, itemRelated: itemPrams });
		}
	};

	useImperativeHandle(
		ref,
		() => ({
			show,
			hide,
		}),
		[],
	);

	return (
		<ModalRef
			ref={refModal}
			onHide={onHide}
			outsideClickCloseable
			onClose={hide}
			visiblePosition="bottom"
			container={{ backgroundColor: 'white' }}
			isTouch={false}>
			<View style={{ paddingHorizontal: 24, paddingBottom: 20, minHeight: 280, maxHeight: 700 }}>
				<Text style={{ fontSize: 16, fontWeight: '700', paddingVertical: 24 }}>{action?.Title}</Text>
				<FlatList
					showsVerticalScrollIndicator={false}
					data={WorkflowStepRelate || []}
					keyExtractor={(item, index) => index?.toString()}
					renderItem={({ item, index }) => {
						const isSl = item?.ID === select?.ID;
						return (
							<View style={{ paddingHorizontal: 8 }}>
								<TouchableOpacity
									activeOpacity={1}
									style={{
										flexDirection: 'row',
										alignItems: 'center',
										backgroundColor: isSl ? '#DBEBFF' : 'white',
										padding: 10,
										borderRadius: 8,
									}}
									onPress={() => {
										if (isSl) {
											// setSelect();
										} else {
											setSelect(item);
										}
									}}>
									<Icon
										src={isSl ? ICONS.icCheckUser : ICONS.icUnCheckUser}
										width={20}
										height={20}
										style={{ marginRight: 8 }}
									/>
									<Text style={{ marginBottom: 2 }}>{isVN ? item?.Title : item?.TitleEN}</Text>
								</TouchableOpacity>
							</View>
						);
					}}
				/>
				<View style={{ flexDirection: 'row' }}>
					<TouchableOpacity
						onPress={() => hide()}
						style={{
							flex: 1,
							borderRadius: 8,
							borderColor: 'rgba(157, 157, 157, 1)',
							borderWidth: 1,
							alignItems: 'center',
							paddingVertical: 10,
							marginRight: 8,
						}}>
						<Text style={{ fontWeight: '600' }}>{translate('close').toLocaleUpperCase()}</Text>
					</TouchableOpacity>
					<TouchableOpacity
						onPress={() => {
							hide();
							refSubmit.current = true;
						}}
						disabled={!select}
						style={{
							flex: 1,
							borderRadius: 8,
							backgroundColor: 'rgba(0, 95, 212, 1)',
							alignItems: 'center',
							paddingVertical: 10,
							marginLeft: 8,
						}}>
						<Text style={{ color: 'white', fontWeight: '600' }}>{translate('continue').toLocaleUpperCase()}</Text>
					</TouchableOpacity>
				</View>
			</View>
		</ModalRef>
	);
};

export default forwardRef(ModalRelated);
