/* eslint-disable prettier/prettier */
import React, { forwardRef, useRef, useState, useImperativeHandle, useEffect, memo } from 'react';

import { useNavigation } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import ModalRef from 'components/Molecules/Modal/ModalRef';
import { COLORS } from 'config/colors';
import { ICONS } from 'config/images';
import { View, TouchableOpacity, Text, Dimensions, TextInput } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { translate } from 'utils/translate';

import { IListAction } from '../ActionButton';

const hideChooseUser = (ActionCode: string) => {
	switch (ActionCode) {
		case 'SAVE': // Lưu
			return true;
		case 'IDEA': // Cho ý kiến
			return false;
		case 'APPROVE': // Phê duyệt
			return false;
		case 'NEXT': // Đồng ý
			return false;
		case 'RETURN': // Yêu cầu hiêụ chỉnh
			return false;
		case 'TASK': // Phân công
			return true;
		case 'REPLACE': // Chuyển xử lý
			return true;
		case 'ADDINFO': // Bổ sung thông tin
			return true;
		case 'REQUESTIDEA': // Yêu câù tham vấn
			return true;
		case 'RECALL': // Thu hồi
			return false;
		case 'CANCEL': // Huỷ
			return false;
		case 'REJECT': // Từ chối
			return false;
		case 'SEND': // Gửi
			return true;

		default:
			return true;
	}
};

export const BoxUser = memo(({ err = false, user, searchUser, setUser, index = 1, icon = ICONS.icUserAdd, KeyFeild, fullText = false, isSearhUser = false }) => {
	if (!Array.isArray(user)) return null
	const { width } = Dimensions.get('window');
	return <TouchableOpacity activeOpacity={1} onPress={searchUser} style={{
		flexDirection: 'row',
		borderRadius: 8,
		borderColor: err && !user?.length ? COLORS.red : 'rgba(217, 217, 217, 1)',
		borderWidth: 1,
		padding: 7,
	}}>
		<View style={{ flex: 1, flexWrap: 'wrap', flexDirection: 'row', overflow: 'hidden', }}>
			{user?.length ? (
				user?.map((item, i) => {
					const { Name, Title, NoiDung, [KeyFeild]: Special = '', FullName } = item || {}
					const LastName = typeof item !== 'string' ? Special || Name || Title || NoiDung || FullName : item
					const onDeleteUser = () => {
						setUser(user.filter((e, ie) => ie !== i))
					}

					return <View key={i?.toString()} style={{
						backgroundColor: 'rgba(240, 240, 240, 0.7)',
						borderRadius: 20,
						padding: 4,
						marginRight: 10 / index,
						marginVertical: 2,
						flexDirection: 'row',
						alignItems: 'center',
						justifyContent: 'space-between'
					}}>
						<View style={{ flexDirection: 'row', alignItems: 'center', maxWidth: index > 1 ? width / (index > 2 ? (6 + index * 2) : 4.3) : width / 2, }}>
							<Text numberOfLines={fullText ? 0 : 1} style={{ marginLeft: 4, marginRight: 1 }}>{LastName}</Text>
						</View>

						<Icon src={ICONS.icCancelGrey} width={16} height={16} onPress={onDeleteUser} />
					</View>
				})
			) : <Text numberOfLines={1} style={{ color: 'rgba(157, 157, 157, 1)', marginTop: 4 }}>{!isSearhUser ? '' : translate('enterUser')}</Text>}



		</View>
		<Icon src={icon} width={24} height={24} onPress={searchUser} style={{ marginTop: 2 }} />
	</TouchableOpacity>
})


const ModalAction = ({ onSearchUser, onSubmitAction = () => { } }: any, ref: React.Ref<unknown> | undefined) => {
	const refModal = useRef<{ show: () => void; hide: () => void } | null>(null);
	const refSubmit = useRef(false)
	const refInput = useRef()
	const insets = useSafeAreaInsets();

	const [action, setAction] = useState({
		ActionCode: "",
		Class: "",
		ID: "",
		Index: "",
		Title: "",
	})

	const [user, setUser] = useState([])
	const [idea, setIdea] = useState('')
	const [err, setErr] = useState(false)


	const show = (item: IListAction, user) => {
		setUser(user || [])
		setAction(item)
		setErr(false)
		refModal.current?.show()
	}
	const hide = () => refModal.current?.hide()

	useEffect(() => {
		setIdea('')
	}, [action.ActionCode])

	useImperativeHandle(
		ref,
		() => ({
			show,
			hide
		}),
		[],
	);

	const searchUser = () => {
		hide()
		onSearchUser(action, user)
	}

	const isHideChooseUser = hideChooseUser(action.ActionCode);

	const onHide = () => {

		if (refSubmit.current) {
			onSubmitAction(action, user, idea)
			setErr(false)
			setIdea('')
			refSubmit.current = false
		}
	}



	return <ModalRef
		ref={refModal}
		onHide={onHide}
		outsideClickCloseable
		onClose={hide}
		visiblePosition="bottom"
		container={{ backgroundColor: 'white' }}
		isTouch={false}
	>
		<View style={{ paddingHorizontal: 24, paddingBottom: 20 }}>
			<Text style={{ fontSize: 16, fontWeight: '700', paddingVertical: 24 }}>{action.Title}</Text>
			<View style={{ marginBottom: 20 }}>
				{isHideChooseUser && <BoxUser user={user} setUser={setUser} searchUser={searchUser} err={err} isSearhUser fullText />}
				{err && !user.length && isHideChooseUser &&
					<Text style={{ fontSize: 12, color: COLORS.red, fontStyle: 'italic' }}>{translate('userRequired')}</Text>}
			</View>
			<TouchableOpacity onPress={() => refInput.current?.focus()} activeOpacity={1} style={{
				borderRadius: 8,
				borderColor: err && !idea?.trim().length ? COLORS.red : 'rgba(217, 217, 217, 1)',
				borderWidth: 1,
				minHeight: 124,
				// marginBottom: 20,
				padding: 10
			}}>
				<TextInput ref={refInput} maxLength={255} value={idea} multiline placeholder={action.ActionCode === 'REJECT' ? translate('reasonReject') : translate('enterIdea')} style={{}} onChangeText={setIdea} />
			</TouchableOpacity>
			<View style={{ marginBottom: 20, marginTop: 2 }}>
				{err && !idea?.trim()?.length && <Text style={{ fontSize: 12, color: COLORS.red, fontStyle: 'italic' }}>{translate('opinionRequired')}</Text>}
			</View>
			<View style={{ flexDirection: 'row', }}>
				<TouchableOpacity onPress={() => {
					setIdea('')
					hide()
				}} style={{
					flex: 1,
					borderRadius: 8,
					borderColor: 'rgba(157, 157, 157, 1)',
					borderWidth: 1,
					alignItems: 'center',
					paddingVertical: 10,
					marginRight: 8
				}}>
					<Text style={{ fontWeight: '600' }}>{translate('close').toLocaleUpperCase()}</Text>
				</TouchableOpacity>
				<TouchableOpacity onPress={() => {
					if (!user?.length && isHideChooseUser) return setErr(true)
					if (!idea?.trim() && !['NEXT', 'APPROVE']?.includes(action.ActionCode)) return setErr(true)
					hide()
					refSubmit.current = true
				}}
					style={{
						flex: 1,
						borderRadius: 8,
						backgroundColor: action.ActionCode === 'REJECT' ? 'rgba(235, 55, 50, 1)' : 'rgba(0, 95, 212, 1)',
						alignItems: 'center',
						paddingVertical: 10,
						marginLeft: 8
					}}>
					<Text style={{ color: 'white', fontWeight: '600' }}>{translate('completed').toLocaleUpperCase()}{action.ActionCode === 'REJECT' ? ` ${action.Title.toLocaleUpperCase()}` : ''}</Text>
				</TouchableOpacity>
			</View>
		</View>
	</ModalRef >
}

export default forwardRef(ModalAction)
