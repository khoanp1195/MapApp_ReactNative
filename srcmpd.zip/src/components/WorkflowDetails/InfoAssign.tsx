import React, { forwardRef, useImperativeHandle, useRef } from 'react';

import { Text } from '@react-native-material/core';
import { Icon } from 'components/Atoms/Icon';
import { refDropDown } from 'components/Atoms/Loading/DropDown';
import FImage from 'components/Organisms/FImage/FImage';
import { COLOR_STATUS, COLOR_TEXT_STATUS } from 'config/colors';
import { ICONS } from 'config/images';
import dayjs from 'dayjs';
import useSystem from 'hooks/useSystem';
import { Animated, Easing, TouchableOpacity, View } from 'react-native';
import { useAppSelector } from 'stores';
import { translate } from 'utils/translate';

const InfoAssign = ({ loadingDetails }, ref) => {
	const { isVN, formatDateTime } = useSystem();
	const scrollY = useRef(new Animated.Value(0)).current;

	const details = useAppSelector(store => store.workflow.details);

	const { beanAppStatus } = useAppSelector(store => store.system);

	const {
		ItemInfo: { Author = [] } = {},
		FormConfig: { StatusGroup = 0, AssignedToInfo = '[]', Content = '', Created, DueDate } = {},
	} = details;

	const listAssignedToInfo = JSON.parse(AssignedToInfo || '[]');

	const ScrollY = (y: number) => {
		Animated.timing(scrollY, { toValue: y, duration: 0, easing: Easing.ease, useNativeDriver: true }).start();
	};

	useImperativeHandle(
		ref,
		() => ({
			ScrollY,
		}),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[],
	);

	const getDateTimeCreated = () => {
		return dayjs(Created).format(formatDateTime) || '';
	};

	const getDueDate = () => {
		const date1 = dayjs(DueDate);
		const date2 = dayjs();

		const minute = date1.diff(date2, 'minute');

		const hours = minute / 60;

		const days = Math.floor((hours > 0 ? hours : hours * -1) / 24);

		if (days > 7)
			return {
				title: `${dayjs(DueDate).format(formatDateTime)}`,
				color: 'rgba(123, 123, 123, 1)',
				bgr: 'rgba(123, 123, 123, 0.2)',
			};

		if (days === 0)
			return { title: translate('to_day'), color: 'rgba(139, 79, 183, 1)', bgr: 'rgba(139, 79, 183, 0.2)' };
		if (hours < 0)
			return { title: `${days} ${translate('days')}`, color: 'rgba(237, 78, 73, 1)', bgr: 'rgba(237, 78, 73, 0.2)' };
		if (hours > 0)
			return {
				title: `${days} ${translate('days')}`,
				color: 'rgba(123, 123, 123, 1)',
				bgr: 'rgba(123, 123, 123, 0.2)',
			};
	};

	const duedate = getDueDate();

	const status = beanAppStatus?.find(v => v.ID === StatusGroup);

	const convertAssignedTo = () => {
		let user: string[] = [];
		listAssignedToInfo?.map(item => {
			user = [...user, item.Name];
		});

		return {
			name: user?.length ? user[0] : '',
			number: user?.length > 1 ? user?.length - 1 : '',
		};
	};

	const opacity = scrollY.interpolate({
		inputRange: [0, 120],
		outputRange: [1, 0],
		extrapolate: 'clamp',
	});

	const opacity2 = scrollY.interpolate({
		inputRange: [0, 60],
		outputRange: [1, 0],
		extrapolate: 'clamp',
	});

	const scale = scrollY.interpolate({
		inputRange: [0, 120],
		outputRange: [1, 0.2],
		extrapolate: 'clamp',
	});

	const infoAssignedTo = convertAssignedTo();

	if (loadingDetails) return null;

	return (
		<Animated.View style={{ paddingHorizontal: 16, backgroundColor: 'white', opacity, zIndex: 100 }}>
			<Animated.Text
				numberOfLines={2}
				ellipsizeMode="head"
				style={{
					fontSize: 16,
					fontWeight: '700',
					lineHeight: 24,
					opacity: opacity2,
					transform: [{ scale }],
					marginTop: 4,
				}}>
				{Content}
				{'  '}
				<View
					style={[
						{
							backgroundColor: COLOR_STATUS[StatusGroup],
							borderRadius: 4,
							alignItems: 'center',
							justifyContent: 'center',
							minWidth: 120,
							padding: 3,
							marginBottom: -1,
						},
					]}>
					<Text style={{ fontSize: 12, fontWeight: '400', color: COLOR_TEXT_STATUS[StatusGroup] }}>
						{isVN ? status?.Title : status?.TitleEN}
					</Text>
				</View>
				<Text> </Text>
				{!!duedate && (
					<View
						style={{
							backgroundColor: duedate.bgr,
							borderRadius: 4,
							alignItems: 'center',
							justifyContent: 'center',
							padding: 3,
							minWidth: 70,
							marginBottom: -1,
							paddingHorizontal: 10,
						}}>
						<Text style={{ fontSize: 12, fontWeight: '400', color: getDueDate()?.color }}>{getDueDate()?.title}</Text>
					</View>
				)}
			</Animated.Text>
			<View style={{ flexDirection: 'row', marginVertical: 15, width: '100%' }}>
				<FImage mh={0} ImagePath={Author?.ImagePath} DefaultImagePath="" />
				<View style={{ flex: 1, marginLeft: 10 }}>
					<View style={{ flexDirection: 'row', justifyContent: 'center' }}>
						<View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', overflow: 'hidden' }}>
							<Text numberOfLines={1} style={{ fontSize: 14, fontWeight: '400', marginRight: 10, maxWidth: '55%' }}>
								{Author?.[0]?.Name || ''}
							</Text>
							<Text style={{ fontSize: 12, fontWeight: '500', color: 'rgba(123, 123, 123, 1)' }}>
								{getDateTimeCreated()}
							</Text>
						</View>
					</View>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
						}}>
						{!!infoAssignedTo?.name && (
							<Text
								numberOfLines={1}
								style={{
									fontSize: 12,
									fontWeight: '400',
									color: 'rgba(123, 123, 123, 1)',
									// flex: 1,
								}}>
								{translate('receiver')} {infoAssignedTo.number ? `${infoAssignedTo.name}, ` : infoAssignedTo.name}
							</Text>
						)}
						<TouchableOpacity
							style={{}}
							onPress={event => {
								event.target.measure((x, y, width, height, pageX, pageY) => {
									refDropDown.current?.show(
										{
											top: pageY,
											left: pageX,
											heightItem: listAssignedToInfo?.length * 30,
										},
										<View style={{}}>
											{listAssignedToInfo.map((item, index) => {
												return (
													<TouchableOpacity
														onPress={() => refDropDown.current?.hide()}
														key={index.toString()}
														style={{
															marginVertical: 5,
															flexDirection: 'row',
															alignItems: 'center',
															height: 30,
															paddingLeft: 20,
															overflow: 'hidden',
														}}>
														<Text numberOfLines={2}>{item.Name}</Text>
													</TouchableOpacity>
												);
											})}
										</View>,
									);
								});
							}}>
							<Text
								style={{
									fontSize: 12,
									fontWeight: '400',
									color: 'rgba(0, 95, 212, 1)',
									flex: 1,
								}}>
								{infoAssignedTo.number ? `+${infoAssignedTo.number}` : ''}
							</Text>
						</TouchableOpacity>
					</View>
				</View>
			</View>
		</Animated.View>
	);
};
export default forwardRef(InfoAssign);
