import React from 'react';

import { View, FlatList } from 'react-native';

const AssignTask = ({ }) => {
	return (
		<View>
			<FlatList
				scrollEnabled={false}
				onEndReachedThreshold={16}
				data={[1, 2, 3, 4, 5, 6, 7, 8, 9]}
				keyExtractor={item => item.toString()}
				renderItem={() => {
					return <View style={{ height: 100, marginBottom: 20, backgroundColor: 'rgba(219, 235, 255, 0.5)' }} />;
				}}
			/>
		</View>
	);
};

export default AssignTask;
