import React from 'react';

import { View, FlatList } from 'react-native';

const Infomation = ({ onScroll = () => { } }) => {
	return (
		<View>
			<FlatList
				scrollEnabled={false}
				scrollEventThrottle={16}
				onScroll={onScroll}
				data={[1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12]}
				keyExtractor={item => item.toString()}
				renderItem={() => {
					return <View style={{ height: 100, marginBottom: 20, backgroundColor: 'rgba(219, 235, 255, 0.5)' }} />;
				}}
			/>
		</View>
	);
};

export default Infomation;
