import React, { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';

import { Icon } from 'components/Atoms/Icon';
import { ICONS } from 'config/images';
import useDebounce from 'hooks/useDebounce';
import { View, Text, LayoutAnimation } from 'react-native';

const STATUS = {
	1: {
		title: 'WARNING',
		color: 'rgba(228, 228, 228, 1)',
		icon: ICONS.icCheckBlack,
		textColor: 'rgba(17, 17, 17, 1)',
	},
	2: {
		title: 'SUCCESS',
		color: 'rgba(220, 255, 218, 1)',
		icon: ICONS.icCheckBlack,
		textColor: 'rgba(17, 17, 17, 1)',
	},
	3: {
		title: 'ERROR',
		color: 'rgba(235, 55, 50, 1)',
		icon: null,
		textColor: 'white',
	},
};

const ToastWorkflow = ({ }, ref) => {
	const [show, setShow] = useState(false);
	const [data, setData] = useState({
		status: 0,
		message: '',
	});

	const handleShow = data => {
		setData(data);
		setShow(true);
	};

	useImperativeHandle(
		ref,
		() => ({
			show: handleShow,
		}),
		[],
	);

	useEffect(() => {
		// let timer = setTimeout(() => {
		// 	setShow(false);
		// 	LayoutAnimation.easeInEaseOut();
		// }, 3000);
		// clearTimeout(timer);
		const timer = setTimeout(() => {
			setShow(false);
			// LayoutAnimation.easeInEaseOut();
		}, 2000);
		return () => timer && clearTimeout(timer);
	}, [show]);

	if (!show) return null;

	const info = STATUS[data?.status as 1 | 2 | 3];
	return (
		<View
			style={{
				// position: 'absolute',
				backgroundColor: info.color,
				zIndex: 1001,
				// bottom: 82,
				width: '100%',
				flexDirection: 'row',
				paddingHorizontal: 16,
				paddingTop: 16,
				paddingBottom: 16,
				alignItems: 'flex-start',
			}}>
			{!!info?.icon && <Icon src={info.icon} width={18} height={18} style={{ marginRight: 8 }} />}
			<Text style={{ color: info.textColor, flex: 1, marginRight: 16 }}>{data?.message}</Text>
			<Icon
				src={ICONS.icRemove}
				width={24}
				height={24}
				tintColor={info.textColor}
				onPress={() => {
					setShow(false);
					LayoutAnimation.easeInEaseOut();
				}}
			/>
		</View>
	);
};

export default forwardRef(ToastWorkflow);
