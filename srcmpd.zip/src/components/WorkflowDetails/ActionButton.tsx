/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable react/no-children-prop */
/* eslint-disable react/jsx-props-no-spreading */
import React from 'react';

import { Icon } from 'components/Atoms/Icon';
import { refDropDown } from 'components/Atoms/Loading/DropDown';
import { ICONS } from 'config/images';
import { View, TouchableOpacity, Text } from 'react-native';
import { translate } from 'utils/translate';

export interface IListAction {
	ID: string;
	ActionCode: string;
	Title: string;
	Class: string;
	Index: string;
}

const ActionButton = ({
	ListAction,
	onPressCallAction,
	loadingDetails,
}: {
	ListAction: IListAction[];
	onPressCallAction: (item: IListAction) => void;
	loadingDetails: boolean;
}) => {
	const getInfoAction = (ActionCode: string) => {
		switch (ActionCode) {
			case 'SAVE':
				return {
					icon: ICONS.icDisk,
					color: '#005FD4',
				};
			case 'IDEA':
				return {
					icon: ICONS.icChatAction,
					color: '#8608EA',
				};
			case 'APPROVE':
				return {
					icon: ICONS.icCheckCircle,
					color: '#34A853',
					textColor: '#34A853',
				};
			case 'NEXT':
				return {
					icon: ICONS.icCheckRectangle,
					color: '#34A853',
				};
			case 'RETURN':
				return {
					icon: ICONS.icPostAdd,
					color: '#EB3732',
					textColor: '#EB3732',
				};
			case 'TASK':
				return {
					icon: ICONS.icFolderShare,
					color: '#005FD4',
				};
			case 'REPLACE':
				return {
					icon: ICONS.icShareRectangle,
					color: '#34A853',
				};
			case 'ADDINFO':
				return {
					icon: ICONS.icPencilBook,
					color: '#DBA410',
				};
			case 'REQUESTIDEA':
				return {
					icon: ICONS.icQuiz,
					color: '#8608EA',
				};
			case 'RECALL':
				return {
					icon: ICONS.icReturn,
					color: '#EB3732',
				};
			case 'CANCEL':
				return {
					icon: ICONS.icRemoveRectangle,
					color: '#EB3732',
				};
			case 'REJECT':
				return {
					icon: ICONS.icMinusCircle,
					color: '#EB3732',
				};
			case 'SEND':
				return {
					icon: ICONS.icSent,
					color: '#FF791F',
				};
			case 'NEWRELATED':
				return {
					icon: ICONS.icLinkField,
					color: '#FF791F',
				};
			case 'RELATED':
				return {
					icon: ICONS.icPlusCircle,
					color: '#005FD4',
				};

			default:
				return {
					icon: ICONS.icMoreCircle,
					color: '#FF791F',
				};
		}
	};

	if (!ListAction?.length || loadingDetails) return null;

	return (
		<View
			style={{
				backgroundColor: 'white',
				zIndex: 99,
				shadowColor: '#000',
				shadowOffset: {
					width: 0,
					height: -2,
				},
				shadowOpacity: 0.1,
				shadowRadius: 4,

				elevation: 5,
				flexDirection: 'row',
				alignItems: 'center',
				paddingHorizontal: 16,
				// position: 'absolute',
				// bottom: 0,
				// left: 0,
				// width: '100%',
				paddingVertical: 16,
			}}>
			{ListAction.slice(0, 2)?.map((item, index) => {
				const infoAction = getInfoAction(item.ActionCode);
				return (
					<TouchableOpacity
						key={index?.toString()}
						onPress={() => onPressCallAction(item)}
						style={{
							flex: 1,
							backgroundColor: infoAction.color,
							alignItems: 'center',
							paddingVertical: 10,
							borderRadius: 8,
							marginRight: 5,
							flexDirection: 'row',
							justifyContent: 'center',
						}}>
						<View
							style={{
								flexDirection: 'row',
								paddingHorizontal: 20,
								alignItems: 'center',
								justifyContent: 'center',
								overflow: 'hidden',
							}}>
							<Icon src={infoAction.icon} width={18} height={18} style={{ marginRight: 6 }} tintColor="white" />
							<Text numberOfLines={1} style={{ fontWeight: '600', color: 'white' }}>
								{item?.Title?.toLocaleUpperCase()}
							</Text>
						</View>
					</TouchableOpacity>
				);
			})}

			{ListAction?.length > 2 && (
				<View style={{ alignItems: 'center', marginHorizontal: 16 }}>
					<Icon
						src={ICONS.icMoreCircle}
						width={20}
						height={20}
						onPress={event => {
							event.target.measure((x, y, width, height, pageX, pageY) => {
								const list: IListAction[] = ListAction?.slice(2, ListAction.length);
								refDropDown.current?.show(
									{
										top: pageY,
										left: pageX,
										heightItem: list.length * 30 + list.length * 10,
									},
									<View>
										{list?.map((item, index) => {
											const infoAction = getInfoAction(item.ActionCode);
											return (
												<TouchableOpacity
													onPress={() => {
														refDropDown.current?.hide();
														onPressCallAction(item);
													}}
													key={index?.toString()}
													style={{
														marginVertical: 5,
														flexDirection: 'row',
														alignItems: 'center',
														height: 30,
														paddingLeft: 10,
													}}>
													<Icon src={infoAction.icon} width={24} height={24} style={{ marginRight: 6 }} />
													<Text style={{ color: infoAction?.textColor || '#111' }}>{item.Title}</Text>
												</TouchableOpacity>
											);
										})}
									</View>,
								);
							});
						}}
					/>
					<Text style={{ fontSize: 10, color: '#64748B' }}>{translate('more')}</Text>
				</View>
			)}
		</View>
	);
};

export default ActionButton;
