import { baseURL } from 'http/modules';

import React, { useEffect, useState } from 'react';

import { useNavigation } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import FImage from 'components/Organisms/FImage/FImage';
import { ICONS } from 'config';
import useSystem from 'hooks/useSystem';
import moment from 'moment';
import {
	View,
	Text,
	FlatList,
	TouchableOpacity,
	KeyboardAvoidingView,
	Platform,
	Share,
	Dimensions,
	useWindowDimensions,
} from 'react-native';
import AutoHeightWebView from 'react-native-autoheight-webview';
import ReactNativeBlobUtil from 'react-native-blob-util';
import FileViewer from 'react-native-file-viewer';
import { actions, RichEditor, RichToolbar } from 'react-native-pell-rich-editor';
// import RenderHtml from 'react-native-render-html';
import WebView from 'react-native-webview';
import { useAppDispatch, useAppSelector } from 'stores';
import { postLikeComment, updateComment } from 'stores/Workflows/sliceWorkflow';
import { IComment } from 'stores/Workflows/types';
import { getIconFile } from 'utils/functions';
import { translate } from 'utils/translate';

interface ItemProps {
	item: {
		ID: string;
		CID: number;
		Content: string;
		Image: string;
		ResourceId: string;
		ResourceCategoryId: number;
		ResourceSubCategoryId: number;
		LikeCount: number;
		CommentCount: number;
		ParentCommentId: any;
		Created: string;
		IsLiked: number;
		Name: string;
		ImagePath: string;
		DefaultImagePath: string;
		PositionName: string;
		children: any[];
	};
	index: number;
	onComment: (e: any) => void;
	onPressLike: (commentid: string, IsLiked: number, LikeCount: number) => void;
}

interface AttachComment {
	ID: string;
	Title: string;
	Url: string;
}

export const ItemComment = ({ item, index, onComment, onPressLike }: ItemProps) => {
	const {
		ImagePath,
		DefaultImagePath,
		Name,
		PositionName,
		Created,
		Content,
		children,
		LikeCount,
		Image,
		CID,
		IsLiked,
		ID,
		ParentCommentId,
		CommentCount,
	} = item;
	const { formatDateTime } = useSystem();
	const dateTime = Created ? moment(new Date(Created)).format(formatDateTime) : '';
	const Attach: AttachComment[] = JSON.parse(Image || '[]');

	const onShare = async (localFile: string) => {
		try {
			const result = await Share.share({
				url: localFile,
			});
			if (result.action === Share.sharedAction) {
				if (result.activityType) {
					// shared with activity type of result.activityType
				} else {
					// shared
				}
			} else if (result.action === Share.dismissedAction) {
				// dismissed
			}
		} catch (error: any) {
			//
		}
	};

	const onPressFile = (attach: AttachComment) => {
		const localFile = `${ReactNativeBlobUtil.fs?.dirs?.CacheDir}/${attach.Title}`;
		let config: { fileCache: boolean; path?: string } = {
			fileCache: true,
		};
		if (Platform.OS === 'ios') {
			config = { ...config, path: localFile };
		}
		const path = `${baseURL}/_layouts/15/VuThao.BPMOP.API/ApiDownload.ashx?file=${encodeURI(attach.Url)}`;

		const exFile = attach.Url?.split('.');

		const isImage = ['jpg', 'png'].includes(exFile[exFile.length - 1]);

		ReactNativeBlobUtil.config(config)
			.fetch('GET', path)
			.then(async res => {
				if (Platform.OS !== 'ios') {
					const result = await ReactNativeBlobUtil.MediaCollection.copyToMediaStore(
						{
							name: attach?.Title,
							mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
						},
						'Download',
						res.path(),
					);
					await ReactNativeBlobUtil.MediaCollection.copyToInternal(result, localFile);
				}
				// if (!isImage) {
				// 	FileViewer.open(localFile, {
				// 		showOpenWithDialog: true,
				// 	}).catch(() => {
				// 		//
				// 	});
				// } else {
				onShare(localFile);
				// }
			});
	};

	const isRichText = Content?.includes('</');

	return (
		<View style={{ marginTop: 15 }}>
			<View style={{ flexDirection: 'row' }}>
				<FImage SW={32} mh={0} ImagePath={ImagePath} DefaultImagePath={DefaultImagePath} />
				<View style={{ flex: 1, marginLeft: 9 }}>
					<View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
						<Text style={{ fontSize: 14, fontWeight: '400' }}>{Name || ''}</Text>
						<Text style={{ fontSize: 12, color: 'rgba(94, 94, 94, 1)' }}>{dateTime}</Text>
					</View>
					<View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
						<Text style={{ fontSize: 12, color: 'rgba(94, 94, 94, 1)' }}>{PositionName}</Text>
					</View>
					<View style={{ marginTop: 0 }}>
						{!isRichText ? (
							<Text style={{ fontSize: 14, fontWeight: '400', color: 'rgba(0, 0, 0, 1)', marginTop: Content ? 6 : 0 }}>
								{Content}
							</Text>
						) : (
							// <RichEditor
							// 	// ref={richtext}
							// 	androidLayerType="software"
							// 	disabled
							// 	containerStyle={{
							// 		flex: 1,
							// 		// minHeight: 200,
							// 	}}
							// 	editorStyle={{ color: '#111' }}
							// 	style={{ minHeight: Content ? 200 : 0 }}
							// 	// initialHeight={200}
							// 	initialContentHTML={Content}
							// 	useContainer={false}
							// 	// onFocus={onFocus}
							// 	// onBlur={onBlur}
							// 	// onChange={text => {
							// 	// 	setError(false);
							// 	// 	refValueField.current = text;
							// 	// }}
							// 	hideKeyboardAccessoryView
							// 	keyboardDisplayRequiresUserAction
							// 	renderToHardwareTextureAndroid
							// />
							<AutoHeightWebView
								style={{ width: Dimensions.get('window').width - 15, marginBottom: 10 }}
								// customScript={`document.body.style.background = 'lightyellow';`}
								customStyle={`
								  * {
								    font-family: Arial,sans-serif;
								  }
								  p {
										font-family: Arial,sans-serif;
								    font-size: 14px;
								  }
								`}
								// onSizeUpdated={size => console.log(size.height)}
								files={[
									{
										href: 'cssfileaddress',
										type: 'text/css',
										rel: 'stylesheet',
									},
								]}
								source={{
									html: Content,
								}}
								// scalesPageToFit
								viewportContent="width=device-width, user-scalable=no"
								scrollEnabled={false}
							/>
						)}

						{Attach?.map((attach: AttachComment, key: number) => {
							const splitTitle = attach?.Title?.split('.');
							const ExpFile = splitTitle?.length > 1 ? splitTitle?.[splitTitle?.length - 1] : '';
							return (
								<TouchableOpacity
									key={key?.toString()}
									style={{ flexDirection: 'row', alignItems: 'center' }}
									onPress={() => onPressFile(attach)}>
									<Icon src={getIconFile(ExpFile)} width={18} height={18} />
									<Text
										style={{
											paddingLeft: 6,
											textDecorationLine: 'underline',
											color: 'rgba(0, 95, 212, 1)',
											marginTop: 6,
										}}>
										{attach?.Title}
									</Text>
								</TouchableOpacity>
							);
						})}
						<View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 6 }}>
							<TouchableOpacity
								onPress={() => {
									onPressLike(ID, IsLiked, LikeCount);
								}}
								style={{ flexDirection: 'row', alignItems: 'center', marginRight: 10 }}>
								<Icon src={IsLiked ? ICONS.icLiked : ICONS.icLike} width={14} height={14} style={{ marginBottom: 2 }} />
								<Text style={{ fontSize: 14, color: '#111', paddingVertical: 8, paddingLeft: 4 }}>
									{IsLiked ? translate('Liked') : translate('Like')}
								</Text>
							</TouchableOpacity>
							<TouchableOpacity
								onPress={() =>
									onComment({
										ParentCommentId: ParentCommentId || ID,
										CID,
										index,
										PositionName,
										DefaultImagePath,
										Content,
									})
								}
								style={{ flexDirection: 'row', alignItems: 'center' }}>
								<Icon src={ICONS.icReply} width={14} height={14} />
								<Text style={{ fontSize: 14, color: '#111', paddingLeft: 4 }}>{translate('Reply')}</Text>
							</TouchableOpacity>
							<View style={{ flexDirection: 'row', justifyContent: 'flex-end', flex: 1 }}>
								{!!LikeCount && (
									<Text style={{ marginLeft: 4, color: '#7B7B7B' }}>
										{LikeCount} {translate('Like').toLocaleLowerCase()}
										{CommentCount ? ',' : ''}
									</Text>
								)}
								{!!CommentCount && (
									<Text style={{ marginLeft: 4, color: '#7B7B7B' }}>
										{CommentCount} {translate('Reply').toLocaleLowerCase()}
									</Text>
								)}
							</View>
						</View>
						<View style={{ height: 1, backgroundColor: 'rgba(238, 238, 238, 1)', marginTop: 10 }} />
						<View style={{ paddingTop: 20 }}>
							{children?.map((e: IComment, key: number) => {
								const {
									Name,
									PositionName,
									ImagePath,
									DefaultImagePath,
									Content,
									LikeCount,
									CID,
									IsLiked,
									Created,
									ID,
									ParentCommentId,
									CommentCount,
								} = e;
								return (
									<View key={key?.toString()} style={{ flexDirection: 'row', paddingBottom: 18 }}>
										<FImage SW={32} ImagePath={ImagePath} DefaultImagePath={DefaultImagePath} />
										<View style={{ flex: 1, justifyContent: 'center' }}>
											<View
												style={{
													flexDirection: 'row',
													justifyContent: 'space-between',
													flex: 1,
													alignItems: 'center',
													overflow: 'hidden',
												}}>
												<Text numberOfLines={1} style={{ fontSize: 14, fontWeight: '400', flex: 1, marginRight: 2 }}>
													{Name || ''}
												</Text>
											</View>
											<View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
												<Text style={{ fontSize: 12, color: 'rgba(94, 94, 94, 1)' }}>{PositionName}</Text>
											</View>
											<Text style={{ fontSize: 14, fontWeight: '400', color: 'rgba(0, 0, 0, 1)', paddingTop: 10 }}>
												{Content}
											</Text>
											<View style={{ flexDirection: 'row', alignItems: 'center' }}>
												<TouchableOpacity
													onPress={() => {
														onPressLike(ID, IsLiked, LikeCount);
													}}
													style={{ flexDirection: 'row', alignItems: 'center', marginRight: 10 }}>
													<Icon
														src={IsLiked ? ICONS.icLiked : ICONS.icLike}
														width={14}
														height={14}
														style={{ marginBottom: 2 }}
													/>
													<Text style={{ fontSize: 14, color: '#111', paddingLeft: 4 }}>
														{IsLiked ? translate('Liked') : translate('Like')}
													</Text>
												</TouchableOpacity>
												<TouchableOpacity
													onPress={() =>
														onComment({
															ParentCommentId: ParentCommentId || ID,
															CID,
															index,
															PositionName,
															DefaultImagePath,
															Content,
														})
													}
													style={{ flexDirection: 'row', alignItems: 'center' }}>
													<Icon src={ICONS.icReply} width={14} height={14} />
													<Text style={{ fontSize: 14, color: '#111', paddingVertical: 8, paddingLeft: 4 }}>
														{translate('Reply')}
													</Text>
												</TouchableOpacity>
												<View style={{ flexDirection: 'row', justifyContent: 'flex-end', flex: 1 }}>
													{!!LikeCount && (
														<Text style={{ marginLeft: 4, color: '#7B7B7B' }}>
															{LikeCount} {translate('Like').toLocaleLowerCase()}
															{CommentCount ? ',' : ''}
														</Text>
													)}
													{!!CommentCount && (
														<Text style={{ marginLeft: 4, color: '#7B7B7B' }}>
															{CommentCount} {translate('Reply').toLocaleLowerCase()}
														</Text>
													)}
												</View>
											</View>
											<View style={{ height: 1, backgroundColor: 'rgba(238, 238, 238, 1)', marginTop: 10 }} />
										</View>
									</View>
								);
							})}
						</View>
					</View>
				</View>
			</View>
		</View>
	);
};

const Comment = (props: any) => {
	const dispatch = useAppDispatch();
	const nativegation = useNavigation();

	const { ID, Content } = props;
	const [comments, setComments] = useState([]);
	const comments1 = useAppSelector(store => store.workflow.comments);
	const user = useAppSelector(store => store.dataNotRemove.customer);

	const fetchSuccess = (res: IComment[]) => {
		const cloneData: IComment[] = JSON.parse(JSON.stringify(res));

		// Tạo một đối tượng theo ID để tìm kiếm nhanh
		const lookup = {};
		cloneData?.forEach((item: IComment) => {
			lookup[item.ID] = item;
			item.children = [];
		});
		const result = [];

		cloneData?.forEach((item: { ParentCommentId: string | number }) => {
			const parent = lookup[item.ParentCommentId];
			if (parent) {
				// Thêm mục con vào mục cha
				parent.children.push(item);
			} else {
				// Nếu không có mục cha, đây là một mục cấp cao nhất
				result.push(item);
			}
		});

		setComments(result);
	};

	const onComment = (data: {
		ParentCommentId: string;
		CID: number;
		index: number;
		PositionName: string;
		DefaultImagePath: string;
		Content: string;
	}) => {
		nativegation.navigate('Reply', { rid: ID, Content, dataFw: data });
	};

	const likeSuccess = (commentid: string, IsLiked: number, LikeCount: number) => {
		const clone: IComment[] = JSON.parse(JSON.stringify(comments1 || '[]'));
		const indexItem = clone.findIndex(element => element.ID === commentid);
		clone[indexItem] = {
			...clone[indexItem],
			IsLiked: IsLiked ? 0 : 1,
			LikeCount: IsLiked ? LikeCount - 1 : LikeCount + 1,
		};
		dispatch(
			updateComment({
				func: 'recall',
				comment: clone,
			}),
		);
	};

	const onPressLike = (commentid: string, IsLiked: number, LikeCount: number) => {
		dispatch(
			postLikeComment({
				params: {
					action: IsLiked ? 'UNLIKE' : 'LIKE',
					rid: ID,
					commentid,
					isWorkflow: true,
				},
				success: () => likeSuccess(commentid, IsLiked, LikeCount),
			}),
		);
	};

	useEffect(() => {
		if (comments1?.length) {
			fetchSuccess(comments1);
		}
	}, [comments1]);

	return (
		<View style={{ flex: 1 }}>
			<KeyboardAvoidingView behavior="padding" style={{ flex: 1, paddingHorizontal: 16, paddingVertical: 24 }}>
				<View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
					<FImage SW={32} mh={0} mt={6} ImagePath={user?.ImagePath} DefaultImagePath={user?.DefaultImagePath} />
					<TouchableOpacity
						onPress={() => nativegation.navigate('Reply', { rid: ID, Content })}
						activeOpacity={1}
						style={{
							borderWidth: 1,
							borderColor: 'rgba(229, 229, 229, 1)',
							borderRadius: 8,
							minHeight: 53,
							flex: 1,
							marginLeft: 8,
							padding: 11,
							flexDirection: 'row',
							alignItems: 'flex-start',
						}}>
						<View style={{ flex: 1 }}>
							<Text style={{ color: 'rgba(153, 153, 153, 1)' }}>{translate('EnterComment')}</Text>
						</View>
						<Icon
							src={ICONS.icLink}
							width={20}
							height={20}
							tintColor="rgba(0, 0, 0, 1)"
							onPress={() => nativegation.navigate('Reply', { rid: ID, Content, isAttach: true })}
						/>
					</TouchableOpacity>
				</View>
			</KeyboardAvoidingView>
			<View style={{ padding: 16 }}>
				<FlatList
					scrollEnabled={false}
					data={comments}
					keyExtractor={(item, index) => index?.toString()}
					renderItem={({ item, index }) => (
						<ItemComment item={item} index={index} onComment={onComment} onPressLike={onPressLike} />
					)}
				/>
			</View>
		</View>
	);
};

export default Comment;
