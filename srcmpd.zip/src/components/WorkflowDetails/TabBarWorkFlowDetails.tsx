import React, { forwardRef, useImperativeHandle, useRef } from 'react';

import { Text } from '@react-native-material/core';
import { Animated, Easing, TouchableOpacity, View } from 'react-native';
import { FlatList } from 'react-native-gesture-handler';
import { useAppSelector } from 'stores';
import { translate } from 'utils/translate';

export const TABNAME_WORKFLOW = {
	INFOMATION: 'infomation',
	ATTACHMENT: 'attachment',
	ASSIGN: 'assign',
	COMMENT: 'comment',
	RELATED: 'related',
};

export const TABNAME_WORKFLOW_NOT_ATTACH = {
	INFOMATION: 'infomation',
	ASSIGN: 'assign',
	COMMENT: 'comment',
	RELATED: 'related',
};

const TabBarWorkFlowDetails = ({ status, onSetStatus, allowAttach }: any, ref: React.Ref<unknown> | undefined) => {
	const { attachmets, assignTask, related, comments } = useAppSelector(store => store.workflow);

	const scrollY = useRef(new Animated.Value(0)).current;
	const refFlatlist = useRef<FlatList>();

	const scrollToIndex = (index: number) => {
		refFlatlist?.current?.scrollToIndex({
			animated: true,
			index,
		});
	};

	const DATA_TABBAR = allowAttach ? TABNAME_WORKFLOW : TABNAME_WORKFLOW_NOT_ATTACH;

	const ScrollY = (y: number) => {
		Animated.timing(scrollY, { toValue: y, duration: 0, easing: Easing.ease, useNativeDriver: true }).start();
	};

	useImperativeHandle(
		ref,
		() => ({
			ScrollY,
		}),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[],
	);

	const shadow = scrollY.interpolate({
		inputRange: [0, 70, 120],
		outputRange: [0, 0, 0.2],
		extrapolate: 'clamp',
	});

	const shadowRadius = scrollY.interpolate({
		inputRange: [0, 70, 120],
		outputRange: [0, 0, 1],
		extrapolate: 'clamp',
	});

	const elevation = scrollY.interpolate({
		inputRange: [0, 70, 120],
		outputRange: [0, 0, 5],
		extrapolate: 'clamp',
	});

	const convertCount = c => {
		if (c < 11) return `${c}`;
		if (c > 11 && c < 100) return c;
		return '99+';
	};

	const getCountWorkflow = item => {
		switch (item) {
			case TABNAME_WORKFLOW.INFOMATION:
				return 0;
			case TABNAME_WORKFLOW.ATTACHMENT:
				return convertCount(attachmets?.length || 0);
			case TABNAME_WORKFLOW.ASSIGN:
				return convertCount(assignTask?.length || 0);
			case TABNAME_WORKFLOW.COMMENT:
				return convertCount(comments?.length || 0);
			case TABNAME_WORKFLOW.RELATED:
				return convertCount(related?.length || 0);

			default:
				return 0;
		}
	};

	return (
		<Animated.View
			style={{
				shadowColor: '#000',
				shadowOffset: {
					width: 0,
					height: 1,
				},
				shadowOpacity: shadow,
				shadowRadius,
				elevation,
				backgroundColor: 'white',
				zIndex: 99,
			}}>
			<FlatList
				ref={refFlatlist}
				horizontal
				contentContainerStyle={{ paddingRight: 10 }}
				showsHorizontalScrollIndicator={false}
				data={Object.values(DATA_TABBAR)}
				keyExtractor={(item, i) => i.toString()}
				renderItem={({ item, index }) => {
					return (
						<TouchableOpacity
							activeOpacity={1}
							style={{ minWidth: 100, zIndex: 999 }}
							onPress={() => {
								if (status !== item) {
									onSetStatus(item);
								}
								if (index > 2) {
									scrollToIndex(index);
								}
								if (index < 3) {
									scrollToIndex(0);
								}
							}}>
							<View>
								<View style={{ justifyContent: 'center', flexDirection: 'row', alignItems: 'center' }}>
									<Text
										style={{
											textAlign: 'center',
											color: status === item ? 'rgba(0, 95, 212, 1)' : 'black',
											fontSize: 12,
											fontWeight: status === item ? '700' : '400',
											lineHeight: 26,
										}}>
										{translate(item)}
									</Text>
									{index !== 0 && (
										<View
											style={{
												backgroundColor: 'rgba(245, 245, 245, 1)',
												alignItems: 'center',
												justifyContent: 'center',
												borderRadius: 4,
												marginLeft: 4,
												padding: 4,
											}}>
											<Text style={{ fontSize: 8, color: 'rgba(100, 116, 139, 1)' }}>{getCountWorkflow(item)}</Text>
										</View>
									)}
								</View>
								<View
									style={{
										backgroundColor: status === item ? 'rgba(0, 95, 212, 1)' : 'white',
										bottom: 0,
										borderTopLeftRadius: 4,
										borderTopRightRadius: 4,
										height: 4,
										zIndex: 99,
										width: '100%',
									}}
								/>
							</View>
						</TouchableOpacity>
					);
				}}
			/>
		</Animated.View>
	);
};

export default forwardRef(TabBarWorkFlowDetails);
