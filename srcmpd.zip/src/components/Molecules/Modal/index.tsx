/* eslint-disable import/no-extraneous-dependencies */
import React from 'react';

import { Icon } from 'components/Atoms/Icon';
import { COLORS, ICONS } from 'config';
import { KeyboardAvoidingView, Platform, useWindowDimensions, View } from 'react-native';
import Modal from 'react-native-modal';

import { ModalProps } from './interfaces';
import { Footer, Header, Title, Line, CloseIcon, styles } from './styles';

export const ModalComponent: React.FC<ModalProps> = ({
	open,
	children,
	visiblePosition = 'bottom',
	outsideClickCloseable = false,
	headerTitle,
	behavior = undefined,
	style,
	containerStyle,
	renderFooter,
	onClose,
	onHide,
	container,
}) => {
	const { height } = useWindowDimensions();
	const handleOnBackdropPress = () => {
		if (!outsideClickCloseable || !onClose) return;
		onClose();
	};

	return (
		<Modal
			style={[visiblePosition === 'bottom' ? styles.bottom : undefined, style]}
			onBackdropPress={handleOnBackdropPress}
			isVisible={open}
			animationIn="slideInUp"
			animationOut="slideOutDown"
			animationInTiming={500}
			animationOutTiming={500}
			statusBarTranslucent={typeof behavior === 'undefined'}
			// deviceHeight={height * 2}
			onModalHide={onHide}
			hideModalContentWhileAnimating
			coverScreen
			avoidKeyboard>
			<KeyboardAvoidingView behavior={Platform.OS === 'ios' ? behavior : undefined} style={container}>
				<View style={[{ backgroundColor: COLORS.white }, containerStyle]}>
					{!!headerTitle && (
						<>
							<View style={{ alignItems: 'center', padding: 20, backgroundColor: COLORS.whiteSmoke }}>
								<Title allowFontScaling={false} numberOfLines={1}>
									{headerTitle}
								</Title>
								<CloseIcon>
									<Icon src={ICONS.close} width={14} height={14} onPress={onClose} />
								</CloseIcon>
							</View>
							<Line />
						</>
					)}
					{children}
					{!!renderFooter && (
						<>
							{/* <Line /> */}
							<Footer>{renderFooter()}</Footer>
						</>
					)}
				</View>
			</KeyboardAvoidingView>
		</Modal>
	);
};
