/* eslint-disable import/no-extraneous-dependencies */
import React, { forwardRef, useState, useImperativeHandle } from 'react';

import { KeyboardAvoidingView, Platform, TouchableOpacity, useWindowDimensions, View } from 'react-native';
import Modal from 'react-native-modal';

import { ModalProps } from './interfaces';
import { styles } from './styles';

const ModalRef: React.FC<ModalProps> = (
	{
		children,
		visiblePosition = 'bottom',
		behavior = undefined,
		style,
		onHide,
		container,
		isTouch = true,
		avoidKeyboard = true,
	},
	ref: React.Ref<unknown> | undefined,
) => {
	const [isVisible, setIsVisible] = useState(false);
	const { height } = useWindowDimensions();

	const show = () => {
		setIsVisible(true);
	};
	const hide = () => setIsVisible(false);

	useImperativeHandle(
		ref,
		() => ({
			show,
			hide,
		}),
		[],
	);

	const handleOnBackdropPress = () => {
		hide();
	};

	return (
		<Modal
			style={[visiblePosition === 'bottom' ? styles.bottom : undefined, style]}
			onBackdropPress={handleOnBackdropPress}
			isVisible={isVisible}
			animationIn="slideInUp"
			animationOut="slideOutDown"
			animationInTiming={400}
			animationOutTiming={300}
			statusBarTranslucent={typeof behavior === 'undefined'}
			deviceHeight={height * 2}
			onModalHide={onHide}
			hideModalContentWhileAnimating
			coverScreen
			avoidKeyboard={avoidKeyboard}
			useNativeDriver={false}
			swipeDirection={['down']}
			useNativeDriverForBackdrop
			propagateSwipe
			supportedOrientations={['portrait', 'landscape']}
			onSwipeComplete={handleOnBackdropPress}>
			<KeyboardAvoidingView behavior={Platform.OS === 'ios' ? behavior : undefined} style={container}>
				{isTouch && (
					<TouchableOpacity style={{ alignItems: 'center', marginVertical: 10 }} onPress={hide}>
						<View style={{ width: 48, height: 6, backgroundColor: 'rgba(156, 164, 171, 1)', borderRadius: 10 }} />
					</TouchableOpacity>
				)}
				{children}
			</KeyboardAvoidingView>
		</Modal>
	);
};

export default forwardRef(ModalRef);
