import { COLORS, FONTS } from 'config';
import { StyleSheet } from 'react-native';
import styled from 'styled-components/native';

export const Container = styled.View`
	background-color: ${COLORS.white};
`;

export const Header = styled.View`
	align-items: center;
	padding: 10px 50px;
	background-color: ${COLORS.whiteSmoke};
`;

export const Title = styled.Text`
	color: ${COLORS.darkJungleGreen};
	font-size: 17px;
	font-family: ${FONTS['Roboto-Bold']};
	font-weight: bold;
	line-height: 24px;
	text-align: center;
	flex-grow: 1;
`;

export const CloseIcon = styled.View`
	position: absolute;
	right: 25px;
	top: 15px;
`;

export const Line = styled.View`
	height: 1px;
	background-color: ${COLORS.azureishWhite};
`;
export const Body = styled.View`
	padding: 20px;
`;

export const Footer = styled.View`
	padding: 20px;
`;

export const styles = StyleSheet.create({
	bottom: {
		justifyContent: 'flex-end',
		margin: 0,
	},
	modalContent: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		alignItems: 'center',
	},
	timeValue: {
		width: 75,
	},
});
