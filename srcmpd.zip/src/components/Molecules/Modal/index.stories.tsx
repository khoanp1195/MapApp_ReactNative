import React from 'react';

// eslint-disable-next-line import/no-extraneous-dependencies
import { useState } from '@storybook/addons';
import { storiesOf } from '@storybook/react-native';
import { Text, View } from 'react-native';

import { ModalComponent } from '.';
import { styles } from './styles';

storiesOf('Organisms/Modal', module).add('default', () => {
	const [open, setOpen] = useState(false);
	return (
		<ModalComponent
			open={open}
			outsideClickCloseable
			onClose={() => setOpen(false)}
			visiblePosition="bottom"
			headerTitle="Chọn ngày">
			<View style={styles.modalContent}>
				<Text>Thời gian</Text>
				<View style={styles.timeValue} />
			</View>
		</ModalComponent>
	);
});
