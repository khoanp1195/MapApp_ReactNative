import React from 'react';

import { StyleProp, ViewStyle } from 'react-native';

export type Position = 'center' | 'bottom';

export interface ModalProps {
	open?: boolean;
	visiblePosition?: Position;
	outsideClickCloseable?: boolean;
	headerTitle?: string;
	behavior?: 'height' | 'position' | 'padding' | undefined;
	style?: StyleProp<ViewStyle>;
	containerStyle?: StyleProp<ViewStyle> | undefined;
	container?: StyleProp<ViewStyle> | undefined;
	children?: React.ReactNode;
	renderFooter?: () => React.ReactNode;
	onClose?: () => void;
	onHide?: () => void;
	useNativeDriver?: boolean;
	isTouch?: boolean;
	avoidKeyboard?: boolean;
}
