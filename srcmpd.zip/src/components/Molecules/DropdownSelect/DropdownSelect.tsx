import React, { useState } from 'react';
import { View, TouchableOpacity, Text, StyleSheet } from 'react-native';

interface DropdownSelectProps {
	options: string[];
	selectedValue: string;
	onSelect: (value: string) => void;
}

const DropdownSelect: React.FC<DropdownSelectProps> = ({ options, selectedValue, onSelect }) => {
	const [isDropdownVisible, setIsDropdownVisible] = useState(false);

	const toggleDropdown = () => {
		setIsDropdownVisible(!isDropdownVisible);
	};

	const handleSelect = (value: string) => {
		onSelect(value);
		toggleDropdown();
	};

	return (
		<View style={styles.container}>
			<TouchableOpacity onPress={toggleDropdown} style={styles.dropdown}>
				<Text style={styles.selectedValue}>{selectedValue}</Text>
				<View style={{ width: 20, height: 20, backgroundColor: 'black' }} />
			</TouchableOpacity>
			{isDropdownVisible && (
				<View style={styles.dropdownOptions}>
					{options.map(option => (
						<TouchableOpacity key={option} onPress={() => handleSelect(option)}>
							<Text style={styles.option}>{option}</Text>
						</TouchableOpacity>
					))}
				</View>
			)}
		</View>
	);
};

const styles = StyleSheet.create({
	container: {
		position: 'relative',
	},
	dropdown: {
		flexDirection: 'row',
		alignItems: 'center',
		padding: 10,
		borderWidth: 1,
		borderColor: '#ccc',
		borderRadius: 5,
	},
	selectedValue: {
		marginRight: 10,
	},
	dropdownOptions: {
		position: 'absolute',
		top: '100%',
		left: 0,
		right: 0,
		backgroundColor: '#fff',
		borderWidth: 1,
		borderColor: '#ccc',
		borderRadius: 5,
		marginTop: 5,
	},
	option: {
		padding: 10,
	},
});

export default DropdownSelect;
