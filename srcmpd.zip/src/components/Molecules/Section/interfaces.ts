import React from 'react';

import { StyleProp, ViewStyle } from 'react-native';

export interface Props {
	leading?: React.ReactNode;
	center?: React.ReactNode;
	trailing?: React.ReactNode;
	style?: StyleProp<ViewStyle>;
	onPress?: () => void;
}
