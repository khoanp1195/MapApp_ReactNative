import styled from 'styled-components/native';

export const Container = styled.Pressable`
	flex-direction: row;
	align-items: center;
	justify-content: space-between;
	padding-top: 7px;
	padding-bottom: 7px;
`;
export const CenterWrap = styled.View`
	margin: 0px 16px;
	flex: 1;
`;
