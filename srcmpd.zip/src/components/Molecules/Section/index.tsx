import React from 'react';

import { Props } from './interfaces';
import { CenterWrap, Container } from './styles';

export const Section: React.FC<Props> = ({ leading, center, trailing, style, onPress }) => (
	// eslint-disable-next-line @typescript-eslint/ban-ts-comment
	// @ts-ignore
	<Container onPress={onPress} style={style}>
		{leading}
		<CenterWrap>{center}</CenterWrap>
		{trailing}
	</Container>
);
