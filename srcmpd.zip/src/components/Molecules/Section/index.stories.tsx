import React from 'react';

import { storiesOf } from '@storybook/react-native';

import { Section } from '.';

storiesOf('Molecules/Section', module).add('default', () => <Section />);
