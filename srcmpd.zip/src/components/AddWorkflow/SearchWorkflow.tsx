/* eslint-disable react/no-unstable-nested-components */
/* eslint-disable react-hooks/exhaustive-deps */
import { ENDPOINT } from 'http/modules';

import React, { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';

import { useIsFocused, useNavigation } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import ItemFavorite from 'components/Organisms/ItemFavorite/ItemFavorite';
import { COLORS, ICONS } from 'config';
import useDebounce from 'hooks/useDebounce';
import useInfinity from 'hooks/useInfinity';
import { navigate } from 'navigation/RootNavigation';
import { RoutesNames } from 'navigation/RoutesNames';
import { Text, TouchableOpacity, View, SectionList, RefreshControl, TextInput, ActivityIndicator } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ParamsProps } from 'screens/Apps/Containers';
import { useAppDispatch } from 'stores';
import { fetchFavorite } from 'stores/Apps/thunks';
import { IItemFavorite, updateFavoriteHome } from 'stores/Home/reducer';
import { translate } from 'utils/translate';

export interface IDataApps {
	WorkflowCategoryID: number;
	title: any;
	data: IItemFavorite[];
}

const Header = ({ title, onSearch, Keyword = '' }: { title: string; onSearch?: () => void }) => {
	const navigation = useNavigation();
	const insets = useSafeAreaInsets();
	const [show, setShow] = useState(false);
	const refInput = useRef();

	const onGoback = () => navigation.goBack();

	const onPressSearch = () => {
		// setShow(true);
		navigation.navigate(RoutesNames.SearchApps, { isCreateWorkflow: true });
	};

	useEffect(() => {
		if (show) {
			refInput.current?.focus();
		}
	}, [show]);

	return (
		<View
			style={{
				flexDirection: 'row',
				shadowColor: '#000',
				shadowOffset: {
					width: 0,
					height: 2,
				},
				shadowOpacity: 0.1,
				shadowRadius: 2,

				elevation: 5,
				backgroundColor: 'white',
				paddingTop: insets.top,
				paddingBottom: 10,
				paddingHorizontal: 16,
				zIndex: 99,
			}}>
			<View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
				<View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
					<Icon src={ICONS.icArrowMenu} width={24} height={24} tintColor="rgba(0, 0, 0, 1)" onPress={onGoback} />
					{show ? (
						<TextInput
							ref={refInput}
							value={Keyword}
							onChangeText={onSearch}
							placeholder={translate('searchButton')}
							style={{ marginLeft: 10, fontSize: 16, flex: 1 }}
							autoFocus
						/>
					) : (
						<Text
							numberOfLines={1}
							style={{ fontSize: 16, fontWeight: '700', marginHorizontal: 12, color: 'rgba(0, 0, 0, 1)' }}>
							{title}
						</Text>
					)}
				</View>
				{!show && (
					<Icon src={ICONS.icSearchApps} width={20} height={20} tintColor="rgba(0, 0, 0, 1)" onPress={onPressSearch} />
				)}
			</View>
		</View>
	);
};

const SearchWorkflow = () => {
	const navigation = useNavigation();
	const dispatch = useAppDispatch();
	const [data, setData] = useState(Array<IDataApps>);
	const [indexHide, setIndexHide] = useState<number[]>([]);
	const isFocus = useIsFocused();

	const [startMore, setStartMore] = useState(false);
	const [startMoreData, setStartMoreData] = useState(false);

	const refLengthData = useRef(0);

	const [Keyword, setKeyword] = useState('');

	const db = useDebounce(Keyword, 300);

	useEffect(() => {
		setIndexHide([]);
	}, [isFocus]);

	const {
		state: { data: dataRes, refreshing, loading },
		gotoFirstPage,
		refreshPage,
		fetchMore,
	} = useInfinity<Array<IItemFavorite>>(`${ENDPOINT.WORKFLOW}`, {
		size: 10,
		requireAuthentication: true,
		params: {
			func: 'getOrSearchListWorkflow',
			flag: 0,
			data: `{"PerType": 0,"WorkflowCategoryId":0,"Keyword":${JSON.stringify(db)}}`,
		},
	});

	useEffect(() => {
		gotoFirstPage();
	}, [db]);

	useEffect(() => {
		let list: IDataApps[] = [];
		// eslint-disable-next-line array-callback-return
		dataRes?.map((e: IItemFavorite) => {
			const findIndex = list.findIndex((x: IDataApps) => {
				return x.WorkflowCategoryID === e.WorkflowCategoryID;
			});
			if (findIndex !== -1) {
				list[findIndex].data = list[findIndex].data?.concat(e);
			} else {
				list = [
					...list,
					{
						WorkflowCategoryID: e.WorkflowCategoryID,
						title: e.WorkflowCategory,
						data: [e],
					},
				];
			}
		});
		setData(list);
	}, [dataRes]);

	const handleEndReached = (info: { distanceFromEnd: number }) => {
		if (dataRes?.length > 9) {
			fetchMore();
		}
	};

	const ListFooter = () => (
		<View style={{ height: 100 }}>
			<View style={{ marginTop: 20 }}>
				{loading && !refreshing && !Keyword?.length && <ActivityIndicator size="small" />}
			</View>
		</View>
	);
	const onPressItem = item => {
		navigate(RoutesNames.AddWorkflow, { item });
	};

	const onSearch = kw => {
		setKeyword(kw);
	};

	useEffect(() => {
		if (startMore && data?.length < 2 && !startMoreData) {
			fetchMore();
		}
		if (data?.length > 1) {
			setStartMore(false);
		}
	}, [startMore, data]);

	useEffect(() => {
		if (startMoreData && refLengthData.current === data?.length) {
			fetchMore();
		}
		if (refLengthData.current !== data?.length) {
			setStartMore(false);
		}
		refLengthData.current = data?.length;
	}, [startMoreData, data]);

	const onRefreshPage = () => {
		setIndexHide([]);
		refreshPage();
	};

	return (
		<View style={{ flex: 1 }}>
			<Header Keyword={Keyword} title={translate('createRequest')} onSearch={onSearch} />
			{!data?.length && !loading && !refreshing && (
				<Text style={{ fontSize: 12, fontStyle: 'italic', textAlign: 'center', paddingTop: 10 }}>
					{translate('noResult')}
				</Text>
			)}
			<SectionList
				style={{ paddingHorizontal: 24 }}
				showsVerticalScrollIndicator={false}
				sections={data}
				keyExtractor={(item, index) => index.toString()}
				renderItem={({ item, index }) => {
					const isHideItem = indexHide.includes(item.WorkflowCategoryID);
					if (isHideItem) return null;
					return <ItemFavorite item={item} index={index} onPressItem={onPressItem} />;
				}}
				renderSectionHeader={({ section }) => {
					return (
						<TouchableOpacity
							activeOpacity={1}
							style={{ paddingVertical: 20 }}
							onPress={() => {
								if (data?.length < 2) {
									setStartMore(true);
								}
								if (indexHide.includes(section.WorkflowCategoryID)) {
									setIndexHide(indexHide.filter(e => e !== section.WorkflowCategoryID));
								} else {
									setIndexHide([...indexHide, section.WorkflowCategoryID]);
									setStartMoreData(true);
								}
							}}>
							<Text numberOfLines={1} style={{ fontSize: 16, fontWeight: '700' }}>
								{section?.title || 'Other'}
							</Text>
						</TouchableOpacity>
					);
				}}
				onEndReached={handleEndReached}
				onEndReachedThreshold={0.5}
				ListFooterComponent={<ListFooter />}
				refreshControl={
					<RefreshControl refreshing={refreshing} onRefresh={onRefreshPage} tintColor={COLORS.trueBlue} />
				}
				stickySectionHeadersEnabled={false}
			/>
		</View>
	);
};

export default SearchWorkflow;
