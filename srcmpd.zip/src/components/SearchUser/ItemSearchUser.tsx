/* eslint-disable @typescript-eslint/no-use-before-define */
/* eslint-disable react-hooks/exhaustive-deps */

import React from 'react';

import { Icon } from 'components/Atoms/Icon';
import FImage from 'components/Organisms/FImage/FImage';
import { COLORS, ICONS } from 'config';
import { View, Text, TouchableOpacity } from 'react-native';
import { IUser } from 'screens/TaskDetail/screens/SearchUser';
import { useAppSelector } from 'stores';

const ItemSearchUser = ({
	item,
	selected,
	onSelectItem,
	isField,
}: {
	item: IUser;
	selected: IUser[];
	onSelectItem: (item: IUser, isSelected: boolean) => void;
}) => {
	const { ID: IDUser = '' } = useAppSelector(state => state.dataNotRemove.customer) || {};
	const isUser = !isField && IDUser === item?.ID?.toString();

	const isSelected = selected?.find(s => s.ID === item.ID);
	if (isUser) return null;
	return (
		<TouchableOpacity
			activeOpacity={1}
			disabled={isUser}
			onPress={() => onSelectItem(item, !!isSelected)}
			style={{
				paddingVertical: 10,
				backgroundColor: 'white',
				borderRadius: 4,
				flexDirection: 'row',
				alignItems: 'center',
				opacity: isUser ? 0.5 : 1,
			}}>
			<Icon
				src={isSelected ? ICONS.icCheckUser : ICONS.icUnCheckUser}
				width={20}
				height={20}
				style={{ marginRight: 20 }}
			/>
			<View style={{ flexDirection: 'row', flex: 1 }}>
				<FImage ImagePath={item?.ImagePath} DefaultImagePath={item?.DefaultImagePath} mh={0} />
				<View style={{ marginLeft: 10, flex: 1, justifyContent: 'center' }}>
					<Text numberOfLines={2}>{item?.Name || item?.FullName}</Text>
					{item?.PositionName && (
						<Text style={{ color: 'rgba(94, 94, 94, 1)', fontSize: 11, fontStyle: 'italic' }}>
							{item?.PositionName}
						</Text>
					)}
					{isUser && (
						<Text style={{ color: COLORS.red, fontSize: 11, fontStyle: 'italic' }}>
							Bạn không thể gửi tham vấn cho chính bạn
						</Text>
					)}
				</View>
			</View>
		</TouchableOpacity>
	);
};

export default ItemSearchUser;
