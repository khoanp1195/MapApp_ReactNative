/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useLayoutEffect, useRef } from 'react';

import { useIsFocused } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { COLORS } from 'config';
import { ICONS } from 'config/images';
import dayjs from 'dayjs';
import useSystem from 'hooks/useSystem';
import { View, Text, Animated, Easing } from 'react-native';
import { useAppDispatch, useAppSelector } from 'stores';
import { fetchCount } from 'stores/Count';
import { FirstChartDaum, getChartHome } from 'stores/Home';
import { translate } from 'utils/translate';

import { styles } from './styles/ChartReport.styles';

// eslint-disable-next-line prettier/prettier
const ChartReport = ({ refreshing = false, updateRefreshing = () => { } }) => {
	const dispactch = useAppDispatch();
	const { isVN } = useSystem();
	const isFocused = useIsFocused();

	const { FirstChartData = [], SecondChartData = [] } = useAppSelector(store => store.home.chartHome) || {};

	const { TotalPreWeek, TotalMonth, TotalPreMonth, TotalPreYear, TotalWeek, TotalYear } = SecondChartData?.[0] || {};

	const animatedValue = useRef(new Animated.Value(0)).current;

	const startHandleAnimated = () => {
		Animated.timing(animatedValue, { toValue: 0, duration: 550, easing: Easing.ease, useNativeDriver: false }).start();
	};

	const endHandleAnimated = () => {
		Animated.timing(animatedValue, { toValue: 55, duration: 550, easing: Easing.ease, useNativeDriver: false }).start();
	};

	useEffect(() => {
		if (refreshing) {
			startHandleAnimated();
			dispactch(fetchCount());
			dispactch(
				getChartHome({
					success: () => {
						updateRefreshing();
						endHandleAnimated();
					},
					failed: () => {
						updateRefreshing();
						endHandleAnimated();
					},
				}),
			);
		}
	}, [refreshing]);

	useLayoutEffect(() => {
		if (isFocused) {
			startHandleAnimated();
			dispactch(
				getChartHome({
					success: () => {
						updateRefreshing();
						endHandleAnimated();
					},
					failed: () => {
						updateRefreshing();
						endHandleAnimated();
					},
				}),
			);
		}
	}, [isFocused]);

	const getHeight = (e = 0) => {
		return animatedValue.interpolate({
			inputRange: [0, 55],
			outputRange: [0, e],
			extrapolate: 'clamp',
		});
	};

	const opacity = animatedValue.interpolate({ inputRange: [0, 55], outputRange: [0, 1], extrapolate: 'clamp' });

	const getTitle = (DoW: number) => {
		switch (DoW) {
			case 1:
				return translate('sunday');
			case 2:
				return translate('monday');
			case 3:
				return translate('tuesday');
			case 4:
				return translate('wenesday');
			case 5:
				return translate('thursday');
			case 6:
				return translate('friday');
			case 7:
				return translate('saturday');
			default:
				return '';
		}
	};

	const getInfoChart = (item: FirstChartDaum) => {
		const { MaxTotal, Total } = item || {};
		const percent = Total / MaxTotal;

		const minPercent = percent > 0.2 ? percent : 0.2;

		return {
			height: percent * 55 || 0,
			color: `rgba(0, 95, 212, ${minPercent})`,
		};
	};

	const getValueTotal = (item: string) => {
		switch (item) {
			case 'this_week':
				return TotalWeek;
			case 'this_month':
				return TotalMonth;
			case 'year':
				return TotalYear;
			default:
				return 0;
		}
	};
	const formatStart = isVN ? 'DD/MM' : 'MM/DD';

	const getLengthDate = () => {
		const start = FirstChartData[0]?.StartOfDate;
		const end = FirstChartData[6]?.StartOfDate;
		const formatEnd = isVN ? 'DD/MM/YYYY' : 'MM/DD/YYYY';
		return `${dayjs(start).format(formatStart)} - ${dayjs(end).format(formatEnd)}`;
	};

	const getTitleTotal = (Total: number) => {
		if (Total < 10) return `0${Total}`;
		if (Total > 999) return '999+';
		return Total;
	};

	return (
		<View style={styles.container}>
			<Text style={{ fontSize: 16, fontWeight: '700', marginBottom: 16 }}>{translate('processed_statistics')}</Text>
			<View style={styles.borderContainer}>
				<View style={styles.viewDate}>
					<View style={styles.date}>
						<Text style={styles.textDate}>{getLengthDate()}</Text>
						<Text style={styles.textRank}>{getTitle(dayjs().day() + 1)}</Text>
					</View>
					<View style={styles.viewChart}>
						{FirstChartData?.map(item => {
							const isSelect = dayjs(item.StartOfDate).date() === dayjs().date();
							const infoChart = getInfoChart(item);
							const height = getHeight(infoChart.height);
							return (
								<View style={styles.itemChart} key={item?.Index?.toString()}>
									<View style={styles.chart}>
										{!!item?.Total && (
											<Animated.Text style={[styles.total, { color: infoChart.color, opacity }]}>
												{getTitleTotal(item.Total)}
											</Animated.Text>
										)}
										<Animated.View
											style={[
												styles.boxChart,
												{
													height,
													backgroundColor: infoChart.color,
												},
											]}
										/>
									</View>
									<View style={[styles.viewDesc, { borderWidth: isSelect ? 1 : 0 }]}>
										<Text
											style={[styles.textDesc, { color: [1, 7].includes(item.DoW) ? COLORS.red : COLORS.textGrey }]}>
											{dayjs(item.StartOfDate).format(formatStart)}
										</Text>
									</View>
								</View>
							);
						})}
					</View>
				</View>
				<View style={styles.dvd} />
				<View style={styles.viewTotal}>
					{['this_week', 'this_month', 'year'].map((item: string, index: number) => {
						return (
							<View key={index?.toString()} style={{ alignItems: 'center' }}>
								<View style={styles.vTotal}>
									<Text style={styles.textTotal}>{getValueTotal(item)}</Text>
									{/* {TotalWeek !== TotalPreWeek && (
										<Icon
											src={TotalWeek > TotalPreWeek ? ICONS.icArrowGreen : ICONS.icArrowRed}
											width={20}
											height={20}
										/>
									)} */}
								</View>
								<Text style={styles.text}>
									{translate(item as 'this_week' | 'this_month' | 'year')}
									{item === 'year' ? ` ${dayjs().year()}` : ''}
								</Text>
							</View>
						);
					})}
				</View>
			</View>
		</View>
	);
};

export default ChartReport;
