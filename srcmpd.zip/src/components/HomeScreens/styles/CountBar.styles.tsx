import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
	container: { paddingVertical: 30 },
	containerItem: {
		width: 96,
		height: 102,
		borderRadius: 12,
		// alignItems: 'center',
		justifyContent: 'center',
		// paddingLeft: 15,
		alignItems: 'center',
	},
	count: { fontWeight: '700', fontSize: 20, color: 'rgba(255, 255, 255, 1)' },
	descriptions: { fontWeight: '400', fontSize: 12, color: 'rgba(255, 255, 255, 1)', marginTop: 4 },
});
