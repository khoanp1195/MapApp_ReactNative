import { COLORS } from 'config';
import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
	container: { flex: 1, marginHorizontal: 24 },
	borderContainer: {
		width: '100%',
		height: 265,
		borderRadius: 12,
		shadowColor: 'rgba(0, 0, 0, 0.5)',
		shadowOffset: {
			width: 0,
			height: 0,
		},
		shadowOpacity: 0.25,
		shadowRadius: 2,
		elevation: 20,
		backgroundColor: 'rgba(255, 255, 255, 1)',
		borderWidth: 0.8,
		borderColor: 'rgba(226, 232, 240, 0.5)',
	},
	viewDate: { flex: 1, justifyContent: 'space-between' },
	date: { justifyContent: 'center', alignItems: 'center', marginVertical: 14 },
	textDate: { fontSize: 12, fontWeight: '500', color: COLORS.textGrey },
	textRank: { fontSize: 24, fontWeight: '700', color: 'rgba(62, 69, 73, 1)', lineHeight: 30 },
	viewChart: { justifyContent: 'space-between', flexDirection: 'row', marginHorizontal: 16, marginBottom: 14 },
	itemChart: { alignItems: 'center' },
	chart: { height: 50, justifyContent: 'flex-end', alignItems: 'center' },
	total: { color: COLORS.borderColorGrey, fontSize: 12 },
	viewDesc: {
		marginTop: 8,
		// width: 32,
		alignItems: 'center',
		borderRadius: 8,
		borderColor: COLORS.borderColorGrey,
		paddingVertical: 4,
		paddingHorizontal: 2,
	},
	textDesc: {
		fontSize: 12,
	},
	dvd: { borderStyle: 'dashed', borderWidth: 0.5, borderColor: COLORS.dvdGrey },
	viewTotal: {
		height: 90,
		flexDirection: 'row',
		justifyContent: 'space-around',
		alignItems: 'center',
		paddingHorizontal: 20,
	},
	textTotal: { fontSize: 20, fontWeight: '700', color: 'rgba(115, 117, 138, 1)', lineHeight: 30 },
	text: { fontSize: 12, color: COLORS.textGrey },
	vTotal: { flexDirection: 'row' },
	boxChart: {
		width: 32,
		borderRadius: 2,
	},
});
