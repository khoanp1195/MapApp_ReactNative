import React, { useEffect } from 'react';

import ItemFavorite from 'components/Organisms/ItemFavorite/ItemFavorite';
import { STATUS_TAKS } from 'components/TaskScreens/consts/consts';
import { navigate } from 'navigation/RootNavigation';
import { BottomNavigationRoutesNames } from 'navigation/RoutesNames';
import { View, Text, FlatList, TouchableOpacity, Dimensions } from 'react-native';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateWorkflowsApps } from 'stores/Apps/reducer';
import { fetchCount } from 'stores/Count/thunks';
import { IItemFavorite, getFavoriteHome } from 'stores/Home';
import { translate } from 'utils/translate';

import { styles } from './styles/FavoriteApps.styles';

const windowWidth = Dimensions.get('window').width;

const FavoriteApps = ({ refreshing, updateRefreshing }: { refreshing: boolean; updateRefreshing: () => void }) => {
	const dispatch = useAppDispatch();
	const favorite = useAppSelector(store => store.home.favorite);

	useEffect(() => {
		if (refreshing) {
			dispatch(
				getFavoriteHome({
					success: updateRefreshing,
					failed: updateRefreshing,
				}),
			);
		}

		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [refreshing]);

	useEffect(() => {
		dispatch(
			getFavoriteHome({
				success: updateRefreshing,
				failed: updateRefreshing,
			}),
		);

		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	const onGotoAllFavo = () => {
		navigate(BottomNavigationRoutesNames.Apps, { screen: 'favorite' });
	};

	const lengthFavorite = favorite?.length || 0;

	const onPressItem = item => {
		dispatch(fetchCount({ WorkflowId: item?.WorkflowID || 0 }));
		dispatch(updateWorkflowsApps(item));
		navigate(BottomNavigationRoutesNames.TaskScreen, {
			screen: 'myTask',
			toMyTask: STATUS_TAKS.PROCESSING,
		});
	};

	const renderItem = ({ item, index }: { item: IItemFavorite; index: number }) => {
		return <ItemFavorite item={item} index={index} isFW={lengthFavorite > 2} onPressItem={onPressItem} />;
	};

	if (!lengthFavorite) return null;
	return (
		<View style={styles.container}>
			<View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
				<Text style={styles.title}>{translate('favorite_apps')}</Text>
				<TouchableOpacity onPress={onGotoAllFavo}>
					<Text style={styles.all}>{translate('flag_all')}</Text>
				</TouchableOpacity>
			</View>
			{lengthFavorite > 2 ? (
				<FlatList
					data={favorite?.slice(0, 4)}
					keyExtractor={(item, index) => index.toString()}
					renderItem={renderItem}
					contentContainerStyle={styles.flatlist}
					numColumns={2}
					scrollEnabled={false}
				/>
			) : (
				<View style={{ width: windowWidth }}>
					{favorite?.map((item, index) => {
						return (
							<ItemFavorite
								item={item}
								index={index}
								key={index?.toString()}
								isFW={lengthFavorite > 2}
								onPressItem={onPressItem}
							/>
						);
					})}
				</View>
			)}
		</View>
	);
};

export default FavoriteApps;
