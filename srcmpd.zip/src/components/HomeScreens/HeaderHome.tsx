/* eslint-disable @typescript-eslint/no-shadow */
/* eslint-disable react-hooks/exhaustive-deps */
import React, { forwardRef, useRef, useState, useImperativeHandle, useEffect } from 'react';

import { useIsFocused } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import FImage from 'components/Organisms/FImage/FImage';
import { Header } from 'components/Organisms/Header';
import { ICONS, imgDummy } from 'config';
import useSystem from 'hooks/useSystem';
import { navigate } from 'navigation/RootNavigation';
import { RoutesNames } from 'navigation/RoutesNames';
import { Animated, NativeScrollEvent, NativeSyntheticEvent, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { styles } from 'screens/HomeScreens/HomeScreen.styles';
import store, { useAppDispatch, useAppSelector } from 'stores';
import { updateWorkflowsApps } from 'stores/Apps';
import { fetchCount } from 'stores/Count/thunks';
import { getCountUnReadNotify } from 'stores/Home';
import { updateStatusDrawer } from 'stores/System';

const HeaderHome = ({ refreshing }: { refreshing: boolean }, ref: React.Ref<unknown> | undefined) => {
	const dispatch = useAppDispatch();
	const scrollY = useRef(new Animated.Value(0)).current;
	const insets = useSafeAreaInsets();
	const isFocus = useIsFocused();

	const { countUnRead } = useAppSelector(store => store.home);
	const workflowsApps = useAppSelector(store => store.apps.workflowsApps);

	const { isVN } = useSystem();
	const user = useAppSelector(store => store.dataNotRemove.customer);

	const handleScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
		Animated.timing(scrollY, {
			toValue: event.nativeEvent.contentOffset.y,
			duration: 0,
			useNativeDriver: false,
		}).start();
	};

	useImperativeHandle(
		ref,
		() => ({
			handleScroll,
		}),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[],
	);

	useEffect(() => {
		if (isFocus && workflowsApps?.ID) {
			dispatch(fetchCount());
			dispatch(updateWorkflowsApps(undefined));
		}
	}, [isFocus]);

	useEffect(() => {
		if (isFocus || refreshing) {
			dispatch(getCountUnReadNotify({}));
		}
	}, [isFocus, refreshing]);

	const { FullName, PositionTitle, PositionTitleEN, ImagePath } = user || {};

	const handleOpenDrawer = () => dispatch(updateStatusDrawer(true));

	const onGotoNotify = () => {
		navigate(RoutesNames.Notifications);
	};

	const opacity = scrollY.interpolate({
		inputRange: [0, 10],
		outputRange: [0.01, 0.5],
		extrapolate: 'clamp',
	});
	const elevationShadow = scrollY.interpolate({
		inputRange: [0, 10],
		outputRange: [0.01, 20],
		extrapolate: 'clamp',
	});

	const RenderLeading = (
		<View style={styles.containerLeading}>
			<Icon src={ICONS.icMenu} width={16} height={16} tintColor="rgba(0, 0, 0, 1)" onPress={handleOpenDrawer} />
			<FImage ImagePath={ImagePath} DefaultImagePath={imgDummy} SW={36} />
			<View>
				<Text numberOfLines={1} style={styles.name}>
					{FullName}
				</Text>
				<Text numberOfLines={1} style={styles.position}>
					{isVN ? PositionTitle : PositionTitleEN}
				</Text>
			</View>
		</View>
	);

	const RenderTraling = (
		<View style={styles.containerLeading}>
			<Icon src={ICONS.icScan} width={22} height={22} style={styles.iconScan} />
			<Icon src={countUnRead > 0 ? ICONS.icBellActive : ICONS.icBell} width={24} height={24} onPress={onGotoNotify} />
		</View>
	);
	return (
		<Animated.View
			style={[
				styles.header,
				{
					shadowOpacity: opacity,
					elevation: elevationShadow,
				},
			]}>
			<Header leading={RenderLeading} trailing={RenderTraling} containerStyle={{ paddingTop: insets.top }} />
		</Animated.View>
	);
};

export default forwardRef(HeaderHome);
