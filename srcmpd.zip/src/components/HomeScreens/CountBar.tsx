import React from 'react';

import { useNavigation } from '@react-navigation/native';
import { Icon } from 'components/Atoms/Icon';
import { STATUS_TAKS } from 'components/TaskScreens/consts/consts';
import { COLORS_COUNT_BAR } from 'config/colors';
import { ICONS } from 'config/images';
import { navigate } from 'navigation/RootNavigation';
import { BottomNavigationRoutesNames, RoutesNames } from 'navigation/RoutesNames';
import { View, Text, FlatList, TouchableOpacity } from 'react-native';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateTabScreenTask } from 'stores/System';
import { translate } from 'utils/translate';

import { styles } from './styles/CountBar.styles';

const ICON_COUNT_BAR = {
	Today: ICONS.icClock,
	Overdue: ICONS.icBellWhite,
	MyTask: ICONS.icGPS,
	Follow: ICONS.icGPSArrow,
};

const NAME_COUNT_BAR = {
	Today: 'today',
	Overdue: 'flag_overdue',
	MyTask: 'processing',
	Follow: 'following',
};

const BAR = ['Today', 'Overdue', 'MyTask', 'Follow'];

const CountBar = () => {
	const { count } = useAppSelector(store => store.count);

	const { CountMyTaskToDay, CountMyTaskOverdue, CountMyTask, CountMyFollowItem } = count || {};

	const VALUE_COUNT_BAR = {
		Today: CountMyTaskToDay,
		Overdue: CountMyTaskOverdue,
		MyTask: CountMyTask,
		Follow: CountMyFollowItem,
	};

	const handlePressItem = (item: string) => {
		switch (item) {
			case 'Today':
				navigate(BottomNavigationRoutesNames.TaskScreen, {
					screen: 'myTask',
					toMyTask: STATUS_TAKS.TODAY,
				});
				break;
			case 'Overdue':
				navigate(BottomNavigationRoutesNames.TaskScreen, {
					screen: 'myTask',
					toMyTask: STATUS_TAKS.OVERDUE,
				});
				break;
			case 'MyTask':
				navigate(BottomNavigationRoutesNames.TaskScreen, {
					screen: 'myTask',
					toMyTask: STATUS_TAKS.PROCESSING,
				});
				break;
			case 'Follow':
				navigate(RoutesNames.Follow, { from: RoutesNames.Follow });
				break;

			default:
				break;
		}
	};

	const renderItem = ({ item, index }: { item: string; index: number }) => {
		const Item = item as 'Today' | 'Overdue' | 'MyTask' | 'Follow';
		const onPressItem = () => handlePressItem(item);
		return (
			<TouchableOpacity
				onPress={onPressItem}
				activeOpacity={1}
				style={[
					styles.containerItem,
					{
						backgroundColor: COLORS_COUNT_BAR[Item],
						marginRight: index === 3 ? 24 : 12,
						marginLeft: index === 0 ? 24 : 0,
					},
				]}>
				<View style={{ flexDirection: 'row', alignItems: 'center' }}>
					<Icon src={ICON_COUNT_BAR[Item]} width={16} height={16} tintColor="rgba(255, 255, 255, 1)" />
					<View style={{ alignItems: 'center' }}>
						<Text style={styles.count}>{VALUE_COUNT_BAR[Item] || 0}</Text>
						<Text style={styles.descriptions}>
							{translate(NAME_COUNT_BAR[Item] as 'today' | 'flag_overdue' | 'processing' | 'following')}
						</Text>
					</View>
				</View>
			</TouchableOpacity>
		);
	};

	return (
		<View style={styles.container}>
			{/* {CountMyTask && CountMyTask !== 0 && ( */}
			<FlatList
				data={BAR}
				keyExtractor={(item, index) => index.toString()}
				renderItem={renderItem}
				horizontal
				showsHorizontalScrollIndicator={false}
			/>
			{/* )} */}
		</View>
	);
};

export default CountBar;
