/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable import/no-cycle */
import React, { createRef, forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';

import { RouteProp, useIsFocused } from '@react-navigation/native';
import { Animated, View } from 'react-native';
import { IFilter } from 'screens/TaskScreens/types';
import { ResourcetypeTask } from 'services/Tasks/types';
import { useAppSelector } from 'stores';

import { STATUS_TAKS } from './consts/consts';
import TabBarTaskChildren from './TabBarTaskChildren';
import TaskContainer from './TaskContainer';

type Params = {
	Item: {
		toMyTask: string;
	};
};

const refMyTask = createRef<{ ScrollY: (y: number) => void } | null>();

export const HandleRefMyTask = (y: number) => {
	refMyTask.current?.ScrollY(y);
};

const MyTasks = (
	{ Route, filterMyTask }: { Route: RouteProp<Params, 'Item'> },
	ref: React.Ref<unknown> | undefined,
) => {
	const workflowsApps = useAppSelector(store => store.apps.workflowsApps);

	const translateValue = useRef(new Animated.Value(0)).current;
	const refTaskContainer = useRef<{ handleFilter: (value: IFilter) => void } | null>();
	const isFocus = useIsFocused();
	const refTask = useRef(STATUS_TAKS.PROCESSING);
	const refToMyTask = useRef('');

	const [status, setStatus] = useState<string>('');

	const handleFilter = (value: IFilter, isReset) => {
		refTaskContainer.current?.handleFilter(value, isReset);
	};

	const onSetStatus = (e: string) => {
		setStatus(e);
	};

	useEffect(() => {
		if (Route?.params?.toMyTask !== status && isFocus && Route?.params?.toMyTask !== refToMyTask.current) {
			setStatus(Route?.params?.toMyTask || refTask.current);
			refToMyTask.current = Route?.params?.toMyTask;
		}
		if (!isFocus) {
			if (status) {
				refTask.current = status;
			}
		}
	}, [Route, isFocus]);

	useEffect(() => {
		if (!workflowsApps?.ID) {
			setStatus(STATUS_TAKS.PROCESSING);
		}
	}, [workflowsApps]);

	useImperativeHandle(
		ref,
		() => ({
			handleFilter,
		}),
		[],
	);

	return (
		<View style={{ flex: 1 }}>
			<TabBarTaskChildren
				ref={refMyTask}
				onSetStatus={onSetStatus}
				isMyTask
				status={status}
				translateValue={translateValue}
			/>
			<TaskContainer
				ref={refTaskContainer}
				isMyTask
				status={status}
				type={ResourcetypeTask.MYTASK}
				filter={filterMyTask}
			/>
		</View>
	);
};

export default forwardRef(MyTasks);
