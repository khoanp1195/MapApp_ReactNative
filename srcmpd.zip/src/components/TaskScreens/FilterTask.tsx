/* eslint-disable @typescript-eslint/no-shadow */
import React from 'react';

import { RouteProp, useRoute } from '@react-navigation/native';
import dayjs from 'dayjs';
import LookupScreen from 'screens/Lookup/LookupScreen';
import { IFilter } from 'screens/TaskScreens/types';
import { useAppSelector } from 'stores';

type Params = {
	Item: {
		onUpdateFilter: (value: IFilter, index: number, isActiveFilter: boolean) => void;
		index: number;
		value: IFilter;
		hideState: string[];
	};
};

const FilterTask = () => {
	const route = useRoute<RouteProp<Params, 'Item'>>();
	const workflowsApps = useAppSelector(store => store.apps.workflowsApps);

	const { onUpdateFilter, index, value, hideState } = route.params || {};

	const onUpdateFilterProps = (value: IFilter, isReset) => {
		const { keyword, state, workflow, toDate, fromDate } = value;

		const date30 = new Date(new Date().setDate(new Date().getDate() - 30));

		const workflowID = workflowsApps?.workflowsApps || 0;

		let isActiveFilter = false;
		if (
			keyword ||
			state[0].value !== 0 ||
			workflow[0].WorkflowID !== workflowID ||
			dayjs(toDate).format('DD/MM/YYYY') === dayjs(new Date()).format('DD/MM/YYYY') ||
			dayjs(fromDate).format('DD/MM/YYYY') === dayjs(date30).format('DD/MM/YYYY')
		) {
			isActiveFilter = true;
		}
		onUpdateFilter(value, index, isActiveFilter, isReset);
	};

	return <LookupScreen isTask onUpdateFilterProps={onUpdateFilterProps} value={value} hideState={hideState} />;
};

export default FilterTask;
