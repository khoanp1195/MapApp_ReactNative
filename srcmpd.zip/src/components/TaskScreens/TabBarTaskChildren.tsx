/* eslint-disable @typescript-eslint/no-shadow */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable react/no-unused-prop-types */
import React, { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';

import { Text, TouchableOpacity, View, Animated, Dimensions, Easing } from 'react-native';
import { FlatList } from 'react-native-gesture-handler';
import { useAppSelector } from 'stores';
import { translate } from 'utils/translate';

import { STATUS_TAKS } from './consts/consts';

const BarWidth = Dimensions.get('window').width - 48;

const TabBarTaskChildren = (
	props: {
		isMyTask?: boolean;
		onSetStatus: (e: string) => void;
		status: string;
		translateValue: Animated.Value;
	},
	ref: React.Ref<unknown> | undefined,
) => {
	const { isMyTask = false, onSetStatus, status, translateValue } = props || {};
	const Count = useAppSelector(store => store.count.count);

	const refFlatlist = useRef<FlatList | null>(null);

	const data = [STATUS_TAKS.TODAY, STATUS_TAKS.OVERDUE, STATUS_TAKS.PROCESSING, STATUS_TAKS.COMPLETED];

	const getCount = (name: string) => {
		switch (name) {
			case STATUS_TAKS.TODAY:
				return isMyTask ? Count?.CountMyTaskToDay : Count?.CountMyRequestToDay;
			case STATUS_TAKS.OVERDUE:
				return isMyTask ? Count?.CountMyTaskOverdue : Count?.CountMyRequestOverdue;
			case STATUS_TAKS.PROCESSING:
				return isMyTask ? Count?.CountMyTask : Count?.CountMyRequest;
			case STATUS_TAKS.COMPLETED:
				return isMyTask ? Count?.CountMyTaskProcessed : Count?.CountMyRequestProcessed;

			default:
				return 0;
		}
	};

	const scrollY = useRef(new Animated.Value(0)).current;

	const ScrollY = (y: number) => {
		// if (y > 30)
		Animated.timing(scrollY, { toValue: y, duration: 0, easing: Easing.ease, useNativeDriver: false }).start();
		// else {
		// Animated.timing(scrollY, { toValue: 0, duration: 0, easing: Easing.ease, useNativeDriver: false }).start();
		// }
	};

	useImperativeHandle(
		ref,
		() => ({
			ScrollY,
		}),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[],
	);

	const opacity = scrollY.interpolate({ inputRange: [0, 25, 30], outputRange: [0, 0, 1], extrapolate: 'clamp' });
	const translateY = scrollY.interpolate({ inputRange: [0, 30], outputRange: [-30, 0], extrapolate: 'clamp' });

	const opacity2 = scrollY.interpolate({
		inputRange: [0, 30],
		outputRange: [1, 0],
		extrapolate: 'clamp',
	});

	const zIndex = scrollY.interpolate({
		inputRange: [0, 30],
		outputRange: [0, 99],
		extrapolate: 'clamp',
	});

	const translateY2 = scrollY.interpolate({ inputRange: [0, 30], outputRange: [0, 0], extrapolate: 'clamp' });

	const scrollToIndex = (index: number) => {
		refFlatlist?.current?.scrollToIndex({
			animated: true,
			index,
		});
	};

	const getIndex = () => {
		switch (status) {
			case STATUS_TAKS.TODAY:
				return 0;
			case STATUS_TAKS.OVERDUE:
				return 1;
			case STATUS_TAKS.PROCESSING:
				return 2;
			case STATUS_TAKS.COMPLETED:
				return 3;
			default:
				return 0;
		}
	};

	useEffect(() => {
		const index = getIndex();
		Animated.spring(translateValue, {
			toValue: (index * BarWidth) / 4,
			useNativeDriver: true,
		}).start();
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [status]);

	useEffect(() => {
		if (status === STATUS_TAKS.TODAY || status === STATUS_TAKS.OVERDUE) {
			scrollToIndex(0);
		}
		if (status === STATUS_TAKS.PROCESSING) {
			scrollToIndex(3);
		}
	}, [status]);

	const getItemLayout = (data: unknown, index: number) => {
		const itemHeight = 96;
		return { length: itemHeight, offset: itemHeight * index, index };
	};

	const handleScrollToIndexFailed = () => {
		//
	};

	return (
		<View style={{ zIndex: 99, backgroundColor: 'white' }}>
			<View style={{ zIndex: 99, backgroundColor: 'white' }}>
				<Animated.View
					style={{
						height: 40,
						backgroundColor: 'white',
						position: 'absolute',
						zIndex,
						top: 0,
						width: '100%',
						opacity,
						transform: [{ translateY }],
						flexDirection: 'row',
						justifyContent: 'space-between',
						alignItems: 'center',
						paddingHorizontal: 24,
						shadowColor: '#000',
						shadowOffset: {
							width: 0,
							height: 2,
						},
						shadowOpacity: 0.1,
						shadowRadius: 3.84,

						elevation: 5,
					}}>
					{data.map((e, i) => {
						const isSelect = status === e;
						return (
							<TouchableOpacity
								hitSlop={{
									top: 10,
									bottom: 10,
									left: 10,
									right: 10,
								}}
								key={i?.toString()}
								style={{ flex: 1 }}
								onPress={() => {
									onSetStatus(e);
									if (i === 1) {
										scrollToIndex(0);
									} else {
										scrollToIndex(i);
									}
								}}>
								<Text
									style={{
										textAlign: 'center',
										fontSize: 12,
										fontWeight: '400',
										color: isSelect ? 'rgba(0, 95, 212, 1)' : 'black',
									}}>
									{translate(e as 'today')}
								</Text>
							</TouchableOpacity>
						);
					})}

					<Animated.View
						style={{
							position: 'absolute',
							width: BarWidth / 4,
							backgroundColor: 'rgba(0, 95, 212, 1)',
							bottom: 0,
							transform: [{ translateX: translateValue }],
							borderTopLeftRadius: 4,
							borderTopRightRadius: 4,
							height: 4,
							marginHorizontal: 24,
							zIndex: 99,
						}}
					/>
				</Animated.View>
				<Animated.View
					style={{
						height: 78,
						backgroundColor: 'white',
						position: 'absolute',
						zIndex: 10,
						width: '100%',
						opacity: opacity2,
						transform: [{ translateY: translateY2 }],
					}}>
					<FlatList
						ref={refFlatlist}
						data={data}
						keyExtractor={(item, index) => index.toString()}
						getItemLayout={getItemLayout}
						onScrollToIndexFailed={handleScrollToIndexFailed}
						renderItem={({ item, index }: { item: string; index: number }) => {
							const isSelect = status === item;
							return (
								<TouchableOpacity
									onPress={() => {
										onSetStatus(item);
										if (index === 1) {
											scrollToIndex(0);
										} else {
											scrollToIndex(index);
										}
									}}
									style={{
										width: 96,
										height: 73,
										backgroundColor: isSelect ? 'rgba(0, 95, 212, 1)' : 'rgba(226, 233, 241, 1)',
										borderRadius: 12,
										justifyContent: 'center',
										paddingLeft: 12,
										marginLeft: 16,
										marginRight: index === 3 ? 16 : 0,
									}}>
									<Text style={{ color: isSelect ? 'white' : 'black', fontSize: 20, fontWeight: '700' }}>
										{getCount(item)}
									</Text>
									<Text style={{ color: isSelect ? 'white' : 'black', fontSize: 12, fontWeight: '400' }}>
										{translate(item as 'today')}
									</Text>
								</TouchableOpacity>
							);
						}}
						horizontal
						showsHorizontalScrollIndicator={false}
					/>
				</Animated.View>
			</View>
		</View>
	);
};

export default forwardRef(TabBarTaskChildren);
