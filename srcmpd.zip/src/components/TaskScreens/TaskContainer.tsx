/* eslint-disable react/no-unstable-nested-components */
/* eslint-disable import/no-cycle */
import React, { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';

import { useIsFocused } from '@react-navigation/native';
import { COLORS } from 'config';
import {
	View,
	FlatList,
	RefreshControl,
	NativeSyntheticEvent,
	NativeScrollEvent,
	Dimensions,
	LayoutAnimation,
	Platform,
	Text,
	ActivityIndicator,
} from 'react-native';
import { ResourcetypeTask } from 'services/Tasks/types';
import { translate } from 'utils/translate';

import { useTasks } from './hooks/useTask';
import ItemTask, { IItemTask } from './ItemTask';
import { HandleRefMyRequests } from './MyRequest';
import { HandleRefMyTask } from './MyTask';

const TaskContainer = (
	{
		status,
		type,
		isMyTask = false,
		filter,
	}: { status: string; type: ResourcetypeTask.MYTASK | ResourcetypeTask.MYREQUEST; isMyTask?: boolean },
	ref: React.Ref<unknown> | undefined,
) => {
	const flatListRef = useRef<FlatList | null>(null);
	const isFocused = useIsFocused();
	const windowHeight = Dimensions.get('window').height;

	const lastOffset = useRef<number>(0);
	const scrollDirection = useRef('');

	const {
		dataTask,
		refreshing,
		refreshPage,
		handleFillter,
		handleEndReached,
		handleNavigateToDetail,
		handleNavigateToTask,
		updateRead,
		loading,
	} = useTasks({
		type,
		status,
		isFocused,
		filter,
	});

	useImperativeHandle(
		ref,
		() => ({
			handleFilter: handleFillter,
			handleRefresh: refreshPage,
		}),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[status],
	);

	// useEffect(() => {
	// 	LayoutAnimation.easeInEaseOut();
	// }, [dataTask]);

	useEffect(() => {
		if (isMyTask) {
			HandleRefMyTask(0);
		} else {
			HandleRefMyRequests(0);
		}
	}, [isMyTask, status]);

	const onScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
		const { y } = event.nativeEvent.contentOffset;
		scrollDirection.current = y - lastOffset.current > 0 ? 'down' : 'up';
		lastOffset.current = y;
		if (isMyTask) {
			HandleRefMyTask(event.nativeEvent.contentOffset.y);
		} else {
			HandleRefMyRequests(event.nativeEvent.contentOffset.y);
		}
	};

	const onScrollEndDrag = () => {
		if (dataTask?.length > 3) {
			if (scrollDirection.current === 'down' && lastOffset.current < 30) {
				return flatListRef.current?.scrollToIndex({
					index: 1,
					animated: true,
				});
			}
			if (scrollDirection.current === 'up' && lastOffset.current < 30) {
				flatListRef.current?.scrollToIndex({
					index: 0,
					animated: true,
				});
			}
		}
	};

	const renderItem = ({ item }: { item: IItemTask }) => {
		return (
			<ItemTask
				item={item}
				type={type}
				status={status}
				updateRead={updateRead}
				handleNavigateToDetail={handleNavigateToDetail}
				handleNavigateToTask={handleNavigateToTask}
			/>
		);
	};

	const ListFooterComponent = () => {
		return (
			<View>
				{loading && <ActivityIndicator size="small" style={{ marginTop: dataTask?.length ? 32 : 20 }} />}
				<View style={{ height: 100 }} />
			</View>
		);
	};

	const getItemLayout = (data: unknown, index: number) => {
		const itemHeight = 130;
		const offset = itemHeight * index;
		return {
			length: itemHeight,
			offset,
			index,
		};
	};

	const keyExtractor = (_item: unknown, index: number) => index?.toString();

	const refreshControl = <RefreshControl refreshing={refreshing} onRefresh={refreshPage} tintColor="white" />;

	return (
		<View style={{ flex: 1 }}>
			<View style={{ height: 40 }} />

			{!loading && !dataTask?.length && (
				<View style={{ marginTop: 40 }}>
					<Text style={{ fontSize: 12, fontStyle: 'italic', textAlign: 'center', paddingTop: 12 }}>
						{translate('noResult')}
					</Text>
				</View>
			)}

			<FlatList
				ref={flatListRef}
				data={dataTask}
				style={{ flex: 1, paddingTop: 30 }}
				onEndReached={handleEndReached}
				onEndReachedThreshold={0.7}
				keyExtractor={keyExtractor}
				renderItem={renderItem}
				showsVerticalScrollIndicator={false}
				scrollEventThrottle={16}
				onScroll={onScroll}
				onScrollEndDrag={onScrollEndDrag}
				ListFooterComponent={ListFooterComponent}
				nestedScrollEnabled
				removeClippedSubviews={Platform.OS !== 'ios'}
				getItemLayout={getItemLayout}
				refreshControl={refreshControl}
				renderToHardwareTextureAndroid
			/>
		</View>
	);
};

export default forwardRef(TaskContainer);
