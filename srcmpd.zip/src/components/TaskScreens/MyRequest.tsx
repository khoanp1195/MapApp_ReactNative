/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable import/no-cycle */
import React, { createRef, forwardRef, useEffect, useState, useImperativeHandle, useRef } from 'react';

import { RouteProp, useIsFocused } from '@react-navigation/native';
import { Animated, View } from 'react-native';
import { IFilter } from 'screens/TaskScreens/types';
import { ResourcetypeTask } from 'services/Tasks/types';

import { STATUS_TAKS } from './consts/consts';
import TabBarTaskChildren from './TabBarTaskChildren';
import TaskContainer from './TaskContainer';

type Params = {
	Item: {
		toMyRequest: string;
	};
};

const refMyRequests = createRef<{ ScrollY: (y: number) => void } | null>();

export const HandleRefMyRequests = (y: number) => {
	refMyRequests.current?.ScrollY(y);
};

const MyRequests = (
	{ Route, filterMyRequest }: { Route: RouteProp<Params, 'Item'> },
	ref: React.Ref<unknown> | undefined,
) => {
	const translateValue = useRef(new Animated.Value(0)).current;
	const refTaskContainer = useRef<{ handleFilter: (value: IFilter) => void } | null>();
	const isFocus = useIsFocused();
	const [status, setStatus] = useState(STATUS_TAKS.TODAY);
	const refTask = useRef(STATUS_TAKS.PROCESSING);
	const refToMyRequest = useRef('');

	const handleFilter = (value: IFilter) => {
		refTaskContainer.current?.handleFilter(value);
	};

	const onSetStatus = (e: string) => {
		setStatus(e);
	};

	useImperativeHandle(
		ref,
		() => ({
			handleFilter,
		}),
		[],
	);
	useEffect(() => {
		if (Route?.params?.toMyRequest !== status && isFocus && Route?.params?.toMyRequest !== refToMyRequest.current) {
			setStatus(Route?.params?.toMyRequest || refTask.current);
			refToMyRequest.current = Route?.params?.toMyRequest;
		}
		if (!isFocus) {
			if (status) {
				refTask.current = status;
			}
		}
	}, [Route, isFocus]);

	return (
		<View style={{ flex: 1 }}>
			<TabBarTaskChildren
				ref={refMyRequests}
				onSetStatus={onSetStatus}
				status={status}
				translateValue={translateValue}
			/>
			<TaskContainer
				ref={refTaskContainer}
				status={status}
				type={ResourcetypeTask.MYREQUEST}
				filter={filterMyRequest}
			/>
		</View>
	);
};

export default forwardRef(MyRequests);
