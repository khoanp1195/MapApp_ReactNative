import React from 'react';

import { Text } from '@react-native-material/core';
import { MaterialTopTabBarProps } from '@react-navigation/material-top-tabs';
import { Icon } from 'components/Atoms/Icon';
import { COLORS, ICONS } from 'config';
import useSystem from 'hooks/useSystem';
import { navigate } from 'navigation/RootNavigation';
import { BottomNavigationRoutesNames } from 'navigation/RoutesNames';
import { TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppDispatch, useAppSelector } from 'stores';
import { updateStatusDrawer } from 'stores/System';
import { translate } from 'utils/translate';

interface Props extends MaterialTopTabBarProps {
	trailing?: React.ReactNode;
}

export const MaterialTopTabsNavigator: React.FC<Props> = ({ navigation, state, trailing }): React.ReactElement => {
	const dispatch = useAppDispatch();
	const workflowsApps = useAppSelector(store => store.apps.workflowsApps);
	const { isVN } = useSystem();
	const titleWorkflow = isVN ? workflowsApps?.Title : workflowsApps?.TitleEN;

	const isWorkflowApps = !!titleWorkflow;

	const handleOpenDrawer = () => {
		if (isWorkflowApps) {
			navigate(BottomNavigationRoutesNames.Home);
		} else {
			dispatch(updateStatusDrawer(true));
		}
	};

	return (
		<SafeAreaView
			edges={['top']}
			style={{
				// flexDirection: 'row',
				// alignItems: 'center',
				overflow: 'hidden',
				paddingHorizontal: 16,
			}}>
			{isWorkflowApps && (
				<View style={{ marginBottom: 4, flexDirection: 'row', alignItems: 'center', marginTop: 2 }}>
					<Icon
						src={ICONS.icArrowMenu}
						width={isWorkflowApps ? 24 : 16}
						height={isWorkflowApps ? 24 : 16}
						tintColor="rgba(0, 0, 0, 1)"
						onPress={handleOpenDrawer}
					/>
					<Text numberOfLines={1} style={{ fontWeight: '700', fontSize: 18, marginLeft: 10 }}>
						{titleWorkflow}
					</Text>
				</View>
			)}
			<View
				style={{
					flexDirection: 'row',
					alignItems: 'center',
					overflow: 'hidden',
					// paddingHorizontal: 24,
					marginBottom: 6,
					marginTop: -2,
				}}>
				{!isWorkflowApps && (
					<Icon
						src={ICONS.icMenu}
						width={16}
						height={16}
						tintColor="rgba(0, 0, 0, 1)"
						onPress={handleOpenDrawer}
						style={{ marginTop: 2 }}
					/>
				)}
				<View
					style={{
						flexDirection: 'row',
						// marginBottom: 10,
						alignItems: 'center',
						overflow: 'hidden',
						flex: 1,
						marginLeft: isWorkflowApps ? 0 : 10,
					}}>
					{state.routes.map((route, index) => {
						const isFocused = state.index === index;
						const onPress = () => {
							const event = navigation.emit({
								type: 'tabPress',
								target: route.key,
								canPreventDefault: true,
							});

							if (!isFocused && !event.defaultPrevented) {
								navigate(route.name);
							}
						};
						return (
							<View
								style={{
									flexDirection: 'row',
									overflow: 'hidden',
									flex: index === 1 ? 1 : 0,
									justifyContent: 'flex-start',
								}}
								key={index?.toString()}>
								<TouchableOpacity onPress={onPress}>
									<Text
										numberOfLines={1}
										style={{
											fontSize: 20,
											fontWeight: '700',
											color: isFocused ? 'rgba(0, 0, 0, 1)' : 'rgba(157, 157, 157, 1)',
											textAlign: 'left',
										}}>
										{translate(route.name as 'myTask' | 'myRequest')}
									</Text>
								</TouchableOpacity>
								{index === 0 && (
									<View
										style={{
											width: 2,
											backgroundColor: 'rgba(217, 217, 217, 1)',
											marginHorizontal: 10,
										}}
									/>
								)}
							</View>
						);
					})}
				</View>
				{trailing}
			</View>
		</SafeAreaView>
	);
};

MaterialTopTabsNavigator.defaultProps = {
	trailing: null,
};
