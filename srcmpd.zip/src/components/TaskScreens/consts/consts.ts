export const STATUS_TAKS = {
	TODAY: 'flag_same_day',
	OVERDUE: 'flag_overdue',
	PROCESSING: 'processing',
	COMPLETED: 'status_completed',
};
