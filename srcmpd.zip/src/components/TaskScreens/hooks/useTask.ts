/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable @typescript-eslint/restrict-template-expressions */
import { ENDPOINT } from 'http/modules/Request';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

import useInfinity from 'hooks/useInfinity';
import moment from 'moment';
import { navigate } from 'navigation/RootNavigation';
import { RoutesNames } from 'navigation/RoutesNames';
import { IFilter } from 'screens/TaskScreens/types';
import { ITask, ResourcetypeTask } from 'services/Tasks/types';
import { useAppDispatch, useAppSelector } from 'stores';
import { fetchCount } from 'stores/Count';
import { reloadWorkflow } from 'stores/System';

import { STATUS_TAKS } from '../consts/consts';
import { IItemTask } from '../ItemTask';

export const useTasks = (params: {
	type: ResourcetypeTask.MYTASK | ResourcetypeTask.MYREQUEST;
	status: string;
	isFocused: boolean;
	filter;
}) => {
	const workflowsApps = useAppSelector(store => store.apps.workflowsApps);

	const workflow = workflowsApps?.ID
		? [{ Title: workflowsApps?.Title, TitleEN: workflowsApps?.TitleEN, WorkflowID: workflowsApps?.WorkflowID }]
		: [{ Title: 'Tất cả', TitleEN: 'All', WorkflowID: 0 }];

	const DefaultFilter = {
		toDate: '',
		fromDate: '',
		state: [{ label: 'Tất cả', value: 0, labelEN: 'All' }],
		workflow,
		keyword: '',
	};
	const { type, status, isFocused = false } = params || {};
	const dispatch = useAppDispatch();
	const { isReload } = useAppSelector(store => store.system);
	const currentFilterValues = params.filter;
	const totalPageRef = useRef<number>(0);
	const { language } = useAppSelector(state => state.dataNotRemove);
	const refStatus = useRef<string>('');

	const [dataTask, setDattaTask] = useState<Array<ITask>>([]);

	const getValueData = () => {
		// ViewType:
		// 2: Đang xử lý,
		// 4: Đã xử lý
		// Flag:
		// 0: lấy tất cả các phiếu,
		// 1: Lấy các phiếu trong ngày,
		// 2: Lấy các phiếu trễ hạn
		switch (status) {
			case STATUS_TAKS.TODAY:
				return {
					ViewType: 2,
					Flag: 1,
				};
			case STATUS_TAKS.OVERDUE:
				return {
					ViewType: 2,
					Flag: 2,
				};
			case STATUS_TAKS.PROCESSING:
				return {
					ViewType: 2,
					Flag: 0,
				};
			case STATUS_TAKS.COMPLETED:
				return {
					ViewType: 4,
					Flag: 0,
				};

			default:
				return {
					ViewType: 2,
					Flag: 1,
				};
		}
	};

	const valueData = useMemo(() => {
		return getValueData();
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [status]);

	const getStatus = () => {
		if (!currentFilterValues?.state) return '';
		const statusGroupFilter = currentFilterValues?.state?.some(v => v.value === 0)
			? ''
			: currentFilterValues?.state?.map(v => v.value).join(',');
		return statusGroupFilter;
	};

	const defaultDataApi = {
		WorkflowID: currentFilterValues?.workflow?.[0]?.WorkflowID || 0,
		ViewType: valueData.ViewType,
		Flag: valueData.Flag,
		FromDate: currentFilterValues?.fromDate ? moment(currentFilterValues?.fromDate).format('YYYY-MM-DD') : '',
		ToDate: currentFilterValues?.toDate ? moment(currentFilterValues?.toDate).format('YYYY-MM-DD') : '',
		StatusGroup: getStatus(),
		Keyword: currentFilterValues.keyword,
	};

	const {
		state: { data: dataRes, refreshing, loading, page },
		gotoFirstPage,
		refreshPage,
		fetchMore,
	} = useInfinity<Array<ITask>>(`${ENDPOINT.WORKFLOW}`, {
		size: 10,
		requireAuthentication: true,
		params: {
			func: 'getList',
			data: JSON.stringify(defaultDataApi),
			resourcetype: type,
			lid: language === 'vi' ? 1066 : 1033,
			totalrecord: refStatus.current !== status ? 0 : totalPageRef.current,
		},
		onSuccess: res => {
			if (!res.data) return;
			totalPageRef.current = res.data?.TotalRecord;
		},
	});

	const handleFillter = (data: IFilter, isReset?: boolean) => {
		// if (isReset) {
		// 	currentFilterValues.current = DefaultFilter;
		// } else {
		// 	currentFilterValues.current = data;
		// }
		const { workflow, state, fromDate, toDate, keyword } = data || {};
		totalPageRef.current = 0;
		const statusGroupFilter = state?.some(v => v.value === 0)
			? ''
			: `,"StatusGroup":"${state?.map(v => v.value).join(',')}"`;
		gotoFirstPage({
			params: {
				func: 'getList',
				data: `{"WorkflowID":${workflow?.[0]?.WorkflowID},"ViewType":${valueData.ViewType},"Flag":${
					valueData.Flag
				}${statusGroupFilter},"FromDate":"${fromDate ? moment(fromDate).format('YYYY-MM-DD') : ''}","ToDate":"${
					toDate ? moment(toDate).format('YYYY-MM-DD') : ''
				}", "Keyword":${JSON.stringify(keyword || '')}}`,
				resourcetype: type,
				lid: language === 'vi' ? 1066 : 1033,
				totalrecord: totalPageRef.current,
			},
		});
	};

	useEffect(() => {
		if (refStatus.current) {
			handleFillter(params.filter);
		}
	}, [params.filter]);

	useEffect(() => {
		// currentFilterValues.current = DefaultFilter;
		if (status && isFocused && refStatus.current !== status) {
			gotoFirstPage();
		}
		refStatus.current = status;
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [status, isFocused]);

	useEffect(() => {
		// if (dataRes) {
		setDattaTask(dataRes?.Data || []);
		// }
	}, [dataRes]);

	const handleEndReached = () => {
		if (loading) return;
		if (dataTask?.length < totalPageRef.current) {
			fetchMore();
		}
	};

	const checkRefresh = (isCallCount = false) => {
		if (currentFilterValues) {
			handleFillter(currentFilterValues);
		} else {
			refreshPage();
		}
		if (!isCallCount) {
			dispatch(fetchCount({ WorkflowId: workflowsApps?.WorkflowID || 0 }));
		}
	};

	useEffect(() => {
		if (totalPageRef.current) {
			checkRefresh();
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [language]);

	useEffect(() => {
		if (isReload) {
			checkRefresh(type !== ResourcetypeTask.MYTASK);
			dispatch(reloadWorkflow(false));
		}
	}, [isReload]);

	const updateRead = useCallback(
		(ID: number) => {
			const cloneData: ITask[] = JSON.parse(JSON.stringify(dataTask));
			const index = dataTask.findIndex(task => task.ID === ID);
			if (index === -1) return;
			cloneData[index] = { ...cloneData[index], Read: true };
			setDattaTask(cloneData);
		},
		[dataTask],
	);

	const handleNavigateToDetail = useCallback((item: IItemTask) => {
		navigate(RoutesNames.WorkflowDetails, { item });
	}, []);

	const handleNavigateToTask = useCallback((item: any) => {
		// navigate(RoutesNames.Task, { item });
	}, []);

	return {
		page,
		dataTask,
		loading,
		refreshing,
		refreshPage: checkRefresh,
		handleFillter,
		handleEndReached,
		updateRead,
		handleNavigateToDetail,
		handleNavigateToTask,
	};
};
