/* eslint-disable prettier/prettier */
import React, { forwardRef, useRef, useState, useImperativeHandle, useMemo } from 'react';

import { Icon } from 'components/Atoms/Icon';
import ModalCalendarRef from 'components/LookupScreens/ModalCalendarRef';
import ModalState from 'components/LookupScreens/ModalState';
import ModalWorkflow from 'components/LookupScreens/ModalWorkflow';
import ModalRef from 'components/Molecules/Modal/ModalRef';
import { ICONS } from 'config/images';
import useSystem from 'hooks/useSystem';
import { View, FlatList, TouchableOpacity, Text, Dimensions } from 'react-native';
import dayjs from 'utils/dayjs';
import { translate } from 'utils/translate';

import { styles } from './styles/ModalFilter.styles';


interface IState {
	value: number;
	label: string;
	labelEN: string;
}
const windowHeight = Dimensions.get('window').height;
interface IWorkflow {
	ID: number;
	WorkflowID: number;
	Title: string;
	TitleEN: string;
	Description: any;
	ImageURL: string;
	IsFavor: number;
	WorkflowCategory: string;
	WorkflowCategoryID: number;
}

interface IState {
	value: number;
	label: string;
	labelEN: string;
}


const ModalFilter = ({ onHide, onSubmitSelect }: {
	onHide?: () => void, onSubmitSelect?: ({ value, index }: {
		value: any;
		index: number;
	}) => void
}, ref: React.Ref<unknown> | undefined) => {
	const refModal = useRef<{ show: () => void; hide: () => void } | null>(null);
	const refModalState = useRef<{ show: () => void; hide: () => void } | null>(null);
	const refModalWorkflow = useRef<{ show: () => void; hide: () => void } | null>(null);
	const refModalCalendar = useRef<{ show: (options: any) => void } | null>(null);
	const refIndex = useRef()
	const { isVN } = useSystem()

	const [workflow, setWorkflow] = useState<IWorkflow[]>([]);
	const [state, setState] = useState<IState[]>([]);
	const [fromDate, setFromDate] = useState(new Date(new Date().setDate(new Date().getDate() - 30)));
	const [toDate, setToDate] = useState(new Date());


	const onSubmitSelectWorkflow = (select: IWorkflow[]) => setWorkflow(select);

	const onSubmitSelectState = (select: IState[]) => setState(select);

	const onSubmitSelectDate = ({ isFromDate, date }: { isFromDate: boolean; date: Date }) => {
		if (isFromDate) return setFromDate(date);
		return setToDate(date);
	};

	const getNameWorkflow = () => {
		if (!workflow?.length) return translate('select_workflow');
		const listName: string[] = workflow.map(item => (isVN ? item.Title : item.TitleEN));
		return listName.toString().replaceAll(',', ', ') || '';
	};

	const getNameState = () => {
		if (!state?.length) return translate('select_state');
		const listName: string[] = state.map(item => (isVN ? item.label : item.labelEN));
		return listName.toString().replaceAll(',', ', ') || '';
	};




	const show = ({ value, index }) => {
		refIndex.current = index
		const { toDate, fromDate, state, workflow } = value || {}
		setWorkflow(workflow)
		setState(state)
		setToDate(toDate)
		setFromDate(fromDate)
		refModal.current?.show()
	}
	const hide = () => refModal.current?.hide()

	useImperativeHandle(
		ref,
		() => ({
			show,
			hide
		}),
		[],
	);



	const onOpenCalendarFormDate = () => {
		const options = {
			headerTitle: translate('from_date'),
			defaultValue: fromDate,
			maxDate: toDate,
		};
		refModalCalendar.current?.show(options);
	};

	const onOpenCalendarToDate = () => {
		const options = {
			headerTitle: translate('to_date'),
			defaultValue: toDate,
			maxDate: '',
		};
		refModalCalendar.current?.show(options);
	};

	const onSubmitFilter = () => {
		hide()
		onSubmitSelect({
			value: {
				toDate,
				fromDate,
				state,
				workflow,
			},
			index: refIndex.current
		})
	}

	const onResetFilter = () => {
		setWorkflow([{ Title: 'Tất cả', TitleEN: 'All', WorkflowID: 0 }])
		setState([{ label: 'Tất cả', value: 0, labelEN: 'All' }])
		setToDate(new Date())
		setFromDate(new Date(new Date().setDate(new Date().getDate() - 30)))
	}



	return <ModalRef
		ref={refModal}
		onHide={onHide}
		outsideClickCloseable
		onClose={hide}
		visiblePosition="bottom"
		container={{ backgroundColor: 'white' }}
	>
		<View style={{ paddingHorizontal: 24, height: windowHeight * 0.85 }} >
			<View style={styles.options}>
				<Text style={styles.titleWorkflow}>{translate('workflow')}</Text>
				<TouchableOpacity activeOpacity={1} style={styles.buttonWorkflow} onPress={() => refModalWorkflow.current?.show(workflow)}>
					<Text style={styles.nameWf}>{getNameWorkflow()}</Text>
					<Icon src={ICONS.icChevronDown} width={20} height={20} />
				</TouchableOpacity>
			</View>
			<View style={styles.vState}>
				<Text style={styles.tState}>{translate('state')}</Text>
				<TouchableOpacity activeOpacity={1} style={styles.bState} onPress={() => refModalState.current?.show(state)}>
					<Text style={styles.nState}>{getNameState()}</Text>
				</TouchableOpacity>
			</View>
			<View style={styles.dvd} />

			{/* <View style={styles.cDate}> */}
			{/* <Text style={styles.tFromDate}>{translate('date_created')}</Text> */}
			<View style={styles.vFromDate}>
				<TouchableOpacity style={{ flex: 1 }} onPress={onOpenCalendarFormDate}>
					<Text style={styles.nFromDate}>{translate('from_date')}</Text>
					<View style={styles.vDate}>
						<Icon src={ICONS.icCalendarNew} width={20} height={20} />
						<Text style={styles.tDate}>{dayjs(fromDate).format(isVN ? 'DD/MM/YYYY' : 'MM/DD/YYYY')}</Text>
					</View>
				</TouchableOpacity>
				<TouchableOpacity style={{ flex: 1 }} onPress={onOpenCalendarToDate}>
					<Text style={styles.nFromDate}>{translate('to_date')}</Text>
					<View style={styles.vDate}>
						<Icon src={ICONS.icCalendarNew} width={20} height={20} />
						<Text style={styles.tDate}>{dayjs(toDate).format(isVN ? 'DD/MM/YYYY' : 'MM/DD/YYYY')}</Text>
					</View>
				</TouchableOpacity>
			</View>
			{/* </View> */}
			<View style={styles.dvd} />
			<View style={{ flexDirection: 'row', marginVertical: 30 }}>
				<TouchableOpacity style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }} onPress={onResetFilter}>
					<Text style={{ fontStyle: 'italic' }}>{translate('filter_reset')}</Text>
				</TouchableOpacity>
				<TouchableOpacity onPress={onSubmitFilter} style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(0, 95, 212, 1)', paddingVertical: 12 }}>
					<Text style={{ color: 'white' }}>{translate('filter_apply')}</Text>
				</TouchableOpacity>
			</View>
			<ModalCalendarRef ref={refModalCalendar} onSubmitSelect={onSubmitSelectDate} />
			<ModalWorkflow isMulti ref={refModalWorkflow} onSubmitSelect={onSubmitSelectWorkflow} />
			<ModalState ref={refModalState} onSubmitSelect={onSubmitSelectState} />
		</View>
	</ModalRef >
}

export default forwardRef(ModalFilter)
