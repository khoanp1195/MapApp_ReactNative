/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable import/no-cycle */
/* eslint-disable react/no-unstable-nested-components */
import React, { memo, useCallback } from 'react';

import { Icon } from 'components/Atoms/Icon';
import FImage from 'components/Organisms/FImage/FImage';
import { COLOR_STATUS, COLOR_TEXT_STATUS, ICONS } from 'config';
import dayjs from 'dayjs';
import useSystem from 'hooks/useSystem';
import { View, Text, TouchableOpacity } from 'react-native';
import { ResourcetypeTask } from 'services/Tasks/types';
import { useAppSelector } from 'stores';
import { translate } from 'utils/translate';

import { STATUS_TAKS } from './consts/consts';
import { styles } from './styles/ItemTask.styles';

export interface IItemTask {
	ID: number;
	IsFollow: number;
	Read: boolean;
	ListID: string;
	SPItemId: number;
	NotifyId: string;
	NotifyCreated: string;
	Content: string;
	WorkflowId: number;
	AssignedBy: string;
	AssignedByInfo: string;
	AssignedTo: string;
	Created: string;
	StatusGroup: number;
	DueDate: Date;
	FileCount: number;
	CommentCount: number;
	Flag: number;
	ResourceCategoryId: number;
	ResourceSubCategoryId: number;
	Workflow: string;
	TotalRecord: number;
	AssignedToInfo: string;
	CreatedByInfo: string;
}

interface IParamsItemTask {
	item: IItemTask;
	type?: string;
	handleNavigateToDetail: (item: IItemTask) => void;
	updateRead: (ID: number) => void;
	handleNavigateToTask: (item: IItemTask) => void;
	status?: string;
	isLookup?: boolean;
}

interface InfoUser {
	NumExpand: number;
	DefaultImagePath: string;
	ImagePath: string;
	Name: string;
}

const ItemTask = ({
	item,
	type,
	status,
	handleNavigateToDetail,
	updateRead,
	handleNavigateToTask,
	isLookup = false,
}: IParamsItemTask) => {
	const {
		FileCount,
		CommentCount,
		Workflow,
		Content,
		AssignedByInfo = '{}',
		Created,
		DueDate,
		StatusGroup,
		Read,
		ID,
		AssignedToInfo = '{}',
		ResourceSubCategoryId,
		ResourceCategoryId,
		CreatedByInfo,
	} = item || {};

	const { isVN, formatDateTime } = useSystem();
	const { beanAppStatus } = useAppSelector(store => store.system);

	const getAssign = useCallback(() => {
		if ((type === ResourcetypeTask.MYTASK && status === STATUS_TAKS.COMPLETED) || type === ResourcetypeTask.MYREQUEST)
			return JSON.parse(AssignedToInfo || '{}');
		return JSON.parse(AssignedByInfo || '{}');
	}, [AssignedToInfo, AssignedByInfo, status, type]);

	const getAssignLookup = useCallback(() => {
		const ToInfo: InfoUser = JSON.parse(AssignedToInfo || '{}');
		const ByInfo = JSON.parse(CreatedByInfo || '{}');
		if (typeof ToInfo === 'object') {
			if (Object.keys(ToInfo)?.length) return ToInfo;
		}
		return ByInfo;
	}, [AssignedToInfo, CreatedByInfo]);

	const assignedInfo: InfoUser = isLookup ? getAssignLookup() : getAssign();

	const { Name, ImagePath, DefaultImagePath, NumExpand = 0 } = assignedInfo || {};

	const statusGroupItem = beanAppStatus?.find(v => v.ID === StatusGroup);

	const TimeCreated = dayjs(Created).format(formatDateTime) || '';

	const getDueDate = useCallback(() => {
		const date1 = dayjs(DueDate);
		const date2 = dayjs();

		const hours = date1.diff(date2, 'hours');
		const days = Math.floor((hours > 0 ? hours : hours * -1) / 24);

		if (days > 7) return { title: `${dayjs(DueDate).format(formatDateTime)}`, color: 'rgba(123, 123, 123, 1)' };
		if (days === 0) return { title: translate('to_day'), color: 'rgba(139, 79, 183, 1)' };
		if (hours < 0) return { title: `${days * -1} ${translate('days')}`, color: 'rgba(237, 78, 73, 1)' };
		if (hours > 0) return { title: `${days} ${translate('days')}`, color: 'rgba(123, 123, 123, 1)' };
	}, [DueDate, formatDateTime]);

	const infoDueDate = getDueDate();

	const onPress = () => {
		if (ResourceCategoryId === 16 && ResourceSubCategoryId === 0) {
			handleNavigateToTask(item);
		} else {
			handleNavigateToDetail(item);
		}
		if (!Read) updateRead(ID);
	};

	return (
		<TouchableOpacity activeOpacity={1} style={styles.container} onPress={onPress}>
			<View style={styles.vContainer}>
				<View style={styles.vInfoUser}>
					<FImage ImagePath={ImagePath} DefaultImagePath={DefaultImagePath} mh={0} SW={32} />
					<View style={styles.vName}>
						<Text numberOfLines={1} style={styles.tName}>
							{Name}
						</Text>
						<Text style={styles.tExpand}>{NumExpand ? ` +${NumExpand}` : ''}</Text>
					</View>
					<Text numberOfLines={1} style={styles.tTime}>
						{TimeCreated}
					</Text>
				</View>

				<Text style={[styles.tContent, { fontWeight: Read ? '400' : '700' }]} numberOfLines={2}>
					{Content}
				</Text>
				<Text style={styles.tWorkflow} numberOfLines={2}>
					{Workflow}
				</Text>

				<View style={styles.vInfoWorkflow}>
					{!!CommentCount && (
						<View style={styles.vCountComment}>
							<Icon src={ICONS.icChat} width={16} height={16} />
							<Text style={styles.tCountComment}>{CommentCount}</Text>
						</View>
					)}
					{!!FileCount && (
						<View style={styles.vCountFile}>
							<Icon src={ICONS.icFile} width={16} height={16} />
							<Text style={styles.tCountFile}>{FileCount}</Text>
						</View>
					)}
					{!!DueDate && (
						<View style={styles.vDate}>
							<Icon src={ICONS.icClock} width={16} height={16} />
							<Text style={[styles.tDate, { color: infoDueDate?.color }]}>{infoDueDate?.title}</Text>
						</View>
					)}
					<View style={styles.vTitle}>
						<View style={[styles.vButtonTitle, { backgroundColor: COLOR_STATUS[StatusGroup] }]}>
							<Text style={{ color: COLOR_TEXT_STATUS[StatusGroup], fontSize: 12 }}>
								{isVN ? statusGroupItem?.Title : statusGroupItem?.TitleEN}
							</Text>
						</View>
					</View>
				</View>
			</View>
			<View style={styles.dvd} />
		</TouchableOpacity>
	);
};

export default memo(ItemTask);
