import React, { createRef, useRef } from 'react';

import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import { MaterialTopTabsNavigator } from 'components/Organisms/MaterialTopTabsNavigator';
import { COLORS } from 'config';
import { Animated, ScrollView, Text, View, FlatList, Easing } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LoginScreen } from 'screens/Login';

const Report = () => {
	const scrollY = useRef(new Animated.Value(0)).current;
	const flatListRef = useRef<FlatList | null>(null);
	const lastOffset = useRef(0);
	const scrollDirection = useRef('');
	const show = (y: number) => {
		Animated.timing(scrollY, { toValue: y, duration: 0, easing: Easing.ease, useNativeDriver: true }).start();
		if (y > 30) {
			Animated.timing(scrollY, { toValue: 30, duration: 0, easing: Easing.ease, useNativeDriver: true }).start();
		} else {
			Animated.timing(scrollY, { toValue: 0, duration: 0, easing: Easing.ease, useNativeDriver: true }).start();
		}
	};
	const opacity = scrollY.interpolate({ inputRange: [0, 25, 30], outputRange: [0, 0, 1], extrapolate: 'clamp' });
	const translateY = scrollY.interpolate({ inputRange: [0, 30], outputRange: [0, 0], extrapolate: 'clamp' });

	const opacity2 = scrollY.interpolate({
		inputRange: [0, 25, 30],
		outputRange: [1, 1, 0],
		extrapolate: 'clamp',
	});

	const select = 1;

	return (
		<SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
			<View style={{ flex: 1 }}>
				<Animated.View
					style={{
						height: 30,
						backgroundColor: 'white',
						position: 'absolute',
						zIndex: 99,
						top: 0,
						width: '100%',
						opacity,
						transform: [{ translateY }],
						flexDirection: 'row',
						justifyContent: 'space-between',
						alignItems: 'center',
						paddingHorizontal: 24,
						shadowColor: '#000',
						shadowOffset: {
							width: 0,
							height: 5,
						},
						shadowOpacity: 0.3,
						shadowRadius: 3.84,

						elevation: 5,
					}}>
					{[1, 2, 3, 4].map(item => {
						const isSelect = select === item;
						return (
							<View key={item.toString()} style={{ flex: 1 }}>
								<Text style={{ textAlign: 'center' }}>{item}</Text>
								<View style={{ height: 4, backgroundColor: isSelect ? 'blue' : 'white' }} />
							</View>
						);
					})}
				</Animated.View>
				<Animated.View
					style={{
						height: 78,
						backgroundColor: 'white',
						position: 'absolute',
						zIndex: 100,
						width: '100%',
						opacity: opacity2,
					}}>
					<FlatList
						horizontal
						showsHorizontalScrollIndicator={false}
						data={[1, 2, 3, 4]}
						keyExtractor={item => item.toString()}
						renderItem={({ item }) => {
							const isSelect = select === item;
							return (
								<View
									style={{
										width: 100,
										height: 73,
										marginRight: item === 4 ? 24 : 10,
										backgroundColor: isSelect ? 'blue' : 'grey',
										marginLeft: item === 1 ? 24 : 0,
									}}>
									<Text>{item}</Text>
								</View>
							);
						}}
					/>
				</Animated.View>
				<FlatList
					ref={flatListRef}
					contentContainerStyle={{ marginTop: 73 }}
					style={{ flex: 1 }}
					data={[1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 16, 17, 18, 19]}
					keyExtractor={item => item.toString()}
					renderItem={item => {
						return <View style={{ height: 100, backgroundColor: 'rgba(194, 194, 194, 0.1)', marginBottom: 10 }} />;
					}}
					onScroll={event => {
						const { y } = event.nativeEvent.contentOffset;
						show(event.nativeEvent.contentOffset.y);
						scrollDirection.current = y - lastOffset.current > 0 ? 'down' : 'up';
						lastOffset.current = y;
						// scrollY.setValue(y);
					}}
					onScrollEndDrag={() => {
						if (scrollDirection.current === 'down' && lastOffset.current < 73) {
							flatListRef.current?.scrollToOffset({
								offset: 100,
								animated: true,
							});
						}
						if (scrollDirection.current === 'up' && lastOffset.current < 30) {
							flatListRef.current?.scrollToOffset({
								offset: 0,
								animated: true,
							});
						}
						// scrollY.setValue(scrollDirection.current === 'down' ? 100 : 0);
						// show(scrollDirection.current === 'down' ? 100 : 0);
					}}
					showsVerticalScrollIndicator={false}
					scrollEventThrottle={16}
				/>
			</View>
		</SafeAreaView>
	);
};

export default Report;
