import { StyleSheet, Dimensions } from 'react-native';

const windowHeight = Dimensions.get('window').height;
const windowWidth = Dimensions.get('window').width;

export const styles = StyleSheet.create({
	container: {
		paddingVertical: 14,
		paddingHorizontal: 16,
		minHeight: windowHeight / 7,
	},
	vContainer: {
		width: '100%',
	},
	vInfoUser: { flexDirection: 'row', alignItems: 'center' },
	vName: { flex: 2.5, flexDirection: 'row', alignItems: 'center' },
	tName: { color: 'rgba(123, 123, 123, 1)', fontSize: 14, fontWeight: '600', marginLeft: 10 },
	tExpand: { color: 'rgba(123, 123, 123, 1)', fontSize: 12, fontWeight: '600', marginLeft: 0 },
	tTime: { flex: 1.5, textAlign: 'right', fontSize: 12, fontWeight: '500' },
	tContent: { marginBottom: 5, marginTop: 5 },
	tWorkflow: { fontSize: 10, color: 'grey', marginBottom: 5 },
	vInfoWorkflow: { flexDirection: 'row' },
	vCountComment: { flexDirection: 'row', alignItems: 'center', marginRight: 10 },
	tCountComment: { marginLeft: 4, color: 'rgba(123, 123, 123, 1)', fontSize: 12, fontWeight: '500' },
	vCountFile: { flexDirection: 'row', alignItems: 'center', marginRight: 10 },
	tCountFile: { marginLeft: 4, color: 'rgba(123, 123, 123, 1)', fontSize: 12, fontWeight: '500' },
	vDate: { flexDirection: 'row', alignItems: 'center', marginRight: 10 },
	tDate: { marginLeft: 4, fontSize: 12, fontWeight: '500' },
	vTitle: { flex: 1, alignItems: 'flex-end' },
	vButtonTitle: {
		paddingVertical: 4,
		minWidth: 100,
		borderRadius: 4,
		alignItems: 'center',
	},
	dvd: {
		width: windowWidth,
		height: 5,
		position: 'absolute',
		bottom: 0,
		backgroundColor: 'rgba(227, 227, 227, 0.5)',
	},
});
