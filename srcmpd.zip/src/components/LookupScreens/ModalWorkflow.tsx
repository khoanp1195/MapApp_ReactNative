/* eslint-disable prettier/prettier */
import { ENDPOINT } from 'http/modules';

import React, { forwardRef, useRef, useState, useImperativeHandle, useEffect } from 'react';

import { Icon } from 'components/Atoms/Icon';
import ModalRef from 'components/Molecules/Modal/ModalRef';
import { COLORS } from 'config';
import { ICONS } from 'config/images';
import useDebounce from 'hooks/useDebounce';
import useInfinity from 'hooks/useInfinity';
import useSystem from 'hooks/useSystem';
import { View, FlatList, TouchableOpacity, Text, TextInput, Dimensions, RefreshControl } from 'react-native';
import { ItemWorkflow } from 'screens/Apps/Containers';
import { translate } from 'utils/translate';

interface IWorkflow {
	ID: number;
	WorkflowID: number;
	Title: string;
	TitleEN: string;
	Description: any;
	ImageURL: string;
	IsFavor: number;
	WorkflowCategory: string;
	WorkflowCategoryID: number;
}

export interface Props {
	onHide?: () => void;
	onSubmitSelect: (select: IWorkflow[]) => void
	isMulti?: boolean
}

const ModalWorkflow = ({ onHide, onSubmitSelect, isMulti = false }: Props, ref: React.Ref<unknown> | undefined) => {
	const refModal = useRef<{ show: () => void; hide: () => void } | null>(null);
	const { lid, isVN } = useSystem()
	const windowHeight = Dimensions.get('window').height;

	const onEndReachedCalledDuringMomentum = useRef(true)

	const [keyword, setKeyword] = useState('')
	const [select, setSelect] = useState<IWorkflow[]>([]);
	const [open, setOpen] = useState(false)

	const dbKeyword = useDebounce(keyword, 300)

	const {
		state: { data: dataRes, refreshing, loading },
		gotoFirstPage,
		refreshPage,
		fetchMore,
	} = useInfinity<Array<ItemWorkflow>>(`${ENDPOINT.WORKFLOW}`, {
		size: 10,
		requireAuthentication: true,
		params: {
			func: 'getOrSearchListWorkflow',
			flag: 2,
			data: `{"PerType": -1,"WorkflowCategoryId":"0","Keyword":${JSON.stringify(keyword || '')}}`,
			lid,
		},
	});

	const show = (workflow = []) => {
		if (workflow) {
			setSelect(workflow)
		}
		setOpen(true)
		setTimeout(() => {
			refModal.current?.show()
		}, 100);
	}
	const hide = () => {
		setOpen(false)
		refModal.current?.hide()
	}

	useImperativeHandle(
		ref,
		() => ({
			show,
			hide
		}),
		[],
	);


	useEffect(() => {
		if (open) {
			gotoFirstPage();
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [dbKeyword, open]);

	const dataWorkFlow: Array<IWorkflow> = [
		{ Title: translate('flag_all'), TitleEN: translate('flag_all'), WorkflowID: 0 },
		...(Array.isArray(dataRes) ? dataRes : []),
	];

	const onEndReachedHandler = () => {
		if (!loading) {
			fetchMore()
		}
	}

	const onSubmit = (data) => {
		hide()
		onSubmitSelect(data || select)
	}

	const ListFooterComponent = <View style={{ marginBottom: 200 }} />

	const onStartHide = () => {
		try {
			refreshPage()
			onHide()
		} catch (error) {
			//
		}
	}

	const onHideModal = () => {
		setOpen(false)
		setKeyword('')
	}
	return (
		<ModalRef
			ref={refModal}
			onHide={onHideModal}
			outsideClickCloseable
			onClose={onStartHide}
			visiblePosition="bottom"
			isTouch={false}
			avoidKeyboard={false}
		>
			<View style={{
				paddingHorizontal: 24,
				height: windowHeight * 0.8,
				overflow: 'hidden',
				backgroundColor: 'white',
				borderTopEndRadius: 8,
				borderTopStartRadius: 8
			}}>

				<View style={{ marginTop: 24, }}>
					<Text style={{ fontSize: 14, fontWeight: '700' }}>{translate('workflow')}</Text>
				</View>

				<TextInput
					placeholder={`${translate('findWorkflow')}`}
					style={{
						height: 46,
						// backgroundColor: 'rgba(246, 248, 254, 1)',
						paddingHorizontal: 10,
						borderRadius: 8,
						fontSize: 16,
						marginVertical: 20,
						borderWidth: 0.8,
						borderColor: 'rgba(217, 217, 217, 1)'
					}}
					onChangeText={setKeyword}
					maxLength={255}
				/>
				< View style={{}}>
					<FlatList
						refreshControl={
							<RefreshControl refreshing={refreshing} onRefresh={refreshPage} tintColor={COLORS.trueBlue} />
						}
						contentContainerStyle={{ marginBottom: 50 }}
						data={dataWorkFlow}
						keyExtractor={(item, index) => index.toString()}
						showsVerticalScrollIndicator={false}
						renderItem={({ item }) => {
							const selected = select.find(itemSelect => itemSelect.WorkflowID === item.WorkflowID)
							const onPress = () => {
								if (isMulti) {
									setSelect([item])
									return onSubmit([item])
								}
								if (item.WorkflowID === 0) return setSelect([item])
								if (selected) return setSelect(select.filter(itemSelect =>
									itemSelect.WorkflowID !== item.WorkflowID && itemSelect.WorkflowID !== 0
								))
								setSelect([...select, item].filter(itemSelect => itemSelect.WorkflowID !== 0))
							}

							return (
								<TouchableOpacity onPress={onPress}
									style={{
										paddingVertical: 16,
										borderRadius: 10,
										flexDirection: 'row',
										alignItems: 'center',
										backgroundColor: selected ? '#DBEBFF' : 'white',
										paddingHorizontal: 8
									}}
								>
									<Icon
										src={selected ? ICONS.icCheckUser : ICONS.icUnCheckUser}
										width={20}
										height={20}
									/>
									<Text numberOfLines={1} style={{ textAlign: 'left', fontWeight: '500', paddingHorizontal: 12 }}>{isVN ? item?.Title : item?.TitleEN}</Text>
								</TouchableOpacity>
							);
						}
						}
						ListFooterComponent={ListFooterComponent}
						onEndReachedThreshold={0.1}
						onEndReached={onEndReachedHandler}
						onMomentumScrollBegin={() => { onEndReachedCalledDuringMomentum.current = false }}
					/>
					{!isMulti && <View style={{ height: 100, width: '100%', paddingTop: 10 }}>
						<TouchableOpacity onPress={() => onSubmit()} style={{ backgroundColor: 'rgba(0, 95, 212, 1)', paddingVertical: 16, alignItems: 'center', borderRadius: 12 }} >
							<Text style={{ color: 'white', fontSize: 16, fontWeight: '600' }}>{translate('save')}</Text>
						</TouchableOpacity>
					</View>}
				</View>

			</View >

		</ModalRef >
	);
};

export default forwardRef(ModalWorkflow);


