/* eslint-disable prettier/prettier */
import React, { forwardRef, useRef, useState, useImperativeHandle, useMemo } from 'react';

import { Icon } from 'components/Atoms/Icon';
import ModalRef from 'components/Molecules/Modal/ModalRef';
import { ICONS } from 'config/images';
import useSystem from 'hooks/useSystem';
import { View, FlatList, TouchableOpacity, Text, Dimensions } from 'react-native';
import { useAppSelector } from 'stores';
import { translate } from 'utils/translate';


interface IState {
	value: number;
	label: string;
	labelEN: string;

}
const windowHeight = Dimensions.get('window').height;


const ModalState = ({ onHide, onSubmitSelect, hideState = [] }: { onHide?: () => void, onSubmitSelect: (data: IState[]) => void; hideState: string[] }, ref: React.Ref<unknown> | undefined) => {
	const refModal = useRef<{ show: () => void; hide: () => void } | null>(null);

	const { beanAppStatus } = useAppSelector(state => state.system);
	const { isVN } = useSystem()

	const [select, setSelect] = useState<IState[]>([]);


	const show = (state = []) => {
		refModal.current?.show()
		setSelect(state)
	}
	const hide = () => refModal.current?.hide()

	useImperativeHandle(
		ref,
		() => ({
			show,
			hide
		}),
		[],
	);

	const dataFilterStatusGroup = useMemo(
		() =>
			beanAppStatus?.map(({ ID: value, TitleEN: labelEN, Title: labelVN }) => {
				return {
					value,
					label: labelVN,
					labelEN,
				};
			}) as IState[],
		[beanAppStatus],
	).filter(item => item.value !== 32);

	const data = dataFilterStatusGroup.filter(elm => !hideState?.includes(elm.value.toString()))

	const onSubmit = () => {
		hide()
		onSubmitSelect(select)
	}




	return <ModalRef
		ref={refModal}
		onHide={onHide}
		outsideClickCloseable
		onClose={hide}
		visiblePosition="bottom"
		isTouch={false}
	>
		<View style={{
			paddingHorizontal: 24, height: windowHeight * 0.8, backgroundColor: 'white', borderTopEndRadius: 8,
			borderTopStartRadius: 8
		}} >
			<View style={{ marginVertical: 24 }}>
				<Text style={{ fontSize: 14, fontWeight: '700' }}>{translate('state')}</Text>
			</View>
			<FlatList
				contentContainerStyle={{}}
				data={[{ label: translate('flag_all'), value: 0, labelEN: 'All' }, ...data]}
				keyExtractor={(item, index) => index.toString()}
				showsVerticalScrollIndicator={false}
				renderItem={({ item }) => {
					const selected = select.find(itemSelect => itemSelect.value === item.value)
					const onPress = () => {
						if (select?.length === 1) {
							if (selected) {
								return setSelect([{ "label": "Tất cả", "labelEN": "All", "value": 0 }])
							}
							return setSelect([...select, item].filter(itemSelect => itemSelect.value !== 0))

						}
						if (item.value === 0) return setSelect([item])
						if (selected) return setSelect(select.filter(itemSelect =>
							itemSelect.value !== item.value && itemSelect.value !== 0
						))
						setSelect([...select, item].filter(itemSelect => itemSelect.value !== 0))
					}
					return (
						<TouchableOpacity onPress={onPress}
							style={{
								paddingVertical: 16,
								borderRadius: 10,
								flexDirection: 'row',
								alignItems: 'center',
								backgroundColor: selected ? '#DBEBFF' : 'white',
								paddingHorizontal: 8, marginBottom: 2
							}}
						>
							<Icon
								src={selected ? ICONS.icCheckUser : ICONS.icUnCheckUser}
								width={20}
								height={20}
							/>
							<Text style={{ textAlign: 'center', fontWeight: '500', paddingHorizontal: 12 }}>{isVN ? item?.label : item?.labelEN}</Text>
						</TouchableOpacity>
					);
				}
				}
			/>
			<View style={{ width: '100%', marginTop: 20, marginBottom: 50 }}>
				<TouchableOpacity onPress={onSubmit} style={{ backgroundColor: 'rgba(0, 95, 212, 1)', paddingVertical: 16, alignItems: 'center', borderRadius: 12 }} >
					<Text style={{ color: 'white', fontSize: 16, fontWeight: '600' }}>{translate('save')}</Text>
				</TouchableOpacity>
			</View>
		</View>
	</ModalRef>
}

export default forwardRef(ModalState)
