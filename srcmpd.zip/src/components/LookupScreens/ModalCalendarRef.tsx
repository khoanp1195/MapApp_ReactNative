import React, { forwardRef, useState, useImperativeHandle } from 'react';

import { CalendarModal } from 'components/Organisms/CalendarModal';
import { COLORS } from 'config';
import dayjs from 'dayjs';
import { translate } from 'utils/translate';

interface IOptions {
	headerTitle: string;
	defaultValue: Date | string;
	maxDate: string;
	minDate: string;
}

const ModalCalendarRef = (
	{ onSubmitSelect }: { onSubmitSelect: (data: { date: Date; isFromDate: boolean }) => void },
	ref: React.Ref<unknown> | undefined,
) => {
	const [open, setOpen] = useState(false);
	const [options, setOptions] = useState<IOptions>({
		headerTitle: '',
		defaultValue: '',
		maxDate: '',
		minDate: '',
	});

	const show = (ops: React.SetStateAction<IOptions>) => {
		setOpen(true);
		setOptions(ops);
	};
	const hide = () => {
		setOpen(false);
		setOptions({
			headerTitle: '',
			defaultValue: '',
			maxDate: '',
			minDate: '',
		});
	};

	useImperativeHandle(
		ref,
		() => ({
			show,
			hide,
		}),
		[],
	);

	const handleSelectDate = (date: Date) => {
		onSubmitSelect({ date, isFromDate: !!options?.maxDate });
		hide();
	};

	if (!options?.defaultValue) return null;
	return (
		<CalendarModal
			headerTitle={options.headerTitle}
			footerTitle={translate('filter_apply')}
			pastScrollRange
			isVisible={open}
			onClose={hide}
			color={COLORS.trueBlue}
			defaultValue={dayjs(options.defaultValue).format('YYYY-MM-DD')}
			onDateSelected={handleSelectDate}
			maxDate={options?.maxDate ? new Date(options.maxDate).toDateString() : ''}
			minDate={options?.minDate ? new Date(options.minDate).toDateString() : ''}
		/>
	);
};

export default forwardRef(ModalCalendarRef);
