import React from 'react';

import { Text } from 'components/Atoms/Text';
import { translate } from 'utils/translate';

import { Props } from './interfaces';
import { Container } from './styles';

export const EmptyState: React.FC<Props> = ({ title, children, description }) => (
	<Container>
		{children}
		{title && (
			<Text fs={13} fw="bold">
				{title}
			</Text>
		)}
		<Text>{description || translate('nodata')}</Text>
	</Container>
);
