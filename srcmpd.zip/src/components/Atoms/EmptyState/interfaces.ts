import React from 'react';

export interface Props {
	title?: string;
	description?: string;
	children?: React.ReactNode;
}
