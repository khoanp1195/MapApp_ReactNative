import React from 'react';

import { storiesOf } from '@storybook/react-native';

import { EmptyState } from '.';

storiesOf('Molecules/EmptyState', module).add('default', () => (
	<EmptyState title="Không có dữ liệu" description="Không có dữ liệu Không có dữ liệu" />
));
