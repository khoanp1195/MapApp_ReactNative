import React from 'react';

import { storiesOf } from '@storybook/react-native';

import { SwitchLanguage } from '.';

storiesOf('Atoms/SwitchLanguage', module).add('default', () => <SwitchLanguage />);
