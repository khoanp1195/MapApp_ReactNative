import { COLORS } from 'config';
import styled from 'styled-components/native';

export const Container = styled.View`
	flex-direction: row;
	align-items: center;
	padding: 3px 4px;
	border-radius: 2px;
	background-color: ${COLORS.whiteSmoke};
`;

export const TextSwitch = styled.Text<{ active?: boolean }>`
	font-style: normal;
	font-weight: 400;
	font-size: 14px;
	line-height: 16px;
	border-radius: 2px;
	padding: 2px 6px;
	background-color: ${props => (props.active ? COLORS.white : COLORS.transparent)};
	color: ${props => (props.active ? COLORS.black : COLORS.textGrey)};
`;
