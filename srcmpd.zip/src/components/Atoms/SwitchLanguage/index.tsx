// import React, { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';

// import { ICONS } from 'config';
// import { View, Text, TouchableOpacity, LayoutAnimation } from 'react-native';
// import { useAppDispatch, useAppSelector } from 'stores';
// import { updateLanguage } from 'stores/System';

// import { Icon } from '../Icon';

// const SwitchLanguage = (
// 	{ isTurnOnDrawer, onHandleSwitch }: { isTurnOnDrawer: boolean },
// 	ref: React.Ref<unknown> | undefined,
// ) => {
// 	const dispatch = useAppDispatch();
// 	const { language } = useAppSelector(state => state.system);
// 	const refLN = useRef('');

// 	const [show, setShow] = useState(false);

// 	const hide = () => {
// 		setShow(false);
// 	};

// 	useEffect(() => {
// 		onHandleSwitch(show);
// 		if (refLN.current) {
// 			dispatch(updateLanguage(refLN.current));
// 			refLN.current = '';
// 		}
// 	}, [show]);

// 	useImperativeHandle(
// 		ref,
// 		() => ({
// 			hide,
// 		}),
// 		[],
// 	);

// 	useEffect(() => {
// 		if (!isTurnOnDrawer) setShow(isTurnOnDrawer);
// 	}, [isTurnOnDrawer]);

// 	return (
// 		<View style={{}}>
// 			<TouchableOpacity
// 				activeOpacity={1}
// 				onPress={() => {
// 					setShow(!show);
// 					LayoutAnimation.easeInEaseOut();
// 				}}
// 				style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: 80 }}>
// 				<Text style={{ fontSize: 15, fontWeight: '500', marginRight: 4 }}>
// 					{language === 'vi' ? 'Việt Nam' : 'English'}
// 				</Text>
// 				<Icon src={ICONS.icArrowDown} width={12} height={12} />
// 			</TouchableOpacity>
// 			<View style={{ zIndex: 999 }}>
// 				{show && (
// 					<View style={{ position: 'absolute', top: 4, zIndex: 1 }}>
// 						<TouchableOpacity
// 							onPress={() => {
// 								setShow(false);
// 								refLN.current = 'vi';
// 								LayoutAnimation.easeInEaseOut();
// 							}}>
// 							<Text
// 								style={{
// 									fontSize: 15,
// 									fontWeight: '500',
// 									marginBottom: 2,
// 									color: language === 'vi' ? 'black' : 'rgba(123, 123, 123, 1)',
// 								}}>
// 								Việt Nam
// 							</Text>
// 						</TouchableOpacity>
// 						<TouchableOpacity
// 							onPress={() => {
// 								setShow(false);
// 								refLN.current = 'en';

// 								LayoutAnimation.easeInEaseOut();
// 							}}>
// 							<Text
// 								style={{
// 									fontSize: 15,
// 									fontWeight: '500',
// 									color: language !== 'vi' ? 'black' : 'rgba(123, 123, 123, 1)',
// 								}}>
// 								English
// 							</Text>
// 						</TouchableOpacity>
// 					</View>
// 				)}
// 			</View>
// 		</View>
// 	);
// };

// export default forwardRef(SwitchLanguage);

import React from 'react';

import { useAppDispatch, useAppSelector } from 'stores';
import { updateLanguage } from 'stores/DataNotRemove';

import { Container, TextSwitch } from './styles';

const SwitchLanguage = () => {
	const dispatch = useAppDispatch();
	const { language } = useAppSelector(state => state.dataNotRemove);

	return (
		<Container>
			<TextSwitch
				active={language === 'vi'}
				onPress={() => dispatch(updateLanguage('vi'))}
				style={{ fontSize: 14, fontWeight: '600' }}>
				VN
			</TextSwitch>
			<TextSwitch
				active={language === 'en'}
				onPress={() => dispatch(updateLanguage('en'))}
				style={{ fontSize: 14, fontWeight: '600' }}>
				EN
			</TextSwitch>
		</Container>
	);
};

export default SwitchLanguage;
