import React from 'react';

import { storiesOf } from '@storybook/react-native';
import styled from 'styled-components/native';

import { Divider } from '.';

const Content = styled.View`
	width: 100%;
	height: 10%;
	justify-content: space-between;
`;

storiesOf('Atoms/Divider', module).add('default', () => (
	<Content>
		<Divider />
		<Divider content="Hoặc" />
	</Content>
));
