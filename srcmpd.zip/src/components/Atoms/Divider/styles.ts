import { FONTS, COLORS } from 'config';
import styled, { css } from 'styled-components/native';

export const Container = styled.View`
	justify-content: center;
	align-items: center;
	flex-direction: row;
	background-color: ${COLORS.white};
`;

export const CustomDivider = styled.View<{ type?: 'horizontal' | 'vertical' }>`
	${props =>
		props.type === 'horizontal'
			? css`
					flex: 1;
					height: 1px;
			  `
			: css`
					width: 1px;
					min-height: 75px;
			  `};
	background-color: ${COLORS.platinum};
`;

export const CustomContent = styled.Text`
	text-align: center;
	color: ${COLORS.cadetGrey};
	font-size: 15px;
	line-height: 20px;
	font-family: ${FONTS['Roboto-Regular']};
	padding: 0px 8px;
`;
