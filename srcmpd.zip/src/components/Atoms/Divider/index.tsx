import React from 'react';

import { DividerProps } from './interfaces';
import { Container, CustomContent, CustomDivider } from './styles';

export const Divider: React.FC<DividerProps> = ({ content, style, type = 'horizontal' }) => (
	<Container>
		{content ? (
			<>
				<CustomDivider />
				<CustomContent>{content}</CustomContent>
				<CustomDivider />
			</>
		) : (
			// eslint-disable-next-line @typescript-eslint/ban-ts-comment
			// @ts-ignore
			<CustomDivider style={style} type={type} />
		)}
	</Container>
);
