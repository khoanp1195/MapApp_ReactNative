import { StyleProp, ViewStyle } from 'react-native';

export interface DividerProps {
	content?: string;
	type?: 'horizontal' | 'vertical';
	style?: StyleProp<ViewStyle>;
}
