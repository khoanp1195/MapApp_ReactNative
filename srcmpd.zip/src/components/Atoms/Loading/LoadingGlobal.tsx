import React, { useImperativeHandle, useState, createRef, useEffect } from 'react';

import { COLORS } from 'config';
import { View, Text, Dimensions } from 'react-native';
import { MaterialIndicator } from 'react-native-indicators';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const windowHeight = Dimensions.get('window').height;

const refLoading = createRef();

export const ShowLoading = (status: boolean) => {
	refLoading.current?.show(status);
};

const LoadingGlobal = () => {
	const [isLoading, setLoading] = useState(false);
	const { bottom } = useSafeAreaInsets();

	useImperativeHandle(
		refLoading,
		() => ({
			show: (status: boolean) => {
				setLoading(status);
			},
		}),
		[],
	);

	useEffect(() => {
		if (isLoading) {
			setTimeout(() => {
				setLoading(false);
			}, 15000);
		}
	}, [isLoading]);

	if (!isLoading) {
		return null;
	}

	return (
		<View
			style={{
				position: 'absolute',
				backgroundColor: COLORS.lineGrey,
				flex: 1,
				width: '100%',
				height: windowHeight + bottom,
				zIndex: 999,
				alignItems: 'center',
				justifyContent: 'center',
			}}>
			<Text>
				<MaterialIndicator color={COLORS.trueBlue} size={35} />;
			</Text>
		</View>
	);
};

export default LoadingGlobal;
