/* eslint-disable react/jsx-props-no-spreading */
// @see https://github.com/chramos/react-native-skeleton-placeholder/blob/master/src/SkeletonPlaceholder.tsx

import React, { forwardRef, useImperativeHandle, useState } from 'react';

import { COLORS } from 'config';
import { Text, View, Dimensions } from 'react-native';
import { MaterialIndicator } from 'react-native-indicators';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export interface LoadingState {
	show?: (e: boolean) => void;
}

const windowHeight = Dimensions.get('window').height;

const LoadingRef = ({ }, ref: LoadingState) => {
	const [isShow, setIsShow] = useState(false);
	const { bottom } = useSafeAreaInsets();

	const _show = e => setIsShow(e);

	useImperativeHandle(
		ref,
		() => ({
			show: _show,
		}),
		[],
	);
	if (!isShow) return null;

	return (
		<View
			style={{
				position: 'absolute',
				backgroundColor: COLORS.lineGrey,
				flex: 1,
				width: '100%',
				height: windowHeight + bottom,
				zIndex: 999,
				alignItems: 'center',
				justifyContent: 'center',
			}}>
			<Text>
				<MaterialIndicator color={COLORS.trueBlue} size={35} />;
			</Text>
		</View>
	);
};

export default forwardRef(LoadingRef);
