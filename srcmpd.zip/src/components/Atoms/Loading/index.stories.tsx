import React from 'react';

import { storiesOf } from '@storybook/react-native';

import { Loading } from '.';

storiesOf('Atoms/Loading', module)
	.add('default', () => <Loading animating />)
	.add('small', () => <Loading animating size="small" />);
