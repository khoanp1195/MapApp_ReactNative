/* eslint-disable react/jsx-props-no-spreading */
// @see https://github.com/chramos/react-native-skeleton-placeholder/blob/master/src/SkeletonPlaceholder.tsx

import React from 'react';

import { COLORS } from 'config';
import { MaterialIndicator } from 'react-native-indicators';

import { Props } from './interfaces';

export const Loading: React.FC<Props> = ({ color, size = 'large', ...innerProps }) => (
	<MaterialIndicator color={color || COLORS.trueBlue} size={size === 'large' ? 50 : 35} {...innerProps} />
);
