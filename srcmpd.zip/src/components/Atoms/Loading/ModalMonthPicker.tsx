/* eslint-disable react-hooks/exhaustive-deps */
import React, { createRef, useImperativeHandle, useRef, useState } from 'react';

import { COLORS } from 'config';
import useSystem from 'hooks/useSystem';
import { View, Text, TouchableWithoutFeedback, LayoutAnimation, Dimensions } from 'react-native';
import MonthPicker from 'react-native-month-year-picker';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppDispatch } from 'stores';
import { updateDateMonth } from 'stores/Workflows/sliceWorkflow';

export const refModalMonthPicker = createRef<{
	show: (position?: { top: number; left: number; heightItem: number }, element?: React.ReactElement) => void;
	hide: () => void;
} | null>();

const ModalMonthPicker = () => {
	const dispatch = useAppDispatch();
	const [show, setShow] = useState(false);
	const [defaultValue, setDefaultValue] = useState();
	const [name, setName] = useState('');
	const { language } = useSystem();

	const handleShow = (date, name) => {
		setShow(true);
		setName(name);
		setDefaultValue(date);
	};

	useImperativeHandle(
		refModalMonthPicker,
		() => ({
			show: handleShow,
			hide: () => setShow(false),
		}),
		[defaultValue, show],
	);

	const onValueChange = (event, newDate) => {
		if (event === 'dateSetAction') {
			dispatch(
				updateDateMonth({
					name,
					value: newDate,
				}),
			);
		}
		setShow(false);
	};

	if (!show) return null;

	return (
		<TouchableWithoutFeedback>
			<View
				style={{
					backgroundColor: COLORS.lineGrey,
					flex: 1,
					position: 'absolute',
					zIndex: 999,
					width: '100%',
					height: '100%',
				}}>
				<MonthPicker
					onChange={onValueChange}
					value={defaultValue ? new Date(defaultValue) : new Date()}
					// minimumDate={new Date()}
					// maximumDate={new Date(2025, 5)}
					locale={language}
					cancelButton="Cancle"
					okButton="Confirm"
				/>
			</View>
		</TouchableWithoutFeedback>
	);
};

export default ModalMonthPicker;
