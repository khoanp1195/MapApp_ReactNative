/* eslint-disable @typescript-eslint/no-shadow */
/* eslint-disable react-hooks/exhaustive-deps */
import React, { createRef, useImperativeHandle, useState } from 'react';

import { COLORS } from 'config';
import { View, Text, TouchableWithoutFeedback, LayoutAnimation, Dimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export const refDropDown = createRef<{
	show: (position?: { top: number; left: number; heightItem: number }, element?: React.ReactElement) => void;
	hide: () => void;
} | null>();

const windowHeight = Dimensions.get('window').height;
const windowWidth = Dimensions.get('window').width;

const DropDown = () => {
	const [show, setShow] = useState(false);
	const [element, setElemnt] = useState<React.ReactElement>();
	const [position, setPosition] = useState({
		top: 0,
		left: 0,
		heightItem: 0,
	});
	const insets = useSafeAreaInsets();

	const handleShow = (position: { top: number; left: number; heightItem: number }, element: React.ReactElement) => {
		setPosition(position);
		setElemnt(element);
		setShow(true);
		LayoutAnimation.easeInEaseOut();
	};

	useImperativeHandle(
		refDropDown,
		() => ({
			show: handleShow,
			hide: () => setShow(false),
		}),
		[position, show],
	);

	if (!show || !element) return null;
	return (
		<TouchableWithoutFeedback onPress={() => setShow(false)}>
			<View
				style={{
					backgroundColor: 'rgba(255,255,255,0.3)',
					flex: 1,
					position: 'absolute',
					zIndex: 999,
					width: '100%',
					height: '100%',
				}}>
				<View
					style={{
						position: 'absolute',
						top:
							windowHeight - position.top > position.heightItem + (insets.bottom || 35) + 23
								? position.top + 23
								: position.top - (position.heightItem + (insets.bottom || 35) - 23),
						left:
							windowWidth - position.left > 230 ? position.left : position.left - (230 - (windowWidth - position.left)),
						right: 0,
						// bottom: 0,
						backgroundColor: 'white',
						overflow: 'hidden',
						justifyContent: 'center',
						borderRadius: 10,
						maxWidth: 230,
					}}>
					<View
						style={{
							margin: 3,
							backgroundColor: 'white',
							shadowColor: '#000',
							shadowOffset: {
								width: 1,
								height: 2,
							},
							shadowOpacity: 0.2,
							shadowRadius: 2,
							borderRadius: 10,
							elevation: 5,
						}}>
						{element}
					</View>
				</View>
			</View>
		</TouchableWithoutFeedback>
	);
};

export default DropDown;
