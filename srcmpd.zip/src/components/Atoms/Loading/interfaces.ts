import { MaterialIndicatorProps } from 'react-native-indicators';

export interface Props extends Pick<MaterialIndicatorProps, 'style' | 'color' | 'animating'> {
	size?: 'large' | 'small';
}
