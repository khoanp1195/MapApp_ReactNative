import { COLORS, FONTS } from 'config';
import styled, { css } from 'styled-components/native';

import { Props } from './interfaces';

export const Heading = styled.Text<Props>`
	font-size: ${props => props.fs || 16}px;
	color: ${props => props.color || COLORS.black};
	line-height: ${props => props.lh || 20}px;
	${props =>
		typeof props.fw === 'number' &&
		props.fw &&
		css`
			font-weight: ${props.fw || 400};
		`}
	margin-left: ${props => props.ml || 0}px;
	${props =>
		typeof props.fw === 'string' &&
		props.fw === 'normal' &&
		css`
			font-family: ${FONTS['Roboto-Regular']};
			font-weight: ${props.fw};
		`}
	${props =>
		typeof props.fw === 'string' &&
		props.fw !== 'normal' &&
		css`
			font-family: ${FONTS['Roboto-Bold']};
			font-weight: ${props.fw};
		`}
	${props =>
		props.lh &&
		css`
			line-height: ${props.lh}px;
		`};
	text-align: ${props => props.textAlign};
`;
