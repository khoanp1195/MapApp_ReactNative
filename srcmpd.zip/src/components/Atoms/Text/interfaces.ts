import { COLORS } from 'config';
import { StyleProp, TextStyle, ViewStyle } from 'react-native';

export interface Props {
	fs?: number;
	fw?: number | string;
	color?: keyof typeof COLORS;
	numberOfLines?: number;
	lh?: number;
	allowFontScaling?: boolean;
	ml?: number;
	textAlign?: 'center' | 'left' | 'right' | 'justify';
	onPress?: () => void;
	style?: StyleProp<ViewStyle | TextStyle>;
	children?: React.ReactNode;
}
