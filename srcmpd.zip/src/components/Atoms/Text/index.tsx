/* eslint-disable @typescript-eslint/ban-ts-comment */
import React from 'react';

import { Props } from './interfaces';
import { Heading } from './styles';

export const Text: React.FC<Props> = ({
	numberOfLines,
	lh,
	fs,
	fw,
	color,
	allowFontScaling,
	textAlign = 'left',
	children,
	onPress,
	style,
}) => (
	<Heading
		fs={fs}
		fw={fw}
		color={color}
		allowFontScaling={allowFontScaling}
		numberOfLines={numberOfLines}
		lh={lh}
		textAlign={textAlign}
		// @ts-ignore
		style={style}
		onPress={onPress}>
		{children}
	</Heading>
);

Text.defaultProps = { allowFontScaling: false };
