import React from 'react';

import { Image, TouchableOpacity } from 'react-native';

import { Props } from './interfaces';

export const Icon: React.FC<Props> = ({ width, height, src, onPress, style, tintColor, resizeMode, aspectRatio }) => (
	<TouchableOpacity
		onPress={onPress}
		disabled={!onPress}
		style={style}
		hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
		<Image source={src} style={{ width, height, tintColor, aspectRatio }} resizeMode={resizeMode || 'contain'} />
	</TouchableOpacity>
);
