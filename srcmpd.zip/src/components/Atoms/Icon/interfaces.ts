import { ImageProps, ImageResizeMode, StyleProp, ViewStyle } from 'react-native';

export interface Props {
	width?: number;
	height?: number;
	src: ImageProps['source'];
	iconName?: string;
	onPress?: () => void;
	tintColor?: string;
	style?: StyleProp<ViewStyle>;
	resizeMode?: ImageResizeMode | undefined;
	aspectRatio?: number | string | undefined;
}
