import React from 'react';

import { storiesOf } from '@storybook/react-native';
import { ICONS } from 'config';
import { View } from 'react-native';

import { Icon } from '.';
import { styles } from './styles';

storiesOf('Atoms/icons', module).add('default', () => (
	<View style={styles.container}>
		<Icon width={110} height={110} src={ICONS.logo} />
	</View>
));
