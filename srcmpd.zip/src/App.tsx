/* eslint-disable import/no-extraneous-dependencies */
import React, { useEffect } from 'react';

import { Database } from '@nozbe/watermelondb';
import SQLiteAdapter from '@nozbe/watermelondb/adapters/sqlite';
import DatabaseProvider from '@nozbe/watermelondb/DatabaseProvider';
import TaskFormModel from 'database/models/TaskFormModel';
import { mySchema } from 'database/schemas/schema';
import { MainNavigator } from 'navigation';
import { LogBox, Platform, UIManager } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import Orientation from 'react-native-orientation-locker';
import { RootSiblingParent } from 'react-native-root-siblings';
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';
import store, { persistor } from 'stores';
import { requestUserPermission } from 'utils/notificationServices';

LogBox.ignoreLogs([
	'Non-serializable values were found in the navigation state',
	'Internal React error',
	'Encountered two children',
	'messaging().registerDeviceForRemoteMessages()',
	'PermissionsAndroid',
	'user canceled the document picker',
	'This can break usage such as persisting and restoring state',
	'Possible unhandled promise rejection',
	'Error evaluating injectedJavaScript',
	'Symbol(CancelError)',
]);

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
	UIManager.setLayoutAnimationEnabledExperimental(true);
}

const adapter = new SQLiteAdapter({
	schema: mySchema,
	dbName: 'DPMDB',
});

const database = new Database({
	adapter,
	modelClasses: [TaskFormModel],
});

const App = () => {
	useEffect(() => {
		Orientation.lockToPortrait();
		requestUserPermission();
	}, []);

	return (
		<DatabaseProvider database={database}>
			<GestureHandlerRootView style={{ flex: 1 }}>
				<Provider store={store}>
					<PersistGate loading={null} persistor={persistor}>
						{/* <RootSiblingParent> */}
						{/* <AnimatedBootSplash /> */}
						<MainNavigator />
						{/* </RootSiblingParent> */}
					</PersistGate>
				</Provider>
			</GestureHandlerRootView>
		</DatabaseProvider>
	);
};

export default App;
