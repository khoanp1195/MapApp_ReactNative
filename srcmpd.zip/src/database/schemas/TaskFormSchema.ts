import { TABLE } from 'database/contains';

const TaskFormSchema = {
	name: TABLE.TASKFORM,
	columns: [
		{ name: 'ListId', type: 'string' },
		{ name: 'FormFieldInfo', type: 'string' },
		{ name: 'InfoCollection', type: 'string' },
		{ name: 'DateModified', type: 'string' },
	],
};

export default TaskFormSchema;
