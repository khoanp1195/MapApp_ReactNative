import React, { useEffect } from 'react';

import { Q } from '@nozbe/watermelondb';
import { useDatabase } from '@nozbe/watermelondb/hooks';
import { AppState } from 'react-native';
import { useAppDispatch, useAppSelector } from 'stores';
import { getListFormTemplateModified } from 'stores/Apps';
import { getTimeSyncForm, setTimeSyncForm } from 'utils/keychain';

import { TABLE } from './contains';

interface Item {
	FormFieldInfo: string;
	FormDefineInfo: string;
	ListId: string;
}

const SyncForm = () => {
	const dispatch = useAppDispatch();
	const database = useDatabase();
	const isLogin = useAppSelector(store => store.dataNotRemove);

	const getFormSuccess = async res => {
		const { status: STATUS = '', data = {} } = res?.data || {};
		if (STATUS === 'SUCCESS') {
			await setTimeSyncForm(data.DateModified);
			const listData = data?.Data || [];

			listData?.forEach(async (item: Item) => {
				const formDB = await database.get(TABLE.TASKFORM).query(Q.where('ListId', item?.ListId)).fetch();
				if (formDB?.length) {
					await database.write(async () => {
						formDB[0].update(form => {
							form.FormFieldInfo = item.FormFieldInfo;
							form.InfoCollection = item.FormDefineInfo;
							form.DateModified = res.data.data.DateModified;
						});
					});
				}
			});
		}
	};

	const syncFormRequestApi = async () => {
		try {
			const modified = await getTimeSyncForm();
			const AllForm = await database.get(TABLE.TASKFORM).query().fetch();
			// AllForm[0].delete();
			if (AllForm?.length) {
				let ListIdForm = [];
				AllForm.map(list => {
					ListIdForm = [...ListIdForm, list?._raw?.ListId];
				});
				dispatch(
					getListFormTemplateModified({
						listid: ListIdForm.toString(),
						modified,
						success: getFormSuccess,
					}),
				);
			}
		} catch (error) {
			//
		}
	};

	const syncFormStatusState = () => {
		syncFormRequestApi();
	};

	const syncFormAppState = async () => {
		try {
			const modified = await getTimeSyncForm();
			const milisecond = new Date() - new Date(modified);
			if (milisecond / 1000 > 3600) {
				syncFormRequestApi();
			}
		} catch (error) {
			//
		}
	};

	useEffect(() => {
		if (isLogin) {
			syncFormStatusState();
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [isLogin]);

	useEffect(() => {
		const subscription = AppState.addEventListener('change', nextAppState => {
			if (nextAppState === 'active') {
				syncFormAppState();
			}
		});

		return () => {
			subscription.remove();
		};
	}, []);

	return null;
};

export default SyncForm;
