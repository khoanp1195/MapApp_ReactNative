import { Model } from '@nozbe/watermelondb';
import { field, writer } from '@nozbe/watermelondb/decorators';
import { TABLE } from 'database/contains';

export default class TaskFormModel extends Model {
	static table = TABLE.TASKFORM;

	@field('ListId') ListId: unknown;

	@field('FormFieldInfo') FormFieldInfo: unknown;

	@field('InfoCollection') InfoCollection: unknown;

	@field('DateModified') DateModified: unknown;

	@writer async delete() {
		await super.destroyPermanently();
	}

	@writer async updateForm(body) {
		await this.update(form => {
			form.FormFieldInfo = body.FormFieldInfo;
			form.InfoCollection = body.InfoCollection;
		});
	}
}
